# Required decisions

The authoritative content is contained in `FINAL_CONTRACT.md`; no matching standalone heading was present.
