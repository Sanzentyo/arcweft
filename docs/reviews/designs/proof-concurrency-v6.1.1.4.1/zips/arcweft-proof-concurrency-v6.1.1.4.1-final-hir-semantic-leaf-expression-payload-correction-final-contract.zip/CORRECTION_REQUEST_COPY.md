# Design request: Proof-concurrency 01.1.1.4.1 final HIR leaf/expression corrected redelivery

- Date: 2026-07-26
- Sequence: Proof-concurrency v6.1.1.4.1, correcting the rejected
  v6.1.1.4 return before the public HIR expression authority switch
- Kind: independently throwable, GitHub-only, design-only full replacement
- Production changes: prohibited
- Required archive name:
  `arcweft-proof-concurrency-v6.1.1.4.1-final-hir-semantic-leaf-expression-payload-correction-final-contract.zip`

## Previous redelivery evidence

The 2026-07-27 archive with the required name was integrity-valid but contained
only `FINAL_STATUS: NOT_READY` and a repository/package build-failure report.
It is retained at
`docs/reviews/designs/proof-concurrency-v6.1.1.4.1/arcweft-proof-concurrency-v6.1.1.4.1-final-hir-semantic-leaf-expression-payload-correction-final-contract.zip`
with SHA-256
`9ccb9af261a3d55bddefe570b4902d9ba6395725904f88bf389b4565e5bd8374`.
See
`docs/implementation/2026-07-27-proof-01-1-1-4-1-not-ready-redelivery-intake.md`.

That archive is not an accepted predecessor and supplies no schema decision.
The next assignee must inspect current GitHub `main` and return the same exact
archive name again; do not treat the failed archive as a delta input.

## Assignment

Return one standalone, decision-complete replacement for Proof
`01.1.1.4`. The previous return claimed `READY_FOR_IMPLEMENTATION`, but the
repository intake rejected that status because its exact Rust schemas change
accepted predecessor contracts and leave result-changing payload decisions to
the implementer.

There are no external attachments. Clone or inspect the latest GitHub `main`,
read the current `AGENTS.md`, the Rust skill available to you, this request,
the primary request, the intake note, and every accepted package and
implementation note referenced by those documents.

Normative repository paths include:

- `docs/reviews/requests/2026-07-25-seq-proof-01.1.1.4-final-hir-semantic-leaf-expression-payload-reconciliation.md`
- `docs/implementation/2026-07-26-proof-01.1.1.4-return-intake.md`
- `docs/implementation/2026-07-26-proof-hir-local-schema-decisions.md`
- `docs/reviews/packages/arcweft-proof-concurrency-v6.1.1-typed-ast-proof-block-hir-runtime-identity-final-contract.zip`
- `docs/reviews/packages/arcweft-aw-ah-009.3.1-call-surface-syntax-production-reconciliation-final-contract.zip`
- `docs/reviews/packages/arcweft-aw-ah-009.3.3-callable-catalog-shared-resolver-production-reconciliation-final-contract.zip`
- `docs/reviews/packages/arcweft-aw-ah-009.3.3.3.1-capacity-dialogue-and-overload-accounting-reconciliation-final-contract.zip`
- `docs/reviews/packages/arcweft-aw-ah-009.3.3.4-typed-associated-capacity-callee-authority-reconciliation-final-contract.zip`
- `docs/reviews/packages/arcweft-aw-ah-009.4-character-dialogue-first-class-runtime-final-contract.zip`
- `docs/reviews/packages/arcweft-aw-ah-009.4.2-dialogue-content-application-syntax-hir-ownership-production-reconciliation-final-contract.zip`

The GitHub-visible AW-AH-007/008 request and implementation notes remain the
RichText input. No external RichText archive is required.

## Decisions that remain usable

Retain these conclusions unless current repository evidence proves a concrete
contradiction:

- one qualified expression arena and one public expression authority;
- the 35-variant high-level `HirExprKind` inventory selected by the rejected
  return;
- deletion of ordinary-expression `DialogueCall` and `MemoBlock`;
- one ordinary-call model and the existing shared callable
  catalog/resolver/candidate-accounting authority;
- same-arena nested expressions for Dialogue/RichText; and
- revision-bound source components rather than semantic payload ranges.

The corrected archive must still restate these as part of a complete contract;
it must not be a delta that requires the rejected ZIP.

## Required corrections

### 1. Preserve later accepted ID and Dialogue schemas

AW-AH-009.4.2 is authoritative. Do not change its exact shapes without a
newer accepted source:

```rust
pub struct HirIdSuffix(Box<str>);
pub struct HirIdFamily(Box<str>);
pub struct HirRelativeId {
    suffix: HirIdSuffix,
    parent_depth: usize,
}
```

Preserve its complete `HirIdRef`, `HirDialogueContentApplication`,
`HirDialogueCoordinate`, `HirPostfixBracket`, candidate-failure,
`HirExprSourceRole`, `HirCallArgumentSourcePart`, `HirSourceSite`, insertion,
candidate-only `SyntheticRole`, and deterministic ordinal contracts. Extend
those owners only where the final expression inventory needs additional exact
variants. Do not replace them with an open-ended “including” list or a generic
role whose mapping is left to implementation.

### 2. Separate type regions from lifetime-registry access

The repository has two distinct concepts:

- type-region lifetimes, including named and elided region syntax; and
- script-visible lifetime-registry scopes/keys such as
  `'frame`, `'line.focus?`, and named registry scopes.

Define separate exact HIR owners, projections, validation, equality, and
source roles. Do not use one `HirLifetime` enum for both. Include the exact
projection of elided type regions and of every registry scope/access mode.

### 3. Preserve path-root semantics

`HirPath { absolute: bool, ... }` is insufficient for the current typed path
families. Select one exact design that preserves or transactionally resolves
implicit-crate, `crate`, `self`, and `super(n)` roots, external-capable project
symbol segments, aliases, and module context. Define failure and source-query
behavior. Do not split dotted source strings and do not silently collapse
`ProjectSymbolPath` root identity.

### 4. Close literal and numeric representation

Define exact direct lowering for every current literal family, including
Duration as a distinct typed semantic family unless repository language
authority proves an observable-equivalent merge. Specify its unit/value,
`Duration` type identity, equality, overflow, malformed recovery, and source
components.

An integer with overflow state cannot store only `magnitude: u128` without
defining what that field contains for a mathematical value greater than
`u128::MAX`. Select an overflow-capable canonical representation or reject
before constructing the valid integer payload while retaining exact typed
recovery evidence. Apply the same closure to compact numeric sequences.

Define decimal coefficient digit invariants, zero/leading-zero
canonicalization, scale/exponent bounds, float width selection, exact bits,
NaN/infinity policy, suffix handling, and unit-number lowering. No source
string may be reparsed later.

### 5. Reconcile associated-type call receivers

The accepted associated-capacity contract requires an authored typed receiver
tree and source map to reach nominal resolution and
`CallCallee::AssociatedType`. A final `HirCallExpr { callee: ExprId, ... }`
alone cannot represent `Vec<T>.with_capacity` without misclassifying the type
receiver as a value expression or retaining syntax.

Define the exact final HIR callee/receiver record, qualified type/receiver ID,
member identity, scope invariant, source-component roles, and direct
projection that feeds the existing resolver. Preserve value-first versus
nominal-second precedence, explicit associated syntax, generic parameter
identity, alias/qualified identity, bare-generic arity failure, and all
AW-AH-009.3 accounting limits. Do not create a Capacity-only call HIR or a
second resolver.

### 6. Define Thread body ownership

Current expression syntax carries a `ThreadBlock` with optional name,
attached/detached modifier, and an ordered `Vec<FlowItem>` body. Do not replace
that body with an unexplained `ExprId`. Define the exact scope, ordered
statement/flow IDs, optional tail/result if any, locals, cancellation/join
semantics, poison behavior, and consumer projection. State whether any block
expression ID is used and prove its kind/invariants if so.

### 7. Make Dialogue and RichText records exhaustive

Define every referenced type, arena ID, enum variant, field, private
constructor, validation error, read-only accessor, source role, recovery
state, and owner crate. Cover current text, raw, escape, ruby, authored and
inferred start/end tags, interpolation, controls, marks, line breaks, errors,
builtin Fx, registered tags, unresolved tags, retained RichText
`DialogueCall`, arguments, authored values, and nested expressions.

State exact stable tag/argument identity and arena locality. Do not leave
`BuiltinRichTextTag`, `BuiltinRichTextFx`, registered IDs, recovery enums, or
argument issue types undefined. Preserve all accepted RichText limits and
cross-layer checked-value ownership without syntax clones or default-on-error.

### 8. Supply the required exhaustive lowering matrix

The primary request requires a variant-by-variant matrix, not a single row
saying that all variants are tested. For every final expression, pattern, and
independent component record, give:

- source-backed or synthetic allocation key;
- exact parent, typed role, and ordinal for every child/component;
- inherited versus created scope and local visibility;
- known-family typed recovery versus generic `Error` recovery;
- omitted optional tail, missing required tail, and missing operand behavior;
- clean, poisoned, stale, foreign, synthetic, and rolled-back query results;
- limits charged at syntax, HIR, checker, resolver, RichText, and decoder
  boundaries; and
- exact/one-over rollback assertions with no leaked ID, source, scope,
  diagnostic, candidate, or retained-result slot.

Do not alter AW-AH-009.4.2 candidate roles or ordinals while filling this
matrix.

### 9. Reconcile current main and all consumers

Inspect the latest `main`, not only the older package baseline. Reconcile the
local member-arena, `HirIfLetStmt`, and typed `UnsafeAuditInsertion` decisions
as fixed adjacent owners. Account for the deletion of the old flattened HIR
Style reader and raw unsafe-audit range path.

Give one deletion-driven migration through HIR, sema, verifier, runtime-plan,
compiler, LSP, formatter, Agent/debug, persistent cache, and project
publication. The same public compiling switch must delete detached syntax
clones, old lowerers/readers, provisional leaves, raw literal/path readers,
inline old call fields, and obsolete expression variants.

## Test contract

Return exact positive, negative, malformed, recovery, compile-fail, stale,
foreign, poison, rollback, and exact/one-over tests for every row above. Tests
must exercise typed APIs and observable behavior. Do not use source scans,
symbol-spelling gates, file-placement gates, or permanent removed-syntax
diagnostics.

In addition to the primary matrix, include direct tests for:

- accepted ID payload field types and parent-depth boundaries;
- every path root and module-context resolution outcome;
- named/elided type regions versus every registry lifetime scope;
- `u128::MAX`, one-over, arbitrarily long malformed/overflow digits, signed
  minimum via unary minus, and compact-sequence overflow;
- every Duration unit and boundary;
- value and associated-type callees, including `Vec<T>` generic identity;
- thread bodies containing statements, Flow items, nested scopes, and
  attached/detached runtime admission;
- all Dialogue/RichText IDs, source components, inferred/recovered forms, and
  nested same-arena calls; and
- every expression/component source-role and ordinal in the exhaustive
  lowering matrix.

## Constraints

- Do not edit production code or return a patch, branch, PR, or overlay.
- Do not redesign the accepted arena/project/transaction architecture.
- Do not introduce aliases, wrappers, extension traits, compatibility shims,
  dual readers, source-string reparsing, source gates, compatibility codecs,
  CSS, Takumi, or removed-syntax-specific diagnostics.
- Do not preserve a provisional WIP shape merely because it exists.
- Copy the complete primary request verbatim into the archive; a summary is
  not a request copy.
- Either omit the manifest self row or describe its non-verifiable sentinel
  semantics explicitly. Every non-self member must have exact byte length and
  SHA-256.

## Required return

Return exactly one English ZIP with all sidecars inside:

```text
arcweft-proof-concurrency-v6.1.1.4.1-final-hir-semantic-leaf-expression-payload-correction-final-contract.zip
```

Include at least README, full primary request copy, this correction request,
FINAL_STATUS, OPEN_QUESTIONS, exact Rust-facing schemas, predecessor
precedence table, exhaustive lowering/source/scope/recovery matrix,
Dialogue/RichText contract, implementation/deletion order, complete test
matrix, requirements traceability, current repository evidence, and manifest.

Use `READY_FOR_IMPLEMENTATION` only when every result-changing decision above
is closed and `OPEN_QUESTIONS.md` is exactly `none`. Otherwise return the same
named archive with `NOT_READY` and concrete unresolved decisions.
