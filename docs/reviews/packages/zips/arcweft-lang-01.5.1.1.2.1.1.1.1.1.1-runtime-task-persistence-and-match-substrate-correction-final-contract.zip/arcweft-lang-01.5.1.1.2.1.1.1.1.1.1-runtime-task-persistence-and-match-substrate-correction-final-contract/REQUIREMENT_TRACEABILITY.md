# Requirement traceability

| Request requirement | Closed decision | Normative documents | Machine files | Test IDs |
|---|---|---|---|---|
| Mandatory correction 1 — canonical value identity versus constant admission | One sink-parametric exhaustive visitor in arcweft-core admits Plain+ConstantAndSnapshot and Plain+SnapshotOnly; explicit constant fence rejects SnapshotOnly; affine never receives RuntimeValueDigest. | `CANONICAL_VALUE_AND_CONSTANT_ADMISSION.md`, `RUST_SCHEMAS.md`, `FINAL_CONTRACT.md` | `machine/contract.json`, `machine/tests.json` | `VAL-001`, `VAL-002`, `VAL-003`, `VAL-004`, `VAL-005`, `VAL-006`, `VAL-007`, `VAL-008`, `VAL-009` |
| Mandatory correction 2 — one typed execution owner | TaskSpec has one TaskExecution field; RuntimeTaskRequest has AwaitManyAggregate and Timeout; nine-family truth table is exhaustive. | `RUST_SCHEMAS.md`, `EXECUTION_TRUTH_TABLE.md`, `STATE_MACHINES.md` | `machine/producer_execution_truth_table.json`, `machine/contract.json` | `EXE-001`, `EXE-002`, `EXE-003`, `EXE-004`, `EXE-005`, `EXE-006`, `EXE-007`, `EXE-008`, `EXE-009` |
| Mandatory correction 3 — one atomic scheduler/journal/adapter owner | RuntimeTaskScheduler<A> in arcweft-runtime-scheduler is the sole owner; runtime-driver becomes a consumer. | `SCHEDULER_OWNER_AND_API.md`, `STATE_MACHINES.md`, `OWNER_API_MAP.md` | `machine/contract.json`, `machine/owner_api_map.json` | `SCH-001`, `SCH-002`, `SCH-005`, `SCH-006`, `SCH-007`, `SCH-008`, `SCH-009` |
| Mandatory correction 4 — prepare/commit error closure | prepare is fallible; staging is private; commit/rollback return unit; AdapterCommit is deleted for launch and replacement. | `SCHEDULER_OWNER_AND_API.md`, `FAILURE_PRECEDENCE_AND_ATOMICITY.md`, `RUST_SCHEMAS.md` | `machine/contract.json` | `SCH-001`, `SCH-002`, `SCH-003`, `SCH-004`, `SCH-010`, `SCH-011` |
| Mandatory correction 5 — NeedHandle semantic equality and generation use | manual Eq/Hash/Ord uses NeedId only; structural validation and active-generation use checks remain strict; only replacement rebind changes generation. | `RUST_SCHEMAS.md`, `IDENTITY_AND_USE.md`, `STATE_MACHINES.md` | `machine/contract.json` | `HND-001`, `HND-002`, `HND-003`, `HND-004`, `HND-005`, `HND-006` |
| Mandatory correction 6 — complete version-1 persistence schemas | 72 explicit version-1 scheduler/value/task/observer/runtime/replay/replacement rows with strict ordering, bounds, joins and atomic restore. | `PERSISTENCE_AND_REPLAY.md`, `RUST_SCHEMAS.md`, `FAILURE_PRECEDENCE_AND_ATOMICITY.md` | `machine/persistence_schemas.json` | `PER-001`, `PER-002`, `PER-003`, `PER-004`, `PER-005`, `PER-006`, `PER-007`, `PER-008`, `PER-009`, `PER-010`, `AM-005`, `TO-006` |
| Mandatory correction 7 — constructible Match and View semantic substrate | CheckedMatchRef binds current HirSnapshotId+ExprId; declaration-rooted stable coordinates and exhaustive semantic transcripts exclude allocation IDs/spans/spelling. | `MATCH_SEMANTIC_TRANSCRIPTS.md`, `RUST_SCHEMAS.md` | `machine/expression_transcripts.json`, `machine/pattern_transcripts.json` | `MAT-001`, `MAT-002`, `MAT-003`, `MAT-004`, `MAT-005`, `MAT-006`, `MAT-007`, `MAT-008`, `MAT-009`, `MAT-010`, `MAT-011`, `MAT-012`, `MAT-013` |
| Mandatory correction 8 — compiler-local versus persistent bundle rows | CompilerLocalViewMatchCatalogRow retains CheckedMatchRef; AcceptedViewMatchBundleRowV1 contains only digest/identity projections. | `VIEW_BUNDLE_PROJECTION.md`, `RUST_SCHEMAS.md`, `COMPILE_CLEAN_SEQUENCE.md` | `machine/contract.json`, `machine/compile_cuts.json` | `BND-001`, `BND-002`, `BND-003`, `CUT-001` |
| Mandatory correction 9 — carrier-backed ownership matrix | All 85 TypeKind variants are exhaustive; Predicate is a leaf; Shared rejects; every successful SnapshotClone names four concrete owners. | `OWNERSHIP_MATRIX.md`, `OWNER_API_MAP.md` | `machine/ownership_matrix.json` | `OWN-001`, `OWN-002`, `OWN-003`, `OWN-004` |
| Mandatory correction 10 — compile-clean deletion sequence | Five protected cuts use only same/earlier types; Cut 3 has no Cut 4 dependency; public RuntimeValue change occurs only in atomic Cut 5. | `COMPILE_CLEAN_SEQUENCE.md`, `DELETION_MATRIX.md`, `DEPENDENCY_GRAPH.md` | `machine/compile_cuts.json`, `machine/deletion_matrix.json` | `CUT-001`, `CUT-002`, `CUT-003`, `CUT-004` |

## Required returned-package categories

| Category from request | Package artifact |
|---|---|
| final contract and decision register | `FINAL_CONTRACT.md`, `DECISION_REGISTER.md` |
| exact Rust-shaped schemas | `RUST_SCHEMAS.md` |
| canonical identity and semantic transcripts | `CANONICAL_VALUE_AND_CONSTANT_ADMISSION.md`, `IDENTITY_AND_USE.md`, `MATCH_SEMANTIC_TRANSCRIPTS.md` |
| nine-family truth table | `EXECUTION_TRUTH_TABLE.md`, JSON/CSV |
| lifecycle/event/timeout/AwaitMany/cancellation/replacement | `STATE_MACHINES.md` |
| complete persistence/replay schemas | `PERSISTENCE_AND_REPLAY.md`, `machine/persistence_schemas.json` |
| exhaustive Match/pattern/value coordinates | `MATCH_SEMANTIC_TRANSCRIPTS.md`, machine transcript JSON |
| carrier-backed ownership matrix | `OWNERSHIP_MATRIX.md`, JSON/CSV |
| dependency and owner/API map | `DEPENDENCY_GRAPH.md`, `OWNER_API_MAP.md` |
| real source evidence/deletion matrix | `SOURCE_EVIDENCE.md`, `DELETION_MATRIX.md`, machine JSON |
| five-cut sequence | `COMPILE_CLEAN_SEQUENCE.md`, machine JSON |
| test matrix | `TEST_MATRIX.md`, `machine/tests.json` |
| machine-readable equivalents validated against prose | `machine/`, `tables/`, `tools/validate_package.py` |
| read-only validator with negative self-tests | `tools/validate_package.py`, `VALIDATION_OUTPUT.txt` |
