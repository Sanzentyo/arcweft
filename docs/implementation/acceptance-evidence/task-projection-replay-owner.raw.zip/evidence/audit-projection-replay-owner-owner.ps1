$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/projection-replay-owner.publication.json"|ConvertFrom-Json
$inputPin=Get-Content -Raw "$root/projection-replay-owner.input.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/projection-replay-owner.owner-validation.json"|ConvertFrom-Json
$previous=Get-Content -Raw "$root/effect-replay.owner-summary.json"|ConvertFrom-Json
$baseline=Get-Content -Raw "$root/effect-replay.owner-terminal.json"|ConvertFrom-Json
if($quality.Source -ne $pub.Parent -or $inputPin.Source -ne $pub.Parent -or $quality.Steps.Count -ne 3){throw 'Owner input differs'}
foreach($step in $quality.Steps){
    $expected=if($step.Name -eq 'owner-run'){100}else{0}
    if($step.ExitCode -ne $expected -or !$step.SourcePinsVerified){throw 'Owner step differs'}
}
$log=[IO.File]::ReadAllText("$root/projection-replay-owner.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1755 tests run: 1749 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Owner terminal summary differs'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1755\) (\S+) (.+)\r?$')|ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/projection-replay-owner.owner-list.json"|ConvertFrom-Json
$ids=@(foreach($suite in $listing.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Name+'$'+$case.Name}}})
if($ids.Count -ne 1755 -or $terminal.Count -ne 1755 -or @($terminal|Group-Object Id|Where-Object Count -GT 1).Count -or @(Compare-Object -CaseSensitive @($ids|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selected and terminal identities differ'}
$delta=@(Compare-Object -CaseSensitive @($baseline.Id|Sort-Object) @($ids|Sort-Object))
if($delta.Count -ne 4 -or @($delta|Where-Object SideIndicator -CNE '=>').Count){throw 'Baseline test identities changed'}
$new=@($terminal|Where-Object {$delta.InputObject -ccontains $_.Id})
if($new.Count -ne 4 -or @($new|Where-Object Result -CNE 'PASS').Count){throw 'New conditional cases failed'}
$failed=@($terminal|Where-Object Result -CEQ 'FAIL'|ForEach-Object Name|Sort-Object)
if(@(Compare-Object -CaseSensitive $previous.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failure identity/diagnostics changed'}
$measurements=@(foreach($p in $pub.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($pub.Source):$($p.Path)") -ne $p.Blob){throw 'Tested source identity changed'}
    $before=@(git show "$($pub.Parent):$($p.Path)" 2>$null); if($LASTEXITCODE){$before=@()}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    [pscustomobject]@{Path=$p.Path;Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$before.Count;Growth=$lines-$before.Count;Class=if($p.Path -like '*/tests.rs' -or $p.Path -like '*/tests/*'){'test'}else{'production'};EmbeddedUnitTestLOC=$(if($p.Path -notlike '*/tests.rs' -and $p.Path -notlike '*/tests/*'){ $text=[IO.File]::ReadAllText($p.Path); $m=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod tests \{'); if($m.Success){$lines-($text.Substring(0,$m.Index).Split([char]10).Length-1)}else{0}}else{0});Owner='arcweft-lang-sema';SHA256=$p.SHA256;Blob=$p.Blob}
})
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse 'HEAD^{tree}') -ne $pub.Tree -or @(git diff --name-only HEAD).Count){throw 'Final source identity differs'}
$metadata=Get-Content -Raw "$root/projection-replay-owner.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$fanOut=@(($metadata.resolve.nodes|Where-Object id -CEQ $owner.id).deps).Count
$fanIn=@($metadata.resolve.nodes|Where-Object {$_.deps.pkg -ccontains $owner.id}).Count
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/projection-replay-owner.owner-terminal.json"
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;OwnerInputParent=$pub.Parent;TestedDirtyBytesEqualCommittedBlobs=$true;Selected=1755;Passed=1749;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;IdsEqual=$true;Duplicates=0;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;Baseline=$previous.Source;FmtExit=0;Measurements=$measurements;PhysicalGrowth=($measurements|Measure-Object Growth -Sum).Sum;FanIn=$fanIn;FanOut=$fanOut;OwnershipDisposition='Live semantic fact and prepared call-graph owners now authorize replay. Context-free Eq implementations on affine projections and sealed branches are removed. The lower engine compares completed components, then delegates opaque branch equivalence to the finished callback client. Exact frontier coalescing retains physical attempt/query equality; semantic replay continues to ignore operational nonce differences. Source-free specialization uses the actual empty-branch law, with no placeholder body/type/row. Cancellation and distinct-owner decisions are not converted to equality. Existing protocol tests now assert callback close before one owner comparison; four new tests cover foreign/expired/poisoned/consumed owners, affine payload reuse and lower equality/distinction/abort. The generic lower fixture has PartialEq but no Eq, and the actual analyzer branch has neither. Responsibilities remain in the existing fact state, call graph and client/lower protocol; no extra authority, public export, dependency, I/O or persisted contract is added. Large touched modules retain their established cohesive ownership; exact physical and embedded test sizes are reported below. Prepared effect graph ownership, full prepared type ports, eager body replacement and six recursive-body failures remain unfinished.'}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/projection-replay-owner.owner-summary.json"
Get-Content "$root/projection-replay-owner.owner-summary.json" -TotalCount 18

$ownerSummaryPath=Join-Path $PSScriptRoot 'projection-replay-owner.owner-summary.json'
$ownerSummary=Get-Content -Raw $ownerSummaryPath|ConvertFrom-Json
$owners=@(
 [pscustomobject]@{Path='crates/arcweft-lang-sema/src/callable/constraints.rs';Disposition='The callback/driver protocol owns close ordering and delegation of opaque branch equality. Its embedded tests exercise that same protocol; no analyzer state or semantic branch interpreter moves into the driver.'},
 [pscustomobject]@{Path='crates/arcweft-lang-sema/src/callable/continuation.rs';Disposition='The prepared graph owns issuer admission, continuation topology and delta replay. The detached comparison becomes private; the live graph is its only production entry. No second node registry or copied graph is introduced.'},
 [pscustomobject]@{Path='crates/arcweft-lang-sema/src/final_analysis/analyzer/calls.rs';Disposition='Candidate/recipe orchestration consumes the real fact owner for replay. Exact and semantic observations share one recipe comparison and differ only in retained operational evidence. This cut adds no independent state owner or source traversal.'},
 [pscustomobject]@{Path='crates/arcweft-lang-sema/src/final_analysis/analyzer/calls/constraints.rs';Disposition='The analyzer callback adapter retains actual analyzer ownership through callback close and branch comparison. Lower sees an opaque value and explicit equality operation, while source semantics remain in this existing client boundary.'},
 [pscustomobject]@{Path='crates/arcweft-lang-sema/src/final_analysis/analyzer/state.rs';Disposition='The sole semantic fact ledger already owns issuer, epoch, poison, graph and affine fact transfer. Contextual projection replay now lives on this owner; the removed context-free Eq is not retained as a parallel success path. Its embedded tests cover the same lifecycle.'},
 [pscustomobject]@{Path='crates/arcweft-lang-sema/src/types/constraints/transaction.rs';Disposition='Lower continues to own its frontier, materialization and completed component equality. It delegates the opaque sealed-value comparison rather than acquiring analyzer/fact dependencies. The cohesive completion protocol stays here without public visibility widening or a second reader.'}
)
$ownerSummary|Add-Member -Force -NotePropertyName OwnershipOwners -NotePropertyValue $owners
$ownerSummary|ConvertTo-Json -Depth 10|Set-Content -Encoding utf8 $ownerSummaryPath
