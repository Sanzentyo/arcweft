$ErrorActionPreference='Stop'
$taskScratch=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$taskScratch/projection-replay-owner.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$taskScratch/projection-replay-owner.owner-summary.json"|ConvertFrom-Json
$consumer=Get-Content -Raw "$taskScratch/projection-replay-owner.consumer-summary.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$taskScratch/projection-replay-owner.broad-quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$taskScratch/projection-replay-owner.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$taskScratch/projection-replay-owner.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD).Trim() -cne $pub.Source -or (git rev-parse origin/main).Trim() -cne $pub.Source -or !$pub.Pushed){throw 'Source is not published'}
if($consumer.Source -cne $pub.Source -or $consumer.Targets -ne 107 -or $consumer.Passed -ne 2507 -or $consumer.Failed -ne 2 -or $owner.Passed -ne 1749 -or $owner.Failed -ne 6 -or $quality.Steps.Count -ne 3 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.Blocking -ne 0){throw 'Validation is incomplete'}
$currentPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$current=[IO.File]::ReadAllText($currentPath)
$history=[IO.File]::ReadAllBytes($historyPath)
$historyHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history))
$genericMatch=[regex]::Match($current,'(?m)^\| Generic Match[^\r\n]*')
if(!$genericMatch.Success){throw 'Generic Match acceptance row is absent'}
$oldArchives=@(git ls-files -s -- 'docs/implementation/acceptance-evidence/*.zip')
[ordered]@{Version=1;InspectedHead=$pub.Source;TrackedDirty=@(git diff --name-only HEAD).Count;HistoryBytes=$history.Length;HistorySHA256=$historyHash;GenericMatch=$genericMatch.Value;PriorArchiveIndex=$oldArchives}|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$taskScratch/projection-replay-owner.docs-before.json"
$sha=$pub.Source
$rows=@(
"| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。実ownerによる候補replayを接続・検証・公開。本体内推論は継続** | 最新Source ``$sha``。Free許可・reify・実フレーム移送、Native／AWBCとprepared relation比較の既受入を維持する。候補projectionとsealed branchの文脈なしEqを削除し、実SemanticFactStateの世代・健全性と実call graph ownerを通して比較する。lowerの重複統合は完成componentとownerのExact比較を使い、物理attempt・query traceも保持する。semantic replayは従来どおり物理nonceを意味にしない。callbackを閉じた後に比較する順序を検証した。prepared effect graph自体のfrontend owner化、一般量化消去・MGU／rank・Fn局所∀、prepared型を含む全portのΓ統合、body一回準備・一括sealとeager経路の置換は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[prepared relation比較](convergence-evidence-history.md#prepared-effect-candidate-replay)・[実owner接続](convergence-evidence-history.md#live-owner-candidate-replay-and-sealed-branch-equivalence)。 |",
"| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,749 PASS／6 FAIL。後続21 packageも今回再実行** | Source ``$sha`` のlocked・全feature Sema lib／tests 1,755件を$($owner.ExecutionSeconds)秒で実行。直前1,751 ID保持・新4件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。実frontendの候補比較とlower callback契約を変更したため、fresh metadata／全target reverse treeの22 packageから後続21 package／107 targetを新たに実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19とcompile-only 3 targetも照合した。以前の実測の再利用で今回のconsumer実行を代用していない。[owner・全consumer・全SHA原本](acceptance-evidence/task-projection-replay-owner.raw.zip)。 |",
"| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source ``$sha``、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件を今回実行し、226 PASS。binはcompile済み・runnable test 0件。21 packageの全consumer照合に含め、選択・終端ID一致・重複0を確認した。以前の入力・件数・失敗・公開SHAは履歴と原本へ保持する。[今回のCLI原本](acceptance-evidence/task-projection-replay-owner.raw.zip)。 |",
"| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace品質・doctest・fmt・構造gateを再実行し終了0** | Source ``$sha`` のlocked workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateを今回実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking 0。15 Rust path・$($owner.PhysicalGrowth)物理LOC増。fact／graph ownerの比較、callbackの完了、lowerの不透明値比較をそれぞれ既存の所有型へ置き、別authority・public export・Cargo依存・codecは追加しない。fan-in／out 12／19は不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。全体clean後に必要なビルドを実施した。今回のTier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・全原本](acceptance-evidence/task-projection-replay-owner.raw.zip)。 |"
)
foreach($row in $rows){
 $label=$row.Split('|')[1].Trim()
 $matches=[regex]::Matches($current,'(?m)^\| '+[regex]::Escape($label)+' \|[^\r\n]*')
 if($matches.Count -ne 1){throw "Current row is not unique: $label"}
 $current=$current.Replace($matches[0].Value,$row)
}
$oldHeader=$current.Split("`n")[2]
$newHeader=$oldHeader.Replace('5941e2eefb6b132741d0489cac602acb205671f8',$sha)
if($newHeader -ceq $oldHeader){throw 'Current header input changed'}
$current=$current.Replace($oldHeader,$newHeader)
[IO.File]::WriteAllText($currentPath,$current,[Text.UTF8Encoding]::new($false))
$append=@"

## Live-owner candidate replay and sealed-branch equivalence

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$sha``、tree ``$($pub.Tree)``。既存mainの15 Rust pathを通常commit／非force pushし、テストしたdirty bytesと公開blobを照合した。owner・workspace品質通過後、consumer実行中のpushはcheckpoint原本にも区別して記録した。既存の未追跡 ``%SystemDrive%/`` を保持した。

- 候補projectionとそれを保持するrecipe／sealed branchの文脈なしPartialEq／Eqを削除した。実SemanticFactStateがissuer・epoch・健全性・live graphを確認し、実call graph ownerが自分のdeltaであることを確認してから比較する。同じ2候補が相互に一致しても、別owner、別graph、失効世代、poison後、graph消費後は証明にしない。比較後も元のaffine payloadをapply／rollbackできる。
- lowerはsealed callback値へEqを要求しない。完成componentの比較後に実clientの比較を呼び、callbackのfinish／scope cleanupを先に完了する。重複統合はExact modeで従来のphysical attempt・query traceまで比較し、通常のsemantic replayでは従来どおり物理nonceを意味へ含めない。比較の不一致を重複へ変えず、取消しを成功へ変えない。source-free specializationだけは、実際にcallbackがない完成pathのdomain empty branchを使う。未準備body・型・効果のplaceholderは発行しない。
- 新4 test IDは、matchingな候補のforeign owner／graph拒否、graph消費後、expired／poisoned世代、payloadの継続使用と、lower比較の同値／別値／取消しの3条件を検証する。既存driverテストもcallback finish 1回の後にowner比較1回となるassertionを追加した。下位fixtureのsealed値はPartialEqだけを持ち、実analyzer branchはPartialEq／Eqの両方を持たずに動作する。物理記録、評価量、既定budget、assertion、選択filterを弱めていない。
- 開発中のEq bound／呼出し側移行のcompile拒否を原本に保持する。最終ownerは1,755件／1,749 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,751 ID保持・新4件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。再帰本体推論6件の修復とはしない。
- 実frontendと共有lower契約の変更なので、fresh full metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、全選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19、CLI規定226 PASS、compile-only 3 targetも照合した。20 package groupとCompiler 31 targetはすべて終端であり、過去のconsumer実測を新Sourceの実行として流用していない。
- workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateは新Sourceで終了0。先行owner Clippyの終了0と警告も保持する。15 path・$($owner.PhysicalGrowth)物理LOC増。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking 0。既存fact state、call graph、clientのlifecycleとlowerのopaque branch境界に責務を置き、依存方向・public export・I/O・codec・version markerは変更しない。大きな既存moduleはこの責務を維持し、物理LOC・byte size・embedded test LOCとfan-in 12／fan-out 19を原本に記録した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- Supersedes: frontendの候補比較が実ownerを通していなかった境界と、最新owner／consumer／品質の一覧を今回の実装・実測へ更新した。prepared effect graph自体のfrontend owner化、prepared型の全producer／consumer、Γ統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は今回の候補比較だけで完了にしない。Generic Match、caller-bound recursion、共有prefix、Free許可／reifyと各既受入を保持する。過去の全SHA・実測・失敗・原本を変更せず、現在の一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-projection-replay-owner.raw.zip](acceptance-evidence/task-projection-replay-owner.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,($append.Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false))
$actual=[IO.File]::ReadAllBytes($historyPath)
$prefix=[byte[]]::new($history.Length)
[Buffer]::BlockCopy($actual,0,$prefix,0,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -cne $historyHash){throw 'Historical prefix changed'}
if([regex]::Match([IO.File]::ReadAllText($currentPath),'(?m)^\| Generic Match[^\r\n]*').Value -cne $genericMatch.Value){throw 'Generic Match acceptance changed'}
if(@(Compare-Object -CaseSensitive $oldArchives @(git ls-files -s -- 'docs/implementation/acceptance-evidence/*.zip')).Count){throw 'Prior archives changed'}
$links=@([regex]::Matches(($rows -join "`n")+"`n"+$append,'\]\(([^)]+)\)')|ForEach-Object {$_.Groups[1].Value}|Sort-Object -Unique)
foreach($link in $links){if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $link.Split('#')[0]))){throw "Changed link is absent: $link"}}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace differs'}
[ordered]@{Version=1;Source=$sha;UpdatedRows=4;HistoryPrefixUnchanged=$true;GenericMatchAcceptanceUnchanged=$true;PriorArchiveIndexUnchanged=$true;ChangedLinksVerified=$links;Paths=@($currentPath,$historyPath,'docs/implementation/acceptance-evidence/task-projection-replay-owner.raw.zip')}|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$taskScratch/projection-replay-owner.docs-validation.json"
Write-Output 'Updated four current rows and appended actual evidence; retained prior acceptance/history/archives'
