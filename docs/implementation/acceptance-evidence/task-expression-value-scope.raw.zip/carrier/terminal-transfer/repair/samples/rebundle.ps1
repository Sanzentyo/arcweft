$ErrorActionPreference='Stop'
$arcEvidence=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
$arcRuns=Join-Path $arcEvidence 'modern-feedback-retained-execution'
$arcOut=Join-Path $arcEvidence 'carrier-terminal-artifact-identity'
New-Item -ItemType Directory -Path $arcOut -Force | Out-Null
$arcBuild=Get-Content (Join-Path $arcEvidence 'carrier-terminal-cli-build.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
function Get-ArcSha($arcPath){(Get-FileHash -Algorithm SHA256 -LiteralPath $arcPath).Hash.ToLowerInvariant()}
$arcCli=(Resolve-Path 'target/debug/arcw.exe').Path
if((Get-ArcSha $arcCli) -ne $arcBuild.binarySha256){throw 'compiled CLI differs'}
foreach($arcRow in $arcBuild.inputs){if((Get-ArcSha $arcRow.path) -ne $arcRow.sha256){throw "CLI inputs drifted at $($arcRow.path)"}}
$arcPlain=Get-Content (Join-Path $arcRuns 'plain-scope-repaired/receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$arcCarriers=Get-Content (Join-Path $arcRuns 'carrier-scope-after.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$arcCases=@([ordered]@{kind='plain';manifest='samples/modern-feedback-view/arcw.toml';prior=$arcPlain.awfbSha256})
$arcCases+=@(foreach($arcRow in $arcCarriers.results){[ordered]@{kind=$arcRow.kind;manifest="target/modern-feedback-carrier-probe-$($arcRow.kind)/arcw.toml";prior=$arcRow.awfbSha256}})
$arcResults=@(foreach($arcRow in $arcCases){
    $arcManifest=(Resolve-Path $arcRow.manifest).Path
    $arcOutput=Join-Path $arcOut "$($arcRow.kind).awfb"
    $arcLog=Join-Path $arcOut "$($arcRow.kind).bundle.log"
    & $arcCli bundle --manifest-path $arcManifest --profile main --output $arcOutput *> $arcLog
    $arcExit=$LASTEXITCODE
    $arcSha=if($arcExit -eq 0){Get-ArcSha $arcOutput}else{$null}
    [ordered]@{kind=$arcRow.kind;bundleExit=$arcExit;manifestSha256=Get-ArcSha $arcManifest;before=$arcRow.prior;after=$arcSha;exact=$arcSha -eq $arcRow.prior;logSha256=Get-ArcSha $arcLog}
})
if((Get-ArcSha $arcCli) -ne $arcBuild.binarySha256){throw 'CLI binary changed during replay'}
[ordered]@{version=1;head=(git rev-parse HEAD);cliSha256=$arcBuild.binarySha256;results=$arcResults}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $arcOut 'receipt.json') -Encoding utf8
$arcResults|ForEach-Object {"$($_.kind) exact=$($_.exact) exit=$($_.bundleExit) sha=$($_.after)"}
if(@($arcResults|Where-Object {!$_.exact}).Count){exit 1}
