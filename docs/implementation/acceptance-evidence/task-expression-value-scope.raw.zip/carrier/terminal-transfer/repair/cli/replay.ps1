$ErrorActionPreference='Stop'
$arcEvidence=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
$arcInputs=Join-Path $arcEvidence 'carrier-return-probe'
$arcOut=Join-Path $arcEvidence 'carrier-terminal-replay'
New-Item -ItemType Directory -Path $arcOut -Force | Out-Null
$arcBuild=Get-Content (Join-Path $arcEvidence 'carrier-terminal-cli-build.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
function Get-ArcSha($arcPath){(Get-FileHash -Algorithm SHA256 -LiteralPath $arcPath).Hash.ToLowerInvariant()}
$arcCli=(Resolve-Path 'target/debug/arcw.exe').Path
if((Get-ArcSha $arcCli) -ne $arcBuild.binarySha256){throw 'compiled CLI differs'}
foreach($arcRow in $arcBuild.inputs){if((Get-ArcSha $arcRow.path) -ne $arcRow.sha256){throw "CLI inputs drifted at $($arcRow.path)"}}
$arcCases=[ordered]@{
 'option-none'=42; 'option-some'=23; 'result-err'=42; 'result-ok'=23;
 'direct-return'=23; 'option-dead-try'=23; 'result-dead-try'=23;
 'option-terminal-tail-none'=42; 'option-terminal-tail-some'=23;
 'result-terminal-tail-err'=42; 'result-terminal-tail-ok'=23;
 'option-typed-terminal-tail'=42; 'result-typed-terminal-tail'=42;
 'option-goto'=42; 'result-break'=42; 'option-dead-strict-operand'=23;
 'option-inner-caught'=23; 'pure-carrier-never'=42; 'pure-carrier-dead-try'=$null;
 'pure-carrier-dead-try-closed-row'=42; 'pure-carrier-dead-try-inferred-alias'=42;
 'pure-carrier-dead-try-nested'=42; 'pure-residual-only'=42; 'pure-residual-only-nested'=42;
 'option-goto-success'=23;
 'let-else-resumable'=$null;
}
$arcResults=@(foreach($arcName in $arcCases.Keys){
    $arcSource=Join-Path $arcInputs "$arcName.arcw"
    $arcLog=Join-Path $arcOut "$arcName.check.log"
    & $arcCli check $arcSource *> $arcLog
    $arcCheck=$LASTEXITCODE
    $arcRun=$null
    $arcExit=$null
    $arcExpected=$arcCases[$arcName]
    if($arcCheck -eq 0 -and $null -ne $arcExpected){
        $arcRunLog=Join-Path $arcOut "$arcName.awbc-product.run.log"
        & $arcCli run $arcSource --entry entry.main --runner headless --executor awbc-product --steps 128 --mode one-op --max-ops 1 *> $arcRunLog
        $arcRun=$LASTEXITCODE
        $arcExit=@(Get-Content -LiteralPath $arcRunLog | Where-Object {$_ -match 'final_status='} | Select-Object -Last 1)
    }
    $arcDiagnostics=@(Get-Content -LiteralPath $arcLog | Where-Object {$_ -match 'error\['})
    $arcPass=if($null -eq $arcExpected){
        $arcRejection=if($arcName -eq 'pure-carrier-dead-try'){'unknown effect row reached executable function projection'}else{'requires a Never-typed failure branch'}
        $arcCheck -eq 1 -and ($arcDiagnostics -join ' ') -match $arcRejection
    }else{$arcCheck -eq 0 -and $arcRun -eq 0 -and ($arcExit -join ' ') -match ('final_status=done Return\("'+$arcExpected+'"\)')}
    [ordered]@{name=$arcName;pass=$arcPass;sourceSha256=Get-ArcSha $arcSource;expected=$arcExpected;check=$arcCheck;run=$arcRun;terminal=$arcExit;diagnostics=$arcDiagnostics}
})
if((Get-ArcSha $arcCli) -ne $arcBuild.binarySha256){throw 'CLI binary changed during replay'}
[ordered]@{version=1;head=(git rev-parse HEAD);cliSha256=$arcBuild.binarySha256;inputs=$arcBuild.inputs;results=$arcResults}|ConvertTo-Json -Depth 9|Set-Content -LiteralPath (Join-Path $arcOut 'receipt.json') -Encoding utf8
$arcResults|ForEach-Object {"$($_.name) pass=$($_.pass) check=$($_.check) run=$($_.run) $($_.diagnostics -join ' ') $($_.terminal -join ' ')"}
if(@($arcResults|Where-Object {!$_.pass}).Count){exit 1}

