$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Receipt([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$source=Read-Receipt 'external-operands-source.verified'
if((git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected source base'}
$terminal=Read-Receipt 'external-operands-reverse2-20261104.runtime.terminal-audit'
$comparison=Read-Receipt 'external-operands-result-comparison'
$coverage=Read-Receipt 'external-operands-boundary-coverage'
if($terminal.selectedPackages -ne 53 -or $comparison.normal.failed -ne 0 -or $comparison.addedFailedIds.Count -ne 0 -or $comparison.removedFailedIds.Count -ne 0){throw 'Unreconciled complete-run failures'}
if($coverage.descriptorCases.Count -ne 25 -or $coverage.directAliasesAndCapture.Count -ne 4){throw 'Missing descriptor execution evidence'}
$freeze=Read-Receipt 'external-operands-reverse2-20261104.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift $($row.path)"}}
$quality=@(foreach($gate in @('check','clippy','structure')){$name="external-operands-quality2-$gate";$result=Read-Receipt $name;if($result.exitCode -ne 0){throw "Required gate failed $name"};[ordered]@{receipt=$name;result=$result}})
$keys=@('RichTextの部分layout指定／source factory',('Generic Match '+[char]96+'.1.2'+[char]96+' C3/C5'),'共有契約／推移的逆依存matrix','CLI全target照合','workspace check／Clippy・fmt・構造gate')
$before=@([IO.File]::ReadAllLines((Join-Path $PWD 'docs/implementation/current-status.md'))|Where-Object {$_.StartsWith('| ') -and ($_ -split '\|')[1].Trim() -in $keys})
if($before.Count -ne 5){throw 'Missing/duplicate canonical status rows'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD 'docs/implementation/convergence-evidence-history.md'))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
[ordered]@{version=1;source=$source.commit;supersededCurrentRows=$before;historyPrefix=$historyPrefix;reason='New direct invocation descriptor and complete Core reverse execution evidence; keep prior accepted features and the remaining first-class factory composition boundary distinct.'}|ConvertTo-Json -Depth 10|Set-Content "$taskTemp/external-operands-status-before.json" -Encoding utf8
foreach($row in (Read-Receipt 'task-documentation-final-untracked-before').files){if(-not(Test-Path -LiteralPath $row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
. "$taskTemp/write-verified-evidence-archive.ps1"
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {($_.Name -like 'external-operands*' -and $_.Name -notlike '*next-actions*' -and $_.Name -notlike '*.other.txt') -or $_.Name -like 'whole-clean-20261104*'})
foreach($name in @('external-operands-quality1.structure-report','external-operands-quality2.structure-report')){$files+=@(Get-ChildItem -LiteralPath "$taskTemp/$name" -File -Recurse)}
foreach($name in @('record-external-operands.ps1','audit-external-operands-tests.ps1','run-presentation-projection-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')){$files+=Get-Item -LiteralPath "$taskTemp/$name"}
$archivePath='docs/implementation/acceptance-evidence/task-rich-text-external-operands.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $archivePath))) $files
$raw.path=$archivePath
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('externalOperands')){throw 'Preserve existing descriptor evidence'}
$record['externalOperands']=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$source.commit;source=$source
 state='Direct external operand-coordinate/linkage and persistence boundary validated. Whole-formal wrapper coordinates are retained; original caller precedence through first-class factory normalization remains outside this acceptance.'
 implementation=@('Core owns source-ordered optional formal coordinates and expanded ABI ranges on the exact checked external target, with canonical coverage and original-argument checks.','Source and AWBC/Serde codecs and executable metadata retain the same descriptor. AWBC admits only layouts matching its signature. All owned contract markers remain 1; Serde requires the operand field and no legacy reader is retained.','Borrowed Source preflight validates complete row ranges before copying declaration strings and counts both owned rows and bounded ranges scratch.','RuntimePlan projects accepted direct operand facts and environment-wrapper formal coordinates; no source labels or type-based formal inference are used.')
 validation=[ordered]@{terminal=$terminal;graph=(Read-Receipt 'external-operands.graph');comparison=$comparison;boundaryCoverage=$coverage;quality=$quality;fmt=(Read-Receipt 'external-operands-final-fmt');newOwnerWarnings=(Read-Receipt 'external-operands-quality2-new-owner-warnings');sourceCaseExecutableDrift=0}
 attempts=@(
  [ordered]@{receipt='external-operands-owner1-20261104.catalog';result=(Read-Receipt 'external-operands-owner1-20261104.catalog');state='rustc import-resolution ICE and missing-rlib catalog failure; no test execution. Cause is not inferred from later failures.'},
  [ordered]@{receipt='whole-clean-20261104';result=(Read-Receipt 'whole-clean-20261104');state='Explicitly requested full cargo clean removed 135688 files/171.5GiB; 4096 source inputs and Git status unchanged.'},
  [ordered]@{receipt='external-operands-owner2-20261104.runtime.terminal-audit';result=(Read-Receipt 'external-operands-owner2-20261104.runtime.terminal-audit');state='Post-clean focused 20/20 pass on earlier input, before final borrowed-preflight and admission-negative refinement.'},
  [ordered]@{receipt='external-operands-reverse1-20261104.catalog';result=(Read-Receipt 'external-operands-reverse1-20261104.catalog');state='Full 53-package catalog failed before execution: Windows os error 1455 prevented mmap of an rlib; following diagnostics included missing rlib/ICE. Not a test-result failure.'}
 )
 environment=[ordered]@{diagnosis=(Read-Receipt 'external-operands-memory-diagnosis');retrySamples=(Read-Receipt 'external-operands-reverse2-memory-samples');action='The unchanged full selection retried with successful artifacts retained. No jobs, profile, runtime budget, capture limit or OS paging settings changed.'}
 ownership='One Core target descriptor owns formal linkage; Source framing and AWBC codecs consume it. Layout validation uses ranges-only bounded scratch; the Source cursor shares one typed row parser with materialization. Compiler execution tests assert declaration identity, exact parameter-to-ABI mapping and rejection through actual AWBC admission. No new crate dependency or unsafe boundary.'
 scope='The final complete Core/RuntimePlan/Compiler reverse closure has 53 packages. Its 25 descriptor/source/admission cases include direct calls, ordinary aliases, captured groups and per-step AWBC restoration; they do not establish original caller precedence for overlapping factory composition. Fresh constructor coverage is 19 cases; the other 5 Presentation/schema cases retain earlier accepted evidence and are not counted as fresh in this selection. Dedicated doctest/wasm and whole-goal/source-factory acceptance are not claimed.'
 correctionReason='Update the sole current list from actual source and complete-run evidence. Keep accepted Generic, sparse layout, property identity and constructor boundaries accepted. ID equality alone does not establish equivalent failure causes.'
 supersededCurrentRows=$before;historyPrefix=$historyPrefix;raw=$raw
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
[ordered]@{version=1;source=$source.commit;raw=$raw.path;entries=$raw.entries.Count;sha256=$raw.sha256}|ConvertTo-Json|Set-Content "$taskTemp/external-operands-evidence-record.json" -Encoding utf8
Write-Output "Recorded descriptor evidence entries=$($raw.entries.Count), hash=$($raw.sha256)"