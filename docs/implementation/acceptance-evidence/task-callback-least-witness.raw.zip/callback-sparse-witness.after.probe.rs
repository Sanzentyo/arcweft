#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;

use std::collections::BTreeSet;
use decision::{DecisionControl, DecisionWork, EffectDecision};

#[derive(Default)]
struct Meter(usize);
impl DecisionControl for Meter {
    type Error = std::convert::Infallible;
    fn charge(&mut self, _: DecisionWork) -> Result<(), Self::Error> {
        self.0 += 1;
        Ok(())
    }
}

fn main() {
    for width in 1..=6 {
        let count = 1u8 << width;
        let mut setup = Meter::default();
        let mut frontier: Vec<_> = (width..width+count)
            .map(|reference| EffectDecision::variable(reference, &mut setup).unwrap())
            .collect();
        for selector in 0..width {
            let bit = EffectDecision::variable(selector, &mut setup).unwrap();
            frontier = frontier.chunks_exact(2)
                .map(|pair| bit.conditional(&pair[1], &pair[0], &mut setup).unwrap())
                .collect();
        }
        let relation = frontier.pop().unwrap();
        let bind: BTreeSet<_> = (width..width+count).collect();
        let mut work = Meter::default();
        let result = relation.complete_conditionally(bind, &mut work).unwrap();
        assert!(result.satisfiable().is_constant(true));
        assert!(result.principal().is_constant(true));
        for mask in 0..count {
            for index in 0..count {
                let value = result.lower_envelope().get(&(width+index)).unwrap();
                assert_eq!(value.evaluate_with_control(|reference| mask & (1 << reference) != 0, &mut setup).unwrap(), index == mask);
            }
        }
        println!("selector widths={width} source={} total_work={}", relation.node_count(), work.0);
    }
    for count in [2, 4, 8, 16, 32, 64] {
        let mut setup = Meter::default();
        let mut relation = EffectDecision::constant(true);
        for reference in 0..count {
            relation = relation.and(&EffectDecision::variable(reference, &mut setup).unwrap(), &mut setup).unwrap();
        }
        let bind: BTreeSet<_> = (0..count).collect();
        let mut work = Meter::default();
        let result = relation.complete_conditionally(bind, &mut work).unwrap();
        assert!(result.principal().is_constant(true));
        for reference in 0..count {
            assert!(result.lower_envelope().get(&reference).unwrap().is_constant(true));
        }
        println!("dense variables={count} source={} total_work={}", relation.node_count(), work.0);
    }
}
