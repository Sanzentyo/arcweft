$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '00ac189fd64f14e453a64bca6bd3cee0ce797104'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'closed-original-owner.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='ConstraintClosedEffects now requires the bound-original phase artifact and actual Future inputs. BoundScopedEffectCompletion can only be issued by consuming the original identity attachment; a raw frozen relation cannot claim final validation authority. Original function inventory membership is checked before transporting actual application queries. Final completion uses the retained original relation and current original read capability, then independently confirms the exact source Gamma/domain/relation receipt against the same canonical tuple and every retained witness. A proved whole universal implication is retained with the original scoped receipt; no guessed pointwise predicate or pure/true fallback is used. OriginalConstraintForest.close stages final closure and the unchanged scope/binding/equation validator before consuming any branches; semantic rejection prunes candidates, operational failure returns the same affine forest with metadata rollback and spent work retained. ClosedOriginalConstraintForest is a separate phase. Source domain formulas are transported from each actual source frame into the calculation scope before conjunction, preventing independent equally shaped bound frames from being conflated. Header projection uses the original prepared graph, actual function dependencies and actual application arguments; it preserves existing source admission, narrowly derived Free support, nested binder transport and consumption of both fields. Canonical equality and SelectedCall validation run only after the common canonical type projection. The obsolete flat effect completion call is deleted. Prepared omitted-annotation detection delegates to the existing exhaustive effect-root grammar. Nine new fixtures remain unrun because library/test targets fail: retained choice witness confirmation, whole implication with unused Gamma, actual function arguments and foreign identity, narrow support and original frames, stale minimum refusal, independent bound premises, unavailable body retry, cancellation retry, and a real admitted header beneath a local binder. The final forest protocol is owned by original/closing, state phases and existing validation remain on original, mathematical replay stays on the effect owner, and header provenance stays on normalization/effects and existing operand owners. No second source traversal, fallback resolver, broad facade, Cargo graph/feature, layer, I/O, unsafe, codec/version, production budget, jobs or profile change. Existing resolved Cargo graph and reverse-dependency evidence is reused. Legacy eager acceptance, transaction/solution callers and older fixtures still require actual phase/graph inputs; no defaults fabricate these. Guarded/non-total headers, frontend public switch and full acceptance remain incomplete. Exact path size/growth/classification and inline test measurements follow; private owner growth received this review without a workspace scanner run.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'closed-original-owner.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'closed-original-owner.'+$iteration+$suffix}})
$names+=@('closed-original-owner.source-publication.json','closed-original-owner.ownership-review.json','closed-original-owner.staged-review.json','closed-original-owner.dev03-diagnostic-review.json')
$names+=@('run-closed-original-owner-check.ps1','archive-closed-original-owner.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-closed-original-owner-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-closed-original-owner-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'closed-original-owner.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
