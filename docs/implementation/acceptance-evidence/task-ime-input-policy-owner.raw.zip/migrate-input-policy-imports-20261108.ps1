$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$paths=@(rg -l '\bViewInputPurpose\b|EnterKeyHint as ViewEnterKeyHint' crates --glob '*.rs')
foreach($path in $paths){
    $text=[IO.File]::ReadAllText($path)
    $pattern='(?m)^(?<indent>[ \t]*)use arcweft_bundle\b[^;]*;'
    $text=[regex]::Replace($text,$pattern,{
        param($match)
        $statement=$match.Value
        $names=[Collections.Generic.List[string]]::new()
        if($statement -match '\bViewInputPurpose\b'){$names.Add('TextInputPurpose')}
        if($statement -match '\bEnterKeyHint\b'){$names.Add('EnterKeyHint')}
        if(!$names.Count){return $statement}
        if($statement.Contains('{')){
            $statement=[regex]::Replace($statement,'\b(?:ViewInputPurpose|EnterKeyHint)(?:\s+as\s+\w+)?\s*,?','')
        }else{$statement=''}
        if($path.Replace('\','/') -eq 'crates/arcweft-player-scene/src/text_controls.rs'){return $statement}
        $statement+"`n"+$match.Groups['indent'].Value+'use arcweft_presentation::text_input::{'+($names -join ', ')+'};'
    })
    $text=$text.Replace('ViewInputPurpose','TextInputPurpose').Replace('ViewEnterKeyHint','EnterKeyHint')
    [IO.File]::WriteAllText($path,$text,[Text.UTF8Encoding]::new($false))
}
