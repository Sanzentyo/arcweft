$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$stem="$r/ime-purpose-enter-key-20261108.quality"
if(Test-Path ($stem+'.source.json')){throw 'Quality epoch exists'}
$paths=@((git ls-files -- '*.rs' '*.toml' '*.lock' '*.json' '*.stderr' '*.arcw' '*.awfagent' 'rust-toolchain*' '.cargo/*')|Where-Object {$_ -notlike 'docs/*'})
$paths=@($paths+@('crates/arcweft-presentation/src/text_input/policy.rs')|Sort-Object -Unique)
$source=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();inputs=@(foreach($p in $paths){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})}
$source|ConvertTo-Json -Depth 8|Set-Content ($stem+'.source.json') -Encoding utf8
function Assert-Inputs {foreach($row in $source.inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
function Invoke-Quality([string]$name,[string[]]$arguments){
    Assert-Inputs
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> ($stem+".$name.log")
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$source.base;command=$arguments;exitCode=$code;sourceInputs=$source.inputs.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content ($stem+".$name.receipt.json") -Encoding utf8
    if($code -ne 0){throw ('Quality failed: '+$name)}
}
Invoke-Quality 'check' @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Quality 'clippy' @('clippy','--locked','--workspace','--all-targets','--all-features')
Invoke-Quality 'structure' @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking','--write',"$r/ime-purpose-enter-key-20261108.structure-report")
$fmt=@(git diff --name-only d5519fb0cd462ccff625a6a9f5e007076ea7fe77 -- '*.rs'|Where-Object {$_ -notlike 'tools/*'})
$fmt+='crates/arcweft-presentation/src/text_input/policy.rs'
Assert-Inputs
& rustfmt --check --edition 2024 --config skip_children=true $fmt *> ($stem+'.fmt.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{base=$source.base;paths=$fmt;exitCode=$code;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.fmt.receipt.json') -Encoding utf8
if($code -ne 0){throw 'Rustfmt failed'}
& "$r/format-ime-generator-body-20261108.ps1" -Check *> ($stem+'.generator-fmt.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{base=$source.base;path='tools/build-web-ime-player-rendered-fixture.rs';exitCode=$code;sourceDrift=0;scope='Rustfmt checks the original script body after its Cargo frontmatter; the authoritative file is not rewritten.'}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.generator-fmt.receipt.json') -Encoding utf8
exit $code
