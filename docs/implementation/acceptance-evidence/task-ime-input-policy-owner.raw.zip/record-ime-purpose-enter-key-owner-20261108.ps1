$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$source=Read-Record 'ime-purpose-enter-key-20261108.source.verified.json'
if((git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected source HEAD'}
$owner=Read-Record 'ime-purpose-enter-key-20261108.owner-r2.runtime.terminal-audit.json'
$generator=Read-Record 'ime-purpose-enter-key-20261108.generator.runtime.terminal-audit.json'
if($owner.passed -ne 341 -or $owner.failed -ne 0 -or $generator.passed -ne 1 -or $generator.failed -ne 0){throw 'Owner result differs'}
$quality=@(foreach($name in @('check','clippy','structure','fmt','generator-fmt')){Read-Record "ime-purpose-enter-key-20261108.quality.$name.receipt.json"})
if(@($quality|Where-Object exitCode -ne 0).Count){throw 'Quality failed'}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'viewImeInputPolicyOwner'){throw 'Owner record exists'}
$raw=@(Get-ChildItem -LiteralPath $r -File -Filter 'ime-purpose-enter-key-20261108*')+@(
    (Get-Item "$r/run-ime-purpose-enter-key-quality-20261108.ps1"),
    (Get-Item "$r/format-ime-generator-body-20261108.ps1"),
    (Get-Item "$r/run-retained-input-frozen-matrix-20261108.ps1"),
    (Get-Item "$r/migrate-input-policy-imports-20261108.ps1"),
    (Get-Item $PSCommandPath))
$archive='docs/implementation/acceptance-evidence/task-ime-input-policy-owner.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($file in ($raw|Sort-Object FullName -Unique)){
        if($file.Extension -notin @('.log','.json','.patch','.txt','.pathspec','.ps1')){throw 'Unexpected raw entry'}
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    foreach($file in Get-ChildItem "$r/ime-purpose-enter-key-20261108.structure-report" -File){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('structure/'+$file.Name),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|dll|rlib|rmeta|pdb|awfb)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$entry=[ordered]@{
    version=1;date='2026-11-08';sourcePublication=$source
    scope='Typed purpose and Enter-key hints from Source closed enums through Bundle and retained View into the existing IME policy types'
    owner=$owner;standaloneGenerator=$generator;uniqueOwnerCases=342
    firstFocusedRun=(Read-Record 'ime-purpose-enter-key-20261108.owner-r1.runtime.terminal-audit.json')
    quality=$quality;graph=(Read-Record 'ime-purpose-enter-key-20261108.graph.json')
    structuralReview=(Read-Record 'ime-purpose-enter-key-20261108.structure-review.json')
    behavior=@('All 11 purpose values and 7 Enter-key values cross real AWFB encode/decode and cold restore in 17 distinct pairs.','Wrong domains, unknown/case-mismatched members, dynamic Strings, integer values, duplicate arguments and Button misuse reject before publication.','Password-purpose on a plain TextField keeps plain privacy; Pin-purpose on SecureField keeps secure privacy. Wrong-privacy submit preserves the complete View snapshot; valid submit atomically publishes input and state.','Existing ID/public API, enum registration, Presentation and all 93 View cases pass. The standalone generator keeps deterministic product bytes and executable callbacks.')
    changes='Remove Bundle-owned duplicate purpose/hint enums and Scene conversion tables. Presentation is the sole vocabulary owner. Register TextInput owner tag 2 inside closed-enum identity version 1; reject unknown owner 3 and out-of-range 256. Required BindTextInput fields evolve in place without legacy readers.'
    formatting='Owner-r2 predates only formatting of the standalone tool body. Final quality and generator use the final body. Retain the initial format-check failure and its correction; do not relabel owner-r2 as rerunning those script bytes.'
    documentCorrection='The IME chapter previously described committed Binding ownership ambiguously. Clarify that TextEditState owns the adapter editing document, while the retained String field is the application authority; preserve the original wording in the source patch/history.'
    archive=$archiveInfo;preservedPriorRecords=@($prior.PSObject.Properties).Count
    integration='Owner and workspace quality passed. The 71-package reverse closure, default CLI, remaining Source sample/policy/Scroll migration and actual Native/Web display remain separate conditions.'
}
$wrapper=(ConvertTo-Json ([ordered]@{viewImeInputPolicyOwner=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd();$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if((ConvertTo-Json $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json $property.Value -Depth 100 -Compress)){throw ('History changed: '+$property.Name)}}
[ordered]@{source=$source.commit;priorRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$archiveInfo}|ConvertTo-Json -Depth 10|Set-Content "$r/ime-input-policy-owner-record-audit.json" -Encoding utf8
Get-Content "$r/ime-input-policy-owner-record-audit.json" -Raw
