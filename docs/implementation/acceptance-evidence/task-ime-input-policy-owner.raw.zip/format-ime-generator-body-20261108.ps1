param([switch]$Check)
$ErrorActionPreference='Stop'
$path='D:/git/arcweft/tools/build-web-ime-player-rendered-fixture.rs'
$source=[IO.File]::ReadAllText($path)
$match=[regex]::Match($source,'(?s)\A(?<prefix>#![^\n]*\r?\n---cargo\r?\n.*?\r?\n---\r?\n)(?<body>.*)\z')
if(!$match.Success){throw 'Rust script frontmatter not found'}
$bodyPath=Join-Path $PSScriptRoot 'ime-generator-format-body.rs'
[IO.File]::WriteAllText($bodyPath,$match.Groups['body'].Value,[Text.UTF8Encoding]::new($false))
$arguments=@('--edition','2024','--config','skip_children=true')
if($Check){$arguments+= '--check'}
& rustfmt @arguments $bodyPath
$code=$LASTEXITCODE
if($code -ne 0){exit $code}
if(!$Check){[IO.File]::WriteAllText($path,$match.Groups['prefix'].Value+[IO.File]::ReadAllText($bodyPath),[Text.UTF8Encoding]::new($false))}
