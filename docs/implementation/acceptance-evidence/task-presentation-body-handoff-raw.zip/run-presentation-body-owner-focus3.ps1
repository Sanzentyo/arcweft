$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$previous=Get-Content -LiteralPath "$taskTemp/presentation-address-only-reverse-20261101.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$additionalPaths=@($previous.paths.path)+@('crates/arcweft-core/src/engine/presentation_tests/replacement.rs')
& "$taskTemp/run-shared-identity-owner.ps1" -Stem 'presentation-body-owner-focus3-20261101' -Selection @('-p','arcweft-core','--lib','--all-features','--locked','-E','test(engine::presentation_tests)') -ExpectedMatches -1 -AdditionalPaths $additionalPaths
exit $LASTEXITCODE
