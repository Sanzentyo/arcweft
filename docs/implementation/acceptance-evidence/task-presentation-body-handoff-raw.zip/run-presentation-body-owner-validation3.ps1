$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$focus=Get-Content -LiteralPath "$taskTemp/presentation-body-owner-library2-20261101.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
& "$taskTemp/run-shared-identity-owner.ps1" -Stem 'presentation-body-owner-library3-20261101' -Selection @('-p','arcweft-core','--lib','--all-features','--locked') -ExpectedMatches -1 -AdditionalPaths @($focus.paths.path)
if($LASTEXITCODE -ne 0){throw 'Core library tests failed'}
$focus=Get-Content -LiteralPath "$taskTemp/presentation-body-owner-library3-20261101.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$stem='presentation-body-owner-quality3-20261101'
function Assert-Inputs {foreach($row in $focus.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift '+$row.path)}}}
function Invoke-Recorded([string]$gate,[object[]]$arguments) {
    Assert-Inputs
    $name="$stem.$gate"
    if(Test-Path -LiteralPath "$taskTemp/$name.json"){throw 'Quality receipt already exists'}
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> "$taskTemp/$name.log"
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=$arguments;exitCode=$code;sourceInputs=$focus.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$name.json" -Encoding utf8
    Write-Output "$gate exit=$code"
    if($code -ne 0){throw ('Quality gate failed '+$gate)}
}
Invoke-Recorded 'check' @('check','-p','arcweft-core','--all-targets','--all-features','--locked')
Invoke-Recorded 'clippy' @('clippy','-p','arcweft-core','--all-targets','--all-features','--locked')
Invoke-Recorded 'default' @('check','-p','arcweft-core','--lib','--locked')
Invoke-Recorded 'wasm' @('check','-p','arcweft-core','--lib','--target','wasm32-unknown-unknown','--locked')
$owned=@('crates/arcweft-core/src/engine/presentation.rs','crates/arcweft-core/src/engine/presentation_tests.rs','crates/arcweft-core/src/engine/presentation_tests/replacement.rs')
& rustfmt --edition 2024 --config skip_children=true --check @owned *> "$taskTemp/$stem.fmt.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;paths=$owned;exitCode=$code;sourceInputs=$focus.paths.Count;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/$stem.fmt.json" -Encoding utf8
if($code -ne 0){throw 'Owned Rust formatting failed'}
Write-Output 'private body-owner validation terminal'
