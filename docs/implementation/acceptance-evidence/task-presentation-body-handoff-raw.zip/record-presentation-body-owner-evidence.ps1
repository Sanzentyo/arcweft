$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Receipt([string]$name) { Get-Content -LiteralPath "$taskTemp/$name" -Raw|ConvertFrom-Json -Depth 100 }
$source=Read-Receipt 'checkpoint-presentation-body-owner.verified.json'
$library=Read-Receipt 'presentation-body-owner-library3-20261101.runtime.terminal-audit.json'
$freeze=Read-Receipt 'presentation-body-owner-library3-20261101.source-freeze.json'
$owner=Read-Receipt 'presentation-body-owner.owner-review.json'
if((git rev-parse HEAD).Trim() -ne $source.commit -or $library.passed -ne 2181 -or $library.failed -ne 0 -or $library.sourceDrift -ne 0 -or $library.catalogCaseDrift -ne 0){throw 'Final source/library evidence differs'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Evidence source drift: '+$row.path)}}
$quality=@(foreach($gate in @('check','clippy','default','wasm','fmt')){
    $receipt=Read-Receipt "presentation-body-owner-quality3-20261101.$gate.json"
    if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw ('Final quality failed: '+$gate)}
    [ordered]@{gate=$gate;receipt=$receipt}
})
$archivePath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-presentation-body-handoff-raw.zip'
$manifestPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-presentation-body-handoff-validation.json'
if((Test-Path -LiteralPath $archivePath) -or (Test-Path -LiteralPath $manifestPath)){throw 'Final evidence already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    $_.Name -like 'presentation-body-owner*' -or $_.Name -like 'checkpoint-presentation-body-owner.*' -or $_.Name -like '*presentation-body-owner*.ps1'
}|Sort-Object FullName -Unique)
$zip=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try {foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)}}finally{$zip.Dispose()}
$result=[ordered]@{
    version=1
    date=[DateTime]::UtcNow.ToString('yyyy-MM-dd')
    source=$source.commit
    workingTree='main; original 14 tracked and 6 actual untracked WIP preserved; source cut published with empty index'
    defect='The private Native register_presentation_body adapter projected a replaced PresentationBody to body.value, discarding the original expected semantic type and function instantiation retained by the ledger.'
    correction='Return the existing complete PresentationBody directly. Replacement moves the old occupant with its original type/invocation while the new body retains the replacing invocation and is retired by its actual function return. No extra authority, wrapper, fallback or wire reader is introduced.'
    publication=$source
    ownerReview=$owner
    finalLibrary=$library
    finalQuality=$quality
    observedBehavior='Two actual admitted function sites have different io.read/io.write effect instantiations. The first registers a Bool body and the nested second replaces the same Background slot with a String body. The returned old body retains its original Bool semantic identity and exact first instantiation, passes original-program typed admission, and the replacing String body is retired with its own instantiation by actual return. Private Native rollback roundtrips before and after return. No fake environment-only function scopes remain in the final fixture.'
    previousAttempts=[ordered]@{
        initialRunner=Read-Receipt 'presentation-body-owner-focus1-20261101.preflight.json'
        rejectedFixture=Read-Receipt 'presentation-body-owner-focus2-20261101.runtime.terminal-audit.json'
        correctedFocused=Read-Receipt 'presentation-body-owner-focus3-20261101.runtime.terminal-audit.json'
        firstLibrary=Read-Receipt 'presentation-body-owner-library1-20261101.runtime.terminal-audit.json'
        secondLibrary=Read-Receipt 'presentation-body-owner-library2-20261101.runtime.terminal-audit.json'
        secondWrapper=Read-Receipt 'presentation-body-owner-library2-20261101.wrapper-preflight.json'
        explanation='The first wrapper failed before Cargo due to nested path-array coercion. The first Rust fixture ran 13 PASS/1 FAIL because it pushed function environments without real matching frames; the unchanged frame/context guard rejected it. Actual function entry/return repaired the fixture (14/14 PASS). Later fixture-only cleanup removed new Clippy warnings. All three library runs passed 2181 cases on their distinct frozen inputs; they are separate runs, not a combined count. After library2, a stale focus3 pointer stopped only the follow-on quality wrapper; quality resumed against the exact audited library2 freeze. Final library3 and all final quality gates use the final 4046 inputs.'
    }
    limits=@(
        'This proves the private Native body return boundary. It does not connect Source staging factories, ViewValue/Handle/Removed construction, commands/methods, the driver, explicit staging scope or public Native saves.'
        'The resolved Cargo graph has 53 Core reverse packages. Current consumers of this pub(crate) helper are twelve Core test calls and no other production caller. Only the affected private Core owner was rerun; workspace-wide and reverse/CLI runs were not rerun for this cut.'
        'Prior shared-surface 9019 PASS, Generic Match 151/151 and CLI 43 failure IDs remain receipts for source 3b1bd1a110c34a04f70ca38a680b000147e9b751; they are not relabeled as new-source executions or reopened because the overall goal remains incomplete.'
        'No public/serialized shape, Cargo dependency, feature, unsafe or I/O changed. Existing owner responsibilities remain; the 221-line regression module is below the structural growth trigger. No executable doc example was added; doctest, Tier 2 and the workspace structural scanner were not rerun.'
        'Core Clippy exits zero with pre-existing warnings. The final changed replacement fixture has no Clippy warning. No assertion, budget, operation count, default filter or test concurrency was weakened.'
    )
    raw=[ordered]@{path='task-presentation-body-handoff-raw.zip';entries=$files.Count;bytes=(Get-Item -LiteralPath $archivePath).Length;sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant()}
}
$result|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $manifestPath -Encoding utf8
[ordered]@{source=$source.commit;libraryPassed=$library.passed;libraryFailed=$library.failed;qualityGates=$quality.Count;sourceInputs=$freeze.paths.Count;sourceDrift=0;rawEntries=$files.Count;rawBytes=$result.raw.bytes;rawSha256=$result.raw.sha256}|ConvertTo-Json -Compress
