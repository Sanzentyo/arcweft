$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$runDir=$PSScriptRoot
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$record=Get-Content -LiteralPath $registry -Raw|ConvertFrom-Json -Depth 100 -DateKind String
if($record.PSObject.Properties.Name -contains 'retainedTextInputOwner'){throw 'Owner evidence exists'}
$prior=@{}
foreach($property in $record.PSObject.Properties){$prior[$property.Name]=ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress}
$owner=Get-Content -LiteralPath "$runDir/retained-text-input-20261108.owner-r6.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 20 -DateKind String
if($owner.actualExitCode -ne 0 -or $owner.executed -ne 78 -or $owner.passed -ne 78 -or $owner.sourceDrift -ne 0){throw 'Owner terminal differs'}
$source=Get-Content -LiteralPath "$runDir/retained-text-input-20261108.source-sealed.verified.json" -Raw|ConvertFrom-Json -Depth 20 -DateKind String
if($source.commit -ne '7af6e561ffa90716501e1ee0f15a397b666bffde'){throw 'Production source differs'}
$raw=@(foreach($pattern in @('retained-text-input-check-r*.log','retained-text-input-owner-r1.log','retained-text-input-20261108.owner-r[2-6].*','retained-text-input-20261108.source-*.verified.json','retained-text-input-20261108.source-*.reviewed.patch')){Get-ChildItem -LiteralPath $runDir -File -Filter $pattern})|Sort-Object FullName -Unique
$archive=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-retained-text-input.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Raw archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open($archive,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $raw){if($file.Extension -notin @('.log','.json','.patch')){throw 'Non-evidence raw entry'};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$PSCommandPath,(Split-Path $PSCommandPath -Leaf),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path='docs/implementation/acceptance-evidence/task-retained-text-input.raw.zip';entries=$raw.Count+1;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$epochs=@(foreach($attempt in 2..6){$stem="retained-text-input-20261108.owner-r$attempt";$catalog=Get-Content -LiteralPath "$runDir/$stem.catalog.json" -Raw|ConvertFrom-Json -Depth 20 -DateKind String; $auditPath="$runDir/$stem.runtime.terminal-audit.json";[ordered]@{epoch=$stem;preparationExit=$catalog.exitCode;terminal=$(if(Test-Path -LiteralPath $auditPath){Get-Content -LiteralPath $auditPath -Raw|ConvertFrom-Json -Depth 20 -DateKind String}else{$null})}})
$entry=[ordered]@{version=1;date='2026-11-08';source=$source.commit;checkpoint='1e2fb3efa929afefbd5acb0ad20c8d21c0a84400';sourcePublication=$source;scope='retained String text-input binding and event-time atomic state publication';authority='Sema checked retained input; ViewRetainedField identity/access; exact mount/path/instruction/session';sourceInputCount=3418;finalOwner=$owner;developmentEpochs=$epochs;directPreliminaryOwner=[ordered]@{command=@('nextest','run','--locked','-p','arcweft-compiler','--test','view_product','--all-features','-E','test(text_input::)');passed=3;skipped=72;inputFreeze='not recorded; development evidence only'};resolvedFailures=@('keyed controls reused one interaction target: owner-r3, 4 pass / 1 fail','readonly state could become a text-input write target: owner-r5, 5 pass / 1 fail');actualProtectedTrackedWip=0;preservedUntrackedCacheFiles=4;historicalHelperLabel='held=14 is copied from an older template, not observed current WIP';integration='workspace gates/reverse consumers and obsolete input factory samples are pending; no Scroll or Native/Web capture acceptance claim';archive=$archiveInfo;preservedPriorRecords=$prior.Count}
$record|Add-Member -NotePropertyName retainedTextInputOwner -NotePropertyValue $entry
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),(ConvertTo-Json -InputObject $record -Depth 100)+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $registry -Raw|ConvertFrom-Json -Depth 100 -DateKind String
foreach($key in $prior.Keys){if((ConvertTo-Json -InputObject $after.$key -Depth 100 -Compress) -cne $prior[$key]){throw "Historical record changed: $key"}}
[ordered]@{source=$source.commit;priorRecords=$prior.Count;records=$after.PSObject.Properties.Count;archive=$archiveInfo}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$runDir/retained-text-input-owner-record-audit.json" -Encoding utf8
Get-Content -LiteralPath "$runDir/retained-text-input-owner-record-audit.json" -Raw