$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$runDir=$PSScriptRoot
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$record=Get-Content -LiteralPath $registry -Raw|ConvertFrom-Json -Depth 100 -DateKind String
$prior=@{}
foreach($property in $record.PSObject.Properties){if($property.Name -ne 'retainedTextInputOwner'){$prior[$property.Name]=ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress}}
$raw=@(foreach($pattern in @('retained-text-input-check-r*.log','retained-text-input-owner-r1.log','retained-text-input-20261108.owner-r*','retained-text-input-20261108.source-*.verified.json','retained-text-input-20261108.source-*.reviewed.patch')){Get-ChildItem -LiteralPath $runDir -File -Filter $pattern})|Sort-Object FullName -Unique
foreach($attempt in 2..6){foreach($suffix in @('source-freeze.json','catalog.json','catalog.log')){if("retained-text-input-20261108.owner-r$attempt.$suffix" -notin $raw.Name){throw 'Missing owner preparation evidence'}}}
foreach($attempt in @(3,5,6)){foreach($suffix in @('binaries-before.json','catalog.inventory.json','runtime.json','runtime.log','runtime.terminal-audit.json')){if("retained-text-input-20261108.owner-r$attempt.$suffix" -notin $raw.Name){throw 'Missing owner runtime evidence'}}}
$archive='D:/git/arcweft/docs/implementation/acceptance-evidence/task-retained-text-input.raw.zip'
if(@(git ls-files -- docs/implementation/acceptance-evidence/task-retained-text-input.raw.zip).Count){throw 'Archive already tracked; preserve it'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stream=[IO.File]::Open($archive,[IO.FileMode]::Create,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($file in $raw){if($file.Extension -notin @('.json','.log','.patch')){throw 'Non-evidence entry'};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    foreach($scriptName in @('record-retained-text-input-owner-20261108.ps1','repair-retained-text-input-raw-20261108.ps1')){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $runDir $scriptName),$scriptName,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose();$stream.Dispose()}
$record.retainedTextInputOwner.archive.entries=$raw.Count+2
$record.retainedTextInputOwner.archive.bytes=(Get-Item -LiteralPath $archive).Length
$record.retainedTextInputOwner.archive.sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()
$record.retainedTextInputOwner.archive|Add-Member -NotePropertyName assemblyCorrection -NotePropertyValue 'Before publication, Windows FileSystem -Filter [2-6] omitted owner epochs; rebuilt with explicit owner-r* inventory and checked every required receipt.' -Force
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),(ConvertTo-Json -InputObject $record -Depth 100)+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $registry -Raw|ConvertFrom-Json -Depth 100 -DateKind String
foreach($key in $prior.Keys){if((ConvertTo-Json -InputObject $after.$key -Depth 100 -Compress) -cne $prior[$key]){throw "History changed: $key"}}
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try{if($zip.Entries.Count -ne $record.retainedTextInputOwner.archive.entries){throw 'Zip count differs'};if(@($zip.Entries|Where-Object {$_.Name -match '\.(exe|dll|rlib|rmeta|pdb)$'}).Count){throw 'Executable artifact in evidence archive'}}finally{$zip.Dispose()}
$proof=[ordered]@{source=$record.retainedTextInputOwner.source;priorRecords=$prior.Count;records=@($after.PSObject.Properties).Count;archive=$record.retainedTextInputOwner.archive}
$proof|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$runDir/retained-text-input-owner-record-audit.json"
$proof|ConvertTo-Json -Depth 8