$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '5ff57816aa85cb5e89fd6e97f844f83c1bd0a4d5'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'reference-nominal-preparation.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='EntityType owns one effect-independent accepts_header rule for kind and payload presence, shared by canonical checking and prepared relations. Directional family expectations accept a specialized payload; reverse acceptance and exact original equality do not erase a required payload. Ref preparation validates any retained payload and can retain its provisional relation without finalizing unrelated Named bodies; nested payload relations still use their real operand ports and existing relation owner. This does not bypass the original forest final check. Canonical nominal_arguments_compatible now compares each argument in both directions, as required by the maintained functions-and-pipeline specification. The inspected prior canonical implementation performed only one direction, unlike prepared nominal planning. This is source evidence for the repair, not a claimed red/green execution. Direct callback effect subtyping remains directional; nominal callback rows, bottom arguments and erased actor identities remain invariant. Six new fixtures cover nominal callback effects, bottom/actor nominal arguments, Ref payload presence in both directions versus original equality, Ref payload mismatch with an unrelated unprepared body, introduced bindable/rigid type relations, and alias mismatch after real binding. Generic relations use the actual application parameter lease and scope; active binding and alias preparation no longer force unrelated body closure. Rigid mismatches are explicitly rejected, and alias resolution re-enters the resolved relation so a generic root cannot hide a structural mismatch. The duplicate unreachable canonical Ref arm introduced during shared-header migration was removed after the first check warning. Tests remain unrun because library/test targets fail. Scalar-only fixture support is renamed to describe its actual structural scope; existing scalar assertions and budgets are unchanged. The shared header rule is a behavior on the owning EntityType, not a parallel table or source reconstruction. Existing canonical nominal owner supplies the complete argument rule; no substitute canonical reader, arbitrary true/pure result, new type grammar, source lineage, broad public facade, dependency/feature, layer, I/O, unsafe, codec/version, production budget, jobs or profile change is introduced. Remaining aligned composite/Fn preparation, local quantification, final callers and full frontend acceptance remain incomplete. Existing accepted nominal runtime/capture cuts and Generic Match acceptance are not reopened by this new source-level compatibility defect. Exact sizes, growth, classifications and embedded test LOC are recorded; the existing Cargo graph/reverse-dependency evidence is reused and no workspace structural scanner is run.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'reference-nominal-preparation.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'reference-nominal-preparation.'+$iteration+$suffix}})
$names+=@('reference-nominal-preparation.source-publication.json','reference-nominal-preparation.ownership-review.json','reference-nominal-preparation.staged-review.json','reference-nominal-preparation.dev02-diagnostic-review.json')
$names+=@('run-reference-nominal-preparation-check.ps1','archive-reference-nominal-preparation.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-reference-nominal-preparation-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-reference-nominal-preparation-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'reference-nominal-preparation.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
