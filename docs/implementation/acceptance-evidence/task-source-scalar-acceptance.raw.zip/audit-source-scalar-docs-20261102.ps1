$ErrorActionPreference='Stop'
$repoDir='D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath $repoDir
$record=Get-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-source-scalar-acceptance.json' -Raw|ConvertFrom-Json -Depth 45
$before=Get-Content -LiteralPath "$taskTemp/source-scalar.docs-before.json" -Raw|ConvertFrom-Json
if((git rev-parse HEAD).Trim() -ne $record.source){throw 'Source changed'}
$history=[IO.File]::ReadAllBytes((Join-Path $repoDir $before.path))
$prefix=[byte[]]::new([int]$before.bytes)
[Buffer]::BlockCopy($history,0,$prefix,0,$prefix.Length)
$prefixHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant()
if($prefixHash -ne $before.sha256){throw 'History prefix changed'}
$status=[IO.File]::ReadAllText((Join-Path $repoDir 'docs/implementation/current-status.md'))
if([regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value -cne $before.genericRow){throw 'Generic acceptance changed'}
$zipPath=Join-Path $repoDir ('docs/implementation/acceptance-evidence/'+$record.raw.path)
if((Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant() -ne $record.raw.sha256){throw 'Archive changed'}
$documents=@('docs/implementation/current-status.md','docs/00-overview/crate-map.md','docs/01-language/literals-and-primitives.md','docs/03-presentation/image-presentation-objects.md','docs/01-language/grammar.md','docs/examples/README.md','docs/implementation/documentation-cleanup.md',$before.path)
$links=0
foreach($path in $documents){
    $body=if($path -eq $before.path){[Text.Encoding]::UTF8.GetString($history,[int]$before.bytes,$history.Length-[int]$before.bytes)}else{[IO.File]::ReadAllText((Join-Path $repoDir $path))}
    $inFence=$false
    foreach($line in ($body -split '\r?\n')){
        if($line -match '^\s*```'){$inFence=-not $inFence;continue}
        if($inFence){continue}
        foreach($match in [regex]::Matches($line,'\[[^\]]*\]\((?<target><[^>]+>|[^\s)]+)\)')){
            $target=$match.Groups['target'].Value.Trim('<','>')
            if($target -match '^(?:[a-z][a-z0-9+.-]*:|#|//)'){continue}
            $plain=[Uri]::UnescapeDataString(($target -split '[#?]')[0])
            if(-not $plain){continue}
            $resolved=[IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetDirectoryName((Join-Path $repoDir $path))) $plain))
            if(-not(Test-Path -LiteralPath $resolved)){throw "Broken link: $path -> $target"}
            $links++
        }
    }
    if($inFence){throw "Unclosed fence: $path"}
}
$old=Get-Content -LiteralPath "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json
foreach($row in $old.files){if(-not(Test-Path -LiteralPath $row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Original untracked WIP changed: $($row.path)"}}
git -c core.whitespace=trailing-space,space-before-tab,cr-at-eol diff --check -- docs
if($LASTEXITCODE){throw 'Documentation whitespace'}
$audit=[ordered]@{version=1;source=$record.source;inspectedHead=(git rev-parse HEAD).Trim();documents=$documents;historyScan='new appended evidence only; old prefix hash checked';localLinks=$links;brokenLinks=0;fencesBalanced=$true;historicalPrefixBytes=$before.bytes;historicalPrefixDrift=0;acceptedGenericMatchRowUnchanged=$true;rawEntryCount=$record.raw.entryCount;rawPayloadEntries=$record.raw.payloadEntries;rawZipSha256=$record.raw.sha256;rawEntryDrift=0;originalUntracked=$old.files.Count;originalUntrackedDrift=0;recordedAt=[DateTime]::UtcNow.ToString('o')}
$audit|ConvertTo-Json -Depth 7|Set-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-source-scalar-acceptance-doc-audit.json' -Encoding utf8
$audit|ConvertTo-Json -Compress
