param(
 [string]$NormalStem='source-scalar-template-reverse55-normal2-20261102',
 [string]$CliStem='source-scalar-template-reverse55-cli1-20261102'
)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
function Read-Json([string]$name){Get-Content -LiteralPath "$e/$name" -Raw | ConvertFrom-Json -Depth 100}
$normal=Read-Json "$NormalStem.runtime.terminal-audit.json"
$cli=Read-Json "$CliStem.runtime.terminal-audit.json"
if($normal.actualExitCode -ne 0 -or $normal.executed -le 0 -or $cli.actualExitCode -notin @(0,100) -or $cli.executed -le 0){throw 'No valid complete reverse runtime evidence'}
$publication=Read-Json 'source-image-handle-bindings.verified.json'
if((& git rev-parse HEAD).Trim() -ne $publication.commit -or $normal.base -ne $publication.commit -or $cli.base -ne $publication.commit){throw 'Source publication mismatch'}
$before=Read-Json 'source-scalar.docs-before.json'
$stem='task-source-scalar-acceptance'
$out="docs/implementation/acceptance-evidence/$stem.json"
$archive="docs/implementation/acceptance-evidence/$stem.raw.zip"
if((Test-Path -LiteralPath $out) -or (Test-Path -LiteralPath $archive)){throw 'Evidence already exists'}
$paths=[string[]]@(rg --files $e -g 'source-scalar*' -g 'scalar-primitives-*' -g 'scalar-quantity-*' -g 'run-scalar-*.ps1' -g 'clean-scalar-*.ps1' -g 'record-source-scalar-*.ps1' -g 'scalar-angle-address*' -g 'run-source-scalar-*.ps1' -g 'source-dialogue-template-order.*' -g 'source-image-handle-bindings.*' -g 'audit-source-scalar*.ps1')
$paths=[string[]]@($paths | Where-Object {$_ -notmatch '\.(?:awfb|exe|rlib|rmeta|zip)$'})
$paths=[string[]]@($paths+@("$e/run-shared-identity-owner.ps1","$e/audit-nextest-final-result.ps1") | Sort-Object -Unique)
[Array]::Sort($paths,[StringComparer]::Ordinal)
$manifest=@(foreach($path in $paths){[ordered]@{path=[IO.Path]::GetRelativePath($e,$path).Replace('\','/');bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path $PWD $archive),[IO.Compression.ZipArchiveMode]::Create)
try {
 for($i=0;$i -lt $paths.Count;$i++){
  $entry=$zip.CreateEntry($manifest[$i].path,[IO.Compression.CompressionLevel]::Optimal)
  $entry.LastWriteTime=[DateTimeOffset]::Parse('2000-01-01T00:00:00Z')
  $inputStream=[IO.File]::OpenRead($paths[$i]);$outputStream=$null
  try{$outputStream=$entry.Open();$inputStream.CopyTo($outputStream)}finally{if($outputStream){$outputStream.Dispose()};$inputStream.Dispose()}
 }
 $entry=$zip.CreateEntry('manifest.json');$entry.LastWriteTime=[DateTimeOffset]::Parse('2000-01-01T00:00:00Z')
 $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
 try{$writer.Write(($manifest|ConvertTo-Json -Depth 8))}finally{$writer.Dispose()}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path $PWD $archive))
try {
 foreach($row in $manifest){$entry=$zip.GetEntry($row.path);if($null -eq $entry -or $entry.Length -ne $row.bytes){throw 'Archive entry missing'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry drift'}}
 $entryCount=$zip.Entries.Count
}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;source=$publication.commit;publication=$publication
 boundary='Registered scalar transport, angle units and checked public-id constants; issued dialogue/formatter template registration; image sample Handle bindings. Driver projection remains a separate unaccepted boundary.'
 sourcePublications=@((Read-Json 'source-scalar-primitives.verified.json'),(Read-Json 'source-scalar-quantity.verified.json'),(Read-Json 'source-scalar-consumers.verified.json'),(Read-Json 'source-scalar-angle-address.verified.json'),(Read-Json 'source-dialogue-template-order.verified.json'),$publication)
 focusedBeforeConsumerFinalization=(Read-Json 'source-scalar-quantity-owner6-20261102.runtime.terminal-audit.json')
 focusedSource='04c5ab0bc363bd1433c98c36143e9d216e18d1d5'
 focusedConditions=@('Image direct unit literals and typed locals, native and decoded AWBC','Exact returned values for seven Length units, Ratio and degree Angle','Negative Length forwarded through a generic function into image and returned unchanged','OneOp max_ops=1 and AWBC public save/owned restore after every step')
 reverseNormal=$normal;reverseCli=$cli;dependencyGraph=(Read-Json 'scalar-angle-address.reverse-graph.json');reverseTree=(Read-Json 'scalar-angle-address.reverse-tree.json');packageCoverage=(Read-Json 'scalar-angle-address.package-coverage.json');documentationCleanup=(Read-Json 'scalar-angle-address.docs-cleanup.json')
 workspaceCheck=(Read-Json 'scalar-angle-address-workspace-check1-20261102.json');workspaceClippy=(Read-Json 'scalar-angle-address-workspace-clippy1-20261102.json');structure=(Read-Json 'scalar-angle-address-structure1-20261102.json');format=(Read-Json 'scalar-angle-address-format1.json')
 qualityInputIdentity=(Read-Json 'scalar-angle-address-quality-input-identity.json');ownerReview=(Read-Json 'scalar-angle-address.owner-review.json')
 structuralMeasurements=[ordered]@{files=3307;rustFiles=3176;physicalRustLoc=1792767;workspacePackages=98;reviewTriggers=385;blocking=0}
 genericMatch=(Read-Json 'scalar-angle-address-generic-coverage.json');view40=(Read-Json 'scalar-angle-address-view40-coverage.json')
 focusedAngleAndReference=(Read-Json 'source-scalar-angle-address-owner1-20261102.runtime.terminal-audit.json');focusedTemplate=(Read-Json 'source-scalar-template-order-owner1-20261102.runtime.terminal-audit.json');imageCliAfterBindings=(Read-Json 'source-scalar-image-sample-owner1-20261102.runtime.terminal-audit.json')
 imageDriverDiagnostic=(Read-Json 'source-scalar-image-observe-prefix-matrix.json');wipIntegration=(Read-Json 'source-scalar-image-sample-held-release.json')
 previousSource='53736b6d64954e0c53603b6d849d9ffdaf46da3f';previousNormal=(Read-Json 'source-scalar-quantity-reverse54-normal2-20261102.runtime.terminal-audit.json');previousCli=(Read-Json 'source-scalar-quantity-reverse54-cli1-20261102.runtime.terminal-audit.json');cliReconciliation=(Read-Json 'scalar-angle-address-cli-failure-reconciliation.json')
 initialCurrentCatalogFailure=(Read-Json 'source-scalar-template-reverse55-normal1-20261102.catalog.json')
 failedCatalogBeforeClean=(Read-Json 'source-scalar-quantity-reverse54-normal1-20261102.catalog.json')
 cleanRecovery=(Read-Json 'scalar-quantity-cargo-clean-20261102.json')
 historyPrefix=[ordered]@{path=$before.path;bytes=$before.bytes;sha256=$before.sha256}
 workingTree='Fixed runtime inputs include the 12 held tracked WIP files; the source commit and complete input hashes are both retained.';heldTracked=12;heldPatchSha256=$publication.heldPatchSha256;heldActualUntracked=6
 limits=@('Focused and reverse runs retain their actual source/feature configurations; counts are not added as independent cases.','The first reverse build failed before runtime because a bundle rlib was unavailable; the full clean and fresh retry are separate evidence.','Source scalar transport and template admission do not by themselves accept image rendering, Root/driver projection, reactive defaults, or Native/Web parity. Native image observation still reports no image at the original 2-step prefix and diagnostic 8/32 steps.', 'Generated bundles and Cargo build artifacts are excluded from the raw archive; none are moved or copied.', 'The current 55-package first catalog also failed before runtime; the identical retry rebuilt successfully without a second clean. The cache fault is not claimed to be fixed by source code.','All existing accepted Generic Match and ViewValue boundaries retain their original acceptance.','The invalid first scratch untracked-inventory attempt is explicitly superseded and is not preservation evidence.')
 raw=[ordered]@{path="$stem.raw.zip";entryCount=$entryCount;payloadEntries=$manifest.Count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();entryDrift=0}
 recordedAt=[DateTime]::UtcNow.ToString('o')
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{source=$record.source;normal=$normal.summary;cli=$cli.summary;rawEntries=$entryCount;rawBytes=$record.raw.bytes;rawSha256=$record.raw.sha256} | ConvertTo-Json -Compress
