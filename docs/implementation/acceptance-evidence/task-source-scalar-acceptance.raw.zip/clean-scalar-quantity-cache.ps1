$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
. "$e/convergence-image-git-bytes.ps1"
$meta=Get-Content -Raw "$e/scalar-quantity.metadata.json" | ConvertFrom-Json -Depth 100
$target=[IO.Path]::GetFullPath($meta.target_directory)
if($target -ne 'D:\git\arcweft\target' -or -not(Test-Path -LiteralPath $target)){throw 'Unexpected Cargo clean target'}
$freeze=Get-Content -Raw "$e/source-scalar-quantity-reverse54-normal1-20261102.source-freeze.json" | ConvertFrom-Json
$head=(& git rev-parse HEAD).Trim()
$status=Read-GitBytes @('status','--porcelain=v1','--untracked-files=all','-z')
$patch=Read-GitBytes @('diff','--binary','--full-index')
function Digest([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
Assert-Inputs
$started=[DateTime]::UtcNow.ToString('o')
& cargo clean --locked *> "$e/scalar-quantity-cargo-clean-20261102.log"
$code=$LASTEXITCODE
Assert-Inputs
if((& git rev-parse HEAD).Trim() -ne $head -or (Digest (Read-GitBytes @('status','--porcelain=v1','--untracked-files=all','-z'))) -ne (Digest $status) -or (Digest (Read-GitBytes @('diff','--binary','--full-index'))) -ne (Digest $patch)){throw 'Git state changed during Cargo clean'}
[ordered]@{version=1;source=$head;reason='Reverse54 catalog build failed: arcweft_bundle rlib missing; Cargo-owned cache rebuild under explicit full-clean instruction';command='cargo clean --locked';target=$target;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;gitStatusDrift=0;gitPatchDrift=0;patchSha256=(Digest $patch);startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');freeBytes=(Get-PSDrive D).Free} | ConvertTo-Json -Depth 8 | Set-Content "$e/scalar-quantity-cargo-clean-20261102.json"
Get-Content "$e/scalar-quantity-cargo-clean-20261102.log"
Get-Content "$e/scalar-quantity-cargo-clean-20261102.json"
exit $code
