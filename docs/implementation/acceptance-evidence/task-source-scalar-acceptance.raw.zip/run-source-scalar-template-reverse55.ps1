$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
while(-not(Test-Path -LiteralPath "$t/scalar-angle-address-structure1-20261102.json")){Start-Sleep -Seconds 5}
$head=(git rev-parse HEAD).Trim()
foreach($stem in @('scalar-angle-address-workspace-check1-20261102','scalar-angle-address-workspace-clippy1-20261102','scalar-angle-address-structure1-20261102')){
 $gate=Get-Content "$t/$stem.json" -Raw|ConvertFrom-Json
 if($gate.exitCode -ne 0 -or $gate.base -ne $head){throw ('Quality gate did not pass for current source: '+$stem)}
}
$paths=@((Get-Content "$t/scalar-angle-address-gates1.source-freeze.json" -Raw|ConvertFrom-Json).paths.path)
$filter='rdeps(=arcweft-primitives) | rdeps(=arcweft-lang-hir)'
& "$t/run-shared-identity-owner.ps1" -Stem 'source-scalar-template-reverse55-normal1-20261102' -Selection @('--workspace','--exclude','arcweft-cli','--lib','--tests','--all-features','--locked','-E',$filter) -ExpectedMatches -1 -AdditionalPaths $paths *> "$t/source-scalar-template-reverse55-normal1-20261102.sequence-output.log"
$normal=$LASTEXITCODE
if($normal -notin @(0,100)){throw 'Normal reverse has no terminal runtime'}
& "$t/run-shared-identity-owner.ps1" -Stem 'source-scalar-template-reverse55-cli1-20261102' -Selection @('-p','arcweft-cli','--lib','--bins','--tests','--all-features','--locked','-E',$filter) -ExpectedMatches -1 -AdditionalPaths $paths *> "$t/source-scalar-template-reverse55-cli1-20261102.sequence-output.log"
$cli=$LASTEXITCODE
if($cli -notin @(0,100)){throw 'CLI reverse has no terminal runtime'}
[ordered]@{version=1;base=$head;normalExitCode=$normal;cliExitCode=$cli;sourceInputs=$paths.Count;recordedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$t/source-scalar-template-reverse55.sequence.json"
exit ([Math]::Max($normal,$cli))