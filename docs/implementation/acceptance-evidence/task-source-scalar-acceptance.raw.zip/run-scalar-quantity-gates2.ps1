$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$freeze=Get-Content -Raw "$e/source-scalar-quantity-owner6-20261102.source-freeze.json" | ConvertFrom-Json
foreach($row in $freeze.paths){$row.bytes=(Get-Item -LiteralPath $row.path).Length;$row.sha256=(Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant()}
$freeze.base=(& git rev-parse HEAD).Trim()
$freeze.recordedAt=[DateTime]::UtcNow.ToString('o')
$freeze | ConvertTo-Json -Depth 15 | Set-Content "$e/scalar-quantity-gates2.source-freeze.json"
function Assert-Inputs {
 foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}
}
function Invoke-Recorded([string]$name,[string[]]$arguments){
 Assert-Inputs
 $started=[DateTime]::UtcNow.ToString('o')
 & cargo @arguments *> "$e/$name.log"
 $code=$LASTEXITCODE
 Assert-Inputs
 [ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 8 | Set-Content "$e/$name.json"
 [ordered]@{command=$name;exitCode=$code} | ConvertTo-Json -Compress
 if($code -ne 0){throw ('Gate failed: '+$name)}
}
Invoke-Recorded 'scalar-quantity-workspace-check2-20261102' @('check','--workspace','--all-targets','--all-features','--locked')
Invoke-Recorded 'scalar-quantity-workspace-clippy2-20261102' @('clippy','--workspace','--all-targets','--all-features','--locked')
Invoke-Recorded 'scalar-quantity-structure2-20261102' @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')
