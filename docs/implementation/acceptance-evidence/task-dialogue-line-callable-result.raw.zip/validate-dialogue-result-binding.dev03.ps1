param([ValidateSet('Focused','Compiler','Owner','Reverse')][string]$Phase)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$base='e08eae8881df4d8635ce7e7e6f4a73c68692a064'
if((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $base){throw 'Validation base differs.'}
$prefix='dialogue-result-binding.dev03'
$paths=@(git diff --name-only $base -- '*.rs')
$blobs=[ordered]@{}
foreach($path in $paths){$blobs[$path]=git hash-object --path=$path -- $path}
$env:CARGO_INCREMENTAL='0'
function Invoke-Validation([string]$Label,[string]$Program,[string[]]$Arguments,[int[]]$Allowed=@(0)){
    $start=Get-Date -Format o
    $log=Join-Path $d "$prefix-$Label.log"
    Write-Output "Starting $Label"
    & $Program @Arguments *> $log
    $code=$LASTEXITCODE
    if((git rev-parse HEAD) -ne $base){throw 'Base changed during validation.'}
    foreach($path in $paths){if((git hash-object --path=$path -- $path) -ne $blobs[$path]){throw "Rust input changed $path."}}
    $summary=@(Select-String -LiteralPath $log -Pattern 'Summary \[','error:','Finished .* profile' | Select-Object -Last 10 -ExpandProperty Line)
    [ordered]@{version=1;base=$base;blobs=$blobs;command=@($Program)+$Arguments;started=$start;finished=(Get-Date -Format o);exit=$code;log_sha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant();summary=$summary} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $d "$prefix-$Label.result.json") -Encoding utf8NoBOM
    $summary | Write-Output
    Write-Output "Finished $Label with $code"
    if($code -notin $Allowed){Get-Content -LiteralPath $log -Tail 55;exit $code}
}
$common=@('--no-fail-fast','--no-tests','fail','--status-level','all','--final-status-level','fail','--color','never')
$filter=@('-E','rdeps(=arcweft-core)')+$common
switch($Phase){
    'Focused' {
        Invoke-Validation 'format' rustfmt (@('--check','--edition','2024','--config','skip_children=true')+$paths)
        Invoke-Validation 'focused' cargo (@('nextest','run','--locked','-p','arcweft-lang-sema','--lib','-E','test(dialogue_line_plan) | test(function_value_origin) | test(annotated_function_binding) | test(dialogue_mark_handler)')+$common)
    }
    'Compiler' {
        Invoke-Validation 'compiler' cargo (@('nextest','run','--locked','-p','arcweft-compiler','--test','evaluated_effects','-E','test(dialogue_selects_and_invokes_the_published_function_in_native_and_decoded_awbc) | test(cancellation_out_selects_the_dialogue_result_in_native_and_decoded_awbc) | test(dialogue_line_output_and_owned_child_resume_once_after_budgeted_activation) | test(decoded_awbc_dialogue_result_wildcard_survives_pending_release)')+$common)
    }
    'Owner' {
        Invoke-Validation 'sema' cargo (@('nextest','run','--locked','-p','arcweft-lang-sema','--lib')+$common) -Allowed @(0,100)
    }
    'Reverse' {
        Invoke-Validation 'dependency-core' cargo @('tree','--locked','--workspace','--invert','arcweft-core','--prefix','none','--edges','normal,dev,build','--no-dedupe')
        Invoke-Validation 'structural' cargo @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')
        Invoke-Validation 'workspace-check' cargo @('check','--locked','--workspace','--all-targets','--all-features')
        Invoke-Validation 'workspace-clippy' cargo @('clippy','--locked','--workspace','--all-targets','--all-features')
        Invoke-Validation 'reverse' cargo (@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli')+$filter) -Allowed @(0,100)
        Invoke-Validation 'cli' cargo (@('nextest','run','--locked','-p','arcweft-cli','--lib','--bins')+$filter)
        Invoke-Validation 'cli-fixtures' cargo (@('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')+$filter)
    }
}
