param([Parameter(Mandatory=$true)][string]$SourceCommit, [Parameter(Mandatory=$true)][string]$SourceTree)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\git\arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
$plan=Get-Content -Raw "$PSScriptRoot/plan.json" | ConvertFrom-Json
$steps=[Collections.Generic.List[object]]::new()
$started=Get-Date -Format o

function Assert-Source {
    if ((git rev-parse HEAD) -ne $SourceCommit -or (git rev-parse 'HEAD^{tree}') -ne $SourceTree -or @(git diff --name-only HEAD).Count -ne 0) {
        throw 'Pinned consumer input changed'
    }
}

function Signature($suite) {
    @($suite.Cases | ForEach-Object { $_.Name+'|'+$_.Ignored+'|'+$_.Filter } | Sort-Object -CaseSensitive)
}

function Save-Receipt {
    [ordered]@{Version=1;Source=$SourceCommit;Tree=$SourceTree;Started=$started;Observed=(Get-Date -Format o);PlannedGroups=$plan.Groups.Count;CompletedGroups=$steps.Count;OriginalTargets=$plan.OriginalTargets;Steps=@($steps.ToArray())} |
        ConvertTo-Json -Depth 12 | Set-Content -Encoding utf8 "$PSScriptRoot/results.json"
}

Assert-Source
Save-Receipt
foreach ($group in $plan.Groups) {
    Assert-Source
    $name=$group.Name
    $selectionPath="$PSScriptRoot/$name.selection.json"
    $selectionErrors="$PSScriptRoot/$name.selection.stderr"
    $runPath="$PSScriptRoot/$name.results.jsonl"
    $runErrors="$PSScriptRoot/$name.run.log"
    $arguments=@($group.Arguments)
    $groupStarted=Get-Date -Format o
    Write-Output "START $name $($group.Package) ($($group.Targets.Count) targets)"
    & cargo nextest list @arguments --message-format json > $selectionPath 2> $selectionErrors
    $selectionExit=$LASTEXITCODE
    $runExit=$null
    $selected=@()
    $signaturesEqual=$false
    $suiteIds=@()
    if ($selectionExit -eq 0) {
        $listing=Get-Content -Raw $selectionPath | ConvertFrom-Json
        $actualSuites=@($listing.'rust-suites'.PSObject.Properties | ForEach-Object {
            $property=$_
            [pscustomobject]@{Id=$property.Name;Kind=$property.Value.kind;Name=$property.Value.'binary-name';Cases=@($property.Value.testcases.PSObject.Properties | ForEach-Object { [pscustomobject]@{Name=$_.Name;Ignored=$_.Value.ignored;Filter=$_.Value.'filter-match'.status} })}
        })
        $suiteIds=@($actualSuites.Id)
        if (@(Compare-Object -CaseSensitive @($group.ExpectedSuites.Id | Sort-Object) @($actualSuites.Id | Sort-Object)).Count -ne 0) {
            throw "Target inventory changed: $($group.Package)"
        }
        foreach ($expected in $group.ExpectedSuites) {
            $actual=@($actualSuites | Where-Object Id -CEQ $expected.Id)
            if ($actual.Count -ne 1 -or $actual[0].Kind -cne $expected.Kind -or $actual[0].Name -cne $expected.Name) {
                throw "Binary identity changed: $($expected.Id)"
            }
            $before=@(Signature $expected)
            $after=@(Signature $actual[0])
            if ($before.Count -ne $after.Count -or ($before.Count -gt 0 -and @(Compare-Object -CaseSensitive $before $after).Count -ne 0)) {
                throw "Listed cases/filter/ignored changed: $($expected.Id)"
            }
        }
        $signaturesEqual=$true
        foreach ($suite in $actualSuites) {
            foreach ($case in $suite.Cases) {
                if ($case.Filter -eq 'matches') {
                    $selected += [pscustomobject]@{Binary=$suite.Id;Name=$case.Name;Ignored=$case.Ignored;Id=($suite.Id+'$'+$case.Name)}
                }
            }
        }
        if (@($selected | Where-Object { !$_.Ignored }).Count -eq 0) { throw "Required group has no runnable cases: $name" }
        & cargo nextest run @arguments --no-tests fail --no-fail-fast --message-format libtest-json-plus > $runPath 2> $runErrors
        $runExit=$LASTEXITCODE
        Get-Content $runErrors -Tail 8
    } else {
        Get-Content $selectionErrors -Tail 12
    }
    Assert-Source
    $steps.Add([pscustomobject]@{Name=$name;Package=$group.Package;Arguments=$arguments;Targets=$group.Targets;Started=$groupStarted;Finished=(Get-Date -Format o);SelectionExit=$selectionExit;RunExit=$runExit;SignaturesEqual=$signaturesEqual;Suites=$suiteIds;Selected=$selected;SelectionSHA256=(Get-FileHash $selectionPath -Algorithm SHA256).Hash;RunSHA256= $(if(Test-Path $runPath){(Get-FileHash $runPath -Algorithm SHA256).Hash}else{$null});LogSHA256= $(if(Test-Path $runErrors){(Get-FileHash $runErrors -Algorithm SHA256).Hash}else{$null})})
    Save-Receipt
}
if (@($steps | Where-Object { $_.SelectionExit -ne 0 -or $_.RunExit -ne 0 }).Count -ne 0) { exit 100 }
exit 0
