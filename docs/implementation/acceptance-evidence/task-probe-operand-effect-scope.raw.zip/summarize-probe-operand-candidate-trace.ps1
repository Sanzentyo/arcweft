$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$sample=Get-Content -LiteralPath (Join-Path $d 'probe-operand-scope.current-second-candidate.json') -Raw | ConvertFrom-Json
$full=Get-Content -LiteralPath (Join-Path $d 'probe-operand-scope.current-candidates.json') -Raw | ConvertFrom-Json
$p=Join-Path $d 'probe-operand-scope.current-second-candidate.lldb.log'
if($sample.sha256 -ne $full.sha256 -or $sample.lldb_exit -ne 0 -or $sample.log_sha256 -ne (Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()){
    throw 'Candidate sample input differs.'
}
$content=Get-Content -LiteralPath $p -Raw
if($content -notmatch 'calls\.rs:2414,.*hit count = 2' -or $content -notmatch 'calls\.rs:2517,.*hit count = 1'){
    throw 'Missing exact second candidate endpoints.'
}
$records=@([regex]::Split($content,'(?m)^\s*\* frame #0:.*?apply_lower_delta at limits\.rs:618\s*$') | Select-Object -Skip 1)
$sites=@(foreach($record in $records){
    foreach($line in ($record -split '\r?\n')){
        if($line -match 'frame #\d+:.*?\x60(.*?) at ([^\\/]+\.rs:\d+)$'){
            $function=$Matches[1]
            $site=$Matches[2]
            if($function -notmatch '::(charge|charge_constraint|visit_node|apply_lower_delta)($|::|<)'){
                $site
                break
            }
        }
    }
})
if($sites.Count -ne $records.Count -or $content -notmatch ('limits\.rs:618,.*hit count = {0}\b' -f $sites.Count)){
    throw 'Stack hits and breakpoint inventory differ.'
}
[ordered]@{
    version=1; candidate=2; test=$sample.test; binary_sha256=$sample.sha256; log_sha256=$sample.log_sha256;
    lower_accounting_checks_passed=$sites.Count;
    type_constraint_context=@($sites | Where-Object {$_ -eq 'context.rs:2364'}).Count;
    fact_checkpoint_opening_charges=@($sites | Where-Object {$_ -in @('continuation.rs:1476','transaction.rs:198','transaction.rs:201')}).Count;
    sites=@($sites | Group-Object | ForEach-Object {[ordered]@{location=$_.Name;hits=$_.Count}} | Sort-Object {$_.location});
} | ConvertTo-Json -Depth 5 | Tee-Object -FilePath (Join-Path $d 'probe-operand-scope.current-second-candidate-accounting.json')
