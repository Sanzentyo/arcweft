$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$out="$e/script-signal-expectation.combined.json"
if(Test-Path -LiteralPath $out){throw 'Preserve combined evidence'}
function Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$owner='script-signal-expectation-owner1-20261103';$rest='script-signal-expectation-reverse1-20261103'
$a=Receipt "$owner.runtime.terminal-audit";$b=Receipt "$rest.runtime.terminal-audit"
if(-not $a.isPassingRun -or $a.executed -ne 6 -or $b.executed -ne 691){throw 'Unexpected complete selection'}
$old=Receipt "$owner.source-freeze";$current=Receipt "$rest.source-freeze";$map=@{}
foreach($r in $old.paths){$map[$r.path]=$r.sha256}
if($map.Count -ne $current.paths.Count){throw 'Source set changed'}
foreach($r in $current.paths){if($map[$r.path] -ne $r.sha256 -or (Get-FileHash -LiteralPath $r.path).Hash.ToLowerInvariant() -ne $r.sha256){throw 'Source drift'}}
$oldPins=Receipt "$owner.binaries-before";$pins=Receipt "$rest.binaries-before";$pinMap=@{}
foreach($r in $oldPins){$pinMap[$r.binary]=$r}
if($oldPins.Count -ne $pins.Count){throw 'Binary set changed'}
foreach($r in $pins){if(-not $pinMap.ContainsKey($r.binary) -or $pinMap[$r.binary].sha256 -ne $r.sha256 -or (Get-FileHash -LiteralPath $r.path).Hash.ToLowerInvariant() -ne $r.sha256){throw 'Executable drift'}}
$coverage=@{};$catalogKeys=@{}
foreach($stem in @($owner,$rest)){
 $inventory=Receipt "$stem.catalog.inventory";$selected=@{}
 foreach($r in $inventory.rows){$key=$r.binary+"`t"+$r.test;if(-not $r.ignored){$catalogKeys[$key]=$r};if($r.status -eq 'matches'){$selected[$key]=$r}}
 $after=$false;$caseCount=0
 foreach($line in [IO.File]::ReadLines("$e/$stem.runtime.log")){
  if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
  if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
   $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test
   if(-not $selected.ContainsKey($key) -or $coverage.ContainsKey($key)){throw 'Unexpected or duplicate final case'}
   $coverage[$key]=[ordered]@{package=$selected[$key].package;binary=$binary;test=$test;status=$status;run=$stem;kind='fresh-disjoint-selection'};$caseCount++
  }
 }
 if($caseCount -ne $selected.Count){throw 'Missing final status rows'}
}
if($coverage.Count -ne 697 -or @(Compare-Object @($catalogKeys.Keys) @($coverage.Keys)).Count){throw 'Incomplete complete reverse closure'}
$cli=@($coverage.Values|Where-Object package -eq 'arcweft-cli');$tool=@($coverage.Values|Where-Object package -eq 'arcweft-test')
$fail=@($cli|Where-Object status -notin @('PASS','SLOW'))
$baseline=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-cli-yield-context.json -Raw|ConvertFrom-Json -Depth 100
$baselineCases=@($baseline.combined.cases|Where-Object package -eq 'arcweft-cli')
$oldKeys=@($baselineCases|ForEach-Object{$_.binary+"`t"+$_.test})
$newKeys=@($cli|ForEach-Object{$_.binary+"`t"+$_.test})
if(@(Compare-Object $oldKeys $newKeys).Count){throw 'CLI selection changed; compare explicitly'}
$oldFailures=@($baselineCases|Where-Object status -notin @('PASS','SLOW')|ForEach-Object{$_.binary+"`t"+$_.test})
$newFailures=@($fail|ForEach-Object{$_.binary+"`t"+$_.test})
$comparison=[ordered]@{baselineSource=$baseline.combined.productionSource;retained=@($newFailures|Where-Object{$_ -in $oldFailures});added=@($newFailures|Where-Object{$_ -notin $oldFailures});resolved=@($oldFailures|Where-Object{$_ -notin $newFailures});selectionDrift=0;scope='Failure IDs only. Actual current stderr remains in the recorded runtime log; equal IDs do not imply equal causes. Three resolved IDs were repaired in the preceding CLI-assertion cut, two in this canonical projection cut.'}
$value=[ordered]@{version=1;base=$current.base;sourceInputs=$current.paths.Count;sourceDrift=0;caseDrift=0;executableDrift=0;executables=$pins;focused=$a;complement=$b;distinctCases=$coverage.Count;newlyExecutedCases=$coverage.Count;duplicateExecutions=0;cli=[ordered]@{executed=$cli.Count;passed=$cli.Count-$fail.Count;failed=$fail.Count;ignored=23;failureSet=$fail};tool=[ordered]@{executed=$tool.Count;passed=@($tool|Where-Object status -in @('PASS','SLOW')).Count;failed=@($tool|Where-Object status -notin @('PASS','SLOW')).Count};comparison=$comparison;cases=@($coverage.Values|Sort-Object package,binary,test);scope='Two disjoint fresh invocations under identical source, features, target, toolchain and executables cover the complete two-package reverse closure. The already passing six cases were not executed again. Current CLI integration failures remain failures; the canonical expectation owner is assessed on actual affected conditions.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{distinct=$coverage.Count;toolPassed=$value.tool.passed;cliExecuted=$cli.Count;cliPassed=$value.cli.passed;cliFailed=$fail.Count;retained=$comparison.retained.Count;added=$comparison.added.Count;resolved=$comparison.resolved.Count;sourceDrift=0;executableDrift=0}|ConvertTo-Json -Compress
