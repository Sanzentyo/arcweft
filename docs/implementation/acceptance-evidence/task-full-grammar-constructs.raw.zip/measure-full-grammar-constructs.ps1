$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. (Join-Path $t 'convergence-image-git-bytes.ps1')
$prefix='checkpoint-full-grammar-constructs-20261106'
$prepared=Get-Content -LiteralPath (Join-Path $t ($prefix+'.prepared.json')) -Raw | ConvertFrom-Json
$metadata=Get-Content -LiteralPath (Join-Path $t 'rag-project-summary.metadata.json') -Raw | ConvertFrom-Json -Depth 100
$workspace=@{};foreach($p in $metadata.packages){if($p.id -in $metadata.workspace_members){$workspace[$p.id]=$p.name}}
$edges=@(foreach($n in $metadata.resolve.nodes){if(-not $workspace.ContainsKey($n.id)){continue};foreach($dep in $n.deps){if($workspace.ContainsKey($dep.pkg)){[pscustomobject]@{from=$workspace[$n.id];to=$workspace[$dep.pkg]}}}})
$files=@(foreach($row in $prepared.paths){
 $path=$row.path
 [byte[]]$old=[byte[]]::new(0)
 if(@(git ls-tree --name-only $prepared.base -- $path).Count){$old=Read-GitBytes @('show',($prepared.base+':'+$path))}
 $oldText=[Text.Encoding]::UTF8.GetString($old)
 $text=[IO.File]::ReadAllText((Join-Path $PWD $path))
 $owner=if($path.StartsWith('crates/')){($path -split '/')[1]}else{'maintained Native capture contract'}
 $class=if($path.EndsWith('.md')){'maintained specification'}elseif($path.Contains('/tests/') -or $path.EndsWith('/tests.rs') -or $path.EndsWith('/crop_tests.rs') -or $path.EndsWith('/full_grammar.rs')){'test'}else{'production'}
 [ordered]@{path=$path;owner=$owner;classification=$class;bytes=(Get-Item -LiteralPath $path).Length;loc=([regex]::Matches($text,"`n")).Count;baseBytes=$old.Length;baseLoc=([regex]::Matches($oldText,"`n")).Count;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();stagedBlob=$row.blob;workspaceFanIn=@($edges | Where-Object to -eq $owner | Select-Object -ExpandProperty from -Unique).Count;workspaceFanOut=@($edges | Where-Object from -eq $owner | Select-Object -ExpandProperty to -Unique).Count}
})
$record=[ordered]@{
 version=1;base=$prepared.base;tree=$prepared.tree;patchSha256=$prepared.patchSha256;files=$files
 graph='full-grammar-constructs.reverse-selection.json; retained all-feature target-all normal/build/dev graph,101pins0;47complete reverse packages'
 ownership='Presentation FxRenderResourceTable owns the closed shader-resource uniform schema and backend-neutral finite output; glow now consumes the same direction parameter as the canonical builtin graph/catalog, with no alias, fallback, contract version change or adapter-specific resolver. Embedded resource tests exercise3phases, normalized offsets and wrong-type/zero/duplicate refusal. This cohesive resource module remains below1200LOC. CLI is the actual retained-frame/capture IO owner. New326LOC integration child groups the full-grammar current-frame metadata and typed catalog assertions; existing Native unit child owns real same-frame raw attachments and sampled pixel checks. No public API, Cargo, dependency, feature, OS or capture budget changes. Large native_samples/shared tests shrink by deleting their replaced helpers, including opaque object-ID parsing and foreign-frame CLI replay; unused raw ID helper removed. Original Scroll9/9 remains unstaged and proven by replay.'
 correctionReason='One observation exposes its active frame, not11simultaneousSource lines. Current authored content uses content transforms, typed fields, literal cue text with leadingLF, two named sparkle runs and canonical Fx specialization IDs. Keep all metadata/hit/depth/proxy/PageLine coverage and move positive Mask/ObjectId reads to local Native owner because MCP mandatory publication withholds them. Capture metadata uses AgentImageObjectRef and report.steps=tick+1. Visual time controls ordinary stage reveal plus Fx; 1s has not revealed the long Source005 effects section, while AdvanceText consumes its page and gives a run-less transition at59. Preserve actual zero-time hidden masks and compare completed visual60s/61s and60.125s/60.375s pixels at entered005/tick55 with original4steps/128ops; no synthetic completed flag, budget increase or step-count assertion of1after55.'
 state='Original12tracked/6untracked WIP participates in tests. Only the owned native_samples hunks are staged; original Scroll WIP replay is proven in full-grammar-constructs.preservation-proof.json. Raw private full snapshots/original-user.patch must not be archived.'
}
$record | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $t 'full-grammar-constructs-owner-measurements.json') -Encoding utf8
$bytes=0;$loc=0;foreach($file in $files){$bytes+=$file.bytes;$loc+=$file.loc}
[ordered]@{base=$record.base;paths=$files.Count;bytes=$bytes;loc=$loc} | ConvertTo-Json

$measurementPath=Join-Path $t 'full-grammar-constructs-owner-measurements.json'
$measurement=Get-Content -LiteralPath $measurementPath -Raw|ConvertFrom-Json -AsHashtable -Depth 30
foreach($file in $measurement.files){
 $text=[IO.File]::ReadAllText((Join-Path $PWD $file.path));$cut=$text.IndexOf('#[cfg(test)]')
 $file.embeddedTestLoc=if($file.classification -eq 'production' -and $cut -ge 0){[regex]::Matches($text.Substring($cut),"`n").Count}else{0}
}
$measurement.state=$measurement.state.Replace('are staged','are published')
$measurement|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $measurementPath -Encoding utf8
