$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$audit=Read-Record 'full-grammar-constructs-reverse47-20261106.consumer-audit'
$tier2=Read-Record 'full-grammar-constructs-tier2-20261106.runtime.terminal-audit'
$wasm=Read-Record 'full-grammar-constructs-wasm1-20261106'
$owner=Read-Record 'full-grammar-constructs-owner6-20261106.runtime.terminal-audit'
$combined=Read-Record 'full-grammar-constructs-owner4-20261106.runtime.terminal-audit'
if($audit.failureComparison.newFailureIds.Count -or $audit.nonCli.failed -or $audit.genericMatch.passed -ne 151 -or $audit.genericMatch.missing -or $audit.genericMatch.failed -or $tier2.passed -ne 7 -or $tier2.failed -or $wasm.exitCode -or $owner.passed -ne 1){throw 'Repair failures or incomplete terminal coverage before acceptance'}
$quality=[ordered]@{}
foreach($name in @('check','clippy','structure')){$q=Read-Record ('full-grammar-constructs-quality1-20261106-'+$name);if($q.exitCode){throw 'Required quality failure'};$quality[$name]=$q}
$quality.format=Read-Record 'full-grammar-constructs-format1-20261106'
if($quality.format.exitCode){throw 'Format failed'}
$source=Read-Record 'checkpoint-full-grammar-constructs-20261106.verified'
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('fullGrammarConstructs')){throw 'Preserve existing evidence'}
$before=$record|ConvertTo-Json -Depth 100 -Compress
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File|Where-Object {
 $_.Name.StartsWith('full-grammar-constructs-') -or $_.Name.StartsWith('checkpoint-full-grammar-constructs-20261106.') -or $_.Name.StartsWith('native-dialogue-progress-probe5.')
}|Where-Object {$_.Name -notlike '*original-held*' -and $_.Name -notlike '*head-after.rs'})
$names=@('full-grammar-constructs.reverse-selection.json','full-grammar-constructs.preservation-proof.json','rag-project-summary.metadata.json','record-full-grammar-constructs.ps1','run-full-grammar-constructs-quality.ps1','run-full-grammar-constructs-matrix.ps1','run-native-coverage-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','audit-full-grammar-constructs-reverse.ps1','measure-full-grammar-constructs.ps1','prepare-full-grammar-constructs-preservation.ps1','checkpoint-full-grammar-constructs-hunks-prepare.ps1','probe-native-dialogue-progress5.ps1')
foreach($name in $names){$files+=Get-Item -LiteralPath (Join-Path $t $name)}
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'full-grammar-constructs-quality1-20261106.structure-report') -File)
if(@($files|Where-Object {$_.Name -like '*original-held*' -or $_.Name -like '*original-user*' -or $_.Name -like '*head-after.rs' -or $_.Extension -in @('.exe','.rlib','.index')}).Count){throw 'Private user source/build artifacts must not be archived'}
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-full-grammar-constructs.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record.fullGrammarConstructs=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source
 ownership=Read-Record 'full-grammar-constructs-owner-measurements';graph=Read-Record 'full-grammar-constructs.reverse-selection';preservation=Read-Record 'full-grammar-constructs.preservation-proof'
 owner=[ordered]@{combinedBeforeFinalSampleRepair=$combined;finalSampleOwner=$owner;scope='Owner4 actual8run7PASS1FAIL includes publicMCP all11actualSourceframes, canonicalFx/transform/proxy/PageLine assertions, priorverticalgeometry, Native12positiveMask/ObjectIdreads plusactualshadercolor/tint and3glowresourcecases. Final sampledNative owner6 is separate1PASS/29.222s, not a fabricated fresh8/8. The complete reverse run replays all final regular cases.'}
 quality=$quality;reverse=$audit;tier2=$tier2;wasm=$wasm
 attempts=[ordered]@{
  firstCatalog=Read-Record 'full-grammar-constructs-owner1-20261106.catalog'
  secondCatalog=Read-Record 'full-grammar-constructs-owner2-20261106.catalog'
  firstRuntime=Read-Record 'full-grammar-constructs-owner3-20261106.runtime.terminal-audit'
  firstRuntimeDiagnostic=Read-Record 'full-grammar-constructs-owner3-failure-projection'
  combined=$combined
  rejectedPageAdvance=Read-Record 'full-grammar-constructs-owner5-20261106.runtime.terminal-audit'
  finalSample=$owner
  correction='Keep E0277 (metadata u32 vsOption test assertion), E0425 (removed shared proxy helper still used by another test), actual5run1PASS4FAIL/95.364s, actual8run7PASS1FAIL/126.174s, actual1FAIL/15.130s and final1PASS/29.222s. First runtime exposed the real shared glow schema mismatch: builtin graph supplies direction but glow accepted/read dir, producing Fx program_validation at63. Fix the shared consumer in place, preserving typedvec2 and3phases, without aliases or backend exceptions. Other fixture repairs use canonical AgentImageObjectRef and report.steps. 1s samples had not revealed longline005effects; real AdvanceText consumes its page and removes runs at59. Final entered55samples retain original4steps/128ops and use0hidden/60visible,60vs61motion,60.125vs60.375wave. No synthetic reveal policy or budget inflation.'
 }
 behavior='One real publicMCP session visits11currentSourceframes separately, without repeatedobserve resets, foreign-frame IDs or aggregated reports. Canonical builtin specialization/catalog identity, typedshaderresource, transforms, proxydeclarations/defaults/overrides/nesting/hits/depth/layers/fields, selectedproxyparents and Page/Line source ranges are retained. Positive rawMask/ObjectId checks read URIs issued by exactly the retained local Native frame, strictcodec/context/parent/objectmetadata/bytecount/alpha/tint; MCP mandatory publication remains unchanged. Shader adds actualbluepixels>32. Typewriterzero mask differs fromcompleted visible mask; shake andbothsparkleapplications change at60s/61s; wave changesat60.125s/60.375s. Geometry andviewportPNG remain their own accepted conditions.'
 correctionReason='Replace impossible11simultaneousactiveframes and foreign-replay rawreads. Current Source explicitlyauthored content target, fields ratherthanparams, cue literalwithleadingLF, two named sparkle runs and no caption/hover scalar parameters; preserve exact currentconditions ratherthanrestoredeletedwiremodels. Deriveparentsfromtypedissuedcontext, never opaque ID spelling. The concrete shaderdirectiondiagnostic is scoped newevidence forglow only; existingGenericMatch151acceptance remains public and is exactly replayed here. All old testresults/fullSHAs remain historical, and current-status is the sole current list.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$cli=@($audit.cli)[0]
$summary=$audit.terminal.summary
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
  "| 共有契約／推移的逆依存matrix | **最新Presentation／CLI実47逆依存は$($audit.terminal.executed)実行／$($audit.terminal.passed) PASS／$($audit.terminal.failed) FAIL** | Source $($source.commit)、$summary。CLI以外$($audit.nonCli.executed)件は全PASS。host buildのみのpackageをruntime実行に数えず、4122入力／case／実行ファイルdrift0。Generic Match受入151 IDも151／151 PASS・欠落0として厳密照合した。以前の全30＋SemaやRenderer実6の実測は履歴へ保持する。[実graph・全実測・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |"
 }elseif($line.StartsWith('| full-grammarの進行後viewport PNG保存 |')){
  $line.Replace('別のrich-text constructs条件は残る。','後続のrich-text constructsは次行で独立して判定する。')
  "| full-grammarのFx／proxy／Page・Line／sampled readback | **当該11場面と共有glowを修復・検証・公開済み** | Source $($source.commit)。実MCPで各現在frameへ進行し、canonical Fx、typed field、親context、hit／depth／Source範囲を検証。glowだけに残った旧dirを現行directionへ統一し、3 phaseと型違い／zero／重複拒否を確認した。同じNative frameのproxy／Page／Line Mask・ObjectId、shader実画素、typewriterとwave／shake／2 sparkleの時刻差も保持。通常revealとFxの両方をsampleする契約に従い、元の4-step／128-opで005／tick55の0・60秒以降を比較する。MCP公開policyは維持する。[旧期待・実不具合・訂正理由・全実測](acceptance-evidence/task-rich-text-property-identity.json)。 |"
 }elseif($line.StartsWith('| CLI全target照合 |')){
  "| CLI全target照合 | **最新の全$($cli.executed)実測は$($cli.passed) PASS／$($cli.failed) FAIL** | Source $($source.commit)の全47逆依存run内で終端照合した。以前の705／696 PASS／9 FAILと後続PNG ownerの実測は履歴に保持する。PNG保存とfull-grammar constructsは今回の全件でもPASS。残る実失敗はScroll1、unsafe1、run-edge1、負例診断1、verifier3の7 owner条件で、完了済み機能へ一般化しない。[全ID・入力・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |"
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
  "| workspace check／Clippy・fmt・構造gate | **Source $($source.commit)の全98 check／Clippy・構造gateは終了0。関連GPU 7 PASS／wasm library check終了0** | 4122入力、all-target／all-feature／locked、変更6 Rustのformat終了0。警告は残る。prepared-text ignored GPU 7件とwasm32 render-web／player-webのlibrary checkを実行し、ブラウザ実行や最終Native-Web画像parityへは拡張しない。以前のdoctestなどは当時のSourceの履歴として保持する。元12 tracked／6 actual untrackedを保全した。[実測・入力・保全証明・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |"
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Current-frame full grammar and canonical glow direction

- Source $($source.commit), parent $($source.parent), tree $($source.tree),7paths/640add996delete, patch$($source.patchSha256). The real Source006frame reported Fx program_validation because the canonical builtin supplied direction but the shared glow consumer accepted/read dir. Unify that existing boundary in place; preserve typedvec2/normalization/3phases and wrong-type/zero/duplicate refusal. The current-frame MCP fixture visits all11actualframes, preserves typedFx/transform/proxy/PageLine/hit/depth/source assertions and derivesparentsfromtheissuedcatalog. Same-frame localNative positive12proxy/PageLineMaskIDreads, shadercolor/bluepixels, prior3clusterrawreads and animations remain; noMCPpolicychange, foreignURIs, syntheticreports or budgetincrease.
- Keep every actualattempt: E0277metadata-u32 assertion andE0425sharedhelper compile errors; owner3 actual5run1PASS4FAIL/95.364s; owner4 actual8run7PASS1FAIL/126.174s; owner5 actual1FAIL/15.130s; owner6 separate1PASS/29.222s. A sample evaluates ordinaryreveal aswellasFx, so1s hasnotrevealed the long005effectssection. AdvanceText consumesits page and gives run-less59; finalfixture retainsentered55and0hidden/60visible,60vs61motionand60.125vs60.375wave. ActualSource005namesarecustom effectandsparkle, transforms targetcontent,Source007literalhasleadingLF and条件と代替の表示; deletedparams/caption/hover models are not restored. This is not a fabricated8/8 rerun.
- Full47reverse actual $summary; CLI$($cli.executed)run/$($cli.passed)PASS/$($cli.failed)FAIL, nonCLI$($audit.nonCli.executed)PASS, newfailureIDs$($audit.failureComparison.newFailureIds.Count), acceptedGenericMatch151/151PASS/missing0/failed0. Source/case/executable/quality input drift0 across4122inputs. Workspace98check/Clippy/structure+fmt6exit0,warnings; prepared_textTier2ignored7PASS; wasm32render-web/player-weblibrarycheck0. No browser/finalimageparity claim. Preserve previous705/696P9F and focusedPNGpass as their original runs rather than recompute historicalcounts.
- Original12tracked/6actualuntracked WIP participates in frozeninputs; clean partial Source replays the original Scroll WIP exactly and leaves other11heldhashes unchanged. Residual$($source.heldPatchSha256); fullprivate user snapshots/replaypatches/indexes are excludedfromraw. Actualprobe5transportprogressreached006but containedthe shaderdiagnostic; keep its receipts/RPCs, includingrun-less005transition59. [All inputs/attempts/Source/preservation/raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md). GenericMatch/style/geometry/viewport acceptance is preserved.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$after.Remove('fullGrammarConstructs')
if(($after|ConvertTo-Json -Depth 100 -Compress) -ne $before){throw 'Prior evidence changed'}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'Prior history prefix changed'}
[ordered]@{source=$source.commit;raw=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $t 'full-grammar-constructs-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'full-grammar-constructs-documentation-audit.json')