$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$epoch='full-grammar-constructs-owner6-20261106'
$owner=Get-Content -LiteralPath (Join-Path $t ($epoch+'.runtime.terminal-audit.json')) -Raw | ConvertFrom-Json
if($owner.executed -ne 1 -or $owner.passed -ne 1 -or $owner.failed){throw 'Finish explicit-sample owner first'}
& (Join-Path $t 'run-action-payload-quality.ps1') -Epoch $epoch -Stem 'full-grammar-constructs-quality1-20261106'
$freeze=Get-Content -LiteralPath (Join-Path $t ($epoch+'.source-freeze.json')) -Raw | ConvertFrom-Json
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$files=@('crates/arcweft-presentation/src/fx/render_resource.rs','crates/arcweft-cli/src/app/agent/native/player_observation/full_grammar.rs','crates/arcweft-cli/tests/check/agent_observe_native.rs','crates/arcweft-cli/tests/check/agent_observe_native/native_full_grammar.rs','crates/arcweft-cli/tests/check/agent_observe_native/shared.rs','crates/arcweft-cli/tests/check/agent_observe_native/native_samples_effects.rs')
& rustfmt --edition 2024 --check @files *> (Join-Path $t 'full-grammar-constructs-format1-20261106.log')
$code=$LASTEXITCODE
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
[ordered]@{version=1;base=$freeze.base;command=@('rustfmt','--edition','2024','--check')+$files;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $t 'full-grammar-constructs-format1-20261106.json') -Encoding utf8
if($code){throw 'Format failed'}