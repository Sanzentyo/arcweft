$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$freeze=Get-Content -LiteralPath (Join-Path $t 'full-grammar-constructs-owner6-20261106.source-freeze.json') -Raw | ConvertFrom-Json
$graph=Get-Content -LiteralPath (Join-Path $t 'full-grammar-constructs.reverse-selection.json') -Raw | ConvertFrom-Json
foreach($row in $graph.cargoInputPins){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Graph pins changed'}}
$selection=@();foreach($package in $graph.selection){$selection+=@('-p',$package)}
$selection+=@('--all-targets','--all-features','--locked')
& (Join-Path $t 'run-native-coverage-owner.ps1') -Stem 'full-grammar-constructs-reverse47-20261106' -Selection $selection -ExpectedMatches -1 -AdditionalPaths $freeze.paths.path
$code=$LASTEXITCODE
if($code -notin @(0,100)){throw 'No valid reverse terminal'}
& (Join-Path $t 'run-native-coverage-owner.ps1') -Stem 'full-grammar-constructs-tier2-20261106' -Selection @('-p','arcweft-render-wgpu','--all-targets','--all-features','--locked','--run-ignored','only','-E','binary(=prepared_text)') -ExpectedMatches 7 -AdditionalPaths $freeze.paths.path
if($LASTEXITCODE){throw 'Prepared-text GPU failed'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$arguments=@('check','-p','arcweft-render-web','-p','arcweft-player-web','--lib','--target','wasm32-unknown-unknown','--all-features','--locked')
$started=[DateTime]::UtcNow.ToString('o')
& cargo @arguments *> (Join-Path $t 'full-grammar-constructs-wasm1-20261106.log')
$code=$LASTEXITCODE
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='wasm library check; no browser runtime or final image parity claim'}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $t 'full-grammar-constructs-wasm1-20261106.json') -Encoding utf8
if($code){throw 'Wasm library check failed'}