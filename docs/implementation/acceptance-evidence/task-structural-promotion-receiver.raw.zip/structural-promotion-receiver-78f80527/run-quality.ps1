$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$d=Join-Path $env:TEMP 'arcweft-promotion-receiver-20261110'
$base='70b5ab712f8326ccf104a88474173d1d496156d7'
$paths=@(git diff --name-only $base -- 'crates/**' 'docs/01-language/proofs-and-unsafe-audits.md' Cargo.toml Cargo.lock)
if($paths.Count -ne 6){throw "Unexpected source paths: $($paths -join ', ')"}
function ArcSha($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
$inputs=@($paths | ForEach-Object {[ordered]@{path=$_;sha256=ArcSha $_}})
function Test-ArcInputs {
    if(Compare-Object $paths @(git diff --name-only $base -- 'crates/**' 'docs/01-language/proofs-and-unsafe-audits.md' Cargo.toml Cargo.lock)){throw 'Source path drift'}
    foreach($row in $inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source byte drift $($row.path)"}}
}
$graphPath=Join-Path $d 'rdeps.log'
$packages=@(Get-Content -LiteralPath $graphPath|ForEach-Object{if($_ -match '^(arcweft-[\w-]+) v'){$Matches[1]}}|Sort-Object -Unique)
$groups=[ordered]@{
    'owners'=@('arcweft-lang-sema')
    'plan-compiler'=@('arcweft-runtime-plan','arcweft-compiler')
    'runtime-host'=@('arcweft-runtime-host')
    'driver-scene'=@('arcweft-runtime-driver','arcweft-player-scene')
    'player-native'=@('arcweft-player-native')
    'player-web'=@('arcweft-player-web')
    'agent-execution'=@('arcweft-agent-repl','arcweft-agent-runner')
    'agent-transport'=@('arcweft-agent-mcp','arcweft-agent-mcp-client','arcweft-adapter-sema')
    'tools-lsp'=@('arcweft-project-loader','arcweft-tooling','arcweft-lsp','arcweft-test')
    'verify'=@('arcweft-verify','arcweft-verify-oxiz','arcweft-verify-z3','arcweft-verify-lsp')
}
$partition=@(foreach($group in $groups.Values){$group})+@('arcweft-cli')
if($partition.Count -ne $packages.Count -or (Compare-Object $partition $packages)){throw 'Run partition does not match resolved Cargo graph'}
$next=@('cargo','nextest','run','--locked','--no-fail-fast','--no-tests','fail')
$stages=[ordered]@{
    'fmt'=@('cargo','fmt','--all','--','--check')
    'workspace-check'=@('cargo','check','--locked','--workspace','--all-targets','--all-features')
    'workspace-clippy'=@('cargo','clippy','--locked','--workspace','--all-targets','--all-features')
    'structure'=@('just','structure-audit-gate')
    'owner-doctests'=@('cargo','test','--locked','--doc','-p','arcweft-lang-sema')
    'cli-build'=@('cargo','build','--locked','-p','arcweft-cli','--bin','arcw')
}
foreach($name in $groups.Keys){$stages[$name]=$next+@('--lib','--tests')+@(foreach($pkg in $groups[$name]){'-p';$pkg})}
$stages['cli-library-binaries']=$next+@('-p','arcweft-cli','--lib','--bins')
$stages['cli-integration']=$next+@('-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')
$path=Join-Path $d 'quality.receipt.json'
$receipt=[ordered]@{
    version=1; base=$base; inputs=$inputs; target='x86_64-pc-windows-msvc'; graphSha256=ArcSha $graphPath
    packages=$packages; active=$null; remaining=$stages.Count; results=@()
}
function Save-ArcReceipt {
    $tmp=Join-Path $d 'quality.receipt.new.json'
    $receipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $tmp -Encoding utf8
    [IO.File]::Move($tmp,$path,$true)
}
Save-ArcReceipt
$failed=0
foreach($name in $stages.Keys){
    Test-ArcInputs
    $command=$stages[$name]
    $log=Join-Path $d "quality-$name.log"
    $receipt.active=$name
    Save-ArcReceipt
    $exe=$command[0]
    $argv=$command[1..($command.Length-1)]
    & $exe @argv *> $log
    $code=$LASTEXITCODE
    Test-ArcInputs
    $summary=@(Select-String -LiteralPath $log -Pattern 'Summary \[|test result:|Finished .+ profile|^ +FAIL \[|Blocking.*:'|ForEach-Object {$_.Line.Trim()}|Select-Object -Last 22)
    $receipt.results+=@([ordered]@{name=$name;command=$command;exitCode=$code;summary=$summary;logSha256=ArcSha $log})
    if($name -eq 'cli-build' -and !$code){$receipt.cliSha256=ArcSha 'target/debug/arcw.exe'}
    $receipt.active=$null
    $receipt.remaining--
    Save-ArcReceipt
    "$name exit $code"
    $summary
    if($code){$failed++}
}
if($failed){exit 1}

