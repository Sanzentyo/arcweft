
$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$d=Join-Path $env:TEMP 'arcweft-promotion-receiver-20261110'
$receiptPath=Join-Path $d 'quality.receipt.json'
$retryPath=Join-Path $d 'quality.retry.receipt.json'
$deadline=[DateTime]::UtcNow.AddMinutes(35)
function ArcSha($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
do {
    if([DateTime]::UtcNow -gt $deadline){throw 'Main quality run never reached a terminal receipt'}
    $q=Get-Content -LiteralPath $receiptPath -Raw|ConvertFrom-Json -AsHashtable
    if(!$q.active -and !$q.remaining){break}
    Start-Sleep -Seconds 10
} while($true)
function Test-ArcRetryInputs {
    $actual=@(git diff --name-only $q.base -- 'crates/**' 'docs/01-language/proofs-and-unsafe-audits.md' Cargo.toml Cargo.lock)
    if(Compare-Object @($q.inputs.path) $actual){throw 'Retry source paths drifted'}
    foreach($row in $q.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Retry source bytes drifted $($row.path)"}}
}
$retry=[ordered]@{version=1;base=$q.base;originalSha256=ArcSha $receiptPath;inputs=$q.inputs;active=$null;attempts=@()}
function Save-ArcRetry {
    $tmp=$retryPath+'.new'
    $retry|ConvertTo-Json -Depth 14|Set-Content -LiteralPath $tmp -Encoding utf8
    [IO.File]::Move($tmp,$retryPath,$true)
}
Save-ArcRetry
foreach($stage in $q.results){
    if(!$stage.exitCode){continue}
    $originalLog=Join-Path $d "quality-$($stage.name).log"
    if((ArcSha $originalLog) -ne $stage.logSha256){throw "Original log changed $($stage.name)"}
    if($stage.command[1] -ne 'nextest' -or $stage.summary.Count -or !(Select-String -LiteralPath $originalLog -Pattern 'internal compiler error|rlib format, but was not found in this form' -Quiet)){continue}
    Test-ArcRetryInputs
    $name=$stage.name
    $command=@($stage.command)
    $retry.active=$name
    Save-ArcRetry
    $logName="quality-$name-retry.log"
    $log=Join-Path $d $logName
    $exe=$command[0]
    $argv=$command[1..($command.Length-1)]
    & $exe @argv *> $log
    $code=$LASTEXITCODE
    Test-ArcRetryInputs
    $summary=@(Select-String -LiteralPath $log -Pattern 'Summary \[|test result:|Finished .+ profile|^ +FAIL \[|Blocking.*:'|ForEach-Object {$_.Line.Trim()}|Select-Object -Last 22)
    $retry.attempts+=@([ordered]@{name=$name;command=$command;exitCode=$code;summary=$summary;logName=$logName;logSha256=ArcSha $log;originalExitCode=$stage.exitCode;originalLogSha256=$stage.logSha256})
    $retry.active=$null
    Save-ArcRetry
    "Retry $name exit $code"
    $summary
}
if(@($retry.attempts|Where-Object exitCode).Count){exit 1}

