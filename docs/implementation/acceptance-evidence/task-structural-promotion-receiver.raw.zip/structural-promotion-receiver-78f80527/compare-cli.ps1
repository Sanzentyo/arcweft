
$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-receiver-20261110'
$cases=Join-Path $env:TEMP 'arcweft-registry-await-20261110/promotion-probes'
function ArcSha($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
$qa=Get-Content -LiteralPath (Join-Path $d 'quality.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$before=Get-Content -LiteralPath (Join-Path $d 'baseline.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if(!$qa.cliSha256 -or $qa.cliSha256 -ne $sha -or $before.cliSha256 -eq $sha -or $before.source -ne $qa.base){throw 'Baseline or changed executable differs'}
$borrowed=@('borrow-root','borrow-enum','borrow-explicit-proof','borrow-option','borrow-struct','generic-field','recursive-borrow')
function Read-ArcResult($name,$command,$source,$expected){
    $out=Join-Path $d "$name.$command.after.json"
    $err=Join-Path $d "$name.$command.after.stderr.log"
    if($command -eq 'verify'){
        & $cli verify $source --mode test --backend emit --json > $out 2> $err
    }else{
        & $cli check $source --json > $out 2> $err
    }
    $code=$LASTEXITCODE
    $report=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
    $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
    if($code -ne 1 -or $report.status -ne 'denied' -or $report.stage -ne 'type-check' -or $diagnostics.Count -ne 1 -or $diagnostics[0].code -ne $expected -or $report.obligations -or $report.solver_checks){throw "Unexpected $name $command result $($diagnostics.code -join ',')"}
    $span=$diagnostics[0].span
    $spelling=(Get-Content -LiteralPath $source -Raw).Substring($span.start,$span.end-$span.start)
    if(($expected -eq 'sema.lifetime.promotion_receiver' -and $spelling -ne 'value') -or ($expected -eq 'sema.lifetime.promotion_execution' -and $spelling -notmatch '^value\.promote(?:_unchecked)?\(')){throw "Unexpected $name $command span $spelling"}
    [ordered]@{name=$name;command=$command;exit=$code;stage=$report.stage;code=$diagnostics[0].code;span=$spelling;inputSha256=ArcSha $source;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
}
$results=@(foreach($row in $before.cases){
    $source=Join-Path $cases "$($row.name).arcw"
    if((ArcSha $source) -ne $row.inputSha256){throw "Baseline input drift $($row.name)"}
    $expected=if($row.name -in $borrowed){'sema.lifetime.promotion_receiver'}else{'sema.lifetime.promotion_execution'}
    Read-ArcResult $row.name 'check' $source $expected
    if($row.name -in 'borrow-explicit-proof','phantom-argument'){
        Read-ArcResult $row.name 'verify' $source $expected
    }
})
$linearOwned=Join-Path $d 'linear-owned.arcw'
$linearBorrowed=Join-Path $d 'linear-borrowed.arcw'
$ownedSource=[IO.File]::ReadAllText($linearOwned)
$borrowedSource=$ownedSource.Replace('struct Cell180 { value: i64 }','struct Cell180 { value: &i64 }')
if($borrowedSource -ceq $ownedSource){throw 'Missing linear control leaf'}
[IO.File]::WriteAllText($linearBorrowed,$borrowedSource,[Text.UTF8Encoding]::new($false))
$linear=@(
    Read-ArcResult 'linear-owned' 'check' $linearOwned 'sema.lifetime.promotion_execution'
    Read-ArcResult 'linear-borrowed' 'check' $linearBorrowed 'sema.lifetime.promotion_receiver'
)
if($results.Count -ne 13 -or $linear.Count -ne 2 -or (ArcSha $cli) -ne $sha){throw 'CLI receipt differs'}
[ordered]@{version=1;base=$qa.base;cliSha256=$sha;cases=$results;linear=$linear}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
@($results)+@($linear)|Format-Table name,command,code,span

