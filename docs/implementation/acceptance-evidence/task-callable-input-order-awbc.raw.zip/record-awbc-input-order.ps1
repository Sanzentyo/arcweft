$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -AsHashtable -Depth 100 }
$publication = Read-Record 'callable-input-order-awbc-checkpoint.verified'
$core = Read-Record 'callable-input-order-awbc-owner2-20261105.runtime.terminal-audit'
$factory = Read-Record 'callable-input-order-awbc-factory1-20261105.runtime.terminal-audit'
$callables = Read-Record 'callable-input-order-awbc-callable-all1-20261105.runtime.terminal-audit'
$structure = Read-Record 'callable-input-order-awbc.structure'
if ((git rev-parse HEAD).Trim() -ne $publication.commit -or $core.executed -ne 2278 -or $core.passed -ne 2278 -or $structure.exitCode -ne 0) { throw 'Unexpected source/Core result' }
$expectedFailures = @('rich_text_factories::source_style_factories_preserve_typography_values_and_units_during_composition', 'rich_text_factories::source_style_factories_use_caller_order_for_conflicting_properties')
if ($factory.executed -ne 19 -or $factory.passed -ne 17 -or $factory.failed -ne 2 -or @(Compare-Object $expectedFailures @($factory.failureSet.test)).Count) { throw 'Factory results differ: inspect before recording' }
if ($callables.executed -ne 316 -or $callables.passed -ne 314 -or $callables.failed -ne 2 -or $callables.skipped -ne 0 -or @(Compare-Object $expectedFailures @($callables.failureSet.test)).Count) { throw 'Full callable results differ' }
$freeze = Read-Record 'callable-input-order-awbc-factory1-20261105.source-freeze'
foreach ($row in $freeze.paths) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Source drift' } }
$graphFreeze = Read-Record 'callable-input-order-owner2-20261105.source-freeze'
$graphInputs = @{}; foreach ($row in $graphFreeze.paths) { $graphInputs[$row.path] = $row.sha256 }
$manifests = @($freeze.paths | Where-Object { $_.path -match '(^|/)Cargo\.(toml|lock)$' })
foreach ($row in $manifests) { if ($graphInputs[$row.path] -ne $row.sha256) { throw 'Cargo graph input changed' } }
$recordPath = 'docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath = 'docs/implementation/current-status.md'
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$before = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if ($record.callableInputOrder.Contains('awbcFramesAndForwarding')) { throw 'Preserve previous evidence' }
$history = [IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix = [ordered]@{ bytes = $history.Length; sha256 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant() }
$status = [IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n", "`n")
$oldRows = @($status -split "`n" | Where-Object { $_ -match '^\| (RichTextの部分layout指定／source factory|共有契約／推移的逆依存matrix|CLI全target照合|workspace check／Clippy・fmt・構造gate) \|' })
$genericRow = @($status -split "`n" | Where-Object { $_ -match '^\| Generic Match' })
$metrics = @(Import-Csv -LiteralPath "$taskTemp/callable-input-order-awbc.structure-report/file_metrics.csv" | Where-Object path -in $publication.paths.path)
if ($metrics.Count -ne 19) { throw 'Missing current owner measurements' }
$metrics | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/callable-input-order-awbc.owner-metrics.json" -Encoding utf8
$files = @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object { $_.Name -like 'callable-input-order-awbc*' })
$files += @(Get-ChildItem -LiteralPath "$taskTemp/callable-input-order-awbc.structure-report" -File -Recurse)
foreach ($name in @('record-awbc-input-order.ps1', 'run-awbc-input-order-structure.ps1', 'run-presentation-projection-owner.ps1', 'audit-nextest-final-result.ps1', 'write-verified-evidence-archive.ps1')) { $files += Get-Item -LiteralPath "$taskTemp/$name" }
$root = [IO.Path]::GetFullPath($taskTemp)
$index = @(foreach ($file in @($files | Sort-Object FullName -Unique)) { [ordered]@{ entry = $file.FullName.Substring($root.Length + 1).Replace([IO.Path]::DirectorySeparatorChar, [char]'/'); bytes = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant() } })
$index | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/callable-input-order-awbc.archive-inputs.json" -Encoding utf8
$files += Get-Item -LiteralPath "$taskTemp/callable-input-order-awbc.archive-inputs.json"
. "$taskTemp/write-verified-evidence-archive.ps1"
$archive = 'docs/implementation/acceptance-evidence/task-callable-input-order-awbc.raw.zip'
$raw = Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record.callableInputOrder.awbcFramesAndForwarding = [ordered]@{
    version = 1; recordedAt = [DateTime]::UtcNow.ToString('o'); source = $publication
    state = 'AWBC frame transport and explicit external-declaration forwarding are implemented. The actual point-unit alias regression passes in Native and decoded AWBC with public JSON save at every OneOp. Two existing pixel-unit factory cases still fail; full reverse/quality acceptance remains pending.'
    implementation = @('FiberFrame owns an immutable Arc<RuntimeInputOrder>. Strict live/inert snapshot conversion, original-signature arity admission and the shared metadata allowance preserve it. All seven applied-callable VM paths transfer the complete invocation; zero-argument callback roots retain the same packet provenance.', 'VmHost lends the active frame order to Product external execution context. RuntimeExternalCallOperandOrder distinguishes authored descriptor order from complete enclosing-input forwarding. The strict JSON, version-1 AWBC and Native Source codecs and body transcript all include this required mode; no legacy reader or implicit canonical fallback.', 'RuntimePlan external declaration wrappers explicitly select InvocationInputs. Borrowed preflight verifies the complete input order and canonical ABI inventory before moving values. The shared projection reorders provider descriptors, unwraps/omits optional bindings, leaves formal ABI values/types in place and resolves the final target to Authored. Ordinary project-body calls retain their own authored order.')
    validation = [ordered]@{
        core = $core; coreCommand = (Read-Record 'callable-input-order-awbc-owner2-20261105.runtime').command
        initialCatalog = (Read-Record 'callable-input-order-awbc-owner1-20261105.catalog'); initialReason = 'Catalog compile101 from E0502 in the new frame fixture: clone the second slot before mutably pushing it. No runtime result for this attempt.'
        factory = $factory; factoryCommand = (Read-Record 'callable-input-order-awbc-factory1-20261105.runtime').command
        allCallables = $callables; allCallablesCommand = (Read-Record 'callable-input-order-awbc-callable-all1-20261105.runtime').command; allCallablesScope = 'Separate full callable_execution run:316 executed,314 PASS,2 FAIL,0 skipped. Its only failures are the same two unchanged px factory cases. All other existing Native/decoded-AWBC callable, action, map, traversal, source-order and suspension cases pass; this is not the full58 reverse-dependency suite.'
        factoryScope = 'One actual Compiler callable_execution filtered run:19 executed,17 PASS,2 FAIL. Point-unit direct and alias composition both yield24pt under Native and decoded AWBC; each AWBC OneOp performs public JSON save/restore. Empty optional aliases, generic function/closure quantities and all14 existing presentation_scalar_values pass. Both original px cases remain unchanged and fail at the existing Pt-only Size property admission. Do not merge this run with Core or claim Native public save.'
        sourceRelation = 'Core/structure were frozen on de4b9bd903fc563a22ae4b38381e43cbd75a60b8 plus the19 published paths. Compiler was frozen on source083baa5e4596a9f4d36c32bb1124adc9683d2db3. Each uses4105 actual repository inputs with0 source/case/executable drift; relevant original user WIP is observed, not pristine HEAD.'
        formatting = 'All19 changed Rust paths rustfmt and staged whitespace exit0.'; structure = $structure
    }
    graphReuse = [ordered]@{ record = 'callableInputOrder.validation.graph'; roots = @('arcweft-core', 'arcweft-rich-text-schema', 'arcweft-dialogue', 'arcweft-lang-sema', 'arcweft-runtime-plan'); reversePackages = 58; checkedManifestInputs = $manifests.Count; manifestDrift = 0; reason = 'Reuse the actual metadata/tree0-difference graph; no Cargo input changed. Full58 runtime and full98 check/Clippy remain pending.' }
    ownershipReview = 'Frame order is owned once and borrowed through the existing original-program context. Codecs and all wrapper producers consume the same closed mode; no name/factory special case, rank side table, copied permutation payload, source reconstruction, dual reader or version bump. All19 owner/physical/code/embedded-test measurements are archived. Structure98 packages,385 review triggers,0 blocking.'
    correctionReason = 'Supersedes the old AWBC/provider-unconnected current statement and the old alias11pt observation only for this new source. Preserve the earlier failing observations, catalog failure and all full SHAs as history. The2 px failures are concrete remaining unit-admission evidence; they do not reopen accepted Generic Match or other accepted RichText boundaries.'
    supersededCurrentRows = $oldRows; historyPrefix = $historyPrefix
    raw = [ordered]@{ path = $archive; bytes = $raw.bytes; sha256 = $raw.sha256; entries = $raw.entries.Count; entryDrift = 0; indexEntry = 'callable-input-order-awbc.archive-inputs.json' }
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$sha = $publication.commit
$rows = @(foreach ($line in ($status -split "`n")) {
    if ($line.StartsWith('| RichTextの部分layout指定／source factory |')) { "| RichTextの部分layout指定／source factory | **既受入を維持。Native／AWBCの順序転送を検証・公開済み、単位等は継続** | Source ${sha}は実引数順をAWBC frame・strict保存形式・宣言wrapperからproviderへ接続する。Core library2278／2278 PASS。Compiler callable_execution全316件は314 PASS／2 FAILで、ptの直接／alias合成は両backendで24pt、AWBC各OneOpの公開JSON保存復元もPASS。旧alias11ptの実測は履歴に保持し、このSourceの残作業から除く。元のpx2条件はPt限定Size schemaで引き続きFAIL。単位を落とすTextModel／表示consumer、typed bare serif、static inline_stylesと全体受入を継続する。部分layout・共通property等の既受入は維持する。[実測・旧失敗・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |" }
    elseif ($line.StartsWith('| 共有契約／推移的逆依存matrix |')) { $line.Replace('中間Sourcebfb7e39cb26299185cf498e1ad8ec16e33b02e10', "中間Source$sha").Replace('Core library2273件', 'Core library2278件') }
    elseif ($line.StartsWith('| CLI全target照合 |')) { $line.Replace('中間Source bfb7e39cb26299185cf498e1ad8ec16e33b02e10', "中間Source $sha") }
    elseif ($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')) { $line.Replace('Sourcebfb7e39cb26299185cf498e1ad8ec16e33b02e10は変更Rust23件', "Source${sha}は変更Rust19件") }
    else { $line }
})
if (@(Compare-Object $genericRow @($rows | Where-Object { $_ -match '^\| Generic Match' })).Count) { throw 'Generic Match row changed' }
[IO.File]::WriteAllText((Join-Path $PWD $statusPath), ($rows -join "`n"), [Text.UTF8Encoding]::new($false))
$append = @"

## 2026-11-05 — AWBC frame order and external declaration forwarding

- Source $sha (parent $($publication.parent)) publishes19 Rust paths: immutable frame provenance, complete applied-callable transfer, strict save/restore, original-program host context and explicit declaration-wrapper descriptor forwarding. Values stay in formal ABI order; authored body calls keep their own descriptor order.
- Keep initial catalog101 (new fixture E0502) and the separate final Core2278/2278 PASS,0 skipped. The actual Compiler19-case run has17 PASS/2 FAIL; a separate full callable_execution run has316 executed,314 PASS/2 FAIL,0 skipped. Direct/alias24pt is now equal in Native and decoded AWBC with public JSON save at every OneOp; both original px cases still fail Pt-only Size admission. Empty aliases, generated function/closure quantities, existing14 scalar cases and all other callable integration cases pass. No budget, assertions or input conditions were weakened.
- All4105 frozen repository inputs/cases/executables have0 drift per run. Changed19 Rust fmt/whitespace and98-package structure gate exit0,385 review triggers/0 blocking. Cargo inputs are unchanged for the58-package graph; full reverse runtime/check/Clippy remain pending. Correct only the superseded AWBC/provider and alias status, retaining all previous results and SHAs. Accepted Generic Match remains accepted. [Raw attempts and scope](acceptance-evidence/task-rich-text-property-identity.json); [one current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath), $append + "`n", [Text.UTF8Encoding]::new($false))
$after = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach ($key in $before.Keys) {
    if ($key -eq 'callableInputOrder') { foreach ($child in $before[$key].Keys) { if (($before[$key][$child] | ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key][$child] | ConvertTo-Json -Depth 100 -Compress)) { throw 'Previous child changed' } } }
    elseif (($before[$key] | ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key] | ConvertTo-Json -Depth 100 -Compress)) { throw 'Previous field changed' }
}
$now = [IO.File]::ReadAllBytes((Join-Path $PWD $historyPath)); $prefix = [byte[]]::new($history.Length); [Array]::Copy($now, $prefix, $history.Length)
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $historyPrefix.sha256) { throw 'History prefix changed' }
[ordered]@{ source = $sha; priorFieldDrift = 0; historyPrefixDrift = 0; rawEntries = $raw.entries.Count; rawBytes = $raw.bytes; rawSha256 = $raw.sha256; manifestInputs = $manifests.Count; manifestDrift = 0 } | ConvertTo-Json -Compress
