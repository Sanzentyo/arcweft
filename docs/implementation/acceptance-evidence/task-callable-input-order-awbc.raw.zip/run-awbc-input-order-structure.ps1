$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze=Get-Content -LiteralPath "$taskTemp/callable-input-order-awbc-owner2-20261105.source-freeze.json" -Raw|ConvertFrom-Json
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}}
Assert-Inputs
$started=[DateTime]::UtcNow.ToString('o')
$command=@('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking','--write',"$taskTemp/callable-input-order-awbc.structure-report")
& cargo @command *> "$taskTemp/callable-input-order-awbc.structure.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=$command;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/callable-input-order-awbc.structure.json" -Encoding utf8
Get-Content -LiteralPath "$taskTemp/callable-input-order-awbc.structure.log" -TotalCount 6
exit $code
