param([string]$InputFreeze='presentation-slot-value-focus3-20261101')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$input=Get-Content -LiteralPath "$taskTemp/$InputFreeze.source-freeze.json" -Raw|ConvertFrom-Json -Depth 25
$quality='presentation-slot-value-quality-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfff')
$freeze=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();recordedAt=[DateTime]::UtcNow.ToString('o');held=$input.held;paths=$input.paths}
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Quality source drift: '+$row.path)}}}
Assert-Inputs
$freeze|ConvertTo-Json -Depth 25|Set-Content -LiteralPath "$taskTemp/$quality.source-freeze.json" -Encoding utf8
[IO.File]::WriteAllText("$taskTemp/product-execution-quality.active.txt",$quality)
function Invoke-Quality([string]$name,[object[]]$arguments) {
    Assert-Inputs
    if(Test-Path -LiteralPath "$taskTemp/$name.json"){throw 'Quality attempt exists'}
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> "$taskTemp/$name.log"
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$name.json" -Encoding utf8
    Write-Output "$name exit=$code"
    if($code -ne 0){throw ('Quality failed: '+$name)}
}
Invoke-Quality "$quality.workspace-check" @('check','--workspace','--all-targets','--all-features','--locked')
Invoke-Quality "$quality.clippy" @('clippy','--workspace','--all-targets','--all-features','--locked')
Invoke-Quality "$quality.core-default" @('check','-p','arcweft-core','--lib','--locked')
Invoke-Quality "$quality.core-wasm" @('check','-p','arcweft-core','--lib','--target','wasm32-unknown-unknown','--locked')
Invoke-Quality "$quality.structure" @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking','--write',"$taskTemp/$quality.structure-report")
$owned=@(Get-Content -LiteralPath "$taskTemp/presentation-slot-value.fmt-owned.txt")
& rustfmt --edition 2024 --config skip_children=true --check @owned *> "$taskTemp/$quality.fmt.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;paths=$owned;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$taskTemp/$quality.fmt.json" -Encoding utf8
if($code -ne 0){throw 'Format failed'}
Write-Output 'quality terminal'
