$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$normal = 'presentation-slot-value-reverse-20261101'
$extra = 'presentation-slot-value-full-cli-20261101'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100 }
$metadata = [IO.File]::ReadLines("$taskTemp/$extra.metadata.log") | Where-Object { $_.StartsWith('{"packages"') } | Select-Object -Last 1 | ConvertFrom-Json -Depth 100
$package = @($metadata.packages | Where-Object name -eq 'arcweft-cli')[0]
$targets = @($package.targets | Where-Object { $_.test -and @($_.kind | Where-Object { $_ -in @('lib', 'bin', 'test') }).Count })
$covered = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$cases = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$ignored = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$rows = @()
foreach ($epoch in @("$normal.cli-unit", "$normal.cli-integration", "$extra.check", "$extra.additional-integration")) {
    $catalog = Read-Record "$epoch.catalog"
    $terminal = Read-Record "$epoch.runtime.terminal-audit"
    $inventory = Read-Record "$epoch.catalog.inventory"
    if ($catalog.exitCode -ne 0 -or $terminal.catalogCaseDrift -ne 0 -or $terminal.sourceDrift -ne 0 -or $terminal.base -ne '774c6dc03d1cab6f3f1e6da70648cf6405e18a74') { throw 'CLI cohort is not current and audited' }
    for ($index = 0; $index -lt $catalog.command.Count; $index++) {
        switch ($catalog.command[$index]) {
            '--lib' { foreach ($target in $targets | Where-Object { 'lib' -in $_.kind }) { [void]$covered.Add($target.name) } }
            '--bins' { foreach ($target in $targets | Where-Object { 'bin' -in $_.kind }) { [void]$covered.Add($target.name) } }
            '--test' { [void]$covered.Add($catalog.command[$index + 1]) }
        }
    }
    foreach ($case in $inventory.rows) {
        $key = $case.binary + [char]0 + $case.test
        if ($case.status -eq 'matches') {
            if (-not $cases.Add($key)) { throw 'CLI case is counted more than once' }
        } elseif ($case.ignored) {
            if (-not $ignored.Add($key)) { throw 'Ignored CLI case is counted more than once' }
        } else { throw 'A nonignored CLI case was excluded' }
    }
    $rows += [pscustomobject]@{ epoch = $epoch; passed = $terminal.passed; failed = $terminal.failed; ignored = $terminal.skipped; catalog = "$epoch.catalog.inventory.json"; terminal = "$epoch.runtime.terminal-audit.json" }
}
$missing = @($targets | Where-Object { -not $covered.Contains($_.name) })
if ($missing.Count -or $covered.Count -ne $targets.Count) { throw 'The current CLI target inventory is incomplete' }
$passed = ($rows | Measure-Object -Property passed -Sum).Sum
$failed = ($rows | Measure-Object -Property failed -Sum).Sum
if ($passed + $failed -ne $cases.Count) { throw 'Unique CLI cases differ from terminal totals' }
[ordered]@{
    version = 1; source = '774c6dc03d1cab6f3f1e6da70648cf6405e18a74'; sourceInputs = 4041
    metadata = "$extra.metadata.log"; testableTargets = @($targets.name | Sort-Object); coveredTargets = @($covered | Sort-Object); missingTargets = @()
    groups = $rows; uniqueExecuted = $cases.Count; passed = $passed; failed = $failed; ignored = $ignored.Count
    caseDrift = 0; sourceDrift = 0; isSingleRuntimeCommand = $false
    scope = 'Every current CLI lib/bin/integration test target is selected across these four audited commands. Target coverage includes compiled zero-case targets; this does not invent native runtime cases for them. Feature unions and individual runtime counts remain separate.'
} | ConvertTo-Json -Depth 15 | Set-Content "$taskTemp/presentation-slot-value-full-cli-20261101.all-cli-scope.json" -Encoding utf8
[pscustomobject]@{ targets = $targets.Count; uniqueExecuted = $cases.Count; passed = $passed; failed = $failed; ignored = $ignored.Count; missingTargets = 0 } | ConvertTo-Json -Compress
