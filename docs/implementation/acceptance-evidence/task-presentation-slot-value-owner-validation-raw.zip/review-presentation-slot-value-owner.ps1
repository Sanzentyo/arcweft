$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskT/convergence-image-git-bytes.ps1"
$base='c947f1e724489be6bf15ba600976ef57b473bad6'
$source='774c6dc03d1cab6f3f1e6da70648cf6405e18a74'
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source changed'}
$old=Get-Content -LiteralPath "$taskT/presentation-slot-address.owner-review.json" -Raw|ConvertFrom-Json -Depth 50
foreach($p in $old.manifestLockPins){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Cargo metadata needs refresh'}}
$metadata=[IO.File]::ReadLines($old.metadataSource)|Where-Object {$_.StartsWith('{"packages"')}|Select-Object -Last 1|ConvertFrom-Json -Depth 100
$nodes=@{};$reverse=@{}
foreach($n in $metadata.resolve.nodes){$nodes[$n.id]=$n;foreach($dep in $n.dependencies){if(-not $reverse.ContainsKey($dep)){$reverse[$dep]=[Collections.Generic.List[string]]::new()};$reverse[$dep].Add($n.id)}}
function Lines([string]$s){if(-not $s.Length){return 0};$n=$s.Split([char]10).Count;if($s.EndsWith("`n")){$n--};$n}
$owned=@(Get-Content -LiteralPath "$taskT/checkpoint-presentation-slot-value.owned.txt"|Where-Object {$_ -like '*.rs'})
$quality=[IO.File]::ReadAllText("$taskT/product-execution-quality.active.txt").Trim()
$scanner=Import-Csv -LiteralPath "$taskT/$quality.structure-report/file_metrics.csv"
$metrics=@(foreach($p in $owned){
 $text=[IO.File]::ReadAllText((Join-Path (Get-Location) $p))
 $isNew=$p -in @('crates/arcweft-core/src/pattern/presentation_slot.rs','crates/arcweft-core/src/value/awbc_save/retained_admission/presentation.rs')
 $prior=if($isNew){''}else{[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',($base+':'+$p))))}
 $package=@($metadata.packages|Where-Object name -eq ($p -split '/')[1])[0]
 $inline=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
 $testLoc=[int](@($scanner|Where-Object path -eq $p)[0].embedded_test_lines)
 $responsibility=switch -Wildcard ($p){
  '*pattern/presentation_slot.rs' {'One exact standard opaque producer and version-1 borrowed four-field payload grammar for every resource family. No lease, mutable state, I/O or source recovery.'}
  '*retained_admission/presentation.rs' {'The original program admission context preflights the entire prospective graph before tuple/string allocation and retains first-failure/quota/provenance. It constructs or reads only an inert shared address, never a resource lease.'}
  '*value/view/effects.rs' {'The existing borrowed opaque view adds a general prospective construction backing referencing its exact owner and borrowed payload. It cannot yield a live value or activate snapshot data; no SlotRef-specific view variant or duplicate value authority.'}
  '*sema/src/ownership.rs' {'Existing recursive runtime ownership projection selects the exact closed SlotRef owner and SnapshotClone behavior. It does not recursively own the referenced surface.'}
  '*type_capability.rs' {'Canonical Copy capability treats SlotRef<T> as unrestricted for generic and closed T; no second local-use resolver.'}
  '*compiler/src/lower.rs' {'Existing final semantic-to-runtime type projection emits the same Core opaque owner; no producer-name reconstruction, fallback, HIR traversal or extra executable frame.'}
  '*presentation_tests.rs' {'Existing Source/compiler contract tests add aliases, explicit/inferred calls, generic duplicate reads and retained ABI checks for all eight resource families. Tests follow the projection owner.'}
  default {'Existing opaque predicate, structured-error or module export owner delegates to the one new payload grammar. No parallel reader, unrelated state or dependency change.'}
 }
 [ordered]@{path=$p;package=$package.name;bytes=(Get-Item -LiteralPath $p).Length;physicalLoc=(Lines $text);baselineLoc=(Lines $prior);growth=((Lines $text)-(Lines $prior));classification=$(if($p -like '*presentation_tests.rs'){'test'}else{'production'});embeddedTestLoc=$testLoc;fanIn=@($reverse[$package.id]).Count;fanOut=@($nodes[$package.id].dependencies).Count;responsibility=$responsibility}
})
$result=[ordered]@{version=1;source=$source;base=$base;workingTree='No task-owned Rust dirt; original tracked WIP14 and untracked actual files6 retained';paths=$metrics;manifestLockPins=$old.manifestLockPins;manifestLockDrift=0;metadataSource=$old.metadataSource;metadataSha256=$old.metadataSha256;metadataReuse='Resolved all-feature graph reused after all pinned manifest/lock hashes matched. Fresh reverse/workspace validation is running separately.';changedPackages=@('arcweft-core','arcweft-lang-sema','arcweft-compiler');workspacePackages=$old.workspacePackages;reverseWorkspace=$old.reverseWorkspace;layerDirection='Core remains Sans-I/O; the shared interaction-model address is lower-layer data. Sema and Compiler project the same Core owner. No manifests, feature wiring, host, renderer or unsafe changes.';disposition='The new exact payload grammar and admission constructor follow separate real ownership boundaries. Existing large pattern/error/type-projection owners retain their established cohesive responsibilities and delegate instead of gaining a parallel grammar. Borrowed construction remains general and allocation-free. No new file grew more than 300 physical LOC; tests exercise the same value/ABI owners.';scope='Codec and type projection only. Plan/AWBC test type owners are not Source factory execution. Source calls, commands and driver connection remain pending.';at=[DateTime]::UtcNow.ToString('o')}
$result|ConvertTo-Json -Depth 35|Set-Content -LiteralPath "$taskT/presentation-slot-value.owner-review.json" -Encoding utf8
[ordered]@{source=$source;paths=$owned.Count;maxGrowth=($metrics.growth|Measure-Object -Maximum).Maximum;manifestLockDrift=0}|ConvertTo-Json -Compress