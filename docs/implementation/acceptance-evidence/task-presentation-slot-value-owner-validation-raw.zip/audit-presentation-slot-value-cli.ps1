$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='presentation-slot-value-full-cli-20261101'
$prior=Get-Content 'docs/implementation/acceptance-evidence/task-r3616-arcweft-cli-runtime.terminal-audit.json' -Raw|ConvertFrom-Json -Depth 35
$current=Get-Content "$taskTemp/$stem.check.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 35
$inventory=Get-Content "$taskTemp/$stem.check.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 35
if($prior.failed -ne 43 -or $current.sourceDrift -ne 0 -or $current.catalogCaseDrift -ne 0){throw 'CLI comparison inputs are not audited'}
$old=[Collections.Generic.HashSet[string]]::new();foreach($case in $prior.failureSet){[void]$old.Add($case.binary+"`0"+$case.test)}
$now=[Collections.Generic.HashSet[string]]::new();foreach($case in $current.failureSet){[void]$now.Add($case.binary+"`0"+$case.test)}
$selected=[Collections.Generic.HashSet[string]]::new();foreach($case in $inventory.rows){if($case.status -eq 'matches' -and -not $case.ignored){[void]$selected.Add($case.binary+"`0"+$case.test)}}
$new=@($current.failureSet|Where-Object {-not $old.Contains($_.binary+"`0"+$_.test)})
$same=@($current.failureSet|Where-Object {$old.Contains($_.binary+"`0"+$_.test)})
$resolved=@($prior.failureSet|Where-Object {$selected.Contains($_.binary+"`0"+$_.test) -and -not $now.Contains($_.binary+"`0"+$_.test)})
$unselected=@($prior.failureSet|Where-Object {-not $selected.Contains($_.binary+"`0"+$_.test)})
[ordered]@{version=1;priorRun=$prior.run;priorInput=$prior.base;priorFailureCount=43;currentRun=$current.run;currentInput=$current.base;currentFailureCount=$current.failed;sameFailureIds=$same;newFailureIds=$new;resolvedFailureIds=$resolved;unselectedPriorFailureIds=$unselected;meaning='Exact binary and test identifier comparison between distinct frozen inputs. Shared failure identifiers retain prior evidence; no cause or resolution is inferred for a target that was not selected, and this is not one combined execution.'}|ConvertTo-Json -Depth 15|Set-Content -LiteralPath "$taskTemp/$stem.cli-comparison.json" -Encoding utf8
[ordered]@{prior=43;current=$current.failed;same=$same.Count;new=$new.Count;resolved=$resolved.Count;unselected=$unselected.Count}|ConvertTo-Json -Compress
