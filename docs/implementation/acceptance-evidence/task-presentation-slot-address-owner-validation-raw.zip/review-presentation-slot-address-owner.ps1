$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskT/convergence-image-git-bytes.ps1"
$base='05b763093877a313f4e0cfd2fc8469a09cfec400'
$source='c3d2b2d35761382c59d87e81618bef51d3398a5c'
if((git rev-parse HEAD).Trim() -ne $source){throw 'Slot source changed'}
$owned=@(Get-Content -LiteralPath "$taskT/checkpoint-presentation-slot-address.owned.txt"|Where-Object {$_ -like '*.rs'})
$oldFreeze=Get-Content -LiteralPath "$taskT/presentation-handle-projection-full-cli-20261101.source-freeze.json" -Raw|ConvertFrom-Json
$manifests=@($oldFreeze.paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -match '(^|/)Cargo\.toml$'})
if(-not $manifests.Count){throw 'No metadata input pins'}
foreach($p in $manifests){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Cargo metadata needs refreshing'}}
$metadataPath="$taskT/presentation-handle-projection-full-cli-20261101.metadata.log"
$metadata=[IO.File]::ReadLines($metadataPath)|Where-Object {$_.StartsWith('{"packages"')}|Select-Object -Last 1|ConvertFrom-Json -Depth 100
$members=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($id in $metadata.workspace_members){[void]$members.Add($id)}
$packages=@{};foreach($p in $metadata.packages){$packages[$p.id]=$p}
$nodes=@{};$reverse=@{}
foreach($n in $metadata.resolve.nodes){$nodes[$n.id]=$n;foreach($dep in $n.dependencies){if(-not $reverse.ContainsKey($dep)){$reverse[$dep]=[Collections.Generic.List[string]]::new()};$reverse[$dep].Add($n.id)}}
$changed=@('arcweft-core','arcweft-interaction-model','arcweft-presentation','arcweft-runtime-driver')
$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$queue=[Collections.Generic.Queue[string]]::new()
foreach($p in $metadata.packages|Where-Object {$_.name -in $changed}){[void]$seen.Add($p.id);$queue.Enqueue($p.id)}
while($queue.Count){$id=$queue.Dequeue();foreach($parent in $reverse[$id]){if($seen.Add($parent)){$queue.Enqueue($parent)}}}
function Lines([string]$value){if(-not $value.Length){return 0};$n=$value.Split([char]10).Count;if($value.EndsWith("`n")){$n--};$n}
$metrics=@(foreach($p in $owned){
 $text=[IO.File]::ReadAllText((Join-Path (Get-Location) $p))
 $prior=if($p -eq 'crates/arcweft-interaction-model/src/presentation/slot.rs'){''}else{[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',($base+':'+$p))))}
 $owner=($p -split '/')[1]
 $package=@($metadata.packages|Where-Object name -eq $owner)[0]
 $test=$p -match '/tests(/|\.rs$)'
 $inline=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
 $responsibility=switch -Wildcard ($p){
  '*interaction-model/src/presentation/slot.rs' {'One target/slot/resource grammar, borrowed validation, strict Serde, exact typed errors. No lease, runtime state, I/O or source lookup.'}
  '*presentation/src/lib.rs' {'Retained slot state and Rust surface contexts hold the shared address; duplicate address fields/key and validation were removed. Sealed Rust body kinds select the existing resource kind. Background context retains only its image identity behavior.'}
  '*runtime-driver/src/display.rs' {'Mechanical shared-address getter migration in the existing display application owner. No new parsing, dispatch, state or Host success path.'}
  '*core/src/presentation/resources.rs' {'Existing custody ledger retains the shared address; private duplicate address grammar removed. Banks, tokens, grants and lease authority are unchanged.'}
  '*storage.rs' {'Existing executable/custody admission delegates address validation and retains structured errors. No second reader or state grammar.'}
  default {if($test){'Tests follow the corresponding address, custody or retained-state owner; malformed decode and sticky executable-admission rejection are both retained.'}else{'Existing presentation vocabulary/error owner; shared-address integration only.'}}
 }
 [ordered]@{path=$p;package=$owner;bytes=(Get-Item -LiteralPath $p).Length;physicalLoc=(Lines $text);baselineLoc=(Lines $prior);growth=((Lines $text)-(Lines $prior));classification=$(if($test){'test'}else{'production'});embeddedTestLoc=$(if($inline.Success){Lines ($text.Substring($inline.Index))}else{0});fanIn=@($reverse[$package.id]).Count;fanOut=@($nodes[$package.id].dependencies).Count;responsibility=$responsibility}
})
$result=[ordered]@{version=1;source=$source;base=$base;workingTree='No task-owned Rust dirt; original tracked WIP14 and untracked actual files6 retained';paths=$metrics;manifestLockPins=$manifests;manifestLockDrift=0;metadataSource=$metadataPath;metadataSha256=(Get-FileHash -LiteralPath $metadataPath).Hash.ToLowerInvariant();metadataReuse='Original all-feature metadata is reused only after every pinned Cargo manifest/lock byte is confirmed unchanged. No dependency or feature edits occurred.';changedPackages=$changed;workspacePackages=$members.Count;reverseWorkspace=@($metadata.packages|Where-Object {$members.Contains($_.id) -and $seen.Contains($_.id)}|Sort-Object name|ForEach-Object name);layerDirection='Core and presentation consume interaction-model. No upper-layer dependency was added to Core; no renderer, host, filesystem, clock or device is introduced in the shared owner.';disposition='One shared address authority replaces private Core address validation and retained registry side keys. Public constructors become fallible so a surface family cannot be silently reinterpreted. Existing background image identity remains on its legitimate display context. The new module is cohesive and below size triggers; unrelated historical hotspots are not split.';broaderAcceptance='Four-owner checks are intermediate evidence. Complete reverse/workspace/target integration and Source SlotRef value ABI are not claimed by this owner publication.';at=[DateTime]::UtcNow.ToString('o')}
$result|ConvertTo-Json -Depth 30|Set-Content -LiteralPath "$taskT/presentation-slot-address.owner-review.json" -Encoding utf8
[ordered]@{source=$source;paths=$owned.Count;workspace=$members.Count;reverse=$result.reverseWorkspace.Count;manifestLockDrift=0;maxGrowth=($metrics.growth|Measure-Object -Maximum).Maximum}|ConvertTo-Json -Compress
