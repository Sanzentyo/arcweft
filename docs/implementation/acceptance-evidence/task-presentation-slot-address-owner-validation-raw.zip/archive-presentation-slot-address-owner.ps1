$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskT/assert-no-arcweft-build.ps1"
$source='c3d2b2d35761382c59d87e81618bef51d3398a5c'
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source changed'}
function Record([string]$name){Get-Content -LiteralPath "$taskT/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$stem='presentation-slot-address-owner2-20261101'
$freeze=Record "$stem.source-freeze"
foreach($p in $freeze.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw ('Source drift: '+$p.path)}}
$terminal=Record "$stem.runtime.terminal-audit"
if($terminal.actualExitCode -ne 0 -or $terminal.executed -ne 2420 -or $terminal.passed -ne 2420 -or $terminal.failed -ne 0 -or $terminal.skipped -ne 0 -or $terminal.selectedPackages -ne 4 -or $terminal.catalogCaseDrift -ne 0 -or $terminal.sourceDrift -ne 0){throw 'Owner terminal differs'}
$gates=@(foreach($name in @('check','clippy','fmt')){$r=Record "$stem.$name";if($r.exitCode -ne 0 -or $r.sourceDrift -ne 0){throw 'Owner gate failed'};$r})
$first=Record 'presentation-slot-address-owner1-20261101.check'
if($first.exitCode -ne 101 -or (Test-Path -LiteralPath "$taskT/presentation-slot-address-owner1-20261101.runtime.json")){throw 'First failure evidence differs'}
$inventory=Record "$stem.catalog.inventory"
$review=Record 'presentation-slot-address.owner-review'
$publication=Record 'checkpoint-presentation-slot-address.verified'
$files=@(Get-ChildItem -LiteralPath $taskT -File|Where-Object {
 $_.Name -match '^presentation-slot-address-owner[12]-20261101\.' -or
 $_.Name -in @('presentation-slot-address.owner-review.json','run-presentation-slot-address-owner.ps1','run-presentation-slot-address-owner2.ps1','review-presentation-slot-address-owner.ps1','archive-presentation-slot-address-owner.ps1','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','assert-no-arcweft-build.ps1','presentation-handle-projection-full-cli-20261101.metadata.log','presentation-handle-projection-full-cli-20261101.metadata.json') -or
 $_.Name -match '^checkpoint-presentation-slot-address\.(verified.json|prepared.json|reviewed.patch|message.txt)$'
})
$zipPath='docs/implementation/acceptance-evidence/task-presentation-slot-address-owner-validation-raw.zip'
$manifestPath='docs/implementation/acceptance-evidence/task-presentation-slot-address-owner-validation.json'
if((Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $manifestPath)){throw 'Do not overwrite evidence'}
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
$entries=@(try{foreach($file in $files|Sort-Object Name){$bytes=[IO.File]::ReadAllBytes($file.FullName);$entry=$zip.CreateEntry($file.Name,[IO.Compression.CompressionLevel]::Optimal);$stream=$entry.Open();try{$stream.Write($bytes)}finally{$stream.Dispose()};[ordered]@{name=$file.Name;bytes=$bytes.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}}}finally{$zip.Dispose()})
$manifest=[ordered]@{version=1;date='2026-11-01';sourceCommit=$source;sourceTree=(git rev-parse 'HEAD^{tree}').Trim();workingTree='Original tracked WIP14/untracked actual files6 retained; no task-owned Rust dirt';sourceInputs=$freeze.paths.Count;sourceDrift=0;publication=$publication;ownerPackages=@('arcweft-core','arcweft-interaction-model','arcweft-presentation','arcweft-runtime-driver');runtime=$terminal;packageCounts=@($inventory.rows|Group-Object package|ForEach-Object {[ordered]@{package=$_.Name;selected=@($_.Group|Where-Object status -eq 'matches').Count;excluded=@($_.Group|Where-Object status -ne 'matches').Count}});gates=$gates;firstAttempt=[ordered]@{check=$first;runtimeNotRun=$true;reason='One retained presentation test still called id() on the now direct PublicId getter. The missing consumer was migrated; no runtime result is invented for the failed check.'};ownershipReview=$review;behavior='One shared target/slot/resource address grammar serves construction, borrowed validation and strict Serde. Core custody and retained slot state store the same address. Invalid decode, wrong-resource valid-address admission, sticky failure and unchanged live retirement are checked.';resourceConditions='Original handle/scope/metadata limits are retained. A formerly untyped slot.bank fixture is renamed slot.background.bank to match its existing Background resource; no budgets or operation counts are widened.';sourceSlotRefValueAbiAccepted=$false;sourcePresentationExecutionAccepted=$false;broaderAcceptance='Complete 62-package reverse closure and workspace gates for this address change are not run here. Prior Handle/Generic Match acceptance and original broad evidence are retained at their own frozen inputs.';raw=[ordered]@{path=(Split-Path $zipPath -Leaf);sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$entries}}
$manifest|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $manifestPath -Encoding utf8
$check=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try{if($check.Entries.Count -ne $entries.Count){throw 'ZIP entry count differs'};foreach($row in $entries){$entry=$check.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw 'ZIP entry differs'}}}finally{$check.Dispose()}
[ordered]@{source=$source;sourceInputs=$freeze.paths.Count;passed=$terminal.passed;failed=$terminal.failed;rawEntries=$entries.Count;rawBytes=(Get-Item -LiteralPath $zipPath).Length;sourceSlotRefValueAbiAccepted=$false}|ConvertTo-Json -Compress
