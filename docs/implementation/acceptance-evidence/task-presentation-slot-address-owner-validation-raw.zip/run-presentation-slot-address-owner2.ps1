$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='presentation-slot-address-owner2-20261101'
& "$taskT/assert-no-arcweft-build.ps1"
if(Test-Path -LiteralPath "$taskT/$stem.check.json"){throw 'Do not overwrite an existing epoch'}
$old=Get-Content -LiteralPath "$taskT/presentation-handle-contract-cli-repair2-20261101.source-freeze.json" -Raw|ConvertFrom-Json
$paths=@(@($old.paths.path)+@('crates/arcweft-interaction-model/src/presentation/slot.rs')|Sort-Object -Unique)
$freeze=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();held=$old.held;recordedAt=[DateTime]::UtcNow.ToString('o');paths=@(foreach($p in $paths){[ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})}
$freeze|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskT/$stem.gate-source-freeze.json" -Encoding utf8
function Invoke-Gate([string]$name,[string]$exe,[string[]]$arguments){
 foreach($p in $freeze.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Source drift'}}
 $start=[DateTime]::UtcNow.ToString('o')
 & $exe @arguments *> "$taskT/$stem.$name.log"
 $code=$LASTEXITCODE
 foreach($p in $freeze.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Source drift'}}
 [ordered]@{version=1;base=$freeze.base;command=@($exe)+$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskT/$stem.$name.json" -Encoding utf8
 if($code -ne 0){throw "Gate failed: $name"}
}
$packages=@('-p','arcweft-interaction-model','-p','arcweft-core','-p','arcweft-presentation','-p','arcweft-runtime-driver')
Invoke-Gate 'check' 'cargo' (@('check')+$packages+@('--all-targets','--all-features','--locked'))
$extras=@('crates/arcweft-core/src/awbc/product_step/tests/dialogue_handoff.rs','crates/arcweft-interaction-model/src/presentation/arguments.rs','crates/arcweft-interaction-model/src/presentation/callables.rs','crates/arcweft-lang-sema/src/final_analysis/tests/presentation.rs','crates/arcweft-core/src/pattern/presentation.rs','crates/arcweft-compiler/src/lower/presentation_tests.rs','crates/arcweft-interaction-model/src/presentation/slot.rs')
& "$taskT/run-shared-identity-owner.ps1" -Stem $stem -Selection (@('--lib')+$packages+@('--all-features','--locked')) -ExpectedMatches -1 -AdditionalPaths $extras
if($LASTEXITCODE -ne 0){throw 'Slot address owner runtime failed'}
Invoke-Gate 'clippy' 'cargo' (@('clippy')+$packages+@('--all-targets','--all-features','--locked'))
$owned=@('crates/arcweft-interaction-model/src/presentation.rs','crates/arcweft-interaction-model/src/presentation/slot.rs','crates/arcweft-core/src/presentation.rs','crates/arcweft-core/src/presentation/resources.rs','crates/arcweft-core/src/presentation/resources/storage.rs','crates/arcweft-core/src/presentation/resources/tests.rs','crates/arcweft-core/src/presentation/resources/banks/tests.rs','crates/arcweft-core/src/awbc/fiber/tests/presentation.rs','crates/arcweft-presentation/src/lib.rs','crates/arcweft-presentation/src/tests.rs','crates/arcweft-runtime-driver/src/display.rs')
$owned|Set-Content -LiteralPath "$taskT/$stem.fmt-owned.txt" -Encoding utf8
Invoke-Gate 'fmt' 'rustfmt' (@('--edition','2024','--config','skip_children=true','--check')+$owned)
Write-Output 'Shared slot address owner checks closed; Source SlotRef value ABI remains a separate pending boundary.'
