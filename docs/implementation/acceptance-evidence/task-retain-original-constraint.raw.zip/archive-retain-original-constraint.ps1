$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '649750493c511846c9ef36563f2d78d8d8cd2659'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'retain-original-constraint.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='The original path or joint branch binds its existing scoped constraint with its graph snapshot. Bound preparation verifies exact membership. Principal effect closure independently confirms that snapshot once and reuses recognition of the identical obligation. Fixture-only callers can still validate an additional original fact.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'retain-original-constraint.ownership-review.json') -Encoding utf8NoBOM
$names=@('retain-original-constraint.dev02-input.json','retain-original-constraint.dev02-staged.patch','retain-original-constraint.dev02-fmt.log','retain-original-constraint.dev02-fmt-check.log','retain-original-constraint.dev02-nextest.log','retain-original-constraint.dev02-result.json','retain-original-constraint.dev02-structure.log','retain-original-constraint.dev02-structure-result.json','retain-original-constraint.dev02-check.jsonl','retain-original-constraint.dev02-check.stderr.log','retain-original-constraint.dev02-check-result.json','retain-original-constraint.dev02-test-errors.json','retain-original-constraint.source-publication.json','retain-original-constraint.ownership-review.json','retain-original-constraint.nextest-comparison.json','archive-retain-original-constraint.ps1','compare-retain-original-constraint-nextest.ps1')
$names+=@('retain-original-constraint.dev01-input.json','retain-original-constraint.dev01-nextest.log','retain-original-constraint.dev01-result.json','retain-original-constraint.dev01-check-result.json')
$names+=@('candidate-work-distribution.diagnostic01-input.json','candidate-work-distribution.diagnostic01-input.patch','candidate-work-distribution.diagnostic01-nextest.log','candidate-work-distribution.diagnostic01-result.json','candidate-work-distribution.diagnostic01-stacks.json')
$names+=@('retain-original-constraint.diagnostic-comparison.json','retain-original-constraint.dev02-context-work-limit.debugger.log','retain-original-constraint.dev02-map-work-limit.debugger.log','retain-original-constraint.dev02-retained-work-limit.debugger.log')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-retain-original-constraint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-retain-original-constraint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'retain-original-constraint.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json




















