param([string]$CoreEpoch='action-channel-receive-core9-20261103',[string]$SourceEpoch='action-channel-receive-source15-20261103',[string]$QualityStem='action-channel-receive-quality4-20261103')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Receipt([string]$Name){Get-Content -LiteralPath "$taskTemp/$Name.json" -Raw|ConvertFrom-Json -Depth 100}
$publication=Receipt 'checkpoint-action-channel-receive-effects.verified'
if((git rev-parse HEAD).Trim() -ne $publication.commit){throw 'Publication changed'}
$core=Receipt "$CoreEpoch.runtime.terminal-audit"
$source=Receipt "$SourceEpoch.runtime.terminal-audit"
if(-not $core.isPassingRun -or $core.executed -ne 2245 -or -not $source.isPassingRun -or $source.executed -ne 12){throw 'Final owner runs differ'}
$freeze=Receipt "$CoreEpoch.source-freeze"
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Final source drift: $($row.path)"}}
$quality=@(foreach($name in @('check','clippy','structure')){$receipt=Receipt "$QualityStem-$name";if($receipt.exitCode){throw 'Final quality failed'};$receipt})
$format=Receipt 'action-channel-receive-format-check'
if($format.exitCode){throw 'Final format failed'}
$original=Receipt 'task-documentation-final-untracked-before'
foreach($row in $original.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$history=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md')
$before=[IO.File]::ReadAllBytes($history)
$prefixSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant()
$raw='docs/implementation/acceptance-evidence/task-action-channel-receive.raw.zip'
$record='docs/implementation/acceptance-evidence/task-action-channel-receive.json'
if((Test-Path $raw) -or (Test-Path $record)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {$_.Name -match '^(action-channel-receive|checkpoint-action-channel-receive[.-])'})
$files+=@(Get-Item "$taskTemp/record-action-channel-receive.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/audit-nextest-final-result.ps1","$taskTemp/run-action-payload-quality.ps1","$taskTemp/user-requested-cargo-clean-20261103T025644Z.json","$taskTemp/user-requested-cargo-clean-20261103T025644Z.log")
foreach($directory in (Get-ChildItem -LiteralPath $taskTemp -Directory|Where-Object Name -Match '^action-channel-receive.*[.]structure-report$')){$files+=@(Get-ChildItem -LiteralPath $directory.FullName -File -Recurse)}
$files=@($files|Sort-Object FullName -Unique)
$entries=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($taskTemp.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Raw count mismatch'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Raw entry mismatch'}}}finally{$zip.Dispose()}
$runs=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter 'action-channel-receive-*.terminal-audit.json'|Sort-Object Name|ForEach-Object {Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json -Depth 100})
$metrics=Import-Csv "$taskTemp/$QualityStem.structure-report/file_metrics.csv"
$measurements=@(foreach($path in $publication.paths.path){$metric=@($metrics|Where-Object path -EQ $path);[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;physicalLoc=$(if($path -like '*.rs' -or $path -like '*.md'){@([IO.File]::ReadLines([IO.Path]::GetFullPath($path))).Count}else{$null});owner=$(if($metric.Count){$metric[0].owner}else{'fixture or maintained specification'});classification=$(if($metric.Count){$metric[0].classification}else{'fixture or maintained specification'})}})
$evidence=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');status='owner-execution-checkpoint';source=$publication.commit;publication=$publication;intermediatePublication=(Receipt 'checkpoint-action-channel-receive.verified')
 scope='Action receive uses ordinary LocalOnly Program Needs, original typed Flow/AWBC instructions, actual Native/Product mailboxes, exact-instruction suspension/resume, and original-source-bound save/restore. Owner execution is verified; full reverse-consumer runtime acceptance remains pending.'
 ownership='The selected original type inventory remains the sole Action declaration and payload authority. The channel is evaluated once and captured. The result relation, retained group and queue candidate are admitted before FIFO dequeue. Native child execution retains the actual main owner inside Engine, included in admission and inert rollback. Every Program template owns its independently executed body effects. Sema seals Thread body effects from the completed fold; Source codecs and task admission authenticate them. ProgramBody borrows the enclosing lexical binder, while Thread creation requires control.spawn rather than invoking the child body in its parent. No new Host task family, live queue Clone/Serde, compatibility reader or non-1 owned version marker.'
 runs=$runs;finalCore=$core;finalSource=$source;quality=$quality;format=$format;fixtureGeneration=(Receipt 'action-channel-receive-fixtures1-20261103')
 repairs=@(
 'Initial compile failures retained: missing exhaustive consumers/type spelling, generated module path, Program body wrapper, caller status migration and fixture fields/imports.'
 'The first nine cases passed four accepted emission cases and failed five new receive cases. The receive result had no original declaration placement. A typed ActionReceive initialization now owns that vacant result.'
 'Subsequent cases exposed whole-session Native admission treating the selected child as main and omitting the temporarily extracted actual main. Main custody now remains inside the session throughout child execution; all owner traversals and rollback include both actual fibers.'
 'A thread sender exposed inherited parent effects on the independently executed child. Program templates now own body effects from the completed Sema fold. The lexical ProgramBody verifier and original Source admission were migrated together; ordinary function signature checks remain exact.'
 'The initial thread test rejected its required Program HostMetadata notification. The final test requires exactly one Program launch for the authored thread, none for receive, and rejects every Host request.'
 'The first full Core run passed2237/2245 and failed8: stale embedded Source fixture bytes, missing thread launch permission in manual fixtures, and the opcode inventory missing0x4b. The two binaries were regenerated using their original Program builder and canonical version1 roundtrip, rather than retaining an obsolete decoder.'
 'The first full workspace check failed101 on two exhaustive JIT/codegen consumers. Receive needs the real session and suspension owner, so the pure-region eligibility checks now select the established VM execution path. Clippy and structure were not run after that failure; their later receipts are separate.'
 )
 behaviors=@('Native and canonical-decoded Product return the actual sent payload; consecutive receives preserve FIFO and equal-shaped channels remain distinct.','Receive captures an aliased channel in a function. A genuine receiver parks before a thread sender publishes, resumes, and returns42. Every Product step crosses JSON save/cold restore.','Empty receive stays Blocked with zero executed operations and no Host work. Altered wait key or original instruction is rejected without replacing the original session.','A restored original parked receiver cancels without executing, synthesizing a payload or emitting effects; repeated VM cancellation is inert. This case tests the actual receiver fiber, not a claim about an external session-cancellation API.')
 sourceInputs=$freeze.paths.Count;sourceDrift=0;caseAndExecutableDrift=0;finalRunsReusePriorPasses=$false
 fullConsumerAcceptance=[ordered]@{lastSource='7104b200150b9b85b31cd686c48573b92b2028d3';normalPassed=9194;cliPassed=660;cliFailed=33;currentEpochRuntime='not yet revalidated across the full reverse closure';genericMatch='accepted and published; no new Generic Match defect was established'}
 structuralReview=[ordered]@{measurements=$measurements;disposition='Original types own role lookup; Core mailbox owns message custody; original Native/VM execution owners own admission and transfers. The new body effects belong to Program templates and are transported by existing Sema/plan/Source/verifier boundaries. Engine owns actual parked-main custody rather than copying values or keeping a resolver side table. Existing large dispatchers remain closed exhaustive owners; no dependency direction, I/O boundary or unsafe boundary changed.'}
 originalWip=[ordered]@{tracked=12;untracked=6;heldPatchSha256=$publication.heldPatchSha256;untrackedHashDrift=0}
 historyPrefix=[ordered]@{bytes=$before.Length;sha256=$prefixSha;drift=0}
 clean=(Receipt 'user-requested-cargo-clean-20261103T025644Z')
 raw=[ordered]@{path=$raw;bytes=(Get-Item $raw).Length;sha256=(Get-FileHash $raw).Hash.ToLowerInvariant();entries=$entries;entryDrift=0}
}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($evidence|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$status=[IO.Path]::GetFullPath('docs/implementation/current-status.md');$text=[IO.File]::ReadAllText($status);$newline=$(if($text.Contains("`r`n")){"`r`n"}else{"`n"})
$header="確認日: 2026-11-03。最新公開Sourceは$($publication.commit)（Action送受信のowner実行とProgram本体のeffect権限を検証）。Core2245件とSource12件はすべて新規PASS、workspace全98のcheck／Clippy・構造gateは終了0。直近の全consumer runtime検証はSource 7104b200150b9b85b31cd686c48573b92b2028d3の通常9194件PASSであり、今回のowner結果へ付け替えない。既存12 tracked／6 actual untracked WIPを保持している。"
$text=[regex]::Replace($text,'(?m)^確認日:[^\r\n]*',[Text.RegularExpressions.MatchEvaluator]{param($m)$header})
$pattern='(?m)^\| Action宣言・payload record／型付きチャンネル値 \|[^\r\n]*'
if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Current Action row differs'}
$rows=@(
 '| Action宣言・payload record／型付きチャンネル値 | **受入・公開済み** | Source 7104b200150b9b85b31cd686c48573b92b2028d3。元Action PublicIdとproducer digestを持つRuntimeNominalDeclarationIdを、宣言・型・schema・Native・AWBCのversion 1契約で共有する。非genericのrecord payloadと元チャンネルidentityを保持し、別宣言・異family・競合identityを拒否する。[宣言identityの受入](acceptance-evidence/task-action-original-declaration-identity.json)、[修飾callの受入](acceptance-evidence/task-action-qualified-path.json)。 |'
 "| Action emit／receive・セッション待機 | **owner実行を検証・公開。全consumer runtime再検証は未完** | Source $($publication.commit)。receiveはチャンネルを一度捕捉するLocalOnly Program Needで、同じセッションのキューから型付きpayloadをFIFOで受け取る。Native／decoded Productで直接受信、関数内alias、別チャンネル分離、thread送信待ちからの再開、毎step JSON保存・cold restore、空待機の0操作、待機改変の原子拒否と受信fiberのキャンセルを検証した。新旧12件とCore全2245件は新規PASS。子実行中のmain所有者欠落とthread本体が親のeffectを借りる問題を再現・修復した。Hostジョブを追加せず、元Sourceの本体権限を照合する。全体goalの未完了を理由に宣言identityやGeneric Matchの受入を戻さない。[中間commit・失敗・修復・最終実測](acceptance-evidence/task-action-channel-receive.json)。 |"
) -join $newline
$text=[regex]::Replace($text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m)$rows})
$qualityPattern='(?m)^\| workspace check／Clippy・fmt・構造gate \|[^\r\n]*'
$qualityRow="| workspace check／Clippy・fmt・構造gate | **最新Sourceの全98 check／Clippy・構造gateは終了0。警告は残存** | Source $($publication.commit)、$($freeze.paths.Count)入力、all-target／all-feature／lockedで全98 gate終了0。変更Rustのfmt checkも終了0。[最新gate・入力・所有境界レビュー](acceptance-evidence/task-action-channel-receive.json)。doctest88件とWeb wasm checkの直近実測はSource 7104b200150b9b85b31cd686c48573b92b2028d3の[原本](acceptance-evidence/task-action-original-declaration-identity.json)へ保持し、今回再実行とはしない。 |"
$text=[regex]::Replace($text,$qualityPattern,[Text.RegularExpressions.MatchEvaluator]{param($m)$qualityRow})
[IO.File]::WriteAllText($status,$text,[Text.UTF8Encoding]::new($false))
$append=@"


## 2026-11-03 Action受信のowner実行・独立Program本体の権限

Source $($publication.commit)、中間Source 50c31c487e22f4f55446b23a20c1832029f526c4。中間commitは既受入送信4件PASS／受信5件FAILの状態を明記して公開し、その後の失敗・修復と原本を保持した。最終owner runはCore2245／2245、Compiler action_channel12／12を新規PASS。全98 check／Clippy・構造gateは終了0。全consumer runtime／doctest／wasmは過去のSource7104の結果と区別する。

宣言placement、子実行中の実際のmain所有者、独立Program本体のeffect、古いfixture bytesと起動権限を修復した。親のlexical型束縛と子の実行権限を分け、元Source templateへ厳密照合する。空待機・thread再開・FIFO・別channel・JSON cold restore・改変拒否・待機fiber cancellationを確認した。Generic MatchとAction宣言identityの既受入は維持する。

現状のAction行は「既受入の宣言」と「送受信owner実行」を分け、長い旧checkpoint列挙を原本へ移した。訂正理由は、全体goalと独立した受入境界を混同せず、最新の検証範囲を一か所で示すため。実測件数・失敗・full SHAは削除せず[原本](acceptance-evidence/task-action-channel-receive.json)へ保持する。

既存履歴の先頭$($before.Length) bytes（SHA256 $prefixSha）をbyte一致で保持し、この段落だけを追記する。既存12 tracked／6 actual untracked WIPも保持。
"@
$stream=[IO.File]::Open($history,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($history);$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixSha){throw 'History prefix changed'}
[ordered]@{source=$publication.commit;rawEntries=$entries.Count;rawBytes=$evidence.raw.bytes;rawSha256=$evidence.raw.sha256;preservedHistoryBytes=$before.Length;preservedHistorySha256=$prefixSha;historyPrefixDrift=0}|ConvertTo-Json
