$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix=Join-Path $taskTemp 'line-root-defer-20261108.core-quality-r1'
if (Test-Path "$prefix.source.json") { throw 'Quality epoch already exists' }
$paths=(Get-Content "$taskTemp/line-initial-inputs-20261108.compiler-expectation-r2.source.json" -Raw | ConvertFrom-Json).inputs.path
$epoch=@(foreach($path in $paths){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$base=(git rev-parse HEAD).Trim()
[ordered]@{base=$base;inputs=$epoch}|ConvertTo-Json -Depth 8|Set-Content "$prefix.source.json"
function Assert-Source { foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}} }
function Invoke-Check([string]$name,[string[]]$arguments){
 Assert-Source
 $started=[DateTime]::UtcNow
 & cargo @arguments *> "$prefix.$name.log"
 $code=$LASTEXITCODE
 Assert-Source
 [ordered]@{base=$base;command=$arguments;exitCode=$code;sourceInputs=$epoch.Count;sourceDrift=0;startedAt=$started.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content "$prefix.$name.receipt.json"
 if($code -ne 0){throw "Check failed: $name"}
}
Invoke-Check 'clippy' @('clippy','--locked','-p','arcweft-core','-p','arcweft-compiler','--all-features','--all-targets')
$paths=@(Get-Content "$taskTemp/line-root-defer-20261108.custody-source.owned.txt")
Assert-Source
& rustfmt --check --edition 2024 --config skip_children=true @paths *> "$prefix.fmt.log"
$code=$LASTEXITCODE
Assert-Source
[ordered]@{base=$base;exitCode=$code;paths=$paths;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content "$prefix.fmt.receipt.json"
exit $code