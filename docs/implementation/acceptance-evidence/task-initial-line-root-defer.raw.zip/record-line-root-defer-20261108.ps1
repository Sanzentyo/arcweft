$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$name='line-root-defer-20261108'
$source='5ba67c20a9aacafe3d1dd25939be42c92cddf52a'
if((git rev-parse HEAD).Trim() -ne $source){throw 'Unexpected source base'}
foreach($check in @('check','clippy','structure','fmt')){
 $receipt=Get-Content "$taskTemp/$name.workspace-quality-r2.$check.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw "Gate did not pass: $check"}
}
$terminal=Get-Content "$taskTemp/$name.prepared-transfer.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($terminal.passed -ne 152 -or $terminal.failed -ne 0 -or $terminal.sourceDrift -ne 0){throw 'Final owner terminal unavailable'}
$epoch=(Get-Content "$taskTemp/$name.prepared-transfer.source-freeze.json" -Raw|ConvertFrom-Json).paths
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
. "$taskTemp/convergence-image-git-bytes.ps1"
$owned=@(Get-Content "$taskTemp/$name.custody-source.owned.txt")+@('crates/arcweft-compiler/tests/evaluated_effects/ordinary_defer.rs')
$metrics=Import-Csv "$taskTemp/$name.structure-report/file_metrics.csv"
$packageMetrics=Import-Csv "$taskTemp/$name.structure-report/package_metrics.csv"
$rows=@(foreach($path in $owned){
 $metric=@($metrics|Where-Object path -eq $path)
 if($metric.Count -ne 1){throw "Missing exact metrics: $path"}
 $bytes=Read-GitBytes @('show',('bb37a6084997ed3ccce688c278e6e3623ca83118:'+$path))
 $before=[Text.Encoding]::UTF8.GetString($bytes)
 $baseLines=($before -split "`n").Count - [int]$before.EndsWith("`n")
 $published=Read-GitBytes @('show',($source+':'+$path))
 if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($published)).ToLowerInvariant() -ne (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()){throw "Published source differs: $path"}
 [ordered]@{path=$path;owner=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLines=[int]$metric[0].physical_lines;embeddedTestLines=[int]$metric[0].embedded_test_lines;classification=$metric[0].classification;baseLines=$baseLines;growth=[int]$metric[0].physical_lines - $baseLines}
})
$metadata=Get-Content "$taskTemp/$name.metadata-all.json" -Raw|ConvertFrom-Json -Depth 100
$workspace=[Collections.Generic.HashSet[string]]::new([string[]]$metadata.workspace_members)
$core=($metadata.packages|Where-Object name -eq 'arcweft-core').id
$reverse=[Collections.Generic.HashSet[string]]::new()
[void]$reverse.Add($core)
do {
 $changed=$false
 foreach($node in $metadata.resolve.nodes){
  if($workspace.Contains($node.id) -and -not $reverse.Contains($node.id)){
   foreach($dep in $node.deps){
    if($reverse.Contains($dep.pkg)){$changed=$reverse.Add($node.id) -or $changed;break}
   }
  }
 }
} while($changed)
$reverseNames=@($metadata.packages|Where-Object {$reverse.Contains($_.id)}|ForEach-Object name|Sort-Object)
if($reverseNames.Count -ne 53){throw 'Resolved Core reverse closure changed'}
$review=[ordered]@{
 version=1;source=$source;workingTree='12 preserved original tracked paths and 6 actual original untracked files; no uncommitted task Rust paths before recording evidence';base='bb37a6084997ed3ccce688c278e6e3623ca83118';files=$rows
 workspacePackages=$metadata.workspace_members.Count;resolvedPackages=$metadata.packages.Count;coreReversePackages=$reverseNames;packageMetrics=@($packageMetrics|Where-Object {$_.package -in @('arcweft-core','arcweft-compiler')})
 ownership='Core owns the unique line-resource ledger and revisioned Active/PublishedHandles registry. The defer packet owns values; received leases remain at their issuer. Native and AWBC enumerate actual packet/frame/register storage and submit borrowed transition proofs. Native child preparation now keeps the validated token-to-local destinations in place of its previous token set, admitting the complete lease transition before taking a packet. No live-value copy, persistent side table, source reconstruction, fallback resolver, I/O dependency, compatibility reader, or contract-version bump was added.'
 cohesion='Large Native engine/dialogue and AWBC product-step/line/snapshot owners retain their existing scheduler, transactional execution, or retained-graph admission boundaries. line_task handle/activation/defer own resource state, revision authority and sole capture packets. ownership slot/binary own the closed diagnostic identity and its codecs. Core stores adapt those same proofs to their actual frames. Compiler ordinary_defer is an integration-test owner with shared real Source/host/cold-restore fixtures. Exact LOC, growth, embedded tests and fan-in/out are retained above; size triggers alone do not justify widening APIs or splitting these coupled state transitions.'
}
$review|ConvertTo-Json -Depth 30|Set-Content "$taskTemp/$name.ownership-review.json"
[ordered]@{version=1;phase='preparation only';cargoStarted=$false;reason='The first focused wrapper referenced the removed crates/arcweft-runtime-driver/src/display/viewport.rs from its historical path template. A current 3416-path manifest replaced the template; no product test failed in this preparation attempt.'}|ConvertTo-Json|Set-Content "$taskTemp/$name.repair-r1.preparation-refusal.json"
$archivePath='docs/implementation/acceptance-evidence/task-initial-line-root-defer.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Root defer archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
 $_.Name -match '^line-root-defer-20261108\.(first\.|regression-source\.|core-check-r[12]\.|repair-r[12]\.|owners-r1\.|core-unit-r1\.|custody-source\.|custody-auth-r1\.|auth-source\.|final-owners\.|prepared-transfer\.|prepared-source\.|workspace-quality-r[12]\.|core-quality-r1\.|metadata-all\.|ownership-review\.)' -or $_.Name -in @('record-line-root-defer-20261108.ps1','run-line-root-frozen-nextest-20261108.ps1','run-source-frozen-nextest.ps1','run-line-root-core-quality-20261108.ps1','run-line-root-workspace-quality-20261108.ps1','run-line-root-workspace-quality-r2-20261108.ps1')
}|Sort-Object Name)
$items=@(foreach($file in $files){[ordered]@{path=$file.FullName;entry=$file.Name}})+@(Get-ChildItem "$taskTemp/$name.structure-report" -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.FullName;entry=('structure-report/'+$_.Name)}})
$entries=@(foreach($item in $items){[ordered]@{entry=$item.entry;bytes=(Get-Item -LiteralPath $item.path).Length;sha256=(Get-FileHash -LiteralPath $item.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archivePath),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($item in $items){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$item.path,$item.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Archive shape differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$source;reproductionSource='56a3b280c9047861960c72071e0c864b8d7fdc06';custodySource='9bbe68a9a97d12f9126f668460f0f010e5c5563a';testAndContractSource='a6196f5cd57c9a481b740128280e9b986a89a316'
 firstProbe=[ordered]@{passed=0;failed=2;skipped=117;native='tick 15: line handle is not live in this activation';savedAwbc='line handle is owned by another runtime slot';limit='Each test stopped in its normal-completion branch; cancellation was not executed in this first failed probe.'}
 accepted='Owned initial Actor input can move into a reached Line root defer. Always/completed/cancelled filters across normal completion/cancellation and Native/saved AWBC cover 12 runtime conditions in four tests. Existing 1-op/512-step, two-reveal, one-acquire/release and ordered-log assertions remain unchanged. A fifth test refuses six slot-coordinate mutations plus packet removal and duplication, verifies the original snapshot after every refusal, and completes the original execution.'
 storage='RuntimeOwnedSlotId::LineDeferCapture identifies actual execution/activation/registration/ordinal custody; binary tag 22, unknown tag 23 rejection, human/binary roundtrips, and all contract markers remain at version 1. Published issuer leases authenticate received custody. Native prepares actual child-local destinations and the whole issuer transition before taking the packet; AWBC projects actual prepared child-register slots before taking it.'
 validation=[ordered]@{compilerFinal=$terminal;corePrior=[ordered]@{source='9bbe68a9a97d12f9126f668460f0f010e5c5563a';passed=2327;failed=0;skipped=0;scope='Earlier Core unit run before the Native preflight-only implementation change; not promoted to a new full Core or Core53 run.'};workspaceGates='Final 5ba67c20a9aacafe3d1dd25939be42c92cddf52a all-target/all-feature workspace check and Clippy, canonical structural gate and 16-path fmt exit 0 with warnings retained.';sourceInputs=3416;sourceDrift=0;graph=$review}
 limitations='Core53/default-CLI primary matrix on this source has no terminal yet. The f267dc30d20a25092c64d08bb42b596b14ad3400 8030-run matrix remains prior-source evidence with its actual four failures. Root defer cleanup acceptance is not full producer/platform/Native-public-save/Tier2/parity acceptance. Generic Match and all other accepted boundaries remain accepted.'
 auditNotes='Focused raw audits retain the old wrapper historical held=14 metadata. Actual original WIP is independently pinned as 12 tracked and 6 actual untracked files, never inferred from that metadata. Initial E0423/E0282 build diagnostics, obsolete-wrapper preparation refusal, intermediate 2/149/3/152 runs and every published SHA are preserved, not relabeled as one fresh run.'
 raw=[ordered]@{path=(Split-Path $archivePath -Leaf);sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if($ledger.Contains('"initialInputLineRootDefer"')){throw 'Root defer evidence already exists'}
$fragment=([ordered]@{initialInputLineRootDefer=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$ledger.LastIndexOf('}')
$after=$ledger.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| Line の初期所有入力 |')){
 '| Line の初期所有入力 | **返却Actor／Copyとroot deferの対象条件を検証・公開済み** | 最新Source 5ba67c20a9aacafe3d1dd25939be42c92cddf52a（捕捉slot 9bbe68a9a97d12f9126f668460f0f010e5c5563a、回帰・契約 a6196f5cd57c9a481b740128280e9b986a89a316）。元の発行元台帳を保ったまま、初期所有入力を実root defer packetと実子frameへ一度だけ移す。Native／毎step保存AWBCでAlways／completed／cancelledと通常終了／取消しの12実行条件、保存の6座標・packet欠落／重複の8改変拒否と元状態保全を確認。最終Compiler evaluated_effects／scoped_deferは152 PASS。1-op／512-step、2 reveal、取得・解放各1回とlog順を維持する。既受入Source e5b53074fd340d6471a8a86f666866504e104bb9 のActor再返却／Copy caller再利用と、Source 02d1edb454e2996078a57d25f67570a102b0b14f の初期packet／activation保存監査も保持する。root登録の旧拒否は同じ失敗入力の通過を根拠に履歴へ移し、全体受入へ拡張しない。[各run・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }elseif($_.StartsWith('| 共有契約／推移的逆依存matrix |')){
 $_.Replace('**Core53の対象照合完了：8026 PASS／4 FAIL／41 SKIP**','**前SourceのCore53照合を保持。root defer修復後の統合終端は未確認**').Replace('検証Source f267','root捕捉slotとNative受取先証明を変更したSource 5ba67c20a9aacafe3d1dd25939be42c92cddf52a の再検証は別入力として扱う。前の検証Source f267')
 }elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 '| workspace check／Clippy・fmt・構造gate | **root defer修復後の全workspace gateは終了0** | Source 5ba67c20a9aacafe3d1dd25939be42c92cddf52a の全target／全feature workspace check／Clippy、canonical構造gate、16 Rust path fmtが3416入力drift0で終了0。警告、先行SourceのCore unit2327 PASS、過去の全gate・SHA・Core doctest80 PASSは履歴へ保持し、新Source全Core runへ合成しない。Cargo変更0、実metadataはworkspace98／resolved846、Core逆依存53 package。全14 family・他platform／Tier2・全表示parityの最終受入へ拡張しない。[全実測・構造責任・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }else{$_}
})
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath),($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — 初期所有入力からLine root deferへの移動

再現テスト Source **56a3b280c9047861960c72071e0c864b8d7fdc06** の初回は0 PASS／2 FAIL／117 SKIP。Nativeはtick15の登録でactivation内にhandleがなく、保存AWBCは所有slot不一致で停止した。両テストは最初の通常終了で失敗し、取消しは未実行だった。受入済みの初期Actor再返却／Copy再利用とは別の追加条件であり、Generic MatchやLine/init等を戻す根拠にはしない。

所有権 Source **9bbe68a9a97d12f9126f668460f0f010e5c5563a** は、実root packetのexecution／activation／登録ID／ordinalをLineDeferCaptureとして識別し、元のPublishedHandles台帳で捕捉・子移動・dropを検証する。保存は実packet／frameとの一致を検査する。全contract markerは1のまま、owned-slot binary tag22の往復と未知tag23拒否をCore単体内で確認した。回帰・契約 Source **a6196f5cd57c9a481b740128280e9b986a89a316** は、Always／completed／cancelled×通常終了／取消し×Native／保存AWBCの12実行条件と、6座標・packet欠落／重複の8改変拒否を検証する。全拒否後に元snapshotが一致し、元実行が完走した。先行2 PASS／117 SKIP、149 PASS、3 PASS／119 SKIP、152 PASSの各runは別入力として残す。

最終 Source **5ba67c20a9aacafe3d1dd25939be42c92cddf52a** は、Nativeの既存元pattern検査で得る受取localを子構築proofへ保持し、捕捉packetを取り出す前に元発行元台帳の更新を集約検査する。後段のfallible照合を前倒しし、公開した前の通過を失敗へ読み替えない。最終Compiler2 targetは **152 PASS／0 SKIP**。元の1-op／512-step、2 reveal、取得・解放各1回、log順を維持した。Core unit **2327 PASS** は9bbe Sourceの先行結果であり、新Source全Core結果とはしない。最終workspace全target／全feature check／Clippy、構造gate、16 path fmtは終了0、3416入力drift0。Core53／CLIの新統合終端はまだなく、前Source f267dc30d20a25092c64d08bb42b596b14ad3400の8030件と4失敗を保持する。

構造監査の実byte／物理LOC／embedded test LOC／増分とfan-in/outを原本へ保持する。Coreの大きなengine／dialogueとAWBC product／line／snapshotは、実行・所有取引または保持graph検査の既存境界を担当する。共通handle／activationは唯一のresource台帳・revisionを、deferは唯一の捕捉packetを、slot／binaryは閉じたidentityとcodecを所有する。子準備のtoken集合を元pattern由来の受取先proofへ置換し、live値のcopy、永続side table、Source再構築、fallbackやI/O依存を足さない。Compiler ordinary_deferは同じ実Source・host・cold restore fixtureを用いるintegration ownerであり、LOCだけを理由とするAPI拡大や分割は行わない。

途中のE0423／E0282と、古い検証wrapperが削除済みviewport.rsを参照したCargo開始前の拒否も原本へ保持した。raw wrapperのhistorical held=14 labelを現状WIP数に使わず、既存12 tracked／6 actual untrackedを別照合する。現状一覧の初期入力行と古いgate説明を今回の具体的な通過で置換し、重複した旧拒否の説明を履歴へ移した。[全入力・失敗・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;compilerPassed=152;archiveEntries=$entries.Count;archiveSha256=$record.raw.sha256;reviewedFiles=$rows.Count;coreReversePackages=$reverseNames.Count}|ConvertTo-Json -Compress
