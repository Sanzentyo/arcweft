param([Parameter(Mandatory)][string]$CleanStem)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
. "$e/convergence-image-git-bytes.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
function HashBytes([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
$source='4e39fbd5427fd7ec3e8c66bc48613832e84e4fec'
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source moved before evidence publication'}
$combined=Receipt 'cli-spec-yield-combined-audit'
$freeze=Receipt 'cli-spec-yield-final-20261103.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
if($combined.source -ne $source -or $combined.normal.passed -ne 3400 -or $combined.normal.failed -ne 0 -or $combined.cli.failed -ne 33 -or $combined.subsets.genericMatch.passed -ne 151 -or $combined.reuseProof.consumerExecutableDrift){throw 'Unexpected acceptance proof'}
$quality=@(foreach($kind in @('check','clippy','structure')){$r=Receipt "cli-spec-yield-quality1-20261103-$kind";if($r.exitCode -or $r.base -ne $source -or $r.sourceDrift){throw "Quality failed: $kind"};$r})
$clean=Receipt $CleanStem
if($clean.exitCode -or $clean.sourceDrift -or $clean.gitStatusDrift -or $clean.target -ne 'D:\git\arcweft\target'){throw 'Full clean did not complete'}
$format=Receipt 'cli-spec-yield-final-fmt'
if($format.exitCode){throw 'Formatting failed'}
$graph=Receipt 'cli-spec-yield-final.graph'
if($graph.reversePackages.Count -ne 22){throw 'Reverse closure changed'}
$untracked=Receipt 'task-documentation-final-untracked-before'
foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$heldFreeze=Receipt 'checkpoint-task-view.source-freeze'
$heldBytes=Read-GitBytes (@('diff','--binary','--full-index','--')+$heldFreeze.held)
if((HashBytes $heldBytes) -ne $heldFreeze.heldPatchSha256){throw 'Original tracked WIP changed'}
$history='docs/implementation/convergence-evidence-history.md'
$before=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history))
$committed=Read-GitBytes @('show',"HEAD:$history")
if((HashBytes $before) -ne (HashBytes $committed)){throw 'History already has unpublished edits'}
$prefixHash=HashBytes $before
$record='docs/implementation/acceptance-evidence/task-cli-yield-context.json'
$raw='docs/implementation/acceptance-evidence/task-cli-yield-context.raw.zip'
if((Test-Path -LiteralPath $record) -or (Test-Path -LiteralPath $raw)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object {$_.Name.StartsWith('cli-spec-yield-') -or $_.Name.StartsWith('cli-spec-edge1-') -or $_.Name.StartsWith('checkpoint-cli-yield-') -or $_.Name.StartsWith($CleanStem+'.') -or $_.Name.StartsWith('implementation-cargo-clean-20261103T1023Z.')})
$files+=@(foreach($name in @('record-cli-yield-acceptance.ps1','audit-cli-yield-reverse.ps1','audit-cli-yield-repaired.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','run-action-payload-quality.ps1','action-channel-receive-sema-repair-graph.json')){Get-Item -LiteralPath "$e/$name"})
$files+=@(Get-ChildItem -LiteralPath "$e/cli-spec-yield-quality1-20261103.structure-report" -File -Recurse)
$files=@($files|Sort-Object FullName -Unique)
$entries=@()
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($e.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Archive entry count differs'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry hash differs'}}}finally{$zip.Dispose()}
$runs=@(foreach($stem in @('cli-spec-yield-owner1-20261103','cli-spec-yield-owner2-20261103','cli-spec-yield-owner3-20261103','cli-spec-yield-reverse1-20261103','cli-spec-yield-owner4-20261103')){[ordered]@{stem=$stem;execution=(Receipt "$stem.runtime");terminal=(Receipt "$stem.runtime.terminal-audit")}})
$value=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;inspectedHead=$source
 workingTree='main; original 12 tracked and 6 actual untracked WIP preserved; source and fixtures already published in three normal fast-forward commits'
 scope='Reject an authored yield in an own eager Flow/Predicate/Proof frame before RuntimePlan lowering, using the existing typed execution-body role fold. Independent nested generators keep their own body. This is not acceptance of every generator/lifetime or CLI integration condition.'
 contract='docs/01-language/control-transfer-return-out-yield.md#yield'
 publications=@(foreach($p in @('checkpoint-cli-yield-context','checkpoint-cli-yield-diagnostic','checkpoint-cli-yield-fixtures')){Receipt "$p.verified"})
 graph=$graph;runs=$runs;combined=$combined;quality=$quality;format=$format
 corrections=@(
  'First focused run: 3 PASS / 1 FAIL because the test used bare Predicate/Proof statement blocks rather than expression-block grammar. Corrected only the test source grammar, kept exact typed owner and authored-span assertions; rerun 4/4 PASS.'
  'Existing CLI aggregate expectations for fixtures 013/015/017 described superseded diagnostics. Updated to the existing typed unknown-symbol code/current loop target and unresolved-Out errors; all seven rejection fixtures and their assertions remain. The aggregate now reaches 019, which still fails before its intended unsafe audit. Equal failure IDs do not mean equal causes.'
  'Initial full 4094-case run really failed 36 cases. Three Sema fixtures had placed yield in Flow: two accepted Generic Match transcript cases and one P24 producer row. Moved only those Yield inputs into Stream-returning fn generator bodies. Retained exact payload inventory, operand-sensitive digest and producer-row assertions. Re-executed all 1395 Sema cases. Generic Match remains accepted.'
 )
 acceptedGeneric=[ordered]@{status='accepted and published; retained';originalAcceptance='850534b9e9bc8c8872f6528dd00050a5e6e7699e';originalPublication='f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2';selected=151;passed=151;fresh=144;reused=7;reusedBoundary='Compiler test executables and relevant source inputs match the initial full run exactly; proof completed before full cargo clean'}
 knownFailures=[ordered]@{cliExecuted=694;cliPassed=661;cliFailed=33;retainedFailureIds=33;addedFailureIds=0;resolvedFailureIds=0;newSelectedCases=1;causeEquivalenceClaim=$false;promotionAudit019020='Actual type-check rejects the final expression type before intended metadata audit; no claim of a uniquely established root cause';validDialogue011='Actual runtime reports no active voice; contract versus fixture precondition still needs investigation'}
 fullClean=$clean;priorCapacityClean=(Receipt 'implementation-cargo-clean-20261103T1023Z')
 sourceInputs=4090;sourceDrift=0;caseDrift=0
 supplementalScope='Current change does not modify executable doctests, Cargo features, Core/runtime or render-web. Prior Source9a doctest 88 and wasm check remain historical evidence for their own bytes; they are not claimed as a fresh run on this Yield cut. Current full workspace check/Clippy compile all selected public consumers.'
 originalWip=[ordered]@{tracked=12;actualUntracked=6;heldPatchSha256=$heldFreeze.heldPatchSha256;untrackedHashDrift=0}
 historyPrefix=[ordered]@{bytes=$before.Length;sha256=$prefixHash;drift=0}
 raw=[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();entryDrift=0;entries=$entries}
 currentStatusOrganization='The sole current list is current-status.md. Existing Core53 and ID71 executions remain history for their different graphs; the new Sema22 closure is not presented as a new full Core53 run. Global-goal or CLI incompletion does not reopen accepted features.'
}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($value|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$append=@"


## 2026-11-03 direct frameのyield拒否・CLI診断とfixture入力の訂正

Source実装7401429aed2330af3a1cedbe7f276878942b20bd、CLI診断aa96871cce4c88476230f3f90267e5d4a1d14b70、fixture公開$source。Flow／Predicate／Proofのown eager bodyを既存の型付きExecutionBodyRoleFoldで調べ、yieldを元Stmt／Item／Whole SourceSpanを持つsema.yield.contextで拒否する。独立したseq／stream等のbodyへ侵入しない。初回focused 3 PASS／1 FAILはPredicate／Proofのtest文法を合法な式blockへ訂正して4／4 PASS。CLIの実fixture016もtype-check段階と正確な記述位置を検証した。013／015／017の旧診断期待だけを現行契約へ同期し、7 fixtureは保持する。aggregateは019の意図したunsafe auditより前の型拒否へ進んだため、未解消の失敗として記録する。

all-target／all-feature／lockedの全Sema逆依存22 package・4090入力を選択し、初回4094件は4058 PASS／36 FAIL／24 ignoredだった。通常側の3失敗はFlow内のyieldを前提にしたfixture入力であり、Generic Matchの未完了を示すものではない。Yield行だけをStream戻り値fnのgenerator bodyへ移し、exact payload／operand依存digest／P24 producer rowのassertionを保持した。全Sema1395／1395件を新規PASS。残る4088入力と105 consumer EXEのhash一致を確認し、1395新規＋2699再利用の4094 distinct件として照合した。通常3400／3400 PASS、CLI694件中661 PASS／33 FAIL。単一の4094全件新規成功とはしない。Generic Match151件は144新規＋7再利用で151／151 PASS、受入・公開済みを維持する。CLI失敗IDはSource9a比で維持33／追加0／解消0、選択caseは新規回帰1件追加・削除0。ID一致から原因一致を推定しない。

Source ${source}の全98 workspace check／Clippyと構造gate、変更7 Rust pathのfmt checkは終了0。警告は残る。以前のSource9aの88 doctest／wasm成功は元の入力の実測として保持し、今回の新規実行へ数えない。明示依頼に従う全体cargo cleanは検証終了後に実行して終了$($clean.exitCode)、対象$($clean.target)、Source4090／Git statusの前後差分0、空き容量$($clean.freeBefore)→$($clean.freeAfter) bytes。EXE再利用のhash証明はcleanより前に完了している。[初回失敗・修復・全case・完全SHA・clean原本](acceptance-evidence/task-cli-yield-context.json)。現状は一つの一覧へ反映し、過去結果や別境界の個別受入を消さない。既存履歴の先頭$($before.Length) bytes（SHA256 $prefixHash）を保持し、この記録だけを追記する。既存12 tracked／6 actual untracked WIPを保持。
"@
$stream=[IO.File]::Open([IO.Path]::GetFullPath($history),[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if((HashBytes $prefix) -ne $prefixHash){throw 'History prefix changed'}
[ordered]@{source=$source;normalPassed=3400;cliPassed=661;cliFailed=33;genericPassed=151;fresh=1395;reused=2699;archiveEntries=$entries.Count;archiveBytes=$value.raw.bytes;archiveSha256=$value.raw.sha256;historyPrefixBytes=$before.Length;historyPrefixSha256=$prefixHash}|ConvertTo-Json -Depth 8
