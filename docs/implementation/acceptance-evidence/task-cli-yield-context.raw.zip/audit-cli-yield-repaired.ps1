param([string]$InitialStem='cli-spec-yield-reverse1-20261103',[string]$CurrentStem='cli-spec-yield-owner4-20261103')
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$out="$e/cli-spec-yield-combined-audit.json"
if(Test-Path -LiteralPath $out){throw 'Existing combined receipt'}
function Read-Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$initial=Read-Receipt "$InitialStem.partition-audit"
$current=Read-Receipt "$CurrentStem.runtime.terminal-audit"
if($initial.normal.failed -ne 3 -or -not $current.isPassingRun -or $current.executed -ne 1395){throw 'Inspect actual terminal outcomes'}
$oldFreeze=Read-Receipt "$InitialStem.source-freeze";$newFreeze=Read-Receipt "$CurrentStem.source-freeze"
$oldPaths=@{};foreach($row in $oldFreeze.paths){$oldPaths[$row.path]=$row}
if($oldPaths.Count -ne $newFreeze.paths.Count){throw 'Input set changed'}
$delta=@(foreach($row in $newFreeze.paths){if(-not $oldPaths.ContainsKey($row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Input drift'};if($oldPaths[$row.path].sha256 -ne $row.sha256){[ordered]@{path=$row.path;before=$oldPaths[$row.path].sha256;after=$row.sha256}}})
$expected=@('crates/arcweft-lang-sema/src/final_analysis/tests/semantic_transcript_acceptance/statements.rs','crates/arcweft-lang-sema/src/final_analysis/tests/statement_producers.rs')
if(@(Compare-Object $expected @($delta.path)).Count){throw 'Unreviewed source delta'}
$inventory=Read-Receipt "$CurrentStem.catalog.inventory";$selected=@{}
foreach($row in $inventory.rows){if($row.status -eq 'matches'){$selected[$row.binary+"`t"+$row.test]=$row}}
$fresh=@{};$after=$false
foreach($line in [IO.File]::ReadLines("$e/$CurrentStem.runtime.log")){
    if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
    if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
        $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test
        if($fresh.ContainsKey($key) -or -not $selected.ContainsKey($key) -or $selected[$key].package -ne 'arcweft-lang-sema' -or $status -notin @('PASS','SLOW')){throw 'Invalid fresh case'}
        $fresh[$key]=[ordered]@{package='arcweft-lang-sema';binary=$binary;test=$test;status=$status;run=$CurrentStem;kind='fresh-corrected-Sema-package'}
    }
}
$wanted=@($initial.cases|Where-Object package -eq 'arcweft-lang-sema'|ForEach-Object {$_.binary+"`t"+$_.test})
if($fresh.Count -ne $current.executed -or @(Compare-Object $wanted @($fresh.Keys)).Count){throw 'Sema case set changed'}
$outside=@($initial.cases|Where-Object package -ne 'arcweft-lang-sema')
$binaries=@($outside.binary|Sort-Object -Unique)
$pins=Read-Receipt "$InitialStem.binaries-before";$currentPins=Read-Receipt "$CurrentStem.binaries-before";$newPins=@{}
foreach($pin in $currentPins){$newPins[$pin.binary]=$pin}
$verifiedPins=@(foreach($pin in $pins){if($pin.binary -in $binaries){if(-not $newPins.ContainsKey($pin.binary) -or $newPins[$pin.binary].sha256 -ne $pin.sha256 -or (Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw "Unchanged consumer executable drift: $($pin.binary)"};$pin}})
if($verifiedPins.Count -ne $binaries.Count){throw 'Missing consumer executable pin'}
$coverage=@{};foreach($row in $fresh.Values){$coverage[$row.binary+"`t"+$row.test]=$row}
foreach($row in $outside){$key=$row.binary+"`t"+$row.test;if($coverage.ContainsKey($key)){throw 'Duplicate coverage'};$coverage[$key]=[ordered]@{package=$row.package;binary=$row.binary;test=$row.test;status=$row.status;run=$InitialStem;kind='reused-identical-consumer-executable'}}
if($coverage.Count -ne $initial.cases.Count){throw 'Incomplete full selection'}
function Partition([object[]]$rows){$fail=@($rows|Where-Object status -notin @('PASS','SLOW'));[ordered]@{executed=$rows.Count;passed=$rows.Count-$fail.Count;failed=$fail.Count;failureSet=$fail}}
$normal=Partition @($coverage.Values|Where-Object package -ne 'arcweft-cli');$cli=Partition @($coverage.Values|Where-Object package -eq 'arcweft-cli')
$subsets=[ordered]@{}
foreach($name in @('genericMatch','view40','qualifiedAction11','referenceRegressions7')){
    $previous=Read-Receipt "entity-reference-types-$name";$missing=@()
    $observed=@(foreach($row in $previous.cases){$key=$row.binary+"`t"+$row.test;if($coverage.ContainsKey($key)){$coverage[$key]}else{$missing+=,$row}})
    $subsets[$name]=[ordered]@{selected=$observed.Count;passed=@($observed|Where-Object status -in @('PASS','SLOW')).Count;failed=@($observed|Where-Object status -notin @('PASS','SLOW')).Count;fresh=@($observed|Where-Object kind -eq 'fresh-corrected-Sema-package').Count;reused=@($observed|Where-Object kind -eq 'reused-identical-consumer-executable').Count;outsideSemaClosure=$missing;cases=$observed}
}
$value=[ordered]@{version=1;source=(git rev-parse HEAD).Trim();productionSource='aa96871cce4c88476230f3f90267e5d4a1d14b70';fixturePublication=(Read-Receipt 'checkpoint-cli-yield-fixtures.verified');initial=$initial.terminal;currentSema=$current;normal=$normal;cli=$cli;comparison=$initial.comparison;freshCases=$fresh.Count;reusedCases=$outside.Count;distinctCases=$coverage.Count;subsets=$subsets;reuseProof=[ordered]@{changedInputs=$delta;unchangedInputs=$newFreeze.paths.Count-$delta.Count;productionCodeDrift=0;consumerExecutableDrift=0;consumerExecutables=$verifiedPins;reason='Only two cfg(test) fixture modules changed. Re-execute the entire Sema package. All other selected consumers keep the same cases, unchanged relevant inputs and identical executable hashes, including their actual retained failures.'};sourceInputs=$newFreeze.paths.Count;sourceDrift=0;caseDrift=0;cases=@($coverage.Values|Sort-Object package,binary,test);scope='Distinct full22 selection after fixture-only repair:1395 fresh Sema tests and2699 identical-executable consumer results. The33 retained CLI failures remain failures. Initial3 invalid-Flow fixture failures remain history; Generic Match acceptance is retained.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{normal=$normal;cli=$cli;fresh=$fresh.Count;reused=$outside.Count;consumerBinaries=$verifiedPins.Count;genericMatchPassed=$subsets.genericMatch.passed;genericMatchFailed=$subsets.genericMatch.failed;genericMatchFresh=$subsets.genericMatch.fresh;genericMatchReused=$subsets.genericMatch.reused}|ConvertTo-Json -Depth 6
