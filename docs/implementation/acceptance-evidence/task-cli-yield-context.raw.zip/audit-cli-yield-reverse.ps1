param([string]$Stem='cli-spec-yield-reverse1-20261103')
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$out="$e/$Stem.partition-audit.json"
if(Test-Path -LiteralPath $out){throw 'Existing partition receipt'}
function Read-Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$audit=Read-Receipt "$Stem.runtime.terminal-audit"
$inventory=Read-Receipt "$Stem.catalog.inventory"
if($audit.catalogCaseDrift -or $audit.sourceDrift){throw 'Unpinned terminal'}
$selected=@{};foreach($row in $inventory.rows){if($row.status -eq 'matches'){$selected[$row.binary+"`t"+$row.test]=$row}}
$cases=@{};$after=$false
foreach($line in [IO.File]::ReadLines("$e/$Stem.runtime.log")){
    if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
    if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
        $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test
        if($cases.ContainsKey($key) -or -not $selected.ContainsKey($key)){throw 'Duplicate or foreign case'}
        $cases[$key]=[ordered]@{package=$selected[$key].package;binary=$binary;test=$test;status=$status;run=$Stem}
    }
}
if($cases.Count -ne $audit.executed -or $cases.Count -ne $selected.Count){throw 'Incomplete case set'}
$normal=@($cases.Values|Where-Object package -ne 'arcweft-cli')
$cli=@($cases.Values|Where-Object package -eq 'arcweft-cli')
function Partition([object[]]$rows){$fail=@($rows|Where-Object status -notin @('PASS','SLOW'));[ordered]@{executed=$rows.Count;passed=$rows.Count-$fail.Count;failed=$fail.Count;failureSet=$fail;packages=@($rows.package|Sort-Object -Unique)}}
$normalResult=Partition $normal;$cliResult=Partition $cli
$before=Read-Receipt 'action-channel-receive-reverse-cli1-20261103.runtime.terminal-audit'
$old=@($before.failureSet|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object -Unique)
$new=@($cliResult.failureSet|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object -Unique)
$oldInventory=Read-Receipt 'action-channel-receive-reverse-cli1-20261103.catalog.inventory'
$oldSelection=@($oldInventory.rows|Where-Object status -eq matches|ForEach-Object {$_.binary+"`t"+$_.test})
$currentSelection=@($cli|ForEach-Object {$_.binary+"`t"+$_.test})
$comparison=[ordered]@{baseline=$before.run;baselineSource='9a75564dc58d4c844f2c25a45958a1d081682934';retained=@($new|Where-Object {$_ -in $old});added=@($new|Where-Object {$_ -notin $old});resolved=@($old|Where-Object {$_ -notin $new});selectedCasesAdded=@($currentSelection|Where-Object {$_ -notin $oldSelection});selectedCasesRemoved=@($oldSelection|Where-Object {$_ -notin $currentSelection});scope='Failure IDs only; the aggregate spec case is known to advance from013 to019 after its diagnostic expectations were corrected. Equal IDs do not establish equal causes.'}
$subsets=[ordered]@{}
foreach($name in @('genericMatch','view40','qualifiedAction11','referenceRegressions7')){
    $prior=Read-Receipt "entity-reference-types-$name";$missing=@()
    $observed=@(foreach($row in $prior.cases){$key=$row.binary+"`t"+$row.test;if($cases.ContainsKey($key)){$cases[$key]}else{$missing+=,$row}})
    $fail=@($observed|Where-Object status -notin @('PASS','SLOW'))
    $subsets[$name]=[ordered]@{selected=$observed.Count;passed=$observed.Count-$fail.Count;failed=$fail.Count;outsideSemaClosure=$missing;cases=$observed}
}
$newCase=@($cli|Where-Object test -eq 'verify_json_rejects_flow_yield_before_lowering_at_the_authored_statement')
if($newCase.Count -ne 1){throw 'Missing new CLI regression'}
$value=[ordered]@{version=1;source='aa96871cce4c88476230f3f90267e5d4a1d14b70';terminal=$audit;normal=$normalResult;cli=$cliResult;comparison=$comparison;subsets=$subsets;newCliYield=$newCase;freshCases=$cases.Count;reusedCases=0;sourceInputs=$audit.sourceInputs;sourceDrift=0;caseDrift=0;cases=@($cases.Values|Sort-Object package,binary,test);scope='One all22 reverse-dependency selection with a single stable all-target/all-feature/locked configuration, partitioned by the actual Cargo package in the case catalog. This does not execute Core packages outside the changed Sema reverse closure and does not reopen their prior acceptance.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{executed=$cases.Count;normal=@{executed=$normalResult.executed;passed=$normalResult.passed;failed=$normalResult.failed};cli=@{executed=$cliResult.executed;passed=$cliResult.passed;failed=$cliResult.failed};retained=$comparison.retained.Count;added=$comparison.added.Count;resolved=$comparison.resolved.Count;genericMatchPassed=$subsets.genericMatch.passed;genericMatchFailed=$subsets.genericMatch.failed}|ConvertTo-Json -Depth 6
