$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$graph = Get-Content -LiteralPath "$taskTemp/rich-text-length.graph.json" -Raw | ConvertFrom-Json
if ($graph.selectedPackages -ne 59 -or $graph.metadataTreeDrift -ne 0) { throw 'Unexpected reverse graph' }
$graphFreeze = Get-Content -LiteralPath "$taskTemp/rich-text-length-owner2-20261105.source-freeze.json" -Raw | ConvertFrom-Json
foreach ($row in @($graphFreeze.paths | Where-Object { $_.path -match '(^|/)Cargo\.(toml|lock)$' })) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Graph manifest input changed' }
}
$selection = @()
foreach ($package in $graph.selection) { $selection += @('-p', $package) }
$selection += @('--all-targets', '--all-features', '--locked')
$freeze = Get-Content -LiteralPath "$taskTemp/rich-text-length-api-owner1-20261105.source-freeze.json" -Raw | ConvertFrom-Json
& "$taskTemp/run-presentation-projection-owner.ps1" -Stem rich-text-length-reverse2-20261105 -Selection $selection -ExpectedMatches -1 -AdditionalPaths @($freeze.paths.path)
exit $LASTEXITCODE
