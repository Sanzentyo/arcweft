$ErrorActionPreference = 'Stop'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem = 'rich-text-length-reverse2-20261105'
$audit = Get-Content -LiteralPath "$taskTemp/$stem.runtime.terminal-audit.json" -Raw | ConvertFrom-Json
$catalog = Get-Content -LiteralPath "$taskTemp/$stem.catalog.inventory.json" -Raw | ConvertFrom-Json
$graph = Get-Content -LiteralPath "$taskTemp/rich-text-length.graph.json" -Raw | ConvertFrom-Json
$lines = [IO.File]::ReadAllLines("$taskTemp/$stem.runtime.log")
$summary = [Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if ($summary -lt 0) { throw 'No terminal summary' }
$region = if ($audit.caseRowSource -eq 'final-status-after-summary') { $lines[($summary+1)..($lines.Length-1)] } else { $lines[0..($summary-1)] }
$packages = @{}
foreach ($row in $catalog.rows) { if ($row.status -eq 'matches') { $packages[$row.binary+"`t"+$row.test] = $row.package } }
$cases = @(foreach ($line in $region) {
    if ($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$') {
        $key = $Matches[2]+"`t"+$Matches[3]
        if (-not $packages.ContainsKey($key)) { throw 'Unknown terminal case' }
        [ordered]@{package=$packages[$key];binary=$Matches[2];test=$Matches[3];status=$Matches[1]}
    }
})
if ($cases.Count -ne $audit.executed -or @($cases | Where-Object status -in @('FAIL','ABORT')).Count -ne $audit.failed) { throw 'Derived counts disagree with the authoritative audit' }
$cases | Export-Csv -LiteralPath "$taskTemp/$stem.final-cases.csv" -NoTypeInformation -Encoding utf8
$perPackage = @(foreach ($package in $graph.selection) {
    $rows = @($cases | Where-Object package -eq $package)
    [ordered]@{package=$package;executed=$rows.Count;passed=@($rows | Where-Object status -in @('PASS','SLOW')).Count;failed=@($rows | Where-Object status -in @('FAIL','ABORT')).Count;runtime=($rows.Count -gt 0)}
})
$cli = @($cases | Where-Object package -eq 'arcweft-cli')
$nonCli = @($cases | Where-Object package -ne 'arcweft-cli')
$derived = [ordered]@{version=1;base=$audit.base;source='authoritative terminal audit and matching final-status case rows';executed=$audit.executed;passed=$audit.passed;failed=$audit.failed;skipped=$audit.skipped;caseDrift=0;cli=[ordered]@{executed=$cli.Count;passed=@($cli | Where-Object status -in @('PASS','SLOW')).Count;failed=@($cli | Where-Object status -in @('FAIL','ABORT')).Count};nonCli=[ordered]@{executed=$nonCli.Count;passed=@($nonCli | Where-Object status -in @('PASS','SLOW')).Count;failed=@($nonCli | Where-Object status -in @('FAIL','ABORT')).Count};packages=$perPackage}
$derived | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/$stem.package-audit.json" -Encoding utf8
[ordered]@{executed=$derived.executed;passed=$derived.passed;failed=$derived.failed;cli=$derived.cli;nonCli=$derived.nonCli;caseDrift=0} | ConvertTo-Json -Depth 5 -Compress
