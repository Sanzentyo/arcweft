$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$stem = 'rich-text-length-reverse-context1-20261105'
if (Test-Path -LiteralPath "$taskTemp/$stem.json") { throw 'Preserve existing diagnostic attempt' }
$freeze = Get-Content -LiteralPath "$taskTemp/rich-text-length-reverse1-20261105.source-freeze.json" -Raw | ConvertFrom-Json
function Assert-Inputs { foreach ($row in $freeze.paths) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Frozen input changed' } } }
Assert-Inputs
$graph = Get-Content -LiteralPath "$taskTemp/rich-text-length.graph.json" -Raw | ConvertFrom-Json
$arguments = @('check')
foreach ($package in $graph.selection) { $arguments += @('-p', $package) }
$arguments += @('--all-targets', '--all-features', '--locked')
$started = [DateTime]::UtcNow.ToString('o')
& cargo @arguments *> "$taskTemp/$stem.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ version = 1; base = (git rev-parse HEAD).Trim(); command = $arguments; exitCode = $code; sourceInputs = $freeze.paths.Count; sourceDrift = 0; startedAt = $started; finishedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$taskTemp/$stem.json" -Encoding utf8
Write-Output "$stem exit=$code"
exit $code
