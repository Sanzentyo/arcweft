param([Parameter(Mandatory)][string]$Stem,[int]$Top=16)
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stream = [IO.File]::Open("$taskTemp/$Stem.runtime.log", [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
$reader = [IO.StreamReader]::new($stream)
$rows = [Collections.Generic.List[object]]::new()
$current = $null
$afterPanic = $false
try {
    while (($line = $reader.ReadLine()) -ne $null) {
        if ($line -match '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$') {
            if ($current) { $rows.Add($current); if ($rows.Count -ge $Top) { break } }
            $current = $null; $afterPanic = $false
            if ($Matches[1] -in @('FAIL','ABORT')) { $current = [ordered]@{status=$Matches[1];binary=$Matches[2];test=$Matches[3];diagnostics=[Collections.Generic.List[string]]::new()} }
        } elseif ($current) {
            if ($line -match 'panicked at|^\s*(assertion|left:|right:)' -or $afterPanic) {
                if ($current.diagnostics.Count -lt 6) { $current.diagnostics.Add($(if ($line.Length -gt 450) {$line.Substring(0,450)+' [truncated]'} else {$line})) }
                $afterPanic = $line -match 'panicked at'
            }
        }
    }
    if ($current -and $rows.Count -lt $Top) { $rows.Add($current) }
} finally { $reader.Dispose(); $stream.Dispose() }
$rows | ConvertTo-Json -Depth 6
