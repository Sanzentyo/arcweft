$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-20261110/text-submit-flow'
function Get-ArcSha($path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
$caseReceipt=Get-Content -LiteralPath (Join-Path $d 'web.font-chain.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$nativeReceipt=Get-Content -LiteralPath (Join-Path $d 'native.matched.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
if($caseReceipt.failures.Count -or $caseReceipt.results.Count -ne 6 -or $nativeReceipt.results.Count -ne 6 -or $caseReceipt.bundleSha256 -ne $nativeReceipt.bundleSha256){throw 'Invalid capture receipts'}
$result=@(foreach($case in $caseReceipt.results) {
    $nativeCase=@($nativeReceipt.results|Where-Object {$_.name -eq $case.name})
    if($nativeCase.Count -ne 1 -or $nativeCase[0].exitCode -or $nativeCase[0].status.status -cne ('done return '+$case.text)){throw "native case failed $($case.name)"}
    $steps=@('waiting','submitted','branch','completed')
    if($case.text){$steps=@('waiting','typed','submitted','branch','completed')}
    if(Compare-Object $steps $case.checkpoints.name -SyncWindow 0){throw "web checkpoint drift $($case.name)"}
    foreach($step in $steps) {
        $native=Join-Path $d "native-matched-$($case.name)/native-operation-$step"
        $web=Join-Path $d "web-$($case.name)-$step"
        $n=Get-Content -LiteralPath "$native.json" -Raw | ConvertFrom-Json -AsHashtable
        $w=Get-Content -LiteralPath "$web.json" -Raw | ConvertFrom-Json -AsHashtable
        $metrics=(& imq image "$native.png" "$web.png" --metrics 'mse:all,mae:all,maxae:all' --format json) -join [Environment]::NewLine
        if($LASTEXITCODE){throw "imq failed for $($case.name) $step"}
        $report=$metrics|ConvertFrom-Json -AsHashtable
        if($report.dimensions.width -ne 1280 -or $report.dimensions.height -ne 720 -or $report.reference_format.pixel_format -ne 'Rgba8' -or $report.distorted_format.pixel_format -ne 'Rgba8' -or $report.metrics.Count -ne 3 -or @($report.metrics|Where-Object {$_.details.samples -ne 3686400}).Count){throw "unexpected imq coverage $($case.name) $step"}
        $nativeSha=Get-ArcSha "$native.png"
        $webSha=Get-ArcSha "$web.png"
        $wc=$case.checkpoints|Where-Object {$_.name -eq $step}
        if ($wc.pngSha256 -ne $webSha -or $wc.tick -ne $w.runtime.logical_tick){throw "web observation drift $($case.name) $step"}
        $sameFrame=($n.frame|ConvertTo-Json -Depth 35 -Compress) -ceq ($w.frame|ConvertTo-Json -Depth 35 -Compress)
        [ordered]@{case=$case.name;checkpoint=$step;nativeTick=$n.tick;webTick=$w.runtime.logical_tick;nativePngSha256=$nativeSha;webPngSha256=$webSha;nativeObservationSha256=Get-ArcSha "$native.json";webObservationSha256=Get-ArcSha "$web.json";frameObservationEqual=$sameFrame;metrics=$report.metrics}
    }
})
$divergences=@($result|Where-Object {$_.nativeTick -ne $_.webTick -or !$_.frameObservationEqual -or @($_.metrics|Where-Object {$_.score -ne 0}).Count})
$receipt=[ordered]@{version=1;tool=((imq --version)-join ' ');bundleSha256=$caseReceipt.bundleSha256;width=1280;height=720;channels=4;sampleCount=3686400;metrics=@('mse:all','mae:all','maxae:all');pairs=$result}
$receipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'native-web-matched-parity.receipt.json') -Encoding utf8
"pairs=$($result.Count) divergences=$($divergences.Count)"
$divergences|ForEach-Object { [pscustomobject]@{case=$_.case;step=$_.checkpoint;native=$_.nativeTick;web=$_.webTick;observation=$_.frameObservationEqual;mse=$_.metrics[0].score;mae=$_.metrics[1].score;maxae=$_.metrics[2].score} }|Format-Table -AutoSize
if($result.Count -ne 29 -or $divergences.Count){exit 1}
