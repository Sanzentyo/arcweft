import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { createRequire } from "node:module";
import { dirname, extname, join, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const output = resolve(process.argv[2] ?? dirname(fileURLToPath(import.meta.url)));
const root = resolve("web");
const { chromium } = createRequire(join(root, "package.json"))("playwright");
const { installManualLogicalClock, advanceLogicalClockSteps } = await import(
  pathToFileURL(join(root, "tests", "manual-logical-clock.mjs")).href
);
const wasm = join(root, "pkg", "arcweft_player_web_bg.wasm");
const bundle = await readFile(join(output, "text-submit-flow.awfb"));
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const wasmHash = sha(await readFile(wasm));
const contentTypes = new Map([
  [".html", "text/html"], [".js", "application/javascript"], [".css", "text/css"],
  [".wasm", "application/wasm"], [".ttf", "font/ttf"], [".png", "image/png"],
]);
const server = createServer(async (request, response) => {
  const path = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
  if (path === "/favicon.ico") {
    response.writeHead(204).end();
    return;
  }
  if (path === "/text-submit-flow.awfb") {
    response.writeHead(200, { "content-type": "application/octet-stream" }).end(bundle);
    return;
  }
  const file = resolve(root, "." + path);
  if (!file.startsWith(root + sep)) {
    response.writeHead(400).end();
    return;
  }
  try {
    const bytes = await readFile(file);
    response.writeHead(200, { "content-type": contentTypes.get(extname(file)) }).end(bytes);
  } catch {
    response.writeHead(404).end();
  }
});
await new Promise((done) => server.listen(0, "127.0.0.1", done));
const browser = await chromium.launch({
  channel: process.env.ARW_PLAYWRIGHT_CHANNEL || "chrome",
  headless: true,
  args: ["--enable-unsafe-webgpu", "--use-angle=d3d11"],
});
const cases = [
  { name: "empty-click", text: "", submit: "click" },
  { name: "short-enter", text: "e\u0301", submit: "enter" },
  { name: "long-ascii-click", text: "Arcweft", submit: "click" },
  { name: "long-japanese-click", text: "あいうえお", submit: "click" },
  { name: "non-bmp-click", text: "A😀B", submit: "click" },
  { name: "long-click", text: "A👩‍💻B", submit: "click" },
];
const results = [];
const failures = [];
const url = new URL("http://127.0.0.1:" + server.address().port + "/index.html");
url.searchParams.set("bundle", "./text-submit-flow.awfb");
url.searchParams.set("fonts", "./assets/arcweft-demo.ttf,./assets/noto-sans-jp-vf.ttf,./assets/noto-emoji-regular.ttf");
url.searchParams.set("entry", "entry.text_submit_flow");

function rows(state) {
  return (state.frame?.text ?? []).map(({text, visible_text, owner}) => ({
    text, visible_text, id: owner?.semantic_id, bounds: owner?.object_bounds,
  }));
}
try {
  for (const testCase of cases) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
    const errors = [];
    const checkpoints = [];
    const changes = [];
    page.on("pageerror", error => errors.push(error.message));
    page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
    page.on("response", response => {
      if (response.status() >= 400) errors.push(response.status() + " " + response.url());
    });
    const canvas = page.locator("#arcweft-canvas");
    const snapshot = () => page.evaluate(() => ({
      runtime: window.__arcweftLastObservation,
      frame: window.__arcweftLastFrameObservation,
      fatal: window.__arcweftFatal,
    }));
    const advance = async () => changes.push(await advanceLogicalClockSteps(page, 4));
    const enter = async () => { await page.keyboard.press("Enter"); await advance(); };
    const click = async (predicate, role) => {
      const inventory = rows(await snapshot());
      const row = inventory.find(predicate);
      assert(row?.bounds, "missing " + role + ": " + JSON.stringify(inventory));
      const bounds = await canvas.boundingBox();
      await page.mouse.click(bounds.x + (row.bounds.x_milli + row.bounds.width_milli / 2) / 1000,
                             bounds.y + (row.bounds.y_milli + row.bounds.height_milli / 2) / 1000);
      await advance();
      return row;
    };
    const capture = async name => {
      const state = await snapshot();
      assert(!state.fatal, JSON.stringify(state.fatal));
      const prefix = "web-" + testCase.name + "-" + name;
      const png = await canvas.screenshot({ path: join(output, prefix + ".png") });
      await writeFile(join(output, prefix + ".json"), JSON.stringify(state));
      checkpoints.push({ name, tick: state.runtime.logical_tick, pngSha256: sha(png), rows: rows(state) });
    };
    const reach = async (predicate, name) => {
      for (let i = 0; i <= 12; i++) {
        const state = await snapshot();
        assert(!state.fatal, JSON.stringify(state.fatal));
        if (predicate(state)) return state;
        if (i === 12 || !state.runtime?.dialogue) assert.fail("cannot reach " + name + ": " + JSON.stringify(rows(state)));
        await enter();
      }
    };
    try {
      await installManualLogicalClock(page);
      await page.goto(url.href);
      await page.waitForFunction(() => Boolean(window.__arcweftFatal) ||
        Boolean(window.__arcweftLastFrameObservation?.text?.length), null, { timeout: 10_000 });
      await canvas.focus();
      assert.equal(await page.locator("input, textarea, [contenteditable], button").count(), 0);
      await reach(state => state.runtime?.status?.startsWith("need_waiting "), "Action receive wait");
      await capture("waiting");
      if (testCase.text) {
        await click(row => row.text.includes("Type text, then press Enter or click Send"), "feedback input");
        await page.keyboard.insertText(testCase.text);
        await advance();
        assert(rows(await snapshot()).some(row => row.text.includes(testCase.text)), "input not rendered exactly");
        await capture("typed");
      }
      if (testCase.submit === "enter") await enter();
      else await click(row => row.text === "Send", "Send button");
      const response = testCase.text ? "Submitted " : "Nothing was submitted";
      const responseState = await reach(state => rows(state).some(row => row.text.includes(response)), response);
      if (testCase.text) assert(rows(responseState).some(row => row.text.includes(testCase.text)));
      await capture("submitted");
      const canvasBounds = await canvas.boundingBox();
      await page.mouse.click(canvasBounds.x + 900, canvasBounds.y + 300);
      await advance();
      const count = [...testCase.text].length;
      const branch = count < 5 ? "The submitted text is short" : "so it takes the longer branch";
      const branchState = await reach(state => rows(state).some(row => row.text.includes(branch)), branch);
      assert(rows(branchState).some(row => row.text.includes(String(count) + " Unicode scalar")));
      await capture("branch");
      await reach(state => state.runtime?.finished, "Flow completion");
      await capture("completed");
      assert.deepEqual(errors, []);
      const end = await snapshot();
      results.push({ ...testCase, count, checkpoints, changes, runtime: end.runtime });
    } catch (error) {
      await writeFile(join(output, "web-" + testCase.name + "-failure.json"),
                      JSON.stringify({ error: error.message, state: await snapshot(), checkpoints, errors }));
      failures.push({ name: testCase.name, text: testCase.text, scalars: [...testCase.text].map(value => value.codePointAt(0)), error: error.message });
    } finally {
      await page.close();
    }
  }
  assert.equal(sha(await readFile(wasm)), wasmHash);
  console.log(JSON.stringify({ version: 1, bundleSha256: sha(bundle), wasmSha256: wasmHash, results, failures }));
  if (failures.length) process.exitCode = 1;
} finally {
  await browser.close();
  await new Promise(done => server.close(done));
}

