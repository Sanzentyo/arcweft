use arcweft_layout::ScalePolicy;
use arcweft_player_scene::{
    frame::{PlayerFrameFit, PlayerFramePlannerState, PlayerFrameRequest, PlayerFrameTime},
    images::BundleImageCatalog,
    input::{DialogueProgress, InputController, InputOutcome, InputPointerModifiers},
};
use arcweft_player_web::report::WebFrameObservationReport;
use arcweft_presentation::{
    input::{KeyPhase, PointerId, ViewportPoint},
    text_input::{TextInput, TextInputSerial},
};
use arcweft_render_wgpu::{
    geometry::{PreparedFrame, RenderPreferences, RenderViewport},
    offscreen::{CaptureAttachment, CaptureRequest, SharedOffscreenCapture},
};
use arcweft_runtime_driver::{
    clock::RuntimeClockStep,
    session::{BundleSession, BundleSessionOptions, BundleStepInput},
};
use png::{BitDepth, ColorType, Encoder};
use serde_json::json;
use std::{env, error::Error, fs, path::{Path, PathBuf}};

struct Probe {
    session: BundleSession,
    images: BundleImageCatalog,
    input: InputController,
    planner: PlayerFramePlannerState,
    capture: SharedOffscreenCapture,
    output: PathBuf,
    tick: u64,
    serial: u64,
    status: String,
    finished: bool,
}
impl Probe {
    fn advance(&mut self, steps: u64) -> Result<(), Box<dyn Error>> {
        for _ in 0..steps {
            self.tick += 1;
            eprintln!("step {}", self.tick);
            let clock = RuntimeClockStep::from_millis(self.tick, 16)?;
            let step = self.session.step_with_clock(clock, BundleStepInput::default());
            assert!(step.diagnostics.is_empty(), "{:?}", step.diagnostics);
            self.status = step.status_label;
            self.finished = step.finished;
        }
        Ok(())
    }
    fn frame(&mut self) -> Result<PreparedFrame, Box<dyn Error>> {
        eprintln!("prepare {}", self.tick);
        let viewport = RenderViewport {
            logical_width: 1280.0, logical_height: 720.0,
            physical_width: 1280, physical_height: 720, scale_factor: 1.0,
        };
        prepare_frame(&self.session, &self.images, &mut self.planner, &mut self.input, viewport, self.tick * 16)
    }
    fn report(&mut self) -> Result<WebFrameObservationReport, Box<dyn Error>> {
        Ok(WebFrameObservationReport::from_prepared_frame(&self.frame()?)?)
    }
    fn apply(&mut self, outcome: InputOutcome) -> Result<(), Box<dyn Error>> {
        assert!(outcome.diagnostics.is_empty(), "{:?}", outcome.diagnostics);
        assert!(outcome.clipboard_requests.is_empty());
        match outcome.dialogue_progress {
            DialogueProgress::None => (),
            DialogueProgress::Reveal { target } => self.session.queue_dialogue_reveal_completion(target),
            DialogueProgress::Advance { target } => self.session.queue_dialogue_advance(target),
        }
        for input_action in outcome.dialogue_input_actions {
            self.session.queue_dialogue_input_action(input_action.observed, input_action.action)?;
        }
        for action in outcome.actions {
            self.session.queue_semantic_action(&action)?;
        }
        for invocation in outcome.view_handler_invocations {
            self.session.queue_view_handler_invocation(&invocation)?;
        }
        self.session.queue_text_control_write_backs(outcome.text_control_write_backs)?;
        Ok(())
    }
    fn enter(&mut self) -> Result<(), Box<dyn Error>> {
        let frame = self.frame()?;
        let down = self.input.keyboard(&frame, "Enter", KeyPhase::Down);
        let up = self.input.keyboard(&frame, "Enter", KeyPhase::Up);
        self.apply(down)?;
        self.apply(up)?;
        self.advance(4)
    }
    fn reach(&mut self, text: &str) -> Result<(), Box<dyn Error>> {
        for _ in 0..=8 {
            if self.report()?.text.iter().any(|item| item.text.contains(text)) {
                return Ok(());
            }
            if self.session.presentation().dialogue.latest_active().is_none() {
                break;
            }
            self.enter()?;
        }
        let report = self.report()?;
        let actual: Vec<_> = report.text.iter().map(|item| &item.text).collect();
        Err(format!("cannot reach {text:?} at tick {}. Text {actual:?}", self.tick).into())
    }
    fn click(&mut self, text: &str) -> Result<(), Box<dyn Error>> {
        let frame = self.frame()?;
        let report = WebFrameObservationReport::from_prepared_frame(&frame)?;
        let bounds = report.text.iter().find(|item| item.text == text)
            .and_then(|item| item.owner.as_ref()).map(|owner| owner.object_bounds)
            .ok_or_else(|| format!("no rendered target {text:?}"))?;
        assert!(bounds.width_milli > 0 && bounds.height_milli > 0);
        let point = ViewportPoint::new(
            (bounds.x_milli as f32 + bounds.width_milli as f32 / 2.0) / 1000.0,
            (bounds.y_milli as f32 + bounds.height_milli as f32 / 2.0) / 1000.0,
        );
        self.click_point(point)
    }
    fn click_point(&mut self, point: ViewportPoint) -> Result<(), Box<dyn Error>> {
        let frame = self.frame()?;
        let down = self.input.pointer_down(&frame, PointerId(1), point, InputPointerModifiers::NONE);
        let up = self.input.pointer_up(&frame, PointerId(1), point, InputPointerModifiers::NONE);
        self.apply(down)?;
        self.apply(up)?;
        self.advance(4)
    }
    fn type_text(&mut self, text: &str) -> Result<(), Box<dyn Error>> {
        let frame = self.frame()?;
        let session = self.input.focused_text_editor().ok_or("no focused editor")?.session();
        for character in text.chars() {
            self.serial += 1;
            let input = TextInput::committed(session, TextInputSerial(self.serial), &character.to_string());
            let outcome = self.input.text_input(&frame, input)?;
            self.apply(outcome)?;
        }
        self.advance(4)?;
        assert!(self.report()?.text.iter().any(|item| item.text.contains(text)), "input not rendered: {text:?}");
        Ok(())
    }
    fn checkpoint(&mut self, name: &str) -> Result<(), Box<dyn Error>> {
        let frame = self.frame()?;
        let report = WebFrameObservationReport::from_prepared_frame(&frame)?;
        assert_eq!(report.image_count, 0);
        let image = self.capture.capture(&frame, &CaptureRequest::whole_frame_color())?;
        let rgba = image.attachment_rgba(CaptureAttachment::Color).ok_or("missing color attachment")?;
        write_png(&self.output.join(format!("native-operation-{name}.png")), image.width, image.height, rgba)?;
        let evidence = json!({"tick": self.tick, "frame": report});
        fs::write(self.output.join(format!("native-operation-{name}.json")), serde_json::to_vec(&evidence)?)?;
        println!("{name} tick {}", self.tick);
        Ok(())
    }
}
fn main() -> Result<(), Box<dyn Error>> {
    let output = PathBuf::from(env::args_os().nth(1).ok_or("output dir required")?);
    let bundle = PathBuf::from(env::args_os().nth(2).ok_or("bundle path required")?);
    let text = env::args().nth(3).ok_or("text required")?;
    let text = text.as_str();
    let submit_enter = env::args().nth(4).as_deref() == Some("enter");
    let bytes = fs::read(bundle)?;
    let (session, artifact) = BundleSession::from_awfb_bytes_with_bundle(&bytes, BundleSessionOptions { entry: Some(arcweft_core::plan::EntryRuntimeId::from_source_entity_body("entry.text_submit_flow")?), ..BundleSessionOptions::default() })?;
    let images = BundleImageCatalog::from_bundle(artifact.bundle())?;
    let font = fs::read("web/assets/arcweft-demo.ttf")?;
    let mut planner = PlayerFramePlannerState::new();
    planner.register_font_bytes(font.clone())?;
    let mut capture = pollster::block_on(SharedOffscreenCapture::new(wgpu::TextureFormat::Rgba8Unorm))?;
    capture.register_font_bytes(font)?;
    for path in ["web/assets/noto-sans-jp-vf.ttf", "web/assets/noto-emoji-regular.ttf"] {
        let font = fs::read(path)?;
        planner.register_font_bytes(font.clone())?;
        capture.register_font_bytes(font)?;
    }
    let mut probe = Probe {
        session, images, input: InputController::default(), planner, capture, output, tick: 0, serial: 0, status: String::new(), finished: false,
    };
    probe.advance(1)?;
    for _ in 0..=12 {
        if probe.status.starts_with("need_waiting ") { break; }
        probe.enter()?;
    }
    assert!(probe.status.starts_with("need_waiting "), "{}", probe.status);
    probe.checkpoint("waiting")?;
    if !text.is_empty() {
        probe.click("Type text, then press Enter or click Send")?;
        let frame = probe.frame()?;
        let session = probe.input.focused_text_editor().ok_or("no focused editor")?.session();
        probe.serial += 1;
        let outcome = probe.input.text_input(&frame, TextInput::committed(session, TextInputSerial(probe.serial), text))?;
        probe.apply(outcome)?;
        probe.advance(4)?;
        assert!(probe.report()?.text.iter().any(|item| item.text.contains(text)), "input did not render: {text:?}");
        probe.checkpoint("typed")?;
    }
    if submit_enter { probe.enter()?; } else { probe.click("Send")?; }
    let response = if text.is_empty() { "Nothing was submitted" } else { "Submitted " };
    probe.reach(response)?;
    if !text.is_empty() {
        assert!(probe.report()?.text.iter().any(|item| item.text.contains(text)));
    }
    probe.checkpoint("submitted")?;
    probe.click_point(ViewportPoint::new(900.0, 300.0))?;
    let count = text.chars().count();
    probe.reach(if count < 5 { "The submitted text is short" } else { "so it takes the longer branch" })?;
    assert!(probe.report()?.text.iter().any(|item| item.text.contains(&format!("{count} Unicode scalar"))));
    probe.checkpoint("branch")?;
    for _ in 0..=12 {
        if probe.finished { break; }
        probe.enter()?;
    }
    assert!(probe.finished, "{}", probe.status);
    assert_eq!(probe.status, format!("done return {text}"));
    probe.checkpoint("completed")?;
    println!("{}", json!({"status": probe.status, "tick": probe.tick, "count": count}));

    Ok(())
}
fn prepare_frame(
    session: &BundleSession,
    images: &BundleImageCatalog,
    planner: &mut PlayerFramePlannerState,
    input: &mut InputController,
    viewport: RenderViewport,
    clock_millis: u64,
) -> Result<PreparedFrame, Box<dyn Error>> {
    let style_environment = session.presentation_environment();
    let candidate = planner.prepare_candidate(
        input,
        PlayerFrameRequest {
            presentation: session.presentation(),
            style_program: session.view_style_program(),
            style_environment: &style_environment,
            style_palettes: session.view_style_palettes(),
            fx_definitions: session.fx_definitions(),
            images,
            viewport,
            fit: PlayerFrameFit::design_1280x720(ScalePolicy::Contain),
            time: PlayerFrameTime::runtime(clock_millis),
            preferences: RenderPreferences::default(),
        },
    )?;
    let (prepared, ()) = planner
        .publication_guard()
        .publish_with(candidate, input, |_| ())?;
    Ok(prepared.frame)
}

fn write_png(path: &Path, width: u32, height: u32, rgba: &[u8]) -> Result<(), Box<dyn Error>> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let file = fs::File::create(path)?;
    let mut encoder = Encoder::new(file, width, height);
    encoder.set_color(ColorType::Rgba);
    encoder.set_depth(BitDepth::Eight);
    encoder.write_header()?.write_image_data(rgba)?;
    Ok(())
}
