$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$publication=Read-Receipt 'declared-callable-group-repair.verified'
$intermediate=Read-Receipt 'declared-callable-group-source.verified'
$sha=$publication.commit
if((git rev-parse HEAD).Trim() -ne $sha -or (git branch --show-current).Trim() -ne 'main'){throw 'Unexpected published source or branch'}
$terminal=Read-Receipt 'declared-callable-group-reverse1-20261104.runtime.terminal-audit'
$owner=Read-Receipt 'declared-callable-group-owner7-20261104.runtime.terminal-audit'
$comparison=Read-Receipt 'declared-callable-group-result-comparison'
$followup=Read-Receipt 'declared-callable-group-cli-followup1-20261104.runtime.terminal-audit'
$probe=Read-Receipt 'declared-callable-group-source-probe-comparison'
$factory=Read-Receipt 'declared-callable-group-factory2-probes'
$graph=Read-Receipt 'declared-callable-group.graph'
$format=Read-Receipt 'declared-callable-group-final-format'
if($terminal.executed -ne 7808 -or $terminal.passed -ne 7793 -or $terminal.failed -ne 15 -or $terminal.skipped -ne 40 -or $terminal.actualExitCode -ne 100 -or $terminal.sourceDrift -ne 0 -or $terminal.catalogCaseDrift -ne 0){throw 'Full-run evidence differs'}
if($owner.executed -ne 52 -or $owner.passed -ne 52 -or $owner.failed -ne 0 -or $owner.sourceDrift -ne 0){throw 'Final owner evidence differs'}
if($comparison.normal.executed -ne 7110 -or $comparison.normal.failed -ne 0 -or $comparison.cli.failed -ne 15){throw 'Package counts differ'}
$extra='arcweft-cli'+"`t"+'app::agent::mcp_stdio::tests::stdio_transport_times_out_and_retains_bounded_stderr_tail'
if($comparison.addedFailedIds.Count -ne 1 -or $comparison.addedFailedIds[0] -ne $extra -or $comparison.removedFailedIds.Count -ne 0){throw 'Investigate other changed failed IDs'}
if($followup.executed -ne 1 -or $followup.passed -ne 1 -or $followup.failed -ne 0 -or $followup.sourceDrift -ne 0){throw 'Isolated follow-up differs'}
$fullBins=Read-Receipt 'declared-callable-group-reverse1-20261104.binaries-before'
$followupBins=Read-Receipt 'declared-callable-group-cli-followup1-20261104.binaries-before'
if(($fullBins|ConvertTo-Json -Depth 10 -Compress) -ne ($followupBins|ConvertTo-Json -Depth 10 -Compress)){throw 'Follow-up executable set differs'}
if($probe.direct.exitCode -ne 0 -or $probe.alias.exitCode -ne 0 -or $probe.executableDrift -ne 0 -or $probe.sourceInputDrift -ne 0){throw 'Source probe differs'}
if($factory.rows.Count -ne 3 -or @($factory.rows|Where-Object {$_.exitCode -ne 1 -or $_.report.stage -ne 'type-check' -or $_.report.diagnostics[0].diagnostic.code -ne 'sema.call.unknown_target'}).Count){throw 'Factory registration evidence differs'}
if($graph.workspacePackages -ne 98 -or $graph.selectedPackages -ne 53 -or $graph.metadataTreeDrift -ne 0 -or $format.exitCode -ne 0){throw 'Graph or format gate differs'}
$expectedCoverage=[ordered]@{declaredGroupOwner=52;externalBindingProjection=25;retainedOptionalBoundary=67;generic=151;propertyIdentity=9;dynamicDisplay=5;codegenProjectCalls=2}
foreach($key in $expectedCoverage.Keys){$cases=@($comparison.coverage[$key]);if($cases.Count -ne $expectedCoverage[$key] -or @($cases|Where-Object status -ne PASS).Count){throw "Coverage differs: $key"}}
$freeze=Read-Receipt 'declared-callable-group-reverse1-20261104.source-freeze'
if($freeze.paths.Count -ne 4102){throw 'Source inventory differs'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift before documentation: $($row.path)"}}
$quality=@(foreach($gate in @('check','clippy','structure')){
    $name="declared-callable-group-quality2-20261104-$gate"
    $r=Read-Receipt $name
    if($r.exitCode -ne 0 -or $r.sourceDrift -ne 0 -or $r.sourceInputs -ne 4102){throw "Quality gate differs: $gate"}
    [ordered]@{gate=$gate;receipt="$name.json";result=$r}
})
$originalUntracked=Read-Receipt 'task-documentation-final-untracked-before'
foreach($row in $originalUntracked.files){if(-not(Test-Path -LiteralPath $row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$beforeRecord=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($beforeRecord.Contains('declaredApplications')){throw 'Preserve existing declared application evidence'}
$beforeRows=@([IO.File]::ReadAllLines((Join-Path $PWD $statusPath))|Where-Object {
    $_.StartsWith('| RichTextの部分layout指定／source factory |') -or $_.StartsWith('| Generic Match ') -or $_.StartsWith('| 共有契約／推移的逆依存matrix |') -or $_.StartsWith('| CLI全target照合 |') -or $_.StartsWith('| workspace check／Clippy・fmt・構造gate |')
})
if($beforeRows.Count -ne 5){throw 'Canonical status rows missing or duplicated'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
[ordered]@{version=1;source=$sha;supersededCurrentRows=$beforeRows;historyPrefix=$historyPrefix;reason='Fresh end-to-end evidence closes the Source optional alias gap. Preserve every prior acceptance and result; factory registration and composition remain distinct.'}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$e/declared-callable-group-status-before.json" -Encoding utf8
$triage=Read-Receipt 'declared-callable-group-cli-added-failure-triage'
$triage.status='Full run FAIL; isolated same-source/same-feature/same-binary follow-up PASS. Preserve both results; root cause remains undetermined.'
$triage.followup=[ordered]@{receipt='declared-callable-group-cli-followup1-20261104.runtime.terminal-audit.json';executed=1;passed=1;failed=0;binarySetCount=$fullBins.Count;binaryDrift=0;budgetsOrDeadlinesChanged=$false}
$triage.causeClaim='The module blob is unchanged. Reproduction varies between the complete run and isolated follow-up. Load sensitivity is a hypothesis, not an established cause; no causal attribution is made from unchanged source or passing retry alone.'
$triage|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$e/declared-callable-group-cli-added-failure-triage.json" -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object {$_.Name -like 'declared-callable-group*' -or $_.Name -in @('audit-declared-callable-group-tests.ps1','probe-declared-callable-group-source.ps1','record-declared-callable-group-evidence.ps1')})
foreach($name in @('declared-callable-group-quality1-20261104.structure-report','declared-callable-group-quality2-20261104.structure-report')){$files+=@(Get-ChildItem -LiteralPath "$e/$name" -File -Recurse)}
foreach($name in @('run-presentation-projection-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1','optional-external-direct-probe.arcw','optional-external-alias-probe.arcw','optional-bindings-source-probe-comparison.json','optional-external-wrapper-build1.log','task-documentation-final-untracked-before.json')){$files+=Get-Item -LiteralPath "$e/$name"}
$root=[IO.Path]::GetFullPath($e)
$index=@(foreach($file in @($files|Sort-Object FullName -Unique)){[ordered]@{entry=$file.FullName.Substring($root.Length+1).Replace([IO.Path]::DirectorySeparatorChar,[char]'/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$index|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$e/declared-callable-group-archive-inputs.json" -Encoding utf8
$files+=Get-Item -LiteralPath "$e/declared-callable-group-archive-inputs.json"
. "$e/write-verified-evidence-archive.ps1"
$archive='docs/implementation/acceptance-evidence/task-rich-text-declared-applications.raw.zip'
$raw=Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record=$beforeRecord
$record.declaredApplications=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$sha
    source=$publication;intermediateSource=$intermediate
    prerequisiteSource='0f0f99ca13b1762b9dd393d565a8ef4a54cd5d36'
    state='Published Source external optional/defaulted direct and alias application boundary. Full CLI acceptance remains incomplete; RichText factories remain separate open conditions.'
    workingTree=[ordered]@{heldTracked=$freeze.held;heldTrackedCount=12;heldPatchSha256=$publication.heldPatchSha256;heldUntracked=$originalUntracked.files;heldUntrackedCount=6;sourceInputs=4102;sourceDrift=0;claim='Validation used this observed checkout including held WIP, not pristine HEAD. Source receipts pin the actual 4102 inputs. Original unrelated WIP was neither staged nor changed.'}
    implementation=@(
        'RuntimeCallableGroupBinding::{Materialized,Declared} is the single typed application mode across PlanSeed/Plan, strict Source graph and AWBC version-one wire. Materialized uses complete bindings; Declared supplies raw ABI values at original formal coordinates and derives Optional None/Some and empty Rest on the actual same-origin/current-group callable.'
        'Borrowed admission validates all original input values and coordinates before owned movement. Raw ABI T and body binding Option<T> remain distinct; no fake Fn<Option<T>>, payload clone, fallback resolver or compatibility reader is introduced.'
        'Sema issues the checked external application projection from the actual selected checked application and immutable catalog identity. Compiler and RuntimePlan preserve the complete canonical declaration function digest, original external definition, callable groups and ordinary provider boundary.'
        'Declared ProjectCall admission resolves remaining formal coordinates only after the final callable state graph is sealed, including pending raw-prefix states. AWBC copy proof joins actual same-family/group retained projections under the shared existing proof budget.'
        'Native and decoded AWBC use the same declared materialization. Existing required-argument aliases, effectful restoration and runtime-codegen ProjectCall consumers are migrated and checked. All touched Arcweft-owned contract versions remain 1.'
    )
    validation=[ordered]@{
        owner=$owner;fullReverse=$terminal;caseResults='declared-callable-group-reverse1-20261104.runtime.cases.json'
        graph=$graph;normal=$comparison.normal;cli=$comparison.cli
        coverage=[ordered]@{counts=$expectedCoverage;receipt='declared-callable-group-result-comparison.json';allSelectedCasesPassed=$true}
        immediatePriorFailureComparison=[ordered]@{priorSource=$comparison.priorSource;priorFailedIds=$comparison.priorFailedIds;currentFailedIds=$comparison.currentFailedIds;addedFailedIds=$comparison.addedFailedIds;removedFailedIds=$comparison.removedFailedIds;causeClaim=$comparison.causeClaim}
        isolatedCliFollowup=[ordered]@{result=$followup;triage=$triage;binarySetCount=$fullBins.Count;binaryDrift=0;fullRunFailureRemains=$true}
        standardSourceProbe=$probe
        quality=$quality;format=$format
        sourceValidationRelation='Owner7/quality2 ran with base a96351849f218a5f8212c08c2cad5cf9331a2ca5 plus the final repaired source that was published as 2aaa0480b171d15274737d7bd49a3c391ce19096. The later complete reverse run, probes and documentation preflight pin those final 4102 inputs without drift.'
        limits='Windows MSVC host; all-targets does not establish every operating system or wasm acceptance. Doctest and wasm-specific checks were not rerun. Existing non-blocking warnings remain. No changed jobs, profiles, features, execution budgets, child deadlines or OS configuration.'
    }
    attempts=@(
        [ordered]@{run='declared-callable-group-build2';stage='compile';reason='Wrong Sema candidate/catalog accessor assumptions; corrected to selected().checked() and signature().'}
        [ordered]@{run='declared-callable-group-owner1-20261104';stage='catalog-compile';reason='Wrong checked accessor and invented AWBC fixture APIs; corrected to existing verification, codec and entry constructors; no runtime result claimed.'}
        [ordered]@{run='declared-callable-group-owner2-20261104';stage='catalog-compile';reason='Compiler fixture inspected private backend storage; corrected to an external atomic call counter; no runtime result claimed.'}
        [ordered]@{run='declared-callable-group-owner3-20261104';stage='catalog-interrupted';reason='Disk exhaustion; exact task-owned Cargo/rustc processes were identified and stopped. Catalog exit -1 is retained, with no runtime execution claimed.'}
        [ordered]@{run='declared-callable-group-owner4-20261104';executed=51;passed=49;failed=2;reason='Existing required/group/effectful alias fixtures exposed conservative Declared result CopyValue proof. Repaired the shared typed proof and final sealed-graph admission; retained original failed logs.'}
        [ordered]@{run='declared-callable-group-owner5-20261104';stage='catalog-compile';reason='New source test dereferenced an unboxed RuntimePlanBuildError; corrected the assertion.'}
        [ordered]@{run='declared-callable-group-owner6-20261104';executed=52;passed=52;failed=0}
        [ordered]@{run='declared-callable-group-owner7-20261104';executed=52;passed=52;failed=0;reason='Final source after bounded projection Debug, owned optional type boxing and fixture/import cleanup.'}
        [ordered]@{run='declared-callable-group-reverse1-20261104';executed=7808;passed=7793;failed=15;reason='Original 14 CLI IDs plus one MCP stdio child-exit deadline failure; full exit 100 retained.'}
        [ordered]@{run='declared-callable-group-cli-followup1-20261104';executed=1;passed=1;failed=0;reason='Same source, 53-package feature selection, all targets and exact 224 executable hashes. Separate isolated result does not erase full-run failure.'}
    )
    environment=[ordered]@{wholeClean=(Read-Receipt 'declared-callable-group-whole-clean-20261104');storageInterruption='declared-callable-group-owner3-storage-interruption.json';claim='Whole cargo clean was explicitly user-authorized. It removed 75585 files / 114.0 GiB before validation resumed, preserving all 4102 source inputs and Git status. All reverse consumers were rebuilt afterward.'}
    ownership=[ordered]@{authority='RuntimeCallableStateDefinition and RuntimeCallableGroupBinding';producer='Actual checked external application with original declaration, catalog identity and canonical full function digest';ingress='Original ABI coordinates and borrowed preflight before move';execution='Original program lease, context formatter/result/limits and Native/AWBC state ownership';proof='Actual retained-state copy proof and final sealed callable graph; existing shared proof budget';sizeReview='Existing cohesive HostBody and callable materialization size warnings remain; no new blanket allow was introduced.'}
    scope=[ordered]@{
        accepted=@('Source ordinary monomorphic external optional/defaulted direct and alias applications','Native and decoded AWBC omitted/present adapter call exactly once with actual result values','Public JSON save/restore at every OneOp step of decoded AWBC execution','Declared raw-ABI Some/None materialization and unknown-formal/wrong-binding rejection','Pending-prefix final graph admission, strict Source replay, retained copy and existing group/effectful alias restoration')
        remaining=@('Register text_style/ruby_style/rich_text_style and connect original call context to construction','Preserve original caller composition order through partial/group capture and factory composition','Carry static inline-style provenance and length units through the consuming owners')
        factoryRegistrationProbe=$factory
        acceptedFeatures='Generic Match remains accepted/public with the same 151 cases passing freshly. Previously accepted sparse layout, property identity, borrowed construction, optional binding and external operand boundaries remain accepted within their documented scope.'
        sourceProbeLimit='Standard cues.stop direct/alias probes establish compilation only. The independent adapter regression supplies Native/decoded-AWBC runtime evidence; neither is factory-registration or complete RichText acceptance.'
    }
    correctionReason='Supersedes the prior current claim that Source alias omission is unfinished: the exact previously rejected source now compiles and the admitted application executes/restores on both backend paths. Old failure records and full SHAs remain historical. The current matrix/CLI rows are replaced with the actual new full run, including its additional MCP failure and separate passing retry.'
    supersedes=@('optionalBindings.scope.remaining: Source checked external optional/defaulted call projection','externalBindingProjection.state/limits: Source alias omission remains open','The five captured current-status rows only; prior evidence objects remain unchanged historical records')
    supersededCurrentRows=$beforeRows;historyPrefix=$historyPrefix
    raw=[ordered]@{path=$archive;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0;indexEntry='declared-callable-group-archive-inputs.json'}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$rows=[IO.File]::ReadAllLines((Join-Path $PWD $statusPath))
$rows=@(foreach($line in $rows){
    if($line.StartsWith('| RichTextの部分layout指定／source factory |')){"| RichTextの部分layout指定／source factory | **既受入を維持・Sourceの省略引数aliasも検証／公開済み。factoryは継続中** | Source ${sha}で、宣言済み引数座標と実callable stateから省略／明示の束縛を導出し、Native／decoded AWBCへ接続した。最終owner 52／52 PASS、実引数0／1件・戻り値・一回の呼出しと各OneOpの公開JSON save／restoreを確認。以前拒否された同一sourceのcues.stop aliasと直接callは実CLIでcompile成功。部分layout・共通property・生成API・Coreの既受入は維持する。残るfactory登録はtext_style／ruby_style／rich_text_styleの実CLI 3件がtype-checkのsema.call.unknown_targetで拒否されたことを根拠とする。元call context接続、合成順、static inline_stylesの出典・長さ単位の消費も別の継続範囲。[具体的入力・新旧の全実測・SHA](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| Generic Match ')){$line.Replace('Source 7d1986b5d6c9520d138df2f19066fe2cf2f2a265の全53逆依存',"Source ${sha}の全53逆依存")}
    elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){"| 共有契約／推移的逆依存matrix | **全53 packageの終端を確認。通常系7,110／7,110 PASS・CLI失敗は別行** | Source ${sha}、4102入力。normal／build／dev・全targetの実Cargo graphとtree照合は差分0、53 package中50で実テストあり。同じall-target／all-feature／lockedの一回のrunは7,808件中7,793 PASS／15 FAIL、40 skipped。arcweft／arcweft-bundle-assets／arcweft-render-webはbuildのみ。Source／case／EXE drift 0。[全件・case別coverage・graph・終端とraw](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| CLI全target照合 |')){"| CLI全target照合 | **統合受入は未完了。最新の全698件は683 PASS／15 FAIL** | Source ${sha}、4102入力、全53逆依存の同じ実runに含む。従来の14 failed IDと、新たなMCP stdioのChildExitDeadline 1件を保持する。同じsource・feature・全224 EXE hashの単独再実行では追加1件がPASSしたが、全体runの15 FAILは変更しない。原因は未確定で、ID一致や単独PASSから原因を推定しない。[全失敗・単独再実行・原本](acceptance-evidence/task-rich-text-property-identity.json)。別境界の失敗でGeneric Matchや既受入のtyped ownerを未完了へ戻さない。 |"}
    elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){"| workspace check／Clippy・fmt・構造gate | **最新Sourceの全98 package check／Clippyと構造gateは終了0。既存警告は残存** | Source ${sha}の最終4102入力に対応する全98 packageのcheck／Clippy（all-target／all-feature／locked）と構造gateは終了0。変更Rust34件のfmtとstaged whitespaceも終了0。容量不足後の全体cargo cleanは75,585 files／114.0 GiB削除、source／Git状態drift 0。その後に全53逆依存を再構築して終端まで確認した。以前のclean・失敗原本も保持する。[receipt・owner review・raw](acceptance-evidence/task-rich-text-property-identity.json)。doctest／wasm専用検証は未再実行。 |"}
    else{$line}
})
[IO.File]::WriteAllLines((Join-Path $PWD $statusPath),$rows,[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-04 — Source declared callable application and optional aliases

- Source $sha (parent $($publication.parent)) completes the checked ordinary external optional/defaulted direct/alias projection on the prior Core/external binding law. Intermediate source $($intermediate.commit) was explicitly checkpointed/pushed pending validation under the user's instruction. Prerequisite source 0f0f99ca13b1762b9dd393d565a8ef4a54cd5d36 and its evidence publication c87971e31f10060028ba296608ebbebf5cb880e9 remain unchanged history. Plan/Source/AWBC application mode and metadata stay at version 1.
- Final owner7 is 52/52 PASS. The compiler regression executes omitted direct, present alias and omitted alias through Native and canonical decoded AWBC, with actual results/call counts and public JSON save/restore at every OneOp step. Final sealed-graph admission and bounded retained CopyValue proof repair the two earlier required/group/effectful alias failures (owner4: 49 PASS / 2 FAIL). Preserve all earlier compile/catalog mistakes and interrupted attempts separately.
- The complete 53-package run on 4102 frozen inputs executes 7808 cases: 7793 PASS / 15 FAIL, 40 skipped, nextest exit 100. Non-CLI is 7110/7110 PASS; CLI is 683/698 PASS. Actual graph/tree, source, case and executable checks have zero drift. Three selected packages without runtime cases are build-only. Full98 check/Clippy/all-target/all-feature/locked and structure exit 0; all 34 changed Rust files pass fmt. Quality/owner receipts pin repaired WIP atop a96351849f218a5f8212c08c2cad5cf9331a2ca5, subsequently published as $sha; this is not a pristine-HEAD test claim.
- The prior 14 CLI failed IDs remain and one MCP stdio case additionally reports ChildExitDeadline instead of Complete at a 100ms shutdown grace. The unchanged module blob alone proves no cause. A separate same-source, same-feature, same224-binary-hash isolated execution is 1/1 PASS. Preserve full-run 15 FAIL and the passing follow-up independently; root cause remains undetermined and no timeout/assertion was weakened.
- Same accepted Generic Match 151, prior Optional 67, external binding projection 25, property identity 9, dynamic display 5 and codegen ProjectCall 2 cases all pass freshly in that full run. Preserve Generic acceptance 850534b9e9bc8c8872f6528dd00050a5e6e7699e / publication f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2 and every earlier accepted typed boundary.
- Correction: remove the current Source-omission-alias gap because the exact earlier cues.stop direct/alias source hashes now both compile successfully using the newly built CLI. This standard probe establishes compilation; the independent adapter test establishes Native/AWBC execution. It does not establish RichText factory completion. Corrected factory probes use valid local identifier value and all three fail type-check with sema.call.unknown_target. Retain the initial invalid-local fixture attempts without using them as registration evidence. Factory registration/context, caller composition order, static inline-style provenance and unit consumption remain separate conditions.
- Storage interruption was followed by the user-authorized whole cargo clean: 75585 files / 114.0 GiB removed, exit 0, all4102 source inputs and Git status unchanged. All consumers were rebuilt afterward. Original12 tracked plus6 actual untracked WIP remain held with unchanged hashes; no branch/worktree, profile/jobs, feature, budget or OS configuration changes.
- All prior evidence JSON fields and this history prefix are preserved. Full SHAs, intermediate publication, every failed attempt, exact source/EXE/catalog/per-case records, clean and follow-up logs are in [the existing task evidence](acceptance-evidence/task-rich-text-property-identity.json). [current-status.md](current-status.md) is the sole current list; these dated results do not reopen completed features.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append,[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in @($beforeRecord.Keys|Where-Object {$_ -ne 'declaredApplications'})){if(($beforeRecord[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw "Prior evidence changed: $key"}}
$afterHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$prefixBytes=[byte[]]::new($history.Length)
[Array]::Copy($afterHistory,$prefixBytes,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefixBytes)).ToLowerInvariant() -ne $historyPrefix.sha256){throw 'History prefix changed'}
[ordered]@{version=1;source=$sha;raw=$record.declaredApplications.raw;priorFieldsDrift=0;historyPrefixDrift=0;currentRows=5;heldTracked=12;heldUntracked=6;fullFailureRetained=$true;isolatedResultSeparate=$true}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$e/declared-callable-group-documentation-qa.json" -Encoding utf8
[ordered]@{source=$sha;rawEntries=$raw.entries.Count;rawBytes=$raw.bytes;rawSha256=$raw.sha256;priorFieldsDrift=0;historyPrefixDrift=0}|ConvertTo-Json -Compress
