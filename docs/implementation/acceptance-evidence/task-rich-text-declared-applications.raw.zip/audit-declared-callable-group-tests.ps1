$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='declared-callable-group-reverse1-20261104'
$terminal=Get-Content -LiteralPath "$e/$stem.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 100
$catalog=Get-Content -LiteralPath "$e/$stem.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 100
$lines=[IO.File]::ReadAllLines("$e/$stem.runtime.log")
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0){throw 'No runtime terminal'}
$selected=@($catalog.rows|Where-Object status -eq 'matches')
$index=@{}
foreach($row in $selected){$key=$row.binary+[char]9+$row.test;if($index.ContainsKey($key)){throw 'Duplicate selected test'};$index[$key]=$row}
$resultLines=if($terminal.caseRowSource -eq 'final-status-after-summary'){$lines[($summary+1)..($lines.Length-1)]}else{$lines[0..($summary-1)]}
$rows=@(foreach($line in $resultLines){
    if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
        $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+[char]9+$test
        if(-not $index.ContainsKey($key)){throw 'Unexpected actual case'}
        [ordered]@{package=$index[$key].package;binary=$binary;test=$test;status=$status}
    }
})
if($rows.Count -ne $terminal.executed -or $rows.Count -ne $selected.Count){throw 'Actual case inventory differs'}
$actual=@{}
foreach($row in $rows){$key=$row.binary+[char]9+$row.test;if($actual.ContainsKey($key)){throw 'Duplicate actual case'};$actual[$key]=$row}
$rows|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$e/$stem.runtime.cases.json" -Encoding utf8
function Observe-Inventory([string]$name){
    $inventory=Get-Content -LiteralPath "$e/$name.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 100
    @(foreach($case in @($inventory.rows|Where-Object status -eq 'matches')){
        $key=$case.binary+[char]9+$case.test
        if($actual.ContainsKey($key)){$actual[$key]}else{[ordered]@{package=$case.package;binary=$case.binary;test=$case.test;status='MISSING'}}
    })
}
$prior=Get-Content -LiteralPath "$e/optional-bindings-reverse1-20261104.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 100
$priorIds=@($prior.failureSet|ForEach-Object {$_.binary+[char]9+$_.test}|Sort-Object)
$failedIds=@($rows|Where-Object status -notin @('PASS','SLOW')|ForEach-Object {$_.binary+[char]9+$_.test}|Sort-Object)
$baseline=Get-Content -LiteralPath "$e/optional-bindings-result-comparison.json" -Raw|ConvertFrom-Json -Depth 100
$generic=@(foreach($case in $baseline.generic){
    $key=$case.binary+[char]9+$case.test
    [ordered]@{group=$case.group;binary=$case.binary;test=$case.test;status=$(if($actual.ContainsKey($key)){$actual[$key].status}else{'MISSING'})}
})
$normal=@($rows|Where-Object package -ne 'arcweft-cli')
$cli=@($rows|Where-Object package -eq 'arcweft-cli')
$coverage=[ordered]@{
    declaredGroupOwner=@(Observe-Inventory 'declared-callable-group-owner7-20261104')
    externalBindingProjection=@(Observe-Inventory 'external-binding-projection-owner5-20261104')
    retainedOptionalBoundary=@(Observe-Inventory 'optional-bindings-owner6-20261104')
    generic=$generic
    propertyIdentity=@($rows|Where-Object {$_.test -match '^rich_text::content_catalog::reusable_style::tests::|^character_dialogue::schema::role_payload::tests::|^character_dialogue_style::tests::'})
    dynamicDisplay=@($rows|Where-Object {$_.package -eq 'arcweft-runtime-driver' -and $_.test -match 'dynamic_character_dialogue_context_tests::'})
    codegenProjectCalls=@($rows|Where-Object {$_.package -eq 'arcweft-runtime-codegen' -and $_.test -match 'project_call'})
}
$result=[ordered]@{
    version=1;source=$terminal.base;total=$rows.Count;sourceInputs=$terminal.sourceInputs;sourceDrift=$terminal.sourceDrift
    normal=[ordered]@{executed=$normal.Count;passed=@($normal|Where-Object status -in @('PASS','SLOW')).Count;failed=@($normal|Where-Object status -notin @('PASS','SLOW')).Count}
    cli=[ordered]@{executed=$cli.Count;passed=@($cli|Where-Object status -in @('PASS','SLOW')).Count;failed=@($cli|Where-Object status -notin @('PASS','SLOW')).Count}
    priorSource=$prior.base;priorRun='optional-bindings-reverse1-20261104';priorFailedIds=$priorIds;currentFailedIds=$failedIds
    addedFailedIds=@($failedIds|Where-Object {$_ -notin $priorIds});removedFailedIds=@($priorIds|Where-Object {$_ -notin $failedIds})
    causeClaim='Failed ID comparison only. Matching IDs do not establish matching causes; original logs and every result remain retained.'
    coverage=$coverage
}
$result|ConvertTo-Json -Depth 100|Set-Content -LiteralPath "$e/declared-callable-group-result-comparison.json" -Encoding utf8
if($result.sourceDrift -ne 0 -or $result.normal.failed -ne 0){throw 'Source drift or non-CLI failure needs investigation'}
foreach($name in $coverage.Keys){
    $cases=@($coverage[$name]);if($cases.Count -eq 0 -or @($cases|Where-Object status -notin @('PASS','SLOW')).Count){throw "Required boundary missing or failing: $name"}
}
if($coverage.generic.Count -ne 151 -or $coverage.declaredGroupOwner.Count -ne 52 -or $coverage.externalBindingProjection.Count -ne 25 -or $coverage.retainedOptionalBoundary.Count -ne 67){throw 'Required owner inventory membership changed'}
if($result.addedFailedIds.Count -or $result.removedFailedIds.Count){throw 'Changed CLI result IDs need investigation'}
[ordered]@{total=$rows.Count;normal=$result.normal;cli=$result.cli;generic=$generic.Count;declaredGroupOwner=$coverage.declaredGroupOwner.Count;externalBindingProjection=$coverage.externalBindingProjection.Count;retainedOptionalBoundary=$coverage.retainedOptionalBoundary.Count;codegenProjectCalls=$coverage.codegenProjectCalls.Count;addedFailedIds=$result.addedFailedIds.Count;removedFailedIds=$result.removedFailedIds.Count}|ConvertTo-Json -Depth 8 -Compress
