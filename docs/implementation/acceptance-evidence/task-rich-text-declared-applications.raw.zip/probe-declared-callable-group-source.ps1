$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$exe=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$exeHash=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
$results=@(foreach($kind in @('direct','alias')){
    $source="$e/optional-external-$kind-probe.arcw"
    $output="$e/declared-callable-group-source-probe-$kind.plan.json"
    $log="$e/declared-callable-group-source-probe-$kind.log"
    if((Test-Path -LiteralPath $output) -or (Test-Path -LiteralPath $log)){throw 'Preserve prior probe inputs and outputs'}
    $arguments=@('compile',$source,'--emit','plan','--output',$output,'--json')
    $started=[DateTime]::UtcNow.ToString('o')
    & $exe @arguments *> $log
    $code=$LASTEXITCODE
    $report=Get-Content -LiteralPath $log -Raw|ConvertFrom-Json -AsHashtable -Depth 100
    $row=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();source=$source;sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();executable=$exe;executableSha256=$exeHash;command=$arguments;exitCode=$code;report=$report;output=$output;outputExists=(Test-Path -LiteralPath $output);startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Compile-only standard cues.stop probe. Runtime evidence belongs to the independent Native/decoded-AWBC adapter regression; no RichText factory acceptance is inferred.'}
    $row|ConvertTo-Json -Depth 100|Set-Content -LiteralPath "$e/declared-callable-group-source-probe-$kind.json" -Encoding utf8
    $row
})
if((Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant() -ne $exeHash){throw 'Probe executable drift'}
foreach($row in $results){if($row.exitCode -ne 0 -or -not $row.outputExists){throw 'Standard direct/alias omission probe is still rejected'}}
$prior=Get-Content -LiteralPath "$e/optional-bindings-source-probe-comparison.json" -Raw|ConvertFrom-Json -Depth 100
if($prior.direct.sourceSha256 -ne $results[0].sourceSha256 -or $prior.alias.sourceSha256 -ne $results[1].sourceSha256){throw 'Original failed probe sources differ'}
[ordered]@{version=1;source=(git rev-parse HEAD).Trim();direct=$results[0];alias=$results[1];executableDrift=0;sourceInputDrift=0;priorSource=$prior.source;priorDirectExit=$prior.direct.exitCode;priorAliasExit=$prior.alias.exitCode;priorAliasStage=$prior.alias.report.stage;conclusion='The same standard cues.stop omitted alias now compiles through RuntimePlan. Both direct and alias produce a plan; historical rejected result is retained.'}|ConvertTo-Json -Depth 100|Set-Content -LiteralPath "$e/declared-callable-group-source-probe-comparison.json" -Encoding utf8
[ordered]@{directExit=$results[0].exitCode;aliasExit=$results[1].exitCode;priorAliasExit=$prior.alias.exitCode;executableDrift=0;sourceInputDrift=0}|ConvertTo-Json -Compress
