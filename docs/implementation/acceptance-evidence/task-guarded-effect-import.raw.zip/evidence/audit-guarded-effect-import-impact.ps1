$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/guarded-effect-import.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/guarded-effect-import.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {
    $changed=$false
    foreach($node in $metadata.resolve.nodes){if(-not $closure.Contains($node.id)){foreach($dep in $node.deps){if($closure.Contains($dep.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}
}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/conditional-component.impact.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count){throw 'Reverse graph changed'}
$consumers=Get-Content -Raw "$root/conditional-component.consumer-summary.json"|ConvertFrom-Json
$cargoInputs=@(git diff --name-only $consumers.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml')
if($cargoInputs.Count){throw 'Cargo graph inputs changed'}
$archive=Get-Content -Raw "$root/conditional-component.archive.json"|ConvertFrom-Json
if((Get-FileHash -LiteralPath $archive.Path -Algorithm SHA256).Hash -cne $archive.SHA256){throw 'Reused frozen evidence changed'}
[ordered]@{Version=1;Source=$pub.Source;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='guarded-effect-import.reverse-tree.txt';CargoInputsUnchanged=$true;ReverseConsumersRerun=$false;ReusedSource=$consumers.Source;ReusedTargets=$consumers.Targets;ReusedPassed=$consumers.Passed;ReusedFailed=$consumers.Failed;ReusedSkipped=$consumers.Skipped;ReusedArchive=$archive.Path;ReusedArchiveSHA256=$archive.SHA256;Reason='All changes remain inside the crate-private prepared-effect owner. The new Imported variant has only the new typed import constructor; existing producers retain Scheme/Unknown terms, and existing non-import completion semantics remain covered by the full owner run. Existing prepared type/callable consumers retain or validate terms; no producer outside the owner creates the new frozen/import path. No cross-crate Rust API, codec, syntax, fixture, manifest, feature or generated artifact changed. The current 22-package graph is unchanged. Reuse the prior complete 107-target execution at its original Source; do not relabel it as this Source. Workspace check/Clippy from that Source are reused, while current owner all-target/all-feature Clippy, all owner tests, doctests, fmt and the structural gate are rerun.'}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/guarded-effect-import.impact.json"
Write-Output "Impact verified: $($packages.Count) packages; consumer evidence reused from $($consumers.Source)"
