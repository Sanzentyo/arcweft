$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/guarded-effect-import.publication.json"|ConvertFrom-Json
$validated=Get-Content -Raw "$root/guarded-effect-import.docs-validation.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/guarded-effect-import.archive.json"|ConvertFrom-Json
$paths=@('docs/implementation/current-status.md','docs/implementation/convergence-evidence-history.md','docs/implementation/acceptance-evidence/task-guarded-effect-import.raw.zip')
if($validated.Source -ne $pub.Source -or !$validated.GenericMatchUnchanged -or !$validated.RustPinsUnchanged -or $validated.ArchiveSHA256 -cne $archive.SHA256 -or (git rev-parse HEAD) -ne $pub.Source -or @(git diff --cached --name-only).Count){throw 'Documentation publication input differs'}
if(@(Compare-Object -CaseSensitive @($paths[0..1]|Sort-Object) @(git diff --name-only HEAD|Sort-Object)).Count){throw 'Unexpected tracked changes'}
$blobs=@(foreach($path in $paths){[pscustomobject]@{Path=$path;Blob=(git hash-object -- $path).Trim();SHA256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}})
git add -- @paths
if($LASTEXITCODE){throw 'Documentation stage failed'}
if(@(Compare-Object -CaseSensitive @($paths|Sort-Object) @(git diff --cached --name-only|Sort-Object)).Count){throw 'Staged documentation differs'}
git diff --cached --check
if($LASTEXITCODE){throw 'Staged documentation whitespace failed'}
git diff --cached --binary > "$root/guarded-effect-import.docs-staged.patch"
git diff --cached --stat
git commit -m 'Record guarded component imports and preserve scoped validation evidence'
if($LASTEXITCODE){throw 'Documentation commit failed'}
$head=(git rev-parse HEAD).Trim()
git fetch origin main > "$root/guarded-effect-import.docs-fetch.log" 2>&1
if($LASTEXITCODE -or (git rev-parse origin/main) -ne $pub.Source){throw 'Remote moved before documentation publication'}
git push origin main > "$root/guarded-effect-import.docs-push.log" 2>&1
if($LASTEXITCODE){throw 'Documentation push failed'}
$observed=(git ls-remote origin refs/heads/main).Split()[0]
if($LASTEXITCODE -or $observed -ne $head -or (git rev-parse origin/main) -ne $head -or @(git diff --name-only HEAD).Count){throw 'Final remote/tree differs'}
foreach($path in @($pub.Paths)+$blobs){
    if((git rev-parse "origin/main:$($path.Path)") -ne $path.Blob -or (git hash-object -- $path.Path) -ne $path.Blob -or (Get-FileHash -LiteralPath $path.Path -Algorithm SHA256).Hash -cne $path.SHA256){throw 'Published blob/bytes differ'}
}
[ordered]@{Version=1;Source=$pub.Source;Documentation=$head;Remote=$observed;SourcePaths=$pub.Paths;DocumentationPaths=$blobs;AllFourteenBlobsVerified=$true;TrackedDirty=0;Untracked=@(git ls-files --others --exclude-standard);ArchiveSHA256=$archive.SHA256;Finished=(Get-Date -Format o)}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/guarded-effect-import.docs-publication.json"
Write-Output "PUBLISHED documentation $head; main=origin/main; fourteen blobs verified; tracked dirty=0"
git status --short

