$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/guarded-effect-import.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/guarded-effect-import.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/guarded-effect-import.impact.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/guarded-effect-import.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/guarded-effect-import.structure.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/guarded-effect-import.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean'}
if($owner.Passed -ne 1705 -or $owner.Failed -ne 6 -or $impact.ReverseConsumersRerun -or !$archive.AllEntriesVerified -or $structure.ExitCode){throw 'Evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'Historical prefix changed'}
$rows=@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。凍結した子のguard付き関数を親へ移す数学層を検証・公開。本体内推論は継続** | 最新Source `SOURCE`。Native／AWBCの42・各step公開保存復元と、実Source Γ・import lease・frame移送の既受入を維持する。子は元の式・依存順・局所∀・domain・Future identityを凍結し、親は実Unknown関数をFutureに結び付ける。子／受入基底ごとの条件付き最小化を共有し、最小解とprincipal条件を一体で移送する。親の追加条件で非principalな子を救済せず、親だけのlabelも子の例外supportへ無条件に加えない。取り込み値は親の最小化座標から除外する。確定時は計算済み結果を代入し、子の元の式を独立再検証する。異なる依存引数・domain・改変拒否・32段の入れ子など新10件はPASS。検査・部分簡約できる量化済み残余条件、任意の未確定supportでの表現、MGU／rank・Fn型ownerの局所∀は未完了。reify入力の元operand導出、checked primitive effect ownerと行seal、全portのΓ統合、frontend prepared value／effect・body一回準備・一括sealも続ける。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[Γとowner](convergence-evidence-history.md#inference-references-and-application-leases)・[今回のguard付きimport](convergence-evidence-history.md#guarded-scoped-effect-component-imports)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,705 PASS／6 FAIL。後続21 packageは直前Sourceの実測を再利用** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,711件を84.132秒で実行。直前1,701 IDを維持し新10件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。現在の全feature Cargo graphで22 packageを再確認した。新しいImported variantはprivate ownerの新constructorだけから作られ、既存のprepared producer・cross-crate API・codec・fixture・Cargo入力は不変のため、後続21 package／107 targetはSource `0691efa11175cadc7c0850278cd1a7ef4be45f62` の2,507 PASS／2 FAIL／1 SKIPを再利用する。Compiler既知2失敗はExpressionCycle slot 17／19であり、今回の再実行とは扱わない。[現在のowner・graph・再利用根拠](acceptance-evidence/task-guarded-effect-import.raw.zip)・[consumer実測](acceptance-evidence/task-conditional-component.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **直前公開Sourceの規定226件PASSを維持。全 check は未再実行** | 実行Source `0691efa11175cadc7c0850278cd1a7ef4be45f62`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS。binはcompile済み・runnable test 0件。今回のprivate準備効果ownerの拡張ではこの結果を再利用し、新Sourceの再実行へ読み替えない。以前の入力・件数・失敗も履歴と原本に保持する。[CLI実行原本](acceptance-evidence/task-conditional-component.raw.zip)・[今回の再利用根拠](acceptance-evidence/task-guarded-effect-import.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新owner Clippy・fmt・doctest・構造gateは終了0。workspace記録は直前Sourceを再利用** | Source `SOURCE` と同一のRust bytesでlocked owner全target／全feature Clippy、workspace fmt、Sema doctest 2件を実行。checkはClippyに包含。構造gateは98 package・3,498 files・3,367 Rust files・1,898,408 Rust LOC・396 review・blocking 0。11 Rust path・1,202物理LOC増の所有責務を確認し、fnの原定義・実Future identity・一度の条件付き最小化・独立replayを同じowner内へ保持した。Cargo graphは22 packageで不変。cross-crate契約・生成物・feature変更がないprivate cutとして、workspace全target／全feature check／ClippyはSource `0691efa11175cadc7c0850278cd1a7ef4be45f62` の終了0を再利用し、今回の実行へ付け替えない。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告は原本へ保持。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を維持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・graph](acceptance-evidence/task-guarded-effect-import.raw.zip)・[workspace実測](acceptance-evidence/task-conditional-component.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$status=[IO.File]::ReadAllText($statusPath)
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'}
    $replacement=$rows[$key].Replace('SOURCE',$pub.Source)
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `0691efa11175cadc7c0850278cd1a7ef4be45f62`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Guarded scoped effect component imports

2026-11-13。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainで11 Rust pathを通常commit／非force pushし、ownerが検証したdirty bytesと公開全blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- 元のdependency・domain・局所∀・式・Future identityを持つgraphを凍結し、実Parent Unknownへの結合を検査してguard付き関数を導入する。取り込み関数はderived variantであり、Parentの最小化座標にはしない。各child／受入基底の条件付き最小解を一度だけ計算し、複数outputと異なるFuture環境でも未代入の結果を共有する。Child K外のlabelは、実Future係数がdefaultと異なる条件の下だけでchildの例外supportとして許す。
- 確定時は計算済みの係数・principal条件・全行共通witnessへ実Futureを代入し、元の子の式をcanonical algebraで独立再検証する。minimizationを再実行しない。loweringと子replayは明示stackで行う。Parent constraintで非principal childを救済しない、Parent labelを無条件に借りない、非単調なderived outputをParentの最小化座標に加えない条件を含む新10件がPASS。依存順の移送、Scheme domain、foreign／重複／arity／予算0／rollback後のstale拒否、独立環境、32段の入れ子、Parentと整合させた不正なcached childの拒否も検証した。
- 最終ownerは1,711件／1,705 PASS／6 FAIL／0 SKIP、84.132秒、5 suite。直前1,701 IDを維持し新10件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。開発checkのImported未網羅と、開発test buildのcheckpoint mutable参照エラーを修復し、raw logを保持した。最終前の対象9件は9 PASS、最終は全ownerで照合した。
- 今回の実行はowner全target／全feature Clippy、workspace fmt、Sema doctest 2件、構造gateが終了0。現在のfull metadata／全target treeでSemaを含む逆依存22 packageを再確認した。既存producerは従来variantを保持し、新importはprivate owner外からまだ導入されない。cross-crate API・codec・syntax・fixture・manifest・feature・生成物変更がないため、後続21 package／107 targetの2,507 PASS／2 FAIL／1 SKIPとworkspace check／ClippyはSource ``0691efa11175cadc7c0850278cd1a7ef4be45f62`` の記録を再利用した。現在Sourceの再実行とは扱わない。
- 11 pathで1,202物理LOC増。completion.rs 148 LOCは凍結とguarded handle、imports.rs 301 LOCは条件付きlowering・supportと確定replay、独立test owner 513 LOCが反例と拒否条件を所有する。既存componentは332 LOC、root closureは457 LOC。fan-in 12／fan-out 19で不変。二つ目のsolver、Source再構築、別Γ表、依存、unsafe、公開互換readerは追加しない。
- Supersedes: 現状一覧の有限基底kernelだけの途中説明を、検証済みの凍結・guarded import・support・独立replayへ整理した。全supportで検査・部分簡約できる量化済み残余条件とfrontend接続まで完了したとは扱わない。過去の全SHA・実測・frozen原本、Generic Match・caller-bound recursion・共有prefixの受入を保持する。現在の残作業は[current-status.md](current-status.md)へ集約する。

原本 [task-guarded-effect-import.raw.zip](acceptance-evidence/task-guarded-effect-import.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended scoped import evidence'
