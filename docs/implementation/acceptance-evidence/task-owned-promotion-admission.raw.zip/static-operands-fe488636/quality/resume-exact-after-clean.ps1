$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$arcRoot=Join-Path $env:TEMP 'arcweft-promotion-20261110'
$arcOut=Join-Path $arcRoot 'exact'
New-Item -ItemType Directory -Path $arcOut -Force | Out-Null
$arcPublication=Get-Content (Join-Path $arcRoot 'source.publication.json') -Raw|ConvertFrom-Json -AsHashtable
$arcBase=$arcPublication.commit
$arcPaths=@($arcPublication.blobs|ForEach-Object {$_.path})
function Get-ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
$arcInputs=@($arcPublication.blobs|ForEach-Object {[ordered]@{path=$_.path;sha256=$_.sha256}})
function Test-ArcInputs {
    foreach($entry in $arcInputs){if((Get-ArcSha $entry.path) -ne $entry.sha256){throw "input drift $($entry.path)"}}
    $arcObserved=@(git diff --name-only $arcBase -- '*.rs' '*.arcw' '*.toml' Cargo.lock)
    if($arcObserved.Count){throw 'published Rust inputs drifted'}
}
Test-ArcInputs
$arcRoots=@('arcweft-lang-hir','arcweft-lang-sema')
$arcTarget='x86_64-pc-windows-msvc'
$arcTreeLog=Join-Path $arcOut 'rdeps.log'
$arcTree=@(foreach($root in $arcRoots){
    "cargo tree --locked --workspace --target $arcTarget --invert $root --prefix none"
    & cargo tree --locked --workspace --target $arcTarget --invert $root --prefix none
    if($LASTEXITCODE){throw "Cargo graph failed $root"}
})
$arcTree|Set-Content -LiteralPath $arcTreeLog -Encoding utf8
$arcNames=@($arcTree|ForEach-Object{if($_ -match '^(arcweft-[\w-]+) v'){$Matches[1]}}|Sort-Object -Unique)
$arcGroups=[ordered]@{
    'owners'=$arcRoots
    'plan-compiler'=@('arcweft-runtime-plan','arcweft-compiler')
    'runtime-host'=@('arcweft-runtime-host')
    'driver-scene'=@('arcweft-runtime-driver','arcweft-player-scene')
    'player-native'=@('arcweft-player-native')
    'player-web'=@('arcweft-player-web')
    'agent-execution'=@('arcweft-agent-repl','arcweft-agent-runner')
    'agent-transport'=@('arcweft-agent-mcp','arcweft-agent-mcp-client','arcweft-adapter-sema')
    'tools-lsp'=@('arcweft-project-loader','arcweft-tooling','arcweft-lsp','arcweft-test')
    'verify'=@('arcweft-verify','arcweft-verify-oxiz','arcweft-verify-z3','arcweft-verify-lsp')
}
$arcPartition=@(foreach($group in $arcGroups.Values){$group})+@('arcweft-cli')
if($arcPartition.Count -ne $arcNames.Count -or (Compare-Object $arcPartition $arcNames)){throw 'stage partition differs from resolved reverse dependencies'}
$arcStages=[ordered]@{
    'workspace-check'=@('check','--locked','--workspace','--all-targets','--all-features')
    'workspace-clippy'=@('clippy','--locked','--workspace','--all-targets','--all-features')
    'cli-build'=@('build','--locked','-p','arcweft-cli','--bin','arcw')
    'owner-doctests'=@('test','--locked','--doc','-p','arcweft-lang-hir','-p','arcweft-lang-sema')
}
$arcNextest=@('nextest','run','--locked','--no-fail-fast','--no-tests','fail')
foreach($name in $arcGroups.Keys){
    $arcStages[$name]=$arcNextest+@('--lib','--tests')+@(foreach($pkg in $arcGroups[$name]){'-p';$pkg})
}
$arcStages['cli-library-binaries']=$arcNextest+@('-p','arcweft-cli','--lib','--bins')
$arcStages['cli-integration']=$arcNextest+@('-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')
$arcReceipt=[ordered]@{
    version=1;base=$arcBase;inputs=$arcInputs;target=$arcTarget;reversePackages=$arcNames;graphSha256=Get-ArcSha $arcTreeLog
    active=$null;remaining=$arcStages.Count;results=@()
}
$arcReceiptFile=Join-Path $arcOut 'quality.receipt.json'
function Save-ArcReceipt {
    $tmp=Join-Path $arcOut 'quality.receipt.new.json'
    $arcReceipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $tmp -Encoding utf8
    [IO.File]::Move($tmp,$arcReceiptFile,$true)
}
$arcResume=Get-Content -LiteralPath $arcReceiptFile -Raw|ConvertFrom-Json -AsHashtable
$arcClean=Get-Content -LiteralPath (Join-Path $arcOut 'cargo-clean.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$arcInterrupted=Get-Content -LiteralPath (Join-Path $arcOut 'cargo-clean-interruption.json') -Raw|ConvertFrom-Json -AsHashtable
if ($arcClean.cleanExit -or $arcClean.targetStillExists -or $arcResume.base -ne $arcBase -or $arcInterrupted.commit -ne $arcBase -or (Compare-Object $arcResume.reversePackages $arcNames) -or $arcResume.graphSha256 -ne $arcReceipt.graphSha256 -or $arcResume.remaining -ne ($arcStages.Count - $arcResume.results.Count)) {
    throw 'The completed stages cannot be safely resumed'
}
foreach ($stage in $arcResume.results) {
    if (!$arcStages.Contains($stage.name) -or $stage.exitCode -or $stage.logSha256 -ne (Get-ArcSha (Join-Path $arcOut "$($stage.name).log"))) { throw "Invalid completed stage $($stage.name)" }
    if (Compare-Object $stage.command (@('cargo')+$arcStages[$stage.name]) -SyncWindow 0) { throw "Command drift $($stage.name)" }
}
$arcReceipt=$arcResume
$arcReceipt.active=$null
$arcReceipt.cargoClean=[ordered]@{
    receiptSha256=Get-ArcSha (Join-Path $arcOut 'cargo-clean.receipt.json')
    interruptionSha256=Get-ArcSha (Join-Path $arcOut 'cargo-clean-interruption.json')
    interruptedLogSha256=Get-ArcSha (Join-Path $arcOut $arcInterrupted.interruptedLog)
    resumedAtUtc=[DateTime]::UtcNow.ToString('o')
}
Save-ArcReceipt
$arcFailures=0
foreach($name in $arcStages.Keys){
    if ($arcReceipt.results.name -contains $name) { continue }
    Test-ArcInputs
    $arcCommand=$arcStages[$name]
    $arcLog=Join-Path $arcOut "$name.log"
    $arcReceipt.active=$name
    Save-ArcReceipt
    & cargo @arcCommand *> $arcLog
    $arcExit=$LASTEXITCODE
    Test-ArcInputs
    $arcLines=@(Select-String -Path $arcLog -Pattern 'Summary \[|test result:|Finished .+ profile|^ +FAIL \['|ForEach-Object {$_.Line.Trim()}|Select-Object -Last 20)
    $arcReceipt.results+=@([ordered]@{name=$name;command=@('cargo')+$arcCommand;exitCode=$arcExit;summary=$arcLines;logSha256=Get-ArcSha $arcLog})
    $arcReceipt.remaining--
    $arcReceipt.active=$null
    if($name -eq 'cli-build' -and $arcExit -eq 0){$arcReceipt.cliSha256=Get-ArcSha 'target/debug/arcw.exe'}
    Save-ArcReceipt
    "$name exit $arcExit"
    $arcLines
    if($arcExit){$arcFailures++}
}
if($arcFailures){exit 1}


