param([string]$Stem='font-family-reverse1-20261105')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$terminal=Get-Content -LiteralPath "$taskTemp/$Stem.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$receipt=Get-Content -LiteralPath "$taskTemp/$Stem.runtime.json" -Raw|ConvertFrom-Json
$lines=[IO.File]::ReadAllLines($receipt.log)
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0){throw 'No terminal summary'}
$statusLines=if($terminal.caseRowSource -eq 'final-status-after-summary'){$lines[($summary+1)..($lines.Length-1)]}else{$lines[0..($summary-1)]}
$cases=@{}
foreach($line in $statusLines){if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
 $key=$Matches[2]+"`t"+$Matches[3]
 if($cases.ContainsKey($key)){throw 'Repeated terminal case'}
 $cases[$key]=$Matches[1]
}}
if($cases.Count -ne $terminal.executed){throw 'Terminal cases differ'}
$referencePath='docs/implementation/acceptance-evidence/accepted-generic-c3-c5-closure-audit.json'
$reference=Get-Content -LiteralPath $referencePath -Raw|ConvertFrom-Json
$groups=@(foreach($group in $reference.groups.PSObject.Properties){
 $rows=@(foreach($case in $group.Value){
  $key=$case.binary+"`t"+$case.name
  [ordered]@{binary=$case.binary;test=$case.name;status=$(if($cases.ContainsKey($key)){$cases[$key]}else{'MISSING'})}
 })
 [ordered]@{group=$group.Name;expected=$rows.Count;passed=@($rows|Where-Object status -in @('PASS','SLOW')).Count;missing=@($rows|Where-Object status -eq 'MISSING').Count;failed=@($rows|Where-Object status -notin @('PASS','SLOW','MISSING')).Count;rows=$rows}
})
$total=0;$passed=0;$missing=0;$failed=0
foreach($group in $groups){$total+=$group.expected;$passed+=$group.passed;$missing+=$group.missing;$failed+=$group.failed}
if($total -ne 151){throw 'Accepted reference set differs'}
$record=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');base=$receipt.base;run=$terminal.run;sourceInputs=$terminal.sourceInputs;sourceDrift=$terminal.sourceDrift;catalogCaseDrift=$terminal.catalogCaseDrift;reference=$referencePath;referenceSha256=(Get-FileHash -LiteralPath $referencePath).Hash.ToLowerInvariant();accepted='850534b9e9bc8c8872f6528dd00050a5e6e7699e';published='f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2';expected=$total;passed=$passed;missing=$missing;failed=$failed;groups=$groups;scope='Fresh exact binary/test identity comparison within the full48 font reverse-closure run; retain the original Generic Match acceptance/publication independently of other failures.'}
$record|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$Stem.generic-match.json" -Encoding utf8
[ordered]@{expected=$total;passed=$passed;missing=$missing;failed=$failed;groups=@($groups|ForEach-Object {[ordered]@{name=$_.group;expected=$_.expected;passed=$_.passed}})}|ConvertTo-Json -Depth 5
