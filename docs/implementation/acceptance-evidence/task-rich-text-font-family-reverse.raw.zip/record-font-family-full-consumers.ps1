$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$source=Read-Record 'font-family-source-proxy-checkpoint.verified'
$terminal=Read-Record 'font-family-reverse1-20261105.runtime.terminal-audit'
$packages=Read-Record 'font-family-reverse1-20261105.packages'
$generic=Read-Record 'font-family-reverse1-20261105.generic-match'
$comparison=Read-Record 'font-family-reverse1-20261105.failure-comparison'
$inputs=Read-Record 'font-family-reverse1-20261105.quality-input-comparison'
$proxy=Read-Record 'font-family-source-proxy1-20261105.runtime.terminal-audit'
$schema=Read-Record 'font-family-proxy-schema2-20261105.runtime.terminal-audit'
if((git rev-parse HEAD).Trim() -ne $source.commit -or $terminal.executed -ne 7140 -or $terminal.failed -ne 14 -or $packages.nonCli.failed -ne 0 -or $generic.passed -ne 151 -or $generic.missing -ne 0 -or $comparison.newFailures -ne 0 -or $inputs.inputDrift -ne 0 -or $proxy.passed -ne 1 -or $schema.passed -ne 2){throw 'Unexpected final results'}
$quality=[ordered]@{};$finalQuality=[ordered]@{}
foreach($stage in 'check','clippy','structure'){
 $quality[$stage]=Read-Record "font-family-workspace-quality1-20261105-$stage"
 $finalQuality[$stage]=Read-Record "font-family-final-owner-quality1-20261105-$stage"
 if($quality[$stage].exitCode -ne 0 -or $finalQuality[$stage].exitCode -ne 0){throw 'Quality failed'}
}
$prefixes=@('font-family-reverse1-20261105','font-family-workspace-quality1-20261105','font-family-final-owner-quality1-20261105','font-family-source-proxy','font-family-proxy-schema')
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$name=$_.Name;@($prefixes|Where-Object {$name.StartsWith($_,[StringComparison]::Ordinal)}).Count -gt 0})
$files+=@(Get-ChildItem -LiteralPath "$taskTemp/font-family-workspace-quality1-20261105.structure-report","$taskTemp/font-family-final-owner-quality1-20261105.structure-report" -File -Recurse)
$files+=@(Get-Item -LiteralPath "$taskTemp/record-font-family-full-consumers.ps1","$taskTemp/audit-font-family-generic-match.ps1","$taskTemp/audit-font-family-full-consumers.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/run-action-payload-quality.ps1","$taskTemp/audit-nextest-final-result.ps1","$taskTemp/rich-text-length-reverse2-20261105.runtime.terminal-audit.json")
. "$taskTemp/write-verified-evidence-archive.ps1"
$rawPath='docs/implementation/acceptance-evidence/task-rich-text-font-family-reverse.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$before=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.fontFamily.Contains('fullConsumers')){throw 'Preserve previous final evidence'}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$oldRows=@($status -split "`n"|Where-Object {$_ -match '^\| (RichTextの部分layout指定／source factory|RichTextの型付きFontFamily|Generic Match|CLI全target照合|workspace check／Clippy)'})
$oldState=$record.fontFamily.state
$record.fontFamily.state='Typed FontFamily Source/codec/projection consumers validated and published. Full48 reverse run7140:7126PASS14FAIL, all14 are earlier CLI failure IDs; non-CLI6440/6440PASS. Generic Match exact accepted151/151PASS. Later test/doc-only Source proxy addition1/1PASS and schema/query2/2PASS with owner quality0. Whole CLI and whole-engine milestone are not accepted by these results.'
$record.fontFamily.fullConsumers=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$source.commit;finalTestAndDocumentationSource=$source
 runtime=$terminal;runtimeCommand=(Read-Record 'font-family-reverse1-20261105.runtime').command;packages=$packages
 runtimeSource='Full run at afdf8773b3743df2fd16691e0ea4deec6183db46 (production/consumer source54c8089a144576d887df678063583d7f31d7a914 plus owner evidence only) with original12 tracked WIP.7140 actual selected cases,45 runtime packages and3 host-build-only packages,48 ignored/skipped.964.555s; source4110/case/EXE drift0. Subsequent Source proxy test and documentation/assertion-diagnostic edits are separate, not included in7140.'
 failureComparison=$comparison
 failureScope='All14 current failed IDs occur in the actual prior55-failure full run: full-grammar current-line assumptions3, Scroll shared-callable resolution1, unauthored presentation params1, repeated-source RAG1, old plan/unsafe fixtures2, run-edge1, negative-fixture diagnostic1 and verifier obligation fixtures4. No new failed IDs; all6440 non-CLI cases PASS. Earlier logical-pixel and negative-fixture fixes are part of this source; do not attribute their improvement to FontFamily or rewrite the old55 failures.'
 genericMatch=$generic
 workspaceQuality=$quality;workspaceQualityInputComparison=$inputs
 qualityScope='Whole98 workspace check/Clippy all-targets/all-features/locked and whole98 structure exit0. Their4110 frozen inputs exactly equal the full reverse runtime inputs, despite different Git bases due to intervening publication. Warnings remain; this is host coverage, not a wasm/doctest/Native-Web image-parity result.'
 sourceProxy=$proxy;sourceProxyCommand=(Read-Record 'font-family-source-proxy1-20261105.runtime').command
 sourceProxyScope='Actual Source #[text_proxy(font=serif)] FontHit{font:FontFamily}, then default, quoted serif, explicit sans_serif and quoted Noto Sans JP overrides. Four proxies retain exact default/schema kind and typed field family through template lowering and JSON roundtrip.1/1PASS178skip0.146s, separate from7140.'
 finalSchemaQuery=$schema;finalSchemaQueryCommand=(Read-Record 'font-family-proxy-schema2-20261105.runtime').command
 finalCompileFailure=Read-Record 'font-family-proxy-schema1-20261105.catalog'
 finalCorrection='Replacing assert!(is_empty()) with assert_eq! initially used an untyped empty array, causing catalog-only E0282, no runtime. Add a typed [&str;0] binding; retain the exact empty textual-enum expectation. Final schema/query2/2PASS233skip. New Source test and these test/documentation edits change no production logic or Cargo behavior; reuse unchanged production/shared semantics validation rather than pretend a new full7140 run.'
 finalOwnerQuality=$finalQuality;finalQualityScope='Compiler/Presentation/AgentProtocol all-target/all-feature/locked check and Clippy plus full98 structure exit0 on the final test/doc-only source; no Clippy warning at the newly changed font/proxy/schema test paths. Other existing warnings remain.'
 contractCorrection='Supersedes the maintained observation paragraph that assigned text-proxy defaults/overrides to RichTextParam proxy_params. Current AgentHitRegion and Source/TextModel use declaration-ordered proxy_schema/proxy_fields; proxy_params is image-resource-owned. Source defaults/overrides and typed query JSON tests establish generic/named family separation. Source/doc patch and the mistaken intermediate E0282 attempt are retained.'
 correctionReason='Replace the current-list pending full48 statement and intermediate246-case CLI snapshot with actual independent full7140/CLI700 results. Refresh only Generic Match verification source, retaining original acceptance/publication. Replace the outdated owner-cut pending state; do not revert any accepted feature because14 other CLI failures or the overall goal remain.'
 supersededCurrentState=$oldState;supersededCurrentRows=$oldRows
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| RichTextの部分layout指定／source factory |')){
  '| RichTextの部分layout指定／source factory | **既受入を維持。順序・px／pt・CLI論理px整合を公開・対象検証済み** | 単位保持d693a3fcc4b4716ac9d608e9c075d8f1ff96bcdf、共有API0345cb6ed70b8ce83a7b3a200ba790a385efa4e8、CLI fixture44dfe5f7113a6b4823f78a64b55e5c845f1c59a0。6 owner309／309、Compiler318／318と負例fixture修復の別4／4を保持する。横書き・縦書き左右で18ptと24pxの実glyph geometryが一致し、45 size入力は元の数値・text・viewport・予算・全geometry assertionを保ったpxへ訂正済み。最新の全CLI実測はCLI行、型付きFontは専用行に集約する。static inline_styles出典と最終画像parityは継続する。[全実測・訂正理由・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| RichTextの型付きFontFamily |')){
  '| RichTextの型付きFontFamily | **当該Source・codec・consumer境界を検証・公開済み** | 型owner8fcabc7e3dfc498df6c96e231a424a66cdf4c95d、共通constructor修復dc79d70a073d2660d9e5801699ffadf692ac560d、consumer検査54c8089a144576d887df678063583d7f31d7a914、Source TextProxy／観測契約同期'+$source.commit+'。generic 5種とnamedを区別し、Source10／10、下位owner354／354、実Native CLIの7指定、改変codec、Source proxyとJSON queryを各独立runで確認した。全48逆依存7140実行は7126 PASS／14 FAIL、非CLI6440／6440 PASSで、14件は全て以前のCLI失敗ID。workspace check／Clippyと構造gateは終了0。各step公開JSON保存復元するAWBCと元の所有権・予算・上限を保持し、途中の全失敗も残す。全CLI統合とNative-Web parityは別境界。[正確な対象・結果・Source・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| Generic Match `.1.2` C3/C5 |')){
  '| Generic Match `.1.2` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。完全transcript、uninhabited-domain、Never／let-else継続、exhaustive-only atomic publicationの受入を維持する。[元の受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)。Source afdf8773b3743df2fd16691e0ea4deec6183db46の全48逆依存で、同じ151 IDが151／151新規PASS、欠落0。[最新case照合と以前の全実測](acceptance-evidence/task-rich-text-property-identity.json)。公開SHAと過去の結果は[検証履歴](convergence-evidence-history.md)へ保持する。別境界や全体goalの未達だけで未完了へ戻さない。 |'
 }elseif($line.StartsWith('| CLI全target照合 |')){
  '| CLI全target照合 | **統合受入は未完了。最新の全700は686 PASS／14 FAIL** | Source afdf8773b3743df2fd16691e0ea4deec6183db46の全48逆依存runから実CLI700 IDを照合した。14失敗は以前のfull runにもあるIDで、full-grammar現在line選択3件、Scroll解決1件、未記述param期待1件、RAG1件、旧plan／unsafe fixture2件、run-edge1件、負例診断1件、verifier fixture4件。新規失敗ID0でも全CLI成功とはしない。以前の698／52 FAIL・246／6 FAILと後続owner修復は、それぞれの入力と結果のまま履歴へ保持し、合算しない。[全失敗・訂正・原本](acceptance-evidence/task-rich-text-property-identity.json)。Generic Matchと他の既受入境界は維持する。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
  '| workspace check／Clippy・fmt・構造gate | **共有Font Sourceの全98 check／Clippy・構造gateは終了0。警告は残る** | 全48 runtime Source afdf8773b3743df2fd16691e0ea4deec6183db46と、workspace qualityの4110入力は完全一致した。全98 all-target／all-feature／locked check・Clippyと構造gateは終了0。その後のtest／docのみの'+$source.commit+'はCompiler／Presentation／AgentProtocolのcheck・Clippyと全98構造gateが終了0。変更Rustをfmtし、新しいFont assertionの警告を解消した。専用wasm・doctest・最終Native-Web parityを、このhost検証で完了とはしない。[実入力・差分照合・終端・raw](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefixHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()
$append=@"

## 2026-11-05 — Typed FontFamily full reverse closure and Source proxy consumers

- Actual full48 reverse run at afdf8773b3743df2fd16691e0ea4deec6183db46:7140run7126PASS14FAIL48skip,964.555s;45 runtime packages and3 host-build-only packages. Non-CLI6440/6440PASS; CLI700=686PASS14FAIL. All14 failed IDs also occur in the previous55-failure full run. Earlier logical-pixel and Compiler fixture repairs are included here; do not attribute their improvement to FontFamily or rewrite the historical55 failures.4110 source/case/EXE drift0. Preserve every failure and original12 tracked/6 untracked WIP.
- Exact accepted Generic Match set151/151 freshPASS (115 transcript24 coverage5 query7 Native/AWBC),0missing. Acceptance850534b9e9bc8c8872f6528dd00050a5e6e7699e and publicationf0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2 remain unchanged. Whole98 workspace check/Clippy alltargets/features/locked and structure exit0; frozen-input comparison with this runtime is exactly4110/0drift, despite publication-only Git base changes. Existing warnings remain.
- Later test/doc-only source $($source.commit) adds Source FontFamily TextProxy defaults and generic/quoted-named overrides with exact schema/field JSON roundtrip:1/1PASS178skip. Replaces the stale observation paragraph's text-proxy map claim with actual proxy_schema/proxy_fields and explicit tagged FontFamily queries; proxy_params remains image-resource-owned. Preserve the separate catalog-only E0282 from an untyped empty array while fixing Clippy's assertion diagnostic; final schema/query2/2PASS233skip keeps the exact empty inventory expectation. Compiler/Presentation/AgentProtocol check/Clippy and full98 structure exit0. These are separate follow-ups, not an invented7141-case full run.
- Supersedes the owner-cut pending48 statement and intermediate CLI current snapshot; all old counts, failures, full SHAs and raw remain historical. [Exact source/patch identities, actual per-package cases, complete failure sets and verified raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md). The full CLI and final whole-engine milestone remain unaccepted; previously accepted boundaries are not reopened.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){
 if($key -eq 'fontFamily'){foreach($child in $before[$key].Keys){if($child -ne 'state' -and ($before[$key][$child]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key][$child]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous font evidence changed'}}}
 elseif(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous evidence changed'}
}
if($after.fontFamily.fullConsumers.supersededCurrentState -ne $before.fontFamily.state){throw 'Missing state correction history'}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixHash){throw 'History changed'}
[ordered]@{source=$source.commit;full=$terminal.summary;genericPassed=$generic.passed;priorActualEvidenceDrift=0;historyPrefixDrift=0;raw=$record.fontFamily.fullConsumers.raw}|ConvertTo-Json -Depth 5
