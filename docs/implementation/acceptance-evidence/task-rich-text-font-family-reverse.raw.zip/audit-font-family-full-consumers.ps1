$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='font-family-reverse1-20261105'
$terminal=Get-Content -LiteralPath "$taskTemp/$stem.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$catalog=Get-Content -LiteralPath "$taskTemp/$stem.catalog.inventory.json" -Raw|ConvertFrom-Json
$receipt=Get-Content -LiteralPath "$taskTemp/$stem.runtime.json" -Raw|ConvertFrom-Json
$lines=[IO.File]::ReadAllLines($receipt.log)
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0 -or $terminal.caseRowSource -ne 'final-status-after-summary'){throw 'Unexpected terminal case source'}
$packages=@{}
foreach($case in $catalog.rows){if($case.status -eq 'matches'){$packages[$case.binary+"`t"+$case.test]=$case.package}}
$cases=@(foreach($line in $lines[($summary+1)..($lines.Length-1)]){
 if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
  $key=$Matches[2]+"`t"+$Matches[3]
  if(-not $packages.ContainsKey($key)){throw 'Case outside catalog'}
  [pscustomobject]@{package=$packages[$key];binary=$Matches[2];test=$Matches[3];status=$Matches[1]}
 }
})
if($cases.Count -ne $terminal.executed){throw 'Case count differs'}
$groups=@(foreach($group in ($cases|Group-Object package|Sort-Object Name)){
 [ordered]@{package=$group.Name;executed=$group.Count;passed=@($group.Group|Where-Object status -in @('PASS','SLOW')).Count;failed=@($group.Group|Where-Object status -notin @('PASS','SLOW')).Count}
})
$cli=@($groups|Where-Object package -eq 'arcweft-cli')[0]
$otherCases=$terminal.executed-$cli.executed;$otherPass=$terminal.passed-$cli.passed;$otherFail=$terminal.failed-$cli.failed
[ordered]@{version=1;run=$terminal.run;source=$terminal.base;selectedPackages=$terminal.selectedPackages;runtimePackages=$groups.Count;hostBuildOnly=$terminal.noMatchingSelectedTests;cli=$cli;nonCli=[ordered]@{executed=$otherCases;passed=$otherPass;failed=$otherFail};packages=$groups}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/$stem.packages.json" -Encoding utf8
[ordered]@{cli=$cli;nonCli=[ordered]@{executed=$otherCases;passed=$otherPass;failed=$otherFail}}|ConvertTo-Json -Depth 5
