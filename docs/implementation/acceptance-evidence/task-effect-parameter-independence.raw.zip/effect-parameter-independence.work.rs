#![allow(dead_code)]
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;

use decision::{DecisionControl, DecisionWork, EffectDecision};
use std::collections::{BTreeMap, BTreeSet};
use std::convert::Infallible;

#[derive(Default)]
struct Meter { visits: usize, nodes: usize }

impl DecisionControl for Meter {
    type Error = Infallible;

    fn charge(&mut self, work: DecisionWork) -> Result<(), Self::Error> {
        match work {
            DecisionWork::Visit => self.visits += 1,
            DecisionWork::Node => self.nodes += 1,
        }
        Ok(())
    }
}

fn main() -> Result<(), Infallible> {
    for width in [1u8, 2, 4, 8] {
        let mut setup = Meter::default();
        let mut row = EffectDecision::constant(false);
        for variable in 1..=width {
            row = row.or(&EffectDecision::variable(variable, &mut setup)?, &mut setup)?;
        }
        let selector = EffectDecision::variable(0, &mut setup)?;
        let guarded = selector.and(&row, &mut setup)?;
        let formals: BTreeSet<_> = (1..=width).collect();

        let mut prior = Meter::default();
        let mut agreement = EffectDecision::constant(true);
        for formal in &formals {
            let low = guarded.substitute(
                &BTreeMap::from([(*formal, EffectDecision::constant(false))]),
                &mut prior,
            )?;
            let high = guarded.substitute(
                &BTreeMap::from([(*formal, EffectDecision::constant(true))]),
                &mut prior,
            )?;
            let equal = low.conditional(&high, &high.not(&mut prior)?, &mut prior)?;
            agreement = agreement.and(&equal, &mut prior)?;
        }
        let prior_region = agreement.forall(&formals, &mut prior)?;

        let mut current = Meter::default();
        let current_region = guarded.independence_region(&formals, &mut current)?;
        assert_eq!(prior_region, current_region);
        assert_eq!(current_region, selector.not(&mut setup)?);
        println!(
            "formals={} prior_visits={} prior_nodes={} new_visits={} new_nodes={}",
            width, prior.visits, prior.nodes, current.visits, current.nodes,
        );
        assert!(current.visits + current.nodes < prior.visits + prior.nodes);
    }
    Ok(())
}