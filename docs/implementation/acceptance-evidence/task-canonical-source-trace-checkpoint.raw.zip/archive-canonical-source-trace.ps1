$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = 'e2501b733c399d4fa77e959c047b23f086b5989f'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'canonical-source-trace.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='Closed source traces and checked source constructors hold canonical actual/expected ports and feed canonical evidence projection. Their reader accepts the real inference branch and closed effects, including a joint product, while keeping its actual source/application ordinal and operand provenance checks. The existing two-root joint fixture is extended to close an actual source through the same joint branch without making a single-source lineage. The common close_type_operand helper is likewise a branch reader. The intermediate dev02 retained its old source-only signature and produced two new source type errors; that owner boundary is corrected in dev03, with all failures preserved. Prepared container composition remains an internal preparation step and is discarded as the public value authority; source derivations retain its exact proof ports. A canonical operand is issued only after ProjectionClosed on the actual branch and algebra projection using the same principal, preserving the exact origin and occurrence frames. Closing source rows no longer overwrites the original prepared equation actual or pattern: final validation shares the canonical operand allocations with the closed probe and retains the exact completion owner, rejecting an equal-looking replacement owner with different actual inputs. Readonly canonical transport belongs to lexical/operand owners, uses the shared canonical scoped grammar and existing lexical reference rules, and keeps source authority without reopening inference. Original equation fields still use their actual prepared transport; its unresolved graph-loan migration is not hidden by a fallback. The canonical conversion deliberately repeats scoped shape projection for a source operand already prepared for checked-container composition; all work is metered, there is no one-pass/performance claim, production budgets are unchanged, and no source body is prepared or minimum solved again. Two new fixtures cover an actual Named function with local type/const binder inside a named spread, exact canonical constructor/evidence, shared final ports, original C preservation, foreign-completion refusal, and canonical relocation of an ambient reference alongside a nested binder while preserving its source authority. Existing private equation/fixture field users are migrated to closed_relation; old graph and closure callers remain unported. Complete target compilation fails and all new fixtures remain unrun. Final materialization/consumer migration, prepared lexical transport graph ownership, Fn-local quantified/guarded semantics and public acceptance are incomplete. Existing accepted Generic Match and runtime cuts are unchanged. LOC/bytes/growth/path classification and named inline test module sizes are retained. Canonical fields and original prepared provenance have different roles; no second semantic type model, copied side table, fake source, source reconstruction, legacy reader, missing Future default, or compatibility shim is added. Cargo dependency/features, layer direction, I/O, unsafe, codec/version, jobs and profile are unchanged. Existing resolved graph/reverse-dependency evidence is reused, without scanner or broad acceptance claims.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'canonical-source-trace.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'canonical-source-trace.'+$iteration+$suffix}})
$names+=@('canonical-source-trace.source-publication.json','canonical-source-trace.ownership-review.json','canonical-source-trace.staged-review.json','canonical-source-trace.dev03-diagnostic-review.json')
$names+=@('run-canonical-source-trace-check.ps1','archive-canonical-source-trace.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-canonical-source-trace-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-canonical-source-trace-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'canonical-source-trace.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
