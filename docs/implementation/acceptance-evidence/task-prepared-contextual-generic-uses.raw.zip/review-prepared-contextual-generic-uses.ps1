$ErrorActionPreference='Stop'
$scratch='C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$prefix=Join-Path $scratch 'prepared-contextual-generic-uses'
$manifest=Get-Content -Raw -LiteralPath ($prefix+'.dev02-input.json') | ConvertFrom-Json
$result=Get-Content -Raw -LiteralPath ($prefix+'.dev02-result.json') | ConvertFrom-Json
if($result.exit -ne 101 -or $result.fmt_exit -ne 0){throw 'Unexpected validation result'}
$paths=@($manifest.paths.path)
$log=[IO.File]::ReadAllLines($prefix+'.dev02-check.log')
$diagnostics=@(for($i=0;$i -lt $log.Length;$i++){if($log[$i] -match '^error(?:\[|:)'){for($j=$i+1;$j -lt [Math]::Min($i+8,$log.Length);$j++){if($log[$j] -match '^\s*--> (.+\.rs):(\d+):(\d+)'){[PSCustomObject]@{path=$Matches[1].Replace('\','/');line=[int]$Matches[2];error=$log[$i]};break}}}})
$changed=@($diagnostics | Where-Object {$_.path -in $paths})
$core=@($changed | Where-Object {$_.path.EndsWith('/final_analysis/analyzer/expressions.rs') -or $_.path.EndsWith('/types/generic_use.rs')})
@{version=1;inputs=$manifest.paths;target_primary=$changed;regression_file_primary=$core;scope='Primary locations in changed Rust paths. All changed Rust paths are listed, and primary diagnostics in the expression expectations and generic-use regression owners are separately counted. This is a compile diagnostic comparison and does not show runtime acceptance.'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath ($prefix+'.dev02-diagnostic-review.json') -Encoding utf8NoBOM
if((git rev-parse HEAD) -ne '48126e289bb5b45ec6043e6ab0397dea01a2cfca'){throw 'Unexpected HEAD'}
if((git rev-parse origin/main) -ne (git rev-parse HEAD)){throw 'Remote moved'}
foreach($entry in $manifest.paths){if((Get-FileHash -LiteralPath $entry.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256){throw 'Input changed'}}
git add -- $paths
if($LASTEXITCODE -ne 0){throw 'Stage failed'}
$staged=@(git diff --cached --name-only)
if(Compare-Object ($paths | Sort-Object) ($staged | Sort-Object)){throw 'Staged paths differ'}
git diff --cached --check
if($LASTEXITCODE -ne 0){throw 'Diff check failed'}
@{version=1;base=(git rev-parse HEAD);paths=$staged;numstat=@(git diff --cached --numstat);diff=@(git diff --cached --no-ext-diff);reviewed=(Get-Date -Format o);diff_check_exit=0} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($prefix+'.staged-review.json') -Encoding utf8NoBOM
@{paths=$staged;primary_count=$changed.Count;regression_file_primary=$core.Count;by_path=@($changed | Group-Object path | Select-Object Name,Count)} | ConvertTo-Json -Depth 4
git diff --cached --stat
