$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = 'f3131c6f293f5f917e79bf4eaf9fd11f4bb8b30c'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'prepared-scope-predicate.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='TypeConstraintEffectScope retains the actual PreparedEffectPredicate instead of a canonical-only formula. It is the original template contract; reference and issuer admission occurs when the actual application is opened, because an inventory alone cannot authenticate a live term. The existing rollback-capable prepared term edit maps exact local slots to the application opening while captured rigid references remain unchanged. Named and Future applications and all original C are retained without body preparation or an early solver. ConstraintApplicationScope owns the single opened predicate beside its actual opening and function declarations; path start and child admission reuse it, and graph-read validation rejects foreign or stale predicates before publication. The prepared effect environment constructor now takes an actual graph view, validates its whole free-reference inventory and retains this unevaluated predicate; all producers and fixtures are migrated to the one constructor. Existing canonical declaration/schema inputs explicitly enter the prepared domain at their real producer boundary. There is no canonical-only fallback reader or missing Future default. Completed context equality compares declaration inventories without operational predicate term ordinals; restoration still retains and validates its original prepared contract, while the existing canonical solution values, captures and predicate remain the semantic comparison authority. Three new fixtures use actual application scope, original relation freeze and conditional binding: late Named body and explicit nonempty Future completion with missing-Future refusal and no reopening at path start; foreign issuer and parameter refusal with term rollback and subsequent valid registration; and distinct prepared predicate IDs yielding equal canonical solutions, with different canonical values remaining unequal. Existing relation/predicate-agreement and original joint-branch fixtures use their actual graph views. All fixtures remain unrun because locked Sema target checking fails. New source diagnostics in the original canonical-only unconstrained shortcut were fixed using the explicit Canonical predicate case; this proves only an available literal truth, never solves an unfinished term. Final compilation, Fn-local quantified and guarded contracts, general predicate equivalence, source-function schema factory, nominal/frontend switch, actual original-product callback dispatch and broad body-once/public acceptance remain unfinished. New owner growth is cohesive application opening, predicate retention and completed semantic identity; tests follow the application boundary. No allocation/copy preflight completeness, single-pass, performance or workspace success claim is made. No dependency/feature, facade, layer reversal, I/O, unsafe, codec/version, budget, jobs or profile changes are introduced. Accepted Generic Match/runtime results and unchanged resolved graph/reverse-dependency evidence are retained; scanner and broad checks are unrun.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'prepared-scope-predicate.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'prepared-scope-predicate.'+$iteration+$suffix}})
$names+=@('prepared-scope-predicate.source-publication.json','prepared-scope-predicate.ownership-review.json','prepared-scope-predicate.staged-review.json','prepared-scope-predicate.dev03-diagnostic-review.json')
$names+=@('run-prepared-scope-predicate-check.ps1','archive-prepared-scope-predicate.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-prepared-scope-predicate-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-prepared-scope-predicate-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'prepared-scope-predicate.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
