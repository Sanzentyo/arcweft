$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
$checkpoint=Get-Content -Raw "$root/result-port-provenance.checkpoint-publication.json" | ConvertFrom-Json
$pin=[ordered]@{Version=1;Base=(git rev-parse HEAD);ChangeBase=$checkpoint.Parent;Paths=$checkpoint.Paths}
if($pin.Base -ne $checkpoint.Commit){throw 'Unexpected source checkpoint'}
$pin | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$root/result-port-provenance.final-input.json"
$steps=@()
function Step($name,$arguments,$output,$log) {
    foreach($p in $pin.Paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256){throw 'Source changed'}}
    $start=Get-Date
    & cargo @arguments 1>"$root/$output" 2>"$root/$log"
    $code=$LASTEXITCODE
    foreach($p in $pin.Paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256){throw 'Source changed'}}
    $script:steps+= [pscustomobject]@{Name=$name;Arguments=$arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;PinsVerified=$true}
    [ordered]@{Version=1;Base=$pin.Base;CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false;Steps=$script:steps} | ConvertTo-Json -Depth 7 | Set-Content -Encoding utf8 "$root/result-port-provenance.final-validation.json"
    Write-Output "$name exit=$code"
    if($code -ne 0 -and $name -ne 'owner-run'){throw "$name failed"}
}
Step 'owner-list' @('nextest','list','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--message-format','json') 'result-port-provenance.final-owner-list.json' 'result-port-provenance.final-owner-list.log'
Step 'owner-run' @('nextest','run','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--no-fail-fast','--no-tests','fail','--message-format','libtest-json-plus') 'result-port-provenance.final-owner-results.jsonl' 'result-port-provenance.final-owner-run.log'
Step 'clippy' @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features') 'result-port-provenance.final-clippy.stdout' 'result-port-provenance.final-clippy.log'
Step 'fmt' @('fmt','--all','--','--check') 'result-port-provenance.final-fmt.stdout' 'result-port-provenance.final-fmt.log'
