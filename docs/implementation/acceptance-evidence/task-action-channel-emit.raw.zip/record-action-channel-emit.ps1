$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$t/assert-no-arcweft-build.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$t/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$publication=Receipt 'checkpoint-action-channel-emit.verified'
if((git rev-parse HEAD).Trim() -ne $publication.commit){throw 'Publication changed'}
$source=Receipt 'action-channel-emit-runtime4-20261103.runtime.terminal-audit'
$core=Receipt 'action-channel-emit-core2-20261103.runtime.terminal-audit'
if(-not $source.isPassingRun -or $source.executed -ne 4 -or -not $core.isPassingRun -or $core.executed -ne 2245){throw 'Final acceptance subset differs'}
$freeze=Receipt 'action-channel-emit-core2-20261103.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Final source drift'}}
$quality=@(foreach($name in @('check','clippy','structure')){$r=Receipt "action-channel-emit-quality3-20261103-$name";if($r.exitCode -ne 0){throw 'Final quality failed'};$r})
$graph=Receipt 'action-channel-storage.reverse-graph'
foreach($row in $graph.graphInputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Graph inputs changed'}}
$original=Receipt 'task-documentation-final-untracked-before'
foreach($row in $original.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$raw='docs/implementation/acceptance-evidence/task-action-channel-emit.raw.zip'
$record='docs/implementation/acceptance-evidence/task-action-channel-emit.json'
if((Test-Path $raw) -or (Test-Path $record)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $t -File|Where-Object {$_.Name -match '^(action-channel-emit|checkpoint-action-channel-emit[.])'})
$files+=@(Get-Item "$t/record-action-channel-emit.ps1","$t/run-presentation-projection-owner.ps1","$t/audit-nextest-final-result.ps1","$t/run-action-payload-quality.ps1","$t/action-channel-storage.reverse-graph.json")
foreach($directory in (Get-ChildItem -LiteralPath $t -Directory|Where-Object Name -Match '^action-channel-emit.*[.]structure-report$')){$files+=@(Get-ChildItem -LiteralPath $directory.FullName -File -Recurse)}
$files=@($files|Sort-Object FullName -Unique)
$entries=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($t.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Raw count mismatch'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Raw entry mismatch'}}}finally{$zip.Dispose()}
$metrics=Import-Csv "$t/action-channel-emit-quality3-20261103.structure-report/file_metrics.csv"
$basePaths=@(git ls-tree -r --name-only $publication.parent)
$measurements=@(foreach($path in $publication.paths.path){
    $old=@();if($path -in $basePaths){$old=@(git show ($publication.parent+':'+$path))}
    $metric=@($metrics|Where-Object path -EQ $path)
    [ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;physicalLoc=@([IO.File]::ReadLines([IO.Path]::GetFullPath($path))).Count;baseLoc=$old.Count;owner=$(if($metric.Count){$metric[0].owner}else{'documentation'});classification=$(if($metric.Count){$metric[0].classification}else{'maintained specification'});embeddedTestLoc=$(if($metric.Count){[int]$metric[0].embedded_test_lines}else{0})}
})
$evidence=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');status='intermediate-source-emission-checkpoint';source=$publication.commit;publication=$publication
    scope='Source emit is projected into the shared evaluated-effect/plan/Source codec and AWBC typed payload/codec/verifier, then executed by the actual Native original operation or Product VM/session owner. Receive/wait/cancel and the full reverse closure remain unfinished.'
    ownership='The selected program owns Action declarations and payload schemas. A queued address retains semantic payload type plus its original RuntimeNominalDeclarationId claim, validated against that same authority before copying, restore or replacement. No alternate Action schema/catalog or live queue Clone/Serde. Native checks destination/capacity before operand evaluation; Product reserves through borrowed value admission before register transfer. Refusal preserves custody via original rollback/checkpoint and nontrapping typed VM errors. All owned version markers remain1.'
    initialCompile=(Receipt 'action-channel-emit-quality1-20261103-check')
    preliminaryQuality=@(foreach($name in @('check','clippy','structure')){Receipt "action-channel-emit-quality2-20261103-$name"})
    firstSourceCases=(Receipt 'action-channel-emit-runtime1-20261103.runtime.terminal-audit')
    initialFourCases=(Receipt 'action-channel-emit-runtime2-20261103.runtime.terminal-audit')
    repairs=@('The initial owner check failed101 because the verifier arm omitted its successful Ok(()).','The first two source cases passed; two additional cases then failed on their pinned uncommitted inputs over base62af78be9649fb33e44a637217d0883b6ba9086a. Original declaration replacement was accepted with the same semantic ID/digest/shape/layout, and missing session authority trapped/unwound instead of returning with its operand register intact.','Retained messages now keep an original declaration address claim and reject mismatch against the selected type row. Inert saves carry that claim in version1 directly. Dedicated Action context/admission errors are execution refusals that retain the exact frame/cursor and budget. No assertion was weakened; the refusal test now names that typed nontrapping error rather than the previous trapping MissingExecutionContext.','The repaired four cases passed in runtime3 and all2245 Core cases passed in core1. A final shared prospective-capacity preflight was then placed before Native operand evaluation; runtime4/core2 and all owner gates rerun on the final production bytes.')
    repairedSourceCases=(Receipt 'action-channel-emit-runtime3-20261103.runtime.terminal-audit')
    preliminaryCore=(Receipt 'action-channel-emit-core1-20261103.runtime.terminal-audit')
    finalSource=$source;finalCore=$core;finalQuality=$quality;format=(Receipt 'action-channel-emit-format-check')
    finalBehavior=@('Direct and effectful-function Native and canonical-decoded Product each return42, with no Host task request or LineEffect proxy.','Each Product step passes through JSON inert save and cold restore; exactly one queued payload42 retains the original Action declaration and semantic payload type.','Without session authority the VM refuses before changing the operand frame or source cursor.','A program that changes only original Action identity while preserving semantic ID, producer digest, shape and layout is refused without changing the session holding its queued message.')
    sourceInputs=$freeze.paths.Count;sourceDrift=0;caseAndExecutableDrift=0;finalRunsReusePriorPasses=$false
    reverseGraph=[ordered]@{root=$graph.root;count=$graph.count;graphInputDrift=0;reference='task-action-channel-storage.json';raw='action-channel-storage.reverse-graph.json';scope='Resolved53-package Core closure is unchanged. This checkpoint executes the Core library and four Compiler source cases, and all-target check/Clippy for Core/RuntimePlan/Compiler. Full closure and workspace acceptance remain pending.'}
    structuralReview=[ordered]@{measurements=$measurements;disposition='Mailbox address/value custody remains in Core action; program_types owns original declaration lookup; Native action and VM resources own their real execution capabilities; existing snapshot and rollback owners retain session state. Compiler/RuntimePlan only project the same evaluated-effect algebra, and Source/wire codecs preserve it. No dependency or I/O boundary changed. Existing large dispatcher/snapshot/semantic owners keep their cohesive closed dispatch responsibilities, with no new schema authority, source reconstruction or public API widening for physical splitting.'}
    originalWip=[ordered]@{tracked=12;untracked=6;heldPatchSha256=$publication.heldPatchSha256;untrackedHashDrift=0}
    priorCompleteConsumerSource='7104b200150b9b85b31cd686c48573b92b2028d3';genericMatch='Accepted and published; new Action queue/refusal defects do not reopen Generic Match or prior declaration identity acceptance.'
    raw=[ordered]@{path=$raw;bytes=(Get-Item $raw).Length;sha256=(Get-FileHash $raw).Hash.ToLowerInvariant();entries=$entries;entryDrift=0}
}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($evidence|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$status=[IO.Path]::GetFullPath('docs/implementation/current-status.md');$text=[IO.File]::ReadAllText($status)
$header="確認日: 2026-11-03。最新公開Sourceは$($publication.commit)（Action送信のowner実行を検証した中間checkpoint）。直近の全consumer検証はSource 7104b200150b9b85b31cd686c48573b92b2028d3の通常9194件PASS。今回の送信4件・Core2245件と3 owner gateを、受信や全consumer／全workspaceの受入とはしない。既存12 tracked／6 actual untracked WIPを保持している。"
$text=[regex]::Replace($text,'(?m)^確認日:[^\r\n]*',[Text.RegularExpressions.MatchEvaluator]{param($m)$header})
$pattern='(?m)^\| Action宣言・payload record／型付きチャンネル値 \|[^\r\n]*'
if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Current Action row differs'}
$text=[regex]::Replace($text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m)
    $row=$m.Value.Replace('**宣言・payload identityの受入を維持。送受信前段を実装中**','**宣言・payload identityの受入を維持。emitのowner実行を検証、receiveは未完**');$cut=$row.IndexOf('前段b014');if($cut -lt 0){throw 'Replaced current wording absent'}
    $row.Substring(0,$cut)+"共通callable／通常call構文の前段739件は[前段実測](acceptance-evidence/task-action-channel-front.json)、保持基盤23df0a9242d5baf528610f78563022300db99949の旧実測は[保持境界](acceptance-evidence/task-action-channel-storage.json)へ保持する。送信Source $($publication.commit)は元operation／programとセッションキューへ接続し、Native／decoded Productが42を返す。毎stepのJSON保存・cold restoreでも元Actionのpayload42を一度だけ保持する。新4件とCore全2245件は最終入力ですべて新規PASS、Core／RuntimePlan／Compilerのall-target check／Clippyと構造gateは終了0。同じ型ID等でのAction宣言差替えと、context不足のtrapを新テストで再現・修復し、元宣言claim照合と値／cursorを保持する拒否へ移行した。receiveの実行・待機／キャンセル、53 package逆依存と全workspace受入は未完。[初回失敗・修復・最終実測](acceptance-evidence/task-action-channel-emit.json)。 |"
})
[IO.File]::WriteAllText($status,$text,[Text.UTF8Encoding]::new($false))
$history=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md');$before=[IO.File]::ReadAllBytes($history);$prefixSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant()
$append=@"


## Action送信のowner実行checkpoint — 2026-11-03

Source $($publication.commit)、parent $($publication.parent)、tree $($publication.tree)、35 path／705 insertions／51 deletions、full patch SHA256 $($publication.patchSha256)。EmitActionを共通effect／plan／元Source codecとAWBC typed payload／codec／verifierへ接続し、元Native operationとProductのactual program／sessionが配送する。Host taskやLineEffect proxy、別Action schemaやlegacy readerは追加していない。Nativeのprospective queue capacityはoperand評価前、Productはborrowed value／capacity admission後にregisterを移す。

最初のcheckはverifierのOk(())欠落で101。修正後のquality2は3 ownerのcheck／Clippy／構造0で、初回source2件は2 PASS。その後、追加した拒否2件を含むruntime2の4件は2 PASS／2 FAILだった。同じsemantic ID・producer digest・shape・layoutのままAction PublicIdを変えたprogram置換が通り、missing mailboxがtrap／unwindして元registerを保持できなかった。これは当該新キュー境界の具体的な未達であり、Generic Matchや既受入Action declaration identityを未完了へ戻す理由ではない。初回WIPの実測はbase62af78be9649fb33e44a637217d0883b6ba9086aと4089入力hashへ結び、修復後Sourceの実行として扱わない。

キューのaddress claimへ元RuntimeNominalDeclarationIdを保持し、選択programの既存type rowと照合するよう修復した。version1 inert saveも同じclaimへ直接移行し、旧readerは残さない。Action context／admissionは実行前拒否として元frame／cursor／budgetを保持する。従来のtrapping MissingExecutionContextではなく、専用のnontrapping typed errorをテストし、値／cursor保持のassertionは維持した。runtime3の4件とcore1の2245件はすべてPASS。その後、共通capacity header preflightをNative評価前へ接続した最終入力でruntime4の4／4 PASS（0.201s）、core2の2245／2245 PASS（14.832s）、Core／RuntimePlan／Compiler all-target／all-feature／locked check・Clippyとcanonical構造gateの終了0を新規確認した。4089入力・case／EXE差分0、警告は残る。最終runで以前の成功は再利用していない。

直接送信とeffectful function内の送信はNative／canonical decoded Productが実戻り値42となり、毎stepのJSON保存／cold restoreでも元Actionのpayload42をちょうど一度保持する。session authorityなしのregister／cursor保持と、元宣言差替えprogramへの置換拒否／session保持も確認した。receive・待機／キャンセルと53 package Core逆依存・全workspace受入は未完。保持基盤Source23dfの「2242 PASS＋fixture3再実行」という旧現状説明は、今回の全2245件新規PASSへ置き換えて現状一覧一か所へ集約した。旧実測・SHA・失敗は前節と原本へ保持し、完了項目を戻していない。既存12 tracked／6 untracked WIPもhash照合して保持した。

raw $($entries.Count) entries／$($evidence.raw.bytes) bytes、SHA256 $($evidence.raw.sha256)、全entry hash差分0。[入力・失敗・修復・構造判断・最終実測・公開照合](acceptance-evidence/task-action-channel-emit.json)。
"@
$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream=[IO.File]::Open($history,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$stream.Write($bytes)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($history);$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixSha){throw 'Historical prefix changed'}
[ordered]@{source=$publication.commit;rawEntries=$entries.Count;rawBytes=$evidence.raw.bytes;rawSha256=$evidence.raw.sha256;preservedHistoryBytes=$before.Length;preservedHistorySha256=$prefixSha;historyPrefixDrift=0}|ConvertTo-Json
