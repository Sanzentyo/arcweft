$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$publication = Get-Content -Raw -LiteralPath (Join-Path $root 'retained-probe.publication.json') | ConvertFrom-Json
$consumer = Get-Content -Raw -LiteralPath (Join-Path $root 'retained-probe.consumer-summary.json') | ConvertFrom-Json
if ($consumer.completedSteps -ne 107 -or -not $consumer.failureIdsUnchanged) { throw 'Consumer evidence is not audited.' }
$files = [Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File | Where-Object {
    $_.Name -match '^(retained-probe[.-]|audit-retained-probe|run-retained-probe|make-retained-probe)' -and
    $_.Name -notin @('retained-probe.manifest.json', 'retained-probe.archive.json', 'retained-probe.docs-publication.json')
} | Sort-Object Name | ForEach-Object { $files.Add([ordered]@{name=$_.Name; path=$_.FullName}) }
Get-ChildItem -LiteralPath (Join-Path $root 'retained-probe-reverse') -File -Recurse | Sort-Object FullName | ForEach-Object {
    $files.Add([ordered]@{name=[IO.Path]::GetRelativePath($root, $_.FullName).Replace('\','/'); path=$_.FullName})
}
$entries = @($files | ForEach-Object {
    $item = Get-Item -LiteralPath $_.path
    [ordered]@{name=$_.name; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant()}
})
$manifest = [ordered]@{
    version=1; source=$publication.Source; tree=$publication.Tree; base=$publication.Base
    phases=@(
        [ordered]@{name='initial'; tree='595d3757eb11bb5ae95c632a4f8002f45682985d'; ownerSelected=1536; passed=1529; failed=7; note='Includes the change-caused 256-candidate budget regression; not the final input.'},
        [ordered]@{name='final'; tree=$publication.Tree; ownerSelected=1537; passed=1531; failed=6; note='Original observation allocation retains preparation; production budgets and coverage unchanged.'}
    )
    files=$entries
}
$manifestPath = Join-Path $root 'retained-probe.manifest.json'
$manifest | ConvertTo-Json -Depth 12 | Set-Content -Encoding utf8 -LiteralPath $manifestPath
$files.Add([ordered]@{name='manifest.json'; path=$manifestPath})
$archivePath = 'D:\git\arcweft\docs\implementation\acceptance-evidence\task-retained-source-probe-preparation.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Refusing to overwrite a frozen archive.' }
$zip = [IO.Compression.ZipFile]::Open($archivePath, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.path, $file.name, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $files.Count) { throw 'Archive entry count mismatch.' }
    foreach ($file in $files) {
        $entry = $zip.GetEntry($file.name)
        $original = Get-Item -LiteralPath $file.path
        if ($null -eq $entry -or $entry.Length -ne $original.Length) { throw ('Archive length mismatch: ' + $file.name) }
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() }
        finally { $stream.Dispose() }
        if ($hash -ne (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()) { throw ('Archive hash mismatch: ' + $file.name) }
    }
    $rawBytes = ($zip.Entries | Measure-Object Length -Sum).Sum
} finally { $zip.Dispose() }
$archive = Get-Item -LiteralPath $archivePath
[ordered]@{
    version=1; source=$publication.Source; tree=$publication.Tree; entries=$files.Count
    rawBytes=$rawBytes; bytes=$archive.Length
    sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
    verifiedEveryEntryIncludingManifest=$true
} | ConvertTo-Json | Set-Content -Encoding utf8 -LiteralPath (Join-Path $root 'retained-probe.archive.json')
Get-Content -LiteralPath (Join-Path $root 'retained-probe.archive.json')
