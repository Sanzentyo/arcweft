$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$reverse = Join-Path $root 'retained-probe-reverse'
$receipt = Get-Content -LiteralPath (Join-Path $reverse 'retained-probe-reverse-results.json') -Raw | ConvertFrom-Json
$plan = Get-Content -LiteralPath (Join-Path $reverse 'retained-probe-reverse-plan.json') -Raw | ConvertFrom-Json
if ($receipt.completedSteps -ne $receipt.plannedSteps -or $receipt.completedSteps -ne $plan.steps.Count) { throw 'Consumer run is not terminal.' }
$ids = [Collections.Generic.List[object]]::new()
$counts = [Collections.Generic.List[object]]::new()
foreach ($step in $receipt.steps) {
    if ($step.selectionExit -ne 0) { throw ('Selection failed: ' + $step.name) }
    foreach ($identity in $step.identities) { $ids.Add($identity) }
    $selection=Get-Content -LiteralPath (Join-Path $reverse ($step.name+'.selection.json')) -Raw | ConvertFrom-Json
    $excludedIgnored=[Collections.Generic.List[object]]::new()
    foreach($suite in $selection.'rust-suites'.PSObject.Properties){
        foreach($case in $suite.Value.testcases.PSObject.Properties){
            if($case.Value.ignored -and $case.Value.'filter-match'.status -eq 'mismatch' -and $case.Value.'filter-match'.reason -eq 'ignored'){
                $identity=[pscustomobject]@{binary=$suite.Name; name=$case.Name; ignored=$true}
                $excludedIgnored.Add($identity); $ids.Add($identity)
            }
        }
    }
    $passed = 0; $failed = 0; $skipped = 0
    if ($step.selectedRunnable -gt 0) {
        $log = Get-Content -LiteralPath (Join-Path $reverse ($step.name + '.nextest.log')) -Raw
        $summary = [regex]::Matches($log, '(?m)^\s*Summary \[[^\]]+\]\s+(\d+) tests? run:\s+(\d+) passed(?:\s+\([^)]*\))?(?:,\s+(\d+) failed(?:\s+\([^)]*\))?)?,\s+(\d+) skipped')
        if ($summary.Count -ne 1) { throw ('Missing or multiple terminal summaries: ' + $step.name) }
        $m=$summary[0]; $passed=[int]$m.Groups[2].Value; $failed=if($m.Groups[3].Success){[int]$m.Groups[3].Value}else{0}; $skipped=[int]$m.Groups[4].Value
        if (($passed+$failed) -ne $step.selectedRunnable -or $skipped -ne ($step.selectedIgnored + $excludedIgnored.Count)) { throw ('Terminal/selection count mismatch: ' + $step.name) }
        if (($failed -eq 0 -and $step.runExit -ne 0) -or ($failed -gt 0 -and $step.runExit -eq 0)) { throw ('Exit/test count mismatch: ' + $step.name) }
    } elseif ($null -ne $step.runExit) { throw ('Empty target unexpectedly ran: ' + $step.name) }
    $counts.Add([pscustomobject][ordered]@{name=$step.name; package=$step.package; target=$step.target; passed=$passed; failed=$failed; skipped=$skipped; result=$step.result; summary=$step.summary})
}
$duplicates = @($ids | Group-Object binary,name | Where-Object Count -ne 1)
if ($duplicates.Count -ne 0) { throw 'Duplicate selected consumer IDs.' }
$packages=@($receipt.steps.package | Sort-Object -Unique)
$expected=@($plan.closure | Where-Object {$_ -ne $plan.owner} | Sort-Object)
if (@(Compare-Object $expected $packages).Count -ne 0) { throw 'Consumer package coverage mismatch.' }
$owner=Get-Content -LiteralPath (Join-Path $root 'retained-probe.fixed-owner-summary.json') -Raw | ConvertFrom-Json
[ordered]@{
    version=1; source=$receipt.source; stagedTree=$receipt.tree; graphBaselineSource='518d63e31dd2be9750158004b171a6174b2725a7'; graphCargoInputsUnchanged=$true
    plannedSteps=$plan.steps.Count; completedSteps=$receipt.completedSteps; consumerPackages=$packages
    featureMode='host-default consumers; all-features owner'; consumerPassed=($counts | Measure-Object passed -Sum).Sum; consumerFailed=($counts | Measure-Object failed -Sum).Sum; consumerSkipped=($counts | Measure-Object skipped -Sum).Sum
    ownerPassed=$owner.passed; ownerFailed=$owner.failed; ownerSkipped=$owner.Skipped
    compiledZeroRunnable=@($receipt.steps | Where-Object result -eq 'compiled-no-runnable-tests').name
    selectedConsumerIds=($receipt.steps | Measure-Object selectedRunnable -Sum).Sum; distinctConsumerCaseIds=$ids.Count; duplicateConsumerIds=$duplicates.Count; terminalSelectionCountsMatch=$true; steps=$counts.ToArray()
} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $root 'retained-probe.consumer-summary.json') -Encoding utf8
Write-Output ('Audited ' + $receipt.completedSteps + ' consumer targets and ' + $ids.Count + ' distinct selected identities.')





$published = Get-Content -Raw -LiteralPath (Join-Path $root 'retained-probe.publication.json') | ConvertFrom-Json -Depth 20
if ($receipt.source -ne $published.Source -or $receipt.tree -ne $published.Tree) { throw 'Consumer source does not match publication.' }
function Get-FailedCases($evidenceDirectory, $runReceipt) {
    $failedCases = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($failedStep in @($runReceipt.steps | Where-Object { $null -ne $_.runExit -and $_.runExit -ne 0 })) {
        $failedLog = Get-Content -Raw -LiteralPath (Join-Path $evidenceDirectory ($failedStep.name + '.nextest.log'))
        foreach ($match in [regex]::Matches($failedLog, '(?m)^\s*FAIL\s+\[[^\]]+\]\s+(?:\([^)]*\)\s+)?(?<binary>\S+)\s+(?<test>\S+)\s*\r?$')) {
            [void]$failedCases.Add($match.Groups['binary'].Value + '::' + $match.Groups['test'].Value)
        }
    }
    @($failedCases | Sort-Object)
}
$currentFailures = @(Get-FailedCases $reverse $receipt)
$baselineDirectory = Join-Path $root 'retained-work-reverse'
$baselineReceipt = Get-Content -Raw -LiteralPath (Join-Path $baselineDirectory 'type-domain-reverse-results.json') | ConvertFrom-Json -Depth 40
$baselineFailures = @(Get-FailedCases $baselineDirectory $baselineReceipt)
if (@(Compare-Object -CaseSensitive $baselineFailures $currentFailures).Count -ne 0) { throw 'Consumer failure IDs changed.' }
$summaryPath = Join-Path $root 'retained-probe.consumer-summary.json'
$summary = Get-Content -Raw -LiteralPath $summaryPath | ConvertFrom-Json -Depth 40
$summary | Add-Member -NotePropertyName failureIdsUnchanged -NotePropertyValue $true
$summary | Add-Member -NotePropertyName failureIds -NotePropertyValue $currentFailures
$summary | Add-Member -NotePropertyName baselineSource -NotePropertyValue '344a6f6f61359268c19ebee202b75cbb974f1799'
$summary | ConvertTo-Json -Depth 40 | Set-Content -Encoding utf8 -LiteralPath $summaryPath
Write-Output ('Verified unchanged failure IDs: ' + $currentFailures.Count)