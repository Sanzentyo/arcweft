$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
. "$taskTemp/convergence-image-git-bytes.ps1"
$stem='existing-consumer-fixture-checkpoint-20261108'
$base=(git rev-parse HEAD).Trim()
if($base -ne 'c96539d2fa8107fac34b03bf7568cbb4ce7b16a5' -or (git branch --show-current).Trim() -ne 'main' -or @(git diff --cached --name-only).Count){throw 'Unexpected base/index'}
$baseline=Get-Content "$taskTemp/checkpoint-task-view.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$untracked=Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json -Depth 30
$adopted=@(
 'crates/arcweft-cli/tests/check/agent_script_debug.rs',
 'crates/arcweft-cli/tests/check/profile_entry_selection.rs',
 'crates/arcweft-runtime-host/src/native_task.rs',
 'samples/agent-script/cli-read-resource-metadata-smoke.awfagent',
 'samples/agent-script/cli-read-resource-smoke.awfagent',
 'samples/agent-script/cli-read-resource-value-smoke.awfagent',
 'samples/agent-script/native-choice-dispatch.arcw',
 'samples/agent-script/native-project-graph-relations.arcw',
 'samples/agent-script/native-visual-regression.arcw'
)
$remaining=@($baseline.held|Where-Object {$_ -notin $adopted})
if($baseline.held.Count -ne 12 -or $remaining.Count -ne 3 -or @($adopted|Where-Object {$_ -notin $baseline.held}).Count){throw 'Held path set differs'}
$patch=Read-GitBytes (@('diff','--binary','--full-index','--')+$baseline.held)
$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant()
if($hash -ne 'c838778adff4d217c794fa25650a77069777260a0df22f27528be31eb3fca53c' -or $hash -ne $baseline.heldPatchSha256){throw 'Original user bytes changed'}
foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked changed'}}
$historical=@('docs/implementation/2026-10-09-cli-bench-repair.md','docs/implementation/2026-10-09-cli-observe-repair.md')
$root=(Resolve-Path 'docs/implementation').Path+[IO.Path]::DirectorySeparatorChar
foreach($path in $historical){if(-not (Get-Item -LiteralPath $path).FullName.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)){throw 'Historical target outside evidence directory'}}
$beforePaths=@(foreach($path in $baseline.held){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
[IO.File]::WriteAllBytes("$taskTemp/$stem.original-held.patch",$patch)
$adoptedPatch=Read-GitBytes (@('diff','--binary','--full-index','--')+$adopted)
[IO.File]::WriteAllBytes("$taskTemp/$stem.adopted.patch",$adoptedPatch)
$remainingPatch=Read-GitBytes (@('diff','--binary','--full-index','--')+$remaining)
[IO.File]::WriteAllBytes("$taskTemp/$stem.remaining-held.patch",$remainingPatch)
$remainingHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($remainingPatch)).ToLowerInvariant()
[ordered]@{version=1;base=$base;originalHeld=$baseline.held;originalHeldPatchSha256=$hash;adopted=$adopted;remaining=$remaining;remainingHeldPatchSha256=$remainingHash;files=$beforePaths;originalUntracked=$untracked;recordedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 30|Set-Content "$taskTemp/$stem.input-before.json"
$archive='docs/implementation/acceptance-evidence/task-existing-consumer-fixture-checkpoint.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
$files=@(
 [pscustomobject]@{path="$taskTemp/$stem.original-held.patch";entry='original-held.patch'},
 [pscustomobject]@{path="$taskTemp/$stem.adopted.patch";entry='adopted.patch'},
 [pscustomobject]@{path="$taskTemp/$stem.remaining-held.patch";entry='remaining-held.patch'},
 [pscustomobject]@{path="$taskTemp/$stem.input-before.json";entry='input-before.json'},
 [pscustomobject]@{path="$taskTemp/prepare-existing-consumer-fixture-checkpoint-20261108.ps1";entry='prepare-checkpoint.ps1'}
)+@(foreach($path in $historical){[pscustomobject]@{path=$path;entry=('historical/'+(Split-Path $path -Leaf))}})
$entries=@(foreach($file in $files){[ordered]@{entry=$file.entry;bytes=(Get-Item -LiteralPath $file.path).Length;sha256=(Get-FileHash -LiteralPath $file.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Resolve-Path -LiteralPath $file.path).Path,$file.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);$stream=$entry.Open();try{$actual=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($actual -ne $row.sha256 -or $entry.Length -ne $row.bytes){throw 'Archive content differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$base;originalHeldPatchSha256=$hash;adopted=$adopted;remainingHeld=$remaining;remainingHeldPatchSha256=$remainingHash;beforeFiles=$beforePaths
 scope='Checkpoint nine pre-existing consumer fixture/API migrations without editing their source bytes. Resource scripts consume typed Result/body variants and assert actual metadata; CLI profiles execute real initializers/reducers/measured flows and assert nonzero work; graph metadata expectations come from accepted semantic APIs. Sample Flow results are explicit. Runtime-host changes remove two unused test imports.'
 validation='These bytes already participated in the recorded 711-case CLI corpus (707 pass / four separately tracked failures), unchanged original WIP hash c838778adff4d217c794fa25650a77069777260a0df22f27528be31eb3fca53c, and current workspace gates. No extra intermediate-commit test run is required by the user. New AWBC source reverse runtime remains independently in progress and is not claimed complete.'
 sourceFreeze='The running non-CLI epoch remains frozen at its recorded composite source. This Git checkpoint changes no Rust/sample input bytes. The subsequent CLI epoch additionally inventories .awfagent inputs. Earlier raw held=14 labels and 12/6 WIP observations remain historical, not the new live inventory.'
 documentation=[ordered]@{removed=$historical;reason='Dated pending lists (98/166 baseline failures and old first-boundary plans) were superseded by item-level current-status and complete newer runtime records. Remove their misleading current-state surface; preserve every original byte, test result, and full SHA in this raw history. Generic Match and all earlier accepted cuts stay accepted.';originalUntracked=6;remainingUntracked=4}
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledger='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledger));$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'existingConsumerFixtureCheckpoint'){throw 'Record exists'}
$fragment=([ordered]@{existingConsumerFixtureCheckpoint=$record}|ConvertTo-Json -Depth 100).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}');$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($p in $old.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($p.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Historical record changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledger),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath).Replace('既存12 tracked／6 actual untracked WIPを保持している。','既存差分の9ファイルをcheckpointし、3 tracked／4 actual untracked WIPを保持している。')
$status=$status.Replace('履歴中の古い現在形・計画や、保持したuntrackedの2026-10-09 CLI修復メモを、そのまま現在の残作業へ転記しない。','履歴中の古い現在形・計画を、そのまま現在の残作業へ転記しない。')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$addition=@"

## 2026-11-08 — 既存consumer差分のcheckpoint・旧CLI現状メモの整理

確認Source **$base**。旧12 tracked WIPの全patch SHA-256 **$hash** を確認し、そのうちresource API／CLI profile／sample Flowの契約同期9ファイルを、内容を変更せず独立checkpointへ採用した。元12ファイルと採用9・保留3のpatch、各file hashをrawへ保全する。実行中のAWBC全逆依存は同じ物理Source入力を使い、checkpointを新しいテスト実行や全体完了とはしない。

旧untrackedの2026-10-09-cli-bench-repair.md／2026-10-09-cli-observe-repair.mdは、98／166 baseline失敗や途中first-boundaryを現在の残作業に見せる資料で、後続の完了監査・公開SHA・全CLI終端により置き換わったため現状資料から削除する。元の全本文・実測・full SHAをrawへ保存し、既存126 recordは変更しない。現状一覧はcurrent-status.md一か所を維持し、Generic Match等の既受入を戻さない。保留は3 tracked／4 actual untracked、元ファイル内容は保持する。[元差分・訂正理由・旧記録](acceptance-evidence/task-flow-registry-execution.json)。raw7 entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::AppendAllText($historyPath,"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$cleanupPath=Join-Path (Get-Location) 'docs/implementation/documentation-cleanup.md'
[IO.File]::AppendAllText($cleanupPath,"`n## 2026-11-08 — 旧CLI修復メモ2件`n`n2026-10-09-cli-bench-repair.md と 2026-10-09-cli-observe-repair.md の途中状態・残作業列挙は、後続の項目別受入と全CLI終端で置き換わったため削除した。実際の検証結果・full SHA・元本文は [checkpoint原本](acceptance-evidence/task-existing-consumer-fixture-checkpoint.raw.zip) に保全した。現状は [現状一覧](current-status.md) を参照する。`n",[Text.UTF8Encoding]::new($false))
foreach($path in $historical){Remove-Item -LiteralPath $path}
$untracked.files=@($untracked.files|Where-Object {$_.path.Replace('\','/') -notin $historical})
if($untracked.files.Count -ne 4){throw 'Remaining untracked inventory differs'}
$untracked|ConvertTo-Json -Depth 30|Set-Content "$taskTemp/task-documentation-final-untracked-before.json"
$stageBaseline=Get-Content "$taskTemp/checkpoint-task-view.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$stageBaseline.held=$remaining;$stageBaseline.heldPatchSha256=$remainingHash
$stageBaseline|ConvertTo-Json -Depth 30|Set-Content "$taskTemp/$stem.publish-baseline.json"
$prepare=Get-Content "$taskTemp/checkpoint-explicit-wide-prepare.ps1" -Raw
$prepare=$prepare.Replace('checkpoint-task-view.source-freeze.json',"$stem.publish-baseline.json")
$prepare|Set-Content "$taskTemp/prepare-existing-consumer-checkpoint-stage-20261108.ps1"
$owned=$adopted+@($ledger,'docs/implementation/current-status.md','docs/implementation/convergence-evidence-history.md','docs/implementation/documentation-cleanup.md',$archive)
$owned|Set-Content "$taskTemp/$stem.owned.txt"
[IO.File]::WriteAllText("$taskTemp/$stem.other.txt",'')
'chore: checkpoint consumer fixture migrations and retire stale CLI status notes'|Set-Content "$taskTemp/$stem.message.txt"
foreach($row in $beforePaths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original source bytes changed'}}
& "$taskTemp/prepare-existing-consumer-checkpoint-stage-20261108.ps1" -Prefix $stem
[ordered]@{base=$base;adopted=$adopted;remaining=$remaining;heldPatchSha256=$remainingHash;removedHistorical=$historical;rawEntries=$entries.Count;rawSha256=$record.raw.sha256;earlierRecordsPreserved=$old.PSObject.Properties.Name.Count}|ConvertTo-Json -Depth 10|Set-Content "$taskTemp/$stem.pre-publication.json"
Get-Content "$taskTemp/$stem.pre-publication.json"
