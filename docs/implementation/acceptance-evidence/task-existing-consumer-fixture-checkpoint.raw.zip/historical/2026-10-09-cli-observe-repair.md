# CLI observe fixture and argument grammar repair — 2026-10-09

Status: in progress. The acceptance target is all 166 baseline failures in
`arcweft-cli::check`, namespace `agent_observe_native`. No test is skipped or
excluded to discharge that target.

Inspected Git base: `df6b213f1cb31d7db5ce878501e4a24371c6987c` on the existing
`main` checkout. The initial working tree contained the parent's frozen Core
codec work and goal note. Those files are outside this repair owner's edits.

## Ownership and changes

- CLI test modules own `NativeCliFixture`, which pairs one source path with
  the caller-authored typed `EntryRuntimeId` and carries that launch into
  observe, hit-test, and resource-read subprocesses. It does not discover an
  entry by scanning source or restore an implicit production launch.
- `samples/rich-text-windows-fonts.arcw` declares its String flow result and
  removes look choices for which the standalone sample provides no character
  manifest. Its font, text, and Fx demonstrations are preserved.
- `samples/rich-text-full-grammar.arcw` uses typed layout ruby properties,
  an integer Fx weight, a declared ordinary `flash` callback, and complete
  timed-call arguments. The String flow result is explicit.
- `samples/image-animation.arcw` replaces the removed module-scope image
  declaration with ordinary image calls. The nine entry IDs, five asset IDs,
  object and target IDs, playback time, bounds, alignment, opacity, transform,
  actions, metadata, and proxies are retained.
- The closed builtin `MotionFunction` domain rejects an unknown motion at
  semantic admission. Its obsolete render-time missing-function test becomes
  compile-rejection coverage; the maintained effects chapter is reconciled.

The additional shared language work owns the complete dotted named-argument
path grammar and the numeral-leading attached-body ambiguity. The parent owns
prepared-text coordinate mapping, source-map/resource inventory, and other
production repairs. All Arcweft contract version markers remain at 1.

## Evidence

- Passed: direct `rustfmt --edition 2024` on the changed Rust test modules.
- Passed: built `target/debug/arcw.exe check` for the updated Windows-fonts
  sample (six line task groups) and full-grammar sample (eleven line task
  groups), each with no warnings or obligations.
- Passed: scoped `git diff --check` after the first fixture migration.
- Not run by this owner: Cargo, nextest, Clippy, or transitive reverse-dependency
  validation. The parent coordinates those commands centrally.
- The parent's frozen pre-repair non-CLI nextest run passed 5,042 tests. That
  receipt describes its original bytes and is not validation of these edits.

The image sample and full observe suite still require validation after the
shared named-argument and attached-body owner repairs. Geometry, typed proxy,
and Fx observation expectations remain under investigation; neither the first
patch nor the sample checks establish complete acceptance.

## Current range/catalog source checkpoint

The parent subsequently allocated the complete prepared-text range, catalog,
geometry, capture, and transport boundary to this owner. The one checked Model
context now owns source/display/prepared conversions. Observation catalogs share
the actual stage and `Arc<TextLayout>` once per owner. Typed factories issue
element/parent identities; object, Objects, hit-test, and image envelopes validate
their scoped references and element metadata. Bounded decoding retains version 1
and rejects detached, mismatched, excessive, or obsolete per-object frame data.

Glyphon derives geometry from already evaluated paint; the renderer and observer
share the actual View affine, including nested and repeated paint occurrences.
The View/CSS-to-glyphon matrix adapter uses the appropriate row/column convention
for both origins and raster shapes. Native bounds, hit proxies, Web painted
geometry, and capture selections consume this projection. Capture binds actual
prepared owner/context/layout allocations and maps display Ruby ordinals to the
retained renderer ordinals. Later-page glyph reveal uses the owning conversion.

Capture resources carry the producer's closed raw pixel format. PNG/raw semantics,
stride, extent, and query-bearing URI handling are explicit. CLI capture fixtures
retain authored launch and element identities while selecting each observation's
issued ID/URI. Clear-page assertions require current page 1 and rendered content;
the old empty-crop expectation is removed. AdvanceText dispatch resolves the issued
root context's typed dialogue/entry identity rather than reconstructing an ID.

Actual central evidence: Model range cases 6/6 PASS within the parent's 20/20 run;
protocol 34/34 and Host 56/56 PASS at the earlier constructor checkpoint;
protocol 35/35 PASS after orientation/hit-region integrity coverage; compiler
5/5 plus full 158/158 PASS and the owning compiler/Plan/protocol Clippy gate PASS.
The last full CLI receipt predates this range migration: 399/605 PASS, with 206
failures (205 original IDs and one new MCP failure). Our original 166-case scope
was 56 PASS / 110 FAIL there. These are distinct historical receipts.

Passed locally: `node --check web/tests/text-parity-smoke.mjs` after its painted
geometry/context consumer migration. The new renderer, native capture, Web,
and full CLI range acceptance is pending central execution. No Cargo/fmt/Git is
run by this owner in this phase. Image command ABI, Content source trace,
retained View authoring, and the remaining original CLI failures stay unfinished.

## Baseline failure inventory

The retained diagnostics are
`C:/Users/sanze/AppData/Local/Temp/arcweft-1009-codec-preflight-cli-failure-diagnostics.json`.
Categories below are initial observed failure stages; later entry repairs can
expose another stale expectation in the same test.

### Geometry or typed observation expectation — 31

- `agent_observe_native::agent_hit_test_reports_depth_sorted_rich_text_proxy`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_accented_latin_word_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_apostrophe_western_word_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_greek_latin_unit_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_hyphenated_western_word_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_european_numeral_sequence_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_accented_latin_word_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_jlreq_preset_specific_column_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_decomposed_accented_latin_word_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_numeric_abbreviation_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_numeric_separator_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_numeric_unit_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_parenthesized_reference_mark_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_reference_mark_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_numeric_unit_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_subscript_object_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_plain_western_word_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_unit_symbol_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_published_jlreq_western_word_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_strict_jlreq_closing_opening_column_plan`
- `agent_observe_native::agent_observe_native_renderer_reports_strict_jlreq_paragraph_class_mix_geometry`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_apostrophe_western_word_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_european_numeral_sequence_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_ideographic_numeric_abbreviation_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_numeric_prefix_abbreviation_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_numeric_separator_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_numeric_suffix_abbreviation_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_parenthesized_reference_mark_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_subscript_object_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_reference_mark_raw_crops`
- `agent_observe_native::agent_observe_reports_explicit_rich_text_proxy_struct_metadata`

### Incomplete ordinary timeline/View call — 3

- `agent_observe_native::agent_observe_native_renderer_reports_full_grammar_sample_vertical_inference_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_full_grammar_sample_rich_text_constructs`
- `agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering`

### Missing explicit launch entry — 101

- `agent_observe_native::agent_observe_native_renderer_applies_shader_glyph_color_phase`
- `agent_observe_native::agent_observe_json_reports_rich_text_reset_controls_and_host_markers`
- `agent_observe_native::agent_observe_native_renderer_applies_shader_post_process_phase`
- `agent_observe_native::agent_hit_test_capture_time_follows_animated_text_proxy_bounds`
- `agent_observe_native::agent_observe_native_capture_step_defaults_capture_time_for_typewriter`
- `agent_observe_native::agent_observe_native_renderer_applies_builtin_effect_post_process_phase`
- `agent_observe_native::agent_observe_native_renderer_reports_capture_step_metadata`
- `agent_observe_native::agent_observe_native_renderer_reports_fullwidth_bracket_pair_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_jlreq_paragraph_column_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_jlreq_line_end_prohibited_opening_punctuation`
- `agent_observe_native::agent_observe_native_renderer_reports_fullwidth_question_mark_hanging_punctuation`
- `agent_observe_native::agent_observe_native_renderer_reports_expanded_jlreq_normal_pair_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_halfwidth_middle_dot_and_prolonged_sound_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_halfwidth_ideographic_comma_hanging_punctuation`
- `agent_observe_native::agent_observe_native_renderer_reports_halfwidth_corner_bracket_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_fullwidth_colon_semicolon_hanging_punctuation`
- `agent_observe_native::agent_observe_native_renderer_reports_halfwidth_small_kana_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_halfwidth_full_stop_hanging_punctuation`
- `agent_observe_native::agent_observe_native_renderer_reports_expanded_jlreq_pair_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_jlreq_punctuation_compression_and_hanging`
- `agent_observe_native::agent_observe_native_renderer_reports_katakana_phonetic_extension_small_kana_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_long_vertical_ruby_expansion_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_small_curly_and_tortoise_bracket_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_short_vertical_rl_ruby_at_edge`
- `agent_observe_native::agent_observe_native_renderer_reports_small_parenthesis_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_strict_jlreq_middle_dot_opening_pair_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_strict_jlreq_middle_dot_pair_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_cluster_orientation_metadata`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_column_progression_direction`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_grapheme_cluster_metadata`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_lr_ruby_text_combine_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_lr_jlreq_paragraph_column_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_inter_character_ruby_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_lr_jlreq_edge_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_presentation_compact_bracket_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_presentation_curly_and_square_bracket_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_presentation_leader_chain_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_ruby_collision_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_ruby_under_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_two_dot_leader_chain_geometry`
- `agent_observe_native::agent_observe_native_renderer_reports_vertical_zwj_cluster_metadata`
- `agent_observe_native::agent_observe_native_renderer_writes_fullwidth_colon_semicolon_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_fullwidth_bracket_pair_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_fullwidth_question_mark_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_halfwidth_corner_bracket_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_halfwidth_middle_dot_and_prolonged_sound_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_halfwidth_full_stop_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_halfwidth_ideographic_comma_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_halfwidth_small_kana_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_compact_bracket_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_compressed_punctuation_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_compressed_punctuation_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_dash_mark_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_iteration_mark_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_leader_mark_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_opening_punctuation_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_prolonged_sound_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_small_kana_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_katakana_phonetic_extension_small_kana_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_jlreq_opening_punctuation_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_overheight_vertical_ruby_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_long_vertical_ruby_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_long_vertical_ruby_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_small_parenthesis_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_small_curly_and_tortoise_bracket_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_strict_jlreq_middle_dot_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_strict_jlreq_middle_dot_opening_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_grapheme_cluster_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_compact_bracket_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_inter_character_ruby_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_compact_bracket_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_compressed_punctuation_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_compressed_punctuation_object_id_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_hanging_punctuation_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_dash_mark_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_hanging_punctuation_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_dash_mark_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_iteration_mark_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_iteration_mark_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_leader_mark_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_leader_mark_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_opening_punctuation_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_opening_punctuation_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_prolonged_sound_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_prolonged_sound_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_small_kana_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_ruby_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_jlreq_small_kana_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_ruby_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_strict_jlreq_middle_dot_object_id_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_lr_strict_jlreq_middle_dot_mask_raw_crop`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_presentation_compact_bracket_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_presentation_leader_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_presentation_curly_and_square_bracket_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_ruby_under_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_two_dot_leader_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_zwj_cluster_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_text_glyph_raw_crops`
- `agent_observe_native::agent_observe_native_rich_text_reports_structured_visual_diagnostics`
- `agent_observe_native::agent_observe_reports_signal_and_visual_effects`
- `agent_observe_native::agent_observe_reports_text_presentation_z_index_depth`

### Numeral-leading attached body recovery — 6

- `agent_observe_native::agent_observe_native_renderer_reports_vertical_goal_clear_smoke_geometry`
- `agent_observe_native::agent_observe_native_renderer_writes_vertical_goal_clear_smoke_raw_crops`
- `agent_observe_native::agent_observe_native_typewriter_text_combine_capture_time_controls_object_id`
- `agent_observe_native::agent_observe_native_typewriter_text_combine_capture_time_controls_all_glyphs`
- `agent_observe_native::agent_observe_native_vertical_lr_typewriter_text_combine_capture_time_controls_all_glyphs`
- `agent_observe_native::agent_observe_native_vertical_lr_typewriter_text_combine_capture_time_controls_object_id`

### Prepared source/display coordinate mismatch — 3

- `agent_observe_native::agent_observe_native_renderer_captures_clear_after_page_object`
- `agent_observe_native::agent_observe_native_renderer_captures_clear_after_page_layer`
- `agent_observe_native::agent_observe_native_renderer_handles_clear_in_rich_text_layer_capture`

### Removed flat CharacterDialogue color option — 1

- `agent_observe_native::agent_observe_json_reports_rich_text_display_objects`

### Removed image declaration grammar — 8

- `agent_observe_native::agent_observe_image_alignment_sample_uses_authored_alignment_geometry`
- `agent_observe_native::agent_observe_native_captures_clipped_animated_image_object`
- `agent_observe_native::agent_observe_mcp_tool_result_preserves_animated_image_object_metadata_and_raw_blob`
- `agent_observe_native::agent_hit_test_capture_time_updates_unpinned_animated_image_frame_metadata`
- `agent_observe_native::agent_hit_test_reports_animated_image_object_proxy_metadata`
- `agent_observe_native::agent_observe_read_uri_preserves_animated_image_layer_frame_pixels`
- `agent_observe_native::agent_observe_reports_missing_scope_for_released_image_handle_object`
- `agent_observe_native::agent_observe_read_uri_preserves_animated_image_object_frame_metadata`

### Stale cluster object identity — 10

- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_accented_latin_word_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_accented_latin_word_class_mix_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_decomposed_accented_latin_word_class_mix_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_greek_latin_unit_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_hyphenated_western_word_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_numeric_unit_class_mix_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_numeric_unit_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_plain_western_word_class_mix_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_unit_symbol_class_mix_raw_crops`
- `agent_observe_native::agent_observe_native_renderer_writes_published_jlreq_western_word_class_mix_raw_crops`

### Unadmitted final semantic type — 3

- `agent_observe_native::agent_observe_native_renderer_reports_windows_fonts_sample_vertical_rl_geometry`
- `agent_observe_native::agent_observe_native_renderer_writes_sample_full_frame_png_vertical_captures`
- `agent_observe_native::agent_observe_native_rich_text_reports_missing_motion_diagnostics_in_image_resources`
