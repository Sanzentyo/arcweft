# CLI runtime and benchmark repair — 2026-10-09

Inspected `main` at `df6b213f1cb31d7db5ce878501e4a24371c6987c` in the existing `D:/git/arcweft` checkout.
The initial observed tree contained the frozen Core codec changes and the existing
convergence goal note; they are not part of this agent's fixture migration.
The root agent owns Cargo, nextest, validation selection, commits, and pushes.

Scope: 98 failed `arcweft-cli::check` cases attributed to
`crates/arcweft-cli/tests/check/cli_runtime_bench.rs` in the 277-record diagnostics
at `C:/Users/sanze/AppData/Local/Temp/arcweft-1009-codec-preflight-cli-failure-diagnostics.json`.
This note records root-cause families rather than treating every terminal
`sema.final_analysis` message as the same production bug.

## Current work

- CLI inputs declare real Flow results. Omitted results lower to `OmittedUnit`;
  returning a String or sequence from that contract is stale test source.
- Runtime launches and measured benchmark targets declare/select explicit entries.
  Scenario entries bind their actual state, initializer, event, and reducer.
- Signal/metric declaration names, `bool`/`char`, reserved bindings, typed marks,
  and value-block syntax follow the maintained grammar.
- All 40 benchmark fixtures now declare entries/results. Array mapping preserves
  its fixed length. Moved Vec inputs are reassigned as whole locals before later
  loops, preserving the original workload without implicit copies.
- `run --flow --value` remains supported. The unsupported option is confined to
  benchmark commands; its dense source replacements remain in progress.
- The runtime line-handle case now consumes the actual current fixture under
  `spec_should_pass/check/011_dialogue_line_value_and_handle_discard.arcw` and
  selects its existing `entry.main`; no duplicate run fixture was created.
- The nonexistent `spec_should_fail/018_private_full_replay_rejected.arcw`
  tuple was removed from the edge-case loop. Its Source declaration/full-replay
  grammar was replaced by external capability Streams. Privacy/replay policy
  belongs to the capability/host adapter boundary described by
  [Streams and generators](../02-runtime/streams-generators.md); this repair
  does not claim replacement privacy coverage.
- Math, bounded traversal, source pure roots, empty AWBC source maps, promotion,
  proof, and presentation resource gaps retain their owning production boundaries.
  No failing tests are silenced; existing skips are recorded separately and acceleration/assertion expectations remain active.

## Owners and contracts

Maintained references: [entries and capabilities](../01-language/entries-and-capabilities.md),
[dense types and prelude](../01-language/standard-types-and-prelude.md),
[traits, map, and traversal](../01-language/traits-seq-ranges.md),
[unary Need and Await](../01-language/await-need-result.md),
[value blocks and ownership](../01-language/block-scopes.md), and
[converged content surface](../01-language/converged-language-surface.md).

Runtime-plan's empty source-map fallback currently emits Block(0) even when the
program contains no blocks. The root agent owns the repair; Core's verifier
correctly rejects that invalid location.

The dense Matrix/Tensor runtime values and kernels exist, but source Sema signatures
still use unresolved Named placeholders; their accepted source and runtime type
projections need one complete typed owner. The local dense repair uses the
existing mathematical value/type boundary, not payload-string casts.

Maintained bounded `Vec.traverse(capability.fn).parallel(limit = N)` has runtime
`AwaitMany` support but no corresponding checked standard callable or final Flow
producer. Its repair must reuse that producer/scheduler authority and preserve
source order, limit validation, domain Result payloads, and task identity.

Root-owned repairs: promotion/proof contract diagnosis, empty AWBC source maps,
pure/JIT ordinary source callable roots, and shared display admission.
The observe agent owns `samples/image-animation.arcw`; this agent owns its bundle
and runtime assertions and the benchmark fixture directory.

## Validation

- Passed: `git diff --check` for the assigned Rust test and benchmark fixture paths.
- Not run by this agent: Cargo, nextest, fmt, check, and Clippy (root owns them).
- Root baseline evidence: non-CLI reverse-dependency run completed with 5042/5042
  passing, 6 slow tests, 16 skipped tests, 816.917 seconds. It ran before these
  fixture edits and is not acceptance evidence for this migration.
- Pending: exact CLI test execution, owner/consumer checks for dense/traversal,
  and the final root validation record.

## Per-test ledger

Current observed checkpoint:47953,15 PASS/83 FAIL out of the original98. The baseline family describes the original failure; the current boundary records only the first observed failure. Proposed next changes do not imply downstream acceptance.

| Test ID | Baseline family | 47953 | Current first boundary | Change/status |
| --- | --- | --- | --- | --- |
| `bench_json_batches_bracket_sequence_pure_aot_on_worker_pool` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_batches_bracket_sequence_pure_jit_calls` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_batches_map_closure_pure_aot_on_worker_pool` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_batches_map_closure_pure_jit_calls` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_can_measure_aot_executor_sections` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `current_executor_control_operation_counts` | Compare current emitted operations/return intent from observed JSON; preserve fast-path/behavior assertions. |
| `bench_json_checks_runtime_assert_sections` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `bench_json_fails_native_file_assertions` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `bench_json_fails_runtime_assert_sections` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `bench_json_fuses_bracket_sequence_pure_sum_jit_calls` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_fuses_map_closure_pure_sum_jit_calls` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_measures_branching_for_loop_pure_jit_characteristics` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_measures_checked_in_branching_iter_pure_jit_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_measures_checked_in_dense_f32_map_pure_batch_fixture_with_auto_jit` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_candidate_metric` | Migrate the storage-count consumer with the owning ordinary FunctionSite candidate metric; retain actual acceleration counts. |
| `bench_json_measures_checked_in_dense_f64_map_pure_batch_fixture_with_auto_jit` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_candidate_metric` | Migrate the storage-count consumer with the owning ordinary FunctionSite candidate metric; retain actual acceleration counts. |
| `bench_json_measures_checked_in_dense_i128_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_i32_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_integer_widths_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_scalar_len_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |
| `bench_json_measures_checked_in_dense_target_size_integer_map_pure_batch_fixtures` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_textual_scalar_len_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |
| `bench_json_measures_checked_in_dense_u128_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_u32_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_u64_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_dense_wide_numeric_len_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `bench_json_measures_checked_in_hot_for_pure_auto_jit_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_candidate_metric` | Migrate the storage-count consumer with the owning ordinary FunctionSite candidate metric; retain actual acceleration counts. |
| `bench_json_measures_checked_in_inferred_pure_jit_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_measures_checked_in_large_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |
| `bench_json_measures_checked_in_linear_aot_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `current_executor_control_operation_counts` | Compare current emitted operations/return intent from observed JSON; preserve fast-path/behavior assertions. |
| `bench_json_measures_checked_in_matrix_add_f64_math_fixture` | `DENSE_SOURCE` | FAIL | `bench_authored_dense_construction` | Replace unsupported bench --value arguments with typed authored Matrix/Tensor values; keep valid run bindings. |
| `bench_json_measures_checked_in_matrix_f64_math_fixture` | `DENSE_SOURCE` | FAIL | `bench_authored_dense_construction` | Replace unsupported bench --value arguments with typed authored Matrix/Tensor values; keep valid run bindings. |
| `bench_json_measures_checked_in_mixed_aot_prefix_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `current_executor_control_operation_counts` | Compare current emitted operations/return intent from observed JSON; preserve fast-path/behavior assertions. |
| `bench_json_measures_checked_in_mixed_for_iter_pure_jit_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_measures_checked_in_mixed_width_for_iter_pure_jit_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_candidate_metric` | Migrate the storage-count consumer with the owning ordinary FunctionSite candidate metric; retain actual acceleration counts. |
| `bench_json_measures_checked_in_nonuniform_map_pure_batch_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |
| `bench_json_measures_checked_in_scalar_for_pure_jit_perf_guard` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_candidate_metric` | Migrate the storage-count consumer with the owning ordinary FunctionSite candidate metric; retain actual acceleration counts. |
| `bench_json_measures_checked_in_small_dense_integer_map_pure_batch_fixtures` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `sum_builder_result_i64` | Exact builder fix and3 regressions applied/refrozen; central validation pending; retain downstream batch/JIT assertions. |
| `bench_json_measures_checked_in_system_info_thread_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `authored_spawn_effect_upper_bound` | Declare the actual control.spawn effect while retaining scheduled work and counters. |
| `bench_json_measures_checked_in_tensor_f64_math_fixture` | `DENSE_SOURCE` | FAIL | `bench_authored_dense_construction` | Replace unsupported bench --value arguments with typed authored Matrix/Tensor values; keep valid run bindings. |
| `bench_json_measures_checked_in_thread_scheduling_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `bench_json_measures_checked_in_wide_for_pure_jit_fixture` | `BENCH_FIXTURE_RESULT_ENTRY` | FAIL | `ordinary_function_candidate_metric` | Migrate the storage-count consumer with the owning ordinary FunctionSite candidate metric; retain actual acceleration counts. |
| `bench_json_measures_for_loop_pure_jit_without_arg_vec_allocation` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `ordinary_function_acceleration_runtime_counter` | Remaining owner repairs source FunctionSite execution/acceleration; expected calls/items are retained. |
| `bench_json_measures_headless_runtime_sections` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |
| `bench_json_measures_native_file_tasks` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `bench_json_measures_profile_inference_matmul_bias_adapter_fixture` | `DENSE_SOURCE` | FAIL | `bench_authored_dense_construction` | Replace unsupported bench --value arguments with typed authored Matrix/Tensor values; keep valid run bindings. |
| `bench_json_measures_pure_helper_with_vm_aot_and_jit` | `EMPTY_AWBC_AND_PURE_ROOT` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `bench_json_measures_runtime_match_to_pure_jit_characteristics` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `current_executor_control_operation_counts` | Compare current emitted operations/return intent from observed JSON; preserve fast-path/behavior assertions. |
| `bench_json_measures_thread_scheduling_characteristics` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `bench_json_measures_threaded_native_read_scheduling` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `authored_spawn_effect_upper_bound` | Declare the actual control.spawn effect while retaining scheduled work and counters. |
| `bench_json_measures_traverse_parallel_file_tasks` | `TRAVERSE_OWNER` | FAIL | `traversable_source_producer` | Connect checked Traverse/parallel to existing Need/AwaitMany/task admission, order and limit contracts. |
| `bench_json_skips_adapter_only_script_benches` | `EMPTY_AWBC_AND_PURE_ROOT` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `bench_json_validates_headless_script_benches` | `BENCH_METADATA_DECLARATION` | FAIL | `current_metric_policy_body` | Use the maintained braced metric policy body, preserving gauge/ratio observations. |
| `bundle_json_packages_image_animation_sample_assets_and_run_bundle_validates_them` | `PRESENTATION_RESOURCE` | FAIL | `observe_owned_image_source_or_asset_contract` | Observe owns the source schema/asset producer; benchmark-side identities and assertions are retained. |
| `bundle_json_packages_save_files_and_run_bundle_executes_native_file_tasks` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `check_accepts_state_write_effect_contract` | `REGISTRY_EFFECT_OWNER` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `cli_json_selects_cli_entry_and_binds_args` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `plan_json_lists_runtime_task_graph` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `current_content_style_scope_and_source_trace` | Use4 real lexical modifier scopes plus owning ProductSourceRef trace; preserve typography/color precedence. |
| `profile_check_accepts_explicit_route_parameters` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `profile_check_rejects_ambient_route_params` | `CURRENT_REJECTION_DIAGNOSTIC` | FAIL | `exact_current_ambient_name_rejection` | Keep ambient name rejection and assert the current exact source owner/diagnostic. |
| `profile_json_can_select_aot_executor_without_absolute_source` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `profile_json_reports_phase_timings_and_runtime_stats_without_absolute_source` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |
| `profile_json_reports_runtime_math_backend_selection` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `profile_json_runs_native_file_tasks_without_absolute_source` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `profile_rejects_unknown_adapter` | `CURRENT_REJECTION_DIAGNOSTIC` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `rejected_await_question_with_fixture_fails_with_guidance` | `FIXTURE_REJECTIONS` | PASS | `obsolete_await_question_check_retirement_pending` | Removed-await? check and its unreferenced011 fixture are retired in the current cut;47953 PASS was transitional and no replacement coverage is claimed. |
| `run_bundle_rejects_image_asset_metadata_mismatch_before_execution` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `observe_owned_image_source_or_asset_contract` | Observe owns the source schema/asset producer; benchmark-side identities and assertions are retained. |
| `run_json_can_select_aot_executor` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `current_executor_control_operation_counts` | Compare current emitted operations/return intent from observed JSON; preserve fast-path/behavior assertions. |
| `run_json_executes_f64_math_intrinsic_with_cli_matrix_bindings` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `dense_source_type_catalog` | Complete the existing Dense numeric type/catalog/checked/runtime/entry projections with Value ABI. |
| `run_json_executes_math_intrinsic_with_cli_matrix_bindings` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `dense_source_type_catalog` | Complete the existing Dense numeric type/catalog/checked/runtime/entry projections with Value ABI. |
| `run_json_executes_native_file_tasks_through_bytecode_vm` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `run_json_executes_scope_and_loop_value_bindings` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `maintained_labeled_loop_parser_hir_projection` | Repair the maintained labeled block/loop projection and keep labeled break/goto result intent. |
| `run_json_executes_source_thread_through_scheduler_marker` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `awbc_real_child_fiber_ledger_boundary` | Use the actual child-fiber/journal owner; no fake marker handle or partial public task-plan switch. |
| `run_json_executes_traverse_parallel_file_tasks` | `TRAVERSE_OWNER` | FAIL | `traversable_source_producer` | Connect checked Traverse/parallel to existing Need/AwaitMany/task admission, order and limit contracts. |
| `run_json_fuses_jit_map_closure_pure_sum` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `function_site_control_transfer` | Remaining owner repairs the exact ordinary function control-transfer ingress; preserve map/fusion execution assertions. |
| `run_json_modes_and_budget_drive_engine_step_boundary` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `run_json_observes_line_child_tasks_through_scheduler` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `current_line_with_thread_grammar_and_ledger` | Migrate old colon child grammar to the current authored child contract; retain scheduler/task assertions. |
| `run_json_reports_headless_observations` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `current_metric_policy_body` | Use the maintained braced metric policy body, preserving gauge/ratio observations. |
| `run_json_reports_runtime_system_info_tasks` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `selected_manifest_system_info_adapter_projection` | Project canonical selected SystemInfo request once for dispatch/parallel/stats; retain3 typed operations and String Result output. |
| `run_json_steps_runtime_plan` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `run_json_uses_jit_for_map_closure_pure_batch` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `function_site_control_transfer` | Remaining owner repairs the exact ordinary function control-transfer ingress; preserve map/fusion execution assertions. |
| `serve_json_lists_server_routes` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `canonical_entry_argument` | Select the existing canonical entry.* ID; no source launch fallback. |
| `serve_json_treats_server_run_entry_as_default_route` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `canonical_entry_argument` | Select the existing canonical entry.* ID; no source launch fallback. |
| `serve_json_typechecks_explicit_route_parameters` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `canonical_entry_argument` | Select the existing canonical entry.* ID; no source launch fallback. |
| `serve_profile_alias_lists_server_routes` | `INLINE_RESULT_ENTRY_GRAMMAR` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `spec_rejected_edge_fixtures_fail_with_diagnostics` | `FIXTURE_REJECTIONS` | FAIL | `isolate_break_yield_out_current_contract` | Current String-return fixture candidates isolate actual illegal transfer; validate exact rejection before expectation changes. |
| `spec_valid_run_edge_fixture_now_executes` | `FIXTURE_REJECTIONS` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `test_json_executes_headless_scenario_expectations` | `SCENARIO_ENTRY` | FAIL | `actual_runtime_diagnostic_pending` | First failure observed; exact runtime JSON/control/expectation trace must be obtained before changing expectations. |
| `test_json_lists_script_tests` | `SCENARIO_ENTRY` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `tooling_commands_reject_direct_non_arcw_paths` | `CURRENT_REJECTION_DIAGNOSTIC` | FAIL | `delete_removed_ids_materialize_tuple` | Retire only the removed ids materialize command tuple; retain current extension and command rejections. |
| `unsafe_json_lists_audit_regions` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_accepts_effect_capability_from_flow_contract` | `VERIFIER_SOURCE` | PASS | `passed_current_checkpoint` | Observed PASS in47953; retain the current substantive test. |
| `verify_json_records_required_solver_checks` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_reports_effect_capability_obligation` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_reports_invalid_proof_body` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_reports_missing_promotion_proof` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_reports_semantic_thread_join_conflict` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_reports_unknown_proof_dependency` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_json_respects_semantic_defer_cancel_discharge` | `VERIFIER_SOURCE` | FAIL | `root_owned_typed_contract` | Root owns the typed proof/promotion/state/audit/Needs disposition repair; substantive assertions remain. |
| `verify_types_json_reports_type_and_runtime_validation_without_absolute_source` | `INLINE_RESULT_ENTRY_GRAMMAR` | FAIL | `removed_compiler_profile_consumer` | Consume current semantic facts/accounting and named project phases; preserve runtime results/counters and path redaction. |

## Historical first owner checkpoint

The checkpoint adds checked nested Map result inference, typed collection len/sum
producer and consumer paths, deterministic integer accumulation, forged AWBC
collection signature rejection, and maintained braced bench assert sections.
Dense construction, Traverse, source Thread, and remaining fixture changes have
not been applied at this checkpoint.

Observed root logs:

- `arcweft-1009-cli-production-assert-repair-targeted.log`: 3/3 pass,
  0.034 seconds. Covers both new syntax/HIR assert regressions and the restored
  existing structured/lossless test.
- `arcweft-1009-cli-production-syntax-hir-full.log`: 1672/1672 pass,
  1 slow, 8 skipped, 189.422 seconds.
- Workspace check is still being repaired/retried by the root owner. The two
  parser results are not acceptance evidence for pending Sema/Core/CLI changes.

The full original 98-test ledger retains the first migrated CLI diagnostic
status. Current-source CLI behavioral acceptance remains pending; no acceleration,
proof, source-thread, or traversal assertion is reduced to make the checkpoint pass.

Focused Map rejection followthrough (frozen; central validation pending):
- Terminal 54147 retained ExpressionTypeUnavailable at unannotated Closure Expr28, authored `|item| score(item)`; the closure-body/block-tail guards alone did not repair it. Root's Never dead-loop case passed in the same 2-test run.
- Both executable ingress and residual completion retried missing raw Call arguments without parent context. The closure candidate's contextual locals had correctly rolled back after the mismatch; independently checking that closure could not recover its input type.
- Current prepared Call outcome now projects HirSelectedCallExpressionDisposition::Unselected. It validates exact authored source arity and ownership through the existing inventory, but selects no callback operands/body/local owners. Unrelated missing selected facts still fail through the existing graph.
- Only admitted Call inventories can request completion of physically expanded argument containers. Declaration-local and expression-owned statement completion, effect preparation, and final semantic graph publication consume the same owning graph.
- Unselected call sealing retains source-backed call diagnostics and candidate evidence without minting executable operand coordinates. The selected HIR inventory validates source ownership before final sealing.
- All three precise negative callback assertions are retained; added unselected-call no-execution assertion. New HIR regression also rejects forged source arity.
- Phase paths: crates/arcweft-lang-hir/src/final_project/{selected_expressions.rs,tests.rs}; crates/arcweft-lang-sema/src/final_analysis/{match_edges.rs,tests/collections.rs,analyzer/{executable_ingress.rs,preparation.rs,pending_effects.rs,call_seal.rs}}.
- git diff --check passed; no Cargo/fmt run by bench agent. Parent central focused regression and remaining Never tests are pending.

Focused recovery checkpoint validation:
- 83584: compiler terminated 101 before tests; declaration graph helper incorrectly named flat project graph. Corrected all consumers to HirSelectedDeclarationExpressionGraph and retained typed contains_statement / contains_local projections.
- 22919: 13 tests, 11 PASS / 2 FAIL. HIR still retained callback Local; Map shifted from Expr28 missing type to Pattern30 missing type. Owner publication had filtered syntax regions without filtering admitted expression paths/scopes.
- 40674: 14 tests, 13 PASS / 1 FAIL. HIR rejected/admitted owner coverage, exact Sum rejection, Map positive, and Never all passed; Map negative exposed transient receiver Expr26 as UnexpectedExpressionFact.
- 30466: TERMINAL0, 14/14 PASS, 0.233s, run1610487d-c3ab-4209-b21d-4a17349d7098. All three Map negative forms retain exact enclosing-call NoViableSignature/source span and deny execution. HIR rejects forged arity, excludes failed callback Local/Pattern/Scope, and retains admitted callback/declaration locals. Sum requires exact UnknownCallTarget(Method,sum), exact values.sum() span/receiver and registered Vec<bool> parameter type. Never cases remained passing.
- Final semantic input publishes only canonical selected graph expression facts; transient recovery receiver/callee query/type facts remain preparation-owned. Strict unexpected/missing fact validation remains unchanged.
- Removed the obsolete private detached unselected inventory duplicate that caused one new ordinary warning; canonical prepared source inventory is retained.
- All repository source, fixtures, samples, and docs are frozen for root's actual reverse-dependency/full-nextest/CLI/check/Clippy/wasm validation. Broad acceptance and CLI failure recovery are not yet verified. Bench agent ran no Cargo/fmt.

Full reverse-dependency followthrough:
- 26226: TERMINAL, actual 4760 selected tests all executed, 4754 PASS / 6 FAIL, 643.969s / 24 skips; outer script exit 1. These six failures are new checkpoint repair inputs, separate from the original 277 CLI failures.
- NonCallable source inventory regressed: `value(identity(1i64))` correctly checked its nested argument without a candidate context, but the generic Unselected graph omitted that accepted nested root. Typed NonCallable source disposition now retains its already-checked source operands/callee. Runtime traversal still requires Callable. The test preserves exact accounting and verifies nested I64 plus outer no-execution.
- Two Character look negatives and one callback Array-length negative now produce an inspectable typed rejection instead of an incidental checker invariant failure. Observe and remaining agents retain their original inputs and now assert exact rejected candidate/schema/source-backed Error NoViableSignature and denied execution. No Character schema or Array-length rule is relaxed.
- OnActivate's effectful-handler rejection retained a transient Method query fact while omitting its rejected callee from the final selected graph. Method completeness now uses the same canonical structural membership. Its exact OnActivate/closed-empty handler contract, sole source-backed NoViableSignature, authored Whole span, and no-execution assertions remain mandatory.
- The ambiguous enum/placeholder test previously treated physical candidate 0's projection as a final expression authority. Both candidate contexts are now observed through the existing bounded physical query transcript, including each actual source type and closed observed function effect row. Neither candidate source is published as final expression authority; the ambiguous application remains unselected.
- Narrow touched paths: `crates/arcweft-lang-hir/src/final_project/selected_expressions.rs`; `crates/arcweft-lang-sema/src/final_analysis/{accounting.rs,error.rs,match_edges.rs,tests.rs,tests/call_diagnostics.rs,analyzer/state.rs,analyzer/preparation.rs,analyzer/executable_ingress.rs,analyzer/calls/constraints.rs}`. Other agents' two Character test hunks and Array test are preserved.
- Narrow candidate is frozen; scoped git diff --check passed. Parent focused/full Sema validation is pending. Bench agent ran no Cargo/fmt; no new Core, accelerator, JIT, or Syntax changes were made.
- 89464: TERMINAL100, focused 23 tests: 22 PASS / 1 FAIL. Five of the six broad failures recovered, including exact NonCallable nested identity/accounting and OnActivate effect rejection. Original Map three negatives/positive, Never, HIR and Sum also passed. Ambiguous `.None` passed; `choose(_)` still failed during analysis with WrongPayloadFamily before its observation assertions.
- Remaining static owner trace: `owner_bound_resolution::seal` inventoried every prepared OwnerBound expression, including the ambiguous candidate's implicit placeholder, then `prepare_callable_seed` requested its executable semantic coordinate although the canonical selected graph correctly omitted it. The narrow candidate now validates the entire drained capture ledger against legitimate staged implicit-callable owners before issuing identities only for canonical structural graph members. Pending candidate query rows do not receive callable identity or coordinate. Changes are confined to `match_edges.rs` and `owner_bound_resolution.rs`, refrozen for central rerun; exact candidate observation and no-execution assertions remain unchanged.
- 35417: TERMINAL0, all focused23/23 PASS, 0.318s, run d35f0dba-8da0-4d84-8df3-8942b65d2fae. All six broad failures recovered: independently checked NonCallable nested source/accounting, two exact Character look rejections, precise Array-length rejection, OnActivate effect rejection/positive acceptance, and both ambiguous per-candidate source type/closed-effect observations. Canonical no-execution assertions, Map3 negatives/positive, HIR/Sum and Never cases passed in the same run. Broader full reverse-dependency, CLI605 and matrix acceptance remains pending; all repository files stay frozen.

Latest full CLI checkpoint and narrow Sum followthrough:
- 47953: TERMINAL, all605 selected/executed:399 PASS /206 FAIL, 283.648s /23 skips; run f30a6772-270d-4280-b4d6-0f3fe826a961. Original277:71 same-ID recovered plus one removed motion syntax migrated to a current test;205 baseline failures remain and one new MCP timeout failure. The MCP failure is outside this agent's ownership.
- Assigned98:15 PASS /83 FAIL. Both actual negative bench assertion tests now pass: bench_json_fails_runtime_assert_sections and bench_json_fails_native_file_assertions. The old await? rejection test's PASS is transitional and does not constitute current executable semantics coverage; authorized removal remains pending.
- Current98 detailed ledger is arcweft-1009-cli-bench-current-stage-ledger.json in TEMP. Every row records its original taxonomy, current actual result, first panic/source assertion, exact diagnostic, and owning repair seam. No downstream acceleration/runtime recovery is inferred from an earlier boundary passing.
- Eight integer Map fixtures now expose the Core Sum construction boundary: Sema publishes I64, the closed CoreSeqSum AWBC signature/runtime require I64, but construction equated result with the source integer width. The narrow source fix now keeps the source width and admits only signed/unsigned source elements with Signed(I64) result. Floating forged seeds are also rejected at the exact element type.
- Three new Core construction regressions cover24 positive typed cases (all12 integer widths over Vec/Array), eight exact noninteger source cases including matching float result forgeries, and two forged integer result projections matching source width. Paths are Core plan/construction/lower.rs and lower/value_tests.rs. Collection raw-string hashes lint changes only the positive source literal delimiter in Sema tests/collections.rs.
- This narrow3-path cut is applied and refrozen, git diff --check passed; central Cargo/fmt/tests are pending. SystemInfo, Dense construction, Traverse, source Thread, and remaining fixture/profile consumer changes remain TEMP-only.
- 75151: parent reports all five final gates TERMINAL0 for the preceding coherent source checkpoint, including mechanical1253/1253 and externalIME1/1 PASS,185.796s. This receipt predates the new Sum construction cut and is not acceptance evidence for it.
- Parent independently committed and pushed the Never cut as5840a64a15ca080fe771195b6384586972139f7d. This agent has made no Cargo/fmt/Git-index/commit/push operations.

Current SystemInfo/fixture/telemetry checkpoint (applied; central validation pending):
- Parent released this cut after publishing Named ABI42db2fb19182e91c0e3add8dbb6f63d20090ee23 and AWBC source-map1cf8d5d81119d4d106fafd946448b1139939ce26. Parent owns all Cargo, nextest, formatting and publication. This agent ran only scoped diff checks.
- NativeSystemInfoAdapter now uses one closed typed SystemInfo request projection for completion, parallel eligibility and statistics. It handles all three existing typed operations and the canonical zero-argument Custom form emitted by selected manifest calls. The host registry still owns digest, Suspend mode, exact program result and AlwaysStart admission; no source spelling exception or alternate task model is introduced.
- New native tests native_system_info_adapter_completes_all_typed_and_manifest_selected_requests and native_system_info_projection_rejects_foreign_or_malformed_requests retain exact String Result outputs4/8/6 and one SystemInfo operation per call, with zero file metrics; they exercise both request carriers and reject foreign capability/operation or extra arguments. The standalone unit outcome uses the actual manifest SystemError producer with a fixture-owned semantic identity. It does not claim compiler program payload admission; the CLI three-operation test remains the distinct source/registry/scheduler acceptance test.
- Shared check.rs profiling summaries now consume current FinalSemanticProfileStats, accepted SyntaxProfileStats, verified AWBC products and actual project compilation phases. Removed typecheck/borrow-check judgment sampling and rewrite optimizer rows are not treated as current authority. Source JIT reporting is exactly semantic plus phases; no nonexistent syntax field is asserted. Runtime return, executor, step, fast-path, task and byte assertions are retained.
- Current profile/headless fixtures were observed in47953 to execute3 operations rather than2. Their checked phase/semantic/product assertions follow that actual report. AOT fast-path remains a nonzero assertion: the same fresh AOT fixture currently reports0 versus expected2, so its owning dispatch repair is still required;0 is not accepted as recovered coverage.
- Dense len fixtures now assert current semantic facts, no call diagnostics and exact authored local counts6/5/5; removed Vec(...) judgment spelling is retired. Their actual length execution/copy counters remain unchanged. Large and nonuniform Map tests keep actual batch/JIT/fusion assertions and use current semantic facts instead of the removed runtime_type_validation expression counter. Ordinary function candidate metrics remain pending the remaining agent's final producer contract; storage counts are not replaced with zero.
- Metric declarations retain their gauge types and now have the maintained braced policy body. SystemInfo/threaded-read flows declare control.spawn without dropping any operation. Serve tests select their existing canonical entry.http/entry.server IDs.
- The removed ids materialize tuple is retired while fmt extension rejection remains. The obsolete rejected_await_question_with_fixture_fails_with_guidance test and unreferenced spec_should_fail/011_await_question_with_rejected.arcw are removed, without parser-rejection replacement coverage. Original98 ledger keeps the exact retired ID; active CLI count must be obtained from the next actual selection.
- Current015/016/017 fixtures declare String results and explicit integer values so they isolate illegal break/yield/out transfers instead of omitted-Unit or uncontextual.Done failures. Their precise existing rejection assertions are retained for the central run. Root-owned014 Never fixture is preserved.
- Cut paths: crates/arcweft-runtime-host/src/native_task.rs; crates/arcweft-cli/tests/check.rs; crates/arcweft-cli/tests/check/cli_runtime_bench.rs; tests/fixtures/arcw/spec_should_pass/bench/004_system_info_threads.arcw; removed tests/fixtures/arcw/spec_should_fail/011_await_question_with_rejected.arcw; updated015_break_value_in_while_rejected.arcw,016_yield_in_flow_rejected.arcw,017_out_in_flow_rejected.arcw; this durable report.
- Earlier75491 executed1965:1962 PASS/3 FAIL,56.855s. All three Sum owner regressions and Named6 passed. One accelerator fixture still declared a U32 Sum/Flow result; its exact producer now admits I64 and preserves U32 source/callback plus result8256/pure_calls128. The other two failures were source-map relabel identity cases owned and repaired by root. This receipt does not prove the new SystemInfo/fixture cut.
- Scoped git diff --check passes. All changed source/tests/fixtures/docs are frozen for parent validation. DenseNumeric, Traverse, AWBC real child-fiber/task ledger, Content source trace and source Map acceleration followthrough remain unfinished, with preserved substantive assertions.
