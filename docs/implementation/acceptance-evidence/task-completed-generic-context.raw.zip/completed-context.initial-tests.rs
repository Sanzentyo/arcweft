use super::*;
use crate::{effects::EffectSet, types::GenericTypeReference};

fn ambient_value(scope: &GenericScope, ambient_depth: u32, own_function: bool) -> TypeKind {
    let array = |scope: &GenericScope, depth| TypeKind::Array {
        item: Box::new(TypeKind::GenericParam(scope.bound_type(depth, 0).unwrap())),
        len: ArrayLength::Generic(scope.bound_const(depth, 0).unwrap()),
    };
    if own_function {
        let binder = GenericBinder::new(1, 1, 0);
        let nested = scope.with_binder(binder);
        let own = TypeKind::GenericParam(nested.bound_type(0, 0).unwrap());
        TypeKind::function_with_binder(
            binder,
            [own.clone(), array(&nested, ambient_depth + 1)],
            own,
            EffectRow::closed(EffectSet::new()),
        )
    } else {
        array(scope, ambient_depth)
    }
}

fn complete_ambient(
    future: bool,
    own_function: bool,
) -> (TypeConstraintSolution, GenericScope, TypeKind) {
    let cancellation = AtomicBool::new(false);
    let (mut work, parameters) = context(scope(false, future), &cancellation).into_parts();
    let ambient = GenericBinder::new(1, 1, 0);
    let enclosing = work.enter_binder_scope(ambient);
    let application = work.application_scope((), parameters).unwrap();
    let id = application.id();
    let key = application
        .parameters()
        .type_reference(&parameter(0).into())
        .unwrap();
    let length = application
        .parameters()
        .const_reference(&constant().into())
        .unwrap();
    let mut path = work.start_path(application).unwrap();
    let value = ambient_value(work.lexical_scope(), 0, own_function);
    path = work
        .add_binding(path, key, &value, value.constraint_shape())
        .unwrap()
        .unwrap();
    if !future {
        let value = ArrayLength::Generic(work.lexical_scope().bound_const(0, 0).unwrap());
        path = work
            .add_const_binding(path, length, &value)
            .unwrap()
            .unwrap();
    }
    let completed = TypeConstraintSolution::complete_application(&path, id, &mut work).unwrap();
    let residual = if future {
        GenericBinder::new(1, 1, 0)
    } else {
        GenericBinder::EMPTY
    };
    let expected_scope = work.lexical_scope().with_binder(residual);
    let expected = ambient_value(&expected_scope, u32::from(future), own_function);
    work.restore_binder_scope(enclosing);
    assert!(work.lexical_scope().binders().is_empty());
    (completed, expected_scope, expected)
}

#[test]
fn completed_values_retain_their_ambient_type_and_const_context_without_residuals() {
    let (solution, expected_scope, expected) = complete_ambient(false, false);
    let (_, value) = solution.bindings().next().unwrap();
    assert_eq!(value.value(), &expected);
    assert_eq!(value.scope(), &expected_scope);
    let (_, length) = solution.const_bindings().next().unwrap();
    assert_eq!(length.scope(), &expected_scope);
    assert_eq!(
        length.value(),
        &ArrayLength::Generic(expected_scope.bound_const(0, 0).unwrap())
    );
}

#[test]
fn residual_slots_do_not_capture_same_position_ambient_type_and_const_parameters() {
    let (solution, expected_scope, expected) = complete_ambient(true, false);
    let (_, value) = solution.bindings().next().unwrap();
    assert_eq!(value.value(), &expected);
    assert_eq!(value.scope(), &expected_scope);
    assert!(solution.has_residual_type(&parameter(1).into()));
    assert!(solution.has_residual_const(&constant().into()));
}

#[test]
fn own_function_binders_survive_completed_ambient_and_residual_transport() {
    let (solution, expected_scope, expected) = complete_ambient(true, true);
    let (_, value) = solution.bindings().next().unwrap();
    assert_eq!(value.value(), &expected);
    assert_eq!(value.scope(), &expected_scope);
    let projected = solution
        .apply_template(&TypeKind::GenericParam(GenericTypeReference::Free(
            parameter(0),
        )))
        .unwrap();
    assert_eq!(projected.view().scope(), &expected_scope);
    assert_eq!(projected.view().value(), &expected);
}
