$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/declaration-scheme-closure.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/declaration-scheme-closure.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$scratch/declaration-scheme-closure.consumer-summary.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/declaration-scheme-closure.broad-quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/declaration-scheme-closure.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/declaration-scheme-closure.archive.json"|ConvertFrom-Json
$checkpoint=Get-Content -Raw "$scratch/declaration-scheme-closure.checkpoint-publication.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Documentation base changed'}
if($owner.Selected -ne 1760 -or $owner.Passed -ne 1754 -or $owner.Failed -ne 6 -or !$owner.IdsEqual -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or $consumers.Targets -ne 107 -or !$consumers.IdsEqual -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.ExitCode -ne 0 -or !$archive.AllEntriesVerified){throw 'Unexpected final validation'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previousStatus=[IO.File]::ReadAllText((Join-Path $PWD $status))
$previousHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previousStatus,'(?m)^\| Generic Match[^\r\n]+').Value
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']="| 再帰関数値の終端効果 | **既受入を維持。型検査済み本体の効果closureを共有scheme graphへ接続・検証・公開。本体内の関数値推論は継続** | 最新Source ``$($pub.Source)``。実checked catalogの全効果formalと元のDを先に登録し、型検査済み本体と実callの置換からscheme application方程式を作る。本体効果の旧row-growth queueは削除し、共有graphの最小解を全行まとめて公開する。失敗・取消し時は入力行を保持する。caller-bound recursion・共有prefix・Free許可／reify・実owner replayと予算接続の受入を維持する。型検査前の宣言scheme登録、prepared型を含む関数値の全port／Γ統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[比較制御](convergence-evidence-history.md#sealed-branch-comparison-control)・[本体closureの接続](convergence-evidence-history.md#callable-body-declaration-scheme-closure)。 |"
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,754 PASS／6 FAIL。後続21 packageも今回再実行** | Source ``$($pub.Source)`` のlocked・全feature Sema lib／tests 1,760件を$($owner.ExecutionSeconds)秒で実行。直前1,758 ID保持・新2件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行し、全2,510件／2,507 PASS／2 FAIL／1 SKIP。選択／終端ID一致・重複0、Compiler既知2失敗とcompile-only 3 targetも照合した。本体closureへの接続と再帰本体の関数値推論の修復を区別する。[owner・consumer・全SHA原本](acceptance-evidence/task-declaration-scheme-closure.raw.zip)。 |"
$rows['CLIの規定対象／全 check 照合']="| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source ``$($pub.Source)`` のlocked・既定feature／filterでlibrary 196件と規定の統合6 target 30件を今回実行し、226 PASS。binはcompile済み・runnable test 0件。選択／終端ID一致・重複0。以前の入力・失敗・公開SHAは履歴へ保持する。[今回のCLI原本](acceptance-evidence/task-declaration-scheme-closure.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace品質・doctest・fmt・構造gateを再実行し終了0** | Source ``$($pub.Source)`` のlocked workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateを実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。7 Rust path・$($owner.PhysicalGrowth)物理LOC増。本体closure・row algebra・診断の既存ownerへ配置し、public APIにはopaque error carrierとFinalSemanticAnalysisErrorのvariantを追加した。準備graphのcapabilityは非公開のまま。Cargo依存・I/O・codec・versionは変更せず、fan-in／out $($owner.FanIn)／$($owner.FanOut)も不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。Tier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入は今回未実行。[品質・構造・原本](acceptance-evidence/task-declaration-scheme-closure.raw.zip)。 |"
$current=$previousStatus
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
    if([regex]::Matches($current,$pattern).Count -ne 1){throw "Current row missing or duplicated: $key"}
    $replacement=$rows[$key]
    $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-14。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
$entry=@"

## Callable-body declaration scheme closure

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの7 Rust pathを通常commit／非force pushし、検証dirty bytes・commit・公開blobを照合した。owner・workspace品質の完了後、consumer $($checkpoint.CompletedGroups)／20 group完了・Compiler未開始の途中でSourceをpushした時点もcheckpoint原本に保持した。既存の未追跡 ``%SystemDrive%/`` を保持した。

- 本体効果を集約する実CallableEffectEquationsが、共有PreparedEffectGraphを使うよう変更した。実checked catalogのheaderから未使用を含む全効果formalと元のDを登録し、その後に実際の型検査済み本体行を一度ずつ設定する。登録はclosure内の本体方程式より先であり、式の型検査前に登録する移行まで済んだという意味ではない。
- 各呼び出しの元のprojectionが実formalを実引数行へ投影し、実schemeへのapplicationを作る。明示された効果boundは従来どおりcall interfaceとして使う。裸のsource走査、例固有の分岐、fakeなFree ID／Source Γ／型／pure bodyは作らない。本体効果の旧row-growth queueは削除した。SCCの走査は別責務である禁止再帰contractの検査へ残す。
- 同じclosure work予算でgraphの最小解と全出力行を確認し、最後に行mapを一度で置き換える。失敗・予算超過・取消しでは入力行を変更しない。rowのコピーも既存のcanonical encoding grammarを通して事前に課金する。
- publicなopaque CallableEffectClosureErrorが元のprivate algebra causeをstandard error chainへ保持する。取消し・work limit・row errorは既存の公開variantへ直接戻し、別の拒否原因に置き換えない。診断値に必要なClone／Eqはimmutable errorだけへ追加し、affine graph／checkpoint／deltaの複製には使わない。
- 新2件は、実Sourceからstageしたschemaの未使用formal保持、実測した成功境界までの全work budget点での原子性、元取消信号、foreign catalog拒否、診断のexact causeを検証する。初回のnullary-arrow fixtureのrecoveryと余分なBoxによるsource chainの失敗、その後のquery予算4096とcatalog closure予算の取り違えによるテスト失敗も原本に保持した。productionの予算は変更せず、最後の検証は元のclosure上限内で成功境界を測って全点を検査した。
- 最終ownerは1,760件／1,754 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,758 ID保持・新2件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。開発中の27件／19 PASS／8 FAIL、1760件／1753 PASS／7 FAILや初回checkを最終Sourceの合格へ読み替えない。
- fresh full metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗、CLI規定226 PASSとcompile-only 3 targetを照合した。全20 groupとCompiler 31 targetが終端であり、過去のconsumer実測を今回の実行として流用していない。
- workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateは今回Sourceで終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。7 path・$($owner.PhysicalGrowth)物理LOC増。本体closureとactual call inventory、row algebra、公開診断という既存ownerを維持し、依存・I/O・codec・versionは変更しない。public error carrier追加の理由、実LOC・byte size・embedded test LOCとfan-in $($owner.FanIn)／fan-out $($owner.FanOut)を原本へ記録した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- Supersedes: 本体効果closureの実producerにprepared scheme graphが未接続だった境界を、当該producerの接続済みへ訂正した。型検査前の宣言scheme登録、prepared型の全関数値port／Γ統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀と再帰本体6件は今回だけで完了にしない。Generic Match、caller-bound recursion、共有prefix、Free許可／reifyと各既受入は維持する。過去の全SHA・実測・失敗・原本を変更せず、現状一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-declaration-scheme-closure.raw.zip](acceptance-evidence/task-declaration-scheme-closure.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
foreach($document in @($rows.Values)+@($entry)){
    foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
        $target=$match.Groups[1].Value
        if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
        if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link: $target"}
    }
}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText((Join-Path $PWD $history),"`n"+$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($previousHistory.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if($after.Length -le $previousHistory.Length -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($previousHistory)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical archive index changed'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$previousHistory.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true;FinalWhitespaceExit=0}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/declaration-scheme-closure.docs-validation.json"
git diff --stat
