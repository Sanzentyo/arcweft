//! On-demand body prerequisites for prepared function-value projections.

use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    sync::Arc,
};

use crate::{
    callable::{
        CallableCandidateId, CallableInstantiation, CallableProjection,
        CallableTerminalEffectProjection, CheckedCallSite, CheckedCallableDeclaration,
        CheckedCallableId, PreparedCallableEffectProjectionSite, PreparedResolvedCallable,
    },
    effect_row::EffectRow,
    final_analysis::{
        FinalSemanticAnalysisError,
        statement_effects::{
            PreparedDeclarationExecutionEffectInput, prepare_declaration_execution_effects,
        },
    },
};

use super::{
    Analyzer,
    callable_effect_graph::{
        CallableEffectCall, CallableEffectEquations, prepared_call_execution_rows,
    },
    executable_ingress::{
        PreparedExecutableDeclaration, PreparedExecutableDeclarationInventory,
        PreparedExecutableIngressFacts,
    },
    expression_error::AnalyzerExpressionError,
    items::{inferred_callable_result_schema, result_schema_has_omitted_function_rows},
    state::CandidateFactTransactionAction,
};

impl Analyzer<'_, '_, '_> {
    /// A named value needs its full latent arrow, including inferred effects,
    /// without claiming that the expression invoked the declaration.
    pub(super) fn prepare_named_callable_value_type(
        &mut self,
        owner: arcweft_lang_hir::identity::ExprId,
        callable: &crate::final_analysis::CheckedProjectCallable,
    ) -> Result<crate::types::TypeKind, AnalyzerExpressionError> {
        let staged = self.staged_callables.as_ref().ok_or_else(|| {
            AnalyzerExpressionError::fatal(FinalSemanticAnalysisError::CheckedCallableCatalog)
        })?;
        let pending = staged
            .builder
            .pending_by_candidate(&CallableCandidateId::Project(
                callable.declaration().clone(),
            ))
            .map_err(|_| {
                AnalyzerExpressionError::fatal(FinalSemanticAnalysisError::CheckedCallableCatalog)
            })?;
        let record = Arc::clone(pending.record());
        if let Some(ty) = crate::types::CompileTimeCallableType::for_project(callable.declaration())
        {
            return Ok(crate::types::TypeKind::CompileTimeCallable(ty));
        }
        let candidate = PreparedResolvedCallable::try_from_checked_record(
            pending.id().clone(),
            Arc::clone(&record),
            crate::callable::PreparedCatalogCallee::Direct {
                project_binding: None,
            },
            CallableInstantiation::None,
            Vec::new(),
            &self.catalogs.callable_limits,
        )
        .map_err(|_| {
            AnalyzerExpressionError::fatal(FinalSemanticAnalysisError::CheckedCallableCatalog)
        })?;
        let result = self.run_candidate_fact_transaction(
            |this, _, _| -> Result<_, AnalyzerExpressionError> {
                this.prepare_callable_body_effects(
                    PreparedCallableEffectProjectionSite::CallableValue(owner),
                    &candidate,
                )
                .map_err(AnalyzerExpressionError::fatal)?;
                let terminal = this
                    .source_callable_terminal_effects(&candidate)
                    .map_err(AnalyzerExpressionError::fatal)?;
                let ty = candidate.callable_value_type(terminal).map_err(|_| {
                    AnalyzerExpressionError::fatal(
                        FinalSemanticAnalysisError::CheckedCallableCatalog,
                    )
                })?;
                let CallableProjection::Ready(ty) = ty else {
                    return Err(AnalyzerExpressionError::fatal(
                        FinalSemanticAnalysisError::CheckedCallableCatalog,
                    ));
                };
                Ok(CandidateFactTransactionAction::Commit(ty))
            },
        )?;
        result
            .into_committed()
            .map_err(AnalyzerExpressionError::fact)
    }

    /// Only a projection that needs an inferred terminal row enters this
    /// prerequisite. Ordinary terminal calls retain their typed effect edge.
    pub(super) fn prepare_pending_result_projection(
        &mut self,
        site: CheckedCallSite,
        candidate: &PreparedResolvedCallable,
    ) -> Result<(), FinalSemanticAnalysisError> {
        let effects = self.source_callable_terminal_effects(candidate)?;
        let result = candidate
            .result_schema_for_group(candidate.call_group(), effects)
            .map_err(|_| FinalSemanticAnalysisError::CallResolutionFailed {
                owner: site.expression(),
            })?;
        if matches!(result, CallableProjection::Pending(_))
            || (result_schema_has_omitted_function_rows(candidate.schema())
                && effects.inferred_result_schema().is_none())
        {
            self.prepare_callable_body_effects(site.into(), candidate)?;
        }
        Ok(())
    }

    pub(super) fn prepare_callable_body_effects(
        &mut self,
        site: PreparedCallableEffectProjectionSite,
        candidate: &PreparedResolvedCallable,
    ) -> Result<(), FinalSemanticAnalysisError> {
        let terminal = self.source_callable_terminal_effects(candidate)?;
        let needs_result = result_schema_has_omitted_function_rows(candidate.schema())
            && terminal.inferred_result_schema().is_none();
        let checked = match terminal {
            CallableTerminalEffectProjection::Known { .. } if !needs_result => return Ok(()),
            CallableTerminalEffectProjection::Pending(checked) => checked.clone(),
            CallableTerminalEffectProjection::Known { .. } => candidate
                .checked()
                .cloned()
                .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?,
        };
        let CheckedCallableDeclaration::Project(declaration) = checked.declaration() else {
            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
        };
        let declaration = declaration.clone();
        let reference = self
            .facts
            .request_effect_projection(site, candidate)
            .map_err(FinalSemanticAnalysisError::from)?;

        // A declaration body has its own lexical execution contexts. Inference
        // must not treat its parameter uses as captures of the requesting call.
        let implicit = std::mem::take(&mut self.implicit_callable_stack);
        let pipes = std::mem::take(&mut self.pipe_stack);
        let function_sites = std::mem::take(&mut self.function_site_stack);
        let prepared = self.prepare_callable_declaration_effects(&checked);
        self.implicit_callable_stack = implicit;
        self.pipe_stack = pipes;
        self.function_site_stack = function_sites;
        let row = prepared?;
        let result_schema = inferred_callable_result_schema(
            &self.modules,
            self.symbols
                .callable(&declaration)
                .ok_or(FinalSemanticAnalysisError::InvalidCallableOwner)?,
            candidate.schema(),
            self.facts.expressions(),
        )?;
        self.facts
            .complete_effect_projection(&reference, &checked, row, result_schema)
            .map_err(FinalSemanticAnalysisError::from)
    }

    fn prepare_callable_declaration_effects(
        &mut self,
        root: &CheckedCallableId,
    ) -> Result<EffectRow, FinalSemanticAnalysisError> {
        let inventory = PreparedExecutableDeclarationInventory::build(self)?;
        let mut pending = VecDeque::from([root.clone()]);
        let mut scheduled = BTreeSet::from([root.clone()]);
        let mut rows = BTreeMap::new();
        let mut boundary = BTreeMap::new();
        let mut equations = CallableEffectEquations::default();
        while let Some(owner) = pending.pop_front() {
            self.control.check()?;
            let CheckedCallableDeclaration::Project(declaration) = owner.declaration() else {
                return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
            };
            let body = inventory
                .get(declaration)
                .ok_or(FinalSemanticAnalysisError::InvalidCallableOwner)?;
            let (row, calls) = self.prepare_declaration_effect_equation(body)?;
            let mut applications = Vec::with_capacity(calls.len());
            for call in calls {
                self.control.check()?;
                match self.source_callable_terminal_effects(call.candidate())? {
                    CallableTerminalEffectProjection::Known { effects, .. } => {
                        if let Some(previous) =
                            boundary.insert(call.target().clone(), effects.clone())
                            && previous != *effects
                        {
                            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
                        }
                    }
                    CallableTerminalEffectProjection::Pending(target) => {
                        if scheduled.insert(target.clone()) {
                            pending.push_back(target.clone());
                        }
                    }
                }
                applications.push(call.expression());
                equations.insert_call(call)?;
            }
            equations.insert_body(owner.clone(), applications)?;
            rows.insert(owner, row);
        }
        equations.close(
            &mut rows,
            &boundary,
            &self
                .staged_callables
                .as_ref()
                .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?
                .builder,
            self.catalogs.callable_limits.max_catalog_build_work(),
            self.control,
        )?;
        rows.remove(root)
            .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)
    }

    fn prepare_declaration_effect_equation(
        &mut self,
        body: &PreparedExecutableDeclaration,
    ) -> Result<(EffectRow, Vec<CallableEffectCall>), FinalSemanticAnalysisError> {
        let declaration = body.declaration();
        if body.contains_event_scrutinee(&self.modules)? {
            // Event-dependent declarations require their ingress authority;
            // an absent ingress type is never replaced with an inferred type.
            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
        }
        self.complete_ingress_declaration(body, &PreparedExecutableIngressFacts::default())?;
        let graph = self
            .facts
            .prepared_calls()
            .map_err(FinalSemanticAnalysisError::from)?;
        let call_effects = prepared_call_execution_rows(graph, self.control)?;
        let selected = self.prepared_declaration_expression_graph(declaration)?;
        let expressions = selected
            .expression_owners()
            .map(|owner| {
                self.facts
                    .expressions()
                    .get(&owner)
                    .cloned()
                    .map(|fact| (owner, fact))
                    .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner })
            })
            .collect::<Result<Vec<_>, _>>()?;
        let statements = self.prepare_declaration_statement_effects(&selected)?;
        let prepared =
            prepare_declaration_execution_effects(PreparedDeclarationExecutionEffectInput {
                modules: &self.modules,
                topology: &self.topology,
                selected: &selected,
                call_effects: &call_effects,
                expressions: &expressions,
                statements: &statements,
                control: self.control,
            })?;
        let effects = prepared
            .declaration_effects(declaration)
            .cloned()
            .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?;
        let evaluated = prepared
            .declaration_effect_expressions(declaration)
            .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?
            .collect::<BTreeSet<_>>();
        let calls = self
            .facts
            .prepared_calls()
            .map_err(FinalSemanticAnalysisError::from)?
            .selected_nodes()
            .filter(|node| evaluated.contains(&node.site().expression()))
            .filter_map(|node| {
                CallableEffectCall::selected(node.site(), node.prefix().application())
            })
            .collect::<Vec<_>>();
        Ok((effects, calls))
    }
}
