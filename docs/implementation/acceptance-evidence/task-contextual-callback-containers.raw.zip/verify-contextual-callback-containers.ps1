param(
    [Parameter(Mandatory)][string]$Commit,
    [Parameter(Mandatory)][string]$Iteration,
    [ValidateSet('bytecode-vm','aot','awbc-product')][string[]]$Executors=@('bytecode-vm','aot','awbc-product')
)

$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSCommandPath
if ((git rev-parse HEAD) -ne $Commit -or @(git status --porcelain --untracked-files=no -- crates).Count) {
    throw 'Checkout differs from the compiled revision.'
}
$exe=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$binary=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
$previous=Get-Content -LiteralPath (Join-Path $root 'introduced-effect-application.dev02-cli-containers.json') -Raw | ConvertFrom-Json
if ($binary -eq $previous.binary_sha256) { throw 'The executable still matches the previous published revision.' }

$cases=@(
    foreach ($case in $previous.runs) {
        $input=$case.args[1]
        $digest=(Get-FileHash -LiteralPath $input -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($digest -ne $case.input_sha256) { throw ('Changed input ' + $case.case) }
        @{name=$case.case;input=$input;sha256=$digest;logs=@();reject=$false;baseline=$case.exit}
    }
    if ($Iteration -ne 'dev06') {
        $nested=Get-Content -LiteralPath (Join-Path $root 'contextual-callback-containers.dev08-nested-baseline.json') -Raw | ConvertFrom-Json
        foreach ($case in $nested.runs) {
            $input=$case.args[1]
            $digest=(Get-FileHash -LiteralPath $input -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($digest -ne $case.input_sha256) { throw ('Changed input ' + $case.name) }
            @{name=$case.name;input=$input;sha256=$digest;logs=@();reject=$false;baseline=$case.exit}
        }
    }
    foreach ($name in @('vec-invoke','vec-invoke-authored-effect','array-invoke','vec-deny-pure','array-deny-size')) {
        $input=Join-Path $root "contextual-callback-containers.dev06-$name-closed-marker.arcw"
        $reject=$name -match '-deny-'
        $logs=@()
        if (-not $reject) { $logs=@('container callback') }
        @{name=$name;input=$input;sha256=(Get-FileHash -LiteralPath $input -Algorithm SHA256).Hash.ToLowerInvariant();logs=$logs;reject=$reject;baseline=[int]($name -ne 'vec-invoke-authored-effect')}
    }
)
$outcomes=@(
    foreach ($case in $cases) {
        foreach ($executor in $Executors) {
            $prefix=Join-Path $root ("contextual-callback-containers.$Iteration-cli-"+$case.name+'-'+$executor)
            $stdout=$prefix+'.stdout.log'
            $stderr=$prefix+'.stderr.log'
            $run=@('run',$case.input,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','256','--json')
            & $exe @run 1> $stdout 2> $stderr
            $exit=$LASTEXITCODE
            $message=[string](Get-Content -LiteralPath $stderr -Raw)
            $result=if ((Get-Item -LiteralPath $stdout).Length) {
                Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json
            } else {
                $null
            }
            $maxOps=($result.steps.stats.executed_ops | Measure-Object -Maximum).Maximum
            $diagnosticSteps=@($result.steps | Where-Object {$_.stats.diagnostics -gt 0 -or $_.diagnostics.Count -gt 0 -or $_.assertion_failures.Count -gt 0}).Count
            $messages=@()
            if ($result) { $messages=@($result.steps[-1].observations.logs | ForEach-Object message) }
            $sameLogs=(ConvertTo-Json -InputObject @($messages) -Compress) -ceq (ConvertTo-Json -InputObject @($case.logs) -Compress)
            $ok=if ($case.reject) {
                $exit -eq 1 -and $message.Contains('error[sema.call.no_viable_signature]')
            } else {
                $exit -eq 0 -and $result.final_status -ceq 'done Return("42")' -and
                    $maxOps -eq 1 -and $diagnosticSteps -eq 0 -and $sameLogs
            }
            @{case=$case.name;executor=$executor;input=$case.input;input_sha256=$case.sha256;args=$run;exit=$exit;
              final_status=$result.final_status;steps=$result.steps.Count;max_ops=$maxOps;diagnostic_steps=$diagnosticSteps;
              log_messages=@($messages);expected_rejection=$case.reject;baseline_vm_exit=$case.baseline;ok=$ok;
              diagnostic=$message;stdout=[IO.Path]::GetFileName($stdout);stderr=[IO.Path]::GetFileName($stderr)}
        }
    }
)
@{version=1;source=$Commit;binary_sha256=$binary;runs=$outcomes;finished=(Get-Date -Format o)} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root "contextual-callback-containers.$Iteration-cli.json") -Encoding utf8NoBOM
$outcomes | ForEach-Object {
    $report = if ($_.ok) { 'PASS' } else { 'FAIL' }
    '{0} {1} {2}: {3} {4}' -f $report,$_.case,$_.executor,$_.final_status,(($_.diagnostic -split [Environment]::NewLine)[0])
}


