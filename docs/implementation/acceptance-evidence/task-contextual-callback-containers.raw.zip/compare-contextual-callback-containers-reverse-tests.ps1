param([string]$Iteration='dev09')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$packages = @(Get-Content -LiteralPath (Join-Path $root 'contextual-callback-containers.dev09-dependency-graph.log') | ForEach-Object {
    if ($_ -match '^(arcweft[-\w]+) v' -and $Matches[1] -ne 'arcweft-cli') { $Matches[1] }
} | Sort-Object -Unique)
function Read-TestResults([string]$filename) {
    $rows = [ordered]@{}
    foreach ($line in Get-Content -LiteralPath (Join-Path $root $filename)) {
        if ($line -match '^\s*Summary \[') { break }
        if ($line -match '^\s*(PASS|FAIL|SKIP) \[.*?\]\s+\(\s*\d+/\d+\) (arcweft[-\w]+)(?:::([^ ]+))? (\S+)$' -and $Matches[2] -in $packages) {
            $key = '{0}::{1} {2}' -f $Matches[2], $Matches[3], $Matches[4]
            $rows[$key] = $Matches[1]
        }
    }
    return ,$rows
}
$before = Read-TestResults 'introduced-effect-application.dev02-reverse-tests.log'
$after = Read-TestResults ('contextual-callback-containers.' + $Iteration + '-reverse-tests.log')
$ids = @(@($before.Keys) + @($after.Keys) | Sort-Object -Unique)
$changes = @(
    foreach ($id in $ids) {
        if ($before[$id] -ne $after[$id]) {
            @{ id=$id; before=$before[$id]; after=$after[$id] }
        }
    }
)
$summary = @{
    packages=$packages
    baseline=@{ total=$before.Count; pass=@($before.Values | Where-Object { $_ -eq 'PASS' }).Count; fail=@($before.Values | Where-Object { $_ -eq 'FAIL' }).Count }
    current=@{ total=$after.Count; pass=@($after.Values | Where-Object { $_ -eq 'PASS' }).Count; fail=@($after.Values | Where-Object { $_ -eq 'FAIL' }).Count }
    changes=$changes
}
$summary | ConvertTo-Json -Depth 5 | Tee-Object -FilePath (Join-Path $root ('contextual-callback-containers.'+$Iteration+'-reverse-comparison.json'))





