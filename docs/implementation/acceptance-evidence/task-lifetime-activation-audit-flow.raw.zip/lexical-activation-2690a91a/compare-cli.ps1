$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-activation-20261110'
$qa=Get-Content -LiteralPath (Join-Path $d 'quality.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
if(!$qa.cliSha256){throw 'Exact CLI build has not completed'}
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
function Get-ArcSha($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
if((Get-ArcSha $cli) -ne $qa.cliSha256){throw 'CLI drift'}
& (Join-Path $d 'run-cli.ps1') -Phase changed | Out-Null
$before=Get-Content -LiteralPath (Join-Path $d 'baseline.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$after=Get-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$prefix='sema.lifetime.promotion_'
$expects=[ordered]@{
    'flow-reached'=@('execution',"42i64.promote('flow)")
    'line-not-reached'=@('target',"'line")
    'thread-flow-not-reached'=@('target',"'flow")
    'borrowed-receiver'=@('receiver','value')
    'proof-does-not-own'=@('receiver','value')
    'thread-audit-not-reached'=@('audit',"value.promote_unchecked('flow)")
    'outside-audit'=@('audit',"42i64.promote_unchecked('flow)")
    'ordinary'=@($null,$null)
}
$results=@(foreach($name in $expects.Keys) {
    $old=@($before.results|Where-Object name -eq $name)
    $new=@($after.results|Where-Object name -eq $name)
    if($old.Count -ne 1 -or $new.Count -ne 1 -or $old[0].sourceSha256 -ne $new[0].sourceSha256){throw "Source replay differs $name"}
    $expected=$expects[$name]
    $text=$null
    if ($expected[0]){
        $code=$prefix+$expected[0]
        $report=Get-Content -LiteralPath (Join-Path $d "changed-$name.json") -Raw|ConvertFrom-Json -AsHashtable
        if($old[0].exit -ne 1 -or $old[0].codes.Count -ne 1 -or $old[0].codes[0] -ne 'sema.call.unknown_target' -or $new[0].exit -ne 1 -or $new[0].codes.Count -ne 1 -or $new[0].codes[0] -ne $code -or $report.status -ne 'denied' -or $report.stage -ne 'type-check'){
            throw "Diagnostic mismatch $name (old=$($old[0].codes -join ',') new=$($new[0].codes -join ','))"
        }
        $span=$report.diagnostics[0].diagnostic.span
        $src=Get-Content -LiteralPath (Join-Path $d "$name.arcw") -Raw
        $text=$src.Substring($span.start,$span.end-$span.start)
        if($text -cne $expected[1]){throw "Source span mismatch $name, observed $text"}
    } elseif ($old[0].exit -or $new[0].exit -or $old[0].codes.Count -or $new[0].codes.Count){throw "Ordinary control failed $name"}
    [ordered]@{name=$name;before=$old[0].codes;after=$new[0].codes;beforeExit=$old[0].exit;afterExit=$new[0].exit;offendingSource=$text;sourceSha256=$new[0].sourceSha256}
})
$source=Join-Path $d 'audit-if-control.arcw'
$reportPath=Join-Path $d 'changed-audit-if-control.json'
$errPath=Join-Path $d 'changed-audit-if-control.stderr.log'
& $cli verify $source --mode dev --json > $reportPath 2> $errPath
$code=$LASTEXITCODE
$old=Get-Content -LiteralPath (Join-Path $d 'baseline-audit-if-control.json') -Raw|ConvertFrom-Json -AsHashtable
if($old.stage -ne 'hir-lower' -or $old.diagnostics[0].diagnostic.code -ne 'hir.lower.project_transaction' -or $code){throw "Nested audit control still rejected with $code"}
[ordered]@{version=1;base=$qa.base;beforeCli=$before.cliSha256;afterCli=$after.cliSha256;results=$results;nestedAuditControl=[ordered]@{beforeCode=$old.diagnostics[0].diagnostic.code;afterExit=$code;sourceSha256=Get-ArcSha $source;reportSha256=Get-ArcSha $reportPath}}|ConvertTo-Json -Depth 10|Tee-Object -FilePath (Join-Path $d 'cli-comparison.receipt.json')

