param([ValidateSet('baseline','changed')][string]$phase)
$ErrorActionPreference='Stop'

$d=Join-Path $env:TEMP 'arcweft-promotion-activation-20261110'
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=(Get-FileHash -LiteralPath $cli -Algorithm SHA256).Hash.ToLowerInvariant()
$fixtures=[ordered]@{
    'flow-reached'="flow main() { let _ = 42i64.promote('flow); }"
    'line-not-reached'="flow main() { let _ = 42i64.promote('line); }"
    'thread-flow-not-reached'="flow main() { thread { let _ = 42i64.promote('flow); } }"
    'borrowed-receiver'="flow main(value: &i64) { let _ = value.promote('flow); }"
    'proof-does-not-own'="proof keep() = ()"+[char]10+"flow main(value: &i64) { let _ = value.promote('flow, proof = @proof.keep); }"
    'thread-audit-not-reached'='flow main() { unsafe lifetime @unsafe.outer reason = "outer" { thread { let value = 42i64; let _ = value.promote_unchecked(''flow); } } }'
    'outside-audit'="flow main() { let _ = 42i64.promote_unchecked('flow); }"
    'ordinary'="flow main() -> i64 { return 42i64; }"
}
$results=@(foreach($name in $fixtures.Keys) {
    $source=Join-Path $d "$name.arcw"
    [IO.File]::WriteAllText($source,$fixtures[$name]+[char]10,[Text.UTF8Encoding]::new($false))
    $out=Join-Path $d "$phase-$name.json"
    $err=Join-Path $d "$phase-$name.stderr.log"
    & $cli verify $source --mode dev --json > $out 2> $err
    $exit=$LASTEXITCODE
    $report=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
    [ordered]@{name=$name;exit=$exit;codes=@($report.diagnostics|ForEach-Object {$_.diagnostic.code}|Where-Object {$_});sourceSha256=(Get-FileHash $source).Hash.ToLowerInvariant();reportSha256=(Get-FileHash $out).Hash.ToLowerInvariant();stderrSha256=(Get-FileHash $err).Hash.ToLowerInvariant()}
})
[ordered]@{version=1;phase=$phase;cliSha256=$sha;head=(git rev-parse HEAD);results=$results}|ConvertTo-Json -Depth 12|Tee-Object -FilePath (Join-Path $d "$phase.receipt.json")

