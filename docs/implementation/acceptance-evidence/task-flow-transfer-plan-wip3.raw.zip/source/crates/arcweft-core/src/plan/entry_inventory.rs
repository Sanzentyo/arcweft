//! Runtime entry inventory records and whole-plan verification.
//!
//! The data-only role contracts remain owned by [`crate::entry`]. This module
//! composes those contracts with runtime-plan identifiers, launch targets, and
//! executable metadata, then verifies the complete entry graph before runtime
//! selection. It performs no source resolution, adapter work, or platform I/O.

use std::borrow::Borrow;
use std::cmp::Ordering;
use std::collections::BTreeSet;
use std::fmt;
use std::sync::Arc;

use serde::{Deserialize, Serialize};
use thiserror::Error;

use crate::entry::{
    CallableContractHash, EntryBindingIdentity, FlowParameterCoordinate, RuntimeCallableExecutable,
    RuntimeCallableExecutableCode, RuntimeCallableId, RuntimeCallableRole, RuntimeCommandContract,
    RuntimeEntryRoles, RuntimeFlowParameterMode, RuntimeStatefulEntryRoles,
};
use crate::pattern::RuntimeSemanticTypeId;
use crate::runtime_id::{
    RuntimeDeferSiteId, RuntimeFunctionSiteId, RuntimeIdError, RuntimeIdFamily, RuntimeIdPath,
    RuntimeProjectCallSiteId, RuntimePublicLabel,
};
use crate::value::RuntimeFlowParameterBinding;

use super::{FlowOp, FlowRuntimeId, RuntimePlan, RuntimePureHelperId};

/// Runtime identifier for a source-declared entry.
#[derive(Clone, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub struct EntryRuntimeId {
    path: RuntimeIdPath,
}

/// Adapter family of a source-declared entry.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeEntryKind {
    Game,
    Editor,
    Cli,
    Server,
    Activity,
    Test,
    Bench,
    Agent,
    Custom(String),
}

/// Launch target selected by an entry.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub enum RuntimeEntryTarget {
    Flow(FlowRuntimeId),
    Routes(Vec<RuntimeRouteSpec>),
    Controller(FlowRuntimeId),
}

/// Closed HTTP method family admitted by the runtime route registry.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub enum RuntimeHttpMethod {
    Get,
    Post,
    Put,
    Patch,
    Delete,
    Head,
    Options,
}

impl RuntimeHttpMethod {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Get => "GET",
            Self::Post => "POST",
            Self::Put => "PUT",
            Self::Patch => "PATCH",
            Self::Delete => "DELETE",
            Self::Head => "HEAD",
            Self::Options => "OPTIONS",
        }
    }
}

/// Stable source-order coordinate of one route-path capture.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(transparent)]
pub struct RouteCaptureCoordinate(u32);

impl RouteCaptureCoordinate {
    #[must_use]
    pub const fn from_position(position: u32) -> Self {
        Self(position)
    }

    pub fn try_from_index(index: usize) -> Result<Self, RuntimeRoutePathError> {
        u32::try_from(index)
            .map(Self)
            .map_err(|_| RuntimeRoutePathError::CaptureCapacity { index })
    }

    #[must_use]
    pub const fn position(self) -> u32 {
        self.0
    }

    pub fn index(self) -> Result<usize, RuntimeRoutePathError> {
        usize::try_from(self.0)
            .map_err(|_| RuntimeRoutePathError::CaptureCoordinate { position: self.0 })
    }
}

/// One canonical route-matching segment.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeRoutePathSegment {
    Literal(String),
    Capture(RouteCaptureCoordinate),
}

/// Canonical path plus its typed dispatch/capture inventory.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeRoutePath {
    segments: Vec<RuntimeRoutePathSegment>,
}

impl RuntimeRoutePath {
    pub fn try_new(
        segments: impl Into<Vec<RuntimeRoutePathSegment>>,
    ) -> Result<Self, RuntimeRoutePathError> {
        let segments = segments.into();
        Self::validate_segments(&segments)?;
        Ok(Self { segments })
    }

    fn validate_segments(
        segments: &[RuntimeRoutePathSegment],
    ) -> Result<(), RuntimeRoutePathError> {
        let mut capture_count = 0usize;
        for segment in segments {
            match segment {
                RuntimeRoutePathSegment::Literal(literal) => {
                    Self::validate_source_literal(literal)?;
                }
                RuntimeRoutePathSegment::Capture(coordinate) => {
                    Self::validate_source_capture(*coordinate, capture_count)?;
                    capture_count += 1;
                }
            }
        }
        Ok(())
    }

    pub(crate) fn validate_source_literal(literal: &str) -> Result<(), RuntimeRoutePathError> {
        if literal.is_empty()
            || literal.starts_with(':')
            || literal.contains('/')
            || literal.chars().any(char::is_control)
        {
            Err(RuntimeRoutePathError::InvalidLiteral)
        } else {
            Ok(())
        }
    }

    pub(crate) fn validate_source_capture(
        coordinate: RouteCaptureCoordinate,
        expected: usize,
    ) -> Result<(), RuntimeRoutePathError> {
        if coordinate.index()? == expected {
            Ok(())
        } else {
            Err(RuntimeRoutePathError::InvalidCapture)
        }
    }

    #[must_use]
    pub fn segments(&self) -> &[RuntimeRoutePathSegment] {
        &self.segments
    }

    #[must_use]
    pub fn capture_count(&self) -> usize {
        self.segments
            .iter()
            .filter(|segment| matches!(segment, RuntimeRoutePathSegment::Capture(_)))
            .count()
    }

    #[must_use]
    pub fn overlaps_dispatch(&self, other: &Self) -> bool {
        self.segments.len() == other.segments.len()
            && self
                .segments
                .iter()
                .zip(other.segments.iter())
                .all(|(left, right)| match (left, right) {
                    (
                        RuntimeRoutePathSegment::Literal(left),
                        RuntimeRoutePathSegment::Literal(right),
                    ) => left == right,
                    (
                        RuntimeRoutePathSegment::Literal(_)
                        | RuntimeRoutePathSegment::Capture(_),
                        RuntimeRoutePathSegment::Capture(_),
                    )
                    | (
                        RuntimeRoutePathSegment::Capture(_),
                        RuntimeRoutePathSegment::Literal(_),
                    ) => {
                        true
                    }
                })
    }

    #[must_use]
    pub fn dispatch_cmp(&self, other: &Self) -> Ordering {
        for (left, right) in self.segments.iter().zip(other.segments.iter()) {
            let ordering = match (left, right) {
                (
                    RuntimeRoutePathSegment::Literal(left),
                    RuntimeRoutePathSegment::Literal(right),
                ) => left.cmp(right),
                (RuntimeRoutePathSegment::Literal(_), RuntimeRoutePathSegment::Capture(_)) => {
                    Ordering::Less
                }
                (RuntimeRoutePathSegment::Capture(_), RuntimeRoutePathSegment::Literal(_)) => {
                    Ordering::Greater
                }
                (RuntimeRoutePathSegment::Capture(_), RuntimeRoutePathSegment::Capture(_)) => {
                    Ordering::Equal
                }
            };
            if ordering != Ordering::Equal {
                return ordering;
            }
        }
        self.segments.len().cmp(&other.segments.len())
    }

    fn validate(&self) -> Result<(), RuntimeRoutePathError> {
        Self::validate_segments(&self.segments)
    }
}

impl fmt::Display for RuntimeRoutePath {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.segments.is_empty() {
            return f.write_str("/");
        }
        for segment in &self.segments {
            f.write_str("/")?;
            match segment {
                RuntimeRoutePathSegment::Literal(literal) => f.write_str(literal)?,
                RuntimeRoutePathSegment::Capture(_) => f.write_str(":")?,
            }
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeRoutePathError {
    #[error("route literal segment is not canonical")]
    InvalidLiteral,
    #[error("route capture inventory is not canonical")]
    InvalidCapture,
    #[error("route capture index {index} exceeds the coordinate domain")]
    CaptureCapacity { index: usize },
    #[error("route capture coordinate {position} does not fit this platform")]
    CaptureCoordinate { position: u32 },
}

/// Route declaration in a server-like entry.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RuntimeRouteSpec {
    pub method: RuntimeHttpMethod,
    pub path: RuntimeRoutePath,
    pub target: FlowRuntimeId,
    pub bindings: Vec<RuntimeRouteBinding>,
}

/// Explicit route parameter binding for a target flow invocation.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RuntimeRouteBinding {
    pub parameter: FlowParameterCoordinate,
    pub source: RuntimeRouteBindingSource,
}

/// Adapter route value source used by a route binding.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub enum RuntimeRouteBindingSource {
    PathCapture(RouteCaptureCoordinate),
}

/// One complete, plan-validated Flow invocation consumed before the first
/// operation executes.
///
/// The carrier owns its exact immutable plan so a coordinate/value inventory
/// cannot be paired with a different runtime generation after sealing.
#[derive(Debug, PartialEq)]
pub struct RuntimeFlowInvocation {
    plan: Arc<RuntimePlan>,
    flow: FlowRuntimeId,
    bindings: Box<[RuntimeFlowParameterBinding]>,
}

#[derive(Clone, Debug, Error, PartialEq)]
pub enum RuntimeFlowInvocationError {
    #[error(
        "runtime Flow invocation parameter {parameter:?} cannot be copied because its value is not unrestricted"
    )]
    NonCopyableParameter { parameter: FlowParameterCoordinate },
    #[error("runtime Flow `{flow}` does not exist")]
    UnknownFlow { flow: String },
    #[error("runtime Flow `{flow}` has no invocation schema")]
    MissingSchema { flow: String },
    #[error("runtime Flow `{flow}` expects {expected} invocation bindings, received {actual}")]
    BindingCount {
        flow: String,
        expected: usize,
        actual: usize,
    },
    #[error("runtime Flow `{flow}` received duplicate parameter coordinate {parameter:?}")]
    DuplicateParameter {
        flow: String,
        parameter: FlowParameterCoordinate,
    },
    #[error("runtime Flow `{flow}` has no parameter coordinate {parameter:?}")]
    UnknownParameter {
        flow: String,
        parameter: FlowParameterCoordinate,
    },
    #[error(
        "runtime Flow `{flow}` invocation row {index} carries noncanonical parameter {parameter:?}"
    )]
    NonCanonicalParameter {
        flow: String,
        index: usize,
        parameter: FlowParameterCoordinate,
    },
    #[error(transparent)]
    FunctionInputs(#[from] crate::value::RuntimeFunctionApplyError),
    #[error("runtime Flow invocation input admission failed: {0}")]
    InputAdmission(#[source] Box<crate::value::AwbcRuntimeValueSnapshotError>),
    #[error(transparent)]
    TransferInputOrder(#[from] crate::value::RuntimeInputOrderError),
    #[error("runtime Flow transfer does not retain its resolved original target")]
    TransferTarget,
    #[error("Flow transfer parameter {parameter:?} must consume a pre-evaluated whole local input")]
    TransferInputSource { parameter: FlowParameterCoordinate },
    #[error("Flow transfer repeats owning input local {local}")]
    DuplicateTransferInput {
        local: crate::runtime_id::RuntimeLocalDeclarationId,
    },
    #[error("Flow transfer input pattern admission failed: {0}")]
    TransferPattern(#[source] Box<crate::value::RuntimeEvalError>),
}

impl super::RuntimePlanInventory {
    /// Admits the complete coordinate permutation before evaluating or staging
    /// operands. The same original schema bounds all following input storage.
    pub(crate) fn validate_flow_transfer_shape<E>(
        &self,
        flow: &FlowRuntimeId,
        transfer: &super::RuntimeFlowTransfer<E>,
    ) -> Result<(RuntimeFunctionSiteId, crate::value::RuntimeInputOrder), RuntimeFlowInvocationError>
    {
        let (runtime_flow, schema) = self.flow_invocation_contract(flow)?;
        if matches!(&transfer.target, super::RuntimeFlowTransferTarget::Static(original) if original != flow)
        {
            return Err(RuntimeFlowInvocationError::TransferTarget);
        }
        if transfer.arguments.len() != schema.parameters.len() {
            return Err(RuntimeFlowInvocationError::BindingCount {
                flow: flow.canonical_label(),
                expected: schema.parameters.len(),
                actual: transfer.arguments.len(),
            });
        }
        let order = transfer.input_order()?;
        for argument in &transfer.arguments {
            let parameter = argument.parameter;
            if parameter
                .index()
                .ok()
                .and_then(|index| schema.parameters.get(index))
                .is_none_or(|formal| formal.coordinate != parameter)
            {
                return Err(RuntimeFlowInvocationError::UnknownParameter {
                    flow: flow.canonical_label(),
                    parameter,
                });
            }
        }
        Ok((runtime_flow.function_site(), order))
    }

    fn flow_invocation_contract(
        &self,
        flow: &FlowRuntimeId,
    ) -> Result<(&super::RuntimeFlow, &crate::entry::RuntimeFlowSchema), RuntimeFlowInvocationError>
    {
        let runtime_flow =
            self.flows
                .flow(flow)
                .ok_or_else(|| RuntimeFlowInvocationError::UnknownFlow {
                    flow: flow.canonical_label(),
                })?;
        let schema =
            self.flows
                .schema(flow)
                .ok_or_else(|| RuntimeFlowInvocationError::MissingSchema {
                    flow: flow.canonical_label(),
                })?;
        Ok((runtime_flow, schema))
    }
}

impl RuntimePlan {
    /// Source order is retained by the packet; only borrowed references are
    /// projected into the canonical ABI for the shared joint input admission.
    pub(crate) fn validate_flow_transfer_inputs<V: Borrow<crate::value::RuntimeValue>>(
        &self,
        flow: &FlowRuntimeId,
        transfer: &super::RuntimeFlowTransfer<V>,
    ) -> Result<
        (
            super::function_inputs::RuntimeFunctionInputAdmission<'_>,
            crate::value::RuntimeInputOrder,
        ),
        RuntimeFlowInvocationError,
    > {
        let (_, order) = self.validate_flow_transfer_shape(flow, transfer)?;
        let mut references = vec![None; transfer.arguments.len()];
        for argument in &transfer.arguments {
            references[argument.parameter.position() as usize] = Some(argument.value.borrow());
        }
        let bindings = references
            .into_iter()
            .enumerate()
            .map(|(index, value)| RuntimeFlowParameterBinding {
                parameter: FlowParameterCoordinate::from_position(index as u32),
                value: value.expect("the checked transfer permutation covers every input"),
            })
            .collect::<Vec<_>>();
        let declaration = self.validate_flow_invocation_with_work(
            flow,
            &bindings,
            &crate::entry::schema::value_budget::ValidationWork::new(
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ),
        )?;
        declaration
            .validate_owned_patterns(
                &[],
                &bindings
                    .iter()
                    .map(|binding| binding.value)
                    .collect::<Vec<_>>(),
            )
            .map_err(|error| RuntimeFlowInvocationError::TransferPattern(Box::new(error)))?;
        Ok((declaration, order))
    }

    /// Consumes this immutable plan and seals a complete coordinate-addressed
    /// invocation for one exact Flow.
    ///
    /// The accepted schema bounds input storage. Collection ignores the
    /// caller's iterator size hint and stops at the first excess binding,
    /// without retaining it or consuming the remaining inputs.
    pub fn seal_flow_invocation(
        self,
        flow: FlowRuntimeId,
        bindings: impl IntoIterator<Item = RuntimeFlowParameterBinding>,
    ) -> Result<RuntimeFlowInvocation, RuntimeFlowInvocationError> {
        let collected = self.collect_flow_invocation_bindings(&flow, bindings)?;
        self.validate_flow_invocation(&flow, &collected)?;
        Ok(RuntimeFlowInvocation {
            plan: Arc::new(self),
            flow,
            bindings: collected.into_boxed_slice(),
        })
    }

    /// Copies a complete borrowed inventory only after its resources, original
    /// program storage, deep Copy ownership and joint input ABI are admitted.
    /// All roots and type/effect relations spend the same allowance. The
    /// returned invocation owns this exact plan and no partial value copy is
    /// made on rejection.
    pub fn seal_flow_invocation_copying<'value>(
        self,
        flow: FlowRuntimeId,
        bindings: impl IntoIterator<
            Item = RuntimeFlowParameterBinding<&'value crate::value::RuntimeValue>,
        >,
        limits: crate::entry::RuntimeSchemaLimits,
    ) -> Result<RuntimeFlowInvocation, RuntimeFlowInvocationError> {
        let plan = Arc::new(self);
        let bindings = plan.copy_flow_invocation_bindings(&flow, bindings, limits)?;
        Ok(RuntimeFlowInvocation {
            plan,
            flow,
            bindings,
        })
    }

    fn copy_flow_invocation_bindings<'value>(
        self: &Arc<Self>,
        flow: &FlowRuntimeId,
        bindings: impl IntoIterator<
            Item = RuntimeFlowParameterBinding<&'value crate::value::RuntimeValue>,
        >,
        limits: crate::entry::RuntimeSchemaLimits,
    ) -> Result<Box<[RuntimeFlowParameterBinding]>, RuntimeFlowInvocationError> {
        let mut admission = crate::value::RuntimeRetainedValueAdmission::for_program(
            crate::task::RuntimeProgramOwner::Plan(Arc::clone(self)),
            limits,
        );
        let failure = |source| RuntimeFlowInvocationError::InputAdmission(Box::new(source));
        admission.validate_metadata(flow).map_err(failure)?;
        let expected = self.flow_invocation_contract(flow)?.1.parameters.len();
        admission
            .validate_metadata_collection(expected)
            .map_err(failure)?;
        let bindings = self.collect_flow_invocation_bindings(flow, bindings)?;
        for binding in &bindings {
            admission
                .validate(binding.value)
                .map_err(|source| match source {
                    crate::value::AwbcRuntimeValueSnapshotError::AffineValue => {
                        RuntimeFlowInvocationError::NonCopyableParameter {
                            parameter: binding.parameter,
                        }
                    }
                    source => failure(source),
                })?;
        }
        self.validate_flow_invocation_with_work(flow, &bindings, &admission.work())?;
        Ok(bindings
            .into_iter()
            .map(|binding| RuntimeFlowParameterBinding {
                parameter: binding.parameter,
                value: binding.value.clone(),
            })
            .collect())
    }

    fn collect_flow_invocation_bindings<V>(
        &self,
        flow: &FlowRuntimeId,
        bindings: impl IntoIterator<Item = RuntimeFlowParameterBinding<V>>,
    ) -> Result<Vec<RuntimeFlowParameterBinding<V>>, RuntimeFlowInvocationError> {
        let expected = self.flow_invocation_contract(flow)?.1.parameters.len();
        let mut collected = Vec::with_capacity(expected);
        for binding in bindings {
            if collected.len() == expected {
                return Err(RuntimeFlowInvocationError::BindingCount {
                    flow: flow.canonical_label(),
                    expected,
                    actual: collected.len() + 1,
                });
            }
            collected.push(binding);
        }
        Ok(collected)
    }

    /// Coordinate admission and the actual FunctionSite input ABI are one
    /// boundary for sealing, native activation, stateful startup and goto.
    pub(crate) fn validate_flow_invocation(
        &self,
        flow: &FlowRuntimeId,
        bindings: &[RuntimeFlowParameterBinding],
    ) -> Result<super::function_inputs::RuntimeFunctionInputAdmission<'_>, RuntimeFlowInvocationError>
    {
        self.validate_flow_invocation_with_work(
            flow,
            bindings,
            &crate::entry::schema::value_budget::ValidationWork::new(
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ),
        )
    }

    fn validate_flow_invocation_with_work<V: Borrow<crate::value::RuntimeValue>>(
        &self,
        flow: &FlowRuntimeId,
        bindings: &[RuntimeFlowParameterBinding<V>],
        work: &crate::entry::schema::value_budget::ValidationWork,
    ) -> Result<super::function_inputs::RuntimeFunctionInputAdmission<'_>, RuntimeFlowInvocationError>
    {
        let flow_label = flow.canonical_label();
        let (runtime_flow, schema) = self.flow_invocation_contract(flow)?;
        if bindings.len() != schema.parameters.len() {
            return Err(RuntimeFlowInvocationError::BindingCount {
                flow: flow_label,
                expected: schema.parameters.len(),
                actual: bindings.len(),
            });
        }
        let mut unique = BTreeSet::new();
        for (index, binding) in bindings.iter().enumerate() {
            if !unique.insert(binding.parameter) {
                return Err(RuntimeFlowInvocationError::DuplicateParameter {
                    flow: flow_label,
                    parameter: binding.parameter,
                });
            }
            if binding.parameter.index().ok() != Some(index) {
                return Err(RuntimeFlowInvocationError::NonCanonicalParameter {
                    flow: flow_label,
                    index,
                    parameter: binding.parameter,
                });
            }
            schema
                .parameters
                .get(index)
                .filter(|parameter| parameter.coordinate == binding.parameter)
                .ok_or_else(|| RuntimeFlowInvocationError::UnknownParameter {
                    flow: flow_label.clone(),
                    parameter: binding.parameter,
                })?;
        }
        let arguments = bindings
            .iter()
            .map(|binding| binding.value.borrow())
            .collect::<Vec<_>>();
        Ok(self.validate_function_site_input_refs_with_work(
            runtime_flow.function_site(),
            &[],
            &arguments,
            work,
        )?)
    }
}

impl RuntimeFlowInvocation {
    /// Repeats this inventory under the selected copy limits. All original
    /// values, ownership and type/effect relations pass the same borrowed
    /// admission as initial copying before any value is cloned. The repeated
    /// invocation retains this exact immutable plan.
    ///
    /// # Errors
    ///
    /// Rejects resource, ownership or ABI failures without copying a partial
    /// inventory or changing the original invocation.
    pub fn try_repeat_unrestricted(
        &self,
        limits: crate::entry::RuntimeSchemaLimits,
    ) -> Result<Self, RuntimeFlowInvocationError> {
        let bindings = self.plan.copy_flow_invocation_bindings(
            &self.flow,
            self.bindings
                .iter()
                .map(|binding| RuntimeFlowParameterBinding {
                    parameter: binding.parameter,
                    value: &binding.value,
                }),
            limits,
        )?;
        Ok(Self {
            plan: Arc::clone(&self.plan),
            flow: self.flow.clone(),
            bindings,
        })
    }

    /// Borrows the exact immutable plan pinned by this affine invocation.
    pub const fn plan(&self) -> &Arc<RuntimePlan> {
        &self.plan
    }

    pub(crate) fn into_parts(
        self,
    ) -> (
        Arc<RuntimePlan>,
        FlowRuntimeId,
        Box<[RuntimeFlowParameterBinding]>,
    ) {
        (self.plan, self.flow, self.bindings)
    }
}

/// Lowered entry declaration preserved for CLI/LSP/runtime launch selection.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RuntimeEntrySpec {
    pub id: EntryRuntimeId,
    pub kind: RuntimeEntryKind,
    /// Stable semantic identity of the complete checked entry binding.
    ///
    /// This exists for every entry, including non-stateful entries whose role
    /// variant is [`RuntimeEntryRoles::None`].
    pub binding: EntryBindingIdentity,
    pub target: RuntimeEntryTarget,
    pub roles: RuntimeEntryRoles,
}

impl EntryRuntimeId {
    pub(crate) fn from_source_path(path: RuntimeIdPath) -> Self {
        Self { path }
    }

    pub fn canonical(value: &str) -> Result<Self, RuntimeIdError> {
        RuntimeIdPath::from_canonical_str(RuntimeIdFamily::Entry, value).map(|path| Self { path })
    }

    pub fn from_source_entity_body(value: &str) -> Result<Self, RuntimeIdError> {
        RuntimeIdPath::from_source_entity_body(
            RuntimeIdFamily::Entry,
            value,
            RuntimeIdFamily::Entry.source_families(),
        )
        .map(|path| Self { path })
    }

    #[must_use]
    pub const fn path(&self) -> &RuntimeIdPath {
        &self.path
    }

    #[must_use]
    pub fn canonical_label(&self) -> String {
        self.path.label()
    }

    #[must_use]
    pub fn public_label(&self) -> RuntimePublicLabel {
        RuntimePublicLabel::for_family(RuntimeIdFamily::Entry, &self.path)
    }
}

impl fmt::Display for EntryRuntimeId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.path.fmt(f)
    }
}

impl RuntimeEntryKind {
    /// Whether a direct Flow target receives its complete input inventory from
    /// the invoking adapter. Bench measurements seal those inputs before each
    /// execution; ordinary direct Entry startup supplies no external inventory.
    #[must_use]
    pub const fn accepts_external_flow_inputs(&self) -> bool {
        matches!(self, Self::Bench)
    }

    /// Canonical source/manifest spelling for this entry kind.
    pub fn as_str(&self) -> &str {
        match self {
            Self::Game => "game",
            Self::Editor => "editor",
            Self::Cli => "cli",
            Self::Server => "server",
            Self::Activity => "activity",
            Self::Test => "test",
            Self::Bench => "bench",
            Self::Agent => "agent",
            Self::Custom(value) => value,
        }
    }

    #[must_use]
    pub const fn is_stateful(&self) -> bool {
        matches!(self, Self::Game | Self::Editor | Self::Test)
    }

    #[must_use]
    pub const fn is_agent(&self) -> bool {
        matches!(self, Self::Agent)
    }

    /// Stable discriminator used by entry-binding encoders.
    #[must_use]
    pub const fn canonical_tag(&self) -> u8 {
        match self {
            Self::Game => 1,
            Self::Editor => 2,
            Self::Test => 3,
            Self::Agent => 4,
            Self::Cli => 5,
            Self::Server => 6,
            Self::Activity => 7,
            Self::Bench => 8,
            Self::Custom(_) => u8::MAX,
        }
    }

    /// Payload carried only by a custom entry kind.
    #[must_use]
    pub fn custom_payload(&self) -> Option<&str> {
        match self {
            Self::Custom(value) => Some(value),
            Self::Game
            | Self::Editor
            | Self::Cli
            | Self::Server
            | Self::Activity
            | Self::Test
            | Self::Bench
            | Self::Agent => None,
        }
    }
}

impl RuntimeEntryTarget {
    #[must_use]
    pub const fn flow(&self) -> Option<&FlowRuntimeId> {
        match self {
            Self::Flow(flow) | Self::Controller(flow) => Some(flow),
            Self::Routes(_) => None,
        }
    }

    #[must_use]
    pub const fn is_controller(&self) -> bool {
        matches!(self, Self::Controller(_))
    }
}

impl FlowRuntimeId {
    /// Creates one generated controller flow for an exact ordinary callable.
    ///
    /// Multiple Agent entries bound to the same callable intentionally share
    /// this code identity while retaining distinct entry bindings and policy.
    #[must_use]
    pub fn for_agent_controller_callable(callable: &RuntimeCallableId) -> Self {
        Self::from_runtime_path(RuntimeIdPath::for_agent_controller_callable(
            callable.as_str(),
        ))
    }
}

/// Failure to validate one complete executable runtime-plan inventory.
#[derive(Clone, Debug, Error, PartialEq)]
pub enum RuntimePlanError {
    #[error(transparent)]
    CallableState(#[from] super::RuntimeCallableStateError),
    #[error(transparent)]
    CallableSpecialization(#[from] super::RuntimeCallableSpecializationError),
    #[error("invalid data codec-use policy: {0}")]
    DataCodecUse(Box<crate::program_types::RuntimeProgramDataShapeError>),
    #[error("duplicate runtime flow `{0}`")]
    DuplicateFlow(String),
    #[error("Flow {flow} does not reference its actual immutable Flow function row")]
    InvalidFlowFunctionOwner { flow: String },
    #[error("Flow function rows have {actual} owners for {expected} Root Flows")]
    FlowFunctionOwnerCount { actual: usize, expected: usize },
    #[error("Flow {flow} parameter schema differs from its function input contract")]
    FlowParameterContractMismatch { flow: String },
    #[error("duplicate runtime entry `{0}`")]
    DuplicateEntry(String),
    #[error("duplicate runtime pure-helper slot {0}")]
    DuplicatePureHelper(usize),
    #[error("duplicate role-callable executable metadata for `{0}`")]
    DuplicateCallableExecutable(String),
    #[error("duplicate role-flow executable metadata for `{0}`")]
    DuplicateFlowExecutable(String),
    #[error("duplicate runtime Flow invocation schema for `{0}`")]
    DuplicateFlowSchema(String),
    #[error("runtime Flow invocation schema references missing flow `{0}`")]
    MissingSchemaFlow(String),
    #[error("runtime Flow `{0}` has no invocation schema")]
    MissingFlowSchema(String),
    #[error("role-callable `{callable}` maps to missing controller flow `{flow}`")]
    MissingCallableControllerFlow { callable: String, flow: String },
    #[error("role-callable `{callable}` maps to missing function site `{site}`")]
    MissingCallableFunctionSite {
        callable: String,
        site: RuntimeFunctionSiteId,
    },
    #[error("role-flow executable metadata references missing flow `{0}`")]
    MissingExecutableFlow(String),
    #[error("entry `{entry}` targets missing flow `{flow}`")]
    MissingEntryTarget { entry: String, flow: String },
    #[error("entry `{entry}` has incompatible kind `{kind}`, target, and roles")]
    IncompatibleEntryRoles { entry: String, kind: String },
    #[error("entry `{entry}` top-level binding does not match its role binding")]
    EntryBindingMismatch { entry: String },
    #[error("entry `{entry}` state role layout does not match its runtime schema")]
    StateLayoutMismatch { entry: String },
    #[error("entry `{entry}` event role layout does not match its runtime schema")]
    EventLayoutMismatch { entry: String },
    #[error("entry `{entry}` initial flow has an invalid state-parameter binding")]
    InvalidInitialFlowStateParameter { entry: String },
    #[error("entry `{entry}` initial flow executable contract does not match its checked role")]
    InitialFlowContractMismatch { entry: String },
    #[error("entry `{entry}` has invalid durable-root execution limits")]
    InvalidRootExecutionLimits { entry: String },
    #[error("entry `{entry}` Agent controller flow does not match its checked controller role")]
    AgentControllerFlowMismatch { entry: String },
    #[error(
        "entry `{entry}` contains duplicate command constructor `{constructor}` for target `{target}`"
    )]
    DuplicateCommandContract {
        entry: String,
        constructor: String,
        target: String,
    },
    #[error(
        "entry `{entry}` command constructor `{constructor}` payload layout does not match its runtime schema"
    )]
    CommandLayoutMismatch { entry: String, constructor: String },
    #[error("entry `{entry}` role `{role}` has an invalid runtime schema: {message}")]
    InvalidRoleSchema {
        entry: String,
        role: &'static str,
        message: String,
    },
    #[error("entry `{entry}` role `{role}` references missing executable callable `{callable}`")]
    MissingCallable {
        entry: String,
        role: &'static str,
        callable: String,
    },
    #[error(
        "entry `{entry}` role `{role}` callable `{callable}` executable contract does not match"
    )]
    CallableContractMismatch {
        entry: String,
        role: &'static str,
        callable: String,
    },
    #[error("role-callable executable `{0}` is not reachable from an entry role")]
    UnreachableCallableExecutable(String),
    #[error("runtime pure program {program} is bound more than once")]
    DuplicatePureProgram {
        program: arcweft_id::runtime_program::RuntimePureProgramId,
    },
    #[error("runtime pure program {program} references missing function site {site}")]
    MissingPureProgramSite {
        program: arcweft_id::runtime_program::RuntimePureProgramId,
        site: crate::runtime_id::RuntimeFunctionSiteId,
    },
    #[error(
        "runtime pure program {program} semantic signature does not match function site {site}"
    )]
    PureProgramSignatureMismatch {
        program: arcweft_id::runtime_program::RuntimePureProgramId,
        site: crate::runtime_id::RuntimeFunctionSiteId,
    },
    #[error("role-flow executable `{0}` is not reachable from an entry role")]
    UnreachableFlowExecutable(String),
    #[error("entry `{entry}` route targets missing flow `{flow}`")]
    MissingRouteTarget { entry: String, flow: String },
    #[error("entry `{entry}` route set is empty")]
    EmptyRouteSet { entry: String },
    #[error("entry `{entry}` contains a non-canonical route path: {reason}")]
    InvalidRoutePath { entry: String, reason: String },
    #[error("entry `{entry}` contains overlapping or non-canonically ordered routes")]
    InvalidRouteOrder { entry: String },
    #[error("entry `{entry}` target flow `{flow}` has no executable parameter schema")]
    MissingEntryFlowExecutable { entry: String, flow: String },
    #[error("entry `{entry}` route to `{flow}` has an invalid closed binding plan")]
    InvalidRouteBindings { entry: String, flow: String },
    #[error("entry `{entry}` direct target `{flow}` requires parameters")]
    ParameterizedDirectEntryTarget { entry: String, flow: String },
    #[error("runtime plan references missing project-call site {site}")]
    MissingProjectCallSite { site: RuntimeProjectCallSiteId },
    #[error("runtime plan references missing defer site {site}")]
    MissingDeferSite { site: RuntimeDeferSiteId },
    #[error("runtime defer site {site} capture ABI does not match its executable body")]
    InvalidDeferCaptureAbi { site: RuntimeDeferSiteId },
    #[error("runtime defer site {site} does not identify a capture-only Unit executable body")]
    InvalidDeferFunctionSite { site: RuntimeDeferSiteId },
    #[error("runtime defer-site table exceeds its identity space")]
    DeferSiteIdentityExhausted,
    #[error("invalid Flow transfer: {0}")]
    FlowTransfer(#[source] Box<RuntimeFlowInvocationError>),
}

impl RuntimePlan {
    /// Verifies the complete immutable executable inventory before selection.
    pub fn verify(&self) -> Result<(), RuntimePlanError> {
        self.inventory.verify()
    }
}

impl super::RuntimePlanInventory {
    /// Verifies the complete executable entry inventory before selection.
    pub fn verify(&self) -> Result<(), RuntimePlanError> {
        for flow in self.flows() {
            let Some(function) = self.function_sites.shared(flow.function_site()) else {
                return Err(RuntimePlanError::InvalidFlowFunctionOwner {
                    flow: flow.id.canonical_label(),
                });
            };
            let params = function
                .parameter_inputs()
                .map(super::RuntimeFunctionInputBinding::input_local)
                .collect::<Vec<_>>();
            if !std::sync::Arc::ptr_eq(&function, &flow.function)
                || function.role() != super::RuntimeFunctionSemanticRole::Flow
                || !matches!(
                    function.body(),
                    super::RuntimeFunctionSiteBody::Executable(_)
                )
                || params.as_slice() != flow.params.as_ref()
            {
                return Err(RuntimePlanError::InvalidFlowFunctionOwner {
                    flow: flow.id.canonical_label(),
                });
            }
        }

        let roots = self
            .flows
            .iter()
            .map(|flow| flow.function_site())
            .collect::<BTreeSet<_>>();
        let actual = self
            .function_sites
            .iter()
            .filter(|site| site.role() == super::RuntimeFunctionSemanticRole::Flow)
            .count();
        if roots.len() != self.flows.len() || actual != roots.len() {
            return Err(RuntimePlanError::FlowFunctionOwnerCount {
                actual,
                expected: self.flows.len(),
            });
        }

        self.callable_states.validate_for_plan(self)?;
        for definition in self.callable_specializations() {
            definition.validate(
                self,
                crate::entry::RuntimeSchemaLimits::engine_default().max_validation_work,
            )?;
        }
        let flow_ids = self.verify_flow_schemas()?;
        self.verify_executable_sites()?;
        let mut helper_ids = BTreeSet::new();
        for helper in &self.pure_helpers {
            if !helper_ids.insert(helper.id) {
                return Err(RuntimePlanError::DuplicatePureHelper(helper.id.0));
            }
        }
        self.verify_pure_programs()?;
        crate::program_types::RuntimeProgramDataShapes::new(
            crate::program_types::RuntimeProgramTypes::Plan(self),
        )
        .validate_codec_uses(crate::entry::RuntimeSchemaLimits::engine_default())
        .map_err(|error| RuntimePlanError::DataCodecUse(Box::new(error)))?;
        let mut callable_ids = BTreeSet::new();
        for executable in &self.callable_executables {
            if !callable_ids.insert(executable.callable.clone()) {
                return Err(RuntimePlanError::DuplicateCallableExecutable(
                    executable.callable.as_str().to_owned(),
                ));
            }
            match &executable.code {
                RuntimeCallableExecutableCode::ControllerFlow(flow) if !flow_ids.contains(flow) => {
                    return Err(RuntimePlanError::MissingCallableControllerFlow {
                        callable: executable.callable.as_str().to_owned(),
                        flow: flow.canonical_label(),
                    });
                }
                RuntimeCallableExecutableCode::FunctionSite(site)
                    if self.function_sites().get(*site).is_none() =>
                {
                    return Err(RuntimePlanError::MissingCallableFunctionSite {
                        callable: executable.callable.as_str().to_owned(),
                        site: *site,
                    });
                }
                RuntimeCallableExecutableCode::FunctionSite(_)
                | RuntimeCallableExecutableCode::ControllerFlow(_) => {}
            }
        }
        let mut executable_flow_ids = BTreeSet::new();
        for executable in &self.flow_executables {
            if !executable_flow_ids.insert(executable.flow.clone()) {
                return Err(RuntimePlanError::DuplicateFlowExecutable(
                    executable.flow.canonical_label(),
                ));
            }
            if !flow_ids.contains(&executable.flow) {
                return Err(RuntimePlanError::MissingExecutableFlow(
                    executable.flow.canonical_label(),
                ));
            }
        }
        let mut entry_ids = BTreeSet::new();
        for entry in &self.entries {
            if !entry_ids.insert(entry.id.clone()) {
                return Err(RuntimePlanError::DuplicateEntry(entry.id.canonical_label()));
            }
            self.verify_entry(entry, &flow_ids)?;
        }
        for executable in &self.callable_executables {
            if !self.entries.iter().any(|entry| {
                entry
                    .roles
                    .references_callable(&executable.callable, executable.contract)
            }) {
                return Err(RuntimePlanError::UnreachableCallableExecutable(
                    executable.callable.as_str().to_owned(),
                ));
            }
        }
        for executable in &self.flow_executables {
            if !self
                .entries
                .iter()
                .any(|entry| entry.references_flow(&executable.flow))
            {
                return Err(RuntimePlanError::UnreachableFlowExecutable(
                    executable.flow.canonical_label(),
                ));
            }
        }
        Ok(())
    }

    fn verify_executable_sites(&self) -> Result<(), RuntimePlanError> {
        for (index, function_id) in self.defer_sites().iter().enumerate() {
            let site = RuntimeDeferSiteId::from_zero_based(index)
                .ok_or(RuntimePlanError::DeferSiteIdentityExhausted)?;
            let function = self
                .function_sites()
                .get(*function_id)
                .ok_or(RuntimePlanError::InvalidDeferFunctionSite { site })?;
            if !matches!(
                function.body(),
                super::RuntimeFunctionSiteBody::Executable(_)
            ) || !matches!(
                self.type_table()
                    .get(function.result())
                    .map(|ty| ty.projection()),
                Some(super::RuntimePlanTypeProjection::Unit)
            ) || function.parameter_inputs().next().is_some()
            {
                return Err(RuntimePlanError::InvalidDeferFunctionSite { site });
            }
        }
        self.try_visit_flow_ops(&mut |op| self.verify_executable_site_op(op))
    }

    fn verify_executable_site_op(&self, op: &FlowOp) -> Result<(), RuntimePlanError> {
        match op {
            FlowOp::Goto(transfer) => {
                let invalid = |error| RuntimePlanError::FlowTransfer(Box::new(error));
                match &transfer.target {
                    super::RuntimeFlowTransferTarget::Static(target) => {
                        self.validate_flow_transfer_shape(target, transfer)
                            .map_err(invalid)?;
                    }
                    super::RuntimeFlowTransferTarget::Dynamic(_) => {
                        transfer
                            .input_order()
                            .map_err(RuntimeFlowInvocationError::from)
                            .map_err(invalid)?;
                    }
                }
                transfer.validate_input_sources().map_err(invalid)?;
            }
            FlowOp::ProjectCall { site } => {
                if self.project_call_sites().get(*site).is_none() {
                    return Err(RuntimePlanError::MissingProjectCallSite { site: *site });
                }
            }
            FlowOp::RegisterDefer { site, captures, .. } => {
                let function_id = self
                    .defer_function_site(*site)
                    .ok_or(RuntimePlanError::MissingDeferSite { site: *site })?;
                let function = self
                    .function_sites()
                    .get(function_id)
                    .ok_or(RuntimePlanError::MissingDeferSite { site: *site })?;
                if captures.iter().any(|capture| {
                    !matches!(capture.kind(), crate::value::RuntimeExprKind::Local(_))
                }) || captures.len() != function.capture_inputs().count()
                    || !captures
                        .iter()
                        .zip(function.capture_inputs())
                        .all(|(capture, input)| capture.ty() == input.pattern().ty())
                {
                    return Err(RuntimePlanError::InvalidDeferCaptureAbi { site: *site });
                }
            }
            FlowOp::ReceiveAction { .. }
            | FlowOp::LetElse { .. }
            | FlowOp::StandardMap(_)
            | FlowOp::FormatOperandAttempt { .. }
            | FlowOp::ProgramTask { .. }
            | FlowOp::Scope { .. }
            | FlowOp::Loop { .. }
            | FlowOp::While { .. }
            | FlowOp::WhileLet { .. }
            | FlowOp::If { .. }
            | FlowOp::IfLet { .. }
            | FlowOp::Match { .. }
            | FlowOp::For { .. }
            | FlowOp::Await { .. }
            | FlowOp::Let { .. }
            | FlowOp::Assign { .. }
            | FlowOp::LineOperation { .. }
            | FlowOp::CommitDialogueResult { .. }
            | FlowOp::SelectDialogueResult { .. }
            | FlowOp::Dialogue { .. }
            | FlowOp::Choice { .. }
            | FlowOp::AwaitMany { .. }
            | FlowOp::StartNeedProducer { .. }
            | FlowOp::HostCall { .. }
            | FlowOp::ApplyGroup { .. }
            | FlowOp::Break { .. }
            | FlowOp::Continue { .. }
            | FlowOp::Return(_)
            | FlowOp::ReturnExpr(_)
            | FlowOp::Effect(_)
            | FlowOp::EvaluatedEffect(_)
            | FlowOp::RegisterCleanup { .. }
            | FlowOp::CancelCleanup { .. }
            | FlowOp::EnterScope { .. }
            | FlowOp::ExitScope
            | FlowOp::ExitScopeBind { .. }
            | FlowOp::Noop => {}
        }
        Ok(())
    }

    fn verify_flow_schemas(&self) -> Result<BTreeSet<FlowRuntimeId>, RuntimePlanError> {
        let mut flow_ids = BTreeSet::new();
        for flow in &self.flows {
            if !flow_ids.insert(flow.id.clone()) {
                return Err(RuntimePlanError::DuplicateFlow(flow.id.canonical_label()));
            }
        }
        let mut schema_flow_ids = BTreeSet::new();
        for schema in self.flow_schemas() {
            if !schema_flow_ids.insert(schema.flow.clone()) {
                return Err(RuntimePlanError::DuplicateFlowSchema(
                    schema.flow.canonical_label(),
                ));
            }
            if !flow_ids.contains(&schema.flow) {
                return Err(RuntimePlanError::MissingSchemaFlow(
                    schema.flow.canonical_label(),
                ));
            }
        }
        for flow in &self.flows {
            if let Some(schema) = self.flows.schema(&flow.id) {
                if !flow.matches_parameter_contract(schema) {
                    return Err(RuntimePlanError::FlowParameterContractMismatch {
                        flow: flow.id.canonical_label(),
                    });
                }
            }
        }
        if let Some(flow) = flow_ids
            .iter()
            .find(|flow| !schema_flow_ids.contains(*flow))
        {
            return Err(RuntimePlanError::MissingFlowSchema(flow.canonical_label()));
        }
        Ok(flow_ids)
    }

    fn verify_pure_programs(&self) -> Result<(), RuntimePlanError> {
        let mut pure_programs = BTreeSet::new();
        for binding in self.pure_programs() {
            if !pure_programs.insert(binding.program()) {
                return Err(RuntimePlanError::DuplicatePureProgram {
                    program: binding.program(),
                });
            }
            let Some(site) = self.function_sites.get(binding.site()) else {
                return Err(RuntimePlanError::MissingPureProgramSite {
                    program: binding.program(),
                    site: binding.site(),
                });
            };
            let input_types = site
                .inputs()
                .iter()
                .map(|input| {
                    self.local_declarations
                        .get(input.input_local())
                        .and_then(|declaration| self.type_table.get(declaration.ty()))
                        .map(super::type_table::RuntimePlanTypeDeclaration::semantic_identity)
                })
                .collect::<Option<Vec<_>>>();
            let result_type = self
                .type_table
                .get(site.result())
                .map(super::type_table::RuntimePlanTypeDeclaration::semantic_identity);
            if input_types.as_deref() != Some(binding.input_types())
                || result_type != Some(binding.result_type())
                || !site.body().is_effect_free()
            {
                return Err(RuntimePlanError::PureProgramSignatureMismatch {
                    program: binding.program(),
                    site: binding.site(),
                });
            }
        }
        Ok(())
    }

    fn verify_entry(
        &self,
        entry: &RuntimeEntrySpec,
        flow_ids: &BTreeSet<FlowRuntimeId>,
    ) -> Result<(), RuntimePlanError> {
        let entry_label = entry.id.canonical_label();
        match &entry.target {
            RuntimeEntryTarget::Flow(flow) | RuntimeEntryTarget::Controller(flow) => {
                if !flow_ids.contains(flow) {
                    return Err(RuntimePlanError::MissingEntryTarget {
                        entry: entry_label,
                        flow: flow.canonical_label(),
                    });
                }
            }
            RuntimeEntryTarget::Routes(routes) => {
                for route in routes {
                    if !flow_ids.contains(&route.target) {
                        return Err(RuntimePlanError::MissingRouteTarget {
                            entry: entry_label,
                            flow: route.target.canonical_label(),
                        });
                    }
                }
            }
        }
        if entry
            .roles
            .binding()
            .is_some_and(|role_binding| role_binding != entry.binding)
        {
            return Err(RuntimePlanError::EntryBindingMismatch {
                entry: entry.id.canonical_label(),
            });
        }

        match (&entry.kind, &entry.target, &entry.roles) {
            (
                RuntimeEntryKind::Game | RuntimeEntryKind::Editor | RuntimeEntryKind::Test,
                RuntimeEntryTarget::Flow(target),
                RuntimeEntryRoles::Stateful(roles),
            ) if target == &roles.initial_flow.flow => self.verify_stateful_entry(&entry.id, roles),
            (
                RuntimeEntryKind::Agent,
                RuntimeEntryTarget::Controller(flow),
                RuntimeEntryRoles::Agent(roles),
            ) => {
                let callable = self.verify_callable(&entry.id, "controller", &roles.controller)?;
                if callable.code != RuntimeCallableExecutableCode::ControllerFlow(flow.clone()) {
                    return Err(RuntimePlanError::AgentControllerFlowMismatch {
                        entry: entry.id.canonical_label(),
                    });
                }
                let Some(executable) = self
                    .flow_executables
                    .iter()
                    .find(|executable| executable.flow == *flow)
                else {
                    return Err(RuntimePlanError::AgentControllerFlowMismatch {
                        entry: entry.id.canonical_label(),
                    });
                };
                if executable.controller.as_ref() != Some(&roles.controller) {
                    return Err(RuntimePlanError::AgentControllerFlowMismatch {
                        entry: entry.id.canonical_label(),
                    });
                }
                Ok(())
            }
            (
                RuntimeEntryKind::Cli
                | RuntimeEntryKind::Server
                | RuntimeEntryKind::Activity
                | RuntimeEntryKind::Bench
                | RuntimeEntryKind::Custom(_),
                RuntimeEntryTarget::Flow(_) | RuntimeEntryTarget::Routes(_),
                RuntimeEntryRoles::None,
            ) => self.verify_existing_entry_target(&entry.id, &entry.kind, &entry.target),
            _ => Err(RuntimePlanError::IncompatibleEntryRoles {
                entry: entry.id.canonical_label(),
                kind: entry.kind.as_str().to_owned(),
            }),
        }
    }

    fn verify_existing_entry_target(
        &self,
        entry: &EntryRuntimeId,
        kind: &RuntimeEntryKind,
        target: &RuntimeEntryTarget,
    ) -> Result<(), RuntimePlanError> {
        match target {
            RuntimeEntryTarget::Flow(flow) => {
                self.flow_executables
                    .iter()
                    .find(|row| row.flow == *flow)
                    .ok_or_else(|| RuntimePlanError::MissingEntryFlowExecutable {
                        entry: entry.canonical_label(),
                        flow: flow.canonical_label(),
                    })?;
                let schema = self
                    .flows
                    .schema(flow)
                    .ok_or_else(|| RuntimePlanError::MissingFlowSchema(flow.canonical_label()))?;
                if !schema.parameters.is_empty() && !kind.accepts_external_flow_inputs() {
                    return Err(RuntimePlanError::ParameterizedDirectEntryTarget {
                        entry: entry.canonical_label(),
                        flow: flow.canonical_label(),
                    });
                }
                Ok(())
            }
            RuntimeEntryTarget::Routes(routes) => self.verify_route_entry_target(entry, routes),
            RuntimeEntryTarget::Controller(_) => Err(RuntimePlanError::IncompatibleEntryRoles {
                entry: entry.canonical_label(),
                kind: "non-stateful".to_owned(),
            }),
        }
    }

    fn verify_route_entry_target(
        &self,
        entry: &EntryRuntimeId,
        routes: &[RuntimeRouteSpec],
    ) -> Result<(), RuntimePlanError> {
        if routes.is_empty() {
            return Err(RuntimePlanError::EmptyRouteSet {
                entry: entry.canonical_label(),
            });
        }
        for (index, route) in routes.iter().enumerate() {
            route
                .path
                .validate()
                .map_err(|error| RuntimePlanError::InvalidRoutePath {
                    entry: entry.canonical_label(),
                    reason: error.to_string(),
                })?;
            if routes[..index].iter().any(|previous| {
                previous.method == route.method && previous.path.overlaps_dispatch(&route.path)
            }) || index > 0
                && routes[index - 1]
                    .method
                    .cmp(&route.method)
                    .then_with(|| routes[index - 1].path.dispatch_cmp(&route.path))
                    != Ordering::Less
            {
                return Err(RuntimePlanError::InvalidRouteOrder {
                    entry: entry.canonical_label(),
                });
            }
            self.flow_executables
                .iter()
                .find(|row| row.flow == route.target)
                .ok_or_else(|| RuntimePlanError::MissingEntryFlowExecutable {
                    entry: entry.canonical_label(),
                    flow: route.target.canonical_label(),
                })?;
            let schema = self.flows.schema(&route.target).ok_or_else(|| {
                RuntimePlanError::MissingFlowSchema(route.target.canonical_label())
            })?;
            let string_identity =
                crate::pattern::RuntimeCheckedType::String.semantic_identity_digest();
            let mut captures = BTreeSet::new();
            let parameters_valid =
                schema
                    .parameters
                    .iter()
                    .enumerate()
                    .all(|(parameter_index, parameter)| {
                        parameter.coordinate.index().ok() == Some(parameter_index)
                            && parameter.mode == RuntimeFlowParameterMode::Owned
                            && parameter.semantic_identity == string_identity
                    });
            let bindings_valid =
                route
                    .bindings
                    .iter()
                    .enumerate()
                    .all(|(parameter_index, binding)| {
                        binding.parameter.index().ok() == Some(parameter_index)
                            && match binding.source {
                                RuntimeRouteBindingSource::PathCapture(capture) => {
                                    capture.index().ok().is_some_and(|capture_index| {
                                        capture_index < route.path.capture_count()
                                            && captures.insert(capture_index)
                                    })
                                }
                            }
                    });
            if schema.parameters.len() != route.bindings.len()
                || route.path.capture_count() != route.bindings.len()
                || !parameters_valid
                || !bindings_valid
                || captures.len() != route.path.capture_count()
            {
                return Err(RuntimePlanError::InvalidRouteBindings {
                    entry: entry.canonical_label(),
                    flow: route.target.canonical_label(),
                });
            }
        }
        Ok(())
    }

    fn verify_stateful_entry(
        &self,
        entry: &EntryRuntimeId,
        roles: &RuntimeStatefulEntryRoles,
    ) -> Result<(), RuntimePlanError> {
        if !roles.command_policy.root_limits.is_valid() {
            return Err(RuntimePlanError::InvalidRootExecutionLimits {
                entry: entry.canonical_label(),
            });
        }
        for (name, role) in [("state", &roles.state), ("event", &roles.event)] {
            role.validate_for_program(crate::program_types::RuntimeProgramTypes::Plan(self))
                .map_err(|error| match (name, error) {
                    (
                        "state",
                        crate::program_types::RuntimeProgramTypeError::NominalLayout { .. },
                    ) => RuntimePlanError::StateLayoutMismatch {
                        entry: entry.canonical_label(),
                    },
                    (
                        "event",
                        crate::program_types::RuntimeProgramTypeError::NominalLayout { .. },
                    ) => RuntimePlanError::EventLayoutMismatch {
                        entry: entry.canonical_label(),
                    },
                    (_, error) => RuntimePlanError::InvalidRoleSchema {
                        entry: entry.canonical_label(),
                        role: name,
                        message: error.to_string(),
                    },
                })?;
        }
        let Some(flow) = self
            .flow_executables
            .iter()
            .find(|flow| flow.flow == roles.initial_flow.flow)
        else {
            return Err(RuntimePlanError::InitialFlowContractMismatch {
                entry: entry.canonical_label(),
            });
        };
        if flow.contract != roles.initial_flow.contract {
            return Err(RuntimePlanError::InitialFlowContractMismatch {
                entry: entry.canonical_label(),
            });
        }
        let Some(schema) = self.flows.schema(&roles.initial_flow.flow) else {
            return Err(RuntimePlanError::InvalidInitialFlowStateParameter {
                entry: entry.canonical_label(),
            });
        };
        let [state_parameter] = schema.parameters.as_slice() else {
            return Err(RuntimePlanError::InvalidInitialFlowStateParameter {
                entry: entry.canonical_label(),
            });
        };
        if state_parameter.coordinate.position() != 0
            || state_parameter.name.is_empty()
            || state_parameter.name.chars().any(char::is_control)
            || state_parameter.mode != RuntimeFlowParameterMode::Owned
            || state_parameter.semantic_identity != roles.state.semantic_identity
        {
            return Err(RuntimePlanError::InvalidInitialFlowStateParameter {
                entry: entry.canonical_label(),
            });
        }
        Self::verify_stateful_command_contracts(entry, &roles.command_policy.admitted)?;
        let initializer = self.verify_callable(entry, "initializer", &roles.initializer)?;
        let reducer = self.verify_callable(entry, "reducer", &roles.reducer)?;
        if !self.verify_stateful_function_site(
            "initializer",
            initializer,
            &[],
            roles.state.semantic_identity,
        ) || !self.verify_stateful_function_site(
            "reducer",
            reducer,
            &[roles.state.semantic_identity, roles.event.semantic_identity],
            roles.state.semantic_identity,
        ) {
            return Err(RuntimePlanError::IncompatibleEntryRoles {
                entry: entry.canonical_label(),
                kind: "stateful callable code".to_owned(),
            });
        }
        Ok(())
    }

    fn verify_stateful_function_site(
        &self,
        role: &'static str,
        executable: &RuntimeCallableExecutable,
        expected_inputs: &[RuntimeSemanticTypeId],
        expected_result: RuntimeSemanticTypeId,
    ) -> bool {
        let RuntimeCallableExecutableCode::FunctionSite(site) = executable.code else {
            return false;
        };
        let Some(site) = self.function_sites().get(site) else {
            return false;
        };
        if site.capture_inputs().next().is_some() || !site.is_eager_pure_candidate() {
            return false;
        }
        let parameters = site.parameter_inputs().collect::<Vec<_>>();
        if parameters.len() != expected_inputs.len() {
            return false;
        }
        for (index, input) in parameters.iter().enumerate() {
            let super::RuntimeFunctionInputSource::Parameter { position, .. } = input.source()
            else {
                return false;
            };
            if u32::try_from(index).ok() != Some(position) {
                return false;
            }
            let Some(pattern_type) = self.type_table().get(input.pattern().ty()) else {
                return false;
            };
            let expected_input_matches = if role == "reducer" && index == 0 {
                let super::RuntimePlanTypeProjection::Reference(inner) = pattern_type.projection()
                else {
                    return false;
                };
                self.type_table()
                    .get(*inner)
                    .is_some_and(|inner| inner.semantic_identity() == expected_inputs[index])
            } else {
                pattern_type.semantic_identity() == expected_inputs[index]
            };
            if !expected_input_matches {
                return false;
            }
            let Some(local) = self.local_declarations().get(input.input_local()) else {
                return false;
            };
            if local.ty() != input.pattern().ty() {
                return false;
            }
        }
        let Some(result) = self.type_table().get(site.result()) else {
            return false;
        };
        if role == "initializer" {
            return result.semantic_identity() == expected_result;
        }
        self.is_reducer_result_type(site.result(), expected_result)
    }

    fn is_reducer_result_type(
        &self,
        result: crate::runtime_id::RuntimePlanTypeId,
        state: RuntimeSemanticTypeId,
    ) -> bool {
        let Some(declaration) = self.type_table().get(result) else {
            return false;
        };
        let super::RuntimePlanTypeProjection::Result { value, error, .. } =
            declaration.projection()
        else {
            return false;
        };
        self.is_reduction_type(*value, state) && self.is_reducer_error_type(*error)
    }

    fn is_reduction_type(
        &self,
        ty: crate::runtime_id::RuntimePlanTypeId,
        state: RuntimeSemanticTypeId,
    ) -> bool {
        let Some(declaration) = self.type_table().get(ty) else {
            return false;
        };
        let super::RuntimePlanTypeProjection::Opaque {
            producer,
            arguments,
            ..
        } = declaration.projection()
        else {
            return false;
        };
        arguments.len() == 1
            && producer.as_str() == "std.reduction"
            && self
                .type_table()
                .get(arguments[0])
                .is_some_and(|argument| argument.semantic_identity() == state)
    }

    fn is_reducer_error_type(&self, ty: crate::runtime_id::RuntimePlanTypeId) -> bool {
        let Some(declaration) = self.type_table().get(ty) else {
            return false;
        };
        let super::RuntimePlanTypeProjection::Opaque { producer, .. } = declaration.projection()
        else {
            return false;
        };
        producer.as_str() == "std.reducer_error"
    }

    fn verify_stateful_command_contracts(
        entry: &EntryRuntimeId,
        commands: &[RuntimeCommandContract],
    ) -> Result<(), RuntimePlanError> {
        let mut command_contracts = BTreeSet::new();
        for command in commands {
            let key = (
                command.constructor.as_str().to_owned(),
                command.target.as_str().to_owned(),
            );
            if !command_contracts.insert(key) {
                return Err(RuntimePlanError::DuplicateCommandContract {
                    entry: entry.canonical_label(),
                    constructor: command.constructor.as_str().to_owned(),
                    target: command.target.as_str().to_owned(),
                });
            }
            let layout = command.payload_schema.try_layout_hash().map_err(|error| {
                RuntimePlanError::InvalidRoleSchema {
                    entry: entry.canonical_label(),
                    role: "command payload",
                    message: error.to_string(),
                }
            })?;
            if layout != command.payload_layout {
                return Err(RuntimePlanError::CommandLayoutMismatch {
                    entry: entry.canonical_label(),
                    constructor: command.constructor.as_str().to_owned(),
                });
            }
        }
        Ok(())
    }

    fn verify_callable(
        &self,
        entry: &EntryRuntimeId,
        role_name: &'static str,
        role: &RuntimeCallableRole,
    ) -> Result<&RuntimeCallableExecutable, RuntimePlanError> {
        let matches = self
            .callable_executables
            .iter()
            .filter(|executable| executable.callable == role.callable)
            .collect::<Vec<_>>();
        let [executable] = matches.as_slice() else {
            return Err(RuntimePlanError::MissingCallable {
                entry: entry.canonical_label(),
                role: role_name,
                callable: role.callable.as_str().to_owned(),
            });
        };
        if executable.contract != role.contract {
            return Err(RuntimePlanError::CallableContractMismatch {
                entry: entry.canonical_label(),
                role: role_name,
                callable: role.callable.as_str().to_owned(),
            });
        }
        Ok(executable)
    }
}

impl RuntimeEntryRoles {
    fn references_callable(
        &self,
        callable: &RuntimeCallableId,
        contract: CallableContractHash,
    ) -> bool {
        match self {
            Self::Stateful(roles) => {
                role_matches(&roles.initializer, callable, contract)
                    || role_matches(&roles.reducer, callable, contract)
            }
            Self::Agent(roles) => role_matches(&roles.controller, callable, contract),
            Self::None => false,
        }
    }
}

impl RuntimeEntrySpec {
    /// Returns whether this exact checked Entry plan retains the Flow as an
    /// executable launch target.
    ///
    /// Consumers must use this owner behavior instead of reconstructing Flow
    /// reachability from Entry kind, roles, or route rows independently.
    #[must_use]
    pub fn references_flow(&self, flow: &FlowRuntimeId) -> bool {
        match &self.roles {
            RuntimeEntryRoles::Stateful(roles) => roles.initial_flow.flow == *flow,
            RuntimeEntryRoles::Agent(_) => {
                matches!(&self.target, RuntimeEntryTarget::Controller(target) if target == flow)
            }
            RuntimeEntryRoles::None => match &self.target {
                RuntimeEntryTarget::Flow(target) => target == flow,
                RuntimeEntryTarget::Routes(routes) => {
                    routes.iter().any(|route| &route.target == flow)
                }
                RuntimeEntryTarget::Controller(_) => false,
            },
        }
    }
}

fn role_matches(
    role: &RuntimeCallableRole,
    callable: &RuntimeCallableId,
    contract: CallableContractHash,
) -> bool {
    role.callable == *callable && role.contract == contract
}
