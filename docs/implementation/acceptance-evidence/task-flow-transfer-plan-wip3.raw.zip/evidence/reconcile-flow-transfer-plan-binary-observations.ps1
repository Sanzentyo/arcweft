$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$name='flow-transfer-plan-20261109.wip3.metadata.json'
$path=Join-Path $e $name
$m=[IO.File]::ReadAllText($path)|ConvertFrom-Json -Depth 100
$m|Add-Member -NotePropertyName binaryObservationScope -NotePropertyValue 'Observed current files after owners-r2 only. Core-r1 original binary hashes were not pinned; later builds updated the same paths. Catalog path reuse does not identify the original Core-r1 executable.'
foreach($row in $m.binaryHashesObservedAfterRuns){$row|Add-Member -NotePropertyName observedAfter -NotePropertyValue 'owners-r2';$row|Add-Member -NotePropertyName originalRunPin -NotePropertyValue 'not-recorded';$row|Add-Member -NotePropertyName appliesTo -NotePropertyValue 'current-file-only'}
[IO.File]::WriteAllText($path,($m|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
$archive='docs/implementation/acceptance-evidence/task-flow-transfer-plan-wip3.raw.zip'
$previous=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()
$previousBytes=(Get-Item -LiteralPath $archive).Length
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($archive),[IO.Compression.ZipArchiveMode]::Update)
try{$entry=$zip.GetEntry('evidence/'+$name);if(!$entry){throw 'Missing metadata entry'};$entry.Delete();[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$path,'evidence/'+$name);[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $e 'reconcile-flow-transfer-plan-binary-observations.ps1'),'evidence/reconcile-flow-transfer-plan-binary-observations.ps1')}finally{$zip.Dispose()}
$hash=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();$size=(Get-Item -LiteralPath $archive).Length
$p='docs/implementation/convergence-evidence-history.md';$history=[IO.File]::ReadAllText($p)
$old='後続source hash／元pathの実test EXE hashを保存した。EXEをコピー／退避していない。'
$new='後続source hash／R2終了後に元pathで観測したcurrent test EXE hashを保存した。R1の実行前後本体hashは未記録で、同じpathは後続buildで更新されたためR1本体pinとして帰属し直さない。実行前後のbinary drift 0は主張しない。EXEをコピー／退避していない。'
if(!$history.Contains($old)){throw 'Missing binary observation wording'}
$history=$history.Replace($old,$new).Replace(('27 entries／'+$previousBytes+' bytes／SHA256 '+$previous),('28 entries／'+$size+' bytes／SHA256 '+$hash))
[IO.File]::WriteAllText($p,$history,[Text.UTF8Encoding]::new($false))
[ordered]@{entries=28;bytes=$size;sha256=$hash;binaryScope='current files after r2 only; no r1 pin or drift claim'}|ConvertTo-Json -Compress
