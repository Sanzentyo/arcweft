$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prefix='flow-transfer-plan-20261109.wip3'
$base=(& git rev-parse HEAD).Trim()
if($base -ne 'b146a7490ac78f413505f8755148ef86c6048384'){throw 'Unexpected base'}
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$rust=@(git diff --name-only -- '*.rs')
$r1=@('crates/arcweft-core/src/engine/defer/tests.rs','crates/arcweft-core/src/plan/construction/source/flow.rs','crates/arcweft-core/src/plan/construction/source/flow/metadata/fields.rs','crates/arcweft-core/src/plan/construction/source/flow/tests.rs','crates/arcweft-core/src/plan/entry_inventory.rs','crates/arcweft-core/src/plan/flows/tests.rs')
$clippy=@($rust|Where-Object {$_ -notin @('crates/arcweft-core/src/engine/defer.rs','crates/arcweft-core/src/engine/line.rs')})
$snapshots=[ordered]@{}
foreach($slice in @([ordered]@{name='core-r1';paths=$r1},[ordered]@{name='clippy-r1';paths=$clippy},[ordered]@{name='owners-r2';paths=$rust})){
    $patch=Read-GitBytes (@('diff','--binary','--full-index',$base,'--')+$slice.paths)
    $name=$prefix+'.'+$slice.name+'.patch'
    [IO.File]::WriteAllBytes((Join-Path $e $name),$patch)
    $snapshots[$slice.name]=[ordered]@{base=$base;patch=$name;patchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant();paths=$slice.paths}
}
$rows=@(foreach($p in $rust){$item=Get-Item -LiteralPath $p;$original=Read-GitBytes @('show',($base+':'+$p));$text=[Text.Encoding]::UTF8.GetString($original);$baseLoc=($text -split [char]10).Length-[int]$text.EndsWith([char]10);[ordered]@{path=$p;bytes=$item.Length;physicalLoc=[IO.File]::ReadAllLines($item.FullName).Length;basePhysicalLoc=$baseLoc;kind=if($p -match '/tests[/\.]|/tests\.rs$'){'test'}else{'production'};sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$binaryRows=@(foreach($name in @('flow-transfer-plan-owner-list-r1.json','flow-transfer-plan-owners-list-r2.json')){$list=[IO.File]::ReadAllText((Join-Path $e $name))|ConvertFrom-Json -Depth 100;foreach($suite in $list.'rust-suites'.PSObject.Properties.Value){if(@($suite.testcases.PSObject.Properties|Where-Object {$_.Value.'filter-match'.status -eq 'matches'}).Count){$p=$suite.'binary-path';[ordered]@{catalog=$name;binary=$suite.'binary-id';path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}}}})
$metadata=[ordered]@{version=1;base=$base;kind='intermediate-unaccepted-source-checkpoint';sourceSnapshots=$snapshots;sourcesObservedAfterRuns=$rows;binaryHashesObservedAfterRuns=$binaryRows;coreR1=[ordered]@{executed=2394;passed=2394;failed=0;skipped=0;slow=1;seconds=145.771;testBuildSeconds=111};ownersR2=[ordered]@{executed=200;passed=200;failed=0;skipped=2361;slow=1;seconds=144.782;coreSelected=35;runtimePlanSelected=165;runtimePlanInventory=166;runtimePlanExcluded=1;testBuildSeconds=225;filter='package(=arcweft-runtime-plan) | test(flow_transfer) | test(engine::defer) | test(plan::flows) | test(flow_source)'};clippyR1=[ordered]@{exit=0;packages=@('arcweft-core','arcweft-runtime-plan');allTargets=$true;allFeatures=$true;seconds=122;warnings=$true};failedCheck=[ordered]@{exit=101;reason='one test helper used nonexistent type-table iter; repaired with id_for_semantic before successful full Core build/run'};graph=[ordered]@{workspace=98;coreReverse=53;runtimePlanReverse=16;coreTreeDifference=0};notRun=@('final 53-package reverse-dependency matrix','workspace quality gates','explicit Source argument transfer','affine presentation Flow-root transfer','full cancellation/private rollback argument matrix')}
$metadataName=$prefix+'.metadata.json'
[IO.File]::WriteAllText((Join-Path $e $metadataName),($metadata|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
$archive='docs/implementation/acceptance-evidence/task-flow-transfer-plan-wip3.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$names=@('record-flow-transfer-plan-wip3.ps1',$metadataName,'flow-transfer-plan-dev-check-r1.log','flow-transfer-plan-owner-list-r1.log','flow-transfer-plan-owner-list-r1.json','flow-transfer-plan-owner-r1.log','flow-transfer-plan-owner-clippy-r1.log','flow-transfer-plan-rdeps-metadata.json','flow-transfer-plan-rdeps-tree.log','flow-transfer-plan-rdeps.json','flow-transfer-plan-owners-list-r2.log','flow-transfer-plan-owners-list-r2.json','flow-transfer-plan-owners-r2.log')+@($snapshots.Values|ForEach-Object {$_.patch})
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($p in $rust){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,[IO.Path]::GetFullPath($p),'source/'+$p)};foreach($name in $names){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $e $name),'evidence/'+$name)}}finally{$zip.Dispose()}
$hash=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();$size=(Get-Item -LiteralPath $archive).Length
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($archive));try{$entries=$zip.Entries.Count;if(@($zip.Entries|Where-Object {$_.FullName -match '\.(exe|awfb|dll|pdb)$'}).Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$p='docs/implementation/current-status.md';$status=[IO.File]::ReadAllText($p)
$status=$status.Replace('最終検証Source','直近完了matrixのSource')
$start=$status.IndexOf('基点cbbea7f86213bc10b2a72b37f8065b981abe741eからNativeの複数保留入力',[StringComparison]::Ordinal)
$end=$status.IndexOf('診断の原文位置表示が現CLIで省略される問題も未達。',$start,[StringComparison]::Ordinal)
if($start -lt 0 -or $end -lt 0){throw 'Current goto checkpoint text changed'}
$new='途中Source b146a7490ac78f413505f8755148ef86c6048384を基点に、Nativeの全入力を借用検査してから一括Moveする経路と、元source／target instantiationを保持したprivate rollback検査を接続中。Plan公開前に静的targetの存在・完全なformal数・入力座標／whole-localを検査し、Source codecは全座標の重複を借用metadataから検査してからoperandを読む。AWBCの静的target不在時のTrap生成を削除した。段階別のCore全2394件PASSと後続owner200件PASSを区別して履歴へ保持し、件数を合算しない。二owner Clippyは終了0・警告あり。Coreの逆依存53 package全体、描画ハンドルのFlow root移管・取消し／引数のprivate rollback完全matrix、Sourceの明示bindingは未完了。[途中Source・実ログ](acceptance-evidence/task-flow-transfer-plan-wip3.raw.zip)。'
$status=$status.Substring(0,$start)+$new+$status.Substring($end)
[IO.File]::WriteAllText($p,$status,[Text.UTF8Encoding]::new($false))
$addition=@'

## 2026-11-09 Flow転送のPlan／codec admission途中checkpoint（受入未了）

先行Native途中Source b146a7490ac78f413505f8755148ef86c6048384をmainへ公開済み。parent cbbea7f86213bc10b2a72b37f8065b981abe741e、tree 0fed35aa4b6282176c9b850c6136b347ba960b2e、patch SHA256 0b19970a1bc4503fce71877ac164904690fc7b5d4513e1e74da9d6cfa476f31b。25明示pathのblob・差分・非forced remote ref一致、index空、held tracked WIP 0を確認した。今回もユーザーの途中保存指示によるcheckpointで、明示引数goto全体の受入ではない。

ABI形状検査を最終RuntimePlanInventoryへ移し、Native実行と公開前sealが同じ元Flow table／schemaを読む。静的target不在・完全formal数不足、座標permutation、distinct whole-local Moveの不正を公開前に拒否する。元Flowのunused formalとbindingを作らないliteral patternのformalも数える。型の完全admission・dynamic ABIとSourceの明示bindingは継続中。AWBC loweringはsealed Planの静的target／permutationを使い、存在しない静的FlowをTrapへ変える旧成功経路を削除した。Source codecはversion 1を維持し、借用した全座標の範囲・重複を共有workで検査してからtarget／引数rootを読む。operandの所有配列や重複検査用集合は構築せず、比較回数を先に共有meterへ課金する。

Nativeの実ケースでは、callee内でfalseをcaller slotへ評価し、引数付きGotoが内側・callee・callerのcleanupを終えてから、渡されたfalseを元の転送先formalから返すことを確認した。各stepでprivate rollbackへ保存／復元し、保留入力が関数呼出しの内側・外側の両方を通る。既存のstatic／dynamic／effect／Choice・失敗filterのケースを維持する。Actorなど描画handleのFlow root移管や全取消しmatrixの受入へ拡張しない。

開発all-targets／all-features Core checkは、test helperが存在しないtype-table iterを呼ぶ1 errorで終了101。元semantic identityを使うid_for_semanticへ修復後、Coreの同feature nextest listはbuild終了0（1分51秒）。Core r1は2394／2394 PASS、0 SKIP、1 slow、145.771秒。新規2件はmissing static targetによるPlan公開拒否と、座標順のcodec保持／値rootが存在しない入力でも先行する重複座標拒否。Native引数ケースもこのrunに含む。その後、unused／nonbinding formal数の公開拒否、retained入力のcollection preflight、AWBCの旧Trap削除を追加した。

二ownerのcargo clippy --locked -p arcweft-core -p arcweft-runtime-plan --all-targets --all-featuresは終了0／2分02秒、警告あり。その後に、Nativeで未使用になったimportとsource originの不要な所有引数を借用へ整理した。後続owners r2のnextest listはbuild終了0（3分45秒）、Core35件＋RuntimePlan165件を点検。RuntimePlan inventory166件中1件は規定除外。同じfilterのrunは200／200 PASS、2361 filter等SKIP、1 slow、144.782秒。RuntimePlanのdecoded AWBC、public save、Native parity、public API compile-failを含む。r1とr2は異なるsourceであり、合計2594件などの単一matrixにしない。原本には基点b146a7490ac78f413505f8755148ef86c6048384＋r1の6 path、Clippyの9 path、r2の11 pathをそれぞれ再現する別patchと、後続source hash／元pathの実test EXE hashを保存した。EXEをコピー／退避していない。

locked／all-features Cargo metadataのnormal／dev／build／target edgeから推移的reverse closureを算出。workspace98、Core53、RuntimePlan16。Coreのtarget all treeと集合差0。最初の照合器がfacade名arcweftをregexから落としていたfalse mismatchを修復し、同じmetadata／treeで再照合した。53 packageの最終matrixとworkspace品質gateは未実行であり、owner結果を全consumerの受入へ拡張しない。既受入のGeneric Match等は維持し、進捗は現状一覧のgoto行だけへ集約する。

所有境界の確認：Inventoryは元Flow／formal／公開seal、Flow Sourceは借用framing、Nativeはcleanup継続、AWBC Flow lowererは検証済み操作から一つのframe／instruction inventoryへの変換を所有する。依存edge・I/O・公開facadeを増やさず、既存の大きいownerへ別責任を追加していない。物理LOC／bytesと基点LOCはmetadataへ記録した。AWBCの大きいexhaustive lowererは同じFlow operationのframe状態と排他的な分岐を共有するため、この削除cutで物理行数だけの分割は行わない。
'@
$addition += [char]10+'原本 '+$archive+'：'+$entries+' entries／'+$size+' bytes／SHA256 '+$hash+'。ソース・patch・ログ・catalog・metadataのみで、EXE／AWFBは含めない。'+[char]10
$historyPath='docs/implementation/convergence-evidence-history.md';$old=[IO.File]::ReadAllBytes($historyPath);$extra=[Text.UTF8Encoding]::new($false).GetBytes($addition);$bytes=[byte[]]::new($old.Length+$extra.Length);[Array]::Copy($old,0,$bytes,0,$old.Length);[Array]::Copy($extra,0,$bytes,$old.Length,$extra.Length);[IO.File]::WriteAllBytes($historyPath,$bytes)
[IO.File]::WriteAllLines((Join-Path $e ($prefix+'.owned.txt')),($rust+@($archive,$p,$historyPath)),[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $e ($prefix+'.other.txt')),'',[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $e ($prefix+'.message.txt')),'wip(runtime): admit Flow transfer inventories before Plan publication'+[char]10,[Text.UTF8Encoding]::new($false))
[ordered]@{rustPaths=$rust.Count;entries=$entries;archive=$archive;bytes=$size;sha256=$hash}|ConvertTo-Json -Compress
