$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$record=Get-Content 'docs/implementation/acceptance-evidence/task-presentation-factory-preflight.json' -Raw|ConvertFrom-Json -Depth 100
$source=$record.source
$cli=$record.cli
$comparison=$record.cliFailureComparison
$library=$record.library
$unit=@($record.matrix.rows|Where-Object group -eq 'cli-unit')[0].terminal
$ordinary=@($record.matrix.rows|Where-Object group -eq 'cli-integration')[0].terminal
$check=@($record.matrix.rows|Where-Object group -eq 'cli-check')[0].terminal
$extra=@($record.matrix.rows|Where-Object group -eq 'cli-extra')[0].terminal
$ordinaryPassed=$library.passed+$unit.passed+$ordinary.passed
$ordinaryFailed=$library.failed+$unit.failed+$ordinary.failed
$shared=$comparison.sameFailureIds.Count
$new=$comparison.newFailureIds.Count
$resolved=$comparison.resolvedFailureIds.Count
$unselected=$comparison.unselectedPriorFailures.Count
$link='[本Sourceのowner・全逆依存・失敗原本](acceptance-evidence/task-presentation-factory-preflight.json)'
$path='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($path)
$generic=[regex]::Match($status,'(?m)^\| Generic Match.*$').Value
function Replace-Row([string]$name,[string]$replacement) {
    $pattern='(?m)^\| '+[regex]::Escape($name)+' \|.*\r?$'
    if([regex]::Matches($script:status,$pattern).Count -ne 1){throw "Unexpected status row: $name"}
    $script:status=[regex]::Replace($script:status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match) $replacement})
}
$header="確認日: 2026-11-01。公開実装Sourceは $source。元14 tracked／6 actual untracked WIPを保持し、今回の検証はその作業差分を含む4,054入力で行った。各行の結果はその入力・境界に限り、別runの結果を一つの全PASSへ合算しない。"
$status=[regex]::Replace($status,'(?m)^確認日:.*\r?$',[Text.RegularExpressions.MatchEvaluator]{param($match) $header})
Replace-Row 'Presentation resource本体・Source factory実行' "| Presentation resource本体・Source factory実行 | **Source imageのNative／decoded AWBC sliceとmetadata事前検査を検証・公開。staging全体は受入前** | 公開$source。元Source・実executable・key・tuple型・元invocationを持つaffine本体を保持する。Core owner 161件PASSと全逆依存は、AWBCの署名・実register型・結果格納先・実行contextを入力移動前に検査し、拒否10条件で元Stringのallocation・cursor・空の結果／ledgerを保つことを含む。Source／AWBC codecは同じ借用metadata grammarをコピー前に検査し、5資源上限のexact／一つ不足と重複key拒否を確認した。実Source imageの両backend実行・評価順12・Image／Root Handle・AWBC各step保存復元も当該Compiler targetでPASS。明示scope capability、View生成、command／method・driver、Native引数評価前と全live候補の構築前検査は継続中。$link。 |"
Replace-Row 'CLI・全 consumer の統合受入' "| CLI・全 consumer の統合受入 | **CLI失敗$($cli.failed)件を保持・統合受入は未完了** | $source・4,054入力の現行CLI全12 targetを下表で照合した。前Sourceの保持失敗IDとの比較は同一$shared・新規$new・解消$resolved・未選択$unselected。ID一致を原因同一とはしない。Presentation command／method・driverやJLREQ geometryの未達を、受入済みの別機能へ戻さない。$link。 |"
Replace-Row 'Presentation factory／共有値の逆依存matrix' "| Presentation factory／共有値の逆依存matrix | **62 package選択。通常3群 $ordinaryPassed PASS／$ordinaryFailed FAIL／$($library.skipped) ignored** | Source $source・4,054入力。library／integrationは $($library.executed)／$($library.passed) PASS、CLI unit $($unit.passed) PASS、通常6 integration target $($ordinary.passed) PASS。同じ入力の3 commandの合計であり、前Sourceの旧tag 17失敗と別runの修復を合算した件数ではない。4 packageは実行case 0のcompile選択。既受入Generic Match 151 IDは151／151 PASS。case／Source／EXE差分0。$link。 |"
Replace-Row 'CLI追加check target' "| CLI追加check target | **$($check.passed) PASS／$($check.failed) FAIL／$($check.skipped) ignored** | $source・4,054入力。前Source 7f506204759703e3d7baaee79832f5c697a6188cの保持43失敗IDとの比較は同一$shared・新規$new・解消$resolved・未選択$unselected。入力が異なるため、IDだけから原因同一とは判定しない。$link。 |"
Replace-Row 'CLI追加3 integration target／全target照合' "| CLI追加3 integration target／全target照合 | **追加$($extra.passed) PASS。全12 targetは$($cli.executedUnique) unique実行・$($cli.passed) PASS／$($cli.failed) FAIL・$($cli.ignored) ignored** | 同じ$source・4,054入力でbracket_numeric_batch、environment_callable_tensor、native_host_contractsを含む全lib／bin／integrationを計4 commandで照合した。case重複0、zero-case targetのcompile選択をruntimeと区別する。$link。 |"
Replace-Row 'workspace check／Clippy・fmt・構造gate' "| workspace check／Clippy・fmt・構造gate | **各gate終了0・構造blocking0・警告は残存** | $sourceと同一の4,054入力。全97 package・全target・全feature・lockedのcheck／Clippy、変更12 Rust path fmtは終了0。構造は3290 files／3160 Rust files・1784665 physical Rust LOC・384 review trigger・blocking0。default／Wasm・doctest・Tier 2は今回未再実行。$link。 |"
if([regex]::Match($status,'(?m)^\| Generic Match.*$').Value -cne $generic){throw 'Accepted Generic Match row changed'}
[IO.File]::WriteAllText($path,$status,[Text.UTF8Encoding]::new($false))
$history='docs/implementation/convergence-evidence-history.md'
$before=[IO.File]::ReadAllBytes($history)
[ordered]@{version=1;path=$history;bytes=$before.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant();genericRow=$generic}|ConvertTo-Json|Set-Content "$taskTemp/presentation-factory-preflight.docs-before.json" -Encoding utf8
$text=@"

## 2026-11-01 Factory metadataの借用preflightと入力移動前検査

- 実装公開は$source。Source／AWBC private codecはowned rowと同じ借用destination grammarを用い、完全なmetadata policy検査をキーのコピーと重複index作成より前へ移した。AWBCは署名・実register型・結果格納先・Handle owner・元実行contextを入力移動前に確認する。型・保持本体・実行leaseを代替modelへ再構成せず、既存のversion 1とwire shapeを維持する。
- 初回catalogはテストfixtureのBox配列／slice型違いで失敗。修正後の最初のownerは176／176 PASS。拡張した明示scope fixtureはImageに未許可のScopeを渡して160 PASS／1 FAILとなり、実際にScopeを許可するBackgroundへfixtureを修正して最終Core owner 161／161 PASS。productionのrole許可やassertionは緩めていない。10拒否条件の入力allocation・cursor・空の結果／ledgerと、5資源上限のowned serialization基準によるexact／一つ不足、両codecの重複key拒否を確認した。これらは異なる入力・選択の別runとして保持する。
- 全62逆依存の同一4,054入力matrixは、library／integration $($library.passed) PASS／$($library.failed) FAIL／$($library.skipped) ignored、CLI unit $($unit.passed) PASS、通常6 integration $($ordinary.passed) PASS。通常3群合計は $ordinaryPassed PASS／$ordinaryFailed FAIL。前Sourceの旧tag 17失敗を修復した結果は、この新しい全library実行で直接確認した。4 packageはcompileのみ。受入済みGeneric Match 151 IDは151／151 PASSで受入を維持する。
- CLI全12 targetは$($cli.executedUnique) unique実行・$($cli.passed) PASS／$($cli.failed) FAIL／$($cli.ignored) ignored、重複0。checkは$($check.passed) PASS／$($check.failed) FAIL／$($check.skipped) ignored、追加3 targetは$($extra.passed) PASS。前Sourceの43失敗IDとの比較は同一$shared・新規$new・解消$resolved・未選択$unselectedで、原因同一とは推定しない。
- workspace全97 package・全target・全feature・locked check／Clippy、12 owned path fmtは終了0。構造は3290 files／3160 Rust files・1784665 physical Rust LOC・384 review trigger・blocking0。警告は残存。元14 tracked／6 untracked WIPは保持した。既存19 hashとbenchの既知blob、14-path patch SHA256を照合した。
- 現状一覧の旧Source・件数は新しい実測へ差し替え、以前の結果とfull SHAは履歴・原本から削除しない。今回の早期metadata拒否を、Nativeの引数評価前検査や全live候補・後段registrationの失敗原子性の完了へ拡張しない。default／Wasm・doctest・Tier 2・最終画像parityは今回未実行であり、既受入機能の取消根拠にはしない。

[全原本](acceptance-evidence/task-presentation-factory-preflight.json)と$($record.raw.entryCount) entryのraw ZIPを保持する（entry差分0、SHA256 $($record.raw.sha256)）。
"@
[IO.File]::AppendAllText($history,$text,[Text.UTF8Encoding]::new($false))
