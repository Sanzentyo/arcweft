$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='presentation-factory-preflight-reverse-20261101'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100 }
$matrix=Read-Record "$stem.matrix"
if($matrix.status -ne 'terminal' -or $matrix.rows.Count -ne 5){throw 'Reverse matrix is not terminal'}
$prior=Read-Record 'presentation-factory-input-guard.cli-target-coverage'
$groups=@('cli-unit','cli-integration','cli-check','cli-extra')
$selected=[Collections.Generic.HashSet[string]]::new()
$targets=[Collections.Generic.HashSet[string]]::new()
$failures=[Collections.Generic.List[object]]::new()
$rows=@(foreach($group in $groups) {
    $row=@($matrix.rows | Where-Object group -eq $group)
    if($row.Count -ne 1 -or $row[0].catalogExit -ne 0 -or $null -eq $row[0].terminal){throw "Missing CLI terminal: $group"}
    $terminal=$row[0].terminal
    if($terminal.sourceDrift -or $terminal.catalogCaseDrift){throw 'CLI drift'}
    $inventory=Read-Record "$stem.$group.catalog.inventory"
    $line=[IO.File]::ReadLines("$taskTemp/$stem.$group.catalog.log")|Where-Object {$_.StartsWith('{"rust-build-meta"')}|Select-Object -Last 1
    $catalog=$line|ConvertFrom-Json -Depth 100
    foreach($suite in $catalog.'rust-suites'.PSObject.Properties){[void]$targets.Add($suite.Value.'kind'+"`t"+$suite.Value.'binary-name')}
    foreach($case in @($inventory.rows | Where-Object status -eq 'matches')) {
        if(-not $selected.Add($case.binary+"`t"+$case.test)){throw 'Repeated CLI case'}
    }
    foreach($failure in $terminal.failureSet){$failures.Add($failure)}
    [ordered]@{group=$group;passed=$terminal.passed;failed=$terminal.failed;skipped=$terminal.skipped;catalogExit=$row[0].catalogExit;runtimeExit=$row[0].runtimeExit}
})
if(@(Compare-Object @($prior.targets|ForEach-Object {$_.kind+"`t"+$_.name}|Sort-Object) @($targets|Sort-Object)).Count){throw 'CLI targets differ from the resolved Cargo target inventory'}
if(@(git diff cf9dfb95f67bdcfd4eb4e43b1fbeb44924d0fc2f --name-only -- '*Cargo.toml' Cargo.lock rust-toolchain.toml .cargo/config.toml).Count){throw 'Cargo graph inputs differ'}
$coverage=[ordered]@{version=1;base=$matrix.base;targetCount=$prior.targetCount;targets=$prior.targets;selectedBy=$prior.selectedBy;executedUnique=$selected.Count;duplicateCases=0;passed=($rows|ForEach-Object {$_['passed']}|Measure-Object -Sum).Sum;failed=$failures.Count;ignored=($rows|ForEach-Object {$_['skipped']}|Measure-Object -Sum).Sum;groups=$rows;zeroCaseTargets=$prior.zeroCaseTargets;metadataReusedFrom=$prior.metadataReusedFrom;dependencyInputDrift=0}
if($coverage.passed+$coverage.failed -ne $coverage.executedUnique){throw 'CLI totals differ'}
$coverage|ConvertTo-Json -Depth 20|Set-Content "$taskTemp/presentation-factory-preflight.cli-target-coverage.json" -Encoding utf8
$previous=Read-Record 'presentation-factory-input-guard-reverse-20261101.cli-check.runtime.terminal-audit'
$old=@{};foreach($case in $previous.failureSet){$old[$case.binary+"`t"+$case.test]=$case}
$now=@{};foreach($case in $failures){$now[$case.binary+"`t"+$case.test]=$case}
$comparison=[ordered]@{version=1;priorInput=$previous.base;currentInput=$matrix.base;priorFailures=$old.Count;currentFailures=$now.Count;sameFailureIds=@($now.Keys|Where-Object {$old.ContainsKey($_)}|Sort-Object|ForEach-Object {$now[$_]});newFailureIds=@($now.Keys|Where-Object {-not $old.ContainsKey($_)}|Sort-Object|ForEach-Object {$now[$_]});resolvedFailureIds=@($old.Keys|Where-Object {-not $now.ContainsKey($_) -and $selected.Contains($_)}|Sort-Object|ForEach-Object {$old[$_]});unselectedPriorFailures=@($old.Keys|Where-Object {-not $selected.Contains($_)}|Sort-Object|ForEach-Object {$old[$_]});interpretation='Case identity comparison only; equal failure IDs do not establish equal causes.'}
$comparison|ConvertTo-Json -Depth 20|Set-Content "$taskTemp/presentation-factory-preflight.cli-failure-comparison.json" -Encoding utf8
if(-not(Test-Path "$taskTemp/$stem.generic-coverage.json")) {
    & "$taskTemp/audit-presentation-factory-preflight-generic.ps1"
    if($LASTEXITCODE -ne 0){throw 'Generic Match coverage audit failed'}
}
$generic=Read-Record "$stem.generic-coverage"
if($generic.base -ne $matrix.base -or $generic.sourceDrift -or $generic.catalogCaseDrift -or $generic.selected -ne 151){throw 'Generic Match audit does not match this source'}
[ordered]@{cliExecuted=$coverage.executedUnique;cliPassed=$coverage.passed;cliFailed=$coverage.failed;cliIgnored=$coverage.ignored;sameFailureIds=$comparison.sameFailureIds.Count;newFailureIds=$comparison.newFailureIds.Count;resolvedFailureIds=$comparison.resolvedFailureIds.Count;unselectedPriorFailures=$comparison.unselectedPriorFailures.Count}|ConvertTo-Json -Compress
