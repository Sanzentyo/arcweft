$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='presentation-factory-preflight-reverse-20261101'
$accepted=(Get-Content 'docs/implementation/acceptance-evidence/task-presentation-factory-validation.json' -Raw|ConvertFrom-Json -Depth 100).genericCoverage
$inventory=Get-Content "$taskTemp/$stem.libraries.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 35
$terminal=Get-Content "$taskTemp/$stem.libraries.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 35
if($terminal.catalogCaseDrift -ne 0 -or $terminal.sourceDrift -ne 0){throw 'Unverified reverse terminal'}
$catalog=@{};foreach($row in $inventory.rows){$key=$row.binary+"`0"+$row.test;if($catalog.ContainsKey($key)){throw 'Repeated catalog case'};$catalog[$key]=$row}
$failures=[Collections.Generic.HashSet[string]]::new()
foreach($row in $terminal.failureSet){[void]$failures.Add($row.binary+"`0"+$row.test)}
$cases=@(foreach($case in $accepted.cases){
    $key=$case.binary+"`0"+$case.test
    if(-not $catalog.ContainsKey($key)){throw 'Accepted Generic Match case is missing'}
    $row=$catalog[$key]
    if($row.status -ne 'matches' -or $row.ignored){throw 'Accepted Generic Match case was excluded'}
    [ordered]@{group=$case.group;binary=$case.binary;test=$case.test;selected=$true;passed=(-not $failures.Contains($key))}
})
if($accepted.acceptedCount -ne 151 -or $cases.Count -ne 151){throw 'Accepted Generic Match inventory differs'}
[ordered]@{version=1;base=$terminal.base;acceptedCommit='850534b9e9bc8c8872f6528dd00050a5e6e7699e';publicationCommit='f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2';acceptedCount=151;selected=151;passed=@($cases|Where-Object {$_.passed}).Count;failed=@($cases|Where-Object {-not $_.passed}).Count;sourceInputs=$terminal.sourceInputs;sourceDrift=0;catalogCaseDrift=0;cases=$cases;scope='Exact accepted 115 transcript / 24 coverage / 5 query / 7 Native-decoded-AWBC continuation-save case IDs, checked against the new complete library terminal; no acceptance is revoked because the overall goal or CLI boundary is incomplete.'}|ConvertTo-Json -Depth 15|Set-Content -LiteralPath "$taskTemp/$stem.generic-coverage.json" -Encoding utf8
[ordered]@{selected=151;passed=@($cases|Where-Object {$_.passed}).Count;failed=@($cases|Where-Object {-not $_.passed}).Count}|ConvertTo-Json -Compress
