$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100 }
$stem='presentation-factory-preflight-reverse-20261101'
$matrix=Read-Record "$stem.matrix"
$publication=Read-Record 'checkpoint-presentation-factory-preflight.verified'
$head=(git rev-parse HEAD).Trim()
$source=$publication.commit
if($matrix.base -ne $source -or $matrix.status -ne 'terminal'){throw 'Unexpected source or unfinished matrix'}
& git merge-base --is-ancestor $source $head
if($LASTEXITCODE -ne 0){throw 'Published source is not an ancestor of the inspected main'}
foreach($row in $publication.paths){if((git rev-parse ('HEAD:'+$row.path)).Trim() -ne $row.blob){throw 'Published implementation blob changed'}}
$library=Read-Record "$stem.libraries.runtime.terminal-audit"
$owner=Read-Record 'presentation-factory-preflight-focus4-20261101.runtime.terminal-audit'
$cli=Read-Record 'presentation-factory-preflight.cli-target-coverage'
$comparison=Read-Record 'presentation-factory-preflight.cli-failure-comparison'
$generic=Read-Record "$stem.generic-coverage"
if($library.passed -ne 8818 -or $library.failed -ne 0 -or $owner.passed -ne 161 -or $owner.failed -ne 0 -or $generic.passed -ne 151){throw 'Unexpected owner or library result'}
$quality=@(foreach($suffix in @('workspace-check','clippy','structure','fmt')) {
    $record=Read-Record "presentation-factory-preflight-quality-20261101.$suffix"
    if($record.exitCode -ne 0){throw "Quality failed: $suffix"}
    [ordered]@{gate=$suffix;record=$record}
})
$freeze=Read-Record "$stem.source-freeze"
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Source drift'}
$original=Get-Content 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json' -Raw|ConvertFrom-Json
$changed=@($original.held|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($changed.Count -ne 1 -or $changed[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or (git hash-object -- $changed[0].path).Trim() -ne '4df23c4afc860ca51ff3255befe87b69a16de39b'){throw 'Original WIP changed'}
$untracked=@(git ls-files --others --exclude-standard)
if($untracked.Count -ne 6 -or @($untracked|Where-Object {$_ -notin @($original.held.path)}).Count){throw 'Original untracked set changed'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath=Join-Path $evidence 'task-presentation-factory-preflight-raw.zip'
$receiptPath=Join-Path $evidence 'task-presentation-factory-preflight.json'
if((Test-Path $zipPath) -or (Test-Path $receiptPath)){throw 'Immutable evidence exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    $_.Name -like 'presentation-factory-preflight-*' -or $_.Name -like 'presentation-factory-preflight.*' -or
    $_.Name -like 'checkpoint-presentation-factory-preflight.*' -or $_.Name -like 'checkpoint-presentation-factory-preflight-status.*' -or
    $_.Name -in @('run-presentation-factory-preflight-quality.ps1','run-presentation-factory-preflight-reverse.ps1','audit-presentation-factory-preflight-generic.ps1','derive-presentation-factory-preflight-validation.ps1','record-presentation-factory-preflight.ps1','update-presentation-factory-preflight-docs.ps1','audit-presentation-factory-preflight-docs.ps1','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1')
})+@(Get-ChildItem "$taskTemp/presentation-factory-preflight-quality-20261101.structure-report" -File)
$files=@($files|Sort-Object FullName -Unique)
$raw=@(foreach($file in $files){[ordered]@{name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try { for($index=0;$index -lt $files.Count;$index++) {
    $entry=$archive.CreateEntry($raw[$index].name,[IO.Compression.CompressionLevel]::Optimal)
    $stream=$entry.Open();try{$bytes=[IO.File]::ReadAllBytes($files[$index].FullName);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
}}finally{$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {
    if($archive.Entries.Count -ne $raw.Count){throw 'Raw entry count differs'}
    foreach($row in $raw){$entry=$archive.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw "Raw entry differs: $($row.name)"}}
}finally{$archive.Dispose()}
$result=[ordered]@{
    version=1;date='2026-11-01';source=$source;inspectedHead=$head;status='Factory metadata and early AWBC operand admission verified; broader staging and CLI acceptance remain separate'
    publication=$publication;sourceInputs=$freeze.paths.Count;sourceDrift=0
    initialCatalog=(Read-Record 'presentation-factory-preflight-focus1-20261101.catalog')
    firstOwner=(Read-Record 'presentation-factory-preflight-focus2-20261101.runtime.terminal-audit')
    extendedFixtureFailure=(Read-Record 'presentation-factory-preflight-focus3-20261101.runtime.terminal-audit')
    owner=$owner;quality=$quality;matrix=$matrix;library=$library;cli=$cli;cliFailureComparison=$comparison;genericCoverage=$generic
    libraryCaseComparison=(Read-Record 'presentation-factory-preflight.library-case-comparison')
    catalogDiagnostic=(Read-Record 'presentation-factory-preflight.core-list-diagnostic')
    catalogObservation='The same Core executable listed directly in about 0.55 seconds. The original full catalog was subsequently observed to have completed normally; it was not stopped or restarted and its selection/configuration was unchanged. The diagnostic does not establish a cause for the listing delay.'
    implementation=@('PresentationArgumentKeyRef is a borrowed projection of the existing destination grammar; owned key serialization delegates to it. Source and AWBC readers use the same complete factory metadata preflight before key copying or duplicate indexing.','AWBC validates signature, exact signature and register type identities, destination bounds/type, Handle owner, supported scope and exact admitted execution context before taking operands. The regression preserves the String contents and allocation, vacant result, cursor, observations and absent ledger across ten rejection forms.','Wire limits and Source depth/collection/string/metadata/work limits are independent. Exact/one-below boundaries are compared to serialization of the actual owned row; Source and AWBC duplicate-key rejection and existing canonical artifact round trips remain covered.')
    corrections=@('The first catalog failed because a test used Box<[Key;1]> where a borrowed slice was required; the fixture annotation was corrected.','The extended scope fixture initially attached Scope to Image, which correctly rejected that unsupported role. The fixture was migrated to the actual Background grammar; production role acceptance was not widened. Failed attempts remain in the raw archive.')
    ownershipReview='The shared destination type owns its borrowed/owned grammar; RuntimePresentationFactoryCall owns layout and metadata admission; VM execution resources own context admission. The new borrowed projection owns no runtime grant or retained payload. Existing layer direction, ABI tags, serialization shape and version-1 domains remain unchanged.'
    limits=@('This is early metadata/context admission, not proof that every later body, registration or whole-live-contour rejection preserves operands. Native argument type admission still follows argument evaluation.','The regression exercises ten rejection forms in a private instruction dispatch; actual Native/decoded-AWBC Source image execution and per-step AWBC save/restore are covered by their separate executable cases.','Default/Wasm, doctest, Tier 2 and final Native/Web image parity were not rerun for this input.','CLI failure-ID equality is not evidence of equal causes; current source-specific results are retained separately.')
    priorEvidence='task-presentation-factory-validation.json'
    originalWip=[ordered]@{tracked=14;actualUntracked=6;unchangedOldHashes=19;benchWorkingBlob='4df23c4afc860ca51ff3255befe87b69a16de39b';heldPatchSha256=$publication.heldPatchSha256}
    raw=[ordered]@{path='task-presentation-factory-preflight-raw.zip';sha256=(Get-FileHash $zipPath).Hash.ToLowerInvariant();entryCount=$raw.Count;entryDrift=0;entries=$raw}
    recordedAt=[DateTime]::UtcNow.ToString('o')
}
$result|ConvertTo-Json -Depth 100|Set-Content $receiptPath -Encoding utf8
[ordered]@{source=$source;inspectedHead=$head;libraryPassed=$library.passed;libraryFailed=$library.failed;ownerPassed=$owner.passed;genericPassed=$generic.passed;cliPassed=$cli.passed;cliFailed=$cli.failed;rawEntries=$raw.Count;rawSha256=$result.raw.sha256;rawBytes=(Get-Item $zipPath).Length}|ConvertTo-Json -Compress
