$ErrorActionPreference = 'Stop'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem = 'action-payload-reverse-normal1-20261102'
$receipt = Get-Content -LiteralPath "$taskTemp/$stem.runtime.json" -Raw | ConvertFrom-Json
$audit = Get-Content -LiteralPath "$taskTemp/$stem.runtime.terminal-audit.json" -Raw | ConvertFrom-Json
$lines = [IO.File]::ReadAllLines($receipt.log)
$summary = [Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if ($summary -lt 0) { throw 'No terminal summary' }
$cases = @{}
foreach ($line in $lines[($summary+1)..($lines.Length-1)]) {
    if ($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$') {
        $key = $Matches[2] + "`t" + $Matches[3]
        if ($cases.ContainsKey($key)) { throw "Duplicate terminal case: $key" }
        $cases[$key] = [ordered]@{status=$Matches[1];binary=$Matches[2];test=$Matches[3]}
    }
}
if ($cases.Count -ne $audit.executed) { throw 'Terminal cases are incomplete' }
foreach ($boundary in @('genericMatch','view40')) {
    $previous = Get-Content -LiteralPath "$taskTemp/presentation-frame-mcp-reverse63-$boundary.json" -Raw | ConvertFrom-Json
    $observed = @(foreach ($case in $previous.cases) {
        $key = $case.binary + "`t" + $case.test
        if (-not $cases.ContainsKey($key)) { throw "Accepted case absent: $key" }
        $cases[$key]
    })
    $failed = @($observed | Where-Object { $_.status -notin @('PASS','SLOW') })
    [ordered]@{version=1;sourceBase=$receipt.base;productionSource='58c5b7d64febafaa8c1dab4e4546b901b5c52f58';run=$stem;accepted=$previous.accepted;passed=$observed.Count-$failed.Count;failed=$failed.Count;caseDrift=0;sourceInputs=$receipt.sourceInputs;sourceDrift=$receipt.sourceDrift;oldEvidence="presentation-frame-mcp-reverse63-$boundary.json";cases=$observed} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$taskTemp/action-payload-reverse-$boundary.json" -Encoding utf8
    [pscustomobject]@{boundary=$boundary;matched=$observed.Count;passed=$observed.Count-$failed.Count;failed=$failed.Count;caseDrift=0} | ConvertTo-Json
}
