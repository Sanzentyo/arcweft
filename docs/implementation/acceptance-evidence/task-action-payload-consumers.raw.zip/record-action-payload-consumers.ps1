$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$normal=Get-Content "$taskTemp/action-payload-reverse-normal1-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$cli=Get-Content "$taskTemp/action-payload-reverse-cli1-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$delta=Get-Content "$taskTemp/action-payload-reverse-cli-delta.json" -Raw|ConvertFrom-Json -Depth 40
$generic=Get-Content "$taskTemp/action-payload-reverse-genericMatch.json" -Raw|ConvertFrom-Json
$view=Get-Content "$taskTemp/action-payload-reverse-view40.json" -Raw|ConvertFrom-Json
$graph=Get-Content "$taskTemp/action-payload-nominal.reverse-graph.json" -Raw|ConvertFrom-Json
if(-not $normal.isPassingRun -or $normal.matchedPackages -ne 22 -or $cli.matchedPackages -ne 1 -or $delta.newlyFailingIds.Count){throw 'New or incomplete consumer failures require repair before reconciliation'}
if($generic.passed -ne 151 -or $generic.failed -or $view.passed -ne 40 -or $view.failed){throw 'Accepted boundary comparison differs'}
$n=Get-Content "$taskTemp/action-payload-reverse-normal1-20261102.source-freeze.json" -Raw|ConvertFrom-Json
$c=Get-Content "$taskTemp/action-payload-reverse-cli1-20261102.source-freeze.json" -Raw|ConvertFrom-Json
$inputs=@{};foreach($row in $n.paths){$inputs[$row.path]=$row.sha256}
if($n.paths.Count -ne $c.paths.Count){throw 'Consumer input counts differ'}
foreach($row in $c.paths){if($inputs[$row.path] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Consumer source drift: $($row.path)"}}
$expected=@($graph.reversePackages|Where-Object {$_ -ne 'arcweft-cli'})
$inventory=Get-Content "$taskTemp/action-payload-reverse-normal1-20261102.catalog.inventory.json" -Raw|ConvertFrom-Json
$actual=@($inventory.rows|Where-Object status -eq 'matches'|ForEach-Object package|Sort-Object -Unique)
if(@(Compare-Object $expected $actual).Count){throw 'Complete reverse closure was not covered'}
$receipt=Get-Content "$taskTemp/action-payload-reverse-cli1-20261102.runtime.json" -Raw|ConvertFrom-Json
$lines=[IO.File]::ReadAllLines($receipt.log)
$panics=@(for($i=0;$i -lt $lines.Length;$i++){if($lines[$i] -match "thread '.+' .*panicked at"){
    [ordered]@{line=$i+1;excerpt=@($lines[$i..([Math]::Min($i+8,$lines.Length-1))]|ForEach-Object {if($_.Length -gt 600){$_.Substring(0,600)+' [line truncated]'}else{$_}})}
}})
$source='58c5b7d64febafaa8c1dab4e4546b901b5c52f58'
$stem='task-action-payload-consumers';$zipPath="docs/implementation/acceptance-evidence/$stem.raw.zip";$recordPath="docs/implementation/acceptance-evidence/$stem.json"
if((Test-Path $zipPath) -or (Test-Path $recordPath)){throw 'Existing consumer evidence'}
$files=@(Get-ChildItem $taskTemp -File|Where-Object {$_.Name -like 'action-payload-reverse-*' -or ($_.Name -like 'checkpoint-action-payload-nominal-owner-evidence.*' -and $_.Extension -ne '.patch')})
$files+=@(Get-Item "$taskTemp/action-payload-nominal.reverse-graph.json","$taskTemp/action-declaration-reverse-cli1-20261102.runtime.terminal-audit.json","$taskTemp/audit-action-payload-accepted-boundaries.ps1","$taskTemp/audit-action-payload-cli-delta.ps1","$taskTemp/run-action-payload-reverse.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/audit-nextest-final-result.ps1","$taskTemp/record-action-payload-consumers.ps1")
$manifest=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in ($files|Sort-Object FullName -Unique)){
    $name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/')
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$name,[IO.Compression.CompressionLevel]::Optimal)
    $manifest+=[ordered]@{entry=$name;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try{foreach($row in $manifest){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Consumer archive entry drift'}}}finally{$zip.Dispose()}
$record=[ordered]@{version=1;source=$source;base=$normal.base;recordedAt=[DateTime]::UtcNow.ToString('o');normal=$normal;cli=$cli;cliDelta=$delta;genericMatch=$generic;view40=$view;graph=$graph;sourceInputs=$c.paths.Count;sourceDrift=0;normalCliInputDrift=0;currentPanicExcerpts=$panics;causeCaution='Current complete stderr is preserved. Equal failure IDs are not a claim of equal causes.';ownerEvidence='task-action-payload-owner.json';originalTrackedWip=12;scope='All 23 transitive consumer packages in two explicit all-target/all-feature/locked contexts. This is not whole-goal, full63 or Native/Web image parity acceptance.';rawArchive=[ordered]@{path=$zipPath;sha256=(Get-FileHash $zipPath).Hash.ToLowerInvariant();entries=$manifest;entryDrift=0}}
$baseline=Get-Content "$taskTemp/checkpoint-task-view.source-freeze.json" -Raw|ConvertFrom-Json
$record['inputProvenance']=[ordered]@{publishedOwnerSource=$source;existingTrackedWipIncluded=$c.held;existingTrackedWipPatchSha256=$baseline.heldPatchSha256;meaning='The tested working-tree snapshot includes these preserved existing edits; the owner source SHA alone is not the complete CLI fixture/test snapshot.'}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($recordPath),($record|ConvertTo-Json -Depth 45)+"`n",[Text.UTF8Encoding]::new($false))
$ownerPath=[IO.Path]::GetFullPath('docs/implementation/acceptance-evidence/task-action-payload-owner.json')
$owner=Get-Content $ownerPath -Raw|ConvertFrom-Json -Depth 50
$owner.historicalCorrections[1]='Test API compile errors and the malformed-pattern fixture failure are retained; syntax correctly rejected malformed Action parameters before HIR linking.'
$owner|Add-Member -NotePropertyName wordingCorrection -NotePropertyValue 'Removed the ambiguous numeric count of compile-error runs: the retained repro1 type-path error, owner2 unavailable method and owner4 private-field access are all preserved. No execution result, SHA, or raw archive changed.'
[IO.File]::WriteAllText($ownerPath,($owner|ConvertTo-Json -Depth 50)+"`n",[Text.UTF8Encoding]::new($false))
$statusPath=[IO.Path]::GetFullPath('docs/implementation/current-status.md');$status=[IO.File]::ReadAllText($statusPath)
$genericRow=@($status.Split("`n")|Where-Object {$_.StartsWith('| Generic Match')})
function Replace-Row([string]$Prefix,[string]$Replacement){$rows=$script:status.Split("`n");$count=0;for($i=0;$i -lt $rows.Count;$i++){if($rows[$i].StartsWith($Prefix)){$suffix=if($rows[$i].EndsWith("`r")){"`r"}else{''};$rows[$i]=$Replacement+$suffix;$count++}};if($count -ne 1){throw "Expected one current row: $Prefix"};$script:status=$rows -join "`n"}
Replace-Row '確認日:' "確認日: 2026-11-02。最新公開Sourceは$source。Action payload変更の影響23 packageと全CLI targetを実照合し、最新結果は下表へ集約する。既存12 tracked／6 actual untracked WIPを保持している。"
Replace-Row '| 共有契約／推移的逆依存matrix |' "| 共有契約／推移的逆依存matrix | **payload Sourceの影響23 packageを実照合。通常22は$($normal.passed)／$($normal.executed) PASS** | base $($normal.base)・$($normal.sourceInputs)入力、all-target／all-feature／lockedで通常$($normal.passed) PASS（6 slow）／$($normal.skipped) ignored。選択・実行22 package、Source／case／test EXE差分0。Generic Match151／View値40 exact IDは全件PASS。残るCLIは次行へ集約する。前Sourceの結果・full SHAは履歴へ保持し、今回を全63／全goalの再実行とはしない。[現在の照合原本](acceptance-evidence/$stem.json)。 |"
Replace-Row '| CLI全target照合 |' "| CLI全target照合 | **最新$($cli.executed)件を全実行し$($cli.passed) PASS／$($cli.failed) FAIL。新規失敗ID $($delta.newlyFailingIds.Count)** | base $($cli.base)・$($cli.sourceInputs)入力、all-target／all-feature／locked。Source／case／test EXE差分0。直前の全693件実行との失敗ID差分は、維持$($delta.retainedFailureIds.Count)／追加$($delta.newlyFailingIds.Count)／解消$($delta.resolvedFailureIds.Count)。原因の同一性はIDから推定せず今回の完全stderrを保持する。[全件・差分・現在の診断](acceptance-evidence/$stem.json)。 |"
if(@(Compare-Object $genericRow @($status.Split("`n")|Where-Object {$_.StartsWith('| Generic Match')})).Count){throw 'Accepted Generic row changed'}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$historyPath=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md');$before=[IO.File]::ReadAllBytes($historyPath)
$text="`n`n## Action payloadの全23 consumer照合 — 2026-11-02`n`nSource $source、base $($normal.base)、$($normal.sourceInputs)入力で通常22 packageの$($normal.executed)件を全実行し、$($normal.passed) PASS／$($normal.failed) FAIL（6 slow、8 ignored）。Generic Match151／View値40は同じexact IDで全件PASS。CLIは$($cli.executed)実行／$($cli.passed) PASS／$($cli.failed) FAIL／$($cli.skipped) ignored。直前の全693件実行から維持$($delta.retainedFailureIds.Count)／追加$($delta.newlyFailingIds.Count)／解消$($delta.resolvedFailureIds.Count)であり、同じIDから原因の同一性は推定しない。両contextのSource／case／EXE差分0、normal／CLI間の入力差分0、全23 packageの欠落0を確認した。[全raw・SHA・graph・現在診断](acceptance-evidence/$stem.json)。`n`n訂正理由: payload owner公開時のconsumer未実行は、今回の全件実測によって現状一覧から置き換えた。旧件数・初回失敗・full SHA・raw archiveは履歴へ保持し、Generic Matchの受入行は変更していない。owner記録のcompile-error件数表現も数を限定しない表記へ訂正した。repro1の型path、owner2の非存在method、owner4のprivate fieldアクセスの各失敗はrawに残し、実結果・SHAは変更していない。`n"
$stream=[IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write);try{$stream.Write([Text.Encoding]::UTF8.GetBytes($text))}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($historyPath);$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
[ordered]@{normal=$normal.passed;cliExecuted=$cli.executed;cliPassed=$cli.passed;cliFailed=$cli.failed;newFailureIds=$delta.newlyFailingIds.Count;archiveEntries=$manifest.Count;archiveBytes=(Get-Item $zipPath).Length;sourceDrift=0;historicalPrefixDrift=0;genericRowDrift=0}|ConvertTo-Json
