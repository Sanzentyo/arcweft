$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prior=Get-Content "$taskTemp/action-declaration-reverse-cli1-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$current=Get-Content "$taskTemp/action-payload-reverse-cli1-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($prior.executed -ne 693 -or $prior.failed -ne 33){throw 'Prior actual CLI baseline differs'}
$oldKeys=@($prior.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$newKeys=@($current.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$result=[ordered]@{
    version=1;productionSource='58c5b7d64febafaa8c1dab4e4546b901b5c52f58';current=$current
    comparisonSource='a2688f77338bd0b34a7651d4910312045a59d6bf'
    comparisonMeaning='Direct comparison with the prior complete 693-case CLI run (660 passed, 33 failed), preserving its actual source base and frozen inputs.'
    prior=$prior
    retainedFailureIds=@($current.failureSet|Where-Object {($_.binary+"`t"+$_.test) -in $oldKeys})
    newlyFailingIds=@($current.failureSet|Where-Object {($_.binary+"`t"+$_.test) -notin $oldKeys})
    resolvedFailureIds=@($prior.failureSet|Where-Object {($_.binary+"`t"+$_.test) -notin $newKeys})
    causeCaution='Matching case IDs do not prove matching causes; the current complete runtime log remains authoritative.'
}
$result|ConvertTo-Json -Depth 30|Set-Content "$taskTemp/action-payload-reverse-cli-delta.json" -Encoding utf8
[ordered]@{executed=$current.executed;passed=$current.passed;failed=$current.failed;retained=$result.retainedFailureIds.Count;added=$result.newlyFailingIds.Count;resolved=$result.resolvedFailureIds.Count;sourceDrift=$current.sourceDrift;caseDrift=$current.catalogCaseDrift}|ConvertTo-Json
