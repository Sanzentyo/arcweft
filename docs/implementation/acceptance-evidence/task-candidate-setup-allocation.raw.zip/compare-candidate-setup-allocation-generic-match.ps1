$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$prefix='candidate-setup-allocation.dev01'
$auditPath='docs/implementation/acceptance-evidence/accepted-generic-c3-c5-closure-audit.json'
$successorPath='docs/implementation/acceptance-evidence/task-expression-value-scope.json'
$sourceLog=Join-Path $d "$prefix-reverse.log"
$accepted=Get-Content -LiteralPath $auditPath -Raw | ConvertFrom-Json -AsHashtable
$successor=Get-Content -LiteralPath $successorPath -Raw
$logInput=Get-Content -LiteralPath (Join-Path $d "$prefix-reverse.result.json") -Raw | ConvertFrom-Json -AsHashtable
$pattern='"original"\s*:\s*"([^"]+)",\s*"current"\s*:\s*"([^"]+)"'
$mapping=@([regex]::Matches($successor,$pattern) | Where-Object {$_.Groups[1].Value -match 'style_length_values_use_registered_roots_and_shared_scalar_reduction'})
if($mapping.Count -ne 1){throw 'Expected one maintained fixture successor.'}
$statuses=@{}
foreach($line in (Get-Content -LiteralPath $sourceLog)){
    if($line -match '^\s+(PASS|FAIL|SKIP)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(.+?)\s*$'){
        $statuses[$Matches[2]+' '+$Matches[3]]=$Matches[1]
    }
}
$groups=[ordered]@{}
$replacements=0
foreach($group in $accepted.groups.Keys){
    $entries=@(foreach($item in $accepted.groups[$group]){
        $original=$item.binary+' '+$item.name
        $id=$original
        if($id -eq $mapping[0].Groups[1].Value){$id=$mapping[0].Groups[2].Value; $replacements++}
        [ordered]@{original=$original;id=$id;status=$statuses[$id]}
    })
    $groups[$group]=[ordered]@{passed=@($entries | Where-Object {$_.status -eq 'PASS'}).Count;total=$entries.Count;items=$entries}
}
$total=@($groups.Values | ForEach-Object {$_.items})
if($total.Count -ne 151 -or $replacements -ne 1 -or @($total | Where-Object {$_.status -ne 'PASS'}).Count){throw 'Accepted Generic Match IDs are absent or regress.'}
[ordered]@{
    version=1;base=$logInput.base;blobs=$logInput.blobs;accepted_audit=$auditPath;fixture_successor=$successorPath;
    log_sha256=(Get-FileHash -LiteralPath $sourceLog).Hash.ToLowerInvariant();count=$total.Count;groups=$groups
} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $d "$prefix-accepted-generic-match.json") -Encoding utf8NoBOM
$groups.GetEnumerator() | ForEach-Object { '{0}: {1}/{2}' -f $_.Key,$_.Value.passed,$_.Value.total }
