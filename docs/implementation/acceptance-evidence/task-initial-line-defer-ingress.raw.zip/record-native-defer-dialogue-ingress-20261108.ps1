$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='line-init-dialogue-20261108'
$source=(Get-Content "$taskTemp/$stem.native-source.verified.json" -Raw|ConvertFrom-Json).commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Unexpected published source'}
foreach($gate in @('check','clippy','structure','fmt')){
 $receipt=Get-Content "$taskTemp/$stem.workspace-quality-r1.$gate.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw "Gate unavailable: $gate"}
}
$terminal=Get-Content "$taskTemp/$stem.bounded-native-owners.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($terminal.executed -ne 163 -or $terminal.passed -ne 161 -or $terminal.failed -ne 2 -or $terminal.sourceDrift -ne 0){throw 'Final owner result differs'}
$unit=Get-Content "$taskTemp/$stem.bounded-inbox-auth.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$consumers=Get-Content "$taskTemp/$stem.input-consumers.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($unit.passed -ne 1 -or $unit.failed -ne 0 -or $consumers.passed -ne 6 -or $consumers.failed -ne 0){throw 'Core input acceptance unavailable'}
$epoch=(Get-Content "$taskTemp/$stem.bounded-native-owners.source-freeze.json" -Raw|ConvertFrom-Json).paths
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$unitPins=@(Get-Content "$taskTemp/$stem.bounded-inbox-auth.binaries-before.json" -Raw|ConvertFrom-Json)
$consumerPins=@(Get-Content "$taskTemp/$stem.input-consumers.binaries-before.json" -Raw|ConvertFrom-Json)
if($unitPins.Count -ne 1 -or $consumerPins.Count -ne 1 -or $unitPins[0].path -cne $consumerPins[0].path -or $unitPins[0].sha256 -cne $consumerPins[0].sha256){throw 'Complementary Core binary differs'}
$untracked=(Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json).files
foreach($row in $untracked){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked drift'}}
. "$taskTemp/convergence-image-git-bytes.ps1"
$metrics=Import-Csv "$taskTemp/$stem.structure-report/file_metrics.csv"
$rows=@(foreach($path in (Get-Content "$taskTemp/$stem.native-source.owned.txt")){
 $metric=@($metrics|Where-Object path -eq $path)
 if($metric.Count -ne 1){throw "Missing metrics: $path"}
 $old=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('7b395a0fa0def969265b5875a6e1114626901d35:'+$path))))
 $oldLines=($old -split "`n").Count-[int]$old.EndsWith("`n")
 [ordered]@{path=$path;owner=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLines=[int]$metric[0].physical_lines;embeddedTestLines=[int]$metric[0].embedded_test_lines;growth=[int]$metric[0].physical_lines-$oldLines}
})
[ordered]@{version=1;source=$source;files=$rows;cargoChanges=0;graph='Unchanged Cargo graph from the earlier root-defer metadata: workspace 98 / resolved 846 / Core reverse 53. The workspace compile gates are fresh; this cut has no new full Core53 runtime matrix.';ownership='The shared LineTaskLiveState owns bounded, ordered input-identity admission and its consumed set. Its prepared event packet borrows existing identities, checks capacity before retaining/cloning, and avoids cloning consumed history. Native DialogueStepInbox owns pending identities for the exact activation until polling consumes them. Public Save was not added to Native; its existing private rollback/live retained admission authenticates queued activation, phase and duplicate/consumed identities. Core contains no new I/O, runtime-value copy, persistent side table, fallback resolver, legacy reader or version bump.';cohesion='Existing line reducer, Native ingress transaction and scheduler responsibilities stay with their owners. Test helpers select the actual reveal to cancel while keeping 1-op/512-step, host acquire/release and ordered logs. Large-file byte/LOC/embedded-test growth is retained above; no API expansion or file split was introduced solely to reduce file size.'}|ConvertTo-Json -Depth 12|Set-Content "$taskTemp/$stem.ownership-review.json"
$archive='docs/implementation/acceptance-evidence/task-initial-line-defer-ingress.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name.StartsWith($stem+'.') -or $_.Name -in @('record-native-defer-dialogue-ingress-20261108.ps1','run-line-init-dialogue-workspace-quality-20261108.ps1','run-line-root-frozen-nextest-20261108.ps1','native-dialogue-input-inbox-test.rs.fragment')}|Sort-Object Name)
$items=@(foreach($file in $files){[ordered]@{path=$file.FullName;entry=$file.Name}})+@(Get-ChildItem "$taskTemp/$stem.structure-report" -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.FullName;entry=('structure-report/'+$_.Name)}})
$entries=@(foreach($item in $items){[ordered]@{entry=$item.entry;bytes=(Get-Item -LiteralPath $item.path).Length;sha256=(Get-FileHash -LiteralPath $item.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($item in $items){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$item.path,$item.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Archive shape differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive content differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$source;priorSource='53488624ba4d39e54a213eca28b3c84661d94761';probeBase='7b395a0fa0def969265b5875a6e1114626901d35'
 accepted='Native initial-input init defer retains a received Actor packet while its child dialogue waits, then completes both normal and explicitly targeted inner-dialogue cancellation paths. One test executes both paths with the original 1-op/512-step, three unique reveals, one acquire/release and ordered logs.'
 correction='The earlier waiting test selected cancellation at the last reveal, which is the receiving outer line after init completes. The harness now names the second reveal, the actual inner dialogue, without changing runtime budgets or host assertions. Nested and explicit init scopes have separate test IDs: Native nested defer passes, Native explicit scope result binding remains a concrete failure. Previous combined-test failures and all full SHAs are retained.'
 implementation='Native latches input action identities in the existing activation inbox before selecting root/child work. The exact activation retains them when another owner consumes the step budget. Polling takes the packet once; the shared reducer rejects batch duplicates and consumed identities. Pending inboxes wake their actual receiving fiber. Borrowed admission checks batch/history sequence capacity before retaining identities and avoids consumed-history clones. Live/private inert admission rejects another activation or an invalid phase.'
 validation=[ordered]@{owners=$terminal;coreInbox=$unit;coreConsumers=$consumers;coreBinary=$unitPins[0];scope='The Core 1-case and complementary 6-case runs share their actual executable path/hash. They are bounded owner evidence, not a full Core unit run. Compiler 163-case selection uses its own declared package/feature composition; no combined full-matrix total is claimed.';gates='Fresh all-target/all-feature workspace check/Clippy, canonical structure gate and 7 Rust paths fmt exit 0; warnings retained';sourceInputs=3416;sourceDrift=0}
 remaining='Native explicit init scope result binding and saved AWBC init-defer child dialogue waiting remain the exact two failed cases in the 163-case owner terminal. The saved AWBC waiting test stops in its first normal branch, so its cancellation branch has not executed. Native public Save, all Core53 runtime consumers, other platforms/Tier2 and final parity are not newly accepted by this cut.'
 history='The first six-case topology probe had 3 pass / 3 fail. The diagnostic Native-state probe and inbox-wakeup-only probe each had 0 pass / 1 fail. The input-action retention followup passed its two-path case. The first Core inbox probe passed; bounded/shared admission then passed the same case and six complementary input/schema/ingress cases. Owner suites before and after the bounded refactor each ran 163 with 161 pass / the same two fail. Each source epoch, skip count, actual executable hash and preparation log is kept separately.'
 preserved='Original WIP remains 12 tracked / 6 actual untracked, independently checked; historical focused-wrapper held=14 labels do not describe the current WIP. Generic Match and all prior accepted boundaries remain accepted.'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'initialLineDeferInputIngress'){throw 'Record already exists'}
$fragment=([ordered]@{initialLineDeferInputIngress=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($prop in $old.PSObject.Properties){if(($prop.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($prop.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Historical evidence changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| Line の初期所有入力 |')){
 "| Line の初期所有入力 | **返却Actor／Copy・root deferの既受入を保持。追加init/scoped条件はNative待機・内側取消しまで修復し、2条件を継続中** | root defer Source 5ba67c20a9aacafe3d1dd25939be42c92cddf52a とActor再返却／Copy再利用、初期packet／activation保存監査は受入済み。最新Source $source はNative init-defer子の対話待機と実際の内側対話の取消しを通過。入力identityを対象activationのinboxへ保持し、重複／再送／別activation改変と既存件数上限の原子拒否をCoreの関連7件で確認した。最終Compiler owner選択は163件中161 PASS／2 FAIL。残る具体条件はNativeの明示init scope結果受取りと、保存AWBCのinit-defer子からの対話待機。保存AWBCの待機取消し枝は未実行。旧3失敗・取消し入力先の訂正と全SHAを履歴に残し、既受入境界全体を戻さない。[各run・残条件・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 "| workspace check／Clippy・fmt・構造gate | **Native対話入力保持cutの全workspace gateは終了0** | Source $source の全target／全feature workspace check／Clippy、canonical構造gate、7 Rust path fmtが3416入力drift0で終了0。警告、先行Sourceの全gate／Core unit／Core53 matrixは履歴へ保持し、新Sourceの全件結果へ合成しない。Cargo依存変更0。全14 family・他platform／Tier2・全表示parityの最終受入へ拡張しない。[実測・構造責任・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — Native init-defer子対話の入力保持

Source **$source** は、初期Actorを捕捉したinit-defer子の対話待機と、内側対話を指定した取消しをNativeで通過させた。1 testの通常／取消し2経路が、元の1-op／512-step、3つの一度だけのreveal、取得・解放各1回とlog順を保つ。受入済みSource **53488624ba4d39e54a213eca28b3c84661d94761** の初期scoped入力／filter／保存改変拒否は維持する。

古い待機helperのcancel-lastは、init後にrevealする外側Lineを選んでいた。実際の内側Lineである2番目のrevealを明示する形に訂正し、予算・host assertionを緩めない。nested deferと明示init scopeを別test IDへ分けた6件の初回は3 PASS／3 FAIL。Native保持状態の診断probeとinbox-wakeupだけのprobeは各0 PASS／1 FAILで、入力actionを保持した後に対象1件が通過した。過去の複合testの失敗を、未実行の取消し成功や各枝の個別実測へ読み替えない。

Nativeの既存DialogueStepInboxが実activationのinput identityを保持し、別ownerが先にstep予算を使っても失わない。poll時に一度だけ取り出し、共有LineTaskLiveStateがepoch／sequence／action順序と重複・消費済みidentityを検査する。prepared packetは既存identityを借用し、保持／複製前に既存sequence上限を確認する。消費履歴全体のcloneを削除し、live／private inert admissionでも対象activationとphaseを検査する。Native公開Saveの新設ではない。

最終Coreはinbox原子性1件と相補input／schema／ingress6件が各PASS。同じ実行ファイルpath／SHA256を照合し、全Core unitへ拡張しない。最終Compiler evaluated_effects／scoped_deferは **163件中161 PASS／2 FAIL**。bounded refactor前後の163件は別epochとして残す。残る実失敗はNativeの明示init scope結果受取りと、保存AWBC init-defer子の対話待機。後者の取消し枝は最初の通常枝で停止したため未実行。Nativeの入れ子登録／待機／内側取消しが通過した根拠で現状行を更新し、root deferやGeneric Match等の既受入を戻さない。

workspace全target／全feature check／Clippy、canonical構造gateと7 Rust path fmtは終了0、3416入力drift0。Core53／CLIの新runtime matrixではない。7ファイルのbyte／LOC／embedded tests／増分とownerの責任をrawへ保持し、Cargo依存・I/O・live値のcopy・永続side table・compatibility reader・version bumpを足さない。既存12 tracked／6 actual untrackedは保持した。[全記録・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;historicalRecordsPreserved=$old.PSObject.Properties.Name.Count;archiveEntries=$entries.Count;archiveSha256=$record.raw.sha256;coreCases=7;compilerPassed=$terminal.passed;compilerFailed=$terminal.failed}|ConvertTo-Json -Compress
