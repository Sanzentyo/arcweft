#[path = "D:/git/arcweft/crates/arcweft-compiler/tests/evaluated_effects/lifetime_scopes.rs"]
mod lifetime_scopes;
#[path = "D:/git/arcweft/crates/arcweft-compiler/tests/support/slot_declarations.rs"]
mod slot_declarations;

use std::{collections::BTreeMap, path::PathBuf, sync::Arc};

use arcweft_character::catalog::{CharacterCatalog, CharacterVisualManifestEvidence};
use arcweft_compiler::{
    lower::{RuntimeEmissionMode, project_runtime_reachability, project_runtime_semantic_facts},
    project::{
        AcceptedLaunchProfileInput, CompiledProject, ProjectCompilationContext,
        ProjectCompilationSession, ProjectCompileError, analyze_project, compile_project,
    },
    source::compile_source,
    types::CompiledSource,
};
use arcweft_core::{
    effect::{LineEffectRequest, RuntimeDropPolicyExpr, RuntimeDropPolicyKind, RuntimeEffectExpr},
    line_task::{LineTaskGroup, LineTaskNode, LineTaskTrigger},
    plan::{
        FlowOp, RuntimeDialogueContentEffectTrigger, RuntimeDialogueContentPlan,
        RuntimeDialogueValueBinding, RuntimeDialogueValueRole, RuntimeFunctionSiteBody,
        RuntimePlan,
    },
    runtime_id::{RuntimeDialogueMarkId, RuntimeLineTaskNodeId},
    time::LogicalDuration,
    value::{RuntimeDialogueContentValue, RuntimeExprKind, RuntimeValue},
};
use arcweft_lang_hir::symbol::{CallablePackageId, ProjectSymbolWorldId};
use arcweft_lang_sema::{
    env::TypeCheckEnv, final_analysis::CheckedExpressionResolution,
    registration::ProjectRegistrationFacts,
};
use arcweft_lang_syntax::{
    ast::module_path::CanonicalModulePath,
    incremental::{ParsedSource, SyntaxDatabase},
    parser::ParseOptions,
};
use arcweft_launch::{LaunchProfileSelection, ProfileId, accepted::SourceBackedManifest};
use arcweft_manifest_model::{BuildSpec, PackageId, PackageSpec, PackageVersion};
use arcweft_project::sources::{ProjectSourceFile, ProjectSources};
use arcweft_resource_model::registry::ResourceTypeRegistry;
use arcweft_runtime_plan::awbc_lower::AwbcLowerer;
use arcweft_source::{
    SourceDocument, SourceDocumentId, SourceName, SourceSetRevision, identity::SourceSnapshotId,
};
use arcweft_text_model::{
    DialogueContentMaterializer, RichTextNode, RichTextObjectProxy, RichTextStyle,
    RichTextTextProxyFieldKind, RichTextTextProxyScalar,
};

fn object_proxy(compiled: &CompiledProject) -> &RichTextObjectProxy {
    fn find_object_proxy(nodes: &[RichTextNode]) -> Option<&RichTextObjectProxy> {
        nodes.iter().find_map(|node| match node {
            RichTextNode::Scope { style, body, .. } => match style.as_ref() {
                RichTextStyle::Object { proxy } => Some(proxy),
                _ => find_object_proxy(body),
            },
            RichTextNode::Ruby { body, .. } => find_object_proxy(body),
            _ => None,
        })
    }

    let [template] = compiled.runtime_plan().dialogue_content_catalog.templates() else {
        panic!("one dialogue content template")
    };
    find_object_proxy(&template.content().nodes).expect("compiler emits one object style")
}

#[test]
fn reference_only_dialogue_id_argument_survives_runtime_reachability() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice(id = @say.shared, source_locale = "ja-JP")[Hello。[p]]
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("checked dialogue ID metadata remains valid through runtime reachability");

    let [flow] = compiled.runtime_plan().plan.flows() else {
        panic!("one executable Flow")
    };
    assert!(
        flow.body()
            .ops()
            .iter()
            .any(|operation| matches!(operation, FlowOp::Dialogue { .. }))
    );
}

#[test]
fn ruby_content_with_a_recovered_closure_candidate_reaches_verified_awbc() {
    for ruby in ["|[夢](ゆめ)", "｜夢《ゆめ》"] {
        let source = format!(
            "pub character alice {{ display = \"Alice\" }}\nflow main() -> Unit {{ alice()[{ruby}] }}\nentry cli @entry.main {{ goto @flow.main }}\n",
        );
        let compiled = compile_attached_dialogue_project(&source).expect(
            "the clean Dialogue interpretation compiles independently of recovered Index syntax",
        );
        let runtime_plan = compiled.runtime_plan();
        let [template] = runtime_plan.dialogue_content_catalog.templates() else {
            panic!("fixture publishes one dialogue template");
        };
        assert_eq!(
            template.content().nodes,
            vec![RichTextNode::Ruby {
                body: vec![RichTextNode::Text { text: "夢".into() }],
                ruby: "ゆめ".into(),
            }]
        );
        assert_candidate_program_executes_in_native_and_awbc(&compiled);
    }
}

#[test]
fn raw_content_uses_the_checked_literal_without_interpreting_braces_or_page_marks() {
    let source = "pub character alice { display = \"Alice\" }\nflow main() -> Unit { alice()[#raw()[literal { braces } [p]]] }\nentry cli @entry.main { goto @flow.main }\n";
    let compiled = compile_attached_dialogue_project(source)
        .expect("raw Content compiles from the accepted literal argument");
    let [template] = compiled.runtime_plan().dialogue_content_catalog.templates() else {
        panic!("fixture publishes one dialogue template");
    };
    assert_eq!(
        template.content().nodes,
        vec![RichTextNode::Raw {
            text: "literal { braces } [p]".into(),
        }]
    );
    assert_candidate_program_executes_in_native_and_awbc(&compiled);
}

fn assert_single_dialogue_execution(
    mut step: impl FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
    template: arcweft_core::runtime_id::RuntimeDialogueContentTemplateId,
) -> arcweft_core::value::RuntimeOpaqueValue {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        plan::FlowEvent,
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };
    let mut advances = Vec::new();
    let mut seen = 0;
    let mut selected_target = None;
    for tick in 0..256 {
        let result = step(
            RuntimeStepInput {
                tick: TickId(tick),
                dialogue_advances: std::mem::take(&mut advances),
                ..RuntimeStepInput::default()
            },
            RuntimeStepOptions::default(),
        );
        let arcweft_core::step::RuntimeStepResult {
            output,
            fiber_status: status,
            ..
        } = result;
        assert!(output.diagnostics.is_empty(), "{:?}", output.diagnostics);
        for event in output.flow_events {
            if let FlowEvent::DialogueLine {
                activation,
                template: actual,
                target,
                values,
                ..
            } = event
            {
                assert_eq!(actual, template);
                assert!(
                    values.is_empty(),
                    "the fixture retains all static content in its selected template"
                );
                seen += 1;
                assert!(selected_target.replace(target).is_none());
                advances.push(activation);
            }
        }
        match &status {
            FlowFiberStatus::Running => {}
            FlowFiberStatus::Dialogue(dialogue) => {
                if let Some(activation) = dialogue.waiting_presentation_activation() {
                    assert_eq!(seen, 1, "presentation wait follows its reveal event");
                    assert_eq!(activation, dialogue.activation());
                } else if seen == 0 {
                    assert_eq!(
                        dialogue.phase(),
                        arcweft_core::engine::DialogueRuntimePhase::Activating,
                        "pre-reveal suspension retains execution without a presentation wait"
                    );
                }
            }
            FlowFiberStatus::Done(exit) => {
                assert_eq!(*exit, FlowExit::Done);
                assert_eq!(seen, 1, "the selected line executes once");
                return selected_target.expect("dialogue line retains its exact target");
            }
            status => panic!("execution stopped unexpectedly: {status:?}"),
        }
    }
    panic!("execution exceeded its deterministic step bound");
}

fn execute_single_dialogue_with_content(
    mut step: impl FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
    expected_template: arcweft_core::runtime_id::RuntimeDialogueContentTemplateId,
) -> (
    arcweft_core::value::RuntimeOpaqueValue,
    Box<[RuntimeDialogueValueBinding]>,
    Vec<LineEffectRequest>,
) {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        plan::FlowEvent,
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };

    let mut advances = Vec::new();
    let mut selected_target = None;
    let mut selected_values = None;
    let mut line_effects = Vec::new();
    let mut seen = 0;
    for tick in 0..256 {
        let result = step(
            RuntimeStepInput {
                tick: TickId(tick),
                dialogue_advances: std::mem::take(&mut advances),
                ..RuntimeStepInput::default()
            },
            RuntimeStepOptions::default(),
        );
        let arcweft_core::step::RuntimeStepResult {
            output,
            fiber_status: status,
            ..
        } = result;
        assert!(output.diagnostics.is_empty(), "{:?}", output.diagnostics);
        line_effects.extend(output.effects.line);
        for event in output.flow_events {
            if let FlowEvent::DialogueLine {
                activation,
                template,
                target,
                values,
                ..
            } = event
            {
                assert_eq!(template, expected_template);
                assert!(selected_target.replace(target).is_none());
                assert!(selected_values.replace(values).is_none());
                seen += 1;
                advances.push(activation);
            }
        }
        match &status {
            FlowFiberStatus::Running | FlowFiberStatus::Dialogue(_) => {}
            FlowFiberStatus::Done(exit) => {
                assert_eq!(*exit, FlowExit::Done);
                assert_eq!(seen, 1, "the selected line executes once");
                return (
                    selected_target.expect("dialogue line retains its exact target"),
                    selected_values.expect("dialogue line retains its evaluated content slots"),
                    line_effects,
                );
            }
            status => panic!("execution stopped unexpectedly: {status:?}"),
        }
    }
    panic!("execution exceeded its deterministic step bound");
}

fn rendered_content_slot_texts(
    catalog: &arcweft_text_model::DialogueContentCatalog,
    artifact: arcweft_core::effect::RuntimeArtifactFingerprint,
    values: &[RuntimeDialogueValueBinding],
) -> Vec<String> {
    let fragment_catalog = catalog
        .fragment_catalog(artifact)
        .expect("compiled dialogue templates form a fragment catalog for this artifact");
    let materializer = DialogueContentMaterializer::new(&fragment_catalog);
    values
        .iter()
        .map(|binding| {
            assert_eq!(binding.role, RuntimeDialogueValueRole::Content);
            assert!(matches!(&binding.value, RuntimeValue::Opaque(_)));
            let content = RuntimeDialogueContentValue::try_from_runtime_value(&binding.value)
                .expect("dialogue Content slot retains its exact Content envelope");
            materializer
                .materialize(&content)
                .expect("dialogue Content value materializes through its template catalog")
                .document()
                .resolved_text()
                .to_owned()
        })
        .collect()
}

fn log_messages(effects: &[LineEffectRequest]) -> Vec<String> {
    effects
        .iter()
        .filter_map(|effect| match effect {
            LineEffectRequest::Log(log) => Some(log.message.clone()),
            _ => None,
        })
        .collect()
}

fn assert_simple_flow_logs_native_and_awbc(compiled: &CompiledSource, expected: &[&str]) {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };

    let report = AwbcLowerer::new(
        &compiled.plan,
        &compiled.dialogue_content,
        "value_effect_execution.arcw",
    )
    .lower()
    .expect("effect plan lowers to verified AWBC");
    let bytes = report
        .program
        .encode_canonical()
        .expect("encode effect AWBC");
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .expect("decode effect AWBC");
    let [flow] = compiled.plan.flows() else {
        panic!("one executable flow")
    };
    let mut native = arcweft_core::engine::Engine::for_flow(compiled.plan.clone(), &flow.id)
        .expect("native flow starts");
    let mut awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
        decoded,
        arcweft_core::awbc::schema::AwbcEntryId(0),
    )
    .expect("decoded AWBC flow starts");
    let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default();
    let run = |step: &mut dyn FnMut(
        RuntimeStepInput,
        RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult| {
        let mut effects = Vec::new();
        for tick in 0..32 {
            let result = step(
                RuntimeStepInput {
                    tick: TickId(tick),
                    ..RuntimeStepInput::default()
                },
                RuntimeStepOptions::default(),
            );
            assert!(
                result.output.diagnostics.is_empty(),
                "{:?}",
                result.output.diagnostics
            );
            effects.extend(result.output.effects.line);
            match result.fiber_status {
                FlowFiberStatus::Running => {}
                FlowFiberStatus::Done(FlowExit::Done) => return log_messages(&effects),
                status => panic!("effect flow stopped unexpectedly: {status:?}"),
            }
        }
        panic!("effect flow exceeded its deterministic step limit")
    };
    let native_logs = run(&mut |input, options| native.step(input, options));
    let awbc_logs =
        run(&mut |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend));
    eprintln!("native={native_logs:?}, decoded_awbc={awbc_logs:?}");
    assert_eq!(native_logs, expected);
    assert_eq!(awbc_logs, native_logs);
}

fn bind_test_character_dialogue_schema(
    compiled: &CompiledProject,
    owner: arcweft_core::task::RuntimeProgramOwner,
) -> arcweft_dialogue::CharacterDialogueRuntimeSchema {
    let generation = compiled
        .runtime_plan()
        .character_dialogue_generation
        .as_ref()
        .expect("the dialogue fixture publishes a CharacterDialogue generation");
    let environment = compiled.analysis_lease().registered_environment();
    let characters =
        CharacterCatalog::try_from_declarations(generation.characters().keys().map(|character| {
            let visual = environment.character_manifest(character).cloned().map_or(
                CharacterVisualManifestEvidence::Absent,
                CharacterVisualManifestEvidence::Present,
            );
            (character.clone(), visual)
        }))
        .expect("the accepted Character inventory and visual evidence form a catalog");

    let product = compiled.dialogue_profile().product();
    let program = product
        .program()
        .expect("the accepted dialogue profile retains its View program");
    let mut views = arcweft_view::ViewRegistry::default();
    program
        .register_runtime_views(&mut views)
        .expect("the accepted dialogue View registry");
    let style_digest = product.style().map(|style| {
        style
            .resource()
            .canonical_digest()
            .map(|digest| arcweft_core::entry::RuntimeValueDigest::from_bytes(digest.as_bytes()))
            .expect("the accepted dialogue Style fingerprint")
    });

    generation
        .bind_runtime(Arc::new(views), Arc::new(characters), style_digest, owner)
        .expect("the schema binds to this exact executable generation")
}

fn assert_candidate_program_executes_in_native_and_awbc(compiled: &CompiledProject) {
    let runtime = compiled.runtime_plan();
    let [template] = runtime.dialogue_content_catalog.templates() else {
        panic!("one selected template")
    };
    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "candidate_execution.arcw",
    )
    .lower()
    .expect("verified AWBC");
    let bytes = report.program.encode_canonical().unwrap();
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .unwrap();
    assert_eq!(decoded, report.program);
    let [flow] = runtime.plan.flows() else {
        panic!("one flow")
    };
    let mut plan = runtime.plan.clone();
    plan.bind_artifact(
        arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
            *blake3::hash(&bytes).as_bytes(),
        )
        .unwrap(),
    )
    .unwrap();
    let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
    let native_schema = bind_test_character_dialogue_schema(
        compiled,
        arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
        .with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
        );
    let native_target = assert_single_dialogue_execution(
        |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
        template.id(),
    );
    let mut awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
        decoded,
        arcweft_core::awbc::schema::AwbcEntryId(0),
    )
    .unwrap();
    let awbc_schema = bind_test_character_dialogue_schema(compiled, awbc.program_owner());
    let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
        .with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
        );
    let awbc_target = assert_single_dialogue_execution(
        |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend),
        template.id(),
    );
    assert_eq!(native_target, awbc_target);
    let character = arcweft_character::id::CharacterId::try_new("character.alice").unwrap();
    assert_eq!(
        native_target.semantic_identity(),
        arcweft_dialogue::CharacterDialogueType::exact(character).runtime_semantic_identity()
    );
}

#[test]
fn candidate_generated_content_types_follow_their_selected_producer() {
    for scope in ["", "scope nested "] {
        let source = format!(
            "#[text_proxy(role = \"keyword\", hit_test = true, channel = \"fallback\")]\npub struct KeywordHit {{ channel: String, weight: Option<i64> }}\npub character alice {{ display = \"Alice\" }}\nflow main() -> Unit {{ let values = [1i64]; let observed = values[{scope}{{ alice()[Before #object(id=@.hotspot, type=KeywordHit, weight=3)[typed]]; 0i64 }}]; assert.check(observed == 1i64); }}\nentry cli @entry.main {{ goto @flow.main }}\n"
        );
        let selected = compile_attached_dialogue_project(&source)
            .expect("a selected Index may contain a typed Content call and named scope");
        let (selector, choice) = selected
            .analysis_lease()
            .final_analysis()
            .expressions()
            .find_map(|(owner, expression)| match expression.resolution() {
                CheckedExpressionResolution::PostfixBracket(choice) => Some((owner, choice)),
                _ => None,
            })
            .expect("retained Index/Dialogue alternatives");
        let module = selected
            .analysis_lease()
            .hir_project()
            .view()
            .modules()
            .find_map(|(_, module)| (module.module_id() == selector.module()).then_some(module))
            .unwrap();
        let chosen = module
            .candidate_provenance()
            .region(choice.candidate())
            .unwrap();
        assert_eq!(
            chosen.interpretation(),
            arcweft_lang_hir::source_index::HirPostfixInterpretation::Index
        );
        let rejected = module
            .candidate_provenance()
            .regions()
            .find(|region| region.selector() == selector && region.root() != choice.candidate())
            .unwrap();
        assert_eq!(
            rejected.recovery_status(),
            arcweft_lang_syntax::incremental::ParseStatus::Recovered
        );
        assert_eq!(
            object_proxy(&selected).type_name.as_deref(),
            Some("KeywordHit")
        );
        assert_candidate_program_executes_in_native_and_awbc(&selected);
    }
}

#[test]
fn candidate_local_type_failure_does_not_publish_an_unselected_type() {
    let compiled = compile_attached_dialogue_project(
        "pub character alice { display = \"Alice\" }\nflow main() -> Unit { alice()[|value: MissingType| value] }\nentry cli @entry.main { goto @flow.main }\n",
    ).expect("the valid Dialogue interpretation rejects the Index annotation in its probe");
    let mut retained_types = 0;
    for (_, module) in compiled.analysis_lease().hir_project().view().modules() {
        for (owner, _) in module.types() {
            if module
                .candidate_provenance()
                .contains(arcweft_lang_hir::identity::SyntheticOwner::Type(owner))
            {
                retained_types += 1;
                assert!(
                    compiled
                        .analysis_lease()
                        .final_analysis()
                        .ty(owner)
                        .is_none()
                );
                assert!(
                    compiled
                        .analysis_lease()
                        .final_analysis()
                        .type_resolution(owner)
                        .is_none()
                );
            }
        }
    }
    assert_eq!(
        retained_types, 1,
        "source tooling retains the rejected annotation"
    );
}

#[test]
fn candidate_control_target_failure_stays_in_the_rejected_interpretation() {
    for transfer in ["break", "continue", "out 1"] {
        let source = format!(
            "pub character alice {{ display = \"Alice\" }}\nflow main() -> Unit {{ alice()[|| {{ {transfer}; 0 }}] }}\nentry cli @entry.main {{ goto @flow.main }}\n",
        );
        let compiled = compile_attached_dialogue_project(&source)
            .expect("the valid Dialogue interpretation rejects an Index-local control target");
        let mut rejected = 0;
        for (_, module) in compiled.analysis_lease().hir_project().view().modules() {
            for (owner, statement) in module.statements() {
                if arcweft_lang_hir::project::HirControlTransferKind::from_statement(
                    statement.kind(),
                )
                .is_some()
                {
                    rejected += 1;
                    assert!(
                        module
                            .candidate_provenance()
                            .contains(arcweft_lang_hir::identity::SyntheticOwner::Stmt(owner))
                    );
                    assert!(
                        compiled
                            .analysis_lease()
                            .final_analysis()
                            .statement(owner)
                            .is_none()
                    );
                }
            }
        }
        assert_eq!(rejected, 1);
    }
}

#[test]
fn candidate_only_local_use_does_not_become_an_executable_capture() {
    let compiled = compile_attached_dialogue_project(
        "pub character alice { display = \"Alice\" }\nflow main() -> Unit { let unused = 1; let speak = || { alice()[unused]; () }; speak(); }\nentry cli @entry.main { goto @flow.main }\n",
    ).expect("the closure's Dialogue body compiles");
    let closures = compiled
        .analysis_lease()
        .final_analysis()
        .expressions()
        .filter_map(|(_, expression)| match expression.resolution() {
            CheckedExpressionResolution::Closure(closure) => Some(closure),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(closures.len(), 1);
    assert!(
        closures[0].captures().is_empty(),
        "a reference in the rejected Index interpretation is not a runtime capture"
    );
    assert_eq!(
        compiled.analysis_lease().final_analysis().captures().len(),
        0
    );
}

#[test]
fn candidate_selection_recomputes_capture_order_and_access() {
    use arcweft_lang_hir::scope::CaptureAccess;
    for (body, expected, expected_value) in [
        (
            "alice()[first]; second * 10 + first",
            vec!["second", "first"],
            21,
        ),
        ("alice()[|| { first = 99; first }]; first", vec!["first"], 1),
        ("alice()[Point { first }]; second", vec!["second"], 2),
    ] {
        let source = format!(
            "pub character alice {{ display = \"Alice\" }}\nflow main() -> Unit {{ let mut first = 1; let second = 2; let read = || {{ {body} }}; let observed = read(); assert.check(observed == {expected_value}); }}\nentry cli @entry.main {{ goto @flow.main }}\n"
        );
        let compiled =
            compile_attached_dialogue_project(&source).expect("selected closure captures compile");
        let closures = compiled
            .analysis_lease()
            .final_analysis()
            .expressions()
            .filter_map(|(_, expression)| {
                if let CheckedExpressionResolution::Closure(closure) = expression.resolution() {
                    Some(closure)
                } else {
                    None
                }
            })
            .collect::<Vec<_>>();
        let [closure] = closures.as_slice() else {
            panic!("one selected closure for {body}")
        };
        let module = compiled
            .analysis_lease()
            .hir_project()
            .view()
            .modules()
            .find_map(|(_, module)| {
                (module.module_id() == closure.owner().module()).then_some(module)
            })
            .unwrap();
        let captures = closure
            .captures()
            .iter()
            .map(|capture| {
                assert_eq!(
                    capture.mode(),
                    CaptureAccess::Read,
                    "a rejected reassignment cannot upgrade a selected read"
                );
                assert!(
                    compiled
                        .analysis_lease()
                        .final_analysis()
                        .capture(capture.capture())
                        .is_some()
                );
                module
                    .resolve_local(capture.local())
                    .unwrap()
                    .name()
                    .as_str()
            })
            .collect::<Vec<_>>();
        assert_eq!(captures, expected, "selected first-use order for {body}");
        assert_candidate_program_executes_in_native_and_awbc(&compiled);
    }
}

#[test]
fn candidate_capture_selection_crosses_each_nested_closure() {
    let compiled = compile_attached_dialogue_project("pub character alice { display = \"Alice\" }\nflow main() -> Unit { let unused = 1; let kept = 2; let outer = || { let inner = || { alice()[unused]; kept }; inner() }; let observed = outer(); }\nentry cli @entry.main { goto @flow.main }\n").expect("nested capture selection compiles");
    let mut closures = 0;
    for (_, expression) in compiled.analysis_lease().final_analysis().expressions() {
        if let CheckedExpressionResolution::Closure(closure) = expression.resolution() {
            closures += 1;
            let [capture] = closure.captures() else {
                panic!("each crossed closure needs only the selected external use")
            };
            let module = compiled
                .analysis_lease()
                .hir_project()
                .view()
                .modules()
                .find_map(|(_, module)| {
                    (module.module_id() == closure.owner().module()).then_some(module)
                })
                .unwrap();
            assert_eq!(
                module
                    .resolve_local(capture.local())
                    .unwrap()
                    .name()
                    .as_str(),
                "kept"
            );
        }
    }
    assert_eq!(closures, 2);
    assert_eq!(
        compiled.analysis_lease().final_analysis().captures().len(),
        2
    );
}

#[test]
fn candidate_recovery_is_selected_before_callable_execution_role() {
    for content in ["|[夢](ゆめ)", "{ yield 1; 0 }"] {
        let source = format!(
            "pub character alice {{ display = \"Alice\" }}\nfn speak() -> Unit {{ alice()[{content}]; () }}\nflow main() -> Unit {{ speak(); }}\nentry cli @entry.main {{ goto @flow.main }}\n"
        );
        let compiled = compile_attached_dialogue_project(&source)
            .expect("rejected syntax or yield cannot determine the function's execution role");
        let executions = compiled
            .analysis_lease()
            .final_analysis()
            .items()
            .filter_map(|(_, item)| {
                if let arcweft_lang_sema::final_analysis::CheckedItemRole::Function {
                    execution,
                    ..
                } = item.role()
                {
                    Some(execution)
                } else {
                    None
                }
            })
            .collect::<Vec<_>>();
        assert!(matches!(
            executions.as_slice(),
            [arcweft_lang_sema::final_analysis::CheckedFunctionExecution::DirectFrame]
        ));
    }
}

#[test]
fn evaluated_effect_operands_reach_awbc_from_final_checked_sources() {
    let compiled = compile_source(
        r#"
flow main() -> Unit {
    log.info("started", detail = "final source")
    drop(.Cancel)([1i64]...)
    drop(.Stop(fade = 120ms))([1i64]...)
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("typed evaluated effects compile from final call operands");

    let evaluated_effects = compiled
        .plan
        .flows()
        .iter()
        .flat_map(|flow| flow.body().ops().iter())
        .filter_map(|operation| match operation {
            FlowOp::EvaluatedEffect(effect) => Some(effect),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(evaluated_effects.len(), 3);
    assert!(matches!(
        evaluated_effects[0],
        RuntimeEffectExpr::Log { .. }
    ));
    let drop_policies = evaluated_effects
        .iter()
        .filter_map(|effect| match effect {
            RuntimeEffectExpr::Drop { policy, .. } => Some(policy),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(drop_policies.len(), 2);
    assert_eq!(drop_policies[0].kind(), RuntimeDropPolicyKind::Cancel);
    assert_eq!(drop_policies[1].kind(), RuntimeDropPolicyKind::Stop);

    let RuntimeEffectExpr::Drop { target, policy } = evaluated_effects[1] else {
        panic!("the first drop effect remains a typed Drop expression")
    };
    assert_eq!(target.kind(), &RuntimeExprKind::Value(RuntimeValue::i64(1)));
    assert!(matches!(policy, RuntimeDropPolicyExpr::Cancel));

    let RuntimeEffectExpr::Drop { target, policy } = evaluated_effects[2] else {
        panic!("the second drop effect remains a typed Drop expression")
    };
    assert_eq!(target.kind(), &RuntimeExprKind::Value(RuntimeValue::i64(1)));
    let RuntimeDropPolicyExpr::Stop { fade } = policy else {
        panic!("the second drop effect retains its typed Stop policy")
    };
    assert_eq!(
        fade.kind(),
        &RuntimeExprKind::Value(RuntimeValue::Duration(LogicalDuration::from_nanos(
            120_000_000
        ),))
    );

    AwbcLowerer::new(
        &compiled.plan,
        &compiled.dialogue_content,
        "evaluated_effects.arcw",
    )
    .lower()
    .expect("typed evaluated effects lower to verified product AWBC");
}

#[test]
fn dialogue_content_callbacks_and_delays_reach_their_exact_runtime_owners_and_awbc() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[Hello [call log.info("content")] [at 120ms call=log.info("delay")]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("dialogue content and delay effects compile from final call operands");
    let runtime_plan = compiled.runtime_plan();
    let [content] = runtime_plan.plan.dialogue_content().rows() else {
        panic!("fixture publishes one dialogue content plan")
    };
    assert_eq!(content.effect_site_count().get(), 2);
    assert_dialogue_effect_sites(&runtime_plan.plan, content, 2);
    let manifest = runtime_plan
        .plan
        .dialogue_content()
        .template(content.template())
        .expect("dialogue template manifest");
    assert!(matches!(
        manifest.effects()[0].trigger(),
        RuntimeDialogueContentEffectTrigger::Content
    ));
    assert!(matches!(
        manifest.effects()[1].trigger(),
        RuntimeDialogueContentEffectTrigger::Delay { duration }
            if duration == LogicalDuration::from_nanos(120_000_000)
    ));

    AwbcLowerer::new(
        &runtime_plan.plan,
        &runtime_plan.dialogue_content_catalog,
        "dialogue_evaluated_effects.arcw",
    )
    .lower()
    .expect("dialogue content and delay effects lower to verified product AWBC");
}

#[test]
fn ordinary_dialogue_calls_lower_inside_their_exact_content_and_delay_callbacks() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
pub character bob { display = "Bob" }

fn emit() -> Unit { () }

flow main() -> Unit {
    alice[inline [call emit()]]
    bob[delayed [at 120ms call=emit()]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("ordinary project and value calls lower as dialogue callback bodies");
    let plan = &compiled.runtime_plan().plan;
    let [immediate, delayed] = plan.dialogue_content().rows() else {
        panic!("fixture publishes one content plan per source line")
    };
    assert_eq!(immediate.effect_sites().len(), 1);
    assert_eq!(delayed.effect_sites().len(), 1);
    assert_ne!(immediate.template(), delayed.template());
    assert_eq!(
        immediate.effect_sites()[0].site(),
        arcweft_core::runtime_id::RuntimeDialogueEffectSiteId::from_zero_based(0).unwrap()
    );
    assert_eq!(
        delayed.effect_sites()[0].site(),
        immediate.effect_sites()[0].site(),
        "site ordinals are local to each exact content template"
    );
    assert_eq!(
        dialogue_effect_triggers(plan, immediate),
        [RuntimeDialogueContentEffectTrigger::Content]
    );
    assert_eq!(
        dialogue_effect_triggers(plan, delayed),
        [RuntimeDialogueContentEffectTrigger::Delay {
            duration: LogicalDuration::from_nanos(120_000_000),
        }]
    );

    assert!(
        dialogue_effect_callback_ops(plan, immediate, 0)
            .iter()
            .any(|operation| matches!(operation, FlowOp::ProjectCall { .. }))
    );
    assert!(
        dialogue_effect_callback_ops(plan, delayed, 0)
            .iter()
            .any(|operation| matches!(operation, FlowOp::ProjectCall { .. }))
    );
    assert!(
        plan.flows()
            .iter()
            .all(|flow| flow.body().ops().iter().all(|operation| !matches!(
                operation,
                FlowOp::ProjectCall { .. } | FlowOp::ApplyGroup { .. }
            ))),
        "point-action calls stay in trigger-owned callback sites"
    );
}

#[test]
fn dialogue_point_call_receives_a_checked_rgb_color_in_native_and_awbc_plans() {
    let compiled = compile_attached_dialogue_project(
        r##"
pub character alice { display = "Alice" }

fn flash(color: Color, time: Duration) -> Unit { () }

flow main() -> Unit {
    alice[flash [call flash(color=rgb("#ffffff"), time=90ms)]]
}

entry cli @entry.main { goto @flow.main }
"##,
    )
    .expect("rgb literal remains a checked Color value at the point-action call");
    let runtime = compiled.runtime_plan();
    let [content] = runtime.plan.dialogue_content().rows() else {
        panic!("one point-action content plan");
    };
    assert!(
        dialogue_effect_callback_ops(&runtime.plan, content, 0)
            .iter()
            .any(|operation| matches!(operation, FlowOp::ProjectCall { .. }))
    );
    AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "dialogue_rgb_point_call.arcw",
    )
    .lower()
    .expect("the typed Color argument lowers to verified AWBC");
}

#[expect(
    clippy::too_many_lines,
    reason = "one actual-project fixture joins closed generic default captures and proves foreign-instance admission rejects atomically"
)]
fn assert_attached_default_formal_authority(compiled: &CompiledProject) {
    use arcweft_runtime_plan::semantic_facts::{
        RuntimeProjectAttachedDefaultCapture, RuntimeProjectAttachedDefaultFunctionFact,
        RuntimeProjectFunctionFactError, RuntimeProjectFunctionInstanceFact,
    };
    let lease = compiled.analysis_lease();
    let project = lease.hir_project().analysis_view().unwrap();
    let owners = project_runtime_reachability(
        project,
        lease.project_symbols(),
        lease.final_analysis(),
        lease.checked_entries(),
        RuntimeEmissionMode::CheckAll,
    )
    .unwrap();
    let (facts, _) = project_runtime_semantic_facts(
        project,
        lease.project_symbols(),
        lease.registered_world(),
        lease.final_analysis(),
        &owners,
        Some(compiled.dialogue_profile()),
        &arcweft_compiler::lower::ProjectInstantiationControl::default(),
    )
    .unwrap();
    let instances = facts.project_function_instances().collect::<Vec<_>>();
    let mut checked = 0;
    let mut rejected_foreign = 0;
    for instance in &instances {
        let Some(default) = instance.attached_default() else {
            continue;
        };
        assert_ne!(
            default.definition_identity(),
            instance.definition_identity()
        );
        assert!(matches!(
            RuntimeProjectAttachedDefaultFunctionFact::try_new(
                instance.definition().clone(),
                default.coordinate().clone(),
                default.digest(),
                default.result().clone(),
                default.execution(),
                default.effects().into(),
                default.captures().into()
            ),
            Err(RuntimeProjectFunctionFactError::InvalidAttachedDefaultFunction)
        ));
        let admit_default = |default| {
            RuntimeProjectFunctionInstanceFact::try_new(
                instance.key().clone(),
                instance.definition().clone(),
                instance.callable().clone(),
                instance.suspension(),
                instance.control(),
                instance.execution(),
                instance.callable_type().clone(),
                instance.parameters().into(),
                instance.effects().into(),
                Some(default),
                instance.body().clone(),
                instance.semantics().clone(),
            )
        };
        if let Some(other) = instances
            .iter()
            .filter_map(|other| other.attached_default())
            .find(|other| {
                other.source() == default.source()
                    && other.definition().environment().local_uses()
                        != default.definition().environment().local_uses()
            })
        {
            assert_eq!(other.definition_identity(), default.definition_identity());
            let foreign_body = RuntimeProjectAttachedDefaultFunctionFact::try_new(
                other.definition().clone(),
                default.coordinate().clone(),
                default.digest(),
                default.result().clone(),
                default.execution(),
                default.effects().into(),
                default.captures().into(),
            )
            .unwrap();
            assert!(matches!(
                admit_default(foreign_body),
                Err(RuntimeProjectFunctionFactError::InvalidAttachedDefaultFunction)
            ));
        }
        for capture in default.captures() {
            checked += 1;
            let parameter = instance
                .parameters()
                .iter()
                .find(|parameter| parameter.identity() == capture.formal().identity())
                .unwrap();
            assert_eq!(parameter, capture.formal());
            assert!(matches!(
                RuntimeProjectAttachedDefaultCapture::try_new(
                    parameter.clone(),
                    capture.pattern_digest(),
                    Box::new([])
                ),
                Err(RuntimeProjectFunctionFactError::InvalidAttachedDefaultFunction)
            ));
            let local = capture.used_locals()[0];
            assert!(matches!(
                RuntimeProjectAttachedDefaultCapture::try_new(
                    parameter.clone(),
                    capture.pattern_digest(),
                    Box::new([local, local])
                ),
                Err(RuntimeProjectFunctionFactError::InvalidAttachedDefaultFunction)
            ));
            let foreign = instances
                .iter()
                .flat_map(|other| other.parameters())
                .find(|other| {
                    other.identity() == parameter.identity()
                        && other.binding_ty() != parameter.binding_ty()
                });
            let Some(foreign) = foreign else { continue };
            let replacement = RuntimeProjectAttachedDefaultCapture::try_new(
                foreign.clone(),
                capture.pattern_digest(),
                capture.used_locals().to_vec().into_boxed_slice(),
            )
            .unwrap();
            let captures = default
                .captures()
                .iter()
                .map(|row| {
                    if row.formal().identity() == parameter.identity() {
                        replacement.clone()
                    } else {
                        row.clone()
                    }
                })
                .collect();
            let forged = RuntimeProjectAttachedDefaultFunctionFact::try_new(
                default.definition().clone(),
                default.coordinate().clone(),
                default.digest(),
                default.result().clone(),
                default.execution(),
                default.effects().into(),
                captures,
            )
            .unwrap();
            assert!(matches!(
                admit_default(forged),
                Err(RuntimeProjectFunctionFactError::InvalidAttachedDefaultFunction)
            ));
            rejected_foreign += 1;
        }
    }
    assert!(checked >= 2, "actual defaults capture logical parameters");
    assert!(
        rejected_foreign >= 2,
        "distinct generic instances cannot exchange their captured formals"
    );
}

#[test]
fn recursive_generic_closure_in_attached_default_reaches_verified_awbc() {
    let source = r#"
pub character alice { display = "Alice" }

fn fallback<T>(value: T, seed: DialogueContent, depth: i64)[body: DialogueContent = {
    log.info("default-enter");
    if depth == 0i64 {
        seed
    } else {
        let recur = || fallback(value, seed, depth - 1i64);
        recur()
    }
}] -> DialogueContent { body }

fn omitted<T>(value: T)[seed: DialogueContent] -> DialogueContent {
    fallback(value, seed, 1i64)
}

fn supplied()[body: DialogueContent = {
    log.info("supplied-default");
    supplied()
}] -> DialogueContent { body }

flow main() -> Unit {
    alice[#omitted(1i64)[default] #supplied()[provided] #omitted("text")[second]]
}

entry cli @entry.main { goto @flow.main }
"#;
    let compiled = compile_attached_dialogue_project(source).expect(
        "recursive generic default closure retains its lexical capture and content partition",
    );
    assert_attached_default_formal_authority(&compiled);
    let declared = slot_declarations::function_body_declarations(&compiled.runtime_plan().plan);
    let shared: Vec<_> = declared
        .iter()
        .filter(|(_, owners)| owners.len() != 1)
        .collect();
    assert!(
        shared.is_empty(),
        "default and dialogue callbacks share caller slots: {shared:?}"
    );
    let runtime = compiled.runtime_plan();
    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "recursive_generic_default.arcw",
    )
    .lower()
    .expect("recursive generic default lowers to verified AWBC");
    let bytes = report.program.encode_canonical().unwrap();
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .unwrap();
    assert_eq!(decoded, report.program);
    let [flow] = runtime.plan.flows() else {
        panic!("one flow")
    };
    let template = flow
        .body()
        .ops()
        .iter()
        .find_map(|operation| match operation {
            FlowOp::Dialogue { content, .. } => runtime
                .plan
                .dialogue_content()
                .get(*content)
                .map(RuntimeDialogueContentPlan::template),
            _ => None,
        })
        .expect("the main flow dialogue owns its exact content template");
    let artifact = arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
        *blake3::hash(&bytes).as_bytes(),
    )
    .unwrap();
    let mut plan = runtime.plan.clone();
    plan.bind_artifact(artifact.clone()).unwrap();

    let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
    let native_schema = bind_test_character_dialogue_schema(
        &compiled,
        arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
        .with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
        );
    let (native_target, native_values, native_effects) = execute_single_dialogue_with_content(
        |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
        template,
    );

    let mut awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
        decoded,
        arcweft_core::awbc::schema::AwbcEntryId(0),
    )
    .unwrap();
    let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
        .with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
        );
    let (awbc_target, awbc_values, awbc_effects) = execute_single_dialogue_with_content(
        |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend),
        template,
    );

    let native_rendered = rendered_content_slot_texts(
        &runtime.dialogue_content_catalog,
        artifact.clone(),
        &native_values,
    );
    let awbc_rendered =
        rendered_content_slot_texts(&runtime.dialogue_content_catalog, artifact, &awbc_values);
    assert_eq!(native_rendered, ["default", "provided", "second"]);
    assert_eq!(awbc_rendered, native_rendered);
    let native_logs = log_messages(&native_effects);
    let awbc_logs = log_messages(&awbc_effects);
    // The supplied ContentCall bypasses its sentinel default; each omitted call
    // runs the depth-1 and depth-0 recursive defaults exactly once.
    assert_eq!(
        native_logs,
        [
            "default-enter",
            "default-enter",
            "default-enter",
            "default-enter"
        ]
    );
    assert_eq!(awbc_logs, native_logs);
    assert_eq!(native_target, awbc_target);
    let character = arcweft_character::id::CharacterId::try_new("character.alice").unwrap();
    assert_eq!(
        native_target.semantic_identity(),
        arcweft_dialogue::CharacterDialogueType::exact(character).runtime_semantic_identity()
    );
}

#[test]
fn init_out_remains_inside_the_pre_reveal_scope_in_runtime_plan() {
    let source = r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice()[本文。[p]] with {
        init {
            log.info("init-before-out")
            out ()
        }
    }
}

entry cli @entry.main { goto @flow.main }
"#;
    let compiled = compile_attached_dialogue_project(source)
        .expect("Init-scoped out is retained as a typed Dialogue result");
    let runtime = compiled.runtime_plan();
    let [flow] = runtime.plan.flows() else {
        panic!("one executable flow")
    };
    let content = flow
        .body()
        .ops()
        .iter()
        .find_map(|operation| match operation {
            FlowOp::Dialogue { content, .. } => runtime.plan.dialogue_content().get(*content),
            _ => None,
        })
        .expect("the flow owns the Dialogue content plan");
    let group = runtime
        .plan
        .line_task_groups()
        .get(
            content
                .line_task_group()
                .expect("Dialogue content owns a line task group")
                .index(),
        )
        .expect("Dialogue line task group is retained");
    let operations = group.activation_ops();
    let enter = operations
        .iter()
        .position(|operation| matches!(operation, FlowOp::EnterScope { .. }))
        .expect("Init enters its lexical activation scope");
    let commit = operations
        .iter()
        .position(|operation| matches!(operation, FlowOp::CommitDialogueResult { .. }))
        .expect("Init retains its authored out commit");
    let exit = operations
        .iter()
        .position(|operation| matches!(operation, FlowOp::ExitScope))
        .expect("Init exits its lexical activation scope");
    let pre_out_effects = operations
        .iter()
        .filter(|operation| matches!(operation, FlowOp::EvaluatedEffect(_)))
        .collect::<Vec<_>>();
    assert!(enter < commit && commit < exit);
    assert_eq!(
        pre_out_effects.len(),
        1,
        "the Init effect precedes out; activation operations: {operations:#?}"
    );
    AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "init_out_pre_reveal.arcw",
    )
    .lower()
    .expect("Init out activation stream lowers to verified AWBC");
}

#[test]
fn nested_modifier_effects_use_the_body_content_effect_plan() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[#strong()[nested [call log.info("modifier-content")] [at 120ms call=log.info("modifier-delay")]]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("nested modifier effects compile from the body-local effect plan");
    let [content] = compiled.runtime_plan().plan.dialogue_content().rows() else {
        panic!("one dialogue content plan")
    };
    assert_dialogue_effect_sites(&compiled.runtime_plan().plan, content, 2);
    assert_eq!(
        dialogue_effect_triggers(&compiled.runtime_plan().plan, content),
        [
            RuntimeDialogueContentEffectTrigger::Content,
            RuntimeDialogueContentEffectTrigger::Delay {
                duration: LogicalDuration::from_nanos(120_000_000),
            },
        ]
    );
}

#[test]
fn nested_fx_effects_use_the_body_content_effect_plan() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[#fx(shake(amplitude=1px))[nested [call log.info("fx-content")] [at 120ms call=log.info("fx-delay")]]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("nested Fx effects compile from the body-local effect plan");
    let [content] = compiled.runtime_plan().plan.dialogue_content().rows() else {
        panic!("one dialogue content plan")
    };
    assert_dialogue_effect_sites(&compiled.runtime_plan().plan, content, 2);
    assert_eq!(
        dialogue_effect_triggers(&compiled.runtime_plan().plan, content),
        [
            RuntimeDialogueContentEffectTrigger::Content,
            RuntimeDialogueContentEffectTrigger::Delay {
                duration: LogicalDuration::from_nanos(120_000_000),
            },
        ]
    );
}

#[test]
fn parent_and_nested_effect_ordinals_remain_local_before_runtime_rebasing() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[root [call log.info("root-content")] #strong()[nested [call log.info("nested-content")] [at 60ms call=log.info("nested-delay")]] [at 120ms call=log.info("root-delay")]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("parent and nested effect plans rebase from distinct local ordinal domains");
    let [content] = compiled.runtime_plan().plan.dialogue_content().rows() else {
        panic!("one dialogue content plan")
    };
    assert_eq!(content.effect_site_count().get(), 4);
    assert_dialogue_effect_sites(&compiled.runtime_plan().plan, content, 4);
    assert_eq!(
        dialogue_effect_triggers(&compiled.runtime_plan().plan, content),
        [
            RuntimeDialogueContentEffectTrigger::Content,
            RuntimeDialogueContentEffectTrigger::Content,
            RuntimeDialogueContentEffectTrigger::Delay {
                duration: LogicalDuration::from_nanos(60_000_000),
            },
            RuntimeDialogueContentEffectTrigger::Delay {
                duration: LogicalDuration::from_nanos(120_000_000),
            },
        ]
    );
}

#[test]
fn explicit_typed_text_proxy_materializes_only_from_final_sema_authority() {
    let compiled = compile_attached_dialogue_project(
        r#"
#[text_proxy(role = "keyword", hit_test = true, channel = "fallback")]
pub struct KeywordHit {
    channel: String
    weight: Option<i64>
}

pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[#object(id = @.hotspot, type = KeywordHit, weight = 3)[typed]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("explicit typed text proxy compiles from final sema authority");
    let proxy = object_proxy(&compiled);
    assert_eq!(proxy.id, "hotspot");
    assert_eq!(proxy.role.as_deref(), Some("keyword"));
    assert!(proxy.hit_test);
    let declaration = proxy.declaration.as_ref().expect("typed provenance");
    assert_eq!(declaration.struct_name, "KeywordHit");
    assert_eq!(declaration.attribute, "text_proxy");
    assert_eq!(proxy.type_name.as_deref(), Some("KeywordHit"));
    let schema = proxy.schema.as_ref().expect("typed schema DTO");
    assert_eq!(schema.id, "KeywordHit");
    assert_eq!(schema.declaration.struct_name, "KeywordHit");
    assert_eq!(schema.declaration.attribute, "text_proxy");
    assert_eq!(schema.fields.len(), 2);
    assert_eq!(schema.fields[0].id, 0);
    assert_eq!(schema.fields[0].name, "channel");
    assert!(matches!(
        schema.fields[0].kind,
        RichTextTextProxyFieldKind::Text
    ));
    assert!(!schema.fields[0].optional);
    assert!(matches!(
        &schema.fields[0].default,
        Some(RichTextTextProxyScalar::Text { value }) if value == "fallback"
    ));
    assert_eq!(schema.fields[1].id, 1);
    assert_eq!(schema.fields[1].name, "weight");
    assert!(matches!(
        schema.fields[1].kind,
        RichTextTextProxyFieldKind::Int
    ));
    assert!(schema.fields[1].optional);
    assert!(schema.fields[1].default.is_none());
    assert_eq!(proxy.fields[0].id, 0);
    assert_eq!(proxy.fields[0].name, "channel");
    assert!(matches!(
        proxy.fields[0].value,
        RichTextTextProxyScalar::Text { ref value } if value == "fallback"
    ));
    assert_eq!(proxy.fields[1].id, 1);
    assert_eq!(proxy.fields[1].name, "weight");
    assert!(matches!(
        proxy.fields[1].value,
        RichTextTextProxyScalar::Int { value: 3 }
    ));

    let executable = compiled
        .analysis_lease()
        .hir_project()
        .analysis_view()
        .expect("compiled project has executable HIR");
    let runtime_owners = project_runtime_reachability(
        executable,
        compiled.analysis_lease().project_symbols(),
        compiled.analysis_lease().final_analysis(),
        compiled.analysis_lease().checked_entries(),
        RuntimeEmissionMode::CheckAll,
    )
    .expect("Object runtime reachability");
    let runtime_facts = project_runtime_semantic_facts(
        executable,
        compiled.analysis_lease().project_symbols(),
        compiled.analysis_lease().registered_world(),
        compiled.analysis_lease().final_analysis(),
        &runtime_owners,
        Some(compiled.dialogue_profile()),
        &arcweft_compiler::lower::ProjectInstantiationControl::default(),
    )
    .expect("Object runtime semantic facts")
    .0;
    let object_owner = compiled
        .analysis_lease()
        .final_analysis()
        .expressions()
        .find_map(|(owner, expression)| {
            matches!(
                expression.resolution(),
                CheckedExpressionResolution::ContentApplication(_)
            )
            .then_some(owner)
        })
        .expect("checked Object application owner");
    assert!(
        runtime_owners.contains_expression(object_owner),
        "Object remains structurally reachable for body traversal"
    );
    assert!(
        !runtime_owners
            .selected_expression_type_owners()
            .expect("Object runtime type owner inventory")
            .contains(&object_owner)
    );
    assert!(runtime_facts.expression_type(object_owner).is_none());
    assert!(
        runtime_facts
            .calls()
            .all(|(owner, _)| owner != object_owner)
    );
}

#[test]
fn typed_text_proxy_schema_preserves_enum_defaults_order_and_optional_fields() {
    let compiled = compile_attached_dialogue_project(
        r#"
enum KeywordKind {
    Plain
    Emphasis
}

#[text_proxy(role = "keyword", kind = .Plain)]
pub struct KeywordHit {
    kind: KeywordKind
    note: Option<String>
}

pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[#object(id = @.hotspot, type = KeywordHit, kind = .Emphasis)[enum]]
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("enum-backed text proxy compiles at the object boundary");
    let proxy = object_proxy(&compiled);
    let schema = proxy.schema.as_ref().expect("typed schema DTO");
    assert_eq!(schema.id, "KeywordHit");
    assert_eq!(proxy.type_name.as_deref(), Some(schema.id.as_str()));
    assert_eq!(schema.fields.len(), 2);
    assert_eq!(schema.fields[0].id, 0);
    assert_eq!(schema.fields[0].name, "kind");
    assert!(!schema.fields[0].optional);
    assert!(matches!(
        &schema.fields[0].kind,
        RichTextTextProxyFieldKind::ClosedEnum { enum_id, variants }
            if enum_id == "KeywordKind" && variants == &["Plain", "Emphasis"]
    ));
    assert!(matches!(
        &schema.fields[0].default,
        Some(RichTextTextProxyScalar::ClosedEnum { enum_id, variant })
            if enum_id == "KeywordKind" && *variant == 0
    ));
    assert_eq!(schema.fields[1].id, 1);
    assert_eq!(schema.fields[1].name, "note");
    assert!(schema.fields[1].optional);
    assert!(schema.fields[1].default.is_none());
    assert_eq!(proxy.fields.len(), 1);
    assert_eq!(proxy.fields[0].id, 0);
    assert_eq!(proxy.fields[0].name, "kind");
    assert!(matches!(
        &proxy.fields[0].value,
        RichTextTextProxyScalar::ClosedEnum { enum_id, variant }
            if enum_id == "KeywordKind" && *variant == 1
    ));
}

#[test]
fn dialogue_mark_projection_is_content_ordered_and_uses_the_exact_checked_trigger() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[before [mark @.first] middle [mark @.second] after] with {
        on mark(@.first) => return ()
        on mark(@.second) => return ()
    }
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("source-ordered dialogue markers compile");

    let plan = &compiled.runtime_plan().plan;
    let [content] = plan.dialogue_content().rows() else {
        panic!("one dialogue content plan");
    };
    assert_eq!(
        content
            .marks()
            .iter()
            .map(|mark| (mark.id().index(), mark.label()))
            .collect::<Vec<_>>(),
        vec![(0, "first"), (1, "second")]
    );

    let group_id = content
        .line_task_group()
        .expect("marker handlers publish one line-task group");
    let group = plan
        .line_task_groups()
        .get(group_id.index())
        .expect("content line-task group");
    let mut triggers = Vec::new();
    collect_mark_triggers(group, group.root(), &mut triggers);
    assert_eq!(
        triggers,
        [
            RuntimeDialogueMarkId::from_zero_based(0).expect("first runtime mark"),
            RuntimeDialogueMarkId::from_zero_based(1).expect("second runtime mark"),
        ]
    );

    let [first, second] = content.marks() else {
        panic!("content mark inventory");
    };
    assert_eq!(first.id(), triggers[0]);
    assert_eq!(second.id(), triggers[1]);
}

#[test]
fn dialogue_mark_projection_keeps_equal_local_names_content_qualified() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }

flow main() -> Unit {
    alice[first [mark @.same] end] with {
        on mark(@.same) => return ()
    }

    alice[second [mark @.same] end] with {
        on mark(@.same) => return ()
    }
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("equal local marker names in distinct applications compile");

    let contents = compiled.runtime_plan().plan.dialogue_content().rows();
    assert_eq!(contents.len(), 2);
    assert!(contents.iter().all(|content| {
        content.marks().len() == 1
            && content.marks()[0].id() == RuntimeDialogueMarkId::from_zero_based(0).unwrap()
            && content.marks()[0].label() == "same"
    }));
    let groups = contents
        .iter()
        .map(|content| {
            let group_id = content.line_task_group().expect("marker line-task group");
            compiled
                .runtime_plan()
                .plan
                .line_task_groups()
                .get(group_id.index())
                .expect("content line-task group")
        })
        .collect::<Vec<_>>();
    let triggers = groups
        .into_iter()
        .map(|group| {
            let mut marks = Vec::new();
            collect_mark_triggers(group, group.root(), &mut marks);
            marks
        })
        .collect::<Vec<_>>();
    assert_eq!(
        triggers,
        vec![vec![RuntimeDialogueMarkId::from_zero_based(0).unwrap()]; 2]
    );
}

#[test]
fn inline_colon_dialogue_plan_reaches_compiler_hir() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice: hello[mark @.end]
    with:
        on mark(@.end) => log.info("end")
    return ()
}

entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("colon dialogue source compiles");
    let plans = compiled
        .analysis_lease()
        .hir_project()
        .view()
        .modules()
        .flat_map(|(_, module)| module.expressions())
        .filter_map(|(_, expression)| match expression.kind() {
            arcweft_lang_hir::expr::HirExprKind::AttachedContentApplication(application) => {
                match application.family() {
                    arcweft_lang_hir::dialogue_application::HirAttachedContentApplicationFamily::DialogueLine { plan, .. } => {
                        plan.as_ref().map(|plan| plan.items().len())
                    }
                    _ => None,
                }
            }
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(plans, [1]);
}

#[test]
fn line_registry_write_effects_follow_the_original_group_into_verified_awbc() {
    use arcweft_core::awbc::schema::{AwbcEffectPayload, AwbcInstruction};
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> String effects { state.write('line), log.write } {
    alice(voice=auto):
        本文。[mark @.change][p]
    with:
        init:
            'line.focus <- true
        on mark(@.change) {
            'line.focus <- false
        }
        cancel on input(.SkipLine) {
            'line.focus <- false
            out "Skipped"
        }
        defer on cancelled { 'line.focus <- false; log.info("cancelled") }
        out "Completed"
    return "done"
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("the authorized line project compiles");
    let runtime = compiled.runtime_plan();
    let [group] = runtime.plan.line_task_groups() else {
        panic!("one original line group")
    };
    let permission = arcweft_id::EffectId::parse("state.write('line.focus)").unwrap();
    assert!(
        group
            .effects()
            .iter()
            .any(|effect| effect.covers(&permission))
    );

    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "line_registry_effects.arcw",
    )
    .lower()
    .expect("registry write payloads and their generated line signatures verify");
    let bytes = report.program.encode_canonical().expect("encode AWBC");
    let program = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .expect("decode verified AWBC");
    let [group] = program.line_task_groups.as_slice() else {
        panic!("one generated line group")
    };
    let activation = &program.functions[group.activation.index()];
    let activation_effects = program.signatures[activation.signature.index()].effects;
    assert!(
        program.effect_sets[activation_effects.index()]
            .effects
            .iter()
            .any(|label| {
                arcweft_id::EffectId::parse(&program.strings[label.index()])
                    .is_ok_and(|effect| effect.covers(&permission))
            })
    );
    let writes = program
        .instructions
        .iter()
        .filter(|instruction| match instruction {
            AwbcInstruction::EmitEffect { effect, .. } => matches!(
                &program.effect_plans[effect.index()].payload,
                AwbcEffectPayload::RegistryWrite { key, .. }
                    if arcweft_id::EffectId::state_write(key) == permission
            ),
            _ => false,
        })
        .count();
    assert_eq!(writes, 4);
}

#[test]
fn reached_line_defers_keep_capture_order_and_verified_awbc_sites() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    let message = "captured"
    alice: hello[p]
    with:
        defer { log.info(message) }
        defer on failed { log.info("failed") }
        defer { log.info("last") }
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("checked line defer bodies compile with their capture ABI");
    let runtime = compiled.runtime_plan();
    let [content] = runtime.plan.dialogue_content().rows() else {
        panic!("one dialogue content plan")
    };
    let group = runtime
        .plan
        .line_task_groups()
        .get(content.line_task_group().expect("line task group").index())
        .expect("published line task group");
    let registrations = group
        .activation_ops()
        .iter()
        .filter_map(|op| match op {
            FlowOp::RegisterDefer {
                site,
                outcome,
                captures,
                owner,
            } => Some((*site, *outcome, captures.len(), *owner)),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(registrations.len(), 3);
    assert_eq!(registrations[0].2, 1);
    assert_eq!(registrations[1].2, 0);
    assert_eq!(registrations[2].2, 0);
    assert_eq!(
        registrations[0].3,
        arcweft_core::plan::RuntimeDeferOwner::LineRoot
    );
    assert_eq!(
        registrations[1].3,
        arcweft_core::plan::RuntimeDeferOwner::LineRoot
    );
    assert_eq!(
        registrations[2].3,
        arcweft_core::plan::RuntimeDeferOwner::LineRoot
    );
    assert_eq!(
        registrations[0].1,
        arcweft_core::line_task::RuntimeDeferOutcomeFilter::Always
    );
    assert_eq!(
        registrations[1].1,
        arcweft_core::line_task::RuntimeDeferOutcomeFilter::Failed
    );
    assert_eq!(runtime.plan.defer_sites().len(), 3);

    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "line_defer_sites.arcw",
    )
    .lower()
    .expect("defer registrations lower to verified AWBC");
    assert_eq!(report.program.defer_sites.len(), 3);
    let bytes = report.program.encode_canonical().expect("encode AWBC");
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .expect("decode AWBC");
    assert_eq!(decoded, report.program);
}

#[test]
fn line_root_deferred_children_execute_in_native_and_awbc_lifo() {
    for terminal_separator in [";", ""] {
        let compiled = compile_attached_dialogue_project(&format!(
            r#"
pub character alice {{ display = "Alice" }}
flow main() -> Unit {{
    let message = "first"
    alice: hello[p]
    with:
        defer {{ log.info(message){terminal_separator} }}
        defer on failed {{ log.info("failed"){terminal_separator} }}
        defer {{ log.info("last"){terminal_separator} }}
}}
entry cli @entry.main {{ goto @flow.main }}
"#
        ))
        .expect("checked line defer effects compile as executable bodies");
        let runtime = compiled.runtime_plan();
        let report = AwbcLowerer::new(
            &runtime.plan,
            &runtime.dialogue_content_catalog,
            "line_defer_execution.arcw",
        )
        .lower()
        .expect("defer bodies lower to verified AWBC");
        let bytes = report.program.encode_canonical().expect("encode AWBC");
        let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
            &bytes,
            arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
        )
        .expect("decode AWBC");

        let [flow] = runtime.plan.flows() else {
            panic!("one flow")
        };
        let [template] = runtime.dialogue_content_catalog.templates() else {
            panic!("one template")
        };
        let mut plan = runtime.plan.clone();
        plan.bind_artifact(
            arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
                *blake3::hash(&bytes).as_bytes(),
            )
            .unwrap(),
        )
        .unwrap();
        let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
        let native_schema = bind_test_character_dialogue_schema(
            &compiled,
            arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
        );
        let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
            );
        let (_, _, native_effects) = execute_single_dialogue_with_content(
            |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
            template.id(),
        );
        assert_eq!(log_messages(&native_effects), ["last", "first"]);

        let mut awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
            decoded,
            arcweft_core::awbc::schema::AwbcEntryId(0),
        )
        .unwrap();
        let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
        let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
            );
        let (_, _, awbc_effects) = execute_single_dialogue_with_content(
            |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend),
            template.id(),
        );
        assert_eq!(log_messages(&awbc_effects), log_messages(&native_effects));
    }
}

#[test]
fn sibling_thread_dialogue_callbacks_join_their_own_activation() {
    use arcweft_core::engine::{FlowExit, FlowFiberStatus};
    use arcweft_core::plan::FlowEvent;
    use arcweft_core::step::{
        RuntimeDialogueContentEvent, RuntimeDialogueContentEventKind, RuntimeStepInput,
        RuntimeStepOptions,
    };
    use arcweft_core::time::TickId;

    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
fn emit(message: String) -> Unit { log.info(message) }
flow main() -> Unit {
    thread first { alice[inline [call emit("first")]] }
    thread second { alice[inline [call emit("second")]] }
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("sibling Threads retain their exact dialogue callbacks");
    let runtime = compiled.runtime_plan();
    let bytes = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "sibling_thread_dialogue_callbacks.arcw",
    )
    .lower()
    .expect("the actual Source lowers to a sealed Product artifact")
    .program
    .encode_canonical()
    .unwrap();
    let [flow] = runtime.plan.flows() else {
        panic!("one source Flow");
    };
    let mut plan = runtime.plan.clone();
    plan.bind_artifact(
        arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
            *blake3::hash(&bytes).as_bytes(),
        )
        .unwrap(),
    )
    .unwrap();
    let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
    let schema = bind_test_character_dialogue_schema(
        &compiled,
        arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut backend = arcweft_core::pure::VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut advances = Vec::new();
    let mut content_events = Vec::new();
    let mut delivered_effects = 0;
    let mut parents = std::collections::BTreeSet::new();
    let mut activations = std::collections::BTreeSet::new();
    let mut effects = Vec::new();
    let mut submissions = 0;
    for tick in 0..256 {
        let revealed = std::mem::take(&mut content_events);
        let ready_advances = if revealed.is_empty() {
            std::mem::take(&mut advances)
        } else {
            Vec::new()
        };
        delivered_effects += revealed.len();
        let result = native.step_with_pure_backend(
            RuntimeStepInput {
                tick: TickId(tick),
                dialogue_content_events: revealed,
                dialogue_advances: ready_advances,
                ..RuntimeStepInput::default()
            },
            RuntimeStepOptions::default(),
            &mut backend,
        );
        assert!(result.stats.executed_ops <= 1);
        assert!(
            result.output.diagnostics.is_empty(),
            "{:?}",
            result.output.diagnostics
        );
        submissions += result.output.requests.tasks.len();
        effects.extend(result.output.effects.line);
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine { activation, .. } = event {
                parents.insert(activation.owner_fiber());
                assert!(activations.insert(activation.clone()));
                let content = runtime
                    .plan
                    .dialogue_content()
                    .get(activation.content())
                    .unwrap();
                let [site] = content.effect_sites() else {
                    panic!("each source line reveals one callback");
                };
                content_events.push(RuntimeDialogueContentEvent::new(
                    activation.clone(),
                    RuntimeDialogueContentEventKind::Effect(site.site()),
                ));
                advances.push(activation);
            }
        }
        if let FlowFiberStatus::Done(exit) = result.fiber_status {
            assert_eq!(exit, FlowExit::Done);
            assert_eq!(submissions, 2);
            assert_eq!(parents.len(), 2);
            assert_eq!(activations.len(), 2);
            assert_eq!(delivered_effects, 2);
            assert_eq!(log_messages(&effects), ["first", "second"]);
            assert_eq!(native.child_fiber_count(), 0);
            return;
        }
    }
    panic!("sibling dialogue callbacks did not finish their owning activations");
}

#[test]
fn cancellation_out_selects_the_dialogue_result_in_native_and_decoded_awbc() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice: hello[p]
    with:
        cancel on input(.SkipLine):
            log.info("cancelled")
            out "Skipped"
        out "Normal"
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("checked cancel out and normal result compile");
    let runtime = compiled.runtime_plan();
    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "cancel_out_execution.arcw",
    )
    .lower()
    .expect("cancel selection lowers to verified AWBC");
    let bytes = report.program.encode_canonical().expect("encode AWBC");
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .expect("decode AWBC");
    let [flow] = runtime.plan.flows() else {
        panic!("one flow")
    };
    for (cancelled, expected) in [(false, &[][..]), (true, &["cancelled"][..])] {
        let mut plan = runtime.plan.clone();
        plan.bind_artifact(
            arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
                *blake3::hash(&bytes).as_bytes(),
            )
            .unwrap(),
        )
        .unwrap();
        let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
        let native_schema = bind_test_character_dialogue_schema(
            &compiled,
            arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
        );
        let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
            );
        assert_eq!(
            execute_dialogue_result_with_action(
                |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
                cancelled,
                "native",
                1,
            ),
            expected,
        );
        let awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
            decoded.clone(),
            arcweft_core::awbc::schema::AwbcEntryId(0),
        )
        .unwrap();
        let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
        let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
            );
        let mut awbc = Some(awbc);
        assert_eq!(
            execute_dialogue_result_with_action(
                |input, options| {
                    let current = awbc
                        .as_mut()
                        .expect("AWBC executor is present for one step");
                    let result = current.step_with_pure_backend(input, options, &mut awbc_backend);
                    let snapshot = current
                        .snapshot()
                        .expect("AWBC cancellation step snapshots");
                    let arcweft_core::executor::ArcweftRuntimeExecutorSnapshot::AwbcProduct(saved) =
                        snapshot;
                    let saved = arcweft_core::awbc::product_step::AwbcProductExecutorSaveSnapshot::from_live(
                        &saved, current.admitted_product_awbc_program().unwrap()).expect("project the cancellation boundary to its save grammar");
                    let bytes = serde_json::to_vec(&saved).expect("encode cancellation save DTO");
                    let decoded = serde_json::from_slice::<
                        arcweft_core::awbc::product_step::AwbcProductExecutorSaveSnapshot,
                    >(&bytes)
                    .expect("decode cancellation save DTO");
                    assert_eq!(decoded, saved);
                    let decoded = current
                        .bind_product_save_snapshot(decoded)
                        .expect("bind cancellation save to the original program and Source");
                    awbc = Some(
                        awbc.take()
                            .expect("AWBC executor transfers to its restore")
                            .restore_snapshot(
                                arcweft_core::executor::ArcweftRuntimeExecutorSnapshot::AwbcProduct(
                                    decoded,
                                ),
                            )
                            .expect("AWBC cancellation step restores with exact owner"),
                    );
                    result
                },
                cancelled,
                "awbc",
                1,
            ),
            expected,
        );
    }
}

#[test]
fn dialogue_registry_writes_reach_the_line_and_nearest_flow_across_product_save() {
    use arcweft_core::{
        awbc::product_step::AwbcProductExecutorSaveSnapshot,
        engine::{FlowExit, FlowFiberStatus},
        executor::{ArcweftRuntimeExecutor, ArcweftRuntimeExecutorSnapshot},
        plan::{FlowEvent, RuntimeEntryTarget},
        runtime_id::DialogueActivationId,
        step::{
            RuntimeDialogueContentEvent, RuntimeDialogueContentEventKind,
            RuntimeDialogueInputActionEvent, RuntimeStepInput, RuntimeStepOptions,
            RuntimeStepResult,
        },
        time::TickId,
    };
    use arcweft_interaction_model::input::{InputActionId, InputEpoch, InputSequence};

    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
fn write_flow_flag() -> Unit effects { state.write('flow.helper_flag) } {
    'flow.helper_flag <- true
    return ()
}
flow main() -> Unit effects { state.write('line), state.write('flow), log.write } {
    'flow.initial_flag <- false
    include @flow.scene
}
flow scene() -> Unit effects { state.write('line), state.write('flow), log.write } {
    alice:
        本文。[mark @.change][p]
    with:
        init:
            'line.initial_flag <- true
            'flow.initial_flag <- true
            if true { 'line.nested_flag <- true }
            write_flow_flag()
        on mark(@.change) {
            'line.marked_flag <- true
            'flow.marked_flag <- true
            log.info("mark")
        }
        cancel on input(.SkipLine) {
            'line.cancel_flag <- true
            'flow.cancel_flag <- true
            log.info("cancel")
            out "Skipped"
        }
        defer on completed { 'line.completed_flag <- true; 'flow.completed_flag <- true; log.info("completed") }
        defer on cancelled { 'line.cancelled_flag <- true; 'flow.cancelled_flag <- true; log.info("cancelled") }
        out "Completed"
    'flow.after_dialogue <- true
    log.info("after dialogue")
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("checked line and callback writes compile");
    let runtime = compiled.runtime_plan();
    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "line_registry.arcw",
    )
    .lower()
    .expect("line effects verify against their original group");
    let bytes = report.program.encode_canonical().unwrap();
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .unwrap();
    let [entry] = runtime.plan.entries() else {
        panic!("fixture owns one Entry")
    };
    let RuntimeEntryTarget::Flow(flow) = &entry.target else {
        panic!("fixture Entry targets a Flow")
    };

    for cancelled in [false, true] {
        let run = |backend: &str,
                   step: &mut dyn FnMut(
            RuntimeStepInput,
            RuntimeStepOptions,
        ) -> RuntimeStepResult| {
            let mut revealed = None::<DialogueActivationId>;
            let mut sent_mark = false;
            let mut sent_finish = false;
            let mut mark_complete = false;
            let mut logs = Vec::new();
            for tick in 0..512 {
                let mut input = RuntimeStepInput {
                    tick: TickId(tick),
                    ..Default::default()
                };
                if let Some(activation) = revealed {
                    if !sent_mark {
                        input
                            .dialogue_content_events
                            .push(RuntimeDialogueContentEvent::new(
                                activation,
                                RuntimeDialogueContentEventKind::Mark(
                                    RuntimeDialogueMarkId::from_zero_based(0).unwrap(),
                                ),
                            ));
                        sent_mark = true;
                    } else if mark_complete && !sent_finish {
                        if cancelled {
                            input.dialogue_input_actions.push(
                                RuntimeDialogueInputActionEvent::new(
                                    activation,
                                    InputActionId::new("SkipLine").unwrap(),
                                    InputEpoch::new(1),
                                    InputSequence::new(1),
                                ),
                            );
                        } else {
                            input.dialogue_advances.push(activation);
                        }
                        sent_finish = true;
                    }
                }
                let result = step(input, RuntimeStepOptions::default());
                assert!(result.stats.executed_ops <= 1, "{result:?}");
                assert!(
                    result.output.diagnostics.is_empty(),
                    "{backend} tick={tick} cancelled={cancelled} revealed={revealed:?} sent_mark={sent_mark} sent_finish={sent_finish} logs={logs:?}: {result:?}"
                );
                assert!(result.output.requests.host_calls.is_empty());
                logs.extend(log_messages(&result.output.effects.line));
                mark_complete |=
                    result.stats.child_fibers == 0 && logs.iter().any(|log| log == "mark");
                for event in result.output.flow_events {
                    if let FlowEvent::DialogueLine { activation, .. } = event {
                        assert!(revealed.replace(activation).is_none());
                    }
                }
                if result.fiber_status == FlowFiberStatus::Done(FlowExit::Done) {
                    assert!(revealed.is_some() && sent_mark && sent_finish);
                    return logs;
                }
            }
            panic!("{backend} line did not finish within 512 steps, cancelled={cancelled}");
        };

        let mut plan = runtime.plan.clone();
        plan.bind_artifact(
            arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
                *blake3::hash(&bytes).as_bytes(),
            )
            .unwrap(),
        )
        .unwrap();
        let mut native = arcweft_core::engine::Engine::for_flow(plan, flow).unwrap();
        let native_schema = bind_test_character_dialogue_schema(
            &compiled,
            arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
        );
        let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
            );
        let native_logs = run("native", &mut |input, options| {
            native.step_with_pure_backend(input, options, &mut native_backend)
        });

        let awbc = ArcweftRuntimeExecutor::from_awbc_product(
            decoded.clone(),
            arcweft_core::awbc::schema::AwbcEntryId(0),
        )
        .unwrap();
        let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
        let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
            );
        let mut awbc = Some(awbc);
        let mut observed_keys = std::collections::BTreeSet::new();
        let mut flow_keys_after_dialogue = None;
        let awbc_logs = run("awbc", &mut |input, options| {
            let mut current = awbc.take().unwrap();
            let result = current.step_with_pure_backend(input, options, &mut awbc_backend);
            let ArcweftRuntimeExecutorSnapshot::AwbcProduct(snapshot) = current.snapshot().unwrap();
            let saved = AwbcProductExecutorSaveSnapshot::from_live(
                &snapshot,
                current.admitted_product_awbc_program().unwrap(),
            )
            .unwrap();
            let wire = serde_json::to_value(&saved).unwrap();
            let entries = wire["dialogues"]["entries"].as_array().unwrap();
            let fiber = &wire["fiber"];
            let frames = fiber["frames"].as_array().unwrap();
            if let [caller, scene] = frames.as_slice() {
                let caller_rows = caller["flow_registry"].as_array().unwrap();
                assert_eq!(caller_rows.len(), 1);
                assert_eq!(caller_rows[0]["row"]["key"]["segments"][0], "initial_flag");
                assert_eq!(caller_rows[0]["row"]["value"]["Bool"], false);
                let mut keys = Vec::new();
                if let Some(rows) = scene["flow_registry"].as_array() {
                    for row in rows {
                        assert_eq!(row["row"]["key"]["scope"], "flow");
                        assert_eq!(row["row"]["value"]["Bool"], true);
                        assert_eq!(row["source"]["Awbc"]["fiber"], fiber["instance"]);
                        assert_eq!(row["source"]["Awbc"]["frame"], scene["instance"]);
                        let [key] = row["row"]["key"]["segments"].as_array().unwrap().as_slice()
                        else {
                            panic!("one authored path segment: {row}");
                        };
                        keys.push(key.as_str().unwrap().to_owned());
                    }
                }
                if flow_keys_after_dialogue.is_none()
                    && keys.first().is_some_and(|key| key == "after_dialogue")
                {
                    assert!(entries.iter().all(|entry| entry.get("Active").is_none()));
                    flow_keys_after_dialogue = Some(keys);
                }
            }
            if result.fiber_status == FlowFiberStatus::Done(FlowExit::Done) {
                assert!(entries.iter().all(|entry| entry.get("Active").is_none()));
                assert!(
                    frames
                        .iter()
                        .all(|frame| frame.get("flow_registry").is_none())
                );
            }
            for entry in entries {
                if let Some(rows) = entry["Active"]["line"]["line_registry"].as_array() {
                    for row in rows {
                        assert_eq!(row["row"]["key"]["scope"], "line");
                        assert_eq!(row["row"]["value"]["Bool"], true);
                        assert_eq!(
                            row["source"]["AwbcLine"]["activation"],
                            entry["Active"]["activation"]
                        );
                        let [key] = row["row"]["key"]["segments"].as_array().unwrap().as_slice()
                        else {
                            panic!("one authored path segment: {row}");
                        };
                        observed_keys.insert(key.as_str().unwrap().to_owned());
                    }
                }
            }
            let decoded = serde_json::from_slice(&serde_json::to_vec(&wire).unwrap()).unwrap();
            let bound = current.bind_product_save_snapshot(decoded).unwrap();
            awbc = Some(
                current
                    .restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(bound))
                    .unwrap(),
            );
            result
        });
        let (logs, keys, flow_keys): (&[&str], &[&str], &[&str]) = if cancelled {
            (
                &["mark", "cancel", "cancelled", "after dialogue"],
                &[
                    "cancel_flag",
                    "cancelled_flag",
                    "initial_flag",
                    "marked_flag",
                    "nested_flag",
                ],
                &[
                    "after_dialogue",
                    "cancel_flag",
                    "cancelled_flag",
                    "helper_flag",
                    "initial_flag",
                    "marked_flag",
                ],
            )
        } else {
            (
                &["mark", "completed", "after dialogue"],
                &[
                    "completed_flag",
                    "initial_flag",
                    "marked_flag",
                    "nested_flag",
                ],
                &[
                    "after_dialogue",
                    "completed_flag",
                    "helper_flag",
                    "initial_flag",
                    "marked_flag",
                ],
            )
        };
        assert_eq!(native_logs, logs);
        assert_eq!(awbc_logs, logs);
        assert_eq!(
            observed_keys.iter().map(String::as_str).collect::<Vec<_>>(),
            keys
        );
        assert_eq!(flow_keys_after_dialogue.unwrap(), flow_keys);
    }
}

#[test]
fn decoded_registry_reads_reach_the_line_and_parent_flow_from_dialogue_callbacks() {
    use arcweft_core::awbc::codec::AwbcDecodeBudget;
    use arcweft_core::awbc::product_step::AwbcProductExecutorSaveSnapshot;
    use arcweft_core::awbc::schema::{AwbcConstant, AwbcEntryId, AwbcInstruction, AwbcProgram};
    use arcweft_core::effect::RuntimeRegistryReadKind;
    use arcweft_core::executor::{ArcweftRuntimeExecutor, ArcweftRuntimeExecutorSnapshot};
    use arcweft_id::{DeclarationName, LifetimeRegistryKey, LifetimeScopeKind};

    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit effects { state.write('flow), state.write('line), log.write } {
    let result = alice()[本文。[mark @.release][p]] with {
        init {
            'flow.saved <- "parent Flow"
            'line.saved <- "line activation"
            log.info("__flow_at_init__")
        }
        on mark(@.release) {
            log.info("mark-handler-enter")
            log.info("__flow_at_mark__")
            out "__line_at_mark__"
        }
    }
    log.info(result)
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .unwrap();
    let runtime = compiled.runtime_plan();
    let mut program = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "reached_registry_read.arcw",
    )
    .lower()
    .unwrap()
    .program;
    let mut reads = std::collections::BTreeSet::new();
    // The existing source writes establish the real registry owners. Emit the
    // read instruction here so the runtime test is independent of Source lowering.
    for instruction in &mut program.instructions {
        let AwbcInstruction::LoadConst { dst, constant } = *instruction else {
            continue;
        };
        let AwbcConstant::String(name) = program.constants[constant.index()] else {
            continue;
        };
        let name = program.strings[name.index()].as_str();
        let scope = match name {
            "__flow_at_init__" | "__flow_at_mark__" => LifetimeScopeKind::Flow,
            "__line_at_mark__" => LifetimeScopeKind::Line,
            _ => continue,
        };
        assert!(reads.insert(name));
        *instruction = AwbcInstruction::ReadRegistry {
            dst,
            key: LifetimeRegistryKey::new(
                scope,
                Box::new([DeclarationName::try_new("saved").unwrap()]),
            ),
            kind: RuntimeRegistryReadKind::Required,
        };
    }
    assert_eq!(reads.len(), 3);
    let bytes = program.encode_canonical().unwrap();
    let decoded = AwbcProgram::decode_canonical(&bytes, AwbcDecodeBudget::default()).unwrap();
    let executor = ArcweftRuntimeExecutor::from_awbc_product(decoded, AwbcEntryId(0)).unwrap();
    let schema = bind_test_character_dialogue_schema(&compiled, executor.program_owner());
    let mut backend = arcweft_core::pure::VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut executor = Some(executor);
    let (logs, succeeded) = execute_dialogue_result_with_mark(
        |input, options| {
            let mut current = executor.take().unwrap();
            let step = current.step_with_pure_backend(input, options, &mut backend);
            assert!(step.stats.executed_ops <= 1);
            let ArcweftRuntimeExecutorSnapshot::AwbcProduct(snapshot) = current.snapshot().unwrap();
            let save = AwbcProductExecutorSaveSnapshot::from_live(
                &snapshot,
                current.admitted_product_awbc_program().unwrap(),
            )
            .unwrap();
            let decoded = serde_json::from_slice(&serde_json::to_vec(&save).unwrap()).unwrap();
            let bound = current.bind_product_save_snapshot(decoded).unwrap();
            executor = Some(
                current
                    .restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(bound))
                    .unwrap(),
            );
            step
        },
        true,
        "decoded AWBC registry read",
    );
    assert!(succeeded);
    assert_eq!(
        logs,
        [
            "parent Flow",
            "mark-handler-enter",
            "parent Flow",
            "line activation"
        ]
    );
}

#[test]
fn mark_out_selects_an_on_only_non_unit_result_in_native_and_decoded_awbc() {
    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    let result = alice()[本文。[mark @.release][p]] with {
        on mark(@.release) {
            log.info("mark-handler-enter")
            out "Released"
        }
    }
    log.info(result)
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("one mark handler supplies the non-Unit DialogueLine result");
    let runtime = compiled.runtime_plan();
    let [content] = runtime.plan.dialogue_content().rows() else {
        panic!("one dialogue content plan")
    };
    let group = runtime
        .plan
        .line_task_groups()
        .get(
            content
                .line_task_group()
                .expect("mark line-task group")
                .index(),
        )
        .expect("accepted mark line-task group");
    assert!(
        group
            .activation_ops()
            .iter()
            .all(|operation| !matches!(operation, FlowOp::CommitDialogueResult { .. }))
    );
    let selectors = group
        .nodes()
        .iter()
        .filter_map(|node| match node {
            LineTaskNode::Action(operations) => Some(
                operations
                    .iter()
                    .filter_map(|operation| match operation {
                        FlowOp::SelectDialogueResult { value } => Some(value),
                        _ => None,
                    })
                    .collect::<Vec<_>>(),
            ),
            _ => None,
        })
        .flatten()
        .collect::<Vec<_>>();
    let [selected] = selectors.as_slice() else {
        panic!("the mark Action owns one typed line-result selector")
    };
    assert_eq!(selected.ty(), group.result_type());
    let mut triggers = Vec::new();
    collect_mark_triggers(group, group.root(), &mut triggers);
    assert_eq!(
        triggers,
        [RuntimeDialogueMarkId::from_zero_based(0).unwrap()]
    );

    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "mark_out_on_only_execution.arcw",
    )
    .lower()
    .expect("mark result selection lowers to verified AWBC");
    let bytes = report.program.encode_canonical().expect("encode AWBC");
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .expect("decode AWBC");
    let [flow] = runtime.plan.flows() else {
        panic!("one flow")
    };

    for deliver_mark in [true, false] {
        let mut plan = runtime.plan.clone();
        plan.bind_artifact(
            arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
                *blake3::hash(&bytes).as_bytes(),
            )
            .unwrap(),
        )
        .unwrap();
        let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
        let native_schema = bind_test_character_dialogue_schema(
            &compiled,
            arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
        );
        let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
            );
        let (native_logs, native_succeeded) = execute_dialogue_result_with_mark(
            |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
            deliver_mark,
            "native",
        );

        let mut awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
            decoded.clone(),
            arcweft_core::awbc::schema::AwbcEntryId(0),
        )
        .unwrap();
        let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
        let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
            .with_external_calls(
                arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
            );
        let (awbc_logs, awbc_succeeded) = execute_dialogue_result_with_mark(
            |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend),
            deliver_mark,
            "awbc",
        );
        if deliver_mark {
            assert!(native_succeeded && awbc_succeeded);
            assert_eq!(native_logs, ["mark-handler-enter", "Released"]);
        } else {
            assert!(!native_succeeded && !awbc_succeeded);
            assert!(native_logs.is_empty());
        }
        assert_eq!(awbc_logs, native_logs);
        assert_eq!(awbc_succeeded, native_succeeded);
    }
}

fn execute_dialogue_result_with_mark(
    step: impl FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
    deliver_mark: bool,
    backend: &str,
) -> (Vec<String>, bool) {
    let first_mark = RuntimeDialogueMarkId::from_zero_based(0).unwrap();
    let marks = if deliver_mark {
        std::slice::from_ref(&first_mark)
    } else {
        &[]
    };
    execute_dialogue_result_with_marks(step, marks, backend)
}

fn execute_dialogue_result_with_marks(
    mut step: impl FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
    marks: &[RuntimeDialogueMarkId],
    backend: &str,
) -> (Vec<String>, bool) {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        plan::FlowEvent,
        step::{
            RuntimeDialogueContentEvent, RuntimeDialogueContentEventKind, RuntimeStepInput,
            RuntimeStepOptions,
        },
        time::TickId,
    };

    let deliver_mark = !marks.is_empty();
    let mut activation: Option<arcweft_core::runtime_id::DialogueActivationId> = None;
    let mut mark_delivered = false;
    let mut mark_handler_child_seen = false;
    let mut mark_handler_completed = false;
    let mut effects = Vec::new();
    let mut seen = 0;
    let mut last_status = None;
    for tick in 0..512 {
        let mut input = RuntimeStepInput {
            tick: TickId(tick),
            ..RuntimeStepInput::default()
        };
        if let Some(current) = activation.as_ref() {
            if deliver_mark && !mark_delivered {
                input
                    .dialogue_content_events
                    .extend(marks.iter().map(|mark| {
                        RuntimeDialogueContentEvent::new(
                            current.clone(),
                            RuntimeDialogueContentEventKind::Mark(*mark),
                        )
                    }));
                mark_delivered = true;
            } else if deliver_mark && !mark_handler_completed {
                // Wait until the selected handler child finishes before advancing.
            } else {
                input.dialogue_advances.push(current.clone());
                activation = None;
            }
        }

        let result = step(input, RuntimeStepOptions::default());
        effects.extend(result.output.effects.line);
        if deliver_mark && mark_delivered && result.stats.child_fibers > 0 {
            mark_handler_child_seen = true;
        }
        if deliver_mark
            && mark_handler_child_seen
            && result.stats.child_fibers == 0
            && log_messages(&effects)
                .iter()
                .any(|message| message == "mark-handler-enter")
        {
            mark_handler_completed = true;
        }
        if !result.output.diagnostics.is_empty() {
            assert!(!deliver_mark, "{backend}: {:?}", result.output.diagnostics);
            assert_eq!(seen, 1, "{backend}: one line was revealed before failure");
            return (log_messages(&effects), false);
        }
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine {
                activation: revealed,
                ..
            } = event
            {
                seen += 1;
                activation = Some(revealed);
                mark_delivered = false;
            }
        }
        last_status = Some(format!("{:?}", result.fiber_status));
        match result.fiber_status {
            FlowFiberStatus::Running | FlowFiberStatus::Dialogue(_) => {}
            FlowFiberStatus::Done(exit) => {
                assert!(
                    deliver_mark,
                    "{backend}: an unselected non-Unit result must fail"
                );
                assert_eq!(exit, FlowExit::Done);
                assert_eq!(seen, 1);
                return (log_messages(&effects), true);
            }
            FlowFiberStatus::Failed(_) => {
                assert!(
                    !deliver_mark,
                    "{backend}: selected result failed unexpectedly"
                );
                assert_eq!(seen, 1, "{backend}: one line was revealed before failure");
                return (log_messages(&effects), false);
            }
            status => panic!("{backend}: dialogue result stopped unexpectedly: {status:?}"),
        }
    }
    panic!(
        "dialogue mark result execution exceeded its step bound: backend={backend}, seen={seen}, deliver_mark={deliver_mark}, last_status={last_status:?}"
    );
}

fn execute_dialogue_result_with_action(
    mut step: impl FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
    cancelled: bool,
    backend: &str,
    expected_lines: usize,
) -> Vec<String> {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        plan::FlowEvent,
        step::{RuntimeDialogueInputActionEvent, RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };
    use arcweft_interaction_model::input::{InputActionId, InputEpoch, InputSequence};
    let mut pending = None;
    let mut effects = Vec::new();
    let mut seen = 0;
    let mut last_status = None;
    for tick in 0..512 {
        let mut input = RuntimeStepInput {
            tick: TickId(tick),
            ..RuntimeStepInput::default()
        };
        if let Some(activation) = pending.take() {
            if cancelled {
                input
                    .dialogue_input_actions
                    .push(RuntimeDialogueInputActionEvent::new(
                        activation,
                        InputActionId::new("SkipLine").expect("valid input action"),
                        InputEpoch::new(1),
                        InputSequence::new(1),
                    ));
            } else {
                input.dialogue_advances.push(activation);
            }
        }
        let result = step(input, RuntimeStepOptions::default());
        assert!(
            result.output.diagnostics.is_empty(),
            "{:?}",
            result.output.diagnostics
        );
        effects.extend(result.output.effects.line);
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine { activation, .. } = event {
                seen += 1;
                assert!(
                    pending.replace(activation).is_none(),
                    "{backend}: two lines in one step"
                );
            }
        }
        last_status = Some(format!("{:?}", result.fiber_status));
        match result.fiber_status {
            FlowFiberStatus::Running | FlowFiberStatus::Dialogue(_) => {}
            FlowFiberStatus::Done(exit) => {
                assert_eq!(exit, FlowExit::Done);
                assert_eq!(seen, expected_lines);
                return log_messages(&effects);
            }
            status => panic!("dialogue result execution stopped unexpectedly: {status:?}"),
        }
    }
    panic!(
        "dialogue result execution exceeded its step bound: backend={backend}, seen={seen}, cancelled={cancelled}, last_status={last_status:?}"
    );
}

#[test]
fn pipe_tail_effect_has_one_operation_and_verified_awbc() {
    let compiled = compile_source(
        r#"
flow main() -> Unit {
    let message = "piped"
    message |> log.info(^)
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("pipe tail effect compiles from its expression-owned operation");
    let effects = compiled
        .plan
        .flows()
        .iter()
        .flat_map(|flow| flow.body().ops())
        .filter(|op| matches!(op, FlowOp::EvaluatedEffect(_)))
        .count();
    assert_eq!(effects, 1);
    assert_simple_flow_logs_native_and_awbc(&compiled, &["piped"]);
}

#[test]
fn source_optional_registry_reads_the_reached_flow_in_native_and_decoded_awbc() {
    let compiled = compile_source(
        r#"
flow main() -> Unit effects { state.write('flow), log.write } {
    let missing: Option<bool> = 'flow.flags.seen?
    if let .None = missing {
        log.info("absent")
    }
    'flow.flags.seen <- true
    let present: Option<bool> = 'flow.flags.seen?
    if let .Some(true) = present {
        log.info("present")
    }
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("typed optional registry reads compile through their checked value facts");
    assert_simple_flow_logs_native_and_awbc(&compiled, &["absent", "present"]);
}

#[test]
fn source_registry_reads_supply_item_types_to_generic_calls() {
    for (write, read, condition, expected) in [
        (
            "'flow.flags.seen <- true",
            "direct('flow.flags.seen)",
            "observed",
            "required",
        ),
        (
            "'flow.flags.seen <- true",
            "optional('flow.flags.seen?)",
            "let .Some(true) = observed",
            "optional",
        ),
        (
            "if false { 'flow.flags.seen <- true }",
            "optional('flow.flags.seen?)",
            "let .None = observed",
            "absent",
        ),
    ] {
        let compiled = compile_source(&format!(
            r#"
fn direct<T>(value: T) -> T {{ value }}
fn optional<T>(value: Option<T>) -> Option<T> {{ value }}
flow main() -> Unit effects {{ state.write('flow), log.write }} {{
    {write}
    let observed = {read}
    if {condition} {{
        log.info("{expected}")
    }}
}}
entry cli @entry.main {{ goto @flow.main }}
"#,
        ))
        .expect("the registry's source write supplies the generic item type");
        assert_simple_flow_logs_native_and_awbc(&compiled, &[expected]);
    }
}

#[test]
fn source_registry_drop_removes_only_the_reached_key() {
    for drop in [
        "drop('flow.flags.seen)",
        "drop_optional('flow.flags.seen?)",
        "'flow.flags.seen |> drop(^)",
        "'flow.flags.seen? |> drop_optional(^)",
        "drop(.Stop(fade = 120ms))('flow.flags.seen)",
    ] {
        let compiled = compile_source(&format!(
            r#"
flow main() -> Unit effects {{ state.write('flow), log.write }} {{
    'flow.flags.seen <- true
    'flow.flags.sibling <- "still present"
    {drop}
    let seen: Option<bool> = 'flow.flags.seen?
    if let .None = seen {{ log.info('flow.flags.sibling) }}
}}
entry cli @entry.main {{ goto @flow.main }}
"#,
        ))
        .unwrap_or_else(|error| panic!("{drop} failed to compile: {error:?}"));
        assert_simple_flow_logs_native_and_awbc(&compiled, &["still present"]);
    }
}

#[test]
fn source_optional_registry_drop_admits_an_absent_key() {
    let compiled = compile_source(
        r#"
flow main() -> Unit effects { state.write('flow), log.write } {
    if false { 'flow.flags.seen <- true }
    drop_optional('flow.flags.seen?)
    let observed: Option<bool> = 'flow.flags.seen?
    if let .None = observed { log.info("absent") }
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("the optional drop admits an absent row with a known item type");
    assert_simple_flow_logs_native_and_awbc(&compiled, &["absent"]);
}

#[test]
fn source_inferred_optional_registry_read_admits_absence_and_registration() {
    for (register, pattern, expected) in [
        (true, ".Some(true)", "present"),
        (false, ".None", "branch absent"),
    ] {
        let compiled = compile_source(&format!(
            r#"
flow main() -> Unit effects {{ state.write('flow), log.write }} {{
    if {register} {{ 'flow.flags.seen <- true }}
    let observed = 'flow.flags.seen?
    if let {pattern} = observed {{
        log.info("{expected}")
    }}
}}
entry cli @entry.main {{ goto @flow.main }}
"#,
        ))
        .expect("the conditional writer fixes the optional registry item type");
        assert_simple_flow_logs_native_and_awbc(&compiled, &[expected]);
    }
}

#[test]
fn source_required_registry_reads_use_reaching_branches_in_native_and_decoded_awbc() {
    for (flag, binding, expected) in [
        (true, "present: String", "then"),
        (false, "present: String", "else"),
        (true, "present", "then"),
        (false, "present", "else"),
    ] {
        let compiled = compile_source(&format!(
            r#"
flow main() -> Unit effects {{ state.write('flow), log.write }} {{
    if {flag} {{
        'flow.flags.seen <- "then"
    }} else {{
        'flow.flags.seen <- "else"
    }}
    let {binding} = 'flow.flags.seen
    log.info(present)
}}
entry cli @entry.main {{ goto @flow.main }}
"#,
        ))
        .expect("both reaching branches register the exact item type");
        assert_simple_flow_logs_native_and_awbc(&compiled, &[expected]);
    }
}

#[test]
fn source_optional_registry_reads_reach_the_line_and_parent_flow() {
    use arcweft_core::awbc::{
        codec::AwbcDecodeBudget,
        schema::{AwbcEntryId, AwbcProgram},
    };
    use arcweft_core::effect::RuntimeArtifactFingerprint;
    use arcweft_core::executor::ArcweftRuntimeExecutor;
    use arcweft_core::pure::VmRuntimePureCallBackend;

    let compiled = compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit effects { state.write('flow), state.write('line), log.write } {
    'flow.prior <- "parent at entry"
    let result = alice()[本文。[mark @.release][mark @.replacement_written][p]] with {
        init {
            let inherited: String = 'flow.prior
            log.info(inherited)
            let absent: Option<String> = 'line.saved?
            if let .None = absent { log.info("line absent") }
            'line.saved <- "line value"
            let present = 'line.saved
            let maybe_present = 'line.saved?
            if let .Some(value) = maybe_present {
                if value == present { log.info(present) }
            }
            'flow.saved <- "parent value"
        }
        on mark(@.release) {
            log.info("mark-handler-enter")
            let parent: Option<String> = 'flow.saved?
            if let .Some(message) = parent { log.info(message) }
            let guaranteed: String = 'line.saved
            let local: Option<String> = 'line.saved?
            if let .Some(_) = local {
                out guaranteed
            } else {
                out "unexpected absence"
            }
        }
        on mark(@.replacement_written) {
            'line.saved <- "line value"
            log.info("sibling-writer")
        }
    }
    log.info(result)
    let persisted: String = 'flow.saved
    log.info(persisted)
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("authored optional reads in the line plan compile");
    let runtime = compiled.runtime_plan();
    let program = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "registry.arcw",
    )
    .lower()
    .unwrap()
    .program;
    let bytes = program.encode_canonical().unwrap();
    let decoded = AwbcProgram::decode_canonical(&bytes, AwbcDecodeBudget::default()).unwrap();
    let [flow] = runtime.plan.flows() else {
        panic!("one Flow");
    };
    let mut plan = runtime.plan.clone();
    plan.bind_artifact(
        RuntimeArtifactFingerprint::try_from_bytes(*blake3::hash(&bytes).as_bytes()).unwrap(),
    )
    .unwrap();
    let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
    let native_schema = bind_test_character_dialogue_schema(
        &compiled,
        arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut native_backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
    );
    let mut awbc = ArcweftRuntimeExecutor::from_awbc_product(decoded, AwbcEntryId(0)).unwrap();
    let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut awbc_backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
    );
    let expected = [
        "parent at entry",
        "line absent",
        "line value",
        "mark-handler-enter",
        "parent value",
        "line value",
        "parent value",
    ];
    let marks = [0, 1].map(|ordinal| RuntimeDialogueMarkId::from_zero_based(ordinal).unwrap());
    let (mut logs, completed) = execute_dialogue_result_with_marks(
        |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
        &marks,
        "native optional registry",
    );
    assert!(completed);
    let before = logs.len();
    logs.retain(|message| message != "sibling-writer");
    assert_eq!(before, logs.len() + 1);
    assert_eq!(logs, expected);
    let (mut logs, completed) = execute_dialogue_result_with_marks(
        |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend),
        &marks,
        "decoded AWBC optional registry",
    );
    assert!(completed);
    let before = logs.len();
    logs.retain(|message| message != "sibling-writer");
    assert_eq!(before, logs.len() + 1);
    assert_eq!(logs, expected);
}

#[test]
fn source_registry_drop_during_line_cancellation_survives_awbc_restore() {
    use arcweft_core::{
        effect::RuntimeArtifactFingerprint, engine::Engine, pure::VmRuntimePureCallBackend,
        task::RuntimeProgramOwner,
    };

    let source = r#"
pub character alice { display = "Alice" }
flow main() -> Unit effects { state.write('flow), state.write('line), log.write } {
    'flow.saved <- true
    let result = alice()[本文。[p]] with {
        init { 'line.saved <- true }
        cancel on input(.SkipLine) {
            drop_optional('line.saved?)
            let line_saved: Option<bool> = 'line.saved?
            if let .None = line_saved { log.info("line removed") }
            drop_optional('flow.saved?)
            out "cancelled"
        }
        out "completed"
    }
    log.info(result)
    let flow_saved: Option<bool> = 'flow.saved?
    if let .None = flow_saved { log.info("flow removed") }
}
entry cli @entry.main { goto @flow.main }
"#;
    let (compiled, awbc) = compile_nested_awbc(source);
    let runtime = compiled.runtime_plan();
    let [flow] = runtime.plan.flows() else {
        panic!("one executable Flow");
    };
    let mut plan = runtime.plan.clone();
    plan.bind_artifact(
        RuntimeArtifactFingerprint::try_from_bytes(*blake3::hash(source.as_bytes()).as_bytes())
            .unwrap(),
    )
    .unwrap();
    let mut native = Engine::for_flow(plan, &flow.id).unwrap();
    let native_schema = bind_test_character_dialogue_schema(
        &compiled,
        RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut native_backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
    );
    let native_logs = execute_dialogue_result_with_action(
        |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
        true,
        "Native registry drop on cancellation",
        1,
    );

    let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut awbc_backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
    );
    let mut awbc = Some(awbc);
    let awbc_logs = execute_dialogue_result_with_action(
        |input, options| {
            let mut current = awbc.take().unwrap();
            let result = current.step_with_pure_backend(input, options, &mut awbc_backend);
            awbc = Some(roundtrip_nested_awbc(current).0);
            result
        },
        true,
        "decoded AWBC registry drop on cancellation",
        1,
    );
    assert_eq!(native_logs, ["line removed", "cancelled", "flow removed"]);
    assert_eq!(awbc_logs, native_logs);
}

const NESTED_LINE_REGISTRY_SOURCE: &str = r#"
pub character alice { display = "Alice" }
flow main() -> Unit effects { state.write('flow), state.write('line), log.write } {
    alice()[Outer[p]] with {
        init {
            'line.saved <- "outer"
            let received: String = alice()[Inner[p]] with {
                init {
                    'line.saved <- true
                    'flow.shared <- "updated by inner"
                    let inner: bool = 'line.saved
                    if inner { log.info("inner") }
                }
                out "returned by inner"
            }
            log.info(received)
            let outer: String = 'line.saved
            log.info(outer)
        }
    }
    let shared: String = 'flow.shared
    log.info(shared)
}
entry cli @entry.main { goto @flow.main }
"#;

#[test]
fn source_analysis_separates_nested_line_registrations_and_keeps_flow_writes() {
    use arcweft_core::effect::RuntimeRegistryReadKind::Required;
    use arcweft_lang_sema::{final_analysis::CheckedValueResolution, types::TypeKind};

    let analysis = with_attached_dialogue_project(NESTED_LINE_REGISTRY_SOURCE, analyze_project)
        .expect("separate Line registries and shared Flow writes prove the required reads");
    let reads: Vec<_> = analysis
        .final_analysis()
        .expressions()
        .filter_map(|(_, expression)| {
            let CheckedExpressionResolution::Value(CheckedValueResolution::RegistryRead(read)) =
                expression.resolution()
            else {
                return None;
            };
            assert_eq!(read.kind(), Required);
            let [segment] = read.key().segments() else {
                panic!("one registry key segment");
            };
            Some((
                read.key().scope().as_str(),
                segment.as_str(),
                expression.value_type(),
            ))
        })
        .collect();
    assert_eq!(reads.len(), 3, "{reads:?}");
    assert!(reads.contains(&("line", "saved", Some(&TypeKind::Bool))));
    assert!(reads.contains(&("line", "saved", Some(&TypeKind::String))));
    assert!(reads.contains(&("flow", "shared", Some(&TypeKind::String))));
}

#[test]
fn native_nested_line_registries_resume_their_parent_line_and_share_the_flow() {
    use arcweft_core::{
        effect::RuntimeArtifactFingerprint, engine::Engine, pure::VmRuntimePureCallBackend,
        task::RuntimeProgramOwner,
    };

    let compiled = compile_attached_dialogue_project(NESTED_LINE_REGISTRY_SOURCE)
        .expect("RuntimePlan registers both dialogue content handles");
    let runtime = compiled.runtime_plan();
    let [flow] = runtime.plan.flows() else {
        panic!("one executable Flow");
    };
    let mut plan = runtime.plan.clone();
    let fixture_artifact = blake3::hash(NESTED_LINE_REGISTRY_SOURCE.as_bytes());
    plan.bind_artifact(
        RuntimeArtifactFingerprint::try_from_bytes(*fixture_artifact.as_bytes()).unwrap(),
    )
    .unwrap();
    let mut native = Engine::for_flow(plan, &flow.id).unwrap();
    let schema = bind_test_character_dialogue_schema(
        &compiled,
        RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    assert_eq!(
        execute_dialogue_result_with_action(
            |input, options| native.step_with_pure_backend(input, options, &mut backend),
            false,
            "Native nested registry",
            2,
        ),
        ["inner", "returned by inner", "outer", "updated by inner"],
    );
}

fn compile_nested_awbc(
    source: &str,
) -> (
    CompiledProject,
    arcweft_core::executor::ArcweftRuntimeExecutor,
) {
    nested_awbc_from_compiled(compile_attached_dialogue_project(source).unwrap())
}

fn nested_awbc_from_compiled(
    compiled: CompiledProject,
) -> (
    CompiledProject,
    arcweft_core::executor::ArcweftRuntimeExecutor,
) {
    use arcweft_core::{
        awbc::{
            codec::AwbcDecodeBudget,
            schema::{AwbcEntryId, AwbcProgram},
        },
        executor::ArcweftRuntimeExecutor,
    };

    let runtime = compiled.runtime_plan();
    let bytes = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "nested_registry.arcw",
    )
    .lower()
    .expect("AWBC resolves both dialogue groups and their captures")
    .program
    .encode_canonical()
    .unwrap();
    let decoded = AwbcProgram::decode_canonical(&bytes, AwbcDecodeBudget::default()).unwrap();
    assert_eq!(decoded.encode_canonical().unwrap(), bytes);
    let awbc = ArcweftRuntimeExecutor::from_awbc_product(decoded, AwbcEntryId(0)).unwrap();
    (compiled, awbc)
}

fn roundtrip_nested_awbc(
    executor: arcweft_core::executor::ArcweftRuntimeExecutor,
) -> (arcweft_core::executor::ArcweftRuntimeExecutor, usize) {
    roundtrip_nested_awbc_checking(executor, |executor, _| executor)
}

fn roundtrip_nested_awbc_checking(
    executor: arcweft_core::executor::ArcweftRuntimeExecutor,
    check: impl FnOnce(
        arcweft_core::executor::ArcweftRuntimeExecutor,
        &serde_json::Value,
    ) -> arcweft_core::executor::ArcweftRuntimeExecutor,
) -> (arcweft_core::executor::ArcweftRuntimeExecutor, usize) {
    use arcweft_core::{
        awbc::product_step::AwbcProductExecutorSaveSnapshot,
        executor::ArcweftRuntimeExecutorSnapshot,
    };

    let ArcweftRuntimeExecutorSnapshot::AwbcProduct(snapshot) = executor.snapshot().unwrap();
    let saved = AwbcProductExecutorSaveSnapshot::from_live(
        &snapshot,
        executor.admitted_product_awbc_program().unwrap(),
    )
    .unwrap();
    let bytes = serde_json::to_vec(&saved).unwrap();
    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    let active = value["dialogues"]["entries"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|entry| entry.get("Active").is_some())
        .count();
    let executor = check(executor, &value);
    let decoded = serde_json::from_slice(&bytes).unwrap();
    let decoded = executor.bind_product_save_snapshot(decoded).unwrap();
    let restored = executor
        .restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(decoded))
        .unwrap();
    (restored, active)
}

#[test]
fn decoded_awbc_nested_line_registries_resume_their_parent_through_each_save() {
    use arcweft_core::pure::VmRuntimePureCallBackend;

    let (compiled, awbc) = compile_nested_awbc(NESTED_LINE_REGISTRY_SOURCE);
    let schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut awbc = Some(awbc);
    let mut saved_nested_session = false;
    let logs = execute_dialogue_result_with_action(
        |input, options| {
            let mut current = awbc.take().unwrap();
            let result = current.step_with_pure_backend(input, options, &mut backend);
            let (restored, active) = roundtrip_nested_awbc(current);
            saved_nested_session |= active == 2;
            awbc = Some(restored);
            result
        },
        false,
        "decoded AWBC nested registry",
        2,
    );
    assert!(
        saved_nested_session,
        "a published save contained both active dialogues"
    );
    assert_eq!(
        logs,
        ["inner", "returned by inner", "outer", "updated by inner"]
    );
}

const NESTED_LINE_HANDLE_SOURCE: &str = r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice()[Outer[p]] with {
        init {
            let actor = alice()[Inner[p]] with {
                let lease = alice.stage.acquire(scope=line)
                out lease
            }
            let moved = actor
            let cue = moved.look(.normal)
            let _ = cue
            let _ = moved
            log.info("parent consumed the child handle")
        }
    }
}
entry cli @entry.main { goto @flow.main }
"#;

const NESTED_LINE_HANDLE_REEXPORT_SOURCE: &str = r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice()[Outer[p]] with {
        init {
            let actor = alice()[Middle[p]] with {
                let received = alice()[Inner[p]] with {
                    let lease = alice.stage.acquire(scope=line)
                    out lease
                }
                out received
            }
            let moved = actor
            let cue = moved.look(.normal)
            let _ = cue
            let _ = moved
            log.info("parent consumed the child handle")
        }
    }
}
entry cli @entry.main { goto @flow.main }
"#;

const LINE_HANDLE_CHARACTER_MANIFEST: &str = r#"{
  "format": "arcweft.character",
  "version": 1,
  "character": "character.alice",
  "canvas": { "width": 64, "height": 128 },
  "anchor": { "x": 32, "y": 128 },
  "default_look": "normal",
  "parts": [{
    "id": "body",
    "z": 0,
    "variants": [{
      "id": "default",
      "asset": "layers/body.png",
      "rect": { "x": 0, "y": 0, "width": 64, "height": 128 },
      "opacity": 255,
      "blend": "normal",
      "clipping": false
    }]
  }],
  "looks": [{ "id": "normal", "select": [{ "part": "body", "variant": "default" }] }]
}"#;

fn execute_nested_line_handle_transfer(
    expected_lines: usize,
    mut step: impl FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
) {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        plan::FlowEvent,
        presentation::{
            RuntimeLineHostCommand, RuntimeLineHostOutcome, RuntimeStageCommand,
            RuntimeStageCommandOutcome,
        },
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };

    let mut input = RuntimeStepInput::default();
    let mut actor = None;
    let mut look_cue = None;
    let mut cancelled_cue = false;
    let mut released = false;
    let mut lines = Vec::new();
    let mut effects = Vec::new();
    for tick in 0..512 {
        input.tick = TickId(tick);
        let result = step(std::mem::take(&mut input), RuntimeStepOptions::default());
        assert!(
            result.output.diagnostics.is_empty(),
            "tick {tick}: {:?}",
            result.output.diagnostics
        );
        effects.extend(result.output.effects.line);
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine { activation, .. } = event {
                input.dialogue_advances.push(activation);
                lines.push(activation);
            }
        }
        for command in result.output.requests.line_commands {
            let outcome = match command {
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::AcquireActor {
                    command,
                    actor: token,
                    ..
                }) => {
                    assert_eq!(token.activation(), command.activation());
                    assert!(actor.replace(token.clone()).is_none());
                    RuntimeStageCommandOutcome::Acquired {
                        command,
                        actor: token,
                    }
                }
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::SetCharacterLook {
                    command,
                    actor: borrowed,
                    cue,
                    look,
                    ..
                }) => {
                    assert_eq!(actor.as_ref(), Some(&borrowed));
                    assert_eq!(cue.activation(), command.activation());
                    assert_ne!(borrowed.activation(), command.activation());
                    assert_eq!(look.as_str(), "normal");
                    assert!(look_cue.replace(cue.clone()).is_none());
                    RuntimeStageCommandOutcome::Accepted { command, cue }
                }
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::CancelCue { command, cue }) => {
                    assert_eq!(look_cue.as_ref(), Some(&cue));
                    assert_eq!(cue.activation(), command.activation());
                    assert!(!cancelled_cue);
                    cancelled_cue = true;
                    RuntimeStageCommandOutcome::Cancelled { command, cue }
                }
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::ReleaseActor {
                    command,
                    actor: token,
                }) => {
                    assert_eq!(token.activation(), command.activation());
                    assert_eq!(actor.as_ref(), Some(&token));
                    assert!(!released);
                    released = true;
                    RuntimeStageCommandOutcome::ReleasedActor {
                        command,
                        actor: token,
                    }
                }
                other => panic!("unexpected line command: {other:?}"),
            };
            input
                .line_outcomes
                .push(RuntimeLineHostOutcome::Stage(outcome));
        }
        match result.fiber_status {
            FlowFiberStatus::Dialogue(_) | FlowFiberStatus::Running => {}
            FlowFiberStatus::Done(FlowExit::Done) if input.line_outcomes.is_empty() => {
                assert_eq!(lines.len(), expected_lines, "revealed lines: {lines:?}");
                assert_eq!(
                    lines
                        .iter()
                        .collect::<std::collections::BTreeSet<_>>()
                        .len(),
                    expected_lines,
                    "each nested line reveals once"
                );
                assert_eq!(actor.unwrap().activation(), lines.first().unwrap());
                assert_eq!(look_cue.unwrap().activation(), lines.last().unwrap());
                assert!(cancelled_cue);
                assert!(released);
                assert_eq!(log_messages(&effects), ["parent consumed the child handle"]);
                return;
            }
            FlowFiberStatus::Done(FlowExit::Done) => {}
            status => panic!("nested line handle stopped at tick {tick}: {status:?}"),
        }
    }
    panic!("nested line handle transfer did not finish");
}

#[test]
fn native_nested_line_handle_moves_into_the_receiving_activation() {
    native_nested_line_handle_transfer(NESTED_LINE_HANDLE_SOURCE, 2);
}

#[test]
fn native_nested_line_handle_reexports_from_receiving_activation() {
    native_nested_line_handle_transfer(NESTED_LINE_HANDLE_REEXPORT_SOURCE, 3);
}

fn native_nested_line_handle_transfer(source: &str, expected_lines: usize) {
    use arcweft_core::{
        effect::RuntimeArtifactFingerprint, engine::Engine, pure::VmRuntimePureCallBackend,
        task::RuntimeProgramOwner,
    };

    let compiled = with_attached_dialogue_project_and_visual(
        source,
        Some(LINE_HANDLE_CHARACTER_MANIFEST),
        compile_project,
    )
    .unwrap();
    let mut plan = compiled.runtime_plan().plan.clone();
    let flow = plan.flows()[0].id.clone();
    let artifact = blake3::hash(source.as_bytes());
    plan.bind_artifact(RuntimeArtifactFingerprint::try_from_bytes(*artifact.as_bytes()).unwrap())
        .unwrap();
    let mut native = Engine::for_flow(plan, &flow).unwrap();
    let schema = bind_test_character_dialogue_schema(
        &compiled,
        RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    execute_nested_line_handle_transfer(expected_lines, |input, options| {
        native.step_with_pure_backend(input, options, &mut backend)
    });
}

#[test]
fn decoded_awbc_nested_line_handle_moves_through_save() {
    decoded_awbc_nested_line_handle_transfer(NESTED_LINE_HANDLE_SOURCE, 2);
}

#[test]
fn decoded_awbc_nested_line_handle_reexports_through_save() {
    decoded_awbc_nested_line_handle_transfer(NESTED_LINE_HANDLE_REEXPORT_SOURCE, 3);
}

fn decoded_awbc_nested_line_handle_transfer(source: &str, expected_lines: usize) {
    use arcweft_core::{
        awbc::product_step::AwbcProductExecutorSaveSnapshot,
        executor::ArcweftRuntimeExecutorSnapshot, pure::VmRuntimePureCallBackend,
    };

    let (compiled, awbc) = nested_awbc_from_compiled(
        with_attached_dialogue_project_and_visual(
            source,
            Some(LINE_HANDLE_CHARACTER_MANIFEST),
            compile_project,
        )
        .unwrap(),
    );
    let schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut awbc = Some(awbc);
    let mut checked_published_lease = false;
    let mut checked_pending_look = false;
    let mut checked_reexported_lease = source != NESTED_LINE_HANDLE_REEXPORT_SOURCE;
    execute_nested_line_handle_transfer(expected_lines, |input, options| {
        let mut current = awbc.take().unwrap();
        let result = current.step_with_pure_backend(input, options, &mut backend);
        let (restored, _) = roundtrip_nested_awbc_checking(current, |executor, save| {
            let mut executor = executor;
            if !checked_pending_look {
                let mut forged = save.clone();
                let look = forged["dialogues"]["entries"]
                    .as_array_mut()
                    .unwrap()
                    .iter_mut()
                    .filter_map(|entry| {
                        entry
                            .pointer_mut("/Active/line/issued_commands")?
                            .as_object_mut()
                    })
                    .flat_map(serde_json::Map::values_mut)
                    .map(|row| &mut row["command"])
                    .find(|command| command["kind"] == "set_character_look");
                if let Some(look) = look {
                    let issuance = &mut look["actor"]["issuance"];
                    *issuance = (issuance.as_u64().unwrap() + 1).into();
                    let bad = serde_json::from_value::<AwbcProductExecutorSaveSnapshot>(forged)
                        .expect("the foreign actor still has a well-formed token");
                    let bad = executor.bind_product_save_snapshot(bad).unwrap();
                    let Err(rejected) =
                        executor.restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(bad))
                    else {
                        panic!("the pending look must refer to the exact borrowed actor");
                    };
                    let (unchanged, error) = rejected.into_parts();
                    assert!(
                        error.to_string().contains("dialogue command journal"),
                        "{error}"
                    );
                    executor = unchanged;
                    checked_pending_look = true;
                }
            }
            if !checked_reexported_lease {
                let mut forged = save.clone();
                let result_slot = forged["dialogues"]["entries"]
                    .as_array_mut()
                    .unwrap()
                    .iter_mut()
                    .filter_map(|entry| {
                        entry
                            .pointer_mut("/PublishedHandles/handles/ledger/leases")?
                            .as_object_mut()
                    })
                    .flat_map(serde_json::Map::values_mut)
                    .find_map(|lease| lease.pointer_mut("/owner/ReceivedDialogueResult/path"));
                if let Some(path) = result_slot {
                    assert_eq!(*path, serde_json::json!([]));
                    *path = serde_json::json!([{"kind":"tuple_element","index":0}]);
                    let bad = serde_json::from_value::<AwbcProductExecutorSaveSnapshot>(forged)
                        .expect("the replacement path is well-formed");
                    let bad = executor.bind_product_save_snapshot(bad).unwrap();
                    let Err(rejected) =
                        executor.restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(bad))
                    else {
                        panic!("the issuer's result slot must match the receiver's value path");
                    };
                    let (unchanged, error) = rejected.into_parts();
                    assert!(
                        error.to_string().contains("restored dialogue result"),
                        "{error}"
                    );
                    executor = unchanged;
                    checked_reexported_lease = true;
                }
            }
            if checked_published_lease {
                return executor;
            }
            let Some(index) = save["dialogues"]["entries"]
                .as_array()
                .unwrap()
                .iter()
                .position(|entry| entry.get("PublishedHandles").is_some())
            else {
                return executor;
            };
            let mut forged = save.clone();
            let leases = forged["dialogues"]["entries"][index]["PublishedHandles"]["handles"]
                ["ledger"]["leases"].as_object_mut().unwrap();
            let key = leases.keys().next().cloned().expect("published lease key");
            let mut lease = leases.remove(&key).expect("published lease row");
            leases.insert("other".to_owned(), lease.clone());
            let error = serde_json::from_value::<AwbcProductExecutorSaveSnapshot>(forged.clone())
                .expect_err("the lease key must agree with the typed token");
            assert!(error.to_string().contains("identity differs"), "{error}");
            let leases = forged["dialogues"]["entries"][index]["PublishedHandles"]["handles"]
                ["ledger"]["leases"].as_object_mut().unwrap();
            leases.remove("other");
            let slot = &mut lease["owner"]["ParentFiber"];
            assert_eq!(slot["kind"], "awbc_register");
            slot["register"] = (slot["register"].as_u64().unwrap() + 1).into();
            leases.insert(key, lease);
            let bad: AwbcProductExecutorSaveSnapshot = serde_json::from_value(forged).unwrap();
            let bad = executor.bind_product_save_snapshot(bad).unwrap();
            let Err(rejected) =
                executor.restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(bad))
            else {
                panic!("a published handle cannot name a different receiver slot");
            };
            let (executor, error) = rejected.into_parts();
            assert!(
                error.to_string().contains("owned by another runtime slot"),
                "{error}"
            );
            checked_published_lease = true;
            executor
        });
        awbc = Some(restored);
        result
    });
    assert!(
        checked_published_lease,
        "a live published lease crossed the public save boundary"
    );
    assert!(
        checked_pending_look,
        "a pending look crossed the public save boundary"
    );
    assert!(
        checked_reexported_lease,
        "the original issuer's forwarded lease crossed the public save boundary"
    );
}

#[test]
fn decoded_awbc_dialogue_result_wildcard_survives_pending_release() {
    assert_decoded_awbc_dialogue_result_wildcard(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    let (keep, _) = alice()[Discard[p]] with {
        let first = alice.stage.acquire(scope=line)
        let second = alice.stage.acquire(scope=line)
        out (first, second)
    }
    log.info("caller resumed after release")
    let _ = keep
}
entry cli @entry.main { goto @flow.main }
"#,
    );
}

#[test]
fn decoded_awbc_reexported_result_wildcard_waits_for_issuer_release() {
    assert_decoded_awbc_dialogue_result_wildcard(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    let (keep, _) = alice()[Discard[p]] with {
        let pair = alice()[Issuer[p]] with {
            let first = alice.stage.acquire(scope=line)
            let second = alice.stage.acquire(scope=line)
            out (first, second)
        }
        out pair
    }
    log.info("caller resumed after release")
    let _ = keep
}
entry cli @entry.main { goto @flow.main }
"#,
    );
}

fn assert_decoded_awbc_dialogue_result_wildcard(source: &str) {
    use arcweft_core::{
        awbc::product_step::AwbcProductExecutorSaveSnapshot,
        engine::{FlowExit, FlowFiberStatus},
        executor::ArcweftRuntimeExecutorSnapshot,
        plan::FlowEvent,
        presentation::{
            RuntimeLineHostCommand, RuntimeLineHostOutcome, RuntimeStageCommand,
            RuntimeStageCommandOutcome,
        },
        pure::VmRuntimePureCallBackend,
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };

    let (compiled, mut awbc) = compile_nested_awbc(source);
    let schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut input = RuntimeStepInput::default();
    let mut acquired = Vec::new();
    let mut released = Vec::new();
    let mut release = None;
    let mut pending_saved = 0;
    let mut tampered = false;
    let mut effects = Vec::new();
    for tick in 0..128 {
        input.tick = TickId(tick);
        if release.as_ref().is_some_and(|(due, _)| tick == *due) {
            input.line_outcomes.push(release.take().unwrap().1);
        }
        let result = awbc.step_with_pure_backend(
            std::mem::take(&mut input),
            RuntimeStepOptions::default(),
            &mut backend,
        );
        assert!(
            result.output.diagnostics.is_empty(),
            "{:?}",
            result.output.diagnostics
        );
        effects.extend(result.output.effects.line);
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine { activation, .. } = event {
                input.dialogue_advances.push(activation);
            }
        }
        for request in result.output.requests.line_commands {
            match request {
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::AcquireActor {
                    command,
                    actor,
                    ..
                }) => {
                    assert!(acquired.len() < 2 && !acquired.contains(&actor));
                    acquired.push(actor.clone());
                    input.line_outcomes.push(RuntimeLineHostOutcome::Stage(
                        RuntimeStageCommandOutcome::Acquired { command, actor },
                    ));
                }
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::ReleaseActor {
                    command,
                    actor,
                }) => {
                    assert_eq!(acquired.len(), 2);
                    let index = match released.len() {
                        0 => 1,
                        1 => 0,
                        _ => panic!("duplicate release"),
                    };
                    assert_eq!(actor, acquired[index]);
                    assert_eq!(command.activation(), actor.activation());
                    released.push(actor.clone());
                    let outcome =
                        RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::ReleasedActor {
                            command,
                            actor,
                        });
                    assert!(
                        release
                            .replace((tick + if index == 1 { 2 } else { 1 }, outcome))
                            .is_none()
                    );
                }
                other => panic!("unexpected dialogue command: {other:?}"),
            }
        }
        let publication_pending = released.len() == 1 && release.is_some();
        (awbc, _) = roundtrip_nested_awbc_checking(awbc, |executor, save| {
            if !publication_pending {
                return executor;
            }
            let mut forged = save.clone();
            let entries = forged["dialogues"]["entries"].as_array_mut().unwrap();
            assert!(
                entries
                    .iter()
                    .any(|entry| entry.pointer("/Active/line/result/Publishing").is_some()),
                "the result remains publishing during release"
            );
            pending_saved += 1;
            if tampered {
                return executor;
            }
            let kept = serde_json::to_value(&acquired[0]).unwrap();
            let discarded = serde_json::to_value(&acquired[1]).unwrap();
            let issuer = entries
                .iter_mut()
                .filter_map(|entry| {
                    let path = if entry.get("Active").is_some() {
                        "/Active/line"
                    } else {
                        "/PublishedHandles/handles"
                    };
                    entry.pointer_mut(path)
                })
                .find(|line| {
                    line["ledger"]["leases"].as_object().is_some_and(|leases| {
                        leases.values().any(|lease| lease["token"] == discarded)
                    })
                })
                .expect("the discarded handle stays in its issuer's ledger");
            let leases = issuer["ledger"]["leases"].as_object_mut().unwrap();
            for lease in leases.values_mut() {
                if lease["token"] == kept {
                    assert_eq!(lease["state"], "active");
                    lease["state"] = "cancelling".into();
                } else if lease["token"] == discarded {
                    assert_eq!(lease["state"], "cancelling");
                    lease["state"] = "active".into();
                }
            }
            let issued = issuer["issued_commands"]
                .as_object_mut()
                .unwrap()
                .values_mut()
                .map(|row| &mut row["command"])
                .find(|command| command["kind"] == "release_actor")
                .expect("the original release command is outstanding");
            assert_eq!(issued["actor"], discarded);
            issued["actor"] = kept;
            let forged = serde_json::from_value::<AwbcProductExecutorSaveSnapshot>(forged).unwrap();
            let forged = executor.bind_product_save_snapshot(forged).unwrap();
            let Err(rejected) =
                executor.restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(forged))
            else {
                panic!("a release cannot retire a handle bound by the original pattern");
            };
            let (executor, error) = rejected.into_parts();
            assert!(
                error.to_string().contains("restored dialogue result"),
                "{error}"
            );
            tampered = true;
            executor
        });
        if publication_pending {
            assert!(
                log_messages(&effects).is_empty(),
                "caller resumed before publication's release was acknowledged"
            );
        }
        match result.fiber_status {
            FlowFiberStatus::Dialogue(_) | FlowFiberStatus::Running => {}
            FlowFiberStatus::Done(FlowExit::Done) if release.is_none() => {
                assert_eq!(released, [acquired[1].clone(), acquired[0].clone()]);
                assert_eq!(pending_saved, 2);
                assert!(tampered);
                assert_eq!(log_messages(&effects), ["caller resumed after release"]);
                return;
            }
            FlowFiberStatus::Done(FlowExit::Done) => {}
            status => panic!("wildcard dialogue stopped at tick {tick}: {status:?}"),
        }
    }
    panic!("dialogue wildcard release did not finish");
}

#[test]
fn decoded_awbc_nested_dialogue_failure_closes_both_activations_through_save() {
    use arcweft_core::{
        engine::FlowFiberStatus,
        pure::VmRuntimePureCallBackend,
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };

    let (compiled, mut awbc) = compile_nested_awbc(
        r#"
pub character alice { display = "Alice" }
fn quotient(divisor: i64) -> i64 { 1i64 / divisor }
flow main() -> Unit {
    alice()[Outer[p]] with {
        init {
            alice()[Inner[p]] with {
                init {
                    let failed = quotient(0i64)
                    log.info("continued inner")
                }
            }
            log.info("continued outer")
        }
    }
    log.info("continued flow")
}
entry cli @entry.main { goto @flow.main }
"#,
    );
    let schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut saved_nested_session = false;
    let mut last_status = None;
    for tick in 0..512 {
        let result = awbc.step_with_pure_backend(
            RuntimeStepInput {
                tick: TickId(tick),
                ..RuntimeStepInput::default()
            },
            RuntimeStepOptions::default(),
            &mut backend,
        );
        assert!(log_messages(&result.output.effects.line).is_empty());
        let (restored, active) = roundtrip_nested_awbc(awbc);
        awbc = restored;
        saved_nested_session |= active == 2;
        last_status = Some((format!("{:?}", result.fiber_status), active));
        match result.fiber_status {
            FlowFiberStatus::Failed(message) => {
                assert!(message.to_lowercase().contains("zero"), "{message}");
                assert!(saved_nested_session);
                assert_eq!(active, 0);
                return;
            }
            FlowFiberStatus::Dialogue(_) | FlowFiberStatus::Running => {}
            status => panic!("nested failure stopped in {status:?}"),
        }
    }
    panic!("nested failure did not unwind to the entry fiber: {last_status:?}");
}

#[test]
fn source_nested_line_registration_cannot_prove_a_parent_read() {
    use arcweft_lang_sema::final_analysis::{CheckedLocalUseError, FinalSemanticAnalysisError};

    let error = with_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit effects { state.write('line), log.write } {
    alice()[Outer[p]] with {
        init {
            alice()[Inner[p]] with { init { 'line.saved <- "inner" } }
            let missing: String = 'line.saved
            log.info(missing)
        }
    }
}
entry cli @entry.main { goto @flow.main }
"#,
        analyze_project,
    )
    .err()
    .expect("the parent Line has no registration");
    assert!(
        matches!(
            error.semantic_error(),
            Some(FinalSemanticAnalysisError::LocalUse(
                CheckedLocalUseError::RegistryRegistrationUnavailable { .. }
            ))
        ),
        "{error:?}"
    );
}

#[test]
fn source_required_registry_reads_reject_a_shared_handler_write_as_type_evidence() {
    use arcweft_lang_sema::final_analysis::{CheckedLocalUseError, FinalSemanticAnalysisError};

    for (first, second) in [("'line.saved <- \"first\"", "true"), ("", "\"second\"")] {
        let error = compile_attached_dialogue_project(&format!(
            r#"
pub character alice {{ display = "Alice" }}
flow main() -> Unit effects {{ state.write('line), log.write }} {{
    alice()[本文。[mark @.first][mark @.second][p]] with {{
        on mark(@.first) {{
            {first}
            let present: String = 'line.saved
            log.info(present)
        }}
        on mark(@.second) {{
            'line.saved <- {second}
        }}
    }}
}}
entry cli @entry.main {{ goto @flow.main }}
"#,
        ))
        .err()
        .expect("the sibling may replace the item with a different type or never register it");
        assert!(
            matches!(
                error.semantic_error(),
                Some(FinalSemanticAnalysisError::LocalUse(
                    CheckedLocalUseError::RegistryRegistrationUnavailable { .. }
                ))
            ),
            "{error:?}",
        );
    }
}

#[test]
fn source_inferred_optional_registry_read_accepts_a_possible_sibling_write() {
    compile_attached_dialogue_project(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit effects { state.write('line), log.write } {
    alice()[本文。[mark @.first][mark @.second][p]] with {
        on mark(@.first) {
            'line.saved <- true
        }
        on mark(@.second) {
            let observed = 'line.saved?
            if let .Some(true) = observed { log.info("present") }
        }
    }
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("a compatible sibling can contribute possible presence");
}

#[test]
fn project_function_effect_tails_have_one_closed_operation() {
    for tail in ["log.info(message)", "message |> log.info(^)"] {
        let compiled = compile_source(&format!(
            r#"
fn emit(message: String) -> Unit {{ {tail} }}
flow main() -> Unit {{ emit("piped"); }}
entry cli @entry.main {{ goto @flow.main }}
"#,
        ))
        .expect("project function effect tail has one closed operation");
        let effects = compiled
            .plan
            .function_sites()
            .iter()
            .filter_map(|site| match site.body() {
                RuntimeFunctionSiteBody::Executable(body) => Some(body.ops()),
                RuntimeFunctionSiteBody::Expression(_) => None,
            })
            .flatten()
            .filter(|op| matches!(op, FlowOp::EvaluatedEffect(_)))
            .count();
        assert_eq!(effects, 1, "{tail}");
        assert_simple_flow_logs_native_and_awbc(&compiled, &["piped"]);
    }
}

#[test]
fn statement_match_expression_effect_arms_preserve_native_awbc_effects() {
    let compiled = compile_source(
        r#"
flow main() -> Unit {
    let maybe: Option<i32> = .Some(7i32)
    match maybe {
        .Some(value) => log.info("some")
        .None => log.info("none")
    }
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("statement Match expression arms retain their checked effect disposition");

    assert_simple_flow_logs_native_and_awbc(&compiled, &["some"]);
}

#[test]
fn statement_match_pure_value_arms_are_discarded_in_native_and_awbc() {
    let compiled = compile_source(
        r#"
flow main() -> Unit {
    let maybe: Option<i32> = .Some(7i32)
    match maybe {
        .Some(value) => value + 1i32
        .None => 0i32
    }
    log.info("after")
}
entry cli @entry.main { goto @flow.main }
"#,
    )
    .expect("statement Match expression arms discard their pure values");

    assert_simple_flow_logs_native_and_awbc(&compiled, &["after"]);
}

#[test]
fn project_inline_record_enum_pattern_binds_fields_in_native_and_decoded_awbc() {
    use arcweft_core::{
        awbc::{
            product_step::AwbcProductStepExecutor,
            schema::{
                AwbcEntry, AwbcEntryId, AwbcEntryKind, AwbcEntryTarget, AwbcFlowExecutable,
                AwbcProgram, AwbcStringId,
            },
        },
        engine::{Engine, FlowExit, FlowFiberStatus},
        entry::{
            EntryBindingIdentity, FlowContractHash, FlowParameterCoordinate, RuntimeFlowExecutable,
            RuntimeSchemaLimits,
        },
        plan::RuntimePlanTypeProjection,
        program_types::RuntimeProgramTypes,
        pure::VmRuntimePureCallBackend,
        step::{RuntimeStepInput, RuntimeStepOptions, RuntimeStepResult},
        time::TickId,
        value::{RuntimeFlowParameterBinding, RuntimeValue},
    };
    use arcweft_runtime_plan::awbc_lower::AwbcLowerOptions;

    let compiled = compile_source(
        r#"
enum GameEvent {
    ChoiceSelected { id: i32 },
}

flow main(event: GameEvent) -> Unit {
    match event {
        .ChoiceSelected { id } => log.info("selected", id = id)
    }
}
"#,
    )
    .expect("inline-record enum pattern has an executable project Flow");
    let [flow] = compiled.plan.flows() else {
        panic!("one parameterized Flow")
    };
    let schema = compiled
        .plan
        .flow_schemas()
        .iter()
        .find(|schema| schema.flow == flow.id)
        .expect("the Flow owns a checked positional input ABI");
    assert_eq!(schema.parameters.len(), 1);
    let event_semantic_type = schema.parameters[0].semantic_identity;
    let event_type = compiled
        .plan
        .type_table()
        .id_for_semantic(event_semantic_type)
        .expect("the Flow input resolves to its exact project enum type row");
    let event_declaration = compiled
        .plan
        .type_table()
        .get(event_type)
        .expect("the Flow input row belongs to the plan type table");
    assert!(matches!(
        event_declaration.projection(),
        RuntimePlanTypeProjection::Nominal { .. }
    ));
    let domain = compiled
        .plan
        .variant_domains()
        .get(event_type)
        .expect("GameEvent retains its exact source-ordered variant domain");
    let (ordinal, choice_case) = domain
        .cases()
        .iter()
        .enumerate()
        .find(|(_, case)| case.name() == "ChoiceSelected")
        .expect("GameEvent includes ChoiceSelected");
    let payload_type = choice_case
        .payload()
        .expect("ChoiceSelected has its authored inline record payload");
    let payload_semantic_type = compiled
        .plan
        .type_table()
        .get(payload_type)
        .expect("the case payload is present in the selected type graph")
        .semantic_identity();
    let types = RuntimeProgramTypes::Plan(&compiled.plan);
    let payload = types
        .try_record_value(
            payload_semantic_type,
            vec![RuntimeValue::i32(42)],
            RuntimeSchemaLimits::engine_default(),
        )
        .expect("the project inline record is built under its accepted plan schema");
    let event = types
        .try_variant_value(
            event_semantic_type,
            u32::try_from(ordinal).expect("case ordinal fits the runtime domain"),
            Some(payload),
            RuntimeSchemaLimits::engine_default(),
        )
        .expect("the supplied event is admitted by the exact project enum schema");
    let parameter = RuntimeFlowParameterBinding {
        parameter: FlowParameterCoordinate::from_position(0),
        value: event,
    };

    let invocation = compiled
        .plan
        .clone()
        .seal_flow_invocation(flow.id.clone(), [parameter.clone()])
        .expect("the native input is sealed against the checked Flow ABI");
    let mut native = Engine::for_flow_invocation(invocation).expect("native Flow starts");

    // RuntimePlan deliberately has no direct launch target for parameterized
    // Flows. Add a test entry to the decoded Product artifact so the same
    // checked Flow ABI can be exercised without inventing a source constructor.
    let mut product = AwbcLowerer::new(
        &compiled.plan,
        &compiled.dialogue_content,
        "inline_record_enum_match.arcw",
    )
    .with_options(AwbcLowerOptions {
        verify: false,
        ..AwbcLowerOptions::default()
    })
    .lower()
    .expect("the parameterized Flow lowers to Product AWBC")
    .program;
    let function = product
        .flow_function(&flow.id)
        .expect("the exact semantic Flow has a Product function binding");
    product.flow_executables.push(AwbcFlowExecutable {
        metadata: RuntimeFlowExecutable {
            flow: flow.id.clone(),
            contract: FlowContractHash::from_bytes([19; 32]),
            controller: None,
        },
        function,
    });
    let entry_string = AwbcStringId(
        u32::try_from(product.strings.len()).expect("Product string table fits its ID domain"),
    );
    product
        .strings
        .push("inline-record-direct-invocation".to_owned());
    product.entries.push(AwbcEntry {
        runtime_id: arcweft_core::plan::EntryRuntimeId::canonical("inline_record_test")
            .expect("test entry identity is canonical"),
        binding: EntryBindingIdentity::from_bytes([19; 32]),
        public_id: entry_string,
        kind: AwbcEntryKind::Cli,
        target: AwbcEntryTarget::Function { function },
        roles: arcweft_core::entry::RuntimeEntryRoles::None,
    });
    product.canonicalize_string_table();
    let bytes = product
        .encode_canonical()
        .expect("the compiler's project enum code encodes canonically");
    let decoded = AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .expect("the project enum program decodes canonically");
    let mut awbc = AwbcProductStepExecutor::for_function_invocation(
        decoded,
        AwbcEntryId(0),
        function,
        [parameter],
        64,
    )
    .expect("decoded Product AWBC admits the same typed Flow input");

    let run =
        |mut step: Box<dyn FnMut(RuntimeStepInput, RuntimeStepOptions) -> RuntimeStepResult>| {
            let mut logs = Vec::new();
            for tick in 0..32 {
                let result = step(
                    RuntimeStepInput {
                        tick: TickId(tick),
                        ..RuntimeStepInput::default()
                    },
                    RuntimeStepOptions::default(),
                );
                assert!(
                    result.output.diagnostics.is_empty(),
                    "{:?}",
                    result.output.diagnostics
                );
                logs.extend(result.output.effects.line.into_iter().filter_map(|effect| {
                    match effect {
                        LineEffectRequest::Log(log) => Some((
                            log.message,
                            log.fields
                                .into_iter()
                                .map(|field| (field.name, field.value))
                                .collect::<Vec<_>>(),
                        )),
                        _ => None,
                    }
                }));
                match result.fiber_status {
                    FlowFiberStatus::Running => {}
                    FlowFiberStatus::Done(FlowExit::Done) => return logs,
                    status => panic!("inline-record match stopped unexpectedly: {status:?}"),
                }
            }
            panic!("inline-record match exceeded its deterministic step bound")
        };
    let native_logs = run(Box::new(|input, options| native.step(input, options)));
    let mut pure_backend = VmRuntimePureCallBackend::default();
    let awbc_logs = run(Box::new(|input, options| {
        awbc.step_with_pure_backend(input, options, &mut pure_backend)
    }));
    let expected = vec![(
        "selected".to_owned(),
        vec![("id".to_owned(), "42".to_owned())],
    )];
    eprintln!("native={native_logs:?}, decoded_awbc={awbc_logs:?}");
    assert_eq!(native_logs, expected);
    assert_eq!(awbc_logs, native_logs);
}

fn collect_mark_triggers(
    group: &LineTaskGroup,
    node_id: RuntimeLineTaskNodeId,
    output: &mut Vec<RuntimeDialogueMarkId>,
) {
    let node = group.node(node_id).expect("sealed line-task node");
    match node {
        LineTaskNode::Sequence(children)
        | LineTaskNode::Start(children)
        | LineTaskNode::Parallel { children, .. } => {
            for child in children {
                collect_mark_triggers(group, *child, output);
            }
        }
        LineTaskNode::Child { trigger, scope, .. } => {
            if let LineTaskTrigger::Mark(mark) = trigger {
                output.push(*mark);
            }
            collect_mark_triggers(group, *scope, output);
        }
        LineTaskNode::Action(_) => {}
    }
}

fn assert_dialogue_effect_sites(
    plan: &RuntimePlan,
    content: &RuntimeDialogueContentPlan,
    expected: usize,
) {
    assert_eq!(content.effect_sites().len(), expected);
    let manifest = plan
        .dialogue_content()
        .template(content.template())
        .expect("dialogue template manifest");
    assert_eq!(manifest.effects().len(), expected);
    for (index, effect) in content.effect_sites().iter().enumerate() {
        let declared = &manifest.effects()[index];
        assert_eq!(effect.site().index(), index);
        assert_eq!(declared.site(), effect.site());
        let callback = plan
            .callable_states()
            .get(effect.state())
            .expect("dialogue callback state");
        let arcweft_core::plan::RuntimeCallableTransition::Invoke { function: site, .. } =
            &callback.transition
        else {
            panic!("dialogue effect callback must invoke a function site");
        };
        let function = plan
            .function_sites()
            .get(*site)
            .expect("dialogue callback function site");
        assert!(function.parameter_inputs().next().is_none());
        let RuntimeFunctionSiteBody::Executable(body) = function.body() else {
            panic!("dialogue effect site must reference an executable function site");
        };
        assert!(!body.effects().is_empty());
        assert!(!body.ops().is_empty());
    }
}

fn dialogue_effect_triggers(
    plan: &RuntimePlan,
    content: &RuntimeDialogueContentPlan,
) -> Vec<RuntimeDialogueContentEffectTrigger> {
    plan.dialogue_content()
        .template(content.template())
        .expect("dialogue template manifest")
        .effects()
        .iter()
        .map(|effect| effect.trigger())
        .collect()
}

fn dialogue_effect_callback_ops<'plan>(
    plan: &'plan RuntimePlan,
    content: &RuntimeDialogueContentPlan,
    effect_index: usize,
) -> &'plan [FlowOp] {
    let effect = content
        .effect_sites()
        .get(effect_index)
        .expect("dialogue effect index");
    let callback = plan
        .callable_states()
        .get(effect.state())
        .expect("dialogue callback state");
    let arcweft_core::plan::RuntimeCallableTransition::Invoke { function, .. } =
        &callback.transition
    else {
        panic!("dialogue effect invokes its callback function site")
    };
    let site = plan
        .function_sites()
        .get(*function)
        .expect("dialogue callback function site");
    let RuntimeFunctionSiteBody::Executable(body) = site.body() else {
        panic!("dialogue point action has an executable callback body")
    };
    body.ops()
}

#[allow(
    clippy::too_many_lines,
    reason = "the end-to-end fixture keeps one explicit source-to-runtime publication pipeline"
)]
fn compile_attached_dialogue_project(source: &str) -> Result<CompiledProject, ProjectCompileError> {
    with_attached_dialogue_project(source, compile_project)
}

fn with_attached_dialogue_project<T>(
    source: &str,
    run: impl FnOnce(
        &mut ProjectCompilationSession,
        &ProjectSources,
        &BTreeMap<CanonicalModulePath, ParsedSource>,
        &ProjectCompilationContext,
    ) -> T,
) -> T {
    with_attached_dialogue_project_and_visual(source, None, run)
}

fn with_attached_dialogue_project_and_visual<T>(
    source: &str,
    visual: Option<&str>,
    run: impl FnOnce(
        &mut ProjectCompilationSession,
        &ProjectSources,
        &BTreeMap<CanonicalModulePath, ParsedSource>,
        &ProjectCompilationContext,
    ) -> T,
) -> T {
    use arcweft_character::{
        manifest::registration::SourceBackedCharacterManifest,
        registration_catalog::SourceBackedCharacterCatalog,
    };

    let source_document = Arc::new(
        SourceDocument::try_new(
            SourceDocumentId::try_new("arcweft-test://evaluated-effects/source")
                .expect("dialogue source document ID"),
            SourceName::path("src/main.arcw"),
            source,
        )
        .expect("dialogue source document"),
    );
    let manifest_document = Arc::new(
        SourceDocument::try_new(
            SourceDocumentId::try_new("arcweft-test://evaluated-effects/manifest")
                .expect("dialogue manifest document ID"),
            SourceName::path("arcw.toml"),
            "schema = 1\n\
[package]\n\
id = \"local.arcweft.evaluated-effects\"\n\
version = \"0.0.0\"\n\
\n\
[profiles.dev]\n\
kind = \"game\"\n\
source = \"src/main.arcw\"\n",
        )
        .expect("dialogue manifest document"),
    );
    let project = ProjectSources::new(
        PathBuf::from("arcw.toml"),
        PathBuf::new(),
        PackageSpec {
            id: PackageId::new("local.arcweft.evaluated-effects").expect("package ID"),
            version: PackageVersion::new("0.0.0").expect("package version"),
        },
        BuildSpec::default(),
        Arc::clone(&manifest_document),
        [ProjectSourceFile::new(
            CanonicalModulePath::crate_root(),
            PathBuf::from("src/main.arcw"),
            Arc::clone(&source_document),
            [],
        )],
    )
    .expect("dialogue project sources");
    let package =
        CallablePackageId::try_new(project.package().id.as_str()).expect("callable package ID");
    let world = ProjectSymbolWorldId::try_new(
        package,
        source_document.identity().id().clone(),
        "evaluated-effects-test",
    )
    .expect("dialogue symbol world");
    let mut registration_documents =
        vec![Arc::clone(&source_document), Arc::clone(&manifest_document)];
    let character_catalogs = visual.map(|json| {
        let document = Arc::new(
            SourceDocument::try_new(
                SourceDocumentId::try_new("arcweft-test://evaluated-effects/alice-visual").unwrap(),
                SourceName::path("alice.json"),
                json,
            )
            .unwrap(),
        );
        let manifest = SourceBackedCharacterManifest::decode_registration_json(&document).unwrap();
        let catalog =
            SourceBackedCharacterCatalog::try_new(document.identity().clone(), vec![manifest])
                .unwrap();
        registration_documents.push(document);
        catalog
    });
    let facts = ProjectRegistrationFacts::try_new(
        world,
        registration_documents,
        Vec::new(),
        character_catalogs.into_iter().collect(),
        Vec::new(),
    )
    .expect("dialogue registration facts");
    let resource_types = Arc::new(ResourceTypeRegistry::empty());
    let accepted = Arc::new(
        SourceBackedManifest::decode(Arc::clone(&manifest_document))
            .expect("accepted dialogue manifest"),
    );
    let profile_id = ProfileId::new("dev").expect("dialogue profile ID");
    let resolved = accepted
        .resolve_profile(LaunchProfileSelection::Explicit(profile_id.as_str()))
        .expect("resolved dialogue profile");
    let topology_revision = SourceSetRevision::try_for_identities([
        manifest_document.identity(),
        source_document.identity(),
    ])
    .expect("dialogue topology revision");
    let context = ProjectCompilationContext::new(
        Arc::new(TypeCheckEnv::standard()),
        Arc::new(facts),
        Arc::clone(&resource_types),
        None,
        None,
    )
    .with_accepted_launch_profile(AcceptedLaunchProfileInput::new(
        accepted,
        profile_id,
        resolved,
        topology_revision,
        resource_types,
    ));
    let mut syntax = SyntaxDatabase::try_new().expect("dialogue syntax database");
    let parsed = syntax
        .parse_initial(
            SourceSnapshotId::initial(source_document.display_name().clone()),
            Arc::clone(&source_document),
            ParseOptions::default(),
        )
        .expect("dialogue attached source");
    let parsed_sources = BTreeMap::<CanonicalModulePath, ParsedSource>::from([(
        CanonicalModulePath::crate_root(),
        parsed,
    )]);
    let mut session = ProjectCompilationSession::try_new().expect("dialogue HIR database");
    run(&mut session, &project, &parsed_sources, &context)
}

fn resolve_authored_spacing_frame(
    compiled: &CompiledProject,
    schema: &arcweft_dialogue::CharacterDialogueRuntimeSchema,
    artifact: arcweft_core::effect::RuntimeArtifactFingerprint,
    template: arcweft_core::runtime_id::RuntimeDialogueContentTemplateId,
    target: &arcweft_core::value::RuntimeOpaqueValue,
    values: &[RuntimeDialogueValueBinding],
) -> arcweft_text_model::LineDisplayFrame {
    let runtime = compiled.runtime_plan();
    let manifest = runtime.plan.dialogue_content().template(template).unwrap();
    let content =
        RuntimeDialogueContentValue::try_from_evaluated_bindings(artifact, manifest, values)
            .expect(
                "the executed values retain the admitted template's exact slot roles and types",
            );
    let fragments = runtime
        .dialogue_content_catalog
        .fragment_catalog(artifact)
        .unwrap();
    let materialized = DialogueContentMaterializer::new(&fragments)
        .materialize(&content)
        .unwrap();
    let spec = runtime
        .dialogue_content_catalog
        .records()
        .iter()
        .find(|spec| spec.template_id() == template)
        .expect("the selected dialogue has its exact catalog record");
    let admitted = schema
        .admit(
            schema.program_owner(),
            &RuntimeValue::Opaque(target.clone()),
            target.semantic_identity(),
        )
        .expect("the executed CharacterDialogue target belongs to this program generation");
    let config = admitted.dialogue().config();
    let RuntimeValue::Opaque(style) = config.style().typed().value() else {
        panic!("the fixture uses the admitted default empty Style role")
    };
    assert!(
        arcweft_dialogue::CharacterDialogueRolePayloadCodec::RichTextProperties
            .decode_properties(style.payload())
            .unwrap()
            .is_empty()
    );
    let RuntimeValue::Opaque(rich_text) = config.rich_text().typed().value() else {
        panic!("the admitted RichText role carries its typed property payload")
    };
    let base_styles = arcweft_text_model::project_character_dialogue_rich_text_properties(
        &arcweft_dialogue::CharacterDialogueRolePayloadCodec::RichTextProperties
            .decode_properties(rich_text.payload())
            .unwrap(),
    )
    .unwrap();
    let context = arcweft_render_text::RuntimeLineContext::new(
        values.to_vec(),
        arcweft_text_model::DialoguePresentationCharacter {
            id: admitted.dialogue().character().clone(),
            display_name: "Alice".to_owned(),
        },
        arcweft_text_model::CharacterDialoguePresentationConfig::from_admitted(
            schema, &admitted, None,
        )
        .unwrap(),
        base_styles,
    );
    let frame =
        arcweft_render_text::resolve_materialized_frame(spec, &materialized, &content, &context)
            .expect("the admitted Content resolves through the existing typed display-map owner");
    assert!(frame.inline_failures.is_empty());
    assert!(frame.unresolved.is_empty());
    frame.validate().unwrap();
    let snapshot = arcweft_text_model::LineDisplayFrameSnapshot::from_live(
        &frame,
        Some(schema.program_owner()),
        Some(schema),
    )
    .unwrap();
    let encoded = serde_json::to_vec(&snapshot).unwrap();
    let decoded: arcweft_text_model::LineDisplayFrameSnapshot =
        serde_json::from_slice(&encoded).unwrap();
    let decoded = decoded
        .into_live(Some(schema.program_owner()), Some(schema))
        .unwrap();
    assert_eq!(decoded, frame);
    // This helper is invoked for both the original Native plan and decoded AWBC.
    // Rebinding requires their actual generation schema, even when all visible
    // rendered text and source ranges are unchanged.
    let mut forged = serde_json::to_value(&snapshot).unwrap();
    forged["effective"]["generation"] =
        serde_json::to_value(arcweft_core::entry::RuntimeValueDigest::ZERO).unwrap();
    let forged: arcweft_text_model::LineDisplayFrameSnapshot =
        serde_json::from_value(forged).unwrap();
    assert!(
        forged
            .into_live(Some(schema.program_owner()), Some(schema))
            .is_err()
    );
    assert!(snapshot.clone().into_live(None, Some(schema)).is_err());
    assert_eq!(serde_json::to_vec(&snapshot).unwrap(), encoded);
    frame
}

fn frames_for_authored_dialogue_spacing(source: &str) -> arcweft_text_model::LineDisplayFrame {
    let compiled = compile_attached_dialogue_project(source).unwrap();
    let runtime = compiled.runtime_plan();
    let report = AwbcLowerer::new(
        &runtime.plan,
        &runtime.dialogue_content_catalog,
        "authored_dialogue_spacing.arcw",
    )
    .lower()
    .expect("the checked source lowers to canonical verified AWBC");
    let bytes = report.program.encode_canonical().unwrap();
    let decoded = arcweft_core::awbc::schema::AwbcProgram::decode_canonical(
        &bytes,
        arcweft_core::awbc::codec::AwbcDecodeBudget::default(),
    )
    .unwrap();
    assert_eq!(decoded, report.program);
    let [flow] = runtime.plan.flows() else {
        panic!("one fixture flow")
    };
    let template = flow
        .body()
        .ops()
        .iter()
        .find_map(|op| match op {
            FlowOp::Dialogue { content, .. } => runtime
                .plan
                .dialogue_content()
                .get(*content)
                .map(RuntimeDialogueContentPlan::template),
            _ => None,
        })
        .expect("the authored dialogue owns its checked template");
    let artifact = arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes(
        *blake3::hash(&bytes).as_bytes(),
    )
    .unwrap();
    let mut plan = runtime.plan.clone();
    plan.bind_artifact(artifact).unwrap();
    let mut native = arcweft_core::engine::Engine::for_flow(plan, &flow.id).unwrap();
    let native_schema = bind_test_character_dialogue_schema(
        &compiled,
        arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
    );
    let mut native_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
        .with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&native_schema),
        );
    let (native_target, native_values, native_effects) = execute_single_dialogue_with_content(
        |input, options| native.step_with_pure_backend(input, options, &mut native_backend),
        template,
    );
    let mut awbc = arcweft_core::executor::ArcweftRuntimeExecutor::from_awbc_product(
        decoded,
        arcweft_core::awbc::schema::AwbcEntryId(0),
    )
    .unwrap();
    let awbc_schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
    let mut awbc_backend = arcweft_core::pure::VmRuntimePureCallBackend::default()
        .with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&awbc_schema),
        );
    let (awbc_target, awbc_values, awbc_effects) = execute_single_dialogue_with_content(
        |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend),
        template,
    );
    assert_eq!(native_target, awbc_target);
    assert_eq!(native_values, awbc_values);
    assert_eq!(native_effects, awbc_effects);
    let native_frame = resolve_authored_spacing_frame(
        &compiled,
        &native_schema,
        artifact,
        template,
        &native_target,
        &native_values,
    );
    let awbc_frame = resolve_authored_spacing_frame(
        &compiled,
        &awbc_schema,
        artifact,
        template,
        &awbc_target,
        &awbc_values,
    );
    assert_eq!(native_frame, awbc_frame);
    native_frame
}

#[test]
fn authored_space_after_interpolation_keeps_ruby_display_range_in_native_and_awbc() {
    let frame = frames_for_authored_dialogue_spacing(
        r##"
pub character alice { display = "Alice" }
flow main() -> Unit {
    let player = "Aoi"
    alice: #color(rgb("#303132"))[Hello #[player] |[夢](ゆめ)[r][p]]
}
entry cli @entry.main { goto @flow.main }
"##,
    );
    assert_eq!(frame.text, "Hello Aoi 夢\n");
    let [ruby] = frame.display_map.ruby_annotations.as_slice() else {
        panic!("the authored Ruby annotation remains one exact owner")
    };
    assert_eq!(ruby.ruby, "ゆめ");
    assert_eq!(
        ruby.base_range,
        arcweft_text_model::RichTextRange::new(10, 13)
    );
    assert_eq!(
        &frame.text[ruby.base_range.start..ruby.base_range.end],
        "夢"
    );
    assert!(frame.display_map.text_runs.iter().any(|run| {
        run.source == arcweft_text_model::RichTextTextSource::Interpolation
            && run.range == arcweft_text_model::RichTextRange::new(6, 9)
    }));
    assert!(frame.display_map.text_runs.iter().any(|run| {
        run.source == arcweft_text_model::RichTextTextSource::Text
            && run.range == arcweft_text_model::RichTextRange::new(9, 10)
    }));
}

#[test]
fn authored_space_after_hard_break_keeps_vertical_text_run_in_native_and_awbc() {
    let frame = frames_for_authored_dialogue_spacing(
        r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice: #layout(.vertical_lr)[縦 |[夢](ゆめ)[r] 2026 ABC。][p]
}
entry cli @entry.main { goto @flow.main }
"#,
    );
    assert_eq!(frame.text, "縦 夢\n 2026 ABC。");
    let after_break: Vec<_> = frame
        .display_map
        .text_runs
        .iter()
        .filter(|run| {
            run.source == arcweft_text_model::RichTextTextSource::Text
                && &frame.text[run.range.start..run.range.end] == " 2026 ABC。"
        })
        .collect();
    let [run] = after_break.as_slice() else {
        panic!("the inline leading space and following digits retain one authored text run")
    };
    assert_eq!(run.range, arcweft_text_model::RichTextRange::new(8, 20));
    assert!(frame.display_map.text_runs.iter().all(|run| {
        run.presentation.layout.as_ref().is_some_and(|layout| {
            layout.writing_mode == arcweft_text_model::RichTextWritingMode::VerticalLr
        })
    }));
    let [ruby] = frame.display_map.ruby_annotations.as_slice() else {
        panic!("the vertical Ruby remains one exact owner")
    };
    assert_eq!(
        ruby.base_range,
        arcweft_text_model::RichTextRange::new(4, 7)
    );
    assert_eq!(ruby.ruby, "ゆめ");
}

#[test]
fn physical_line_endings_normalize_display_without_erasing_inline_spaces_in_native_and_awbc() {
    let source = concat!(
        "pub character alice { display = \"Alice\" }\n",
        "flow main() -> Unit {\n",
        "    let player = \"Aoi\"\n",
        "    alice()[\r\n  Head #[player]  \r\n\t Next[r] \t2026 \r Third\n    Last[p]]\n",
        "}\n",
        "entry cli @entry.main { goto @flow.main }\n",
    );
    let frame = frames_for_authored_dialogue_spacing(source);
    assert_eq!(frame.text, "\nHead Aoi  \nNext\n \t2026 \nThird\nLast");
    let breaks: Vec<_> = frame
        .display_map
        .text_runs
        .iter()
        .filter(|run| run.source == arcweft_text_model::RichTextTextSource::ControlHardBreak)
        .collect();
    assert_eq!(breaks.len(), 5);
    for run in breaks {
        assert_eq!(&frame.text[run.range.start..run.range.end], "\n");
        assert_eq!(run.range.end - run.range.start, 1);
    }
}

#[path = "D:/git/arcweft/crates/arcweft-compiler/tests/evaluated_effects/dialogue_readiness.rs"]
mod dialogue_readiness;

#[path = "D:/git/arcweft/crates/arcweft-compiler/tests/evaluated_effects/dialogue_template_order.rs"]
mod dialogue_template_order;

#[path = "D:/git/arcweft/crates/arcweft-compiler/tests/evaluated_effects/content_style_origin.rs"]
mod content_style_origin;

#[test]
fn native_owned_registry_control() { run_owned_line_registry(false, false); }
#[test]
fn decoded_awbc_owned_registry_control() { run_owned_line_registry(true, false); }
#[test]
fn native_owned_line_registry() { run_owned_line_registry(false, true); }
#[test]
fn decoded_awbc_owned_line_registry() { run_owned_line_registry(true, true); }

fn run_owned_line_registry(awbc: bool, stored: bool) {
    use arcweft_core::{
        effect::RuntimeArtifactFingerprint, engine::Engine, pure::VmRuntimePureCallBackend,
        task::RuntimeProgramOwner,
    };
    let action = if stored {
        "'line.saved <- actor\ndrop('line.saved)"
    } else {
        "let _ = actor"
    };
    let source = format!(r#"
pub character alice {{ display = "Alice" }}
flow main() -> Unit effects {{ state.write('line), log.write }} {{
    alice()[Outer[p]] with {{
        init {{
            let actor = alice()[Inner[p]] with {{
                let lease = alice.stage.acquire(scope=line)
                out lease
            }}
            {action}
            log.info("continued after release")
        }}
    }}
}}
entry cli @entry.main {{ goto @flow.main }}
"#);
    let compiled = with_attached_dialogue_project_and_visual(
        &source, Some(LINE_HANDLE_CHARACTER_MANIFEST), compile_project,
    ).expect("typed registration and release compile");
    eprintln!("compiled awbc={awbc} stored={stored}");
    if awbc {
        let (compiled, mut runtime) = nested_awbc_from_compiled(compiled);
        let schema = bind_test_character_dialogue_schema(&compiled, runtime.program_owner());
        let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
        );
        execute_owned_registry_probe(|input, options| {
            runtime.step_with_pure_backend(input, options, &mut backend)
        });
    } else {
        let mut plan = compiled.runtime_plan().plan.clone();
        let flow = plan.flows()[0].id.clone();
        plan.bind_artifact(
            RuntimeArtifactFingerprint::try_from_bytes(*blake3::hash(source.as_bytes()).as_bytes()).unwrap(),
        ).unwrap();
        let mut runtime = Engine::for_flow(plan, &flow).unwrap();
        let schema = bind_test_character_dialogue_schema(
            &compiled, RuntimeProgramOwner::Plan(runtime.program_plan()),
        );
        let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
        );
        execute_owned_registry_probe(|input, options| {
            runtime.step_with_pure_backend(input, options, &mut backend)
        });
    }
}

fn execute_owned_registry_probe(
    mut step: impl FnMut(
        arcweft_core::step::RuntimeStepInput, arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
) {
    use arcweft_core::{
        engine::{FlowExit, FlowFiberStatus},
        plan::FlowEvent,
        presentation::{RuntimeLineHostCommand, RuntimeLineHostOutcome, RuntimeStageCommand, RuntimeStageCommandOutcome},
        step::{RuntimeStepInput, RuntimeStepOptions},
        time::TickId,
    };
    let mut input = RuntimeStepInput::default();
    let mut actor = None;
    let mut released = false;
    let mut logs = Vec::new();
    for tick in 0..512 {
        input.tick = TickId(tick);
        let result = step(std::mem::take(&mut input), RuntimeStepOptions::default());
        assert!(result.output.diagnostics.is_empty(), "tick {tick} status {:?}: {:?}", result.fiber_status, result.output.diagnostics);
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine { activation, .. } = event {
                input.dialogue_advances.push(activation);
            }
        }
        logs.extend(log_messages(&result.output.effects.line));
        for command in result.output.requests.line_commands {
            let outcome = match command {
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::AcquireActor { command, actor: token, .. }) => {
                    assert_eq!(token.activation(), command.activation());
                    assert!(actor.replace(token.clone()).is_none());
                    eprintln!("acquired at tick {tick}");
                    RuntimeStageCommandOutcome::Acquired { command, actor: token }
                }
                RuntimeLineHostCommand::Stage(RuntimeStageCommand::ReleaseActor { command, actor: token }) => {
                    assert_eq!(Some(&token), actor.as_ref());
                    assert_eq!(token.activation(), command.activation());
                    assert!(!released);
                    released = true;
                    eprintln!("released at tick {tick}");
                    RuntimeStageCommandOutcome::ReleasedActor { command, actor: token }
                }
                other => panic!("unexpected line command {other:?}"),
            };
            input.line_outcomes.push(RuntimeLineHostOutcome::Stage(outcome));
        }
        match result.fiber_status {
            FlowFiberStatus::Running | FlowFiberStatus::Dialogue(_) => {}
            FlowFiberStatus::Done(FlowExit::Done) => {
                assert!(released && input.line_outcomes.is_empty(), "must acknowledge release before successful termination");
                assert_eq!(logs, ["continued after release"]);
                return;
            }
            status => panic!("tick {tick}: {status:?}, released={released}, logs={logs:?}"),
        }
    }
    panic!("owned registration probe exceeded step bound")
}

