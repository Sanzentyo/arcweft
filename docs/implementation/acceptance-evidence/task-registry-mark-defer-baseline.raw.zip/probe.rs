use std::{collections::BTreeMap, path::PathBuf, sync::Arc};

use arcweft_character::catalog::{CharacterCatalog, CharacterVisualManifestEvidence};
use arcweft_compiler::project::{
    AcceptedLaunchProfileInput, CompiledProject, ProjectCompilationContext,
    ProjectCompilationSession, ProjectCompileError, compile_project,
};
use arcweft_core::{
    awbc::{codec::AwbcDecodeBudget, schema::{AwbcEntryId, AwbcProgram}},
    effect::RuntimeArtifactFingerprint,
    engine::{Engine, FlowFiberStatus},
    executor::ArcweftRuntimeExecutor,
    plan::FlowEvent,
    pure::VmRuntimePureCallBackend,
    runtime_id::{DialogueActivationId, RuntimeDialogueMarkId},
    step::{RuntimeDialogueContentEvent, RuntimeDialogueContentEventKind, RuntimeStepInput, RuntimeStepOptions, RuntimeStepResult},
    time::TickId,
};
use arcweft_lang_hir::symbol::{CallablePackageId, ProjectSymbolWorldId};
use arcweft_lang_sema::{env::TypeCheckEnv, registration::ProjectRegistrationFacts};
use arcweft_lang_syntax::{
    ast::module_path::CanonicalModulePath,
    incremental::{ParsedSource, SyntaxDatabase},
    parser::ParseOptions,
};
use arcweft_launch::{LaunchProfileSelection, ProfileId, accepted::SourceBackedManifest};
use arcweft_manifest_model::{BuildSpec, PackageId, PackageSpec, PackageVersion};
use arcweft_project::sources::{ProjectSourceFile, ProjectSources};
use arcweft_resource_model::registry::ResourceTypeRegistry;
use arcweft_runtime_plan::awbc_lower::AwbcLowerer;
use arcweft_source::{
    SourceDocument, SourceDocumentId, SourceName, SourceSetRevision, identity::SourceSnapshotId,
};

fn probe_steps(
    case: &str,
    backend: &str,
    mut step: impl FnMut(RuntimeStepInput, RuntimeStepOptions) -> RuntimeStepResult,
) {
    let mark = RuntimeDialogueMarkId::from_zero_based(0).unwrap();
    let mut activation: Option<DialogueActivationId> = None;
    let mut delivered = false;
    let mut advanced = false;
    let mut saw_child = false;
    let mut child_count = 0;
    let mut terminal_status = None;
    for tick in 0..512 {
        let mut input = RuntimeStepInput {
            tick: TickId(tick),
            ..RuntimeStepInput::default()
        };
        if let Some(id) = activation {
            if !delivered {
                input.dialogue_content_events.push(RuntimeDialogueContentEvent::new(
                    id,
                    RuntimeDialogueContentEventKind::Mark(mark),
                ));
                delivered = true;
            } else if saw_child && child_count == 0 && !advanced {
                input.dialogue_advances.push(id);
                advanced = true;
            }
        }
        let result = step(input, RuntimeStepOptions::default());
        child_count = result.stats.child_fibers;
        saw_child |= child_count != 0;
        for event in result.output.flow_events {
            if let FlowEvent::DialogueLine { activation: revealed, .. } = event {
                assert!(activation.replace(revealed).is_none());
            }
        }
        for effect in result.output.effects.line {
            println!("EFFECT {case} {backend} {tick} {effect:?}");
        }
        if !result.output.diagnostics.is_empty() {
            println!("DIAGNOSTIC {case} {backend} {tick} {:?}", result.output.diagnostics);
            return;
        }
        if !matches!(result.fiber_status, FlowFiberStatus::Running | FlowFiberStatus::Dialogue(_)) {
            println!("TERMINAL {case} {backend} {tick} {:?} delivered={delivered} saw_child={saw_child}", result.fiber_status);
            return;
        }
        terminal_status = Some(result.fiber_status);
    }
    println!("BOUND {case} {backend} {terminal_status:?} delivered={delivered} saw_child={saw_child}");
}

fn main() {
    let template = r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    let result = alice()[hello[mark @.probe][p]] with {
        on mark(@.probe) {
            log.info("mark-handler-enter")
            __DEFER__
            out "result"
        }
    }
    log.info(result)
}
entry cli @entry.main { goto @flow.main }
"#;
    for (case, cleanup) in [
        ("control", ""),
        ("defer", "defer { log.info(\"mark cleanup\") }"),
        ("failed-only", "defer on failed { log.info(\"mark cleanup\") }"),
    ] {
        let compiled = match compile_attached_dialogue_project(&template.replace("__DEFER__", cleanup)) {
            Ok(compiled) => compiled,
            Err(error) => { println!("COMPILE {case} {error:?}"); continue; }
        };
        let runtime = compiled.runtime_plan();
        let program = match AwbcLowerer::new(&runtime.plan, &runtime.dialogue_content_catalog, "scope-probe.arcw").lower() {
            Ok(report) => report.program,
            Err(error) => { println!("AWBC LOWER {case} {error:?}"); continue; }
        };
        let bytes = program.encode_canonical().unwrap();
        let decoded = AwbcProgram::decode_canonical(&bytes, AwbcDecodeBudget::default()).unwrap();

        let [flow] = runtime.plan.flows() else { panic!("one Flow") };
        let mut plan = runtime.plan.clone();
        plan.bind_artifact(RuntimeArtifactFingerprint::try_from_bytes(*blake3::hash(&bytes).as_bytes()).unwrap()).unwrap();
        let mut native = Engine::for_flow(plan, &flow.id).unwrap();
        let schema = bind_test_character_dialogue_schema(
            &compiled,
            arcweft_core::task::RuntimeProgramOwner::Plan(native.program_plan()),
        );
        let mut native_backend = VmRuntimePureCallBackend::default().with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
        );
        probe_steps(case, "native", |input, options| native.step_with_pure_backend(input, options, &mut native_backend));

        let mut awbc = ArcweftRuntimeExecutor::from_awbc_product(decoded, AwbcEntryId(0)).unwrap();
        let schema = bind_test_character_dialogue_schema(&compiled, awbc.program_owner());
        let mut awbc_backend = VmRuntimePureCallBackend::default().with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
        );
        probe_steps(case, "awbc", |input, options| awbc.step_with_pure_backend(input, options, &mut awbc_backend));
    }
}

fn bind_test_character_dialogue_schema(
    compiled: &CompiledProject,
    owner: arcweft_core::task::RuntimeProgramOwner,
) -> arcweft_dialogue::CharacterDialogueRuntimeSchema {
    let generation = compiled
        .runtime_plan()
        .character_dialogue_generation
        .as_ref()
        .expect("the dialogue fixture publishes a CharacterDialogue generation");
    let environment = compiled.analysis_lease().registered_environment();
    let characters =
        CharacterCatalog::try_from_declarations(generation.characters().keys().map(|character| {
            let visual = environment.character_manifest(character).cloned().map_or(
                CharacterVisualManifestEvidence::Absent,
                CharacterVisualManifestEvidence::Present,
            );
            (character.clone(), visual)
        }))
        .expect("the accepted Character inventory and visual evidence form a catalog");

    let product = compiled.dialogue_profile().product();
    let program = product
        .program()
        .expect("the accepted dialogue profile retains its View program");
    let mut views = arcweft_view::ViewRegistry::default();
    program
        .register_runtime_views(&mut views)
        .expect("the accepted dialogue View registry");
    let style_digest = product.style().map(|style| {
        style
            .resource()
            .canonical_digest()
            .map(|digest| arcweft_core::entry::RuntimeValueDigest::from_bytes(digest.as_bytes()))
            .expect("the accepted dialogue Style fingerprint")
    });

    generation
        .bind_runtime(Arc::new(views), Arc::new(characters), style_digest, owner)
        .expect("the schema binds to this exact executable generation")
}

fn compile_attached_dialogue_project(source: &str) -> Result<CompiledProject, ProjectCompileError> {
    with_attached_dialogue_project(source, compile_project)
}

fn with_attached_dialogue_project<T>(
    source: &str,
    run: impl FnOnce(
        &mut ProjectCompilationSession,
        &ProjectSources,
        &BTreeMap<CanonicalModulePath, ParsedSource>,
        &ProjectCompilationContext,
    ) -> T,
) -> T {
    with_attached_dialogue_project_and_visual(source, None, run)
}

fn with_attached_dialogue_project_and_visual<T>(
    source: &str,
    visual: Option<&str>,
    run: impl FnOnce(
        &mut ProjectCompilationSession,
        &ProjectSources,
        &BTreeMap<CanonicalModulePath, ParsedSource>,
        &ProjectCompilationContext,
    ) -> T,
) -> T {
    use arcweft_character::{
        manifest::registration::SourceBackedCharacterManifest,
        registration_catalog::SourceBackedCharacterCatalog,
    };

    let source_document = Arc::new(
        SourceDocument::try_new(
            SourceDocumentId::try_new("arcweft-test://evaluated-effects/source")
                .expect("dialogue source document ID"),
            SourceName::path("src/main.arcw"),
            source,
        )
        .expect("dialogue source document"),
    );
    let manifest_document = Arc::new(
        SourceDocument::try_new(
            SourceDocumentId::try_new("arcweft-test://evaluated-effects/manifest")
                .expect("dialogue manifest document ID"),
            SourceName::path("arcw.toml"),
            "schema = 1\n\
[package]\n\
id = \"local.arcweft.evaluated-effects\"\n\
version = \"0.0.0\"\n\
\n\
[profiles.dev]\n\
kind = \"game\"\n\
source = \"src/main.arcw\"\n",
        )
        .expect("dialogue manifest document"),
    );
    let project = ProjectSources::new(
        PathBuf::from("arcw.toml"),
        PathBuf::new(),
        PackageSpec {
            id: PackageId::new("local.arcweft.evaluated-effects").expect("package ID"),
            version: PackageVersion::new("0.0.0").expect("package version"),
        },
        BuildSpec::default(),
        Arc::clone(&manifest_document),
        [ProjectSourceFile::new(
            CanonicalModulePath::crate_root(),
            PathBuf::from("src/main.arcw"),
            Arc::clone(&source_document),
            [],
        )],
    )
    .expect("dialogue project sources");
    let package =
        CallablePackageId::try_new(project.package().id.as_str()).expect("callable package ID");
    let world = ProjectSymbolWorldId::try_new(
        package,
        source_document.identity().id().clone(),
        "evaluated-effects-test",
    )
    .expect("dialogue symbol world");
    let mut registration_documents =
        vec![Arc::clone(&source_document), Arc::clone(&manifest_document)];
    let character_catalogs = visual.map(|json| {
        let document = Arc::new(
            SourceDocument::try_new(
                SourceDocumentId::try_new("arcweft-test://evaluated-effects/alice-visual").unwrap(),
                SourceName::path("alice.json"),
                json,
            )
            .unwrap(),
        );
        let manifest = SourceBackedCharacterManifest::decode_registration_json(&document).unwrap();
        let catalog =
            SourceBackedCharacterCatalog::try_new(document.identity().clone(), vec![manifest])
                .unwrap();
        registration_documents.push(document);
        catalog
    });
    let facts = ProjectRegistrationFacts::try_new(
        world,
        registration_documents,
        Vec::new(),
        character_catalogs.into_iter().collect(),
        Vec::new(),
    )
    .expect("dialogue registration facts");
    let resource_types = Arc::new(ResourceTypeRegistry::empty());
    let accepted = Arc::new(
        SourceBackedManifest::decode(Arc::clone(&manifest_document))
            .expect("accepted dialogue manifest"),
    );
    let profile_id = ProfileId::new("dev").expect("dialogue profile ID");
    let resolved = accepted
        .resolve_profile(LaunchProfileSelection::Explicit(profile_id.as_str()))
        .expect("resolved dialogue profile");
    let topology_revision = SourceSetRevision::try_for_identities([
        manifest_document.identity(),
        source_document.identity(),
    ])
    .expect("dialogue topology revision");
    let context = ProjectCompilationContext::new(
        Arc::new(TypeCheckEnv::standard()),
        Arc::new(facts),
        Arc::clone(&resource_types),
        None,
        None,
    )
    .with_accepted_launch_profile(AcceptedLaunchProfileInput::new(
        accepted,
        profile_id,
        resolved,
        topology_revision,
        resource_types,
    ));
    let mut syntax = SyntaxDatabase::try_new().expect("dialogue syntax database");
    let parsed = syntax
        .parse_initial(
            SourceSnapshotId::initial(source_document.display_name().clone()),
            Arc::clone(&source_document),
            ParseOptions::default(),
        )
        .expect("dialogue attached source");
    let parsed_sources = BTreeMap::<CanonicalModulePath, ParsedSource>::from([(
        CanonicalModulePath::crate_root(),
        parsed,
    )]);
    let mut session = ProjectCompilationSession::try_new().expect("dialogue HIR database");
    run(&mut session, &project, &parsed_sources, &context)
}

