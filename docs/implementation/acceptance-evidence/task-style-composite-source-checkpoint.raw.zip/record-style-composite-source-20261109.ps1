$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-composites-20261109.source-checkpoint.verified.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit){throw 'Source changed'}
$owner=Read-Record 'style-composites-20261109.owner-r2.runtime.terminal-audit.json'
$quality=@(foreach($gate in @('check','clippy','structure','fmt')){Read-Record "style-composites-20261109.quality.$gate.receipt.json"})
$imports=Read-Record 'style-composites-20261109.import-quality.json'
if($owner.actualExitCode -ne 0 -or $owner.executed -ne 46 -or @($quality|Where-Object exitCode -ne 0).Count -or $imports.exitCode -ne 0){throw 'Missing passing check'}
$review=Read-Record 'style-composites-20261109.owner-review.json'
foreach($p in $review.paths){$p.bytes=(Get-Item -LiteralPath $p.path).Length;$p.physicalLoc=@(Get-Content -LiteralPath $p.path).Count}
$review.disposition=$review.disposition.Replace('433-line','438-line')
$review|ConvertTo-Json -Depth 8|Set-Content "$r/style-composites-20261109.owner-review.json"
$archive='docs/implementation/acceptance-evidence/task-style-composite-source-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(Get-ChildItem -LiteralPath $r -File -Filter 'style-composites-20261109*'|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')})
$files+=@('run-style-composites-owner-20261109.ps1','run-style-composites-owner-r2-20261109.ps1','run-style-composites-quality-20261109.ps1','run-style-composites-consumers-20261109.ps1','run-style-composites-cli-consumers-20261109.ps1','record-style-composite-source-20261109.ps1','cargo-clean-20261109-002215.json','cargo-clean-20261109-002215.log')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';publication=$pub
 status='Explicitly typed composite Style construction verified at owner boundary and published; full reverse-dependency runtime execution and full Style/sample acceptance remain open.'
 model='Construct BorderRadii, ShadowList, FilterList, Transition, Resource and non-None Clip/Mask directly into native carriers. Typed signatures bind authored arguments before defaults. Preserve list order, symbolic SystemColor, exact u32 milliseconds, and native transitionability. Component semantic digests reuse native field encoders. Duration/ResourceId are semantic-only roles. All contract markers remain 1.'
 tokenComposition='Use original sheet/declaration/initializer identities with cycle checks and native depth 64. Same-kind direct references remain symbolic, including border-radius Length shorthand. BorderRadii contexts convert Length/token constants to uniform corners. Native resolver remains runtime cascade authority.'
 initialOwner=(Read-Record 'style-composites-20261109.owner-r1.runtime.terminal-audit.json')
 finalOwner=$owner;testCorrection=(Read-Record 'style-composites-20261109.test-correction.json')
 quality=$quality;finalImportQuality=$imports;finalFmt=(Read-Record 'style-composites-20261109.final-fmt.json')
 ownerReview=$review;graph=(Read-Record 'style-composites-20261109.graph.json');reverseDependencyTree=(Read-Record 'style-composites-20261109.tree-invert.json')
 scope='Final owner-r2: 46/46 pass; 2559 filtered cases are not consumer execution. Do not add initial 43 pass/2 fail. All 98 workspace packages passed locked/all-target/all-feature check and Clippy, structure and fmt before one import-only correction; final Sema all-target/all-feature Clippy and explicit fmt passed after it. Complete View closure: 41 packages, nonCLI all-features 40 and CLI defaults 1; runtime results pending.'
 cleanup=(Read-Record 'cargo-clean-20261109-002215.json')
 cleanupScope='Explicit full cargo clean removed 294059 files/399.1 GiB, exit 0. Historical results and hashes retained; old in-place EXE/AWFB paths deleted by this authorized clean are not claimed to exist now.'
 pending='Reverse-dependency runtime execution, unannotated-token inference, Environment publication, remaining sample migration and actual Native/Web operation/capture parity. Other ledger requirements remain independent; Generic Match acceptance unchanged.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 144 -or $prior.PSObject.Properties.Name -contains 'styleCompositeSourceCheckpoint'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "styleCompositeSourceCheckpoint": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$row='| Style 指定値・token・構築処理 | **明示型付き複合値までowner検証・公開** | Source '+$pub.commit+' でBorderRadii／ShadowList／FilterList／Transition／Resourceと非None Clip／Maskを接続し、全25 kindに構築形を持つ。native値・typed引数／既定値・記述順・exact ms・sheet内token合成／uniform radii・循環／深さ上限を検証。border-radius自体は既存のLength shorthandとsymbolic tokenを維持する。owner最終46件全PASS。全98 workspaceのcheck／Clippy・構造gate・fmtが終了0、後続import整理はSema Clippy／fmtで再確認。数値・font／palette・元annotation／元宣言／codec／source rangeの公開実績は保持する。残る範囲は逆依存41 packageの実行、未annotation token推論、Environment、残るsampleと実Native／Web操作／表示。前回Style現状の「残る5 kind／factory／token合成」は今回の実装・検証を根拠に置換し、元SHA・初回2失敗・訂正理由は[履歴と原本](acceptance-evidence/task-flow-registry-execution.json)へ保持した。 |'
$status=(@($status -split $lf|ForEach-Object {if($_.StartsWith('| Style 指定値・token・構築処理 ')){$row}elseif($_.StartsWith('確認日 ')){$_.Replace('300162fe9b638be752b4661e1daf5bae85151081',$pub.commit)}else{$_}})) -join $lf
if(($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — 明示型付きStyle複合値のSource構築

Source $($pub.commit) をmainへ通常公開し、parent／tree／20 pathのblobとpatchを照合した。5つの複合value kindと非None Clip／Maskを既存native値へ接続した。typed signatureが引数順・名前・既定値を所有し、list順序、symbolic system color、exact whole-msとu32範囲、native transitionabilityを保持する。token定数は元sheet／宣言／initializerを使い、循環とnative深さ64を検査する。通常の同kind参照を保持し、BorderRadii文脈だけLengthをuniform cornersへ変換する。runtime cascadeの別resolverや値代数は作っていない。

初回owner45件は43 PASS／2 FAIL。テストがborder-radiusをBorderRadiiと誤認したが、既存registryと実resolverはLength shorthandを指定するため、symbolic Length参照と実cascadeを検証する期待へ訂正した。重複named argumentは既存HIR readinessで拒否されるため専用testで検証し、positional/named重複その他はtype-check拒否を維持した。production driftは0で新Compiler test pathだけを修正し、最終全46件がPASS（4.861秒、2559 filter SKIP、3914入力／catalog／実EXE drift0）。初回43件とsubsetの合算ではない。

全98 workspaceのlocked／all-target／all-feature check・Clippy、構造gate、fmtが終了0。その後の変更は構築moduleのimport整理1 pathだけで、Sema all-target／all-feature Clippyと明示19 Rust pathのfmtが終了0。metadataとtarget-all treeで一致したView逆依存41 packageの実行は後続で行い、owner46件を統合runと記さない。前回現状の「残る5 kind／factory／token合成」は今回の実装とowner結果で解消したため現状一覧から外した。未annotation token推論、Environment、sample移行と実Native／Web受入は未達として保持し、Generic Matchその他の既受入は変更しない。過去の数値／型／font/token結果と全SHAは履歴として保持した。

同日の明示依頼による全体cargo cleanは終了0、294059 files／399.1 GiBを削除した。旧EXE／AWFBの元pathはこのcleanで削除済みで、hashと実測は履歴に保持する。source・検証記録を消していない。既存144 registry propertyを値の全件照合で保持し、styleCompositeSourceCheckpointを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。build artifactをZIPへコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;owner=$owner.summary;archive=$entry.archive}|ConvertTo-Json -Depth 6|Set-Content "$r/style-composites-20261109.acceptance-record.json"
Get-Content "$r/style-composites-20261109.acceptance-record.json"

