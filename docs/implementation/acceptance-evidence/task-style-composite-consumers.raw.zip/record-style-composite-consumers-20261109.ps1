$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-composites-20261109.source-checkpoint.verified.json'
$noncli=Read-Record 'style-composites-integrated-20261109.noncli-r1.runtime.terminal-audit.json'
$cli=Read-Record 'style-composites-integrated-20261109.cli-r1.runtime.terminal-audit.json'
$old=Read-Record 'style-numeric-values-integrated-20261108.cli-r1.runtime.terminal-audit.json'
$main=Read-Record 'style-composites-integrated-20261109.cli-r1.main-audit.json'
$probe=Read-Record 'style-composites-20261109.native-r1.json'
$priorProbe=Read-Record 'style-numeric-values-20261108.native-r1.json'
$coverage=Read-Record 'style-composites-20261109.coverage.json'
if((git rev-parse HEAD).Trim() -ne '4907775d15b74747efe9154556c373ada7d01262'){throw 'Matrix recording base changed'}
if($noncli.actualExitCode -ne 0 -or $noncli.executed -ne 4677 -or $cli.executed -ne 711 -or $cli.failed -ne 4){throw 'Unexpected matrix result'}
if(@(Compare-Object @($old.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object) @($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)).Count){throw 'CLI failure set changed'}
if($probe.checkExitCode -ne 0 -or $probe.bundleExitCode -ne 0 -or $probe.main.sha256 -ne $main.sha256 -or $main.binaryDrift -ne 0 -or $probe.artifact.sha256 -ne $priorProbe.artifact.sha256){throw 'Native Source probe or tested CLI mismatch'}
if($coverage.missing -ne 0 -or $coverage.duplicates -ne 0){throw 'Coverage changed'}
$archive='docs/implementation/acceptance-evidence/task-style-composite-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(foreach($filter in @('style-composites-integrated-20261109*','style-composites-20261109.native-r1*')){Get-ChildItem -LiteralPath $r -File -Filter $filter|Where-Object {$_.Extension -in @('.json','.log')}})
$files+=@('style-composites-20261109.coverage.json','style-composites-20261109.selection-audit.json','run-style-composites-consumers-20261109.ps1','run-style-composites-cli-consumers-20261109.ps1','audit-style-composite-coverage-20261109.ps1','audit-style-composite-cli-failures-20261109.ps1','run-style-composite-native-source-probe-20261109.ps1','record-style-composite-consumers-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';productionPublication=$pub;recordingBase=(git rev-parse HEAD).Trim()
 status='Explicitly typed Style construction and token composition passed complete View reverse-dependency execution apart from the same four diagnosed CLI failures. Full Style/sample acceptance remains open.'
 qualityReuse='Reuse styleCompositeSourceCheckpoint quality, import-only correction and final fmt for unchanged production/test/fixture bytes. No new workspace quality invocation is claimed here.'
 nonCli=$noncli;cli=$cli;selection=(Read-Record 'style-composites-20261109.selection-audit.json')
 freshTotals=[ordered]@{executed=$noncli.executed+$cli.executed;passed=$noncli.passed+$cli.passed;failed=$noncli.failed+$cli.failed;skipped=$noncli.skipped+$cli.skipped;runtimeRuns=2;featurePoints=2;scope='Only current complete nonCLI-r1 and CLI-r1. Do not add owner46, initial owner failures, earlier numeric/Core matrices, or the separate Source probe.'}
 coverage=$coverage;failureDiagnostics=(Read-Record 'style-composites-integrated-20261109.failure-diagnostics.json')
 graphReuse='The 41-package View closure and metadata/target-all tree agreement are retained in styleCompositeSourceCheckpoint. NonCLI all features selects 40 packages, 37 with runtime cases; CLI uses defaults.'
 mainAudit=$main;nativeSourceProbe=$probe;matchesPriorCanonicalNativeBundle=$true
 nativeScope='Use the actual pinned CLI with no extra build. Native text input check and main-profile AWFB generation pass; 89 instructions/81840 bytes, byte-identical hash to prior Source300. This is not interactive Native/Web acceptance.'
 pending='Unannotated-token inference, Environment publication, remaining sample migration and actual Native/Web operation/capture parity. Scroll source admission, voice start and promotion proof failures remain open. Generic Match acceptance is unchanged.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 145 -or $prior.PSObject.Properties.Name -contains 'styleCompositeConsumers'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "styleCompositeConsumers": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$source=$pub.commit
$replacements=@{
 '| Style 指定値・token・構築処理 '=('| Style 指定値・token・構築処理 | **明示型付き構築・token合成を統合検証・公開** | Source '+$source+' で全25 kindと非None Clip／Maskの構築形を接続した。native値・typed引数／既定値・記述順・exact ms・sheet内token合成／uniform radii・循環／深さ上限を検証。border-radiusは既存のLength shorthandとsymbolic tokenを維持する。font／palette・元annotation／元宣言／codec／source rangeの公開実績も保持する。consumer・CLI・品質の最新実測は横断行に集約。native-text-inputは同じ実CLIでcheck／main-profile AWFB生成を再確認し、前回と同じcanonical生成物を得た。残る範囲は未annotation token推論、Environment、残るsampleと実Native／Web操作／表示。解消した旧列挙と元SHA・失敗・訂正理由は[履歴と原本](acceptance-evidence/task-flow-registry-execution.json)へ保持する。 |')
 '| 共有契約／推移的逆依存matrix '=('| 共有契約／推移的逆依存matrix | **新規5388実行：5384 PASS／4 FAIL／41 SKIP** | Source '+$source+'。metadata／target-all tree一致のView逆依存41 packageを、非CLI全feature40 packageとCLI既定へ分けた。非CLIは4677／4677 PASS・18 SKIP・772.782秒で、37 packageがruntime caseを持つ。caseのないarcweft／bundle-assets／render-webの3 packageはcompile検証の範囲とする。過去Core／HIR範囲をそれぞれ投影し、重複する旧caseの和集合4670件は欠落／重複0、改名1件を対応付けた。追加7件はCompiler5／Sema1／View1。Source／catalog／実EXE drift0。最終2 run／2 feature pointのみ集計し、owner46件・初回失敗・以前の全件件数・別Source probeは加算しない。[終端・選択・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
 '| CLIの規定対象／全 check 照合 '=('| CLIの規定対象／全 check 照合 | **Style複合値統合後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | Source '+$source+'、536.146秒。先行と同じ4失敗ID・実診断で、新規失敗0。Scrollのshared callable Expr15拒否、active dialogue has no voice、promotion2件のsolver到達前Expr8 type-check拒否は未解消。実CLI本体のSHA256はd84ab197818e9b8323542a4d2affe19bda37f773804ea65bb4f13521939ccd8bで、元pathの本体とtest EXEを前後照合した。別Source probeのnative-text-input check／main-profile bundle生成は同じ実CLIで終了0、89命令／81840 bytes、旧生成物hashと一致する。旧SourceのSHAと実測は履歴へ保持し、このprobeを711件へ加算しない。[診断・EXE pin・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
 '| workspace check／Clippy・fmt・構造gate '=('| workspace check／Clippy・fmt・構造gate | **Style複合値のworkspace gateは終了0** | Source '+$source+' の全98 package・全target・全feature・locked check／Clippy、構造gate、fmtが終了0（3914入力drift0、警告あり）。後続のproduction変更は構築moduleのimport整理1 pathだけで、Sema全target／feature Clippyと明示19 Rust pathのfmtが終了0。以後production／test／fixtureは変更せず、上記consumer matrixも同じSourceで終端照合した。今回の記録ではこの有効な品質結果を再利用し、再実行とは記さない。[gate・訂正理由・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
}
$replaced=0
$status=(@($status -split $lf|ForEach-Object {$line=$_;$match=@($replacements.Keys|Where-Object {$line.StartsWith($_)});if($match.Count -gt 1){throw 'Ambiguous status row'};if($match.Count){$replaced++;$replacements[$match[0]]}else{$line}})) -join $lf
if($replaced -ne 4 -or ($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Status scope changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — Style複合値の全View consumer照合

Source $source、記録基点4907775d15b74747efe9154556c373ada7d01262の同じproduction／test／fixtureを固定した。metadataとtarget-all treeが一致するView逆依存41 packageを、非CLI全feature40 packageとCLI既定1 packageに分けた。非CLIは4677／4677 PASS・18 SKIP・772.782秒、37 packageにruntime caseがあり、arcweft／bundle-assets／render-webの3 packageはcompile evidenceとして区別する。Scopeを前回HIRの23 packageから置換した理由は、今回native View componentの共有APIを変更したためであり、HIR自身の旧テストを今回実行したとは記さない。

CLIは711実行／707 PASS／4 FAIL／23 SKIP・536.146秒。同じ4失敗IDと、Scroll shared callable Expr15、voice absent、promotion Expr8の実診断を照合した。最終新規集計は5388実行／5384 PASS／4 FAIL／41 SKIP、2 run／2 feature pointだけで、owner46・初回owner失敗・旧Core／HIR件数を合算しない。旧Core範囲4657件と旧HIR範囲3612件は重複しており、今回へ投影した和集合4670件に欠落／重複0。過去のStyle Length改名1件を対応付け、追加はCompiler5／Sema1／View1の7件と確認した。

3914／3938のSource入力とcatalog／実test EXEの差分0。実CLI本体 $($main.sha256) は元target pathで実行前後に照合した。同じ本体を追加buildせず使い、native-text-inputのSource checkとmain-profile AWFB生成が終了0。元生成path $($probe.artifact.path) は89命令／81840 bytes、SHA256 $($probe.artifact.sha256) で以前のSource300生成物hashと一致する。これはinteractive Native／Web受入を意味しない。workspace gate・最終import Clippy／fmtはSource checkpointの有効な結果を再利用した。

現状一覧の旧5302件・基本値時点のCLI／品質説明を今回の範囲へ更新し、過去の実測と全SHAは履歴・registryに保持した。Styleの重複した件数説明は横断行へ集約した。未annotation token推論、Environment、sample移行、Scroll／voice／promotionと実Native／Web条件は具体的な未達として保持し、Generic Match等の既受入を戻さない。既存145 registry propertyを値の全件照合で保持し、styleCompositeConsumersを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。EXE／AWFBをZIPへコピーせず、元build pathで保持した。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;freshTotals=$entry.freshTotals;archive=$entry.archive}|ConvertTo-Json -Depth 6|Set-Content "$r/style-composites-20261109.consumer-acceptance-record.json"
Get-Content "$r/style-composites-20261109.consumer-acceptance-record.json"

