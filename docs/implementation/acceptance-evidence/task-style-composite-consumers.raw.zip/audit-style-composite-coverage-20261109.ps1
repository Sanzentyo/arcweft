$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$current=Get-Content "$r/style-composites-integrated-20261109.noncli-r1.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$graph=Get-Content "$r/style-composites-20261109.graph.json" -Raw|ConvertFrom-Json -Depth 30
$after=@($current.rows|Where-Object status -eq 'matches')
$keys=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $after){if(!$keys.Add(($row.binary+[char]0+$row.test))){throw 'Duplicate current case'}}
$oldName='final_analysis::tests::semantic_transcript_acceptance::expression_corpus::contextual_expressions::style_length_values_use_registered_roots_and_shared_scalar_reduction'
$newName='final_analysis::tests::semantic_transcript_acceptance::expression_corpus::contextual_expressions::style_length_values_use_specified_values_and_exact_decimal_scaling'
$known=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$baselines=@(
 [pscustomobject]@{source='70a050cc9cd0b94d83b79a295ec688bccd3b1d3b';catalog='string-read-operations-integrated-20261108.noncli-r2.catalog.inventory.json'},
 [pscustomobject]@{source='300162fe9b638be752b4661e1daf5bae85151081';catalog='style-numeric-values-integrated-20261108.noncli-r2.catalog.inventory.json'}
)
$records=@(foreach($baseline in $baselines){
 $inventory=Get-Content "$r/$($baseline.catalog)" -Raw|ConvertFrom-Json -Depth 20
 $before=@($inventory.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $graph.packages.name})
 $missing=@(foreach($row in $before){
  $name=if($row.test -ceq $oldName){$newName}else{$row.test}
  $key=$row.binary+[char]0+$name
  [void]$known.Add($key)
  if(!$keys.Contains($key)){$row}
 })
 if($missing.Count){$missing|ConvertTo-Json -Depth 8|Set-Content "$r/style-composites-20261109.coverage.missing.json";throw ('Retained case missing: '+$baseline.source)}
 [ordered]@{source=$baseline.source;catalog=$baseline.catalog;retainedInCurrentClosure=$before.Count;missing=0}
})
$additional=@($after|Where-Object {!$known.Contains(($_.binary+[char]0+$_.test))})
[ordered]@{
 version=1;source='eb4b9a820e7e74a106e4ca17405e50b642cb579b';currentSelected=$after.Count
 baselines=$records;baselineCountsAreOverlapping=$true;baselineUnionRetained=$known.Count;missing=0;duplicates=0
 additionalCurrentCases=$additional.Count;additionalByPackage=@($additional|Group-Object package|ForEach-Object {[ordered]@{package=$_.Name;cases=$_.Count}})
 rename=[ordered]@{old=$oldName;new=$newName;reason='The earlier numeric checkpoint moved Style Length to exact HIR scaling. Original values, negatives, ranges, units and ordinary numeric-root assertions are preserved.'}
 scope='Each earlier catalog is projected into the current View closure independently. Do not add overlapping baseline counts or call newly selected existing package tests newly authored tests. Actual runtime totals come only from this complete current matrix.'
}|ConvertTo-Json -Depth 12|Set-Content "$r/style-composites-20261109.coverage.json"
Get-Content "$r/style-composites-20261109.coverage.json"

