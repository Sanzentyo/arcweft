$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$publication=Get-Content -Raw -LiteralPath "$root\original-binding.publication.json"|ConvertFrom-Json
$pin=Get-Content -Raw -LiteralPath "$root\original-binding.final-input.json"|ConvertFrom-Json
$receipt=Get-Content -Raw -LiteralPath "$root\original-binding.final-receipt.json"|ConvertFrom-Json
if($receipt.Tree -ne $publication.Tree -or $receipt.RunExit -ne 0 -or $receipt.ClippyExit -ne 0 -or $receipt.FmtExit -ne 0 -or $receipt.Selected -ne 13){throw 'Evidence is incomplete'}
if(@(git -C 'D:\git\arcweft' diff --name-only 518d63e31dd2be9750158004b171a6174b2725a7 -- Cargo.toml Cargo.lock .cargo rust-toolchain.toml ':(glob)**/Cargo.toml').Count -ne 0){throw 'Cargo graph inputs changed'}
[ordered]@{
    Version=1;Source=$publication.Source;Tree=$publication.Tree
    Owner='arcweft-lang-sema::types::constraints::transaction::component'
    OriginalAuthority='Original frontiers retain source traces, applications, and binding maps. The read view borrows the exact selected root path and original lexical scope; no mutable producer is lent.'
    Coordinate='A typed Constraint(frontier,path) / Rejected / Ambiguous origin replaces flattened ordinals. Aliases and derived uses retain the same origin coordinate.'
    ScopeOwnership='One original scope allocation belongs to the producer definition, including unresolved branches. Available projections borrow the same immutable scope through Arc.'
    Measurements=$pin.Sources
    Cohesion='No file grows by 300 LOC or exceeds 1200 LOC; producer origin, its frozen scope and read protocol remain one private owner. No production visibility is widened for file splitting.'
    GraphReusedFrom='d20f11a7fa9762662df0cdbbe042670207b0177b'
    GraphArchive='task-retained-source-probe-preparation.raw.zip'
    GraphArchiveSHA256='412435c9c1315650bb8177d1e69135cc0612725177013e31b8b16b16fe2d7398'
    ClosurePackages=22;CargoInputsUnchanged=$true
    SelectedScope='All 13 private component tests, all-target/all-feature Sema Clippy and workspace fmt. No active frontend callsite or external consumer of the new view.'
    ReusedStructure='Prior ed5 source gate: blocking 0; no new scanner run claimed. No Cargo/dependency direction change or size/growth trigger in this cut.'
    Limitations='Read-only binding input is not joint binding agreement, producer eligibility/ranking completion, frontend integration or canonical publication.'
}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$root\original-binding.scope-and-ownership.json" -Encoding utf8
$files=[Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File|Where-Object {
    ($_.Name.StartsWith('original-binding.') -or $_.Name -eq 'make-original-binding-archive.ps1') -and
    $_.Name -notin @('original-binding.manifest.json','original-binding.archive.json','original-binding.docs-publication.json','original-binding.docs-audit.json')
}|Sort-Object Name|ForEach-Object {$files.Add(@{name=$_.Name;path=$_.FullName})}
$manifest=[ordered]@{
    version=1;source=$publication.Source;tree=$publication.Tree;base=$publication.Parent
    phases=@(
        @{name='initial-check';exit=101;selected=0;note='One production import and a test-only nonexistent empty effect-scope constructor; source snapshots, input hashes, patch and diagnostics retained.'},
        @{name='intermediate-selection';selected=13;passed=13;failed=0;note='Original view before typed-origin replacement; distinct input hashes and patch retained.'},
        @{name='final-selection';tree=$publication.Tree;selected=13;passed=13;failed=0;selectedOut=1521;note='Three new meaningful regressions passed; selected IDs match terminal IDs, duplicates 0. Not added to any full-owner count.'}
    )
    commands=@('CARGO_INCREMENTAL=0 cargo nextest list --locked -p arcweft-lang-sema --lib --all-features -E test(types::constraints::transaction::component::tests::) --message-format json','CARGO_INCREMENTAL=0 cargo nextest run --locked -p arcweft-lang-sema --lib --all-features -E test(types::constraints::transaction::component::tests::) --no-tests fail --no-fail-fast','CARGO_INCREMENTAL=0 cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features','CARGO_INCREMENTAL=0 cargo fmt --all --check')
    files=@($files|ForEach-Object {$item=Get-Item -LiteralPath $_.path;@{name=$_.name;bytes=$item.Length;sha256=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant()}})
}
$manifest|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$root\original-binding.manifest.json" -Encoding utf8
$files.Add(@{name='manifest.json';path="$root\original-binding.manifest.json"})
$archivePath='D:\git\arcweft\docs\implementation\acceptance-evidence\task-original-value-binding-inputs.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive exists'}
$zip=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.path,$file.name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    if($zip.Entries.Count -ne $files.Count){throw 'Archive entry count mismatch'}
    foreach($file in $files){
        $entry=$zip.GetEntry($file.name);$item=Get-Item -LiteralPath $file.path
        if($null -eq $entry -or $entry.Length -ne $item.Length){throw 'Archive entry length mismatch'}
        $stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -ne (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Archive entry hash mismatch'}
    }
    $rawBytes=($zip.Entries|Measure-Object Length -Sum).Sum
}finally{$zip.Dispose()}
$archive=Get-Item -LiteralPath $archivePath
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=$files.Count;RawBytes=$rawBytes;Bytes=$archive.Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();EveryEntryVerified=$true}|ConvertTo-Json|Set-Content -LiteralPath "$root\original-binding.archive.json" -Encoding utf8
Get-Content -LiteralPath "$root\original-binding.archive.json"
