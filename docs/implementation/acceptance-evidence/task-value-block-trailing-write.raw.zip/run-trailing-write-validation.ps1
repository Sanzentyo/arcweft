$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='value-block-trailing-write-20261107'
$owner=Get-Content "$taskTemp/$prefix.owner-final.receipt.json" -Raw|ConvertFrom-Json
if($owner.exitCode -ne 0){throw 'Owner validation failed'}
$previous=Get-Content "$taskTemp/flow-defer-registry-20261107.source-freeze.json" -Raw|ConvertFrom-Json
$paths=@(foreach($path in @($previous.paths.path+'docs/01-language/block-scopes.md'|Sort-Object -Unique)){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$base=(&git rev-parse HEAD).Trim()
[ordered]@{version=1;head=$base;at=[DateTime]::UtcNow.ToString('o');paths=$paths}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.source-freeze.json" -Encoding utf8
$cargo=@($paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'})
$oldCargo=@{};foreach($row in $previous.paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'}){$oldCargo[$row.path]=$row.sha256}
if(@($cargo|Where-Object {$oldCargo[$_.path] -ne $_.sha256}).Count){throw 'Metadata inputs changed'}
$graph=Get-Content "$taskTemp/awbc-defer-runnable-20261107.metadata-reverse-union.json" -Raw|ConvertFrom-Json
if($graph.syntax.Count -ne $graph.syntaxPackages){throw 'Incomplete syntax reverse graph'}
[ordered]@{version=1;sourceBase=$base;metadata='function-scope-20261107.metadata-all.json';cargoInputs=$cargo.Count;cargoDrift=0;resolvedReversePackages=$graph.syntax.Count;packages=$graph.syntax}|ConvertTo-Json -Depth 6|Set-Content "$taskTemp/$prefix.graph.json" -Encoding utf8
& cargo tree --locked --workspace --invert arcweft-lang-syntax *> "$taskTemp/$prefix.reverse.tree.log"
if($LASTEXITCODE -ne 0){throw 'Reverse graph inspection failed'}
$rustPaths=@(Get-Content "$taskTemp/$prefix.source.owned.txt"|Where-Object {$_ -like '*.rs'})
& rustfmt --edition 2024 --config skip_children=true --check @rustPaths *> "$taskTemp/$prefix.fmt.log"
$fmtCode=$LASTEXITCODE
[ordered]@{version=1;arguments=@('--edition','2024','--config','skip_children=true','--check')+$rustPaths;exitCode=$fmtCode}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.fmt.receipt.json" -Encoding utf8
if($fmtCode -ne 0){exit $fmtCode}
foreach($check in @(
 @{name='workspace-check';arguments=@('check','--locked','--workspace','--all-targets','--all-features')},
 @{name='workspace-clippy';arguments=@('clippy','--locked','--workspace','--all-targets','--all-features')},
 @{name='structure';arguments=@('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')}
)){
 $started=[DateTime]::UtcNow;$arguments=$check.arguments
 & cargo @arguments *> "$taskTemp/$prefix.$($check.name).log"
 $code=$LASTEXITCODE
 [ordered]@{version=1;arguments=$arguments;exitCode=$code;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.$($check.name).receipt.json" -Encoding utf8
 Write-Output ($check.name+': exit '+$code)
 if($code -ne 0){exit $code}
}
$started=[DateTime]::UtcNow
$filter='rdeps(=arcweft-lang-syntax)'
$listArguments=@('nextest','list','--locked','--workspace','--lib','--tests','-E',$filter,'--message-format','json')
for($attempt=0;$attempt -lt 2;$attempt++){
 & cargo @listArguments > "$taskTemp/$prefix.reverse-list-$attempt.json" 2> "$taskTemp/$prefix.reverse-list-$attempt.stderr.log"
 $code=$LASTEXITCODE
 [ordered]@{version=1;sourceBase=$base;arguments=$listArguments;attempt=$attempt;exitCode=$code;phase='Build/list before tests';at=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse-list-$attempt.receipt.json" -Encoding utf8
 if($code -eq 0){break}
 if(!(Select-String -LiteralPath "$taskTemp/$prefix.reverse-list-$attempt.stderr.log" -Pattern '1455' -Quiet)){exit $code}
}
if($code -ne 0){exit $code}
$list=Get-Content "$taskTemp/$prefix.reverse-list-$attempt.json" -Raw|ConvertFrom-Json -Depth 100
$selected=@(foreach($binary in $list.'rust-suites'.PSObject.Properties){foreach($test in $binary.Value.testcases.PSObject.Properties){if($test.Value.'filter-match'.status -eq 'matches'){[pscustomobject][ordered]@{package=$binary.Value.'package-name';binary=$binary.Value.'binary-name';test=$test.Name}}}})
if(!$selected.Count){throw 'Empty reverse selection'}
$selected|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.selection.json" -Encoding utf8
$arguments=@('nextest','run','--locked','--workspace','--lib','--tests','-E',$filter,'--no-tests','fail','--no-fail-fast')
& cargo @arguments *> "$taskTemp/$prefix.reverse.log"
$code=$LASTEXITCODE
$drift=@($paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
$summary=@(Select-String -LiteralPath "$taskTemp/$prefix.reverse.log" -Pattern 'Summary \['|ForEach-Object {$_.Line})
[ordered]@{version=1;sourceBase=$base;filter=$filter;listArguments=$listArguments;successfulListAttempt=$attempt;arguments=$arguments;listExitCode=0;filterMatchedTests=$selected.Count;exitCode=$code;sourceInputs=$paths.Count;sourceDrift=$drift;cargoInputs=$cargo.Count;cargoDrift=0;summary=$summary;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.receipt.json" -Encoding utf8
$summary|Write-Output
if($drift){throw 'Source changed during matrix'}
exit $code
