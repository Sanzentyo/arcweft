$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='value-block-trailing-write-20261107'
$source=Get-Content "$taskTemp/$prefix.source.verified.json" -Raw|ConvertFrom-Json
$fixtureSource=Get-Content "$taskTemp/$prefix.assignment-source.verified.json" -Raw|ConvertFrom-Json
$matrix=Get-Content "$taskTemp/$prefix.reverse.receipt.json" -Raw|ConvertFrom-Json
if((&git rev-parse HEAD).Trim() -ne $fixtureSource.commit -or $fixtureSource.parent -ne $source.commit -or $matrix.sourceDrift -ne 0 -or $matrix.listExitCode -ne 0){throw 'Unfinished or changed validation'}
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
$changed=@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
$fixtureInput=Get-Content "$taskTemp/$prefix.assignment-input.json" -Raw|ConvertFrom-Json
if($changed.Count -ne 1 -or $changed[0].path -ne $fixtureInput.path -or (Get-FileHash -LiteralPath $fixtureInput.path).Hash.ToLowerInvariant() -ne $fixtureInput.sha256){throw 'Unexpected delta after broad run'}
$fixtureOwner=Get-Content "$taskTemp/$prefix.assignment-owner-fixed.receipt.json" -Raw|ConvertFrom-Json
$fixtureClippy=Get-Content "$taskTemp/$prefix.assignment-clippy-final.receipt.json" -Raw|ConvertFrom-Json
$fixtureFmt=Get-Content "$taskTemp/$prefix.assignment-fmt.receipt.json" -Raw|ConvertFrom-Json
if($fixtureOwner.exitCode -ne 0 -or $fixtureClippy.exitCode -ne 0 -or $fixtureClippy.testInputDrift -ne 0 -or $fixtureFmt.exitCode -ne 0){throw 'Fixture repair validation failed'}
$untracked=Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json
if(@($untracked.files|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Original untracked files changed'}
$selected=Get-Content "$taskTemp/$prefix.reverse.selection.json" -Raw|ConvertFrom-Json
$log=[IO.File]::ReadAllText("$taskTemp/$prefix.reverse.log")
$failed=@([regex]::Matches($log,'(?m)^\s*FAIL\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+([^\r\n]+)')|ForEach-Object {[pscustomobject]@{binary=$_.Groups[1].Value;test=$_.Groups[2].Value}}|Sort-Object test -Unique)
$expected=@('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering','spec_valid_run_edge_fixture_now_executes','verify_json_records_required_solver_checks','verify_json_reports_missing_promotion_proof','final_analysis::tests::assignment_semantics_reject_non_direct_or_non_nominal_places_and_type_mismatch')
if(@(Compare-Object @($failed.test|Sort-Object) @($expected|Sort-Object)).Count){throw 'New failures need investigation'}
if(($matrix.summary -join "`n") -notmatch '(\d+) tests run: (\d+) passed.*?(\d+) failed.*?(\d+) skipped'){throw 'Unknown terminal summary'}
$counts=[ordered]@{run=[int]$Matches[1];passed=[int]$Matches[2];failed=[int]$Matches[3];skipped=[int]$Matches[4]}
if($counts.run -ne $selected.Count -or $counts.failed -ne $failed.Count){throw 'Count mismatch'}
foreach($name in @('value_block_trailing_registry_writes_keep_statement_and_omitted_tail_identity','value_block_trailing_place_assignment_keeps_its_statement_identity','value_block_nested_operators_do_not_replace_record_or_expression_tails','value_block_trailing_registry_write_retains_missing_initializer_recovery','trailing_registry_write_is_an_ordinary_statement_in_cleanup_value_blocks')){if($log -notmatch ('(?m)^\s*PASS\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+\S+\s+[^\r\n]*'+[regex]::Escape($name)+'\s*$')){throw "Missing broad regression pass: $name"}}
$quality=[ordered]@{}
foreach($name in @('fmt','workspace-check','workspace-clippy','structure')){$r=Get-Content "$taskTemp/$prefix.$name.receipt.json" -Raw|ConvertFrom-Json;if($r.exitCode -ne 0){throw "Failed quality: $name"};$quality[$name]=$r}
$names=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*"|Where-Object {$_.Name -notmatch '\.(compiler-test|syntax-tests)\.rs$|\.production\.patch$|\.(message|other|owned)\.txt$|\.pathspec$|\.docs\.'}|ForEach-Object {$_.Name})
$names+=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter 'awbc-defer-goto-probe-20261107*'|ForEach-Object {$_.Name})
$names+=@('run-trailing-write-validation.ps1','record-trailing-write.ps1','function-scope-20261107.metadata-all.json')
$names=@($names|Sort-Object -Unique)
$zipPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-value-block-trailing-write.raw.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Evidence archive already exists'}
Compress-Archive -LiteralPath @($names|ForEach-Object {"$taskTemp/$_"}) -DestinationPath $zipPath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{foreach($entry in $archive.Entries){$row=$entries|Where-Object entry -eq $entry.FullName;$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($row.bytes -ne $entry.Length -or $row.sha256 -ne $hash){throw 'Archive content mismatch'}};if($archive.Entries.Count -ne $entries.Count){throw 'Archive entry mismatch'}}finally{$archive.Dispose()}
$cliCount=@($selected|Where-Object package -eq 'arcweft-cli').Count
$cliFailed=@($failed|Where-Object binary -eq 'arcweft-cli::check')
$nonCliFailed=@($failed|Where-Object binary -ne 'arcweft-cli::check')
$record=[ordered]@{
 version=1;date='2026-11-07';source=$source
 behavior='The value-block statement/tail decision reuses the existing typed statement classifier for AssignmentStatement and LifetimeSetStatement. A trailing write remains a statement with an omitted Unit tail. Record literals, operators inside calls/strings, normal expression tails and value-shaped if/loop/match/thread heads retain their original grammar. No new parser, source reconstruction, semantic side table, runtime opcode or contract version.'
 reproduction=@{cli=(Get-Content "$taskTemp/$prefix.original.receipt.json" -Raw|ConvertFrom-Json);syntax=(Get-Content "$taskTemp/$prefix.syntax-repro.receipt.json" -Raw|ConvertFrom-Json);passed=1;failed=3;initialTestHarnessBuild=(Get-Content "$taskTemp/$prefix.syntax-before.receipt.json" -Raw|ConvertFrom-Json);harnessCorrection='The first test build used the typed grammar kind where Rowan exposes a raw kind. Correct that test conversion before collecting the 1-pass/3-fail behavioral baseline; preserve the initial E0308 log as a harness failure.'}
 owner=@{syntaxPassed=752;syntaxReceipt=(Get-Content "$taskTemp/$prefix.syntax-final.receipt.json" -Raw|ConvertFrom-Json);scopedDeferPassed=24;scopedDeferReceipt=(Get-Content "$taskTemp/$prefix.owner-final.receipt.json" -Raw|ConvertFrom-Json);note='Owner selections are separate compositions and are not added to the broad run.'}
 conditions='Compact, LF and CRLF cleanup bodies execute in Native and canonical-decoded AWBC at one operation per step; each Product step uses public save and cold restore. Exact true logs observe the reached registry write. Syntax tests retain missing-initializer recovery at the exact zero-width closing-brace span and distinguish indexed-place assignment, record literal and nested-call/string operators.'
 cliRepaired=(Get-Content "$taskTemp/$prefix.fixed.receipt.json" -Raw|ConvertFrom-Json)
 graph=(Get-Content "$taskTemp/$prefix.graph.json" -Raw|ConvertFrom-Json);matrix=$matrix;counts=$counts;actualPackages=@($selected.package|Sort-Object -Unique).Count;cli=@{run=$cliCount;passed=$cliCount-$cliFailed.Count;failed=$cliFailed.Count;remaining=$cliFailed};nonCli=@{run=$selected.Count-$cliCount;passed=$selected.Count-$cliCount-$nonCliFailed.Count;failed=$nonCliFailed.Count;failuresInBroadRun=$nonCliFailed};quality=$quality
 fixtureRepair=@{source=$fixtureSource;owner=$fixtureOwner;passed=1;caseCount=5;clippy=$fixtureClippy;fmt=$fixtureFmt;input=$fixtureInput;firstAttempt=(Get-Content "$taskTemp/$prefix.assignment-owner.receipt.json" -Raw|ConvertFrom-Json);reason='The broad run exposed a stale HIR-rejection expectation. Require all five inputs to enter HIR and fail specifically with WrongPayloadFamily at the checked semantic boundary; remove the recovery skip. Parenthesize the actual declared entity receiver so the field is not lexed as an undeclared longer entity ID. Use a mutable nominal base to isolate the RHS type mismatch. The first repair attempt exposed the old entity-ID mistake; preserve its ValueResolutionFailed log. Only the test method changes; production and other broad inputs are unchanged.';earlyClippyLimit='The earlier assignment-clippy attempt overlapped the final test input edit, so only assignment-clippy-final is attributed to the published fixture bytes. Both logs remain raw history.';scope='A test-only repair uses the exact affected nextest case in full workspace --lib --tests composition and Sema all-target/all-feature Clippy. This is one passing test with five conditions, not a rerun of the broad matrix or all Sema tests.'}
 inputIdentity=@{preRunInputs=$freeze.paths.Count;matrixDriftAtEnd=0;rootFixtures=@($freeze.paths|Where-Object path -like 'tests/*').Count;cargoInputs=$matrix.cargoInputs;cargoDrift=0;subsequentTestOnlyDelta=$changed;fixtureInput=$fixtureInput;otherBroadInputDrift=0;originalTrackedWip=$source.heldPatchSha256;originalUntrackedFiles=$untracked.files.Count;untrackedDrift=0}
 ownerMetrics=(Get-Content "$taskTemp/$prefix.owner-metrics.json" -Raw|ConvertFrom-Json)
 ownershipReview='The existing statement classifier remains the syntax authority; only the existing block-sequence discriminator consumes two more statement shapes. Its 4-LOC growth preserves the current parser responsibility. Existing function grammar and compiler scoped-defer harnesses own the regression coverage. No dependency, facade, public API or second state authority is added.'
 correction='Supersedes the current remaining-work listing for semicolon-free trailing-write HIR recovery: the former valid source now compiles and runs under both CLI executors, with Native/public-save AWBC source tests. Required-read static presence remains a separate condition. Remove this resolved syntax condition from current-status while retaining its original failures, exact source and full commit history. Generic Match and all accepted Native boundaries remain accepted.'
 nextGotoProbe=@{first=(Get-Content "$taskTemp/awbc-defer-goto-probe-20261107.receipt.json" -Raw|ConvertFrom-Json);function=(Get-Content "$taskTemp/awbc-defer-goto-probe-20261107.function.receipt.json" -Raw|ConvertFrom-Json);audit=(Get-Content "$taskTemp/awbc-defer-goto-probe-20261107.audit.json" -Raw|ConvertFrom-Json);current=(Get-Content "$taskTemp/awbc-defer-goto-probe-20261107.current.receipt.json" -Raw|ConvertFrom-Json);interpretation='Exact binary identities are retained. The initial CLI predates this parser cut and is not relabeled; all six probes were also rerun with the rebuilt Source24 CLI. All zero exit codes and Done statuses are insufficient: AWBC loses root cleanup for static/dynamic goto and both function/caller cleanup for goto from a function. Native retains all three exact sequences. These are concrete pending AWBC conditions; do not reopen Native acceptance.'}
 limits='The broad matrix has five failures: four CLI and one stale Sema fixture. The Sema fixture is subsequently repaired and its one exact test passes; do not relabel the full matrix as four failures or combine the runs into a synthetic aggregate. This cut does not accept AWBC goto/Choice, direct AWBC return from open scopes, Line-affine cleanup captures, aggregate spawn preflight, promotion/MustDrop proofs, Native public saves, other-platform or ignored Tier2 execution. Prior Core53 results retain Source36 identity.'
 raw=@{path='task-value-block-trailing-write.raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$entries}
}
$jsonPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($jsonPath)
if($before.Contains('"valueBlockTrailingWriteStatements"')){throw 'Duplicate evidence section'}
$fragment=([ordered]@{valueBlockTrailingWriteStatements=$record}|ConvertTo-Json -Depth 70).Trim()
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($jsonPath,$after,[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-07 — Trailing writes retain statement identity in value blocks

Production **$($source.commit)**、parent **$($source.parent)** と、fixture **$($fixtureSource.commit)** を既存mainへ通常commit/pushし、4+1 pathのtree／blob／完全差分を照合した。既存tracked 12 pathとuntracked 6 fileは保持した。
元のCLI入力はHIR recoveryで停止し、構文回帰4件は修正前に1 PASS／3 FAIL。最初のテストbuildのE0308はRowanのraw kindと型付きkindの比較を直した後に再現を採取しており、本番の失敗と混同しない。value block末尾の通常代入／registry書込みを既存の文分類で保持し、Unit tailの省略へ接続した。recordやcall内の演算子、通常の式tail、欠落初期値の正確な0幅recoveryを保つ。
Syntax全752件とscoped_defer全24件は通過。compact／LF／CRLFをNativeとdecoded AWBCで1 opずつ実行し、AWBCは毎step公開保存からcold restoreした。元のCLI入力も同じ64-op／8-step条件で両実行器がDoneとなった。workspace全target／全feature check／Clippy、fmt、構造gateは終了0。
Syntaxの全25逆依存をworkspace既定featureで実行し、$($counts.run)件中$($counts.passed) PASS／$($counts.failed) FAIL／$($counts.skipped) SKIP。CLIは${cliCount}件中$($cliCount-$cliFailed.Count) PASS／4 FAIL、非CLIは$($selected.Count-$cliCount)件中$($selected.Count-$cliCount-$nonCliFailed.Count) PASS／1 FAIL。Semaの旧fixtureはHIR拒否を期待して停止していた。5不正入力を必ずHIRへ通し、checked semantic authorityのWrongPayloadFamilyで拒否する検査へ訂正した。entity receiverを括弧で区切って実在宣言を使い、RHS不一致はmutableなnominal baseで単独に検査する。修復後の同じworkspace構成の対象1件はPASS、Sema全target／全feature Clippyとfmtは終了0。広域5 FAILを4 FAILの再実行に書き換えず、先行752件／24件・前Core53 matrixとも合算しない。
広域run終了時のroot fixture180件と現行仕様を含む$($freeze.paths.Count)入力、Cargo100入力はdrift0。その後の変更は当該Sema test methodの1 pathだけで、他の広域入力は不変。修正済みの入力を固定した最終Clippy／公開時も差分0。最初のfixture修復で露出したValueResolutionFailedと、編集に重なった先行Clippyの適用限界も原本へ保持した。
現状一覧の末尾書込みHIR recoveryは解消として置換し、元の診断・失敗・SHAは履歴へ保持した。次のgoto probeはDoneだけで判定せずログを照合し、AWBCのstatic／dynamic gotoでouter cleanup、関数内gotoでfunction／outer cleanupの欠落を確認した。各CLIの元binary identityを保持し、Nativeの受入を戻さない。Generic Matchも受入・公開済みを維持する。
[修正前後・原本・全公開SHA](acceptance-evidence/task-flow-registry-execution.json)。
"@
[IO.File]::AppendAllText('D:/git/arcweft/docs/implementation/convergence-evidence-history.md',$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$lines=[IO.File]::ReadAllLines($statusPath)
$updated=foreach($line in $lines){
 if($line.StartsWith('| 共有契約／推移的逆依存matrix |')){'| 共有契約／推移的逆依存matrix | **Syntax逆依存25パッケージ：'+$counts.passed+' PASS／5 FAIL／'+$counts.skipped+' SKIP。Semaの1件は後続fixture修復で対象PASS** | Production `'+$source.commit+'` の'+$counts.run+'件をWindowsのworkspace既定feature、lib／integrationで実行。非CLIは'+($selected.Count-$cliCount-$nonCliFailed.Count)+' PASS／1 FAIL。fixture `'+$fixtureSource.commit+'` は5不正代入をSemaで必ず拒否する検査へ直し、同じworkspace構成の対象1件がPASS。広域を4 FAILへ書き換えず、先行ownerや前Core53 matrixも合算しない。[Source・全選択・修復・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 elseif($line.StartsWith('| CLIの規定対象／全 check 照合 |')){'| CLIの規定対象／全 check 照合 | **workspace既定CLI '+$cliCount+'件：'+($cliCount-$cliFailed.Count)+' PASS／4 FAIL** | Source `'+$source.commit+'`、上記Syntax逆依存runの内数。未解消はauthored Scrollの意味解析、必須VoiceHandleに実音声がない実行、promotion証明／solverの2件。以前の監査・取消しcleanup・scalar修復もPASSを維持する。完全な失敗ID・入力・診断は[実測](acceptance-evidence/task-flow-registry-execution.json)に保持する。 |'}
 elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){'| workspace check／Clippy・fmt・構造gate | **workspace全target・全feature check／Clippy、fmt、構造gateは終了0** | Production `'+$source.commit+'` の変更3 Rust pathをformat確認し、block末尾判定とtyped recoveryを検証した。後続fixture `'+$fixtureSource.commit+'` はSema全target／全feature Clippyと1 pathのfmtが終了0。警告・review triggerは原本に保持。Core doctest80件は該当入力不変のSource `1d60c0bcd12d0142f2eb1cc713115d495bfc5486` の結果として保持する。他platform／Tier2の受入へ拡張しない。[実測・全公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 elseif($line.StartsWith('| 通常 Flow の scoped defer |')){$line.Replace('AWBCのgoto／Choice、','AWBCのgotoはstatic／dynamicで本体root cleanup、関数内でfunction／caller cleanupが抜けることを実CLIで再現した。Choice、')}
 else{$line}
}
[IO.File]::WriteAllText($statusPath,($updated -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;counts=$counts;cli=$cliCount;entries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json -Depth 5
