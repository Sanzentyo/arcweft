$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Receipt([string]$name) {
    Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100
}
$source = Read-Receipt 'checkpoint-layout-presence-lints.verified'
if ($source.commit -ne (git rev-parse HEAD).Trim()) { throw 'Source publication changed' }
$terminal = Read-Receipt 'layout-presence-reverse1-20261104.runtime.terminal-audit'
$comparison = Read-Receipt 'layout-presence-result-comparison'
$graph = Read-Receipt 'layout-presence.graph'
$metadata = Read-Receipt 'layout-presence.metadata'
$initial = Get-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-rich-text-layout-presence.json' -Raw | ConvertFrom-Json -Depth 100
$coverage = @(Read-Receipt 'layout-presence-native-aux-coverage')
$auxiliaryCases = @($coverage.cases | Sort-Object binary,test -Unique)
if ($terminal.executed -ne 4815 -or $terminal.passed -ne 4801 -or $terminal.failed -ne 14 -or $auxiliaryCases.Count -ne 16) { throw 'Observed totals changed' }
$qualityNames = @(
    'layout-presence-final1-quality-check', 'layout-presence-final1-quality-clippy',
    'layout-presence-final1-quality-structure', 'layout-presence-final1-fmt',
    'layout-presence-final2-quality-check', 'layout-presence-final2-quality-clippy',
    'layout-presence-final2-quality-structure', 'layout-presence-final2-fmt'
)
$quality = @(foreach ($name in $qualityNames) { $receipt = Read-Receipt $name; if ($receipt.exitCode -ne 0) { throw "Gate failed: $name" }; [ordered]@{receipt=$name;result=$receipt} })
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$historyBytes = [IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix = [ordered]@{bytes=$historyBytes.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBytes)).ToLowerInvariant()}
$statusPath = 'docs/implementation/current-status.md'
$oldStatusLines = [IO.File]::ReadAllLines((Join-Path $PWD $statusPath))
$oldRows = @($oldStatusLines | Where-Object { $_ -match '^\| (RichTextの部分layout指定|Generic Match|共有契約／推移的逆依存matrix|CLI全target照合|workspace check／Clippy)' })
[ordered]@{version=1;head=$source.commit;supersededCurrentRows=$oldRows;reason='Replace the checkpoint and old latest/composite CLI description with a fresh complete 4815-case run. Historical counts, SHAs and failure outputs remain in their original evidence.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskTemp/layout-presence-status-before.json" -Encoding utf8
$measurements = @(foreach ($path in (Get-Content -LiteralPath "$taskTemp/layout-presence.owned-rust.txt")) {
    $lines = [IO.File]::ReadAllLines((Join-Path $PWD $path))
    $old = git show "c7b4b1c471ab25c1c839f325922ad06822e5d2ba:$path" 2>$null
    $package = $metadata.packages | Where-Object name -eq ($path -split '/')[1]
    $testStart = ($lines | Select-String '^mod tests \{' | Select-Object -First 1).LineNumber
    [ordered]@{path=$path;package=$package.name;bytes=(Get-Item -LiteralPath $path).Length;physicalLoc=$lines.Length;previousLoc=@($old).Count;classification=$(if($path -match '^crates/[^/]+/tests/'){ 'integration-test' }elseif($path -match '/tests/|/tests\.rs$'){ 'unit-test-module' }elseif($path.EndsWith('/lib.rs')){ 'facade' }else{ 'production' });embeddedTestLoc=$(if($testStart){$lines.Length-$testStart+1}else{0});fanIn=@($metadata.resolve.nodes | Where-Object {$package.id -in $_.deps.pkg}).Count;fanOut=@(($metadata.resolve.nodes | Where-Object id -eq $package.id).deps).Count}
})
$measurements | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/layout-presence-owner-measurements.json" -Encoding utf8
$untrackedBefore = (Read-Receipt 'task-documentation-final-untracked-before').files
$untrackedDrift = @($untrackedBefore | Where-Object { !(Test-Path -LiteralPath $_.path) -or (Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256 })
if ($untrackedDrift.Count) { throw 'Original untracked files changed' }
. "$taskTemp/write-verified-evidence-archive.ps1"
$archivePath = 'docs/implementation/acceptance-evidence/task-rich-text-layout-presence.raw.zip'
$files = @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object { $_.Name -like 'layout-presence*' -and $_.Extension -ne '.zip' -and $_.Name -ne 'layout-presence-final1-quality.changed-owner-warnings.json' })
$files += @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object { $_.Name -like 'checkpoint-layout-presence*' })
foreach ($directory in @('layout-presence-final1-quality.structure-report','layout-presence-final2-quality.structure-report')) { $files += @(Get-ChildItem -LiteralPath "$taskTemp/$directory" -File -Recurse) }
$files += @(foreach ($name in @('record-layout-presence.ps1','run-presentation-projection-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')) { Get-Item -LiteralPath "$taskTemp/$name" })
$raw = Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $archivePath))) $files
$raw.path = $archivePath
$record = [ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$source.commit
    state='Sparse authored layout contribution boundary validated and published; this is not whole-engine or source-factory acceptance'
    source=[ordered]@{checkpoint='726323d1edc63a6a543f7b8b817570ecc2ea2b3e';final=$source;checkpointValidation=$initial.initialValidation;finalRefinement='Three paths: reuse the existing optional-length projection, move the test visitor, add two semicolons; public shape and dependencies unchanged'}
    acceptedBoundary=@('Omitted authored layout properties inherit active style contributions','Explicit default-valued layout properties override inherited nondefaults','Ruby typography without a selector does not manufacture ruby placement','Resolved text direction and writing mode honor explicit resets','Empty layout updates preserve absent/inherited layout and sparse JSON round trips')
    reverse=[ordered]@{roots=$graph.roots;edgeKinds=$graph.edgeKinds;packages=$graph.packages;workspacePackages=$metadata.workspace_members.Count;result=$terminal;caseComparison=$comparison;nativeAuxiliary=[ordered]@{recipe='just/verify.just:test-native-aux-capture';coveredTargets=10;distinctFreshCases=$auxiliaryCases;separateRepeat='not run; the same cases are already part of the complete reverse execution'}}
    quality=[ordered]@{receipts=$quality;broadScope='All 98 workspace packages, all targets/features/locked on checkpoint bytes; final private/test-only three-path refinement receives compiler/text-model all-target/all-feature checks plus the complete final-byte reverse execution';changedLineWarnings=(Read-Receipt 'layout-presence-final2-quality.changed-line-warnings');warningsElsewhere='retained; no claim of a warning-free workspace';doctests='not rerun: no executable Rust documentation changed';wasmDedicatedCheck='not rerun; no new cross-platform execution claim'}
    clean=$initial.clean
    preserved=[ordered]@{trackedPaths=12;patchSha256=$source.heldPatchSha256;untrackedPaths=6;untrackedHashDrift=0;historyPrefixBeforeAppend=$historyPrefix}
    ownerReview=@(
        'Text-model owns sparse authored presence and resolved layout as distinct data roles. Layout updates apply on their owning type; no I/O or extra schema authority is introduced.',
        'Compiler lower.rs remains the existing accepted-semantics projection bridge (10639 physical LOC). This cut changes only its layout projection and reuses the private length path; it adds no independent state or wider public API. Keep this cohesive bridge for this cut.',
        'Compiler project/tests.rs only registers the new 73-line child test module; source compilation and observed cascade behavior stay in that child, without exposing production APIs for file splitting.',
        'Sema dialogue_line_plan.rs retains checked Content parameter origin from the already accepted call operands. Its existing line-plan ownership remains cohesive; dependency direction is unchanged.',
        'Render-text resolved_document.rs keeps resolved text style application with its owning type. Player/WGPU/capture fixtures migrate their existing explicit values and preserve all assertions. Historical size triggers are not blocking dependency violations.'
    )
    measurements=$measurements
    supersedes=[ordered]@{currentDescription='The old latest CLI 676 PASS/22 FAIL plus eight disjoint focused passes is replaced by a new complete fresh CLI 684 PASS/14 FAIL result; it is not arithmetic reuse';previousEvidence=@('task-cli-bench-headless-fixture.json','task-cli-jlreq-fixture-sizing.json','task-cli-jlreq-hyphen-boundary.json');failureComparison='Same 14 failed IDs, zero added/removed; cause equivalence is not inferred from IDs'}
    acceptanceScope='No source-factory execution, selector-independent property storage, first-class factory argument-order, full provenance or RAG acceptance is claimed here. Current work is listed only in docs/implementation/current-status.md.'
    raw=$raw
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-rich-text-layout-presence.json' -Encoding utf8
$replacements = @{}
$replacements['RichTextの部分layout指定／source factory'] = '| RichTextの部分layout指定／source factory | **部分layout指定を検証・公開済み。source factory接続は継続中** | Source 726323d1edc63a6a543f7b8b817570ecc2ea2b3e、最終638d6459bf68b4679349f2bfccc03f53d1878d26。authored updateと解決済みlayoutを分け、記述した値とschema defaultを区別する。ruby sizeだけの指定で既存配置・gap・書字方向を保持し、明示horizontal／auto／既定gapを反映する5回帰が5／5新規PASS。empty updateとsparse JSONも検証した。RAGの実失敗はsema.call.unknown_targetのtext_styleであり、accepted-semantic checkerは迂回しない。factory登録・構築前admission、共通property identity、first-class引数順、static inline_stylesを含む出典の未達は別の継続範囲とする。初期4 PASS・全件14 FAIL・全SHA・cleanの[原本と受入範囲](acceptance-evidence/task-rich-text-layout-presence.json)を保持する。 |'
$replacements['Generic Match `.1.2` C3/C5'] = '| Generic Match `.1.2` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。完全transcript、uninhabited-domain、Never／let-else継続、exhaustive-only atomic publicationの受入を維持する。[元の受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)。Source 638d6459bf68b4679349f2bfccc03f53d1878d26のSema／text-model全35逆依存で、同じ151 IDが151／151新規PASS。[最新のcase照合](acceptance-evidence/task-rich-text-layout-presence.json)。先行cd17eba41b99c837432722c6570f60f4287696e3の151 PASS／再利用証明と以前のfixture移行・初回失敗は各[検証履歴](convergence-evidence-history.md)へ保持する。別境界や全体goalの未達だけで未完了へ戻さない。 |'
$replacements['共有契約／推移的逆依存matrix'] = '| 共有契約／推移的逆依存matrix | **Sema／text-model全35逆依存を終端照合。通常側4117／4117 PASS** | Source 638d6459bf68b4679349f2bfccc03f53d1878d26、4091入力、all-target／all-feature／locked。35 packageを選択し33にRust testがある。bundle-assets／render-webはテスト0件であり、実行PASSへ数えない。全4815件は4801 PASS／14 FAIL・40 skipped、CLIは次行へ集約する。source／case／実EXE driftは0。Native auxiliaryの10 target・16 distinct caseもこの実runで全PASSと照合し、別runとして加算しない。[graph・全case・境界別照合](acceptance-evidence/task-rich-text-layout-presence.json)。先行Syntax全25の通常5162／5162は異なる入力・選択範囲の[当時の原本](acceptance-evidence/task-bench-execution-target.json)へ保持する。 |'
$replacements['CLI全target照合'] = '| CLI全target照合 | **統合受入は未完了。最新の全698件は684 PASS／14 FAIL** | Source 638d6459bf68b4679349f2bfccc03f53d1878d26、4091入力、全35逆依存の同じ一回の実runに含むCLI全target／all-feature／locked。CLIは698件684 PASS／14 FAIL・23 ignored。旧「676 PASS／22 FAIL＋後続JLREQ8条件のfocused PASS」という現状説明を、新しい全件実測で置換した。合成値ではない。前回未再実行だった14 failed IDと同一で、追加・解消IDは0。ID一致だけから原因同一とは推定しない。[最新全件・全失敗・訂正理由](acceptance-evidence/task-rich-text-layout-presence.json)。旧headless source、JLREQ sizing／hyphenの初回失敗・修復・公開SHAは[当時の履歴](convergence-evidence-history.md)と各原本へ保持する。RichTextのfactory・出典は専用行で追い、Generic Matchや既受入のtyped ownerを一括して未完了へ戻さない。 |'
$replacements['workspace check／Clippy・fmt・構造gate'] = '| workspace check／Clippy・fmt・構造gate | **全98と最終owner gateは終了0。変更行の新規警告0・既存警告は残存** | Source 726323d1edc63a6a543f7b8b817570ecc2ea2b3eで全98 check／Clippy（all-target／all-feature／locked）とworkspace fmtが終了0。後続3pathはprivate投影の既存helper再利用・セミコロン・test内fn位置のみで、Source 638d6459bf68b4679349f2bfccc03f53d1878d26のCompiler／text-model check／Clippy、Rust3件fmt、canonical構造gateが終了0。全98を最終bytesで再実行したとは扱わず、最終bytesの全35逆依存実行と区別する。[全receipt・警告修復・owner review](acceptance-evidence/task-rich-text-layout-presence.json)。今回doctest／wasm専用検証は未再実行。[以前の実測](acceptance-evidence/task-action-channel-receive-consumers.json)を新規実行へ数えない。 |'
$seen = @{}
$updated = foreach ($line in $oldStatusLines) {
    if ($line.StartsWith('| ')) {
        $key = ($line -split '\|')[1].Trim()
        if ($replacements.ContainsKey($key)) { if ($seen.ContainsKey($key)) { throw 'Duplicate current row' }; $seen[$key]=$true; $replacements[$key]; continue }
    }
    $line
}
if ($seen.Count -ne $replacements.Count) { throw 'Current row replacement missing' }
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($updated -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
$historyAppend = @"

## 2026-11-04 — sparse RichText layout presence

Source checkpoint 726323d1edc63a6a543f7b8b817570ecc2ea2b3e and final refinement
638d6459bf68b4679349f2bfccc03f53d1878d26 separate authored presence from resolved
layout. The fresh 35-package reverse run finishes 4,815 cases: 4,801 PASS,
14 CLI FAIL and 40 skipped; normal cases are 4,117/4,117 and CLI is 684/698.
The five new regressions and the same accepted Generic Match 151 IDs all pass.
The failed-ID set remains the prior 14; no cause equivalence is inferred.
The old latest 676/22 plus eight focused passes is superseded as a current
description by this fresh complete run, while its actual results and SHAs remain
in the earlier evidence. Full clean removes 141,989 files/191.7 GiB with zero
source/status drift. The raw receipts retain the initial four-case pass and the
full failed run: [layout presence evidence](acceptance-evidence/task-rich-text-layout-presence.json).

"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$historyAppend,[Text.UTF8Encoding]::new($false))
$afterHistory = [IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyHasher = [Security.Cryptography.SHA256]::Create()
try { $prefixHash = [Convert]::ToHexString($historyHasher.ComputeHash($afterHistory,0,$historyBytes.Length)).ToLowerInvariant() }
finally { $historyHasher.Dispose() }
if ($prefixHash -ne $historyPrefix.sha256) { throw 'Historical prefix changed' }
[ordered]@{source=$source.commit;rawBytes=$raw.bytes;rawSha256=$raw.sha256;rawEntries=$raw.entries.Count;rawEntryDrift=0;replacedRows=$seen.Count;historicalPrefix=$historyPrefix;historicalPrefixDrift=0;originalUntrackedDrift=0} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath "$taskTemp/layout-presence-evidence-record.json" -Encoding utf8
Get-Content -LiteralPath "$taskTemp/layout-presence-evidence-record.json" -Raw
