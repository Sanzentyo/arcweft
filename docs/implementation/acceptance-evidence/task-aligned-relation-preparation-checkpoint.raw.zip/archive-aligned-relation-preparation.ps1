$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '13ff2882576c30776dd49cbbba3772caa200343d'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'aligned-relation-preparation.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='Aligned composite relation preparation now retains conditional effects for the original forest rather than eagerly sealing every candidate against unavailable Named bodies. Constructor, kind, owner, tuple/parameter arity and binder mismatches are explicitly rejected; generic source scopes and alias preparation remain on the actual operand/application owners. Directional Never handling respects the relation direction, including contravariant function inputs. Structural dependent payload comparison keeps its exact header, Ref payload presence, ordered Choice children and exact function effects without changing original equality into subtyping. Nominal arguments retain both-direction relations. All preparation inputs first pass provenance-aware whole-tree admission: ConstraintProjectionView.admit_operand uses a new unit-output mode of the same type fold, exact value/constant/header ports and each actual operand frame. It does not rebuild a semantic value, follow active bindings, solve effects, mint a source lineage or grant the receiving inventory Free authority to the source. An invalid non-Validation pairing is rejected. The temporary bare-value precheck was removed; private source/scope access was not widened. CrossShapeCompatibility shares the existing ByteCollection/AgentValue root dispatch between canonical and prepared owners. Only those unconverted cross-shape relations still enter the old reader, with directional acceptance as its only input; its unused equality/structural route is deleted. This reader, local Fn quantification/guarded semantics, final callers and the complete frontend switch remain unfinished. Eight new fixtures cover composite kind/arity/binder mismatches, directional bottom, structural dependent payloads, an unresolved descendant behind a wrong header, conditional function row acceptance at actual original closure, contravariant function input, invariant nominal callback rows at closure, and source-specific Free authority despite a wider receiving inventory. Existing scalar/Ref test assertions and budgets remain unchanged; the new full-closure helper has its own explicit work allowance and uses the same real graph/context throughout. Tests remain unrun because targets do not compile. The shared projection algorithm remains the sole type traversal; admission owns no output artifact, resolver, catalog or parallel authority. Binding-plan growth remains the same relational state and dependency cluster; the private admission mode is a real output/permission boundary, not a physical split requiring a public facade. Exact path sizes/growth/classification/embedded tests follow. No Cargo graph/feature, layer direction, I/O, unsafe, codec/version, production limit, jobs or profile change. Existing Cargo graph and reverse-dependency evidence is reused; no workspace scanner or broad acceptance is claimed.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'aligned-relation-preparation.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03','dev04')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'aligned-relation-preparation.'+$iteration+$suffix}})
$names+=@('aligned-relation-preparation.source-publication.json','aligned-relation-preparation.ownership-review.json','aligned-relation-preparation.staged-review.json','aligned-relation-preparation.dev04-diagnostic-review.json')
$names+=@('run-aligned-relation-preparation-check.ps1','archive-aligned-relation-preparation.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-aligned-relation-preparation-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-aligned-relation-preparation-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'aligned-relation-preparation.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
