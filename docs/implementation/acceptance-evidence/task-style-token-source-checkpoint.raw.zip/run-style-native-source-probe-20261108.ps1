param([Parameter(Mandatory)][string]$Epoch)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$stem="$r/style-token-construction-20261108.native-$Epoch"
if(Test-Path ($stem+'.source.json')){throw 'Probe epoch exists'}
$paths=@((git ls-files -- '*.rs' '*.toml' '*.lock' '*.json' '*.stderr' '*.arcw' '*.awfagent' 'rust-toolchain*' '.cargo/*')|Where-Object {$_ -notlike 'docs/*'})
$paths+=@('crates/arcweft-lang-sema/src/final_analysis/model/style.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style.rs')
$inputs=@(foreach($p in @($paths|Sort-Object -Unique)){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$inputs|ConvertTo-Json -Depth 8|Set-Content ($stem+'.source.json') -Encoding utf8
function Assert-Inputs {foreach($row in $inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Probe source drift: '+$row.path)}}}
$buildCommand=@('build','--locked','-p','arcweft-cli','--bin','arcw')
& cargo @buildCommand *> ($stem+'.build.log')
$build=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=$buildCommand;exitCode=$build;sourceInputs=$inputs.Count;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.build.json') -Encoding utf8
if($build -ne 0){exit $build}
$main='D:/git/arcweft/target/debug/arcw.exe'
$hash=(Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant()
$start=[DateTime]::UtcNow.ToString('o')
$checkCommand=@('check','--manifest-path','samples/native-text-input/arcw.toml','--json')
& $main @checkCommand *> ($stem+'.check.log')
$check=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant() -ne $hash){throw 'Actual CLI changed'}
$receipt=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();main=[ordered]@{path=$main;sha256=$hash};sourceInputs=$inputs.Count;sourceDrift=0;binaryDrift=0;checkCommand=$checkCommand;checkExitCode=$check;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Actual CLI Source check, not interactive Native/Web acceptance'}
$receipt|ConvertTo-Json -Depth 12|Set-Content ($stem+'.check.json') -Encoding utf8
if($check -ne 0){exit $check}
$report=Get-Content ($stem+'.check.log') -Raw|ConvertFrom-Json -Depth 100
if($report.status -ne 'ok'){throw 'Check lacks successful status'}
$artifact='D:/git/arcweft/target/arcweft/native-text-input-style.awfb'
$bundleCommand=@('bundle','--manifest-path','samples/native-text-input/arcw.toml','--profile','main','--output',$artifact,'--json')
& $main @bundleCommand *> ($stem+'.bundle.log')
$bundle=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant() -ne $hash){throw 'Actual CLI changed'}
$receipt.bundleCommand=$bundleCommand
$receipt.bundleExitCode=$bundle
if($bundle -eq 0){$receipt.artifact=[ordered]@{path=$artifact;bytes=(Get-Item -LiteralPath $artifact).Length;sha256=(Get-FileHash -LiteralPath $artifact).Hash.ToLowerInvariant()}}
$receipt.finishedAt=[DateTime]::UtcNow.ToString('o')
$receipt|ConvertTo-Json -Depth 12|Set-Content ($stem+'.json') -Encoding utf8
$receipt|ConvertTo-Json -Depth 12
exit $bundle
