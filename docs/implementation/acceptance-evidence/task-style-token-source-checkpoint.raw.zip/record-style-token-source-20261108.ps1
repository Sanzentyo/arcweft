param([Parameter(Mandatory)][string]$ProbeEpoch)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-token-construction-20261108.source-checkpoint.verified.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit){throw 'Source checkpoint changed'}
$probe=Read-Record "style-token-construction-20261108.native-$ProbeEpoch.json"
if($probe.checkExitCode -ne 0 -or $probe.bundleExitCode -ne 0){throw 'Source acceptance probe did not pass'}
$archive='docs/implementation/acceptance-evidence/task-style-token-source-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(foreach($filter in @('style-token-annotation-20261108*','style-token-publication-20261108*','style-token-construction-20261108*')){Get-ChildItem -LiteralPath $r -File -Filter $filter|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')}})
$files+=@('run-style-annotation-quality-20261108.ps1','run-style-token-construction-quality-20261108.ps1','run-style-native-source-probe-20261108.ps1','run-retained-input-frozen-matrix-20261108.ps1','audit-nextest-final-result.ps1','record-style-token-source-20261108.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$entry=[ordered]@{
    version=1;date='2026-11-08';status='Intermediate Source publication: original token annotation/declaration/reference ownership, font stacks and symbolic palette. Complete Style and interactive sample acceptance remain open.'
    annotationPublication=(Read-Record 'style-token-annotation-20261108.source-checkpoint.verified.json')
    declarationPublication=(Read-Record 'style-token-publication-20261108.source-checkpoint.verified.json')
    publication=$pub
    model='All 25 native token annotations use the original Style item/token ordinal/HIR type node, semantic-only nominal report and distinct cache identity. HIR projects normalized zero-depth token identity once. Compiler transports checked native values and original whole-declaration source ranges. Style construction operands retain native font/system-color values and original sheet/token/initializer identities; exact type/value-kind validation and transcript tag 0x0226 preserve previous tags and version 1. Token names use the existing typed HIR path/select chain and original evaluation topology, never raw Source or runtime qualifier evaluation. Lookup work is bounded by the longest declared name in that sheet. Native ViewStyleSheet retains authority over token graph/type/cycle/depth validation and runtime cascade.'
    ownerReview=[ordered]@{context=[ordered]@{path='crates/arcweft-lang-sema/src/final_analysis/analyzer/style.rs';bytes=8409;physicalLoc=229};checker=[ordered]@{path='crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style.rs';bytes=15696;physicalLoc=365};operand=[ordered]@{path='crates/arcweft-lang-sema/src/final_analysis/model/style.rs';bytes=3761;physicalLoc=117};disposition='Cohesive source-only ownership context, checker, and checked operand model. Existing Color/Length checking moved out of the general expression module into the same Style checker. ViewSpecifiedValue remains the sole complete native value algebra. No I/O, dependency or layer-direction changes; no runtime frame/snapshot admission. The 365-line new checker received the >300-growth ownership review; no public visibility was widened solely for file splitting.'}
    annotationOwner=(Read-Record 'style-token-annotation-20261108.owner-r1.runtime.terminal-audit.json')
    declarationOwner=(Read-Record 'style-token-publication-20261108.owner-r1.runtime.terminal-audit.json')
    firstConstructionOwner=(Read-Record 'style-token-construction-20261108.owner-r2.runtime.terminal-audit.json')
    finalConstructionOwner=(Read-Record 'style-token-construction-20261108.owner-r3.runtime.terminal-audit.json')
    corrections='Development check failures preserve missing exhaustive diagnostics/module paths, wrong lifetime/HIR argument projections, a missing test import, a misplaced raw-string test block and incorrect test property names. The first construction catalog failed after moving an import. First executed construction run: 9 pass/3 fail. Dotted token references were being sent through ordinary prepared selection before the Style checker; Style now owns that contextual decision first and marks token qualifiers static. Original typed Path/Select structure is checked against the actual declaration. The cross-sheet rejection fixture now separates its two source declarations with newlines and includes a valid control. Final 12-case selection passes without assertion/budget/filter weakening.'
    quality=@(foreach($name in @('check','clippy','structure','fmt')){Read-Record "style-token-construction-20261108.quality.$name.receipt.json"})
    graph=(Read-Record 'style-token-construction-20261108.graph.json');reverseDependencyTree=(Read-Record 'style-token-construction-20261108.tree-invert.json');consumerScope='Metadata and target-all invert tree agree on the 22-package Sema reverse-dependency closure. Owner tests and whole-workspace quality gates do not replace the still-pending complete consumer execution for these Style bytes. Prior String 8089-case totals remain scoped to Source 70a050cc9cd0b94d83b79a295ec688bccd3b1d3b.'
    nativeSourceProbe=$probe
    pending='Finish remaining static value/factory families, unannotated-token inference, typed composition/conversions and Environment Source publication, complete consumer execution and Native/Web interactive acceptance. Preserve every sample style, control, branch and original action. Generic Match, retained input, named Action, String and other bounded accepted cuts remain accepted.'
    archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false;containsGeneratedBundles=$false}
}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'styleTokenSourceCheckpoint'){throw 'Record exists'}
$wrapper=[ordered]@{styleTokenSourceCheckpoint=$entry}|ConvertTo-Json -Depth 100
$inner=$wrapper.Substring($wrapper.IndexOf('{')+1).TrimEnd();$inner=$inner.Substring(0,$inner.LastIndexOf('}')).TrimEnd()
$next=$base.TrimEnd();$next=$next.Substring(0,$next.LastIndexOf('}')).TrimEnd()+','+"`n"+$inner+"`n}`n"
$after=$next|ConvertFrom-Json -Depth 100 -DateKind String
foreach($p in $prior.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($p.Name)|ConvertTo-Json -Depth 100 -Compress)){throw 'Historical record drift'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$next,[Text.UTF8Encoding]::new($false))
$current='D:/git/arcweft/docs/implementation/current-status.md'
$lines=@([IO.File]::ReadAllLines($current))
$generic=@($lines|Where-Object {$_ -match '^\| Generic Match'})
if(@($lines|Where-Object {$_.StartsWith('| Style 指定値・token・構築処理 |')}).Count){throw 'Current Style row already exists'}
$output=[Collections.Generic.List[string]]::new()
foreach($line in $lines){
    if($line.StartsWith('確認日 ')){$line='確認日 2026-11-08、観察Source `'+$pub.commit+'`。項目ごとの受入・公開Sourceと検証範囲を下表で独立して追跡する。Styleの型・token宣言／参照・font／paletteのSource接続を中間公開した。Native入力sampleは実CLI check／main-profile AWFB生成まで確認し、実Native／Web表示の受入は継続する。tracked実装WIPは0、4 actual untrackedのローカルcacheは保持している。'}
    if($line.StartsWith('| View の保持 String 入力／公開target・IME hint・placeholder |')){$start=$line.IndexOf('NativeのFontFamilyList型・Style tokenは未達。');$end=$line.IndexOf('残るsample・Scroll・実Native／Web操作／表示は継続する。',$start);if($start -lt 0 -or $end -lt 0){throw 'Superseded Style status not found'};$line=$line.Remove($start,$end-$start).Insert($start,'Style Sourceの範囲は専用行に集約した。')}
    if($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){$fmt=@($entry.quality|Where-Object {$_.paths}).paths.Count;$line='| workspace check／Clippy・fmt・構造gate | **Style token Source checkpointの全workspace gateは終了0** | Source `'+$pub.commit+'` の全98 package・全target・全feature・locked check／Clippy、canonical構造gate、変更'+$fmt+' Rust pathのfmtが終了0、3909入力drift0（警告あり）。ownerの初回9 PASS／3 FAIL、修正後12／12 PASSを履歴へ保持。完全な22逆依存の実行は継続条件で、先行Stringの全件結果を転用しない。[gate・失敗・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
    $output.Add($line)
    if($line.StartsWith('| View の保持 String 入力／公開target・IME hint・placeholder |')){$output.Add('| Style 指定値・token・構築処理 | **型・宣言・参照・font／paletteを中間公開** | 型基盤 `c4824f38ebce38305adb7f8ac757e13edb4b8e4e`、全25 annotationの元owner／cache分離 `3cada521ecac205c76744b09613b9cf519d5ccb5`、元宣言ID／source rangeを持つtoken公開 `32277ec5e8bff06feef249e981e3f038c3153ebb`、参照・font stack・system color接続 `'+$pub.commit+'`。構築operandと完成値を別型で保持し、元sheet内のtyped Path／Select参照を検証する。前方参照・別sheetの同名・codec往復・実cascade・不正型／scope／引数／token graph拒否を含む12／12 PASS。native-text-inputの元font stack／focus ring／入力欄を保ち、実CLI checkとmain-profile AWFB生成まで確認したため、旧「FontFamilyList型・Style token未達」という現状説明を訂正した。旧slot41の失敗・全SHA・途中の失敗は履歴に保持。未annotation推論、残る値／factoryと型付きcomposition／Environment、全22逆依存、sample全体とNative／Web操作／表示の受入は継続する。[実測・訂正理由・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')}
}
if(($generic -join "`n") -cne ((@($output|Where-Object {$_ -match '^\| Generic Match'})) -join "`n")){throw 'Accepted Generic Match row changed'}
[IO.File]::WriteAllText($current,($output -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
$history=@'

## 2026-11-08 — Style token・font／palette Source接続のcheckpoint

annotation Source `3cada521ecac205c76744b09613b9cf519d5ccb5` は全25 native kindを元Style／token ordinal／型nodeに束縛し、通常のnominal lookupからreport purposeとcache identityを分離した。宣言公開Source `32277ec5e8bff06feef249e981e3f038c3153ebb` はnonempty-token一律拒否を除去し、正規化済みHIR ID・checked ViewSpecifiedValue・元宣言source rangeをcodecへ接続した。構築Source `{{SOURCE}}` は元sheetに属するtoken参照、順序付きfont stack、system font、symbolic paletteを、通常runtime値から分かれた型付きoperandとして保持する。既存Color／Length処理も同じSource専用checkerへ移し、完成値・graph・cascadeのauthorityは既存Viewに維持した。

annotation owner 4件、宣言／codec owner 1件がPASS。構築の初回listは移動時のimport不足で失敗し、初回実行12件は9 PASS／3 FAIL。typed Selectを通常の値として先に評価していたため、Styleのcontextual判定をprepared selectionより前に置き、qualifierをstaticとして扱った。元Path／Selectの正規化された名前と実宣言・元initializer・型の一致を再検証し、別sheet拒否fixtureは宣言を改行で分離し正常な対照も置いた。修正後12／12 PASS、1674 explicit-filter SKIP、3909 Source／catalog／実EXE drift0。全98 workspaceのlocked・全target・全feature check／Clippy、構造gate、fmtも終了0（警告あり）。development compile失敗を含む原本は削除・成功への読み替えをしていない。

native-text-inputは元のfont stack・focus ring・入力欄を保った実CLI checkとmain-profile AWFB生成まで進んだ。この具体的な検証により、旧現状行の「FontFamilyList型・Style token未達」を訂正し、現在のStyle範囲を専用1行に集約した。過去のslot41失敗とそのSource SHAは元記録に残す。これは全Style・全sample・Native／Web表示の受入ではなく、未annotation推論、残る値／factory、composition／Environment、22逆依存全件を継続する。先行Stringの8089件をこのSourceの全件合格へ転用せず、Generic Match等の既受入も未完了へ戻さない。

既存142 registry recordの値を全件照合して保持した。原本 `{{ARCHIVE}}` は{{ENTRIES}} entry／{{BYTES}} bytes、SHA256 `{{SHA}}`。実行ファイルと生成AWFBは元のbuild pathに置き、ZIPには含めない。詳細はregistryの `styleTokenSourceCheckpoint`。
'@
foreach($key in @('SOURCE','ARCHIVE','ENTRIES','BYTES','SHA')){$value=switch($key){SOURCE{$pub.commit};ARCHIVE{$entry.archive.path};ENTRIES{$entry.archive.entries};BYTES{$entry.archive.bytes};SHA{$entry.archive.sha256}};$history=$history.Replace(('{{'+$key+'}}'),[string]$value)}
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+"`n"+$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$entry.archive}|ConvertTo-Json -Depth 8|Set-Content "$r/style-token-construction-20261108.checkpoint-record.json" -Encoding utf8
Get-Content "$r/style-token-construction-20261108.checkpoint-record.json" -Raw
