$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = 'e4a087b93e151fc38219473fffdbc6c6c5e0eddb'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'original-product-future-inputs.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='Each original product seeds the exact inference functions of its merged application inventory and those reachable from its terms and obligations. The forest validates Future rows once with the owning graph, then specializes each product using the rows in that product dependency closure. Standalone specialization still validates the supplied bindings against its own definitions. A failed closure returns the original affine forest for retry. New and expanded regressions were not executed because Sema could not compile.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'original-product-future-inputs.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'original-product-future-inputs.'+$iteration+$suffix}})
$names+=@('original-product-future-inputs.source-publication.json','original-product-future-inputs.ownership-review.json','original-product-future-inputs.staged-review.json','original-product-future-inputs.dev02-diagnostic-review.json')
$names+=@('run-original-product-future-inputs-check.ps1','archive-original-product-future-inputs.ps1','review-original-product-future-inputs.ps1')
$names+=@('original-product-future-inputs.structure.log','original-product-future-inputs.structure-result.json')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-original-product-future-inputs-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-original-product-future-inputs-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'original-product-future-inputs.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json










