$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/effect-primitive-gamma.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/effect-primitive-gamma.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/effect-primitive-gamma.impact.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/effect-primitive-gamma.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/effect-primitive-gamma.structure.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/effect-primitive-gamma.consumer-summary.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/effect-primitive-gamma.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean'}
if($owner.Passed -ne 1726 -or $owner.Failed -ne 6 -or !$impact.ReverseConsumersRerun -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$archive.AllEntriesVerified -or $structure.ExitCode){throw 'Evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'Historical prefix changed'}
$rows=@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。型・定数・effectのFree許可とreify保持を検証・公開。本体内推論は継続** | 最新Source `SOURCE`。Native／AWBCの42・各step公開保存復元、Source Γ・import lease・実フレーム移送の既受入を維持。元の量化R、guard付きimport、Future部分代入、nullary条件の同時消去とprincipal条件付きの下限を保持する。一般のcross-label条件・choice・局所∀・非nullary・importは簡約できる範囲を越えたら元のRを保持する。型・定数のFree参照は対応するportのSource宣言・template owner・parameter lease・alias終端・completed bindingの個別captureで許可を確認する。effect完成行・predicateは実計算scope・domainと、各完成値が実際に使う参照だけのowner／import leaseを保持する。関数ヘッダのFree参照を代数操作前に検証し、元の対応フィールドと実際に使った完成行から各フィールドのΓを発行する。行とpredicateの許可流用、正規化による不許可参照の消失、共有inventoryだけによる許可を拒否する。effect-only reifyも元operandの実scopeと許可を確認し、成功・取消し時に受け手scopeを復元する。省略行は未確定のまま保持する。一般量化消去・MGU／rank・Fn型ownerの局所∀、prepared型を含む全portのΓ統合、frontend prepared value／effect・body一回準備・一括sealは継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[残余簡約](convergence-evidence-history.md#nullary-effect-residual-reduction)・[今回のΓ保持](convergence-evidence-history.md#scoped-effect-primitive-gamma-and-header-admission)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,726 PASS／6 FAIL。後続21 packageは2,507 PASS／2 FAIL／1 SKIP** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,732件をSECONDS秒で実行。直前1,728 ID保持・新4件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。開発時の全1,732件は1,725 PASS／7 FAILで、追加1失敗はcaller effect宣言を持たないground fixtureだった。明示的なSource Γへ移行し、失敗結果と当時の19 pathの全bytesも保持した。全feature metadata／全target reverse treeの22 packageを確認し、後続21 package／107 targetも同じSourceで再実行した。2,510件中2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19も不変。[現在のowner・全consumer・graph・全SHA原本](acceptance-evidence/task-effect-primitive-gamma.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source `SOURCE`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件を今回再実行し、226 PASS。binはcompile済み・runnable test 0件。21 packageの全consumer照合に含め、選択・終端ID一致・重複0を確認した。以前の入力・件数・失敗・公開SHAと再利用範囲は履歴と原本へ保持する。[今回のCLI原本](acceptance-evidence/task-effect-primitive-gamma.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace全target／全feature check・Clippy、fmt・doctest・構造gateは終了0** | Source `SOURCE` と同一のRust bytesでlocked workspace全target／全feature checkとClippy、workspace fmt、Sema doctest 2件を今回実行。構造gateはPACKAGES package・FILES files・RUSTFILES Rust files・RUSTLOC Rust LOC・REVIEWS review・blocking 0。20 Rust path・GROWTH物理LOC増。Γの発行は実計算context、各フィールドの許可は既存operand導出、実フレームとcaptureは既存completed transportが所有する。既存fold・effect mapperを使い、raw completion readerを削除した。新しいtype walkerやΓの並行catalogは導入しない。Cargo graphは22 package、fan-in／outは12／19で不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告も保持。2026-11-14の全体cargo cleanでtarget消失・終了0を確認した。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を維持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・graph・clean](acceptance-evidence/task-effect-primitive-gamma.raw.zip)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$status=[IO.File]::ReadAllText($statusPath)
foreach($key in $rows.Keys){
 $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
 if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'}
 $replacement=$rows[$key].Replace('SOURCE',$pub.Source).Replace('SECONDS',[string]$owner.ExecutionSeconds).Replace('PACKAGES',[string]$structure.Packages).Replace('RUSTFILES',[string]$structure.RustFiles).Replace('FILES',[string]$structure.Files).Replace('RUSTLOC',[string]$structure.RustPhysicalLOC).Replace('REVIEWS',[string]$structure.ReviewTriggers).Replace('GROWTH',[string]$owner.PhysicalGrowth)
 $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$date=Get-Date -Format 'yyyy-MM-dd'
$status=[regex]::Replace($status,'確認日 [0-9]{4}-[0-9]{2}-[0-9]{2}。','確認日 '+$date+'。')
$status=[regex]::Replace($status,'この更新の基点の `main` と `origin/main` は `[a-f0-9]{40}`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Scoped effect primitive Gamma and header admission

$date。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの20 Rust pathを通常commit／非force pushし、ownerが検証したdirty bytesと公開全blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- 数学的effect completionを消費し、行・predicateを既存ConstraintOperandへ一度だけ移す。move-only issuanceは値・実計算context・各値が使う参照だけの実owner／import leaseを結び付ける。contextは実scope・元の制約・計算domainとSource／ScopedRelationの区別を保持し、operandへの逆参照を持たない。共同relationへ架空のSource ΓやDを発行せず、raw completion accessorと全consumerを置換した。
- 元の関数ヘッダのFree参照を代数操作前に対応portの導出で検証する。canonicalな最終行とpredicateには、対応する元フィールドまたはそのフィールドが実際に使ったΓ保持完成行だけを根拠に、個別の許可を発行する。再投影もそのフィールドの許可を使う。省略行を空行やΓ検証済み行に変えない。
- effect-only reifyは型付きoperandを受け、元の実フレームと許可を確認してから既存controlled mapperへ渡す。行・predicateの元Source admissionにも同じmapperを使う。新4件は、共有inventory内の兄弟完成値の許可交換、行とpredicateの許可混同、canonical消去前の不許可参照、受け手にだけ見える参照を検証する。既存の実ambient／local frame・保存・再開・取消し後の受け手scope復元条件も拡張した。
- 開発時の全1,732件は1,725 PASS／7 FAIL／0 SKIP。既知6件に加わった1件は、caller effectの宣言を持たないground Source fixtureであり、明示的な元Source Γへ修復した。当時の19 path全bytesと失敗原本、テスト追加時のborrow-check拒否も保持する。最終ownerは1,732件／1,726 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,728 ID保持・新4件PASS・選択／終端ID一致・重複0。既知6失敗の5 ExpressionCycle／1 PendingCallableEffectProjectionは不変で、再帰本体の推論の完了とはしない。
- producer変更のためfresh full metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19、CLI規定226 PASS、compile-only 3 targetを照合した。workspace全target／全feature check・Clippy、workspace fmt、Sema doctest 2件、構造gateは終了0。全consumerの実行を過去の実測で代用していない。
- 20 path・$($owner.PhysicalGrowth)物理LOC増。Γ issuanceは実計算context、port許可は既存operand導出、代数操作は既存projection fold、scopeとcaptureは既存completed transportの責務とした。Cargo graphとfan-in 12／fan-out 19は不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし。2026-11-14のcargo clean後にtarget消失と再確認の終了0を観測し、D空き137467404288 bytesを記録した。最初の削除ログ取得に失敗したため、正確な削除ファイル数・削除bytesは記載しない。
- Supersedes: 現状一覧のeffect-only reify・effectのFree許可・完成primitive Γ保持の未完了列挙を、今回検証した境界の完了へ訂正した。一般量化消去・MGU／rank・Fn局所∀・prepared型を含む全portのΓ統合・frontend本体一回準備と一括sealは残る。以前の全SHA・実測・失敗・原本とGeneric Match・caller-bound recursion・共有prefixの受入を保持する。現在の一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-effect-primitive-gamma.raw.zip](acceptance-evidence/task-effect-primitive-gamma.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended effect Gamma evidence.'