$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$groupDir="$root/effect-primitive-gamma-reverse"
$repairDir="$root/effect-primitive-gamma-compiler"
$grouped=Get-Content -Raw "$groupDir/results.json" | ConvertFrom-Json
$repair=Get-Content -Raw "$repairDir/effect-primitive-gamma-compiler-results.json" | ConvertFrom-Json
$publication=Get-Content -Raw "$root/effect-primitive-gamma.publication.json" | ConvertFrom-Json
if ($grouped.CompletedGroups -ne 20 -or $repair.completedSteps -ne 31 -or $repair.plannedSteps -ne 31) { throw 'Consumer execution is not terminal' }
foreach ($receipt in @($grouped,$repair)) {
    if ($receipt.Source -ne $publication.Source -or $receipt.Tree -ne $publication.Tree) { throw 'Consumer source identity differs' }
}
if (@($grouped.Steps | Where-Object SelectionExit -ne 0).Count -ne 0) { throw 'Consumer compilation failed' }
$baseline=Get-Content -Raw "$root/original-value.consumer-baseline.json" | ConvertFrom-Json
$allSuites=[Collections.Generic.List[object]]::new()
$allWanted=[Collections.Generic.List[object]]::new()
$allTerminal=[Collections.Generic.List[object]]::new()

function Wanted($listing) {
    foreach ($property in $listing.'rust-suites'.PSObject.Properties) {
        $suite=$property.Value
        $allSuites.Add([pscustomobject]@{Id=$property.Name;Package=$suite.'package-name';Kind=$suite.kind;Name=$suite.'binary-name';DefinedCases=@($suite.testcases.PSObject.Properties).Count})
        foreach ($case in $suite.testcases.PSObject.Properties) {
            $match=$case.Value.'filter-match'
            if ($match.status -eq 'matches' -or ($case.Value.ignored -and $match.status -eq 'mismatch' -and $match.reason -eq 'ignored')) {
                [pscustomobject]@{Id=($property.Name+'$'+$case.Name);Binary=$property.Name;Name=$case.Name;Package=$suite.'package-name';Ignored=$case.Value.ignored;EventName=($suite.'package-name'+'::'+$suite.'binary-name'+'$'+$case.Name)}
            }
        }
    }
}

function Reconcile($wanted,$terminal,$label) {
    if ($wanted.Count -ne $terminal.Count -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -ne 0) { throw "Consumer count/duplicate mismatch: $label" }
    if (@(Compare-Object -CaseSensitive @($wanted.Id | Sort-Object) @($terminal.Id | Sort-Object)).Count -ne 0) { throw "Consumer case identity mismatch: $label" }
    foreach ($entry in $wanted) { $allWanted.Add($entry) }
    foreach ($entry in $terminal) { $allTerminal.Add($entry) }
}

foreach ($step in @($grouped.Steps | Where-Object SelectionExit -eq 0)) {
    if ($step.RunExit -ne 0 -or !$step.SignaturesEqual) { throw "Grouped package did not pass: $($step.Package)" }
    foreach ($file in @(@{Path="$groupDir/$($step.Name).selection.json";Hash=$step.SelectionSHA256},@{Path="$groupDir/$($step.Name).results.jsonl";Hash=$step.RunSHA256},@{Path="$groupDir/$($step.Name).run.log";Hash=$step.LogSHA256})) {
        if ((Get-FileHash $file.Path -Algorithm SHA256).Hash -ne $file.Hash) { throw 'Grouped log hash changed' }
    }
    $listing=Get-Content -Raw "$groupDir/$($step.Name).selection.json" | ConvertFrom-Json
    $wanted=@(Wanted $listing)
    $byEvent=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
    foreach ($entry in $wanted) { $byEvent.Add($entry.EventName,$entry) }
    $terminal=@(Get-Content "$groupDir/$($step.Name).results.jsonl" | ForEach-Object {
        $event=$_ | ConvertFrom-Json
        if ($event.type -eq 'test' -and $event.event -in @('ok','failed','ignored')) {
            if (!$byEvent.ContainsKey($event.name)) { throw "Unexpected terminal case $($event.name)" }
            $entry=$byEvent[$event.name]
            [pscustomobject]@{Id=$entry.Id;Binary=$entry.Binary;Name=$entry.Name;Package=$entry.Package;Result=$event.event}
        }
    })
    Reconcile $wanted $terminal $step.Name
}

foreach ($step in $repair.steps) {
    if ($step.selectionExit -ne 0 -or $null -eq $step.runExit) { throw "Compiler target not executed: $($step.name)" }
    $selectionPath="$repairDir/$($step.name).selection.json"
    $runPath="$repairDir/$($step.name).nextest.log"
    if ((Get-FileHash $selectionPath -Algorithm SHA256).Hash -ne $step.selectionHash -or (Get-FileHash $runPath -Algorithm SHA256).Hash -ne $step.runLogHash) { throw 'Compiler log hash changed' }
    $listing=Get-Content -Raw $selectionPath | ConvertFrom-Json
    $wanted=@(Wanted $listing)
    $suiteIds=@($listing.'rust-suites'.PSObject.Properties.Name)
    $before=@($baseline.Signatures | Where-Object {$suiteIds -ccontains $_.Id} | ForEach-Object {$_.Items})
    $after=@(foreach ($suite in $listing.'rust-suites'.PSObject.Properties) { foreach ($case in $suite.Value.testcases.PSObject.Properties) { $suite.Name+'$'+$case.Name+'|'+$case.Value.ignored+'|'+$case.Value.'filter-match'.status } })
    if (@(Compare-Object -CaseSensitive @($before | Sort-Object) @($after | Sort-Object)).Count -ne 0) { throw 'Compiler target/case/filter changed' }
    $log=[IO.File]::ReadAllText($runPath)
    $summary=[regex]::Match($log,'(?m)^\s*Summary \[[^\]]+\]')
    if (!$summary.Success) { throw 'Compiler terminal summary missing' }
    $terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL)\s+\[[^\]]+\]\s+(?:\([^)]*\)\s+)?(?<binary>\S+)\s+(?<test>\S+)\s*\r?$') | ForEach-Object {
        [pscustomobject]@{Id=($_.Groups['binary'].Value+'$'+$_.Groups['test'].Value);Binary=$_.Groups['binary'].Value;Name=$_.Groups['test'].Value;Package='arcweft-compiler';Result=$(if($_.Groups[1].Value -eq 'PASS'){'ok'}else{'failed'})}
    })
    Reconcile $wanted $terminal $step.name
}

if ($allSuites.Count -ne 107 -or @($allSuites | Group-Object Id | Where-Object Count -ne 1).Count -ne 0) { throw 'Effective 107-target coverage differs' }
if ($allWanted.Count -ne 2510 -or @($allWanted | Group-Object Id | Where-Object Count -ne 1).Count -ne 0) { throw 'Consumer case coverage differs' }
$passed=@($allTerminal | Where-Object Result -eq 'ok').Count
$failed=@($allTerminal | Where-Object Result -eq 'failed')
$skipped=@($allTerminal | Where-Object Result -eq 'ignored').Count
if ($passed -ne 2507 -or $failed.Count -ne 2 -or $skipped -ne 1) { throw 'Consumer outcome totals differ' }

$failureIds=@($failed | ForEach-Object { $_.Binary+'::'+$_.Name } | Sort-Object)
if (@(Compare-Object -CaseSensitive $baseline.FailureIds $failureIds).Count -ne 0) { throw 'Consumer failure IDs changed' }
$actualDiagnostics=@(foreach ($step in @($repair.steps | Where-Object { $null -ne $_.runExit -and $_.runExit -ne 0 })) {
    $log=[IO.File]::ReadAllText("$repairDir/$($step.name).nextest.log")
    [regex]::Matches($log,'ExpressionCycle \{[^\r\n]+') | ForEach-Object Value
})
if ($actualDiagnostics.Count -ne 2 -or @($actualDiagnostics | Where-Object { $_ -match ', slot: 17, kind: Expr' }).Count -ne 1 -or @($actualDiagnostics | Where-Object { $_ -match ', slot: 19, kind: Expr' }).Count -ne 1) { throw 'Compiler actual failure diagnostics changed' }
$packages=@($allSuites.Package | Sort-Object -Unique)
if ($packages.Count -ne 21) { throw 'Consumer package coverage differs' }
$zero=@($allSuites | Where-Object DefinedCases -eq 0)
if ($zero.Count -ne 3) { throw 'Compiled-only target coverage differs' }
$cli=@($allTerminal | Where-Object Package -eq 'arcweft-cli')
if ($cli.Count -ne 226 -or @($cli | Where-Object Result -ne 'ok').Count -ne 0) { throw 'Prescribed CLI coverage differs' }
$quality=Get-Content -Raw "$root/effect-primitive-gamma.broad-quality.json"|ConvertFrom-Json
if($quality.Source -ne $publication.Source -or $quality.Steps.Count -ne 3 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count){throw 'Broad quality gate failed'}
if((Get-Content -Raw "$root/effect-primitive-gamma.sema-doctest.stdout") -notmatch 'test result: ok\. 2 passed; 0 failed'){throw 'Doctest outcome differs'}
$allTerminal.ToArray() | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/effect-primitive-gamma.consumer-terminal.json"
[ordered]@{Version=1;Source=$publication.Source;ActualDiagnostics=$actualDiagnostics} | ConvertTo-Json | Set-Content -Encoding utf8 "$root/effect-primitive-gamma.compiler-diagnostics.json"
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;ConsumerPackages=$packages;Targets=107;DistinctCases=2510;Passed=$passed;Failed=$failed.Count;Skipped=$skipped;IdsEqual=$true;Duplicates=0;Failures=$failureIds;FailureBaseline='8b5e375a9c7b3096fe5ed2f65df556a463741a8d';CompiledOnly=$zero;CliPassed=226;SuccessfulGroupedPackages=20;CompilerSingleTargetRuns=31;CompilerStrategy='31 prescribed targets sequentially; current selection signatures match the pinned historical inventory; no new grouped compiler build attempted'} | ConvertTo-Json -Depth 7 | Set-Content -Encoding utf8 "$root/effect-primitive-gamma.consumer-summary.json"
Get-Content "$root/effect-primitive-gamma.consumer-summary.json" -TotalCount 35



