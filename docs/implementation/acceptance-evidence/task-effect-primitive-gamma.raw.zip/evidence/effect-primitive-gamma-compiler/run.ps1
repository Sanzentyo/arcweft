param([Parameter(Mandatory=$true)][string]$sourceCommit, [Parameter(Mandatory=$true)][string]$sourceTree)
$ErrorActionPreference = 'Stop'
$evidencePath = $PSScriptRoot
$env:CARGO_INCREMENTAL = '0'
Set-Location -LiteralPath 'D:\git\arcweft'
$plan = Get-Content -LiteralPath (Join-Path $evidencePath 'effect-primitive-gamma-compiler-plan.json') -Raw | ConvertFrom-Json
$results = [Collections.Generic.List[object]]::new()
$startedUtc = [DateTime]::UtcNow.ToString('o')
$receiptPath = Join-Path $evidencePath 'effect-primitive-gamma-compiler-results.json'

function Assert-Inputs {
    if ((git rev-parse HEAD) -ne $sourceCommit -or (git write-tree) -ne $sourceTree -or @(git diff --name-only).Count -ne 0) {
        throw 'Pinned reverse validation inputs changed.'
    }
}

function Save-Receipt {
    [ordered]@{
        version = 1
        source = $sourceCommit
        tree = $sourceTree
        startedUtc = $startedUtc
        observedUtc = [DateTime]::UtcNow.ToString('o')
        plannedSteps = $plan.steps.Count
        completedSteps = $results.Count
        environment = @{ CARGO_INCREMENTAL = '0' }
        steps = @($results.ToArray())
    } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}

Assert-Inputs
Save-Receipt
foreach ($step in $plan.steps) {
    Assert-Inputs
    $stepStart = [DateTime]::UtcNow.ToString('o')
    $selectionPath = Join-Path $evidencePath ($step.name + '.selection.json')
    $selectionErrorPath = Join-Path $evidencePath ($step.name + '.selection.stderr')
    $runLog = Join-Path $evidencePath ($step.name + '.nextest.log')
    $arguments = @($step.arguments)
    Write-Output ('START ' + $step.name + ' ' + $step.package + ' ' + $step.kind + ':' + $step.target)
    & cargo nextest list @arguments --message-format json 1> $selectionPath 2> $selectionErrorPath
    $selectionExit = $LASTEXITCODE
    $runExit = $null
    $selected = 0
    $selectedIgnored = 0
    $identities = [Collections.Generic.List[object]]::new()
    if ($selectionExit -eq 0) {
        $selection = Get-Content -LiteralPath $selectionPath -Raw | ConvertFrom-Json
        foreach ($suiteProperty in $selection.'rust-suites'.PSObject.Properties) {
            $suite = $suiteProperty.Value
            foreach ($caseProperty in $suite.testcases.PSObject.Properties) {
                $case = $caseProperty.Value
                if ($case.'filter-match'.status -ne 'matches') { continue }
                $identities.Add(@{ binary = $suiteProperty.Name; name = $caseProperty.Name; ignored = $case.ignored })
                if ($case.ignored) { $selectedIgnored++ } else { $selected++ }
            }
        }
        if ($selected -gt 0) {
            & cargo nextest run @arguments --no-tests fail --no-fail-fast *> $runLog
            $runExit = $LASTEXITCODE
            Get-Content -LiteralPath $runLog -Tail 8
        }
    } else {
        Get-Content -LiteralPath $selectionErrorPath -Tail 12
    }
    Assert-Inputs
    $summary = if (Test-Path -LiteralPath $runLog) {
        @(Get-Content -LiteralPath $runLog | Select-String -Pattern '^\s*Summary \[' | ForEach-Object { $_.Line.Trim() })
    } else { @() }
    $results.Add([ordered]@{
        name = $step.name
        package = $step.package
        target = $step.target
        kind = $step.kind
        arguments = $arguments
        startedUtc = $stepStart
        finishedUtc = [DateTime]::UtcNow.ToString('o')
        selectionExit = $selectionExit
        selectionHash = (Get-FileHash -LiteralPath $selectionPath -Algorithm SHA256).Hash.ToLowerInvariant()
        selectionStderrHash = (Get-FileHash -LiteralPath $selectionErrorPath -Algorithm SHA256).Hash.ToLowerInvariant()
        selectedRunnable = $selected
        selectedIgnored = $selectedIgnored
        identities = @($identities.ToArray())
        runExit = $runExit
        runLogHash = if (Test-Path -LiteralPath $runLog) { (Get-FileHash -LiteralPath $runLog -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null }
        result = if ($selectionExit -ne 0) { 'compile-or-list-failed' } elseif ($selected -eq 0) { 'compiled-no-runnable-tests' } elseif ($runExit -eq 0) { 'passed' } else { 'failed' }
        summary = $summary
    })
    Save-Receipt
    Write-Output ('DONE ' + $step.name + ' selected=' + $selected + ' ignored=' + $selectedIgnored + ' list=' + $selectionExit + ' run=' + $runExit)
}
$failures = @($results | Where-Object { $_.selectionExit -ne 0 -or ($null -ne $_.runExit -and $_.runExit -ne 0) })
Write-Output ('TERMINAL steps=' + $results.Count + ' failedSteps=' + $failures.Count)
if ($failures.Count -gt 0) { exit 100 }



