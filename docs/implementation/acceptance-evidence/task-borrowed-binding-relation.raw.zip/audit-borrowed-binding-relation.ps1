$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/borrowed-binding-relation.final-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/borrowed-binding-relation.final-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/borrowed-binding-relation.final-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1625 tests run: 1619 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1625\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/borrowed-binding-relation.final-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1625 -or $terminal.Count -ne 1625 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$previous=Get-Content -Raw "$root/binding-operand-projection.final-terminal.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Id|Sort-Object) @($selected|Sort-Object)).Count){throw 'Selected test IDs changed'}
$failed=@($terminal | Where-Object Result -eq 'FAIL' | ForEach-Object Name | Sort-Object)
$baseline=Get-Content -Raw "$root/original-context-retention-fixed.owner-summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$new=@($terminal | Where-Object Name -Match 'types::constraints::transaction::operand::projection::tests::')
if($new.Count -ne 4 -or @($new | Where-Object Result -ne 'PASS').Count){throw 'Owner regressions missing'}
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Source changed'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    $baseText=@(git show "$($pin.Base):$($p.Path)" 2>$null); $baseLines=if($LASTEXITCODE -eq 0){$baseText.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '/tests(?:/|\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=0;SHA256=$p.SHA256;Blob=$p.Blob}
})
$terminal | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/borrowed-binding-relation.final-terminal.json"
[ordered]@{Version=1;Base=$pin.Base;Selected=1625;Passed=1619;Failed=6;Skipped=0;SlowTests=if($summary.Groups['slow'].Success){[int]$summary.Groups['slow'].Value}else{0};IdsEqual=$true;SameSelectedIdsAsPrevious=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};RetainedProjectionTests=$new.Name;SourcePinsVerified=$true;ClippyExit=0;FmtExit=0;Measurements=$measurements;Ownership='The existing candidate relation owns Choice, alias, binder, occurs, type and scalar relations. Unchanged type operands are borrowed through their original references; only a changed alias contributes an owned replacement. Generic-to-generic type and const bindings pass the selected existing term rather than reconstructing a reference-only term. Removed one-use helpers whose split discarded the whole selected operand. No new state, traversal, authority, dependency, visibility, unsafe, I/O, version or budget change. This does not complete scoped binding-map, alias-proof, normalization, effect or capture-seal migration.';ReverseEvidence='Private implementation of the same Sema relation, with the same eligibility, relation direction, work accounting and binding entry points. Full Sema owner/frontend/API tests exercise its consumers. Resolved three-mode 22-package closure and Cargo inputs remain unchanged. The 21-consumer results are pinned to 8b5e375a9c7b3096fe5ed2f65df556a463741a8d and are not a new run.';Development='No new tests that mirror implementation spelling. Existing full-owner behavioral, alias, scope, Choice and fixed-budget tests are the selected evidence. The post-clean build recompiles dependencies. No measured throughput or allocation performance claim is made.'} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$root/borrowed-binding-relation.summary.json"
Get-Content "$root/borrowed-binding-relation.summary.json" -TotalCount 16
