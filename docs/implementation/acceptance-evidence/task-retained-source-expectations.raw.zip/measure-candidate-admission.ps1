param([string]$Label)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$base=git rev-parse HEAD
if($base -ne '4abf0111cde59c9070eb5b8e46dfb36b8fd7415c'){throw 'Unexpected diagnostic base.'}
git diff --check
if($LASTEXITCODE -ne 0){throw 'Diagnostic diff check failed.'}
git diff -- | Set-Content -LiteralPath (Join-Path $d "$Label.patch") -Encoding utf8NoBOM
$blobs=[ordered]@{}
foreach($path in @(git diff --name-only --)){$blobs[$path]=git hash-object --path=$path -- $path}
$env:CARGO_INCREMENTAL='0'
$env:CARGO_TERM_COLOR='never'
$env:ARCWEFT_TRACE_CANDIDATE_BUDGET='1'
$arguments=@('nextest','run','--locked','-p','arcweft-lang-sema','--lib','--no-fail-fast','--no-tests','fail','--failure-output','immediate','-E','test(t_lim_12_007)')
$log=Join-Path $d "$Label.log"
$start=(Get-Date).ToString('o')
"Starting candidate accounting measurement"
& cargo @arguments *> $log
$code=$LASTEXITCODE
[ordered]@{version=1;base=$base;blobs=$blobs;command=@('cargo')+$arguments;started=$start;finished=(Get-Date).ToString('o');exit=$code;log=(Split-Path -Leaf $log);log_sha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant()} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $d "$Label.json") -Encoding utf8NoBOM
Select-String -LiteralPath $log -Pattern '^error|^ *Summary ' | Select-Object -Last 10 | ForEach-Object Line
exit $code
