param([ValidateSet('Sema','Reverse','Cli')][string]$Phase)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
function Merge-NextestResults([hashtable]$Map,[string]$File){
    $path=Join-Path $d $File
    foreach($line in Get-Content -LiteralPath $path){
        if($line -match '^\s+(PASS|FAIL|SKIP)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(.+?)\s*$'){
            $status=$Matches[1]
            $id=$Matches[2]+' '+$Matches[3]
            $Map[$id]=$status
        }
    }
}
function Compare-Results([hashtable]$Old,[hashtable]$Current){
    $transitions=@(foreach($pair in $Old.GetEnumerator()){
        if($Current.ContainsKey($pair.Key) -and $pair.Value -ne $Current[$pair.Key]){
            [ordered]@{id=$pair.Key;before=$pair.Value;after=$Current[$pair.Key]}
        }
    })
    [ordered]@{
        baseline=[ordered]@{passed=@($Old.Values | Where-Object {$_ -eq 'PASS'}).Count;failed=@($Old.Values | Where-Object {$_ -eq 'FAIL'}).Count}
        current=[ordered]@{passed=@($Current.Values | Where-Object {$_ -eq 'PASS'}).Count;failed=@($Current.Values | Where-Object {$_ -eq 'FAIL'}).Count}
        missing=@($Old.Keys | Where-Object {-not $Current.ContainsKey($_)} | Sort-Object)
        added=@(foreach($id in $Current.Keys | Sort-Object){if(-not $Old.ContainsKey($id)){[ordered]@{id=$id;status=$Current[$id]}}})
        transitions=@($transitions | Sort-Object { $_.id })
    }
}
$old=@{}
$current=@{}
switch($Phase){
    'Sema' {
        Merge-NextestResults $old 'candidate-budget.dev02-sema.log'
        Merge-NextestResults $current 'candidate-admission.dev05-sema.log'
    }
    'Reverse' {
        Merge-NextestResults $old 'candidate-budget.dev02-reverse.log'
        Merge-NextestResults $current 'candidate-admission.dev06-reverse.log'
    }
    'Cli' {
        Merge-NextestResults $old 'candidate-budget.dev02-cli.log'
        Merge-NextestResults $old 'candidate-budget.dev02-cli-fixtures.log'
        Merge-NextestResults $current 'candidate-admission.dev06-cli.log'
        Merge-NextestResults $current 'candidate-admission.dev06-cli-fixtures.log'
    }
}
if(!$old.Count -or !$current.Count){throw 'Empty Nextest comparison.'}
$result=Compare-Results $old $current
$changed=@($result.transitions | Where-Object {$_.after -ne 'PASS'})
[ordered]@{version=1;phase=$Phase;comparison=$result;observed_at=(Get-Date).ToString('o')} |
    ConvertTo-Json -Depth 7 | Tee-Object -FilePath (Join-Path $d ("candidate-admission.dev06-compare-"+$Phase.ToLowerInvariant()+'.json'))
if($result.missing.Count -or $changed.Count -or @($result.added | Where-Object {$_.status -ne 'PASS'}).Count){throw 'Newly missing or failing tests.'}


