param([string]$Label)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$path=Join-Path $d "$Label.log"
$records=[Collections.Generic.List[object]]::new()
$current=$null
foreach($line in Get-Content -LiteralPath $path){
    if($line -match 'ARCWEFT_CANDIDATE_BUDGET start=(\d+) ResolverWork \{ consumed: (\d+), limit: (\d+), resolver: (\d+), argument_mapping: (\d+), type_checks: (\d+)'){
        if($null -ne $current){throw 'Candidate start without finish.'}
        $current=[ordered]@{candidate=[int]$Matches[1];before=[int]$Matches[2];limit=[int]$Matches[3];resolver_before=[int]$Matches[4];mapping_before=[int]$Matches[5];type_checks_before=[int]$Matches[6];submit=@()}
    } elseif($line -match 'ARCWEFT_SUBMIT_BUDGET (\w+)=(\d+)'){
        if($null -ne $current){$current.submit+=@([ordered]@{phase=$Matches[1];work=[int]$Matches[2]})}
    } elseif($line -match 'ARCWEFT_CANDIDATE_BUDGET finish=(\d+) succeeded=(true|false) ResolverWork \{ consumed: (\d+), limit: (\d+), resolver: (\d+), argument_mapping: (\d+), type_checks: (\d+)'){
        if($null -eq $current -or [int]$Matches[1] -ne $current.candidate){throw 'Candidate finish without its start.'}
        $current.succeeded=$Matches[2] -eq 'true'
        $current.after=[int]$Matches[3]
        $current.resolver_after=[int]$Matches[5]
        $current.mapping_after=[int]$Matches[6]
        $current.type_checks_after=[int]$Matches[7]
        $current.units=$current.after-$current.before
        $records.Add($current)
        $current=$null
    }
}
if($null -ne $current -or !$records.Count){throw 'Incomplete candidate transcript.'}
$costs=@($records | Where-Object succeeded | Group-Object {$_.units} | Sort-Object Count -Descending | ForEach-Object {[ordered]@{units=[int]$_.Name;number=$_.Count}})
$r=[ordered]@{version=1;records=$records.Count;costs=$costs;first=@($records|Select-Object -First 4);last=@($records|Select-Object -Last 3);all=$records.ToArray();observed_at=(Get-Date).ToString('o')}
$r | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $d "$Label.summary.json") -Encoding utf8NoBOM
$r.Remove('all')
$r | ConvertTo-Json -Depth 8
