$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$prefix = 'line-out-producer-20261108'
$source = Get-Content "$taskTemp/$prefix.source.verified.json" -Raw | ConvertFrom-Json
if ((& git rev-parse HEAD).Trim() -ne $source.commit) { throw 'Producer source differs from main.' }
$quality = [ordered]@{}
foreach ($pair in @(@('owner', 'owner.receipt'), @('clippy', 'quality.clippy.receipt'), @('testClippy', 'test-quality.receipt'), @('fmt', 'fmt.receipt'), @('resultCases', 'result-cases.receipt'))) {
    $receipt = Get-Content "$taskTemp/$prefix.$($pair[1]).json" -Raw | ConvertFrom-Json
    if ($receipt.exitCode -ne 0) { throw "Unfinished gate: $($pair[0])" }
    $quality[$pair[0]] = $receipt
}
foreach ($row in $quality.fmt.hashes) {
    if ((Get-FileHash -LiteralPath $row.path).Hash -ne $row.sha256) { throw 'Published source differs from tested bytes.' }
}
$ledgerPath = 'D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before = [IO.File]::ReadAllText($ledgerPath)
if ($before.Contains('"lineOutProducer"')) { throw 'Producer evidence already recorded.' }
$archivePath = 'D:/git/arcweft/docs/implementation/acceptance-evidence/task-line-out-producer.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Archive already exists.' }
$names = @(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*" | ForEach-Object Name) + @('record-line-out-producer-20261108.ps1') | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object { Join-Path $taskTemp $_ }) -DestinationPath $archivePath -CompressionLevel Optimal
$entries = @($names | ForEach-Object { [ordered]@{entry=$_;bytes=(Get-Item "$taskTemp/$_").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$_").Hash.ToLowerInvariant()} })
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $entries.Count) { throw 'Archive count mismatch.' }
    foreach ($entry in $zip.Entries) {
        $expected = $entries | Where-Object { $_.entry -eq $entry.FullName }
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256) { throw 'Archive entry mismatch.' }
    }
} finally { $zip.Dispose() }
$record = [ordered]@{
    version=1;date='2026-11-08';source=$source
    behavior=@('Direct checked Line capability calls use the same typed command/site/capture draft factory as let bindings.', 'An already admitted expression-result local owns the produced value before a Move into CommitDialogueResult; no copied handle or invented temporary identity.', 'Other out values use the ordinary source-order, budgeted value continuation. Pure result commitment remains the existing operation.')
    actual=[ordered]@{
        compiler=[ordered]@{run=99;passed=97;failed=2;skipped=0;receipt=(Get-Content "$taskTemp/$prefix.compiler.receipt.json" -Raw | ConvertFrom-Json);note='Same tested producer bytes before adding the effectful-out test. No synthetic 100-case run.'}
        resultCases=[ordered]@{run=2;passed=2;failed=0;skipped=98;cases=@('line_result_direct_acquisition_uses_its_owning_line_plan','line_result_effectful_call_keeps_its_value_continuation_and_source_order');backends=@('Native','decoded AWBC with public JSON save and cold restore each step');operationBound=1;tickBound=512;stageAcquireAndRelease=1;note='Additional test plus direct Actor rerun, a separate execution from the 99-case result.'}
        owner=[ordered]@{run=134;passed=134;failed=0;skipped=1;skippedCase='awbc_lower::tests::program_fanout::regenerate_presentation_cancellation_fixtures';skipReason='Existing ignored fixture generator; no default filter or ignore change.'}
        quality=$quality
    }
    corrections=@('Replace the current direct-out remaining-work clause because the original failing Actor input now completes in Native and saved AWBC. Keep the original RuntimePlanLower rejection and all Source SHAs in the earlier immutable evidence.', 'The earlier 10-case 7 PASS / 3 FAIL record remains a run of its original Source; this 99-case run and later 2-case run do not rewrite or add to its counts.', 'Previously accepted Generic Match, Line/init and Native bounded features remain accepted. The two new unresolved capture conditions retain their concrete reproductions.')
    remainingFailures=@('ordinary_defer::native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line: unknown runtime local declaration 4', 'ordinary_defer::saved_awbc_ordinary_flow_defer_keeps_returned_line_actor_until_its_cleanup: invalid ordinary deferred scope transition at tick 15')
    reverseGraph=(Get-Content "$taskTemp/$prefix.reverse-graph.json" -Raw | ConvertFrom-Json)
    ownershipReview=(Get-Content "$taskTemp/$prefix.ownership-review.json" -Raw | ConvertFrom-Json -Depth 15)
    limits=@('The RuntimePlan reverse closure is 16 packages, contained in the pending Core53 final convergence matrix. No fresh 16-package or Core53 all-consumer run is claimed.', 'Core 2323 tests and 80 doctests at ddd7307237fb1697e15cc5cadf6efe00426ea07c retain unchanged relevant Core inputs; these are reused, not new runs.', 'The structural gate is reused for unchanged crate/state/public/wire boundaries; exact touched-owner measurements and cohesion reasons are retained.', 'Broader nested Line capability composition, Native public save and final Native/Web visual acceptance are not established by these cases.')
    raw=[ordered]@{path='task-line-out-producer.raw.zip';sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$fragment = ([ordered]@{lineOutProducer=$record} | ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last = $before.LastIndexOf('}')
$after = $before.Substring(0,$last).TrimEnd() + ",`n  " + $fragment.Substring(1,$fragment.Length-2).Trim() + "`n}`n"
$null = $after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($ledgerPath,$after,[Text.UTF8Encoding]::new($false))
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — Line out の所有する producer と値継続

Source **$($source.commit)** を既存 main へ通常 commit/pushし、親・tree・全 blob・完全差分を照合した。直接のLine capabilityはletと同じ型付きoperation factoryへ渡し、事前admission済みの式結果localから一度だけMoveして結果をcommitする。通常のout値はsource orderとbudgetを持つ値継続へ接続し、旧pure-expression直通の分岐を置き換えた。新しいhandleの複製・temp ID・wire versionは作らない。
同じproducer bytesのevaluated_effects全99件は97 PASS／2 FAIL。元の直接Actor取得outはNativeと毎step公開保存／cold restoreするAWBCの両方でPASS。その後に効果付き関数のoutを追加し、直接Actorと合わせた別runの2件はPASS。ログ順序value→body、1-op／512-step、実ledgerの取得・解放各1回を維持した。99件を100件の新runに合成しない。RuntimePlan ownerは134 PASS／1 SKIPで、SKIPは既存のfixture再生成用ignored test。RuntimePlan／Compiler全target・全feature Clippy、追加test targetのClippy、3 Rust pathのfmtは終了0。警告は原本に保持する。
直接outの未達列挙は、同じ失敗入力が通過した具体的な理由を添えて現状一覧で置換した。先行Sourceの3失敗と全SHA・rawは履歴のまま保持する。残る2実測はcleanup内Lineの捕捉contextとAWBC通常defer捕捉の拒否で、既受入のNative範囲／Line-init／Generic Matchを戻さない。RuntimePlanの逆依存は16 package。最終Core53／workspaceの再検証は未実施で、Core2323件とdoctest80件は未変更のCore入力の前runを再利用する。[全結果・訂正・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$anchor='新しい入力で、cleanup内Lineの捕捉先誤り（unknown local 4）、AWBC通常defer捕捉の登録拒否、直接outするLine操作のlowering拒否を再現した。この3条件とAWBC取消し・登録／子構築前の集約検査は継続中。'
if ([regex]::Matches($status,[regex]::Escape($anchor)).Count -ne 1) { throw 'Current capture clause differs.' }
$replacement='直接outのLine操作はSource '+$source.commit+' で既存factoryと値継続へ接続し、元のActor入力と効果付き関数の結果をNative／保存付きAWBCで検証したため、旧lowering拒否の列挙を置換した。evaluated_effectsは99件中97 PASS／2 FAIL、追加後の結果2件は別runでPASS。残る実測はcleanup内Lineの捕捉先誤り（unknown local 4）とAWBC通常defer捕捉の登録拒否。AWBC取消し・登録／子構築前の集約検査も継続中。'
$status=$status.Replace($anchor,$replacement)
$gateAnchor='新Sourceのworkspace全体／Core53再検証は未実施。'
if ([regex]::Matches($status,[regex]::Escape($gateAnchor)).Count -ne 1) { throw 'Current gate clause differs.' }
$status=$status.Replace($gateAnchor,'追加Source '+$source.commit+' はRuntimePlan owner134件／1 SKIP、RuntimePlan・Compilerの全target／全feature Clippyと3 path fmtを確認。Core入力は不変。新Sourceのworkspace全体／Core53再検証は未実施。')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;entries=$entries.Count;rawSha256=$record.raw.sha256;ownerPassed=134;compilerPassed=97;compilerFailed=2;resultCases=2} | ConvertTo-Json
