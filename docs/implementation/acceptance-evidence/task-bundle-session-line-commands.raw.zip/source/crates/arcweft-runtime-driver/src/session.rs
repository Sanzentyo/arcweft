use self::root_command::PendingRootCommandResult;
use self::virtualization::validate_virtual_list_scroll_owner;
use crate::clock::RuntimeClockStep;
use crate::dialogue::{
    BundlePresentationInput, BundlePresentationTransition, DialogueAdvanceRejection,
    DialogueAdvanceTarget, DialoguePresentationStore,
};
use crate::display::{
    BundlePresentationResources, BundlePresentationSnapshot, CatalogDialogueRuntimeContextProvider,
    DisplayResolution, resolve_display_frames,
};
use crate::fx_runtime::BundleFxRuntimeError;
use crate::generation_runtime::{
    GenerationRuntimeError, GenerationRuntimeImage, GenerationRuntimeTable,
};
use crate::session_save::{
    BUNDLE_SESSION_SAVE_SCHEMA_ID, BUNDLE_SESSION_SAVE_SCHEMA_VERSION,
    BundleSessionArtifactIdentity, BundleSessionCharacterPresentationSnapshot,
    BundleSessionExecutorSnapshot, BundleSessionGenerationSnapshot, BundleSessionPendingBlocker,
    BundleSessionRuntimeSnapshot, BundleSessionSaveError, BundleSessionSavePayload,
    BundleSessionSnapshot, digest_label, validate_presentation_runtime_status,
    validate_presentation_snapshot,
};
use crate::swap::{
    GenerationBuildError, ProgramGeneration, SwapCompatibility, SwapError, SwapSession,
    classify_swap_for_entry,
};
use crate::task::{
    HostTaskDispatch, RuntimeTaskCancelOutcome, RuntimeTaskCancelTarget, RuntimeTaskListOptions,
    RuntimeTaskOwner, RuntimeTaskRecord, RuntimeTaskRegistry,
};
use crate::text_control_writeback::RuntimeTextControlWriteBack;
use crate::view_projection::{ViewProjectionInput, project_view_resources};
use crate::view_runtime::{
    BundleViewDiagnostic, BundleViewDiagnosticCode, BundleViewEventDispatchError,
    BundleViewRuntime, BundleViewRuntimeError, reconciled_root_handles_for_restore,
};
use arcweft_bundle::container::{ArtifactIdentity, BundleDigest, BundleView, ReadBudget};
use arcweft_bundle::fx_definitions::FxDefinitions;
use arcweft_bundle::patch::{
    BundlePatchArtifact, PatchBundleError, PatchCompatibility, PatchMaterializedTarget,
    PatchValidationError, apply_patch_bundle, decode_patch_bundle,
};
use arcweft_bundle::resource_codec::{
    ViewProgramResource, ViewRuntimeActionButton, ViewRuntimeFocusGroup,
    ViewRuntimeFocusNavigation, ViewRuntimeScrollRegion, ViewRuntimeSurface,
    ViewRuntimeTextControl, ViewRuntimeTextSelection,
};
use arcweft_bundle::{ArcweftBundle, BundleKind};
use arcweft_character::presentation_name::AcceptedCharacterPresentationCatalog;
use arcweft_core::awbc::{
    product_step::AwbcProductStepBuildError,
    schema::{AwbcEntryId, AwbcProgram},
};
use arcweft_core::effect::{LineEffectRequest, RuntimeAssertionFailure};
use arcweft_core::engine::{FlowFiberStatus, FlowStatusLabelStyle};
use arcweft_core::executor::{
    ArcweftRuntimeExecutor, ArcweftRuntimeExecutorGenerationError, ArcweftRuntimeExecutorSnapshot,
    RuntimeExecutor,
};
use arcweft_core::observation::RuntimeObservationState;
use arcweft_core::plan::{EntryRuntimeId, FlowEvent};
use arcweft_core::presentation::{RuntimeLineHostCommand, RuntimeLineHostOutcome};
use arcweft_core::pure::{RuntimePureCallBackend, VmRuntimePureCallBackend};
use arcweft_core::root::{RootEventInput, RootTransitionOutcome, RuntimeCommandEnvelope};
use arcweft_core::step::{
    RuntimeDialogueInputActionEvent, RuntimeHostCallError, RuntimeHostCallErrorKind,
    RuntimeHostCallId, RuntimeHostCallRequest, RuntimeHostCallResult, RuntimeStepBudget,
    RuntimeStepInput, RuntimeStepMode, RuntimeStepOptions, RuntimeStepStats, RuntimeStepStopReason,
};
use arcweft_core::task::GenerationId;
use arcweft_core::task::{
    CancelScopeId, LogicalEpoch, RuntimeNeedState, TaskEvent, TaskEventKind, TaskId, TaskSequence,
};
use arcweft_core::value::{RuntimeBinding, RuntimeFormatContext, RuntimePayload, RuntimeValue};
use arcweft_id::LocaleTag;
use arcweft_interaction_model::audio::{AudioCommandEnvelope, AudioEvent};
use arcweft_interaction_model::id::Identifier;
use arcweft_interaction_model::input::{
    InputActionId, InputEpoch, InputEventKind, InputSequence, InteractionTarget, RoutedInputEvent,
};
use arcweft_interaction_model::payload::InteractionPayload;
use arcweft_interaction_model::presentation::PresentationImage;
use arcweft_manifest_model::ProjectLocaleSpec;
use arcweft_presentation::appearance::{
    PresentationEnvironment, PresentationEnvironmentField, PresentationEnvironmentOverrides,
    PresentationEnvironmentValue, PresentationEnvironmentValues, SystemPaletteSet,
};
use arcweft_presentation::input::Action;
use arcweft_presentation::text_input::TextControlWriteBack;
use arcweft_resource_model::registry::ResourceTypeRegistry;
use arcweft_text_model::DialogueContentCatalog;
use arcweft_view::ViewHandlerInvocation;
use arcweft_view::{ViewStyleProgram, virtualization::ViewVirtualizationRuntime};
use std::collections::BTreeMap;
use std::sync::Arc;
use thiserror::Error;

mod axis_seed;
mod construction;
pub mod environment;
mod fx;
mod hot_swap;
mod lifecycle;
mod persistence;
mod replay;
mod root_command;
mod text_control;
mod virtualization;

pub use self::environment::{
    PresentationEnvironmentUpdate, PresentationEnvironmentUpdateError, SessionEnvironmentState,
};
pub use self::replay::{
    ROOT_REPLAY_ENGINE_IDENTITY, ROOT_REPLAY_SAVE_SCHEMA_ID, ROOT_REPLAY_SCHEMA_VERSION,
    RecordedExternalOutcome, RecordedExternalOutcomePositionV1, RecordedExternalOutcomeResultV1,
    RecordedHostCallErrorKindV1, RecordedRootOutcomeV1, RecordedRootTransitionV1, RootReplayError,
    RootReplayRecorderV1, RootReplayRecordingError, RootReplayReportV1, RootReplayStepError,
    RootReplayTraceV1,
};
pub use self::root_command::{
    RootCommandHostArgument, RootCommandHostCallBinding, RootCommandHostCallCatalog,
    RootCommandHostCallCatalogError, RootCommandHostCallEndpoint, RootCommandHostResultRoute,
};
pub use self::virtualization::BundleVirtualListMountError;
use construction::{SessionRuntime, build_session_runtime};
use text_control::apply_text_control_write_back_to_controls;

/// Host-selected options for a portable bundle session.
#[derive(Clone, Debug, PartialEq)]
pub struct BundleSessionOptions {
    pub entry: Option<EntryRuntimeId>,
    /// Host-selected initial locale; otherwise the bundle project default.
    pub active_locale: Option<LocaleTag>,
    pub mode: RuntimeStepMode,
    pub max_ops: usize,
    pub view_root_bindings: Vec<RuntimeBinding>,
    pub root_command_host_calls: RootCommandHostCallCatalog,
    /// Immutable engine-owned resource types used as the base when an AWFB
    /// publishes extension manifests.
    pub engine_resource_types: Arc<ResourceTypeRegistry>,
    /// Complete host provider snapshot, or `None` when no provider is available.
    pub presentation_environment: Option<PresentationEnvironmentValues>,
}

impl Default for BundleSessionOptions {
    fn default() -> Self {
        Self {
            entry: None,
            active_locale: None,
            mode: RuntimeStepMode::Game,
            max_ops: 64,
            view_root_bindings: Vec::new(),
            root_command_host_calls: RootCommandHostCallCatalog::default(),
            engine_resource_types: Arc::new(ResourceTypeRegistry::empty()),
            presentation_environment: None,
        }
    }
}

/// Host data supplied to one portable runtime step, excluding logical time.
#[derive(Debug, Default, PartialEq)]
pub struct BundleStepInput {
    pub view_bindings: Vec<RuntimeBinding>,
    pub root_events: Vec<RootEventInput>,
    /// Typed later-phase/Agent events that become root ingress next step.
    pub deferred_root_events: Vec<RootEventInput>,
    pub presentation_inputs: Vec<BundlePresentationInput>,
    pub input_events: Vec<RoutedInputEvent>,
    pub dialogue_input_actions: Vec<RuntimeDialogueInputActionEvent>,
    pub need_states: Vec<RuntimeNeedState>,
    pub task_events: Vec<TaskEvent>,
    pub audio_events: Vec<AudioEvent>,
    pub host_call_results: Vec<RuntimeHostCallResult>,
    /// Outcomes for commands issued by an earlier step, with their original identity.
    pub line_outcomes: Vec<RuntimeLineHostOutcome>,
}

/// Result of routing an input action from one observed dialogue View occurrence.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DialogueInputActionQueueOutcome {
    Queued,
    Rejected(DialogueAdvanceRejection),
}

/// Runtime-ready input after pending host work and presentation routing are resolved.
struct PreparedBundleStepInput {
    runtime: RuntimeStepInput,
    routed_input_events: Vec<RoutedInputEvent>,
    presentation_transitions: Vec<BundlePresentationTransition>,
    text_control_write_backs: Vec<RuntimeTextControlWriteBack>,
    diagnostics: Vec<String>,
}

/// One deterministic VM step plus the host work and presentation state it emitted.
#[derive(Debug, PartialEq)]
pub struct BundleSessionStep {
    pub index: usize,
    pub clock: RuntimeClockStep,
    pub stop_reason: RuntimeStepStopReason,
    pub stop_reason_label: String,
    pub fiber_status: FlowFiberStatus,
    pub status_label: String,
    pub stats: RuntimeStepStats,
    pub diagnostics: Vec<String>,
    /// Typed assertion failures admitted at this host boundary. Successful
    /// assertions were omitted by the runtime and never enter this vector.
    pub assertion_failures: Vec<RuntimeAssertionFailure>,
    pub observations: RuntimeObservationState,
    pub flow_events: Vec<FlowEvent>,
    pub root_initializations: Vec<arcweft_core::root::RootInitializationOutcome>,
    pub root_transitions: Vec<RootTransitionOutcome>,
    pub root_commands: Vec<RuntimeCommandEnvelope>,
    pub deferred_root_events: Vec<RootEventInput>,
    pub requested_host_calls: Vec<RuntimeHostCallRequest>,
    pub line_effects: Vec<LineEffectRequest>,
    pub presentation_transitions: Vec<BundlePresentationTransition>,
    pub presentation: BundlePresentationSnapshot,
    pub text_control_write_backs: Vec<RuntimeTextControlWriteBack>,
    pub audio_commands: Vec<AudioCommandEnvelope>,
    /// Dialogue commands for the host to execute and acknowledge through `BundleStepInput`.
    pub line_commands: Vec<RuntimeLineHostCommand>,
    pub requested_tasks: Vec<HostTaskDispatch>,
    pub program_task_completions: Vec<arcweft_core::task::ProgramTaskCompletion>,
    pub cancel_scopes: Vec<CancelScopeId>,
    pub finished: bool,
}

/// Foreground-entry start request for the current single-fiber runtime driver.
///
/// `SessionDefault` reuses the entry selected when the generation runtime image
/// was built from `BundleSessionOptions`. `Entry` is an explicit AWBC entry table
/// id supplied by a caller that already resolved public launch metadata.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum BundleEntryStart {
    #[default]
    SessionDefault,
    Entry(AwbcEntryId),
}

impl BundleEntryStart {
    #[must_use]
    pub const fn session_default() -> Self {
        Self::SessionDefault
    }

    #[must_use]
    pub const fn entry(entry: AwbcEntryId) -> Self {
        Self::Entry(entry)
    }
}

impl From<AwbcEntryId> for BundleEntryStart {
    fn from(entry: AwbcEntryId) -> Self {
        Self::Entry(entry)
    }
}

fn dialogue_fx_instances(
    presentations: &DialoguePresentationStore,
) -> std::collections::BTreeSet<arcweft_presentation::fx::FxInstanceId> {
    presentations
        .iter()
        .flat_map(|dialogue| {
            dialogue.entries().iter().flat_map(move |entry| {
                entry.frame().fx_applications().map(move |application| {
                    entry
                        .fx_instance_identity(dialogue.id(), application)
                        .instance()
                })
            })
        })
        .collect()
}

/// Minimal observable handle for a newly started foreground entry.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct StartedForegroundEntry {
    pub generation: GenerationId,
    pub entry: AwbcEntryId,
}

/// Portable decoded bundle execution session.
#[derive(Debug)]
pub struct BundleSession {
    source_label: String,
    executor: ArcweftRuntimeExecutor,
    runtime_images: GenerationRuntimeTable<SessionRuntime>,
    dialogue_content: DialogueContentCatalog,
    character_presentation: Option<AcceptedCharacterPresentationCatalog>,
    project_locale: ProjectLocaleSpec,
    active_locale: LocaleTag,
    image_objects: Vec<PresentationImage>,
    text_inputs: Vec<ViewRuntimeTextControl>,
    action_buttons: Vec<ViewRuntimeActionButton>,
    scroll_regions: Vec<ViewRuntimeScrollRegion>,
    surfaces: Vec<ViewRuntimeSurface>,
    focus_groups: Vec<ViewRuntimeFocusGroup>,
    focus_navigation: Vec<ViewRuntimeFocusNavigation>,
    fx_definitions: FxDefinitions,
    view_runtime: BundleViewRuntime,
    environment: SessionEnvironmentState,
    view_style_palettes: SystemPaletteSet,
    engine_resource_types: Arc<ResourceTypeRegistry>,
    resource_types: Arc<ResourceTypeRegistry>,
    options: BundleSessionOptions,
    pending_input_events: Vec<RoutedInputEvent>,
    pending_dialogue_input_actions: Vec<RuntimeDialogueInputActionEvent>,
    pending_presentation_inputs: Vec<BundlePresentationInput>,
    pending_text_control_write_backs: Vec<RuntimeTextControlWriteBack>,
    pending_host_call_results: Vec<RuntimeHostCallResult>,
    pending_deferred_root_events: Vec<RootEventInput>,
    pending_root_command_results: BTreeMap<RuntimeHostCallId, PendingRootCommandResult>,
    waiting_action_receive_calls: Vec<PendingActionReceiveCall>,
    presentation: BundlePresentationSnapshot,
    view_virtualization: ViewVirtualizationRuntime,
    next_step_index: usize,
    next_task_sequence: u64,
    next_dialogue_input_sequence: u64,
    swap: SwapSession,
    /// Generation that owns retained dialogue/View presentation state, even
    /// after the foreground fiber has completed.
    presentation_generation: Arc<ProgramGeneration>,
    runtime_generation_pin: Option<Arc<ProgramGeneration>>,
    task_generation_pins: BTreeMap<TaskSequence, Arc<ProgramGeneration>>,
    pending_restartable_reensure: BTreeMap<TaskId, HostTaskDispatch>,
    tasks: RuntimeTaskRegistry,
    next_generation_id: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct PendingActionReceiveCall {
    request: RuntimeHostCallId,
    action_id: String,
}

/// Error raised before a portable session can start.
#[derive(Debug, Error, PartialEq)]
pub enum BundleSessionError {
    #[error(transparent)]
    ExecutorGeneration(#[from] ArcweftRuntimeExecutorGenerationError),
    #[error("bundle kind `{0:?}` is not supported by the game session")]
    UnsupportedBundleKind(BundleKind),
    #[error("an exact entry selection is required to start a bundle session")]
    MissingEntrySelection,
    #[error("invalid canonical entry selection `{entry}`: {message}")]
    InvalidEntrySelection { entry: String, message: String },
    #[error("unknown entry `{entry}`")]
    UnknownEntry { entry: String },
    #[error("entry `{entry}` does not select a single runnable flow")]
    NonFlowEntry { entry: String },
    #[error(transparent)]
    RootCommandHostCatalog(#[from] RootCommandHostCallCatalogError),
    #[error("failed to verify product AWBC generation: {message}")]
    ProductAwbcVerification { message: String },
    #[error("bundle dialogue Content contract is invalid: {message}")]
    DialogueContentContract { message: String },
    #[error(transparent)]
    ProductAwbcRuntime(#[from] AwbcProductStepBuildError),
    #[error("product AWBC entry `{entry}` does not exist")]
    ProductAwbcEntry { entry: String },
    #[error("failed to fingerprint bundle generation: {message}")]
    GenerationFingerprint { message: String },
    #[error("failed to decode bundle container: {message}")]
    DecodeBundle { message: String },
    #[error("invalid Character presentation product: {message}")]
    CharacterPresentation { message: String },
    #[error("invalid CharacterDialogue runtime generation: {message}")]
    CharacterDialogueGeneration { message: String },
    #[error("unsupported semantic action `{action}` at the game runtime boundary")]
    UnsupportedSemanticAction { action: String },
    #[error("semantic action `{action}` is missing its option payload")]
    MissingSemanticActionPayload { action: String },
    #[error("dialogue input action identity allocator is exhausted")]
    DialogueInputIdentityExhausted,
    #[error(
        "runtime text-control write-back target `{target}` with session {session} is not active"
    )]
    UnknownTextControlWriteBackTarget { target: String, session: u64 },
    #[error(transparent)]
    ViewEvent(#[from] BundleViewEventDispatchError),
    #[error(transparent)]
    ViewRuntime(#[from] BundleViewRuntimeError),
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum BundleEntryStartError {
    #[error("AWBC entry {entry:?} does not exist in the active generation")]
    UnknownEntry { entry: AwbcEntryId },
    #[error("AWBC entry {entry:?} does not select a single runnable flow")]
    NonFlowEntry { entry: AwbcEntryId },
    #[error("generation runtime table failed: {0}")]
    GenerationRuntime(#[from] GenerationRuntimeError),
    #[error(transparent)]
    ProductAwbcRuntime(#[from] AwbcProductStepBuildError),
    #[error(transparent)]
    RootCommandHostCatalog(#[from] RootCommandHostCallCatalogError),
    #[error(transparent)]
    Environment(#[from] PresentationEnvironmentUpdateError),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BundleHotSwapReport {
    pub generation: GenerationId,
    pub compatibility: SwapCompatibility,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BundlePatchReadiness {
    Noop,
    TargetBundleRequired { operations: usize },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BundlePatchReadinessReport {
    pub base_generation: GenerationId,
    pub base_content_root: BundleDigest,
    pub target_content_root: BundleDigest,
    /// Compatibility declared by the decoded patch manifest.
    ///
    /// This value is suitable for inspection only. Applying a patch requires
    /// the verified compatibility returned after bundle materialization.
    pub declared_compatibility: PatchCompatibility,
    pub readiness: BundlePatchReadiness,
}

#[derive(Debug, Error)]
pub enum BundleHotSwapError {
    #[error("bundle session generation identity space is exhausted")]
    GenerationIdExhausted,
    #[error("failed to build bundle generation: {0}")]
    BuildGeneration(#[from] GenerationBuildError),
    #[error("failed to prepare hot swap: {0}")]
    Prepare(#[source] SwapError),
    #[error("failed to commit hot swap: {0}")]
    Commit(#[source] SwapError),
    #[error("bundle session cannot apply `{compatibility}` without host restart")]
    RestartRequired { compatibility: SwapCompatibility },
    #[error("failed to build replacement session runtime: {0}")]
    Session(#[from] BundleSessionError),
    #[error("failed to inspect active entry for hot swap: {message}")]
    ActiveEntry { message: String },
    #[error(
        "hot swap requires empty root work queues (reducer_active={reducer_active}, \
         pending_events={pending_events}, pending_commands={pending_commands}, \
         pending_command_results={pending_command_results})"
    )]
    PendingRootWork {
        reducer_active: bool,
        pending_events: usize,
        pending_commands: u32,
        pending_command_results: usize,
    },
    #[error("failed to decode AWFB patch bundle: {0}")]
    DecodePatch(#[source] PatchBundleError),
    #[error("invalid AWFB patch artifact: {0}")]
    InvalidPatch(#[source] PatchBundleError),
    #[error("patch does not apply to the active generation: {0}")]
    WrongPatchBase(#[source] PatchValidationError),
    #[error("patch base artifact mismatch: active {active:?}, expected {expected:?}")]
    WrongPatchBaseArtifact {
        active: Box<ArtifactIdentity>,
        expected: Box<ArtifactIdentity>,
    },
    #[error("active session was not created from an AWFB container")]
    MissingActiveContainerIdentity,
    #[error("failed to materialize AWFB patch: {0}")]
    MaterializePatch(#[source] PatchBundleError),
    #[error("failed to decode materialized AWFB patch target: {message}")]
    DecodePatchTarget { message: String },
    #[error("generation runtime table failed: {0}")]
    GenerationRuntime(#[from] GenerationRuntimeError),
    #[error("hot-swap View virtualization contract changed: {message}")]
    ViewVirtualization { message: String },
    #[error("hot-swap executable View state is incompatible: {message}")]
    ViewRuntime { message: String },
    #[error("hot-swap Character presentation state is incompatible: {message}")]
    CharacterPresentation { message: String },
    #[error(transparent)]
    Environment(#[from] PresentationEnvironmentUpdateError),
    #[error(transparent)]
    FxRuntime(#[from] BundleFxRuntimeError),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RuntimeSemanticAction {
    ChoiceSelect,
}

impl RuntimeSemanticAction {
    const fn as_str(self) -> &'static str {
        match self {
            Self::ChoiceSelect => "action.choice.select",
        }
    }

    fn from_action(action: &Action) -> Result<Self, BundleSessionError> {
        let kind = action.kind().as_str();
        match kind {
            "action.choice.select" => Ok(Self::ChoiceSelect),
            _ => Err(BundleSessionError::UnsupportedSemanticAction {
                action: kind.to_owned(),
            }),
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RuntimeInputTargetKind {
    Runtime,
}

impl RuntimeInputTargetKind {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Runtime => "runtime",
        }
    }

    fn target(self) -> InteractionTarget {
        InteractionTarget::new(self.as_str()).expect("static runtime input target is non-empty")
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RuntimeInputKind {
    Choice,
    ActionInvoke,
}

impl RuntimeInputKind {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Choice => "choice",
            Self::ActionInvoke => "action.invoke",
        }
    }

    fn event_kind(self) -> InputEventKind {
        InputEventKind::Custom {
            name: Identifier::new(self.as_str()).expect("static runtime input name is non-empty"),
        }
    }
}

impl BundleSession {
    /// Locale selected for this session's formatter and Character presentation.
    pub const fn active_locale(&self) -> &LocaleTag {
        &self.active_locale
    }

    /// Retains this session's selected program for an asynchronous host result.
    pub fn program_owner(&self) -> arcweft_core::task::RuntimeProgramOwner {
        self.executor.program_owner()
    }

    /// Queues a core input event produced by a platform/presentation adapter.
    pub fn queue_input(&mut self, event: RoutedInputEvent) {
        self.pending_input_events.push(event);
    }

    /// Queues a dialogue action only for the exact occurrence observed by the
    /// input adapter. A stale View token is a rejected input, not a session error.
    pub fn queue_dialogue_input_action(
        &mut self,
        observed: DialogueAdvanceTarget,
        action: InputActionId,
    ) -> Result<DialogueInputActionQueueOutcome, BundleSessionError> {
        match self
            .presentation
            .dialogue
            .resolve_input_action_activation(observed)
        {
            Ok(activation) => {
                let sequence = self.next_dialogue_input_sequence;
                self.next_dialogue_input_sequence = sequence
                    .checked_add(1)
                    .ok_or(BundleSessionError::DialogueInputIdentityExhausted)?;
                let epoch = u64::try_from(self.next_step_index)
                    .map_err(|_| BundleSessionError::DialogueInputIdentityExhausted)?;
                self.pending_dialogue_input_actions
                    .push(RuntimeDialogueInputActionEvent::new(
                        activation,
                        action,
                        InputEpoch::new(epoch),
                        InputSequence::new(sequence),
                    ));
                Ok(DialogueInputActionQueueOutcome::Queued)
            }
            Err(reason) => Ok(DialogueInputActionQueueOutcome::Rejected(reason)),
        }
    }

    /// Final semantic bridge from Arcweft presentation actions to core input
    /// events. DOM controls are never involved.
    pub fn queue_semantic_action(&mut self, action: &Action) -> Result<(), BundleSessionError> {
        match RuntimeSemanticAction::from_action(action) {
            Ok(RuntimeSemanticAction::ChoiceSelect) => {
                let option = action.payload().cloned().ok_or_else(|| {
                    BundleSessionError::MissingSemanticActionPayload {
                        action: RuntimeSemanticAction::ChoiceSelect.as_str().to_owned(),
                    }
                })?;
                self.queue_choice_selection(option);
            }
            Err(BundleSessionError::UnsupportedSemanticAction { .. }) => {
                self.queue_action_invoke(action)?;
            }
            Err(error) => return Err(error),
        }
        Ok(())
    }

    fn queue_action_invoke(&mut self, action: &Action) -> Result<(), BundleSessionError> {
        let target = InteractionTarget::new(action.kind().as_str()).map_err(|_| {
            BundleSessionError::UnsupportedSemanticAction {
                action: action.kind().as_str().to_owned(),
            }
        })?;
        let event = RoutedInputEvent::new(
            InputEpoch::default(),
            InputSequence::default(),
            target,
            RuntimeInputKind::ActionInvoke.event_kind(),
        );
        let event = if let Some(payload) = action.payload() {
            event.with_payload(InteractionPayload::Text(payload.clone()))
        } else {
            event
        };
        self.queue_input(event);
        self.resolve_waiting_action_receive_calls(
            action.kind().as_str(),
            action.payload().map(String::as_str),
        );
        Ok(())
    }

    pub fn queue_choice_selection(&mut self, option: impl Into<String>) {
        self.queue_input(
            RoutedInputEvent::new(
                InputEpoch::default(),
                InputSequence::default(),
                RuntimeInputTargetKind::Runtime.target(),
                RuntimeInputKind::Choice.event_kind(),
            )
            .with_payload(InteractionPayload::Text(option.into())),
        );
    }

    /// Queues a stale-safe advance for the observed dialogue occurrence/stage.
    pub fn queue_dialogue_advance(&mut self, target: DialogueAdvanceTarget) {
        self.pending_presentation_inputs
            .push(BundlePresentationInput::advance_dialogue(target));
    }

    /// Queues a stale-safe semantic reveal completion for the observed stage.
    pub fn queue_dialogue_reveal_completion(&mut self, target: DialogueAdvanceTarget) {
        self.pending_presentation_inputs
            .push(BundlePresentationInput::complete_dialogue_reveal(target));
    }

    fn make_pure_backend(
        &self,
        format_context: RuntimeFormatContext,
    ) -> VmRuntimePureCallBackend<
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend<'static>,
    > {
        let schemas = self
            .runtime_images
            .images()
            .filter_map(|image| image.runtime().character_dialogue_schema.clone())
            .collect::<Vec<_>>();
        let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
            arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::with_generations(
                schemas,
            ),
        );
        backend.set_format_context(format_context);
        backend
    }

    /// Executes a routed View transition and queues any resulting presentation action.
    pub fn queue_view_handler_invocation(
        &mut self,
        invocation: &ViewHandlerInvocation,
    ) -> Result<(), BundleViewEventDispatchError> {
        let format_context = RuntimeFormatContext::new(self.active_locale.clone());
        let mut backend = self.make_pure_backend(format_context.clone());
        if let Some(input) = self.view_runtime.dispatch_invocation_in_session(
            invocation,
            &format_context,
            &mut backend,
            Some(&mut self.executor),
        )? {
            self.pending_presentation_inputs.push(input);
        }
        self.refresh_view_after_event(&mut backend);
        Ok(())
    }

    /// Publish the effects of an accepted UI event before the next adapter
    /// event. The VM clock does not advance; retained roots and inputs remain
    /// the authority used by ordinary frame evaluation.
    fn refresh_view_after_event(
        &mut self,
        backend: &mut impl arcweft_core::pure::RuntimeCallBackend,
    ) {
        let previous_text_inputs = std::mem::take(&mut self.presentation.text_inputs);
        if !self.update_view_presentation(
            &[],
            &previous_text_inputs,
            None,
            &mut Vec::new(),
            backend,
        ) {
            self.presentation.text_inputs = previous_text_inputs;
        }
    }

    pub fn queue_text_control_write_back(
        &mut self,
        write_back: &TextControlWriteBack,
    ) -> Result<(), BundleSessionError> {
        let target = write_back.target().id().as_str();
        if !self
            .presentation
            .text_inputs
            .iter()
            .chain(&self.text_inputs)
            .any(|control| control.target == target && control.session == write_back.session().0)
        {
            return Err(BundleSessionError::UnknownTextControlWriteBackTarget {
                target: target.to_owned(),
                session: write_back.session().0,
            });
        }
        let retained = self.view_runtime.has_retained_text_input(target);
        let format_context = RuntimeFormatContext::new(self.active_locale.clone());
        let mut backend = self.make_pure_backend(format_context.clone());
        if retained {
            if let Some(action) = self.view_runtime.dispatch_text_input_in_session(
                write_back,
                &format_context,
                &mut backend,
                Some(&mut self.executor),
            )? {
                self.pending_presentation_inputs.push(action);
            }
        }
        let runtime_write_back = match apply_text_control_write_back_to_controls(
            &mut self.presentation.text_inputs,
            write_back,
        ) {
            Ok(write_back) => write_back,
            Err(BundleSessionError::UnknownTextControlWriteBackTarget { .. }) => {
                apply_text_control_write_back_to_controls(&mut self.text_inputs, write_back)?
            }
            Err(error) => return Err(error),
        };
        if let Some(source_control) = self.text_inputs.iter_mut().find(|control| {
            control.target == runtime_write_back.target()
                && control.session == runtime_write_back.session()
        }) {
            runtime_write_back
                .value()
                .as_str()
                .clone_into(&mut source_control.value);
            source_control.selection = runtime_write_back.selection();
        }
        self.pending_text_control_write_backs
            .push(runtime_write_back);
        if retained {
            self.refresh_view_after_event(&mut backend);
        }
        Ok(())
    }

    pub fn queue_text_control_write_backs<I>(
        &mut self,
        write_backs: I,
    ) -> Result<(), BundleSessionError>
    where
        I: IntoIterator<Item = TextControlWriteBack>,
    {
        write_backs
            .into_iter()
            .try_for_each(|write_back| self.queue_text_control_write_back(&write_back))
    }

    pub fn pending_text_control_write_backs(&self) -> &[RuntimeTextControlWriteBack] {
        &self.pending_text_control_write_backs
    }

    fn resolve_waiting_action_receive_calls(&mut self, action_id: &str, payload: Option<&str>) {
        let mut index = 0;
        while index < self.waiting_action_receive_calls.len() {
            if self.waiting_action_receive_calls[index].action_id == action_id {
                let call = self.waiting_action_receive_calls.remove(index);
                self.pending_host_call_results.push(RuntimeHostCallResult {
                    id: call.request,
                    outcome: action_receive_payload(action_id, payload),
                });
            } else {
                index += 1;
            }
        }
    }

    /// Executes exactly one VM step using explicit, non-zero logical time.
    #[allow(
        clippy::too_many_lines,
        reason = "one session step is the atomic owner of VM execution, output publication, presentation update, and lifecycle finalization"
    )]
    pub fn step_with_clock(
        &mut self,
        clock: RuntimeClockStep,
        input: BundleStepInput,
    ) -> BundleSessionStep {
        let mut view_bindings = self.options.view_root_bindings.clone();
        view_bindings.extend(input.view_bindings.iter().cloned());
        self.presentation.advance_fx_clock(clock.dt_millis());
        let view_clock_error = self.view_runtime.advance_millis(clock.dt_millis()).err();
        self.swap.enter_runtime_step();
        let PreparedBundleStepInput {
            runtime,
            routed_input_events,
            presentation_transitions,
            text_control_write_backs,
            diagnostics: input_diagnostics,
        } = self.prepare_step_input(clock, input);
        let format_context = RuntimeFormatContext::new(self.active_locale.clone());
        let mut pure_backend = self.make_pure_backend(format_context.clone());
        self.executor.set_format_context(format_context);
        let result = self.executor.step_with_pure_backend(
            runtime,
            RuntimeStepOptions {
                mode: self.options.mode,
                budget: RuntimeStepBudget {
                    max_ops: self.options.max_ops,
                },
                max_new_task_requests: usize::try_from(u64::MAX - self.next_task_sequence)
                    .unwrap_or(usize::MAX),
            },
            &mut pure_backend,
        );
        self.swap.finish_runtime_step();

        let mut stats = result.stats.clone();
        let mut output = result.output;
        let root_initializations = std::mem::take(&mut output.root_initializations);
        let root_transitions = std::mem::take(&mut output.root_transitions);
        let root_commands = std::mem::take(&mut output.root_commands);
        let deferred_root_events = std::mem::take(&mut output.requests.root_events_next_step);
        self.pending_deferred_root_events
            .extend(deferred_root_events.iter().cloned());
        let flow_events = std::mem::take(&mut output.flow_events);
        let line_effects = std::mem::take(&mut output.effects.line);
        let assertion_failures = line_effects
            .iter()
            .filter_map(|effect| match effect {
                LineEffectRequest::Assert(assertion) => {
                    Some(RuntimeAssertionFailure::new(assertion.clone()))
                }
                _ => None,
            })
            .collect();
        let runtime_generation = self.runtime_generation_pin.as_ref().map_or_else(
            || self.swap.active_generation_id(),
            |generation| generation.id,
        );
        let context_provider = self
            .runtime_images
            .get(runtime_generation)
            .ok()
            .map(|image| image.runtime())
            .and_then(|runtime| {
                runtime.character_presentation.as_ref().map(|catalog| {
                    CatalogDialogueRuntimeContextProvider::new(
                        catalog,
                        &runtime.active_locale,
                        &runtime.project_locale,
                        runtime.character_dialogue_schema.as_deref(),
                        runtime.view_runtime.style_program(),
                    )
                })
            });
        let display = resolve_display_frames(
            &self.dialogue_content,
            &flow_events,
            context_provider
                .as_ref()
                .map(|provider| provider as &dyn crate::display::DialogueRuntimeContextProvider),
        );
        let mut diagnostics = output
            .diagnostics
            .into_iter()
            .map(|diagnostic| diagnostic.message)
            .collect::<Vec<_>>();
        diagnostics.extend(input_diagnostics);
        diagnostics.extend(
            presentation_transitions
                .iter()
                .filter_map(presentation_transition_diagnostic),
        );
        diagnostics.extend(display.diagnostics.iter().cloned());
        let mut requested_host_calls =
            self.publish_and_acknowledge_root_commands(&root_commands, &mut diagnostics);
        let previous_text_inputs = self.presentation.text_inputs.clone();
        self.update_presentation_snapshot(&display, &result.fiber_status, &mut diagnostics);
        let view_pure_before = pure_backend.stats();
        self.update_view_presentation(
            &view_bindings,
            &previous_text_inputs,
            view_clock_error,
            &mut diagnostics,
            &mut pure_backend,
        );
        stats.pure = stats
            .pure
            .saturating_add(pure_backend.stats().saturating_delta(view_pure_before));
        self.append_fx_diagnostics(&mut diagnostics);
        let observations = self.executor.fiber().frame.observations.clone();

        let requested_tasks = self.dispatch_requested_tasks(clock, output.requests.tasks);
        requested_host_calls
            .extend(self.capture_view_host_calls(output.requests.host_calls, &routed_input_events));
        let cancel_scopes = output.requests.cancel_scopes;
        self.apply_task_cancellations(&cancel_scopes);
        let audio_commands = output.requests.audio;
        let (index, finished) = self.finish_step_lifecycle(&result.fiber_status);

        BundleSessionStep {
            index,
            clock,
            stop_reason: result.stop_reason,
            stop_reason_label: format!("{:?}", result.stop_reason),
            status_label: result
                .fiber_status
                .status_label(FlowStatusLabelStyle::Runtime),
            fiber_status: result.fiber_status,
            stats,
            diagnostics,
            assertion_failures,
            observations,
            flow_events,
            root_initializations,
            root_transitions,
            root_commands,
            deferred_root_events,
            requested_host_calls,
            line_effects,
            presentation_transitions,
            presentation: self.presentation.clone(),
            text_control_write_backs,
            audio_commands,
            line_commands: output.requests.line_commands,
            requested_tasks,
            program_task_completions: output.requests.program_task_completions,
            cancel_scopes,
            finished,
        }
    }

    fn finish_step_lifecycle(&mut self, fiber_status: &FlowFiberStatus) -> (usize, bool) {
        let finished = !self.tasks.has_active_program_tasks()
            && matches!(
                fiber_status,
                FlowFiberStatus::Done(_) | FlowFiberStatus::Failed(_)
            );
        if finished
            && !self
                .executor
                .product_requires_runtime_generation_pin()
                .expect("bundle sessions own a Product executor")
        {
            self.runtime_generation_pin = None;
            self.retire_unused_generations();
        }
        let index = self.next_step_index;
        self.next_step_index = self.next_step_index.saturating_add(1);
        (index, finished)
    }

    fn apply_task_cancellations(&mut self, cancel_scopes: &[CancelScopeId]) {
        for scope in cancel_scopes {
            self.tasks
                .cancel(&RuntimeTaskCancelTarget::Scope(scope.clone()));
        }
    }

    fn prepare_step_input(
        &mut self,
        clock: RuntimeClockStep,
        mut input: BundleStepInput,
    ) -> PreparedBundleStepInput {
        let mut diagnostics = Vec::new();
        if let Err(error) = self.presentation.dialogue.advance_reveal(clock.dt()) {
            diagnostics.push(error.to_string());
        }
        let mut root_events = std::mem::take(&mut self.pending_deferred_root_events);
        root_events.append(&mut input.root_events);
        input.root_events = root_events;
        let ordinary_host_call_results = self.route_host_call_results(
            input.host_call_results,
            &mut input.root_events,
            &mut diagnostics,
        );
        // Local cancellation has already changed the registry status. Host
        // events still need exact dispatch correlation before reaching Core.
        let submitted_task_events = input.task_events.len();
        let mut task_events = self.tasks.apply_task_events(input.task_events);
        if submitted_task_events > 0 && task_events.is_empty() {
            diagnostics.push("runtime task publication batch was rejected".to_owned());
        }
        task_events.extend(self.tasks.drain_task_events());
        self.release_completed_task_generation_pins(&task_events);
        input.input_events.append(&mut self.pending_input_events);
        input
            .dialogue_input_actions
            .append(&mut self.pending_dialogue_input_actions);
        input
            .presentation_inputs
            .append(&mut self.pending_presentation_inputs);
        let mut dialogue_advances = Vec::new();
        let presentation_transitions =
            self.route_presentation_inputs(input.presentation_inputs, &mut dialogue_advances);
        let routed_input_events = input.input_events.clone();
        let text_control_write_backs = std::mem::take(&mut self.pending_text_control_write_backs);
        let dialogue_content_events = self.presentation.dialogue.take_reached_content_events();
        PreparedBundleStepInput {
            runtime: RuntimeStepInput {
                tick: clock.tick(),
                dt: clock.dt(),
                root_events: input.root_events,
                deferred_root_events: input.deferred_root_events,
                input_events: input.input_events,
                dialogue_input_actions: input.dialogue_input_actions,
                dialogue_content_events,
                dialogue_advances,
                need_states: input.need_states,
                task_events,
                audio_events: input.audio_events,
                host_call_results: self
                    .pending_host_call_results
                    .drain(..)
                    .chain(ordinary_host_call_results)
                    .collect(),
                line_outcomes: input.line_outcomes,
            },
            routed_input_events,
            presentation_transitions,
            text_control_write_backs,
            diagnostics,
        }
    }

    fn route_presentation_inputs(
        &mut self,
        inputs: Vec<BundlePresentationInput>,
        dialogue_advances: &mut Vec<arcweft_core::runtime_id::DialogueActivationId>,
    ) -> Vec<BundlePresentationTransition> {
        let mut transitions = Vec::new();
        for input in inputs {
            match input {
                BundlePresentationInput::CompleteDialogueReveal { target } => {
                    transitions.push(self.presentation.dialogue.complete_reveal(target));
                }
                BundlePresentationInput::AdvanceDialogue { target } => {
                    let (transition, activation) = self.presentation.advance_dialogue(target);
                    if let Some(activation) = activation {
                        dialogue_advances.push(activation);
                    }
                    transitions.push(transition);
                }
            }
        }
        transitions
    }

    pub fn is_finished(&self) -> bool {
        !self.tasks.has_active_program_tasks()
            && matches!(
                &self.executor.fiber().frame.status,
                FlowFiberStatus::Done(_) | FlowFiberStatus::Failed(_)
            )
    }

    fn update_presentation_snapshot(
        &mut self,
        display: &DisplayResolution,
        status: &FlowFiberStatus,
        diagnostics: &mut Vec<String>,
    ) {
        let previous_dialogue_fx = self.presentation.dialogue.clone();
        let frame = match self
            .executor
            .presentation_frame(arcweft_core::entry::RuntimeSchemaLimits::engine_default())
        {
            Ok(frame) => frame,
            Err(error) => {
                diagnostics.push(error.to_string());
                return;
            }
        };
        let presentation_handle_diagnostics = match self.presentation.update(
            display,
            status,
            frame,
            BundlePresentationResources {
                text_inputs: &self.text_inputs,
                action_buttons: &self.action_buttons,
                scroll_regions: &self.scroll_regions,
                surfaces: &self.surfaces,
                focus_groups: &self.focus_groups,
                focus_navigation: &self.focus_navigation,
            },
        ) {
            Ok(diagnostics) => diagnostics,
            Err(error) => {
                diagnostics.push(error.to_string());
                Vec::new()
            }
        };
        diagnostics.extend(
            presentation_handle_diagnostics
                .iter()
                .map(ToString::to_string),
        );
        self.reconcile_dialogue_fx(&dialogue_fx_instances(&previous_dialogue_fx));
    }

    fn reconcile_dialogue_fx(
        &mut self,
        previous: &std::collections::BTreeSet<arcweft_presentation::fx::FxInstanceId>,
    ) {
        let applications = self
            .presentation
            .dialogue
            .iter()
            .flat_map(|dialogue| {
                dialogue.entries().iter().flat_map(move |entry| {
                    entry
                        .frame()
                        .fx_applications()
                        .cloned()
                        .map(move |application| {
                            (
                                entry.fx_instance_identity(dialogue.id(), &application),
                                application,
                            )
                        })
                })
            })
            .collect::<Vec<_>>();
        let current = applications
            .iter()
            .map(|(identity, _)| identity.instance())
            .collect::<std::collections::BTreeSet<_>>();
        let before = self.presentation.fx.clone();
        for instance in previous.difference(&current) {
            self.presentation.fx.remove_instance(*instance);
        }
        let mut failures = self.presentation.fx_diagnostics.clone();
        for (identity, application) in applications {
            if let Err(error) = self.presentation.fx.retain_instance(
                &self.fx_definitions,
                identity,
                application.template().clone(),
                application.template().initial_runtime().to_vec(),
                arcweft_presentation::fx::FxGraphChildPath::default(),
                None,
            ) {
                let diagnostic = error.diagnostic();
                if !failures.contains(&diagnostic) {
                    failures.push(diagnostic);
                }
            }
        }
        if self.presentation.fx != before {
            self.presentation.revision = self.presentation.revision.saturating_add(1);
        }
        if self.presentation.fx_diagnostics != failures {
            self.presentation.fx_diagnostics = failures;
            self.presentation.revision = self.presentation.revision.saturating_add(1);
        }
    }

    fn update_view_presentation(
        &mut self,
        bindings: &[RuntimeBinding],
        previous_text_inputs: &[ViewRuntimeTextControl],
        clock_error: Option<BundleViewRuntimeError>,
        diagnostics: &mut Vec<String>,
        pure_backend: &mut impl arcweft_core::pure::RuntimeCallBackend,
    ) -> bool {
        let previous_fx = self
            .presentation
            .view
            .mounts
            .iter()
            .flat_map(|mount| {
                mount
                    .fx
                    .iter()
                    .map(|application| application.identity.instance())
            })
            .collect::<std::collections::BTreeSet<_>>();
        let source_frame = match self
            .executor
            .presentation_frame(arcweft_core::entry::RuntimeSchemaLimits::engine_default())
        {
            Ok(frame) => frame,
            Err(error) => {
                let diagnostic = BundleViewDiagnostic {
                    code: BundleViewDiagnosticCode::InputType,
                    handle: None,
                    mount: None,
                    view: None,
                    instruction: None,
                    message: error.to_string(),
                };
                diagnostics.push(diagnostic.to_string());
                self.presentation.view.diagnostics.push(diagnostic);
                return false;
            }
        };
        let mut frame = self.view_runtime.evaluate_with_dialogue_and_backend(
            crate::view_runtime::BundleViewRootInput::Execution(source_frame),
            &self.presentation.dialogue.view_inputs(),
            bindings,
            self.environment.effective().reduced_motion(),
            &RuntimeFormatContext::new(self.active_locale.clone()),
            pure_backend,
        );
        if let Some(error) = clock_error {
            frame.diagnostics.push(BundleViewDiagnostic {
                code: BundleViewDiagnosticCode::InvalidValueProgram,
                handle: None,
                mount: None,
                view: None,
                instruction: None,
                message: error.to_string(),
            });
        }
        diagnostics.extend(frame.diagnostics.iter().map(ToString::to_string));
        let replaced_resources = if self.view_runtime.has_program() {
            let projected = project_view_resources(
                &frame,
                &ViewProjectionInput {
                    executable_definitions: &self.view_runtime.definition_ids(),
                    current_images: &self.presentation.images,
                    current_text_inputs: previous_text_inputs,
                    images: &self.image_objects,
                    text_inputs: &self.text_inputs,
                    action_buttons: &self.action_buttons,
                    scroll_regions: &self.scroll_regions,
                    surfaces: &self.surfaces,
                    focus_groups: &self.focus_groups,
                    focus_navigation: &self.focus_navigation,
                },
            );
            self.presentation.replace_view_resources(projected);
            true
        } else {
            false
        };
        self.presentation.replace_view_frame(frame);
        self.reconcile_view_fx(&previous_fx);
        replaced_resources
    }

    fn reconcile_view_fx(
        &mut self,
        previous: &std::collections::BTreeSet<arcweft_presentation::fx::FxInstanceId>,
    ) {
        let applications = self
            .presentation
            .view
            .mounts
            .iter()
            .flat_map(|mount| mount.fx.iter().cloned())
            .collect::<Vec<_>>();
        let current = applications
            .iter()
            .map(|application| application.identity.instance())
            .collect::<std::collections::BTreeSet<_>>();
        let before = self.presentation.fx.clone();
        for instance in previous.difference(&current) {
            self.presentation.fx.remove_instance(*instance);
        }
        let mut failures = self.presentation.fx_diagnostics.clone();
        for application in applications {
            let definition = self.fx_definitions.get(application.identity.definition());
            let Some(definition) = definition else {
                let error = BundleFxRuntimeError::MissingDefinition {
                    definition: Box::new(application.identity.definition().clone()),
                    instance: application.identity.instance(),
                };
                let diagnostic = error.diagnostic();
                if !failures.contains(&diagnostic) {
                    failures.push(diagnostic);
                }
                continue;
            };
            if application.parameter_layout != definition.parameter_layout().digest() {
                let error = BundleFxRuntimeError::ApplicationBinding {
                    definition: Box::new(definition.id().clone()),
                    reason: "View Fx parameter layout digest does not match the definition"
                        .to_owned(),
                };
                let diagnostic = error.diagnostic();
                if !failures.contains(&diagnostic) {
                    failures.push(diagnostic);
                }
                continue;
            }
            let mut arguments = vec![None; definition.parameters().len()];
            let mut binding_error = None;
            for binding in application.arguments {
                let index = usize::from(binding.parameter.get());
                let Some(slot) = arguments.get_mut(index) else {
                    binding_error =
                        Some(format!("View Fx parameter index {index} is out of range"));
                    break;
                };
                if slot.is_some() {
                    binding_error = Some(format!(
                        "View Fx parameter index {index} is bound more than once"
                    ));
                    break;
                }
                let expected = definition.parameters()[index].parameter_type();
                if binding.value.parameter_type() != expected {
                    binding_error = Some(format!(
                        "View Fx parameter index {index} has type {:?}, expected {expected:?}",
                        binding.value.parameter_type()
                    ));
                    break;
                }
                *slot = Some(binding.value);
            }
            if let Some(reason) = binding_error {
                let error = BundleFxRuntimeError::ApplicationBinding {
                    definition: Box::new(definition.id().clone()),
                    reason,
                };
                let diagnostic = error.diagnostic();
                if !failures.contains(&diagnostic) {
                    failures.push(diagnostic);
                }
                continue;
            }
            let draft = match arcweft_presentation::fx::FxApplicationDraft::try_new(
                definition.id().clone(),
                arguments,
                0,
                None,
            ) {
                Ok(draft) => draft,
                Err(error) => {
                    let error = BundleFxRuntimeError::ApplicationBinding {
                        definition: Box::new(definition.id().clone()),
                        reason: error.to_string(),
                    };
                    let diagnostic = error.diagnostic();
                    if !failures.contains(&diagnostic) {
                        failures.push(diagnostic);
                    }
                    continue;
                }
            };
            let bound = match arcweft_presentation::fx::FxApplication::bind(definition, draft) {
                Ok(bound) => bound,
                Err(error) => {
                    let error = BundleFxRuntimeError::ApplicationBinding {
                        definition: Box::new(definition.id().clone()),
                        reason: error.to_string(),
                    };
                    let diagnostic = error.diagnostic();
                    if !failures.contains(&diagnostic) {
                        failures.push(diagnostic);
                    }
                    continue;
                }
            };
            let template = bound.template().clone();
            let parameters = template.initial_runtime().to_vec();
            if let Err(error) = self.presentation.fx.retain_instance(
                &self.fx_definitions,
                application.identity,
                template,
                parameters,
                application.child_path,
                None,
            ) {
                let diagnostic = error.diagnostic();
                if !failures.contains(&diagnostic) {
                    failures.push(diagnostic);
                }
            }
        }
        if self.presentation.fx != before {
            self.presentation.revision = self.presentation.revision.saturating_add(1);
        }
        if self.presentation.fx_diagnostics != failures {
            self.presentation.fx_diagnostics = failures;
            self.presentation.revision = self.presentation.revision.saturating_add(1);
        }
    }

    fn dispatch_requested_tasks(
        &mut self,
        clock: RuntimeClockStep,
        tasks: Vec<arcweft_core::task::TaskSubmission>,
    ) -> Vec<HostTaskDispatch> {
        let count = u64::try_from(
            tasks
                .iter()
                .filter(|task| {
                    !self
                        .pending_restartable_reensure
                        .contains_key(&task.task_id())
                })
                .count(),
        )
        .expect("an addressable task batch fits the task sequence counter");
        let next_sequence = self
            .next_task_sequence
            .checked_add(count)
            .expect("Core emitted no more task requests than the supplied sequence quota");
        let first_sequence = self.next_task_sequence;
        for offset in 0..count {
            let sequence = TaskSequence(first_sequence + offset);
            assert!(
                !self.task_generation_pins.contains_key(&sequence)
                    && !self.tasks.contains_sequence(sequence),
                "task dispatch sequence must be unused before batch publication"
            );
        }
        let tasks = tasks
            .into_iter()
            .map(|task| {
                if let Some(saved) = self.pending_restartable_reensure.get(&task.task_id()) {
                    assert_eq!(
                        &saved.task, &task,
                        "Product re-ensure must preserve its sealed TaskSpec"
                    );
                    assert_eq!(
                        self.executor.task_generation(&task.task_id()),
                        Some(saved.task.handle().correlation.generation),
                        "Product re-ensure must preserve its owning generation"
                    );
                    return (task, None);
                }
                let launch_generation = task.handle().correlation.generation;
                let generation = Arc::clone(
                    self.runtime_images
                        .get(launch_generation)
                        .expect("producer task generation must have a retained runtime image")
                        .generation(),
                );
                (task, Some(generation))
            })
            .collect::<Vec<_>>();
        let mut new_offset = 0_u64;
        let dispatches = tasks
            .into_iter()
            .map(|(task, generation)| {
                if let Some(saved) = self.pending_restartable_reensure.remove(&task.task_id()) {
                    return saved;
                }
                let generation = generation.expect("fresh task has a generation pin");
                let sequence = TaskSequence(first_sequence + new_offset);
                new_offset += 1;
                let bundle_asset_context = matches!(
                    &task.spec().request,
                    arcweft_core::task::TaskRequest::Host(
                        arcweft_core::task::HostTaskRequest::AssetLoad(_)
                    )
                )
                .then(|| generation.bundle_asset_context());
                self.task_generation_pins
                    .insert(sequence, generation.clone());
                let dispatch = HostTaskDispatch {
                    logical_epoch: LogicalEpoch(clock.tick().0),
                    sequence,
                    task,
                    last_publication_revision: None,
                    bundle_asset_context,
                };
                self.tasks.register_dispatch(&dispatch);
                dispatch
            })
            .collect();
        assert_eq!(new_offset, count, "prechecked fresh task count is exact");
        self.next_task_sequence = next_sequence;
        dispatches
    }

    fn capture_view_host_calls(
        &mut self,
        requests: Vec<RuntimeHostCallRequest>,
        step_input_events: &[RoutedInputEvent],
    ) -> Vec<RuntimeHostCallRequest> {
        let mut external = Vec::new();
        for request in requests {
            if request.capability() == "view.action" && request.operation() == "await" {
                match action_receive_action_id(&request) {
                    Some(action_id) => {
                        if let Some(invocation) =
                            action_invocation_from_step_inputs(&action_id, step_input_events)
                        {
                            self.pending_host_call_results.push(RuntimeHostCallResult {
                                id: request.id,
                                outcome: action_receive_payload(
                                    &action_id,
                                    invocation.payload.as_deref(),
                                ),
                            });
                        } else {
                            self.waiting_action_receive_calls
                                .push(PendingActionReceiveCall {
                                    request: request.id,
                                    action_id,
                                });
                        }
                    }
                    None => self.pending_host_call_results.push(RuntimeHostCallResult {
                        id: request.id,
                        outcome: Err(RuntimeHostCallError {
                            kind: RuntimeHostCallErrorKind::Rejected,
                            message: "view.action.await requires one action target".to_owned(),
                        }),
                    }),
                }
            } else {
                external.push(request);
            }
        }
        external
    }

    fn release_completed_task_generation_pins(&mut self, task_events: &[TaskEvent]) {
        if task_events.is_empty() {
            return;
        }
        for event in task_events {
            if matches!(event.kind, TaskEventKind::Progress(_)) {
                continue;
            }
            let Some(generation) = self.tasks.generation_for_event(event) else {
                continue;
            };
            let Some(dispatch_sequence) = self.tasks.dispatch_sequence_for_event(event) else {
                continue;
            };
            if self
                .task_generation_pins
                .get(&dispatch_sequence)
                .is_some_and(|pinned| pinned.id == generation)
            {
                self.task_generation_pins.remove(&dispatch_sequence);
            }
        }
        self.retire_unused_generations();
    }
}

fn action_receive_action_id(request: &RuntimeHostCallRequest) -> Option<String> {
    let value = request.args().first()?.value();
    match value {
        RuntimeValue::EntityRef(value) => Some(value.runtime_label()),
        RuntimeValue::String(value) => Some(value.to_owned()),
        _ => None,
    }
}

struct ActionInvocation {
    payload: Option<String>,
}

fn action_invocation_from_step_inputs(
    action_id: &str,
    step_input_events: &[RoutedInputEvent],
) -> Option<ActionInvocation> {
    step_input_events
        .iter()
        .find_map(|event| action_invocation_from_input_event(action_id, event))
}

fn action_invocation_from_input_event(
    action_id: &str,
    event: &RoutedInputEvent,
) -> Option<ActionInvocation> {
    let InputEventKind::Custom { name } = &event.event else {
        return None;
    };
    if name.as_str() != RuntimeInputKind::ActionInvoke.as_str()
        || event.target.as_str() != action_id
    {
        return None;
    }
    let payload = match event.payload.as_ref() {
        Some(InteractionPayload::Text(value)) => Some(value.clone()),
        Some(InteractionPayload::Entity(value)) => Some(value.as_str().to_owned()),
        Some(
            InteractionPayload::Null
            | InteractionPayload::Bool(_)
            | InteractionPayload::I64(_)
            | InteractionPayload::U64(_)
            | InteractionPayload::F64(_)
            | InteractionPayload::List(_)
            | InteractionPayload::Map(_),
        )
        | None => None,
    };
    Some(ActionInvocation { payload })
}

fn action_receive_payload(
    action_id: &str,
    payload: Option<&str>,
) -> Result<RuntimePayload, RuntimeHostCallError> {
    let payload = payload.ok_or_else(|| RuntimeHostCallError {
        kind: RuntimeHostCallErrorKind::Rejected,
        message: format!(
            "runtime action `{action_id}` is missing the text/entity payload required by action.receive"
        ),
    })?;
    RuntimeValue::try_record(vec![
        (
            "action".to_owned(),
            RuntimeValue::String(action_id.to_owned()),
        ),
        ("value".to_owned(), RuntimeValue::String(payload.to_owned())),
    ])
    .map(RuntimePayload::from)
    .map_err(|error| RuntimeHostCallError {
        kind: RuntimeHostCallErrorKind::Failed,
        message: error.to_string(),
    })
}

fn presentation_transition_diagnostic(transition: &BundlePresentationTransition) -> Option<String> {
    let BundlePresentationTransition::DialogueAdvanceRejected { target, reason } = transition
    else {
        return None;
    };
    Some(format!(
        "dialogue advance rejected for {target:?}: {reason:?}"
    ))
}

#[cfg(test)]
mod view_handler_queue_tests {
    use super::*;
    use arcweft_bundle::resource_codec::SourceMapSection;
    use arcweft_bundle::{BundleManifest, BundleRuntimeSummary};
    use arcweft_character::id::CharacterId;
    use arcweft_core::effect::RuntimeArtifactFingerprint;
    use arcweft_core::entry::{
        EntryBindingIdentity, FlowContractHash, RuntimeEntryRoles, RuntimeFlowExecutable,
        RuntimeFlowSchema,
    };
    use arcweft_core::plan::{
        EntryRuntimeId, FlowRuntimeId, RuntimeEntryKind, RuntimeEntrySpec, RuntimeEntryTarget,
        RuntimeFlowOpSeed, RuntimeFlowSeed, RuntimePlanBuilder,
    };
    use arcweft_dialogue::InlineFailurePolicy;
    use arcweft_id::TextKey;
    use arcweft_id::view::ViewId;
    use arcweft_presentation::input::{InputEpoch, InputEvent};
    use arcweft_runtime_plan::awbc_lower::AwbcLowerer;
    use arcweft_source::{SourceDocument, SourceDocumentId, SourceName};
    use arcweft_text_model::{
        CharacterDialoguePresentationConfig, DialoguePresentationCharacter, LineDisplayFrame,
        RichTextDisplayMap,
    };
    use arcweft_view::{
        DialogueEntryId, DialogueInstanceId, DialoguePresentationId, DialogueRevision,
        DialogueStageIndex,
    };

    #[test]
    fn action_receive_rejects_a_missing_payload_instead_of_synthesizing_empty_text() {
        let error = action_receive_payload("action.inspect", None)
            .expect_err("missing action payload is rejected");

        assert_eq!(error.kind, RuntimeHostCallErrorKind::Rejected);
        assert!(error.message.contains("action.inspect"));
    }

    #[test]
    fn action_receive_preserves_an_explicit_empty_text_payload() {
        let payload = action_receive_payload("action.inspect", Some(""))
            .expect("explicit empty text remains a valid payload");
        let RuntimeValue::Record(fields) = payload.value() else {
            panic!("action.receive payload is a record");
        };
        assert!(matches!(
            fields.iter().find(|field| field.name() == "value"),
            Some(field) if field.value() == &RuntimeValue::String(String::new())
        ));
    }

    #[test]
    fn session_runtime_and_executor_share_the_exact_awbc_generation_lease() {
        let session = BundleSession::new(&session_bundle(), BundleSessionOptions::default())
            .expect("valid product session");
        let runtime = session
            .runtime_images
            .get(GenerationId::new(0))
            .expect("initial generation")
            .runtime();
        assert!(session.program_owner().same_program(
            &arcweft_core::task::RuntimeProgramOwner::Awbc(runtime.program.program_arc())
        ));
    }

    #[test]
    fn dialogue_input_action_uses_the_observed_activation_and_rejects_stale_revision() {
        let mut session = BundleSession::new(&session_bundle(), BundleSessionOptions::default())
            .expect("valid product session");
        let view = ViewId::standard_dialogue();
        let definition = crate::dialogue::DialogueViewDefinition::new(view.clone());
        let activation = arcweft_core::runtime_id::DialogueActivationId::new(
            arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes([0x47; 32])
                .expect("fixture artifact"),
            arcweft_core::runtime_id::RuntimePersistentFiberId::from_allocated(1),
            serde_json::from_value(serde_json::json!(1)).expect("fixture content identity"),
            7,
        );
        session
            .presentation
            .dialogue
            .apply_operations(&[crate::dialogue::DialoguePresentationOperation::append(
                activation.clone(),
                definition.clone(),
                dialogue_frame(view),
            )])
            .expect("retained dialogue occurrence");
        let dialogue = session
            .presentation
            .dialogue
            .get_by_definition(&definition)
            .expect("retained dialogue presentation");
        let entry = dialogue.active_entry().expect("active dialogue occurrence");
        assert!(!entry.is_waiting_for_advance());
        let observed = DialogueAdvanceTarget::new(
            dialogue.id(),
            entry.id(),
            entry.instance(),
            entry.stage_index(),
            dialogue.revision(),
        );
        let action = InputActionId::new("SkipLine").expect("action identity");
        assert_eq!(
            session
                .queue_dialogue_input_action(observed, action.clone())
                .expect("input identity remains available"),
            DialogueInputActionQueueOutcome::Queued
        );
        let [queued] = session.pending_dialogue_input_actions.as_slice() else {
            panic!("one activation-bound action is queued");
        };
        assert_eq!(queued.activation(), &activation);
        assert_eq!(queued.action(), &action);
        assert_eq!(queued.sequence(), InputSequence::new(0));
        assert_eq!(
            session
                .queue_dialogue_input_action(observed, action.clone())
                .expect("next input identity remains available"),
            DialogueInputActionQueueOutcome::Queued
        );
        assert_eq!(
            session.pending_dialogue_input_actions[1].sequence(),
            InputSequence::new(1)
        );
        let stale = DialogueAdvanceTarget::new(
            observed.dialogue,
            observed.entry,
            observed.instance,
            observed.stage,
            observed.revision.next().expect("fixture revision advances"),
        );
        assert_eq!(
            session
                .queue_dialogue_input_action(stale, action)
                .expect("stale input is not a session failure"),
            DialogueInputActionQueueOutcome::Rejected(DialogueAdvanceRejection::StaleRevision)
        );
        assert_eq!(session.pending_dialogue_input_actions.len(), 2);
        assert_eq!(session.next_dialogue_input_sequence, 2);
    }

    #[test]
    fn session_queues_the_exact_token_selected_by_the_player_invocation() {
        let bundle = session_bundle();
        let mut session = BundleSession::new(&bundle, BundleSessionOptions::default())
            .expect("handler-capable bundle session");
        let view = ViewId::standard_dialogue();
        let frame = dialogue_frame(view.clone());
        let target = DialogueAdvanceTarget::new(
            DialoguePresentationId::new(31),
            DialogueEntryId::new(32),
            DialogueInstanceId::new(33),
            DialogueStageIndex::new(0),
            DialogueRevision::new(1),
        );
        let input = crate::dialogue::DialogueViewInput {
            handle: arcweft_id::presentation::PresentationHandleId::try_new(
                "dialogue.session.handler",
            )
            .expect("dialogue handle"),
            view: &view,
            frame: &frame,
            state: crate::dialogue::DialogueViewState {
                occurrence: crate::dialogue::DialogueViewOccurrence {
                    presentation: DialoguePresentationId::new(31),
                    entry: DialogueEntryId::new(32),
                    instance: DialogueInstanceId::new(33),
                },
                stage: crate::dialogue::DialogueViewStage {
                    index: DialogueStageIndex::new(0),
                    page: crate::dialogue::DialoguePageIndex::new(0),
                    stage_count: 1,
                    page_count: 1,
                },
                reveal: crate::dialogue::DialogueViewReveal::complete(),
                primary_action: crate::dialogue::DialogueViewPrimaryAction {
                    target: Some(target),
                },
            },
        };
        let view_frame = session
            .view_runtime
            .evaluate_with_dialogue(&[], &[input], &[], false);
        assert!(view_frame.diagnostics.is_empty(), "{view_frame:#?}");
        let binding = &view_frame.mounts[0].events[0];
        let invocation = ViewHandlerInvocation::from_input(
            &InputEvent::activate(InputEpoch(1), binding.target().clone()),
            binding.event(),
            binding.route(),
        )
        .expect("player semantic Activate invocation");

        session
            .queue_view_handler_invocation(&invocation)
            .expect("exact mounted token queues");

        assert_eq!(
            session.pending_presentation_inputs,
            vec![BundlePresentationInput::advance_dialogue(target)]
        );
    }

    fn session_bundle() -> ArcweftBundle {
        let mut builder = RuntimePlanBuilder::new();
        let flow = FlowRuntimeId::from_checked_declaration_digest([0x61; 32], "flow.main")
            .expect("checked Flow identity");
        builder
            .admit_type_batch(
                [arcweft_core::plan::RuntimePlanTypeSeed::new(
                    arcweft_core::pattern::RuntimeCheckedType::String.semantic_identity_digest(),
                    arcweft_core::plan::RuntimePlanTypeProjection::String,
                )],
                [],
            )
            .expect("Flow result type admits");
        builder
            .push_flow_seed(RuntimeFlowSeed::new(
                flow.clone(),
                arcweft_core::plan::RuntimeFunctionSiteDeclarationSeed::flow(
                    arcweft_core::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity(
                        [61; 32],
                    ),
                    None,
                    Box::new([]),
                    arcweft_core::pattern::RuntimeCheckedType::String.semantic_identity_digest(),
                    arcweft_core::plan::RuntimeEffectSet::empty(),
                ),
                arcweft_core::plan::RuntimeExecutableBodySeed {
                    effects: arcweft_core::plan::RuntimeEffectSet::empty(),
                    ops: (vec![RuntimeFlowOpSeed::Return("done".to_owned())]).into_boxed_slice(),
                },
            ))
            .expect("Flow admits");
        builder
            .push_flow_schema(RuntimeFlowSchema {
                flow: flow.clone(),
                parameters: Vec::new(),
            })
            .expect("Flow schema admits");
        builder
            .push_flow_executable(RuntimeFlowExecutable {
                flow: flow.clone(),
                contract: FlowContractHash::from_bytes([0x62; 32]),
                controller: None,
            })
            .expect("Flow executable admits");
        builder
            .push_entry(RuntimeEntrySpec {
                id: EntryRuntimeId::from_source_entity_body("entry.main").expect("Entry identity"),
                kind: RuntimeEntryKind::Cli,
                binding: EntryBindingIdentity::from_bytes([0x63; 32]),
                target: RuntimeEntryTarget::Flow(flow),
                roles: RuntimeEntryRoles::None,
            })
            .expect("Entry admits");
        let plan = builder.finish().expect("runtime plan seals");
        let dialogue = arcweft_text_model::DialogueContentCatalog::new();
        let awbc = AwbcLowerer::new(&plan, &dialogue, "session-view-handler.arcw")
            .lower()
            .expect("runtime plan lowers")
            .program;
        let source = SourceDocument::try_new(
            SourceDocumentId::try_new("runtime-driver-session-view-handler").expect("source ID"),
            SourceName::Memory,
            "flow main { return \"done\" }",
        )
        .expect("source document");
        ArcweftBundle::try_new(
            BundleManifest {
                profile_id: None,
                profile_kind: None,
                entry: Some("entry.main".to_owned()),
                adapter: None,
                locale: arcweft_manifest_model::ProjectLocaleSpec::default(),
                adapter_manifest_ids: Vec::new(),
                required_host_calls: Vec::new(),
                runtime: BundleRuntimeSummary {
                    artifact_fingerprint: RuntimeArtifactFingerprint::try_from_bytes([0x64; 32])
                        .expect("artifact fingerprint"),
                    entry_flow: Some("flow.main".to_owned()),
                    flows: 1,
                    bytecode_instructions: awbc.instructions.len(),
                    line_task_groups: 0,
                    stream_plans: 0,
                },
            },
            SourceMapSection::try_from_documents(&[&source]).expect("source map"),
            awbc,
            dialogue,
        )
        .expect("standard handler bundle")
    }

    fn dialogue_frame(view: ViewId) -> LineDisplayFrame {
        LineDisplayFrame {
            line: arcweft_core::plan::RuntimeLineId::from_runtime_line_value(
                "say.session.view.handler",
            )
            .expect("line identity"),
            character: DialoguePresentationCharacter {
                id: CharacterId::try_new("character.session").expect("character identity"),
                display_name: "Session".to_owned(),
            },
            text_key: TextKey::try_new("text.session.view.handler").expect("text key"),
            effective: CharacterDialoguePresentationConfig::standalone(
                view,
                InlineFailurePolicy::FailLine,
            ),
            text: String::new(),
            base_styles: Vec::new(),
            nodes: Vec::new(),
            display_map: RichTextDisplayMap::default(),
            host_events: Vec::new(),
            inline_failures: Vec::new(),
            unresolved: Vec::new(),
            content: arcweft_core::value::RuntimeDialogueContentValue::try_new(
                arcweft_core::effect::RuntimeArtifactFingerprint::try_from_bytes([0x71; 32])
                    .expect("fixture artifact"),
                arcweft_core::runtime_id::RuntimeDialogueContentTemplateId::from_zero_based(0)
                    .expect("fixture template"),
                arcweft_core::entry::RuntimeDialogueContentTemplateDigest::from_bytes([0x72; 32]),
                [],
            )
            .expect("fixture Content envelope"),
        }
    }
}
