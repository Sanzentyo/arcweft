$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$base=(git rev-parse HEAD).Trim()
if ($base -ne '02f19979c220d702789c0340f0fc9f86b51cd5f6' -or @(git diff --cached --name-only).Count) { throw 'Unexpected base/index' }
$prefix='line-command-driver-final'
$patch=Read-GitBytes @('diff','--binary','--full-index','HEAD')
$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant()
[IO.File]::WriteAllBytes((Join-Path $e ($prefix+'.patch')),$patch)
$paths=@(git diff HEAD --name-only)
$rust=@($paths | Where-Object {$_ -like '*.rs'})
function Confirm-Source {
    $check=Read-GitBytes @('diff','--binary','--full-index','HEAD')
    if ((git rev-parse HEAD).Trim() -ne $base -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($check)).ToLowerInvariant() -ne $sha) {throw 'Source changed'}
}
$selection=@('--locked','--all-features','-p','arcweft-runtime-driver','-p','arcweft-compiler','--lib','--test','awbc_product_session','--test','source_presentation_driver','-E','package(=arcweft-runtime-driver) or binary(=source_presentation_driver)')
$listArgs=@('nextest','list','--message-format','json')+$selection
$runArgs=@('nextest','run','--no-fail-fast','--no-tests','fail')+$selection
$listLog=Join-Path $e ($prefix+'.list.log')
& cargo @listArgs *> $listLog
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$catalog=([IO.File]::ReadLines($listLog) | Where-Object {$_.StartsWith('{')} | Select-Object -Last 1) | ConvertFrom-Json -AsHashtable
$selected=@(foreach ($suite in $catalog.'rust-suites'.Values) {
    foreach ($test in $suite.testcases.Keys) {
        if ($suite.testcases[$test].'filter-match'.status -eq 'matches') {
            [ordered]@{id=$suite.'binary-id'+' '+$test;path=$suite.'binary-path'}
        }
    }
})
$testId='arcweft-compiler::source_presentation_driver source_dialogue_line_commands_resume_through_the_bundle_session_after_restore'
if ($selected.Count -ne 122 -or @($selected|Where-Object {$_.id -ceq $testId}).Count -ne 1) {throw 'Unexpected owner selection'}
$binaries=@($selected.path | Sort-Object -Unique)
function Read-Pins {
    @(foreach ($path in $binaries) {
        [ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
    })
}
$before=Read-Pins
$before | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-before.json')) -Encoding utf8
$checks=@(
    @{name='nextest';cmd='cargo';args=$runArgs},
    @{name='fmt';cmd='rustfmt';args=@('--check','--edition','2024','--config','skip_children=true')+$rust},
    @{name='check';cmd='cargo';args=@('check','--locked','--workspace','--all-targets','--all-features')},
    @{name='clippy';cmd='cargo';args=@('clippy','--locked','--workspace','--all-targets','--all-features')},
    @{name='wasm';cmd='cargo';args=@('check','--locked','--target','wasm32-unknown-unknown','--all-features','--lib','-p','arcweft-player-web')},
    @{name='structure';cmd='cargo';args=@('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')}
)
$results=@(foreach ($check in $checks) {
    $log=$prefix+'.'+$check.name+'.log'
    $argsForCheck=$check.args
    $watch=[Diagnostics.Stopwatch]::StartNew()
    & $check.cmd @argsForCheck *> (Join-Path $e $log)
    $exitCode=$LASTEXITCODE
    $watch.Stop()
    Confirm-Source
    if ($check.name -eq 'nextest') {
        $after=Read-Pins
        $after | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-after.json')) -Encoding utf8
        if (Compare-Object $before.sha256 $after.sha256) {throw 'Binary drift'}
        $terminal=@([IO.File]::ReadLines((Join-Path $e $log)) | Where-Object {$_ -match '^\s+(Summary|FAIL)\s+\['})
        Write-Host ($terminal -join [Environment]::NewLine)
    }
    Write-Host ($check.name+' exit '+$exitCode)
    [ordered]@{name=$check.name;command=$check.cmd;arguments=$argsForCheck;exitCode=$exitCode;seconds=$watch.Elapsed.TotalSeconds;log=$log}
})
[ordered]@{version=1;base=$base;patchSha256=$sha;paths=$paths;listArgs=$listArgs;selected=$selected;terminal=$terminal;checks=$results} |
    ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.results.json')) -Encoding utf8
if (@($results | Where-Object {$_.exitCode -ne 0}).Count) {exit 1}