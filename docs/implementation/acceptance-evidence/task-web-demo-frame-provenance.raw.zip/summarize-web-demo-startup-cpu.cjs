const fs = require("node:fs");
const profile = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const nodes = new Map(profile.nodes.map(n => [n.id,n]));
const parents = new Map();
for (const n of profile.nodes) for (const child of n.children ?? []) parents.set(child,n.id);
const categories = {};
const byName = {};
const flags = [
  ["logical", /::logical_identity/],
  ["brok", /BrowserTaskBroker>::from_bundle/],
  ["awfb_decode", /from_awfb_slice_with_external_sections_and_resource_types/],
  ["product_validation", /validate_schema_and_kind/],
  ["session_start", /BundleSession>::from_awfb_bytes/],
  ["container_parse", /BundleView>::parse/],
  ["assets_decode", /optional_asset_catalog/],
  ["font_set", /PlayerFontSet>::from_font_resource_bytes/],
  ["blake3", /blake3.*::portable::compress_in_place/],
];
const resolved = new Map();
for (let i=0; i<profile.samples.length; i++) {
  const id = profile.samples[i], delta = (profile.timeDeltas[i] ?? 0) / 1000;
  let row = resolved.get(id);
  if (!row) {
    const stack = [];
    for (let cur=id; cur!==undefined; cur=parents.get(cur)) stack.push(nodes.get(cur).callFrame.functionName);
    const matched = flags.filter(([,re])=>stack.some(n=>re.test(n))).map(([key])=>key);
    const slot = matched.includes("awfb_decode") ? (matched.includes("session_start") ? "awfb_in_session" : "awfb_outside_session") : null;
    if (slot) matched.push(slot);
    row = {leaf:stack[0],matched}; resolved.set(id,row);
  }
  byName[row.leaf] = (byName[row.leaf] ?? 0) + delta;
  for (const label of row.matched) categories[label] = (categories[label] ?? 0) + delta;
}
console.log(JSON.stringify({categories,topLeaves:Object.entries(byName).sort((a,b)=>b[1]-a[1]).slice(0,10),totalSamples:profile.samples.length},null,2));
