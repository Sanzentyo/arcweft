$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='task-view-contextual-capture-acceptance'
$publication=Get-Content "$taskTemp/checkpoint-view-contextual-capture.verified.json" -Raw|ConvertFrom-Json -Depth 25
$source=$publication.commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source changed'}
$before=Get-Content "$taskTemp/view-contextual-capture.docs-before.json" -Raw|ConvertFrom-Json
$reuse=Get-Content "$taskTemp/presentation-view-contextual-capture-reuse-20261102.json" -Raw|ConvertFrom-Json -Depth 25
if($reuse.changed.Count -ne 1 -or $reuse.unchanged -ne 4065){throw 'Unexpected input changes'}
$output="docs/implementation/acceptance-evidence/$stem.json"
$zipPath="docs/implementation/acceptance-evidence/$stem.raw.zip"
if((Test-Path $output) -or (Test-Path $zipPath)){throw 'Evidence exists'}
$paths=@(rg --files $taskTemp -g 'presentation-view-contextual-capture-*')
$paths+=@('run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','checkpoint-view-contextual-capture.prepared.json','checkpoint-view-contextual-capture.verified.json','view-contextual-capture.docs-before.json','record-view-contextual-capture-20261102.ps1')|ForEach-Object {Join-Path $taskTemp $_}
$paths=@($paths|Sort-Object -Unique)
$manifest=@(foreach($path in $paths){[ordered]@{path=[IO.Path]::GetRelativePath($taskTemp,$path).Replace('\','/');bytes=(Get-Item $path).Length;sha256=(Get-FileHash $path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path $PWD $zipPath),[IO.Compression.ZipArchiveMode]::Create)
try{for($i=0;$i -lt $paths.Count;$i++){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$paths[$i],$manifest[$i].path,[IO.Compression.CompressionLevel]::Optimal)};$entry=$zip.CreateEntry('manifest.json');$writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false));try{$writer.Write(($manifest|ConvertTo-Json -Depth 8))}finally{$writer.Dispose()}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path $PWD $zipPath))
try{foreach($row in $manifest){$entry=$zip.GetEntry($row.path);if($null -eq $entry -or $entry.Length -ne $row.bytes){throw 'Archive entry missing'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry drift'}};$entries=$zip.Entries.Count}finally{$zip.Dispose()}
$terminal=Get-Content "$taskTemp/presentation-view-contextual-capture-owner1-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 25
$clippy=Get-Content "$taskTemp/presentation-view-contextual-capture-clippy1-20261102.json" -Raw|ConvertFrom-Json
$format=Get-Content "$taskTemp/presentation-view-contextual-capture-format1-20261102.json" -Raw|ConvertFrom-Json
if($terminal.executed -ne 40 -or $terminal.failed -or $clippy.exitCode -or $format.exitCode){throw 'Validation incomplete'}
$record=[ordered]@{version=1;source=$source;publication=$publication;boundary='Expected closure parameter types and ViewValue return through a generic callback';accepted=[ordered]@{previous=36;added=4;total=40;programInvocation=12;ordinaryFlow=28;backends=@('Native','canonical decoded AWBC');maxOps=1;maxTicks=256;eachAwbcStepPublicSaveOwnedRestore=$true};conditions=@('A String-to-i64 function binding supplies the expected parameter type to an unannotated closure that captures a View alias.','apply<T> receives String-to-T callback and returns the constructed ViewValue to the original Flow before mount/unmount. The callback parameter is inferred from its expected String type.');runtime=$terminal;clippy=$clippy;format=$format;reuse=$reuse;reusedEvidence='task-view-semantic-capture-acceptance.json: actual 23-package/5014-case terminal run and 97-package workspace gates for implementation eebe9aee7bbacfd59c51704cdc2ce0a516328e5d. Only the integration fixture changed; those broad results remain original evidence, not fresh reruns.';limits=@('No unconstrained standalone closure parameter inference is claimed.','Reactive defaults, renderer/driver integration and actual Native/Web image parity remain separately bounded.','The original 14 tracked WIP changes remain part of the tested inputs; a clean checkout is not claimed.');held=[ordered]@{tracked=14;patchSha256=$publication.heldPatchSha256;actualUntracked=6};raw=[ordered]@{path="$stem.raw.zip";entryCount=$entries;payloadEntries=$manifest.Count;bytes=(Get-Item $zipPath).Length;sha256=(Get-FileHash $zipPath).Hash.ToLowerInvariant();entryDrift=0};recordedAt=[DateTime]::UtcNow.ToString('o')}
$record|ConvertTo-Json -Depth 60|Set-Content $output -Encoding utf8
$statusPath=Join-Path $PWD 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
if([regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value -cne $before.genericRow){throw 'Generic row changed'}
$status=[regex]::Replace($status,'(?m)^確認日:[^\r\n]*',"確認日: 2026-11-02。最新の公開Sourceは $source（実装eebe9aee7bbacfd59c51704cdc2ce0a516328e5d＋View aliasの期待型／generic callback実行テスト）。元14 tracked／6 actual untracked WIPを保持した。個別の受入と横断runの適用範囲は下表で判定する。")
$row="| Source ViewValue生成・保持 | **Program invocation・通常Flowの40条件で検証・公開済み** | Source $source、実装eebe9aee7bbacfd59c51704cdc2ce0a516328e5d。既受入36条件を維持し、期待するString→i64型からclosure引数を決める場合と、generic apply<T>のcallbackが返したViewValueを元Flowでmount／unmountする4条件を追加した。Program invocation 12／通常Flow 28条件がNative・canonical decoded AWBCでPASS。OneOp・max_ops=1・256 ticksと各step AWBC公開save／owned restoreを維持する。semantic captureは元owner／reachability証拠を保持し、実行値・Core frame・local／capture slotを作らない。実データのcapture ABIは同じ所有authorityを共有し、source orderの連続ordinalを使う。型注釈付きcapture・データ前後・nested closureの既受入8条件も維持する。reactive default・driver描画・期待型のないstandalone closure推論へは拡張しない。[追加4条件・40件・再利用証明](acceptance-evidence/$stem.json)、[capture修復・36件・全23逆依存](acceptance-evidence/task-view-semantic-capture-acceptance.json)、[保持値とcodec](acceptance-evidence/task-source-view-value.json)。 |"
$pattern='(?m)^\| Source ViewValue生成・保持 \|[^\r\n]*'
if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row missing'}
$status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match)$row})
$quality='(?m)^\| workspace check／Clippy・fmt・構造gate \|[^\r\n]*'
$status=[regex]::Replace($status,$quality,[Text.RegularExpressions.MatchEvaluator]{param($match)$line=$match.Value.Replace('最新Sourceの全97 package gate','実装Sourceの全97 package gate');$line.Substring(0,$line.Length-2)+" 後続Source $source はtest fixture 1 pathだけを変更し、当該targetの全feature Clippy／fmtは各終了0。全97 gateの再実行とはしない。[test入力一致と限定検証](acceptance-evidence/$stem.json)。 |"})
# Only extend the final cell of the quality row; preserve the table's other cells.
$qualityRow=[regex]::Match($status,$quality).Value
if(($qualityRow.ToCharArray()|Where-Object {$_ -eq '|'}).Count -ne 4){throw 'Quality table shape changed'}
if([regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value -cne $before.genericRow){throw 'Generic acceptance drift'}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$history=@"


## View aliasの期待型／generic callback実行 — 2026-11-02

Source $source（親eb4702edd9c22bf8e1c2d1d712e0bc5606bedc50）を通常commit／non-forced pushし、tree $($publication.tree)、patch SHA256 $($publication.patchSha256)、test fixture 1 pathのblobを照合した。36条件を維持し、期待型からclosure引数を決める場合とgeneric callbackが返すViewValueの関数境界を越えた保持を、Native／canonical decoded AWBCの4条件で追加した。40／40 PASS。OneOp・max_ops=1・256 ticksと各AWBC stepの公開save／owned restoreを維持し、元Flowでmount／unmount後に実戻り値42へ到達した。

4,066入力の差分は当該test fixtureだけで、本番Rust／Cargoを含む残る4,065入力は実装eebe9aee7bbacfd59c51704cdc2ce0a516328e5dの23逆依存runと一致する。test targetの全feature／locked Clippyとfmtは終了0。実装の4,322 library成功、全CLI649 PASS／43 FAIL、全97 workspace gateはそのSource／feature unionの証拠として再利用し、今回再実行したとはしない。元14 trackedのpatch SHA256 $($publication.heldPatchSha256)と元6 actual untrackedも保持した。現状の36条件表記は、この新4条件の実行結果を理由に40条件へ更新し、Generic Matchの受入行と古い実行記録は変更していない。[実行・公開・再利用証明](acceptance-evidence/$stem.json)、[実ログZIP](acceptance-evidence/$stem.raw.zip)。期待型のないstandalone推論、reactive default、driver描画、Native/Web実画像parityの受入は主張しない。
"@
[IO.File]::AppendAllText((Join-Path $PWD $before.path),$history,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;rawEntries=$entries;rawBytes=$record.raw.bytes;rawSha256=$record.raw.sha256;historyAppended=$true}|ConvertTo-Json -Compress
