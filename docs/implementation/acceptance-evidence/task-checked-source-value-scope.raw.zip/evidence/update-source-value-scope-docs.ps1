$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/source-value-scope-final.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/source-value-scope-final.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/source-value-scope.consumer-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/source-value-scope.archive.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/source-value-scope.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -cne $pub.Source -or @(git diff --name-only HEAD).Count -or $owner.Source -cne $pub.Source -or $consumers.Source -cne $pub.Source -or $owner.Passed -ne 1656 -or $owner.Failed -ne 6 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2){throw 'Final evidence is incomplete'}
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `0b60adcc2b24ad580822753c163df9c43d5344b9`','この更新の基点の `main` と `origin/main` は `0d42831c0085b414c3bd7f6351473291f7d85a4f`')
$rows=@(
@('再帰関数値の終端効果','| 再帰関数値の終端効果 | **呼出し側で束縛した単独・相互再帰を検証し公開済み。本体内の推論は修復中** | 既受入Source `6e9e72458880680839f899706d88034311f0c7fa` のcaller-bound recursion、共有prefixのString／i64適用、100 ms後のNative／AWBCの42・各step公開JSON保存復元を維持する。最新Source `0d42831c0085b414c3bd7f6351473291f7d85a4f` は元operand・対応する子と配列長・実SourceのΓに基づく元値admissionとtemplate開放を維持する。checked source値も、その値を検査したOriginalProducerContextを元ownerと一緒に保持し、実宣言Γ／明示importで型・const・effect・predicateのFreeを検査してからコピーする。root・correlated child・選択replayで同じSourceコンテキストを転送し、候補の可視inventoryは許可に使わない。パラメーターを含まない既存の文法leafは再帰コピー／Γ走査を重複させず、4,096予算・256候補を各1回＋選択replay 1回の条件を維持する。残るのはsource／result／Completedの導出後の値転送・effect置換での値ごとのFree検査と実出力capture seal、callerの実Γを含む引数全体の転送、条件付きMGU・適格性／rank・Fn局所∀、frontendのprepared value／effect接続とbody一回準備・一括seal。数学的C・元callerのD・Free許可を区別し、移行済み範囲を全体goalから戻さない。実測は下表へ集約する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[元値](convergence-evidence-history.md#original-source-value-admission)・[template](convergence-evidence-history.md#template-opening-authority)・[checked source値と修復理由](convergence-evidence-history.md#checked-source-value-scope)。 |'),
@('再帰本体の型表現／Semaの推移的逆依存','| 再帰本体の型表現／Semaの推移的逆依存 | **同一SourceでSemaは1,656 PASS／6 FAIL、他21 consumerは2,507 PASS／2 FAIL／1 SKIP** | Source `0d42831c0085b414c3bd7f6351473291f7d85a4f`。全feature Sema lib／testsは1,662件を73.063秒で実行し、選択と終端の全IDが一致・重複0。直前の1,658 IDを維持し、新4 IDが全件PASS。checked source値の型・const・effect・predicateで、受信側inventoryからの借用を正確なerrorとして拒否し、値自身の宣言Γ／明示import、局所Fn、元owner保持を確認する。コピー前の予算拒否とleafの取消しも検査した。256候補・各probe 1回＋replay 1回の既存testは入力・assertion・4,096予算を変えずPASS。失敗IDと実診断は既知6件と一致（5 ExpressionCycle、1 PendingCallableEffectProjection）。他21 package・既定feature・規定107 targetも選択2,510 IDと終端が一致・重複0。Compilerの既知2失敗はExpressionCycle（slot 17／19）。0 runnableの3 targetはcompileとして記録する。22 packageのgraphはCargo入力差分0を照合して再利用し、実行結果は今回のSourceに固定した。owner全featureとconsumer既定featureは別sliceである。[今回の全原本と中間失敗](acceptance-evidence/task-checked-source-value-scope.raw.zip)。 |'),
@('CLIの規定対象／全 check 照合','| CLIの規定対象／全 check 照合 | **今回の規定対象226件はPASS。全 check は未再実行** | Source `0d42831c0085b414c3bd7f6351473291f7d85a4f`、locked・既定feature／filter。library 196件と規定の統合6 target 30件が今回PASSし、binはコンパイル済み・runnable test 0件。全checkの修復や以前の失敗の再現はこの結果から推定しない。以前の入力・件数・失敗は履歴と既存原本に保持する。[今回の原本](acceptance-evidence/task-checked-source-value-scope.raw.zip)。 |'),
@('workspace check／Clippy・fmt・構造gate','| workspace check／Clippy・fmt・構造gate | **今回のworkspace全target／全feature check・Clippy、Sema doctest、整形・構造gateは終了0** | Source `0d42831c0085b414c3bd7f6351473291f7d85a4f` のlocked・workspace全target／全feature check／Clippy、Sema全feature doctest 2件、owner全target／全feature Clippy、workspace fmt check、canonical構造gateを今回実行した（review trigger 396・blocking 0）。step前後のcommit／tree／tracked差分0、owner全7 pathのbyte pin・公開blobを照合した。警告・中間失敗・診断用一時出力とその削除も原本へ保持する。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanの履行は前回の履歴に保持し、今回は繰り返していない。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持し、今回は未実行。Tier 2、新しい再帰本体のNative／AWBC・Native／Web受入も今回のhost検証から主張しない。[今回の原本](acceptance-evidence/task-checked-source-value-scope.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |')
)
foreach($row in $rows){
    $pattern='(?m)^\| '+[regex]::Escape($row[0])+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row is not unique'}
    $replacement=$row[1]
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
if(@($before.GenericMatchRow).Count -ne 1 -or @(Compare-Object -CaseSensitive $before.GenericMatchRow @(Get-Content $statusPath|Where-Object {$_ -match '^\| Generic Match'})).Count){throw 'Accepted Generic Match changed'}
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
if((Get-Item $historyPath).Length -ne $before.HistoryBytes -or (Get-FileHash $historyPath -Algorithm SHA256).Hash -cne $before.HistorySHA256){throw 'History prefix changed'}
$addition=@'

## Checked source value scope

2026-11-13。最終Source `0d42831c0085b414c3bd7f6351473291f7d85a4f`、tree `9005cfd42b06f7350726b50be42eeb196b1461d0`、親 `40b9243879c03c8d6af8537bc81be469eb7d3b8a`、移行基点・前回資料公開 `e9298da171d4bfc796b7f2a2dde3b3b27dd5ddc0`。既存mainで通常commit／non-forced pushし、head・tree・全変更blobを照合した。checkpointの全件前の公開は、途中commitの正常動作保証を不要とするユーザー指示による。既存の未追跡 `%SystemDrive%/` を保持した。

ConstraintSourceValueOwnerは実際に保持するchecked／staged valueと、その値を検査したOriginalProducerContextを一緒に公開する。AnalyzerObservedSourceValueの2 factoryへ、候補を調べる前に確定したSourceコンテキストを渡す。root clientだけでなくcorrelated childの再生用AnalyzerCallApplicationSourcesにも同じコンテキストを保持し、以前破棄していたchildのコンテキストも転送する。SourceProbeTerm::Valueの解決は、値のownerが持つ実宣言Γと明示import leaseでtype／const／effect／predicateのFreeを検査してコピーする。receiving inventory、候補のD、数学的C、型から収集した許可一覧をΓの代用にしない。opaque value ownerとprobe receipt／Source identityの検査は維持した。

最終Sourceの全feature Sema lib／testsは1,662件中1,656 PASS／6 FAIL／0 SKIP、73.063秒、slow 0。5 binaryの選択と終端の全IDが一致・重複0。Source `0b60adcc2b24ad580822753c163df9c43d5344b9` の全1,658 IDを維持し、新4 IDがPASS。別ΓのFreeがreceiving inventoryでrigidとして見えていても正確なout-of-scope errorで拒否し、値自身の宣言Γ／明示importを受理する。局所Fnの型・const・effect binderとpredicate、元value ownerの保持、コピー前の予算拒否、closed grammar leafでも取消しを確認した。既知6失敗のIDと実診断は前回と一致（5 ExpressionCycle、1 PendingCallableEffectProjection）。

checkpoint `40b9243879c03c8d6af8537bc81be469eb7d3b8a`（tree `ce64a3702a7a2a24042ed281ad5c5a67c41a602a`）は1,661件中1,654 PASS／7 FAIL／0 SKIP、71.820秒。新3件はPASSしたが、既存t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_onceが追加で失敗した。4,096予算を維持した診断用runではSOURCE_SCOPE_LOWER total=4097 previous=4096 delta=1 limit=4096を観測した。診断にはlimits.rsへのcfg(test)出力だけを一時追加し、counter／上限／selector／assertionを変更していない。出力を取り除き、同ファイルのblobがcheckpointと最終Sourceで完全一致することを照合した。最初の開発時checkは欠けたOriginalProducerContext importとcorrelated source carrierの未移行fieldを、次のlistは新testの宣言parameter ID／Result／function factoryの型違いを修復した。これらを最終Sourceの結果と混ぜず原本へ保持する。

追加失敗の原因は、パラメーターを含まない既存のTypeConstraintShape::Leaf／NeverにもΓ検査用の再帰walkを重ねたことだった。この文法classは参照出現も再帰的なsemantic type storageもなく、source probeでrootを既に計上している。Sourceのownerを保持したままそのmetadataをコピーし、参照／複合型は従来の共通controlled foldで検査・コピーする。全経路で取消しを先に確認する。型名やfixtureごとの例外、unmeteredな複合型walk、上限引上げ、probe／replayの省略は導入しなかった。修復後の限定runは新3件＋元の境界1件の4 PASS。最終Sourceの全件runでも、元の256候補・全候補のprobe各1回・選択replay 1回・物理257評価・4,096上限の全assertionがPASSした。

同じ最終Sourceで他21 package・既定feature・規定107 targetを実行し、選択2,510 IDと終端が一致・重複0、2,507 PASS／2 FAIL／1 SKIP。20 package／76 targetはpackageごと、Compilerの31 targetは逐次実行した。Compilerの既知2失敗はflow_waitの同じIDとExpressionCycle（slot 17／19）。3 targetはcompile-only。CLI library 196件と統合6 target 30件は226 PASS、Compiler callable_executionの376件もPASS。owner全featureとconsumer既定featureは別slice。22 packageの推移的逆依存graphはCargo入力差分0を照合して再利用し、テストは今回のSourceで新たに実行した。

workspace全target／全feature・locked check／Clippy、Sema全feature doctest 2件、owner Clippy、workspace fmt check、canonical構造gateは終了0。各step前後のcommit／tree／tracked差分0、owner全7 pathのbyte pinと公開blob、出力hashを照合した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。警告も保持する。canonical gateは98 package・3,487 files・3,356 Rust files・1,893,982 Rust physical LOC、review trigger 396・blocking 0。Sema fan-in／outは8／15、devは4／0でCargo edgeの変更はない。

所有者はchecked source valueとSource preparationであり、Γを候補のside tableへ置かなかった。lowerはSource解決時のΓ検査と保持を所有し、既存の共通foldを再利用する。大きなanalyzer/calls/constraintsは既存のcallback・replay調整にSourceコンテキストを渡す責務を加えたもので、別のΓ resolverやAST walker、独立state clusterを増やしていない。新test moduleはこのSource境界に閉じる。各pathのbytes・physical LOC・基点との差を原本へ保持した。公開API・layer方向・I/O・unsafe・version・製品予算を変更しない。

現状行の訂正理由はchecked source値のΓ保持とコピー前のFree検査が実装・検証されたためであり、導出後のsource／result／Completed転送やeffect置換の値ごとの許可、実出力capture seal、引数全体の実Γ、条件付きMGU／rank／局所∀、frontendのprepared接続・body一回準備・一括sealまで完成したとはしない。Generic Match、caller-bound recursion、共有prefixの受入は維持し、その行を未完了へ戻していない。実測・中間失敗・公開full SHAは履歴と原本へ保持し、現状一覧はcurrent-status.mdの一か所とする。今回のhost検証を新しい再帰本体のNative／AWBC・Tier 2／Wasm・Native／Web表示の受入とはしない。全体cargo cleanは前回の履行記録を保持し、今回は再実行していない。

[全原本](acceptance-evidence/task-checked-source-value-scope.raw.zip)は@@ENTRIES@@ entry、展開時@@RAW_BYTES@@ bytes、ZIP @@ZIP_BYTES@@ bytes、SHA-256 `@@ZIP_SHA@@`。manifestと全entryの長さ・hash・portable pathを読み戻して照合した。
'@
$addition=$addition.Replace('@@ENTRIES@@',[string]$archive.Entries).Replace('@@RAW_BYTES@@',[string]$archive.RawBytes).Replace('@@ZIP_BYTES@@',[string]$archive.ZIPBytes).Replace('@@ZIP_SHA@@',$archive.SHA256.ToLowerInvariant()).Replace("`r`n","`n")+"`n"
[IO.File]::AppendAllText($historyPath,$addition,[Text.UTF8Encoding]::new($false))
$bytes=[IO.File]::ReadAllBytes($historyPath)
$prefix=[byte[]]::new([int]$before.HistoryBytes)
[Array]::Copy($bytes,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -cne $before.HistorySHA256){throw 'History prefix differs'}
git diff --check
if($LASTEXITCODE -ne 0){throw 'Documentation whitespace failed'}
