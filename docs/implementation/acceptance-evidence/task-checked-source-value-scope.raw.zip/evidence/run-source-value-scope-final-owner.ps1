$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
$publication=Get-Content -Raw "$root/source-value-scope-final.publication.json"|ConvertFrom-Json
$steps=[Collections.Generic.List[object]]::new()
function Assert-Source {
    if((git rev-parse HEAD) -ne $publication.Source -or (git rev-parse 'HEAD^{tree}') -ne $publication.Tree -or @(git diff --name-only HEAD).Count){throw 'Owner source identity changed'}
    foreach($p in $publication.Paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Owner source bytes changed'}}
}
function Step($name,$arguments,$output,$log) {
    Assert-Source
    $start=Get-Date
    Write-Output "START $name"
    & cargo @arguments 1>"$root/$output" 2>"$root/$log"
    $code=$LASTEXITCODE
    Assert-Source
    $steps.Add([pscustomobject]@{Name=$name;Arguments=$arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;SourcePinsVerified=$true;Output=$output;Log=$log;OutputSHA256=(Get-FileHash "$root/$output" -Algorithm SHA256).Hash;LogSHA256=(Get-FileHash "$root/$log" -Algorithm SHA256).Hash})
    [ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;CARGO_INCREMENTAL='0';NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1';JobsOverride=$false;ProfileOverride=$false;Steps=@($steps.ToArray())}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/source-value-scope-final.owner-validation.json"
    Write-Output "END $name exit=$code"
    Get-Content -LiteralPath "$root/$log" -Tail 10
    if($code -ne 0 -and $name -ne 'owner-run'){throw "$name failed"}
}
Assert-Source
Step 'owner-list' @('nextest','list','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--message-format','json') 'source-value-scope-final.owner-list.json' 'source-value-scope-final.owner-list.log'
Step 'owner-run' @('nextest','run','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--no-fail-fast','--no-tests','fail','--message-format','libtest-json-plus') 'source-value-scope-final.owner-results.jsonl' 'source-value-scope-final.owner-run.log'
Step 'owner-clippy' @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features') 'source-value-scope-final.owner-clippy.stdout' 'source-value-scope-final.owner-clippy.log'
Step 'fmt' @('fmt','--all','--','--check') 'source-value-scope-final.fmt.stdout' 'source-value-scope-final.fmt.log'



