$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/application-source-context.final-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/application-source-context.final-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/application-source-context.final-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1617 tests run: 1611 passed, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1617\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/application-source-context.final-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1617 -or $terminal.Count -ne 1617 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$failed=@($terminal | Where-Object Result -eq 'FAIL' | ForEach-Object Name | Sort-Object)
$baseline=Get-Content -Raw "$root/original-context-retention-fixed.owner-summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$new=@($terminal | Where-Object Name -Match 'binding_owners_keep_their_original_source|a_root_cannot_replace_its_application_owners_original_context')
if($new.Count -ne 2 -or @($new | Where-Object Result -ne 'PASS').Count){throw 'Owner regressions missing'}
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Source changed'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    $baseLines=@(git show "$($pin.Base):$($p.Path)").Count
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path.Contains('/tests/')){'test'}else{'production'};EmbeddedTestLOC=0;SHA256=$p.SHA256;Blob=$p.Blob}
})
$terminal | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/application-source-context.final-terminal.json"
[ordered]@{Version=1;Base=$pin.Base;Selected=1617;Passed=1611;Failed=6;Skipped=0;IdsEqual=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;SourcePinsVerified=$true;ClippyExit=0;FmtExit=0;Measurements=$measurements;Ownership='The application owns immutable lexical introduction and original source context. Imported leases retain this same owner; binding lookup borrows both authorities without a copied catalog. Transaction root, nested admission and result specialization pass the actual path source context. Context retains work accounting and source/path admission. Existing large context/transaction modules retain these cohesive roles; no dependency, public API, unsafe, I/O, version or budget change. Test fixture recontextualization is cfg(test), only before admission. Free dependency enforcement and operand provenance remain separate unfinished boundaries.';ReverseEvidence='Private owner metadata and impossible mismatched-source rejection only; no changed valid frontend language behavior. Full Sema was run. The resolved three-mode graph and 22-package closure remain unchanged; the last 21-consumer results remain pinned to 8b5e375a9c7b3096fe5ed2f65df556a463741a8d and are not claimed as rerun.';Development='Initial E0283 in new tests repaired with explicit Domain. First selected run 96 passed/1 failed: the new test used a declaration key instead of its actual opened inference key; fixed fixture via owner type_reference. Next 97 selected passed. First full run 1611 passed/6 known failed; Clippy passed; fmt failed on changed layout. Formatted and reran the final owner/quality input, retaining all prior results.'} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$root/application-source-context.summary.json"
Get-Content "$root/application-source-context.summary.json" -TotalCount 16
