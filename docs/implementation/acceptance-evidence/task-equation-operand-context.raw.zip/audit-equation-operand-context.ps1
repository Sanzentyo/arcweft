$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/equation-operand-context.final-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/equation-operand-context.final-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/equation-operand-context.final-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1619 tests run: 1613 passed, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1619\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/equation-operand-context.final-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1619 -or $terminal.Count -ne 1619 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$failed=@($terminal | Where-Object Result -eq 'FAIL' | ForEach-Object Name | Sort-Object)
$baseline=Get-Content -Raw "$root/original-context-retention-fixed.owner-summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$new=@($terminal | Where-Object Name -Match 'source_equation_operands_keep_their_receipts_when_closed_and_transported|a_child_result_equation_retains_the_selected_port_after_closure_and_transport')
if($new.Count -ne 2 -or @($new | Where-Object Result -ne 'PASS').Count){throw 'Owner regressions missing'}
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Source changed'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    $baseText=@(git show "$($pin.Base):$($p.Path)" 2>$null); $baseLines=if($LASTEXITCODE -eq 0){$baseText.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '/tests(?:/|\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=0;SHA256=$p.SHA256;Blob=$p.Blob}
})
$terminal | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/equation-operand-context.final-terminal.json"
[ordered]@{Version=1;Base=$pin.Base;Selected=1619;Passed=1613;Failed=6;Skipped=0;IdsEqual=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;SourcePinsVerified=$true;ClippyExit=0;FmtExit=0;Measurements=$measurements;Ownership='ConstraintOperand owns the value, exact scoped context and opaque origin DAG. It retains original source, actual template owner, source receipt and resolved selected result request; composition and specialization retain real input edges. PendingEquation carries operands for both sides and final expected, and original-product transport uses this same carrier. The separate equation scope field was removed. The cohesive operand owner has its own responsibility module. Existing large transaction/context algorithms retain their roles; no Cargo edge, public export, unsafe, I/O, version or budget change. Bindings/aliases, checked frontend value ports and strict Free authorization remain unfinished.';ReverseEvidence='Private owner metadata and impossible mismatched-source rejection only; no changed valid frontend language behavior. Full Sema was run. The resolved three-mode graph and 22-package closure remain unchanged; the last 21-consumer results remain pinned to 8b5e375a9c7b3096fe5ed2f65df556a463741a8d and are not claimed as rerun.';Development='Initial all-target check failed with E0277 at the result-use invariant conversion; mapped through TypeConstraintError. A development owner selection ran 100 tests, all passed, 1495 filter-excluded not run (0.863 seconds). It overlapped continued evidence-carrier edits and is not claimed as a pinned final-source run. The final full-owner list/run and quality checks below use a separate before/after pin manifest.'} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$root/equation-operand-context.summary.json"
Get-Content "$root/equation-operand-context.summary.json" -TotalCount 16
