$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskEvidence/assert-no-arcweft-build.ps1"
. "$taskEvidence/convergence-image-git-bytes.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$taskEvidence/$name.json" -Raw|ConvertFrom-Json -Depth 100}
function Sha([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
$publication=Receipt 'checkpoint-thread-indent.verified';$head=(git rev-parse HEAD).Trim()
if($head -ne $publication.commit -or $publication.parent -ne '89f18f9e2d2896ff21853e8e16e2750d4c8ee28e' -or $publication.paths.Count -ne 10){throw 'Review source publication'}
$combined=Receipt 'thread-indent.combined'
if($combined.normal.failed -or $combined.generic.passed -ne 151){throw 'Resolve actual new language-owner failures before acceptance'}
$mcpKey="arcweft-cli`tapp::agent::mcp_stdio::tests::stdio_transport_times_out_and_retains_bounded_stderr_tail"
if($combined.comparison.added.Count -ne 1 -or $combined.comparison.added[0] -ne $mcpKey){throw 'Review new failure outside the independently inspected MCP timeout case'}
$mcpPath='crates/arcweft-cli/src/app/agent/mcp_stdio.rs';$mcpBase=Read-GitBytes @('show',"89f18f9e2d2896ff21853e8e16e2750d4c8ee28e:$mcpPath")
if((Sha $mcpBase) -ne (Get-FileHash -LiteralPath $mcpPath).Hash.ToLowerInvariant()){throw 'MCP transport source changed; investigate before assigning scope'}
$quality=@(foreach($kind in @('check','clippy','structure')){$row=Receipt "thread-indent-quality1-20261103-$kind";if($row.exitCode -or $row.sourceDrift){throw 'Required quality gate failed'};$row})
$fmt=Receipt 'thread-indent-fmt';if($fmt.exitCode){throw 'Formatting failed'}
$freeze=Receipt 'thread-indent-reverse1-20261103.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$untracked=Receipt 'task-documentation-final-untracked-before';foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$history='docs/implementation/convergence-evidence-history.md';$before=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));$committed=Read-GitBytes @('show',"HEAD:$history")
if((Sha $before) -ne (Sha $committed)){throw 'History already has unpublished edits'}
$prefixHash=Sha $before
$raw='docs/implementation/acceptance-evidence/task-thread-indentation.raw.zip';$record='docs/implementation/acceptance-evidence/task-thread-indentation.json'
if((Test-Path -LiteralPath $raw) -or (Test-Path -LiteralPath $record)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $taskEvidence -File|Where-Object {$_.Name.StartsWith('thread-indent-') -or $_.Name.StartsWith('thread-indent.') -or $_.Name.StartsWith('checkpoint-thread-indent.')})
$files+=@(Get-ChildItem -LiteralPath "$taskEvidence/plan-current1" -File)
$files+=@(Get-ChildItem -LiteralPath "$taskEvidence/thread-indent-quality1-20261103.structure-report" -File -Recurse)
$files+=@(foreach($name in @('thread-indent.graph.json','cli-spec-yield-final.metadata.json','audit-thread-indent.ps1','recheck-thread-mcp.ps1','update-thread-current-status.ps1','measure-thread-indent.ps1','record-thread-indent.ps1','run-thread-indent-rest.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','run-action-payload-quality.ps1')){Get-Item -LiteralPath "$taskEvidence/$name"})
$files=@($files|Sort-Object FullName -Unique);$entries=@()
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($taskEvidence.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Archive count mismatch'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry mismatch'}}}finally{$zip.Dispose()}
$value=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$head;workingTree='main; original12 tracked and6 actual untracked WIP retained';scope='Thread indentation grammar and typed source-index ownership, including line-plan Thread+mark child projection. This cut does not claim flat-fence support or repair of style/provenance coverage.';publication=$publication;graph=(Receipt 'thread-indent.graph');combined=$combined;quality=$quality;format=$fmt;structureReview=(Receipt 'thread-indent.structure-review');contract='docs/01-language/dialogue-calls-scopes-cancellation.md permits indentation sugar for Thread. The ordinary ThreadExpression owns the statement-only suite; no separate line-plan Thread grammar is introduced.';rootCause=[ordered]@{parser='Thread expression dispatch/body discovery previously required a brace, and statement terminator stopped at the header newline';sourceIndex='HIR treated an implicit zero-width close anchor as a missing authored brace, rather than using the attached body is_unclosed predicate';fix='Share statement indentation geometry and the no-tail ThreadFlow suite emitter, preserve physical-line owner indentation in direct/let/return positions, attach authored colon on the same body, stage/freeze exact existing IndentationIntroducer role, and use attached.is_unclosed()';regressions='Lossless direct/let/return parse with outer sibling; invalid indentation recovery; typed attachment; clean HIR with exact wait and colon spans; real CLI current Character and both immediate/mark children'};attempts=@(
 [ordered]@{stem='thread-indent-syntax1-20261103';result='Initial Syntax lib-only3/3PASS before later source repair; historical only'},
 [ordered]@{stem='thread-indent-owner1-20261103';result='Full25 catalog built but selected1 rather than expected2; accidental new test inside raw fixture string was corrected, original fixture restored; no runtime ran'},
 [ordered]@{stem='thread-indent-owner2-20261103';result='Both2 selected tests failed at HIR source-index publication; led to owning is_unclosed and exact-colon source-role repair'},
 [ordered]@{stem='thread-indent-owner3-20261103';result='4PASS/1FAIL; Syntax/HIR passed, CLI plan succeeded and child count passed but a newly added string expectation incorrectly assumed authored mark name instead of canonical mark ID'},
 [ordered]@{stem='thread-indent-cli4-20261103';result='Corrected private CLI structural JSON expectation;1/1PASS; production unchanged. Four prior Syntax/HIR successes reused after exact input/case/EXE proof'}
 );probe='thread-indent-probe.json pins actual CLI executable and exact fixture;2 children with triggers immediate and mark1. Older plan-current1 probes explicitly lack a pre-run binary hash and are used only to locate boundaries.';acceptedFeatures='Generic Match remains accepted and published; the same151 case IDs freshly pass in the full25 complement. Independent accepted Thread runtime/save/capture features are not reopened by this syntax/source-index defect.';remaining='CLI retained failures stay failed with actual stderr. Original plan fixture still uses removed Character.dialogue_style, old flattened View field and old cascade layers; meaningful current style/provenance requirements are not deleted. Compiler still passes empty static inline_styles for valid content modifiers; further owner repair is separate.';sourceInputs=$freeze.paths.Count;sourceDrift=0;caseDrift=0;originalWip=[ordered]@{tracked=12;actualUntracked=6;heldPatchSha256=$publication.heldPatchSha256;untrackedHashDrift=0};historyPrefix=[ordered]@{bytes=$before.Length;sha256=$prefixHash;drift=0};raw=[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();entryDrift=0;entries=$entries}}
$mcpRecheck=Receipt 'thread-indent-mcp-recheck1-20261103.runtime.terminal-audit'
if($mcpRecheck.executed -ne 1){throw 'Missing focused MCP observation'}
$value['mcpFailure']=[ordered]@{test=$mcpKey;actual='Expected stderr capture Complete; observed ChildExitDeadline';requestTimeoutMs=250;shutdownResponseTimeoutMs=50;shutdownGraceTimeoutMs=100;sourceSha256=(Sha $mcpBase);sourceDrift=0;focusedRecheck=$mcpRecheck;scope='This source-unchanged transport test does not invoke the Thread parser or HIR owner. Preserve the new failure and the repeat as separate observations. A focused repeat does not replace the full CLI29-failure result or establish general timing reliability.'}
$value['reuseAuditCorrection']=[ordered]@{initialAssumption='Only the CLI check executable would rebuild after a private test assertion changed';observed='Cargo rebuilt12 CLI executables. All CLI cases are freshly executed, so none are reused. The only reused4 cases retain exact Syntax/HIR executable hashes. Focused CLI and complement share all executable hashes.';binaryDelta=$combined.reuseProof.binaryDelta;invalidReuse=0}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($value|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$append=@"


## 2026-11-03 Threadインデント文法・元source indexの修復

Source $head、parent89f18f9e2d2896ff21853e8e16e2750d4c8ee28e。維持仕様が許可するThreadのインデント形式がbrace限定の式dispatchと行末境界で拒否され、修復途中にはimplicit close anchorを閉じ忘れと誤認するHIR source indexの不整合が再現した。通常のThreadExpressionで、Awaitと同じstatement-only suite owner・物理行ownerのインデントを共有し、direct／let initializer／returnに対応した。一つのAttachedThreadExpressionBodyがauthored colonとimplicit anchorを持ち、HIRは既存IndentationIntroducer roleの正確なspanと成分数を検査し、閉じ忘れ判定を同bodyのis_unclosed()へ統一する。行専用Threadモデル、source再構築、過剰成分の許容や旧readerを加えない。flat fence全体の受入とはしない。

初回Syntax3件PASS、catalog選択guard失敗（新testをraw fixture内へ挿入した誤り）、修復途中のHIR／CLI2件FAIL、およびその後の4PASS／CLI新期待値1FAILを原出力ごと保持する。最後のCLI失敗はplan自体と子数が成功し、public summaryがmark名ではなく解決済みIDのmark1を出す点で新testが誤っていた。新testをJSONの2 children・immediate／mark1・Thread本文operationへ訂正し、1／1PASS。productionは変更せず、他4089入力・再利用4件の実EXE・case一致を確認した。

全25実逆依存、all-target／all-feature／lockedの5853 distinct件は、最後の5849新規と同一Syntax／HIR実EXEの4再利用で照合した。通常側$($combined.normal.executed)／$($combined.normal.passed) PASS・$($combined.normal.failed) FAIL、CLI$($combined.cli.executed)件は$($combined.cli.passed) PASS／$($combined.cli.failed) FAIL、catalog全体32 ignored。CLI元28失敗IDとの比較は維持$($combined.comparison.retained.Count)／追加$($combined.comparison.added.Count)／解消$($combined.comparison.resolved.Count)、新しいThread case1件を別に追加。ID一致から原因一致を推定せず、今回のstderrを保持する。Generic Matchの同じ151 IDは151／151新規PASSで既受入を維持し、CLI全体や別境界の未完了を理由に戻さない。

新規のCLI失敗1件は、source変更0のMCP transport testが100msの終了grace内でCompleteを期待したところChildExitDeadlineを返したもの。250ms request／50ms shutdown response／100ms graceとstderr32byteを変えず、単独で1件再確認した結果は$($mcpRecheck.passed) PASS／$($mcpRecheck.failed) FAIL。これは全件runの29 FAILを置き換えず、transportの一般的なtiming reliabilityの受入にも使わない。Thread構文・HIRを呼び出さない独立条件として実測を残す。再利用監査の初回guardはCLI checkだけがrebuildされるとの誤った仮定で停止したが、実際にはCLI12 executableがrebuildされていた。CLI全件は新規実行しており再利用せず、再利用4件だけのSyntax／HIR実EXE一致と、最後のCLI／complement間全EXE一致を確認した。

全98 workspace check／Clippy、変更Rust10件fmt、canonical構造gateは終了0、警告は残る。実LOC・byte・base growth・test・fan-in/outとowner cohesionを原本に記録し、statement suite、typed attachment、HIR source manifest、CLI planの責任を維持する。[全case・実測・途中失敗・公開full SHA・gate・raw](acceptance-evidence/task-thread-indentation.json)。元planの廃止済みCharacter設定／View field／cascade期待と、実際のstatic inline_styles欠落は別境界の具体的未達として保持し、assertionを消して合格にはしない。既存履歴先頭$($before.Length) bytes（SHA256 $prefixHash）を保持して追記し、12 tracked／6 actual untracked WIPは変更しない。
"@
$appendBytes=[Text.Encoding]::UTF8.GetBytes($append.Replace("`r`n","`n")+"`n");$stream=[IO.File]::Open([IO.Path]::GetFullPath($history),[IO.FileMode]::Append)
try{$stream.Write($appendBytes)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));if((Sha $after[0..($before.Length-1)]) -ne $prefixHash){throw 'Historical prefix changed'}
[ordered]@{source=$head;rawEntries=$entries.Count;rawBytes=$value.raw.bytes;rawSha256=$value.raw.sha256;prefixBytes=$before.Length;prefixSha256=$prefixHash;prefixDrift=0}|ConvertTo-Json -Compress
