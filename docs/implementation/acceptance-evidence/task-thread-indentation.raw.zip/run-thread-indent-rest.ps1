$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskEvidence/assert-no-arcweft-build.ps1"
$focused=Get-Content -LiteralPath "$taskEvidence/thread-indent-cli4-20261103.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if(-not $focused.isPassingRun -or $focused.executed -ne 1){throw 'Focused CLI regression has not passed'}
$old=Get-Content -LiteralPath "$taskEvidence/thread-indent-owner3-20261103.source-freeze.json" -Raw|ConvertFrom-Json
$current=Get-Content -LiteralPath "$taskEvidence/thread-indent-cli4-20261103.source-freeze.json" -Raw|ConvertFrom-Json
$sourceMap=@{};foreach($row in $old.paths){$sourceMap[$row.path]=$row.sha256}
$delta=@($current.paths|Where-Object {$sourceMap[$_.path] -ne $_.sha256})
if($delta.Count -ne 1 -or $delta[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs'){throw 'Review source delta before reusing four passing owner cases'}
$command=(Get-Content -LiteralPath "$taskEvidence/thread-indent-owner3-20261103.catalog.json" -Raw|ConvertFrom-Json).command
$selection=@($command[2..($command.Count-3)])
$selection[$selection.Count-1]='not ('+$selection[$selection.Count-1]+')'
$inventory=Get-Content -LiteralPath "$taskEvidence/thread-indent-owner3-20261103.catalog.inventory.json" -Raw|ConvertFrom-Json
$expected=@($inventory.rows|Where-Object {-not $_.ignored -and $_.status -ne 'matches'}).Count
& "$taskEvidence/run-presentation-projection-owner.ps1" -Stem 'thread-indent-reverse1-20261103' -Selection $selection -ExpectedMatches $expected -AdditionalPaths $current.paths.path
$runtimeExit=$LASTEXITCODE
if($runtimeExit -notin @(0,100)){throw 'Complement has no acceptable terminal'}
& "$taskEvidence/run-action-payload-quality.ps1" -Epoch 'thread-indent-reverse1-20261103' -Stem 'thread-indent-quality1-20261103'
