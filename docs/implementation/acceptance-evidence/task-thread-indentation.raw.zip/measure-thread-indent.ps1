$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskEvidence/convergence-image-git-bytes.ps1"
$head=(git rev-parse HEAD).Trim()
$paths=(Get-Content -LiteralPath "$taskEvidence/current-execution-handoff-20261103.json" -Raw|ConvertFrom-Json).pendingOwnedPaths
$metadata=Get-Content -LiteralPath "$taskEvidence/cli-spec-yield-final.metadata.json" -Raw|ConvertFrom-Json -Depth 100
$members=@($metadata.workspace_members);$nodes=@{};$packages=@{}
foreach($node in $metadata.resolve.nodes){$nodes[$node.id]=$node}
foreach($package in $metadata.packages){$packages[$package.name]=$package}
$rows=@(foreach($path in $paths){
 $crate=$path.Split('/')[1];$package=$packages[$crate];$node=$nodes[$package.id]
 $bytes=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($path));$baseBytes=Read-GitBytes @('show',"${head}:$path")
 $text=[Text.Encoding]::UTF8.GetString($bytes);$baseText=[Text.Encoding]::UTF8.GetString($baseBytes)
 $loc=[regex]::Matches($text,"`n").Count+[int](-not $text.EndsWith("`n"));$baseLoc=[regex]::Matches($baseText,"`n").Count+[int](-not $baseText.EndsWith("`n"))
 $test=$path -match '/tests/|/tests\.rs$|/predicate_proof_tests\.rs$'
 [ordered]@{path=$path;crate=$crate;bytes=$bytes.Length;physicalLoc=$loc;basePhysicalLoc=$baseLoc;growth=$loc-$baseLoc;classification=$(if($test){'test'}else{'production'});embeddedTestLoc=$(if($test){$loc}else{0});workspaceFanOut=@($node.dependencies|Where-Object {$_ -in $members}).Count;workspaceFanIn=@($metadata.resolve.nodes|Where-Object {$_.id -in $members -and $package.id -in $_.dependencies}).Count}
})
$value=[ordered]@{version=1;head=$head;workingTree='dirty;10 owned Thread paths plus12 original held tracked WIP;6 actual untracked held';rows=$rows;ownershipReview=@(
 [ordered]@{owner='Syntax Thread expression and statement-suite parser';responsibility='Lossless Thread grammar and malformed suite recovery. Existing Await statement-only suite emitter owns the common body grammar; Thread delegates instead of introducing a line-plan-only grammar.';disposition='Keep cohesive parser owners. statement.rs exceeds2500LOC but the added responsibility is the existing indentation/control-body algorithm. No unrelated state, semantic policy, I/O, dependency edge or public API for file splitting was introduced. Tests follow Syntax success/recovery/attachment boundaries.'},
 [ordered]@{owner='Syntax AttachedThreadExpressionBody';responsibility='One typed body retains an optional authored colon and implicit delimiter anchors. is_unclosed remains the authority for structural missing-brace classification.';disposition='The public getter exposes actual authored source needed by HIR; it is not a physical-split convenience. Invalid implicit/explicit shape combinations are rejected, without a parallel indentation body type.'},
 [ordered]@{owner='HIR thread_body_projection';responsibility='Stage and validate the original Thread body source graph, exact authored colon role and insertion anchors.';disposition='Keep the shared stage/freeze manifest together. Use existing IndentationIntroducer role and owning is_unclosed predicate; exact component cardinality remains enforced. No duplicate source reconstruction, I/O or reversed layer dependency.'},
 [ordered]@{owner='CLI plan regression';responsibility='End-to-end current Character/display and line-plan child projection.';disposition='cli_runtime_bench.rs exceeds8000LOC; this cut adds one case beside the existing plan owner, without cross-concern test helpers, state or dependency changes. Keep its coherent fixture/JSON assertions here; no public widening or physical-only split. Existing plan style/provenance assertions and original workload remain unchanged; their actual unresolved failure remains visible.'}
 );sourceSpellingPolicy='Measurements and review aids only; executable regression checks, typed source manifests and canonical dependency gate establish behavior.'}
$value|ConvertTo-Json -Depth 30|Set-Content -LiteralPath "$taskEvidence/thread-indent.structure-review.json" -Encoding utf8
$rows|ForEach-Object {[pscustomobject]$_}|Select-Object path,physicalLoc,basePhysicalLoc,growth,embeddedTestLoc,workspaceFanIn,workspaceFanOut|ConvertTo-Json -Compress
