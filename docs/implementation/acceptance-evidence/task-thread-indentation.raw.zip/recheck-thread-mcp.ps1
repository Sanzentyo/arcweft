$ErrorActionPreference='Stop'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskEvidence/assert-no-arcweft-build.ps1"
$command=(Get-Content -LiteralPath "$taskEvidence/thread-indent-owner3-20261103.catalog.json" -Raw|ConvertFrom-Json).command
$selection=@($command[2..($command.Count-3)])
$selection[$selection.Count-1]='test(=app::agent::mcp_stdio::tests::stdio_transport_times_out_and_retains_bounded_stderr_tail)'
$paths=(Get-Content -LiteralPath "$taskEvidence/thread-indent-reverse1-20261103.source-freeze.json" -Raw|ConvertFrom-Json).paths.path
& "$taskEvidence/run-presentation-projection-owner.ps1" -Stem 'thread-indent-mcp-recheck1-20261103' -Selection $selection -ExpectedMatches 1 -AdditionalPaths $paths
