$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Receipt([string]$name){Get-Content -LiteralPath "$taskEvidence/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$out="$taskEvidence/thread-indent.combined.json"
if(Test-Path -LiteralPath $out){throw 'Preserve existing combined receipt'}
$owner='thread-indent-owner3-20261103';$cli='thread-indent-cli4-20261103';$rest='thread-indent-reverse1-20261103'
$old=Receipt "$owner.source-freeze";$current=Receipt "$rest.source-freeze";$focused=Receipt "$cli.source-freeze"
$oldMap=@{};$focusedMap=@{};foreach($row in $old.paths){$oldMap[$row.path]=$row.sha256};foreach($row in $focused.paths){$focusedMap[$row.path]=$row.sha256}
if($old.paths.Count -ne $current.paths.Count -or $focused.paths.Count -ne $current.paths.Count){throw 'Input set changed'}
$delta=@($current.paths|Where-Object {$oldMap[$_.path] -ne $_.sha256})
if($delta.Count -ne 1 -or $delta[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs'){throw 'Unexpected owner source delta'}
foreach($row in $current.paths){if($focusedMap[$row.path] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Focused/current source drift'}}
$oldPins=Receipt "$owner.binaries-before";$focusedPins=Receipt "$cli.binaries-before";$pins=Receipt "$rest.binaries-before"
$oldPinMap=@{};$focusedPinMap=@{};foreach($row in $oldPins){$oldPinMap[$row.binary]=$row.sha256};foreach($row in $focusedPins){$focusedPinMap[$row.binary]=$row.sha256}
if($oldPins.Count -ne $pins.Count -or $focusedPins.Count -ne $pins.Count){throw 'Binary set changed'}
$binaryDelta=@($pins|Where-Object {$oldPinMap[$_.binary] -ne $_.sha256})
if(-not $binaryDelta.Count -or @($binaryDelta|Where-Object {$_.binary -notlike 'arcweft-cli*'}).Count){throw 'A reused non-CLI executable changed'}
foreach($reusedBinary in @('arcweft-lang-syntax','arcweft-lang-hir')){if($oldPinMap[$reusedBinary] -ne $focusedPinMap[$reusedBinary]){throw 'Reused Syntax/HIR executable differs'}}
foreach($row in $pins){if($focusedPinMap[$row.binary] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Focused/current binary drift'}}
$coverage=@{};$catalogKeys=@{};$catalogIgnored=@{}
foreach($stem in @($owner,$cli,$rest)){
 $inventory=Receipt "$stem.catalog.inventory";$selected=@{}
 foreach($row in $inventory.rows){$key=$row.binary+"`t"+$row.test;if($row.ignored){$catalogIgnored[$key]=$row}else{$catalogKeys[$key]=$row};if($row.status -eq 'matches'){$selected[$key]=$row}}
 $after=$false;$observed=0
 foreach($line in [IO.File]::ReadLines("$taskEvidence/$stem.runtime.log")){
  if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
  if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
   $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test;$observed++
   if(-not $selected.ContainsKey($key)){throw 'Unexpected final case'}
   if($stem -eq $owner -and $binary -eq 'arcweft-cli::check'){continue}
   if($coverage.ContainsKey($key)){throw 'Duplicate final coverage'}
   $coverage[$key]=[ordered]@{package=$selected[$key].package;binary=$binary;test=$test;status=$status;run=$stem;kind=$(if($stem -eq $owner){'reused-identical-Syntax-HIR-executable'}else{'fresh-final-source'})}
  }
 }
 if($observed -ne $selected.Count){throw 'Missing final statuses'}
}
if($coverage.Count -ne 5853 -or @(Compare-Object @($catalogKeys.Keys) @($coverage.Keys)).Count){throw 'Incomplete reverse closure'}
function Partition([object[]]$rows){$failed=@($rows|Where-Object status -notin @('PASS','SLOW'));[ordered]@{executed=$rows.Count;passed=$rows.Count-$failed.Count;failed=$failed.Count;failureSet=$failed}}
$normal=Partition @($coverage.Values|Where-Object package -ne 'arcweft-cli');$cliResult=Partition @($coverage.Values|Where-Object package -eq 'arcweft-cli')
$previous=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-script-signal-expectation.json -Raw|ConvertFrom-Json -Depth 100
$previousCases=@($previous.combined.cases|Where-Object package -eq 'arcweft-cli');$previousFailures=@($previousCases|Where-Object status -notin @('PASS','SLOW')|ForEach-Object {$_.binary+"`t"+$_.test})
$currentFailures=@($cliResult.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$caseAdded=@($coverage.Values|Where-Object package -eq 'arcweft-cli'|Where-Object {($_.binary+"`t"+$_.test) -notin @($previousCases|ForEach-Object {$_.binary+"`t"+$_.test})})
if($caseAdded.Count -ne 1 -or $caseAdded[0].test -ne 'plan_json_keeps_indented_thread_and_mark_children'){throw 'Unexpected CLI inventory delta'}
$comparison=[ordered]@{baselineSource=$previous.source;retained=@($currentFailures|Where-Object {$_ -in $previousFailures});added=@($currentFailures|Where-Object {$_ -notin $previousFailures});resolved=@($previousFailures|Where-Object {$_ -notin $currentFailures});newCases=$caseAdded;scope='Compare failure IDs only; current failures retain actual stderr, without an assumption of identical causes.'}
$genericPrior=(Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-cli-yield-context.json -Raw|ConvertFrom-Json -Depth 100).combined.subsets.genericMatch.cases
$generic=@(foreach($row in $genericPrior){$key=$row.binary+"`t"+$row.test;if(-not $coverage.ContainsKey($key)){throw 'Missing accepted Generic Match case'};$coverage[$key]})
$genericResult=Partition $generic
if($genericResult.executed -ne 151){throw 'Generic subset changed'}
$value=[ordered]@{version=1;base=$current.base;graph=(Receipt 'thread-indent.graph');sourceInputs=$current.paths.Count;sourceDrift=0;caseDrift=0;executables=$pins;executableDrift=0;reuseProof=[ordered]@{changedInputs=$delta;unchangedInputs=$current.paths.Count-$delta.Count;binaryDelta=$binaryDelta;reusedCases=4;reason='Only a newly introduced private CLI JSON assertion changed after the four Syntax/HIR cases passed. All production and other test inputs, exact case IDs, features/target/toolchain and the reused executables match. Current CLI and complement share all source and executable hashes.'};distinctCases=$coverage.Count;freshFinalSourceCases=@($coverage.Values|Where-Object kind -eq 'fresh-final-source').Count;reusedCases=4;normal=$normal;cli=$cliResult;ignored=$catalogIgnored.Count;generic=$genericResult;comparison=$comparison;cases=@($coverage.Values|Sort-Object package,binary,test);runs=@(Receipt "$owner.runtime.terminal-audit";Receipt "$cli.runtime.terminal-audit";Receipt "$rest.runtime.terminal-audit");scope='Complete all-target/all-feature/locked Syntax reverse closure25. Four unchanged successful Syntax/HIR cases are reused, corrected CLI case and complementary5848 cases are freshly executed. Failed earlier attempts remain separate historical results. Existing independent accepted features retain their own acceptance.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{normalExecuted=$normal.executed;normalPassed=$normal.passed;normalFailed=$normal.failed;cliExecuted=$cliResult.executed;cliPassed=$cliResult.passed;cliFailed=$cliResult.failed;genericPassed=$genericResult.passed;genericFailed=$genericResult.failed;retained=$comparison.retained.Count;added=$comparison.added.Count;resolved=$comparison.resolved.Count;ignored=$catalogIgnored.Count;distinct=$coverage.Count;reused=4}|ConvertTo-Json -Compress
