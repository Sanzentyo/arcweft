$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskEvidence/assert-no-arcweft-build.ps1"
$record=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-thread-indentation.json -Raw|ConvertFrom-Json -Depth 100
$head=$record.source;$combined=$record.combined
if((git rev-parse HEAD).Trim() -ne $head -or $combined.normal.failed -or $combined.generic.passed -ne 151){throw 'Review latest source/results'}
$path='docs/implementation/current-status.md';$text=[IO.File]::ReadAllText([IO.Path]::GetFullPath($path))
function Replace-Row([string]$prefix,[string]$replacement){
 $pattern='(?m)^\| '+[regex]::Escape($prefix)+'[^\r\n]*'
 if([regex]::Matches($script:text,$pattern).Count -ne 1){throw ('Current status row must be unique: '+$prefix)}
 $script:text=[regex]::Replace($script:text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match)$replacement})
}
Replace-Row 'Generic Match `.1.2` C3/C5' "| Generic Match ``.1.2`` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。今回のSource $head・Syntax全25逆依存では同じ151 IDを151／151新規PASSと照合した。[最新の全case照合](acceptance-evidence/task-thread-indentation.json)。以前の合法generator fixture移行、初回失敗、新規144＋同一EXE再利用7の証明は[その時点の記録](acceptance-evidence/task-cli-yield-context.json)へ保持する。別境界や全体goalの未達だけで未完了へ戻さない。 |"
if($text.Contains('| Threadのインデント形式／元source保持 |')){throw 'Do not duplicate current Thread status'}
$thread="| Threadのインデント形式／元source保持 | **当該構文・投影条件は検証・公開済み** | Source $head。通常ThreadExpressionがAwaitと同じstatement-only suiteを使い、direct／let initializer／returnの本文と外側siblingを保持する。暗黙close anchorを閉じ忘れと区別し、実在するcolonは既存IndentationIntroducer roleで正確なspan・成分数を検査する。Syntax3件、HIRのclean＋wait／colon範囲、実CLIのThreadとmarkの2 childrenがPASS。途中のcatalog guard、HIR2失敗と誤ったCLI新期待値1失敗も[実測と訂正理由](acceptance-evidence/task-thread-indentation.json)に保持する。flat fence全体と旧planのスタイル出典情報の修復はこの受入に含めない。 |"
$anchor='(?m)^(\| 対話の段階実行／所有子Thread／line out値[^\r\n]*)(\r?\n)'
if([regex]::Matches($text,$anchor).Count -ne 1){throw 'Missing stable row insertion anchor'}
$text=[regex]::Replace($text,$anchor,[Text.RegularExpressions.MatchEvaluator]{param($match)$match.Groups[1].Value+$match.Groups[2].Value+$thread+$match.Groups[2].Value})
Replace-Row '共有契約／推移的逆依存matrix' "| 共有契約／推移的逆依存matrix | **今回のSyntax全25逆依存を終端照合。通常側$($combined.normal.executed)／$($combined.normal.passed) PASS** | Source $head、all-target／all-feature／locked、4090入力。5853 distinct件は、最後の5849件新規実行と入力・case・実EXE一致によるSyntax／HIR4件再利用で照合した。一つの全件新規runとはしない。全catalog32 ignored、CLIは下行へ集約する。[今回の実graph・全case・途中失敗・再利用証明](acceptance-evidence/task-thread-indentation.json)。直前のSema22、Core53、以前のID／Syntax71は別入力・別graphの履歴として保持し、今回の新規件数に重複加算しない。 |"
Replace-Row 'CLI全target照合' "| CLI全target照合 | **統合受入は未完了。$($combined.cli.executed)件中$($combined.cli.passed) PASS／$($combined.cli.failed) FAIL** | Source $head、4090入力、all-target／all-feature／locked、CLI23 ignored。今回の全25逆依存照合では新しいThread子投影1件を含めてCLI全$($combined.cli.executed)件を新規実行した。前のSource 5bd260821e67abdad2907a0ccd4c2297e026c526 の失敗IDとの比較は維持$($combined.comparison.retained.Count)／追加$($combined.comparison.added.Count)／解消$($combined.comparison.resolved.Count)。追加1件はsource変更のないMCP transport testのChildExitDeadlineで、100ms grace内のComplete期待を満たさなかった。単独再確認は$($record.mcpFailure.focusedRecheck.passed) PASS／$($record.mcpFailure.focusedRecheck.failed) FAILだが、全件runの29 FAILを置き換えず、一般的なtiming reliabilityの受入とはしない。ID一致から原因一致を推定せず、実際のstderrを保持する。[最新全case・失敗差分・raw](acceptance-evidence/task-thread-indentation.json)。旧planのCharacter設定／View field／cascade期待と、現行content modifierでもstatic inline_stylesが空の未達は別ownerの修復対象。意味のあるassertionを削除して合格にはしない。以前の666 PASS／28 FAILとsignalの修復、33失敗からの訂正理由は[当時の原本](acceptance-evidence/task-script-signal-expectation.json)に保持する。 |"
Replace-Row 'workspace check／Clippy・fmt・構造gate' "| workspace check／Clippy・fmt・構造gate | **全98 check／Clippy・変更fmt・構造gateは終了0。警告は残存** | 最新Source $head、4090入力、all-target／all-feature／locked。全98 workspace check／Clippy、変更Rust10件fmt、canonical構造gateが終了0。[今回のgate・実LOC・所有境界レビュー](acceptance-evidence/task-thread-indentation.json)。doctest9 crate・88件PASS（5 crateは0件）とWebのwasm checkは以前のSource 9a75564dc58d4c844f2c25a45958a1d081682934 での実測として保持し、今回の新規実行とはしない。[以前のdoctest・wasm](acceptance-evidence/task-action-channel-receive-consumers.json)。 |"
[IO.File]::WriteAllText([IO.Path]::GetFullPath($path),$text,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$head;uniqueStatusRows=1;genericAccepted=$true;history='original entries unchanged, new observation appended separately';normalPassed=$combined.normal.passed;cliPassed=$combined.cli.passed;cliFailed=$combined.cli.failed}|ConvertTo-Json -Compress
