$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='flow-defer-registry-20261107'
$source=Get-Content "$taskTemp/$prefix.source.verified.json" -Raw|ConvertFrom-Json
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Frozen source changed'}
$started=[DateTime]::UtcNow
$filter='rdeps(=arcweft-core)'
$listArgs=@('nextest','list','--locked','--workspace','--lib','--tests','-E',$filter,'--message-format','json')
& cargo @listArgs > "$taskTemp/$prefix.reverse-retry.list.json" 2> "$taskTemp/$prefix.reverse-retry.list.stderr.log"
$listCode=$LASTEXITCODE
if($listCode -ne 0){
 [ordered]@{version=1;source=$source.commit;listArguments=$listArgs;exitCode=$listCode;phase='Build/list before test execution';startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse-retry.build-failure.receipt.json" -Encoding utf8
 exit $listCode
}
$list=Get-Content "$taskTemp/$prefix.reverse-retry.list.json" -Raw|ConvertFrom-Json -Depth 100
$selected=@(foreach($binary in $list.'rust-suites'.PSObject.Properties){foreach($test in $binary.Value.testcases.PSObject.Properties){if($test.Value.'filter-match'.status -eq 'matches'){[pscustomobject][ordered]@{package=$binary.Value.'package-name';binary=$binary.Value.'binary-name';test=$test.Name}}}})
if(!$selected.Count){throw 'Empty reverse selection'}
$selected|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse-retry.selection.json" -Encoding utf8
$runArgs=@('nextest','run','--locked','--workspace','--lib','--tests','-E',$filter,'--no-tests','fail','--no-fail-fast')
& cargo @runArgs *> "$taskTemp/$prefix.reverse-retry.log"
$code=$LASTEXITCODE
$drift=@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
$summary=@(Select-String -LiteralPath "$taskTemp/$prefix.reverse-retry.log" -Pattern 'Summary \['|ForEach-Object {$_.Line})
[ordered]@{version=1;source=$source.commit;filter=$filter;listArguments=$listArgs;arguments=$runArgs;listExitCode=$listCode;filterMatchedTests=$selected.Count;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=$drift;summary=$summary;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse-retry.receipt.json" -Encoding utf8
$summary|Write-Output
if($drift){throw 'Source changed during reverse matrix'}
exit $code
