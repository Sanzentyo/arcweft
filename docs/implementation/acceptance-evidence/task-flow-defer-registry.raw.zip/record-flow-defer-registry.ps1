$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='flow-defer-registry-20261107'
$source=Get-Content "$taskTemp/$prefix.source.verified.json" -Raw|ConvertFrom-Json
$matrix=Get-Content "$taskTemp/$prefix.reverse-retry.receipt.json" -Raw|ConvertFrom-Json
if((&git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected documentation base'}
if($matrix.sourceDrift -ne 0 -or $matrix.listExitCode -ne 0){throw 'Incomplete reverse matrix'}
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Frozen source changed'}
$untracked=Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json
if(@($untracked.files|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Original untracked files changed'}
$selected=Get-Content "$taskTemp/$prefix.reverse-retry.selection.json" -Raw|ConvertFrom-Json
$log=[IO.File]::ReadAllText("$taskTemp/$prefix.reverse-retry.log")
$failed=@([regex]::Matches($log,'(?m)^\s*FAIL\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+([^\r\n]+)')|ForEach-Object {[pscustomobject]@{binary=$_.Groups[1].Value;test=$_.Groups[2].Value}}|Sort-Object test -Unique)
$expected=@('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering','spec_valid_run_edge_fixture_now_executes','verify_json_records_required_solver_checks','verify_json_reports_missing_promotion_proof')
if(@(Compare-Object @($failed.test|Sort-Object) @($expected|Sort-Object)).Count){throw 'Unexpected failures need investigation'}
$summary=$matrix.summary -join "`n"
if($summary -notmatch '(\d+) tests run: (\d+) passed.*?(\d+) failed.*?(\d+) skipped'){throw 'Unknown matrix summary'}
$counts=[ordered]@{run=[int]$Matches[1];passed=[int]$Matches[2];failed=[int]$Matches[3];skipped=[int]$Matches[4]}
if($counts.run -ne $selected.Count -or $counts.failed -ne $failed.Count){throw 'Selection and terminal differ'}
$registryTests=@('scoped_defer_writes_the_reached_flow_registry_before_resuming_parent','function_defer_writes_its_callers_flow_registry','scoped_defer_reads_and_drops_only_its_reached_flow_registry_key','nested_defer_reaches_flow_registry_through_its_real_cleanup_parent','generic_defer_keeps_registry_values_bound_to_each_original_capture_type')
$semaTest='closed_subset_uses_the_same_scoped_capability_coverage_as_permission_checks'
foreach($name in @($registryTests+$semaTest)){if($log -notmatch ('(?m)^\s*PASS\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+\S+\s+[^\r\n]*'+[regex]::Escape($name)+'\s*$')){throw "Missing regression pass: $name"}}
$quality=[ordered]@{}
foreach($name in @('workspace-check','workspace-clippy','structure','fmt')){$receipt=Get-Content "$taskTemp/$prefix.$name.receipt.json" -Raw|ConvertFrom-Json;if($receipt.exitCode -ne 0){throw "Failed quality: $name"};$quality[$name]=$receipt}
$names=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*"|Where-Object {$_.Name -notmatch '\.(message|other|pathspec|owned)\.?(txt)?$'}|ForEach-Object {$_.Name})
$names+=@('run-flow-defer-registry-validation.ps1','run-flow-defer-registry-retry.ps1','record-flow-defer-registry.ps1','function-scope-20261107.metadata-all.json')
$names=@($names|Sort-Object -Unique)
$zipPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-defer-registry.raw.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Raw destination already exists'}
Compress-Archive -LiteralPath @($names|ForEach-Object {"$taskTemp/$_"}) -DestinationPath $zipPath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{foreach($entry in $archive.Entries){$row=$entries|Where-Object entry -eq $entry.FullName;$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($row.bytes -ne $entry.Length -or $row.sha256 -ne $hash){throw 'Archive byte/hash mismatch'}};if($archive.Entries.Count -ne $entries.Count){throw 'Archive entry set mismatch'}}finally{$archive.Dispose()}
$cliCount=@($selected|Where-Object package -eq 'arcweft-cli').Count
$record=[ordered]@{
 version=1;date='2026-11-07';source=$source;regressionBase=$source.parent
 behavior='One ProductRegistryOrigin resolves actual Dialogue or Deferred custody to the reached Flow registry. Ordinary cleanup validates its active lexical owner and inflight marker, then follows real child/activation parent edges. It uses the same authenticated prepare/commit mutation boundary as Dialogue. No fake Line, copied owner table, fallback registry, new opcode, contract version or persisted authority is added.'
 semanticRepairs=@{scopedCapability='Closed EffectRow subset checks now use the existing EffectId scoped coverage rule, matching permission checks. The maintained state.write(scope) grant covers child keys; preserve the broad authored grant rather than narrowing fixtures to bypass the bug. Open/symbolic inference is unchanged.';dropTail='Registry drop state.write is collected from the final checked operation for every expression position, including a Unit body tail. Remove the statement-only augmentation so callback invocation metadata retains the same permission.'}
 initialReproduction=@{passed=0;failed=3;scope='Three added cases before the fixes; two reach AWBC RegistryContextRequired after Native, while the function case is rejected at Source effect-bound checking.';correction='An intermediate commentary incorrectly said all three first passed Native. This record corrects that claim; the original log and diagnostics are preserved.'}
 intermediateOwner=@{receipt=(Get-Content "$taskTemp/$prefix.owner-target.receipt.json" -Raw|ConvertFrom-Json);passed=20;failed=3;cause='Two scoped-effect upper-bound checks and Native callback drop authorization.'}
 finalOwner=@{receipt=(Get-Content "$taskTemp/$prefix.owner-fixed.receipt.json" -Raw|ConvertFrom-Json);passed=23;failed=0;composition=(Get-Content "$taskTemp/$prefix.owner-target.composition.json" -Raw|ConvertFrom-Json);note='The --workspace --test scoped_defer owner run has a different dependency artifact composition from --workspace --lib --tests. It is not relabeled as the broad matrix.'}
 tests=@{registry=$registryTests;semantics=$semaTest;conditions='Both Native and canonical-decoded AWBC; each Product step public-save/cold-restore, one operation budget, exact logs, original capture types, sibling key retention and runtime write/read/drop. The Sema unit checks positive scoped coverage, negative sibling/foreign scopes and unchanged substitutions.'}
 buildFailures=@{owner=(Get-Content "$taskTemp/$prefix.owner-build-failure.receipt.json" -Raw|ConvertFrom-Json);reverse=(Get-Content "$taskTemp/$prefix.reverse-build-failure.receipt.json" -Raw|ConvertFrom-Json);recovery='Windows paging error 1455 stopped both broad lists before tests. Retain both failures; retry the identical workspace/default-feature/library-and-integration selection against unchanged source using successful cached build units. No cargo jobs, profile or feature setting was changed.'}
 graph=(Get-Content "$taskTemp/$prefix.graph.json" -Raw|ConvertFrom-Json);matrix=$matrix;counts=$counts;actualPackages=@($selected.package|Sort-Object -Unique).Count
 cli=@{run=$cliCount;passed=$cliCount-$failed.Count;failed=$failed.Count;remaining=$failed};nonCliPassed=$selected.Count-$cliCount;quality=$quality
 inputIdentity=@{preRunInputs=$freeze.paths.Count;rootFixtures=@($freeze.paths|Where-Object path -like 'tests/*').Count;cargoInputs=@($freeze.paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'}).Count;sourceDrift=0;cargoDrift=0;originalTrackedWip=$source.heldPatchSha256;originalUntrackedFiles=$untracked.files.Count;untrackedDrift=0}
 ownerMetrics=(Get-Content "$taskTemp/$prefix.owner-metrics.json" -Raw|ConvertFrom-Json)
 ownershipReview='Registry custody resolution and prepared row admission belong to one private Product owner shared by Line and ordinary cleanup. Delete the old dialogue-only resolver and migrate every VM resource producer/test directly. The new 214-LOC module is one owner algorithm, not an alternate registry authority. EffectRow owns closed capability coverage; checked expression effects own intrinsic registry drop effects. Existing large files retain their responsibility; no new dependency or public API.'
 correction='Supersedes the current-status claim that admitted ordinary-defer Flow registry access still lacks AWBC context. Explicit semicolon/Unit-tail sources execute. Optional reads intentionally observe dynamic callback writes; a required read still needs its separate static reaching-presence proof. HIR recovery for an unterminated trailing write is a distinct syntax condition and is not used to reopen accepted runtime boundaries. Remove repeated old matrix/partition counts from the two accepted registry feature rows; retain their full SHAs and all measurements in prior JSON/history sections, with the latest broad matrix stated once.'
 limits='This cut does not accept promotion/MustDrop formal proofs, mandatory VoiceHandle execution, ordinary-defer goto/Choice, direct AWBC return from open scopes, cancellation/Line-affine capture, aggregate registration/spawn preflight, other-platform/Tier2 execution or Native public-save support. Generic Match and accepted Native boundaries remain accepted. An unused import in dialogue.rs is retained in these frozen tested bytes; its warning is preserved.'
 raw=@{path='task-flow-defer-registry.raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$entries}
}
$jsonPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($jsonPath)
if($before.Contains('"ordinaryFlowDeferredRegistry"')){throw 'Duplicate evidence key'}
$fragment=([ordered]@{ordinaryFlowDeferredRegistry=$record}|ConvertTo-Json -Depth 70).Trim()
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n"+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($jsonPath,$after,[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-07 — Ordinary cleanup registry custody and scoped effect coverage

Source **$($source.commit)**、parent **$($source.parent)** を既存 main へ通常 commit/push し、13 path の tree／blob／完全差分を照合した。既存 tracked 12 path と untracked 6 file は保持した。
通常 defer は実際の lexical owner と実行中登録を認証し、元の child／activation の親をたどって到達した Flow registry を操作する。Line と同じ一つの prepare／commit 境界へ統合し、旧対話専用 resolver を削除した。仮 Line、親の複製表、fallback、命令・保存versionは追加しない。
最初の3件は2件がAWBCのcontext不足、1件がSourceのeffect上限で失敗した。「全3件が先にNativeを通過」とした途中説明を訂正する。次の対象runは20 PASS／3 FAIL。現行契約どおり scope root の権限が子キーを覆うようclosed EffectRowのsubset判定を共通規則へ揃え、Unit末尾のregistry dropも型付き式の効果へ集めた。広い権限のfixtureを狭めて回避しない。最終対象23件は全通過した。
対象専用の --workspace --test scoped_defer はCore依存artifactが広域構成と異なることを実測しており、同じ構成との説明は訂正した。広域listの2回のWindows1455はテスト未実行として原本に保持。入力・feature・対象を変えずキャッシュを再利用した全Core逆依存53パッケージのrunは、$($counts.run)件中 $($counts.passed) PASS／$($counts.failed) FAIL／$($counts.skipped) SKIP。実テストがあるのは$(@($selected.package|Sort-Object -Unique).Count)パッケージ。CLIは$cliCount件中$($cliCount-$failed.Count) PASS／4 FAIL、非CLI $($selected.Count-$cliCount)件は全通過。5件の新registry回帰とSemaのscope権限回帰もこのrunでPASS。先行23件は合算しない。
workspace全target／全feature check／Clippy、変更13 Rust pathのfmt、構造gateは終了0。開始前にroot fixture180件を含む3,829入力を固定し、Cargo100入力を含めdrift0。旧「AWBC通常deferのFlow registryがcontext不足」という現状説明はこの実測で置換する。必須読取りの静的存在証明と、semicolonなし末尾書込みの構文条件は別境界であり、runtime受入を未完了へ戻す根拠にしない。Generic Matchと従来のNative受入を保持する。
[初回失敗・訂正理由・全コマンド・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。
"@
[IO.File]::AppendAllText('D:/git/arcweft/docs/implementation/convergence-evidence-history.md',$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$lines=[IO.File]::ReadAllLines($statusPath)
$result=foreach($line in $lines){
 if($line.StartsWith('| Flow／Line の lifetime registry と入れ子対話 |')){
  '| Flow／Line の lifetime registry と入れ子対話 | **対象機能を検証・公開済み** | Flow呼出しとLineは別のregistryを持ち、子Lineは到達した親Flowを操作する。元スロット・発行元を認証する型付き書込み、複製可能値の必須／任意読取りとOption型推論、drop、入れ子StageActor受取り、deferからの登録／置換、Cue発火前のdrop／置換／Line終了をNative／decoded AWBCで確認済み。AWBCは未発火packetと実行中fiberの所有を分け、複数解放応答と捕捉slotを保持してversion 1公開保存から再開する。順序が確定した上書きは後の型を推論し、異型が合流する分岐は拒否する。順序不確定な呼出し先の書込みからの型推論、MustDropの意味解析とverifier収集、他scope／資源への拡張は別の継続条件。重複していた旧matrix件数は履歴へ集約した。[全受入SHA・実測・訂正理由](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }elseif($line.StartsWith('| Line／init の defer とレジストリ |')){
  '| Line／init の defer とレジストリ | **Line全体とinitは検証・公開済み** | 登録直後の現在値を読める。正常initは失敗時限定の書込みを適用せず、cleanupで型が変わり得る場合は古い型の読取りを拒否する。Native／decoded AWBCを1 opずつ実行し、AWBCは毎step公開保存から復元した。Source `3b7a98a0f3983c8d45148ac4e401e29a136e082b` は、対話の登録ID frontierを巻き戻した保存を、捕捉値なしcleanupの実行待ち／実行中の両方で拒否する。旧分割runの進捗と件数は履歴へ集約し、この受入を全体goalの未達で戻さない。通常Flowとmark handlerは各専用行で追跡する。[修正前後の実測・全公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }elseif($line.StartsWith('| 通常 Flow の scoped defer |')){
  '| 通常 Flow の scoped defer | **Native の既受入境界を保持。Source／AWBC の待機・Flow registryを検証・公開済みで、全体受入は継続中** | 最新Source `'+$source.commit+'`。関数本体と明示scopeのLIFO cleanup、generic capture／戻り値、失敗後の残りのcleanup、40 ms＋60 msの待機と途中0 opを保持。追加5件で、scope・関数・入れ子cleanupから到達したFlow registryの書込み・任意読取り・型付きdrop、別キー保持、String／i64の型付き置換をNative／AWBCで検証した。AWBCは毎step version 1公開保存からcold restoreする。scope rootの権限は子キーを覆い、Unit末尾dropもcallbackの効果へ保持する。Nativeの既受入goto／Choice／関数本体は保持。AWBCのgoto／Choice、直接AWBCの開いたscopeからのreturn、取消し・Line affine捕捉、登録／子構築前の集約資源検査は継続中。必須読取りには別途静的な存在証明が必要で、semicolonなし末尾書込みのHIR recoveryも別の構文条件。旧context不足の列挙は今回の実測により置換した。[全失敗・訂正・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
  '| 共有契約／推移的逆依存matrix | **最新Core逆依存53パッケージ：'+$counts.passed+' PASS／'+$counts.failed+' FAIL／'+$counts.skipped+' SKIP** | Source `'+$source.commit+'`。Windowsのworkspace既定feature、lib／integrationを選択し、実テスト'+@($selected.package|Sort-Object -Unique).Count+'パッケージ、'+$counts.run+'件を実行した。非CLI '+($selected.Count-$cliCount)+'件は全通過。Windows1455による先行list停止2回はテスト未実行として保持し、同じ入力・構成の再試行で回復した。過去のRuntimePlan／Syntax matrixと対象23件は合算しない。[全選択・実測・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }elseif($line.StartsWith('| CLIの規定対象／全 check 照合 |')){
  '| CLIの規定対象／全 check 照合 | **workspace既定CLI '+$cliCount+'件：'+($cliCount-$failed.Count)+' PASS／4 FAIL** | Source `'+$source.commit+'`、上記Core逆依存runの内数。未解消はauthored Scrollの意味解析、必須VoiceHandleに実音声がない実行、promotion証明／solverの2件。以前の監査一覧・不正監査fixture・取消しcleanup・scalar修復もPASSを維持。完全な失敗ID・入力・診断は[実測](acceptance-evidence/task-flow-registry-execution.json)へ保持し、別Sourceの件数は履歴で区別する。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
  '| workspace check／Clippy・fmt・構造gate | **workspace全target・全feature check／Clippy、fmt、構造gateは終了0** | Source `'+$source.commit+'`。変更13 Rust pathのfmt、共有registry所有境界とscope付き効果の修復を確認した。警告・review triggerは原本に保持。Core doctest80件は該当入力不変のSource `1d60c0bcd12d0142f2eb1cc713115d495bfc5486` の結果として保持し、新runとしない。他platform／Tier2の受入へ拡張しない。[実測・全公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }else{$line}
}
[IO.File]::WriteAllText($statusPath,($result -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;counts=$counts;cli=$cliCount;entries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json -Depth 5
