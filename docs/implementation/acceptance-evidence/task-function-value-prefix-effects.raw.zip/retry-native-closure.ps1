param([Parameter(Mandatory=$true)][string]$Source)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$env:CARGO_INCREMENTAL='0'
$scratch=Join-Path $env:TEMP 'arcweft-coordinate-continuation-20261111'
$acceptance=Join-Path $scratch ('acceptance-'+$Source.Substring(0,12))
$original=Get-Content -LiteralPath (Join-Path $acceptance 'receipt.json') -Raw|ConvertFrom-Json
if(!$original.finished -or @($original.results|Where-Object exit -ne 0).Count -ne 1 -or ($original.results|Where-Object exit -ne 0).name -cne 'light-42'){throw 'Expected only the completed light-42 environmental failure'}
$directory=Join-Path $acceptance 'retry-light-42'
if(Test-Path -LiteralPath $directory){throw 'Retry receipts already exist; preserve them'}
New-Item -ItemType Directory -Path $directory|Out-Null
function Confirm-Source {if((git rev-parse HEAD) -cne $Source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned source changed'}}
Confirm-Source
$plan=[System.Collections.Generic.List[object]]::new()
function Add-Run([string]$Name,[string]$Package,[string[]]$Targets,[bool]$AllowEmpty=$false){$plan.Add([ordered]@{name=$Name;packages=@($Package);args=@('nextest','run','--locked','-p',$Package)+$Targets+@('--no-tests',$(if($AllowEmpty){'pass'}else{'fail'}),'--no-fail-fast')})}
function Add-Build([string]$Name,[string]$Target){$plan.Add([ordered]@{name=$Name;packages=@('arcweft-player-native');args=@('build','--locked','--profile','test','-p','arcweft-player-native','--bin',$Target)})}
Add-Run 'native-lib' 'arcweft-player-native' @('--lib')
Add-Build 'native-bin-build' 'arcweft-player-native'
Add-Build 'ime-bin-build' 'windows-tsf-ime-sample'
Add-Run 'native-bin-tests' 'arcweft-player-native' @('--bin','arcweft-player-native') $true
Add-Run 'ime-bin-tests' 'arcweft-player-native' @('--bin','windows-tsf-ime-sample') $true
Add-Run 'native-ingress' 'arcweft-player-native' @('--test','windowed_ingress_runtime')
Add-Run 'native-patch' 'arcweft-player-native' @('--test','windowed_live_patch_smoke')
Add-Run 'text-input-lib' 'arcweft-player-text-input' @('--lib')
Add-Run 'project-lib' 'arcweft-project' @('--lib')
Add-Run 'project-inventory' 'arcweft-project' @('--test','bytecode_link_producer_inventory')
[ordered]@{version=1;source=$Source;replacesStage='light-42';reason='Windows paging allocation error 1455 during parallel target compilation; split targets without jobs/profile overrides';stages=$plan.ToArray()}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $directory 'plan.json') -Encoding utf8NoBOM
$results=[System.Collections.Generic.List[object]]::new()
function Save-Receipt([string]$Active,[bool]$Finished){[ordered]@{version=1;source=$Source;active=$Active;finished=$Finished;results=$results.ToArray()}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $directory 'receipt.json') -Encoding utf8NoBOM}
foreach($stage in $plan){
    Confirm-Source
    Save-Receipt $stage.name $false
    $log=Join-Path $directory ($stage.name+'.log')
    $argv=$stage.args
    & cargo @argv *> $log
    $code=$LASTEXITCODE
    Confirm-Source
    $summary=@(Select-String -LiteralPath $log -Pattern '^\s*Summary .*tests? run:'|ForEach-Object {$_.Line.Trim()})
    $totals=$null
    $line=$summary|Select-Object -Last 1
    if($line -match '([\d,]+) tests? run: ([\d,]+) passed(?: \([^)]+\))?(?:, ([\d,]+) failed)?, ([\d,]+) skipped'){$totals=[ordered]@{run=[int]($Matches[1]-replace ',');pass=[int]($Matches[2]-replace ',');fail=if($Matches.ContainsKey(3)){[int]($Matches[3]-replace ',')}else{0};skip=[int]($Matches[4]-replace ',')}}
    if(!$code -and $argv[0] -ceq 'nextest' -and !$totals){$code=1}
    $results.Add([ordered]@{name=('retry-'+$stage.name);command=@('cargo')+$argv;packages=$stage.packages;exit=$code;totals=$totals;summary=$summary;log=('retry-light-42/'+$stage.name+'.log');logSha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant()})
    "$($stage.name) exit=$code $($summary -join ' | ')"
    Save-Receipt '' $false
    if($code){exit $code}
}
Save-Receipt '' $true
$resolved=@($original.results|Where-Object exit -eq 0)+$results.ToArray()
$covered=@($resolved|ForEach-Object packages|Sort-Object -Unique)
if(Compare-Object $original.packages $covered){throw 'Resolved stages do not cover the original closure'}
[ordered]@{version=1;source=$Source;packages=$original.packages;active='';finished=$true;results=$resolved;originalReceipt='receipt.json';originalReceiptSha256=(Get-FileHash -LiteralPath (Join-Path $acceptance 'receipt.json')).Hash.ToLowerInvariant();environmentRetry=@{stage='light-42';originalExit=101;originalLog='light-42.log';reason='Windows paging allocation error 1455';retryReceipt='retry-light-42/receipt.json';jobsOrProfileOverrides=$false}}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $acceptance 'resolved-acceptance.json') -Encoding utf8NoBOM
