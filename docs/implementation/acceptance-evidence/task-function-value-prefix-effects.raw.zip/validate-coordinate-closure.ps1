param([Parameter(Mandatory=$true)][string]$Source)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$env:CARGO_INCREMENTAL='0'
$scratch=Join-Path $env:TEMP 'arcweft-coordinate-continuation-20261111'
$directory=Join-Path $scratch ('acceptance-'+$Source.Substring(0,12))
if(Test-Path -LiteralPath $directory){throw 'Acceptance directory already exists; preserve its receipts'}
New-Item -ItemType Directory -Path $directory | Out-Null
$closure=(Get-Content -Raw -LiteralPath (Join-Path $scratch 'cargo-closure.json')|ConvertFrom-Json).closure.'host-metadata'
$past=(Get-Content -Raw -LiteralPath (Join-Path $env:TEMP 'arcweft-project-call-effects-20261111/reverse-split-plan.json')|ConvertFrom-Json).stages
$plan=[Collections.Generic.List[object]]::new()
$results=[Collections.Generic.List[object]]::new()
function Confirm-Source {
    if((git rev-parse HEAD) -cne $Source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned tracked source changed'}
}
function Add-Command([string]$Name,[string]$Program,[string[]]$Arguments,[string[]]$Packages=@()){
    $plan.Add([ordered]@{name=$Name;program=$Program;args=$Arguments;packages=$Packages})
}
function Add-Nextest([string]$Name,[string[]]$Packages,[string[]]$Targets){
    $flags=@($Packages|ForEach-Object {'-p';$_})
    Add-Command $Name 'cargo' (@('nextest','run','--locked')+$flags+$Targets+@('--no-tests','fail','--no-fail-fast')) $Packages
}
function Save-Receipt([string]$Active,[bool]$Finished){
    $temporary=Join-Path $directory 'receipt.pending.json'
    [ordered]@{version=1;source=$Source;packages=$closure;active=$Active;finished=$Finished;results=$results.ToArray()}|
        ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temporary -Encoding utf8NoBOM
    [IO.File]::Move($temporary,(Join-Path $directory 'receipt.json'),$true)
}
Confirm-Source
git diff --exit-code f3b67393f9ee19fb09a21c2f9b66d9b7078b3e04 HEAD -- Cargo.toml Cargo.lock ':(glob)**/Cargo.toml' .cargo rust-toolchain.toml
if($LASTEXITCODE){throw 'Cargo graph inputs changed; derive a fresh reverse graph'}
Add-Nextest 'core' @('arcweft-core') @('--lib')
Add-Nextest 'sema' @('arcweft-lang-sema') @('--lib','--tests')
Add-Nextest 'runtime-plan' @('arcweft-runtime-plan') @('--lib','--tests')
Add-Nextest 'compiler-focused' @('arcweft-compiler') @('--test','callable_execution','--test','flow_wait','--test','project_function_instances')
Add-Command 'format' 'cargo' @('fmt','--all','--','--check')
Add-Command 'workspace-check' 'cargo' @('check','--locked','--workspace','--all-targets','--all-features')
Add-Command 'workspace-clippy' 'cargo' @('clippy','--locked','--workspace','--all-targets','--all-features')
Add-Command 'structure' 'just' @('structure-audit-gate')
Add-Command 'wasm' 'cargo' @('check','--locked','--target','wasm32-unknown-unknown','-p','arcweft-player-web')
Add-Command 'docs' 'cargo' @('test','--locked','--doc','-p','arcweft-core','-p','arcweft-lang-sema','-p','arcweft-runtime-plan','-p','arcweft-compiler')
foreach($stage in $past){
    if($stage.name -ceq 'arcweft-core-lib'){continue}
    $packages=@($stage.packages|Where-Object {$_ -in $closure -and $_ -notin @('arcweft-lang-sema','arcweft-runtime-plan')})
    if(!$packages.Count){continue}
    $targets=@($stage.targets)
    if($targets[0] -ceq '--test' -and $packages -contains 'arcweft-compiler'){
        $targets=@($targets|Where-Object {$_ -cne '--test' -and $_ -notin @('callable_execution','flow_wait','project_function_instances')}|ForEach-Object {'--test';$_})
    }
    if(!$targets.Count){continue}
    if($stage.name -ceq 'arcweft-render-wgpu-integration-4'){
        $flags=@('-p','arcweft-render-wgpu')+$targets
        Add-Command 'gpu-ignored-list' 'cargo' (@('nextest','list','--locked')+$flags+@('--message-format','json'))
        Add-Command $stage.name 'cargo' (@('nextest','run','--locked')+$flags+@('--no-tests','pass','--no-fail-fast')) $packages
    } else {
        Add-Nextest $stage.name $packages $targets
    }
}
Add-Command 'cli-build' 'cargo' @('build','--locked','--profile','test','-p','arcweft-cli','--bin','arcw')
Add-Nextest 'cli-lib-bins' @('arcweft-cli') @('--lib','--bins')
Add-Nextest 'cli-integration' @('arcweft-cli') @('--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')
$selected=@($plan|ForEach-Object {$_.packages}|Sort-Object -Unique)
if(Compare-Object $closure $selected){throw 'Split test plan does not cover the complete resolved closure'}
[ordered]@{version=1;source=$Source;graphSource='f3b67393f9ee19fb09a21c2f9b66d9b7078b3e04';packages=$closure;stages=$plan.ToArray()}|
    ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $directory 'plan.json') -Encoding utf8NoBOM
foreach($stage in $plan){
    Confirm-Source
    Save-Receipt $stage.name $false
    $log=Join-Path $directory ($stage.name+'.log')
    $program=$stage.program
    $argv=$stage.args
    if($stage.name -ceq 'gpu-ignored-list'){
        & $program @argv 1> $log 2> (Join-Path $directory 'gpu-ignored-list.stderr')
    } else { & $program @argv *> $log }
    $code=$LASTEXITCODE
    Confirm-Source
    if($stage.name -ceq 'gpu-ignored-list' -and !$code){
        $listing=Get-Content -Raw -LiteralPath $log|ConvertFrom-Json -AsHashtable
        $cases=@($listing['rust-suites'].Values|ForEach-Object {$_['testcases'].Values})
        if($cases.Count -ne 3 -or @($cases|Where-Object {!$_.ignored}).Count){throw 'Unexpected GPU ignored selection'}
    }
    $summary=@(Select-String -LiteralPath $log -Pattern '^\s*Summary .*tests? run:|^test result:'|ForEach-Object {$_.Line.Trim()})
    $totals=$null
    $line=$summary|Where-Object {$_ -like 'Summary *'}|Select-Object -Last 1
    if($line -match '([\d,]+) tests? run: ([\d,]+) passed(?: \([^)]+\))?(?:, ([\d,]+) failed)?, ([\d,]+) skipped'){
        $totals=[ordered]@{run=[int]($Matches[1]-replace ',');pass=[int]($Matches[2]-replace ',');fail=if($Matches.ContainsKey(3)){[int]($Matches[3]-replace ',')}else{0};skip=[int]($Matches[4]-replace ',')}
    }
    if($stage.args[0] -ceq 'nextest' -and $stage.args[1] -ceq 'run' -and !$totals -and !$code){$code=1}
    $free=(Get-PSDrive D).Free
    $results.Add([ordered]@{name=$stage.name;command=@($stage.program)+$stage.args;packages=$stage.packages;exit=$code;totals=$totals;summary=$summary;log=(Split-Path $log -Leaf);logSha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant();freeBytes=$free})
    "$($stage.name) exit=$code $($summary -join ' | ')"
    Save-Receipt '' $false
    if($code -ne 0 -and $stage.name -in @('core','sema','runtime-plan','compiler-focused')){exit $code}
    if($free -lt 40GB){throw 'Insufficient free space for another build'}
}
Save-Receipt '' $true
if(@($results|Where-Object exit -ne 0).Count){exit 1}
