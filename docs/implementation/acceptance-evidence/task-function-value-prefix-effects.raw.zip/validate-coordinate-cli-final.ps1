param([Parameter(Mandatory=$true)][string]$Source)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$env:CARGO_INCREMENTAL='0'
$scratch=Join-Path $env:TEMP 'arcweft-coordinate-continuation-20261111'
$directory=Join-Path $scratch ('acceptance-'+$Source.Substring(0,12)+'/cli-probes-final')
if(Test-Path -LiteralPath $directory){throw 'CLI probe directory already exists; preserve its receipts'}
New-Item -ItemType Directory -Path $directory | Out-Null
$binary=(Resolve-Path 'target/debug/arcw.exe').Path
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path).Hash.ToLowerInvariant()}
$binaryHash=Hash $binary
function Confirm-Source {
    if((git rev-parse HEAD) -cne $Source -or (git diff --name-only) -or (git diff --cached --name-only) -or (Hash $binary) -cne $binaryHash){throw 'Pinned source or executable changed'}
}
Confirm-Source
$cases=[ordered]@{}
$cases['same-group-effects']=@{logs=@('prefix','effectful');source=@'
entry cli @entry.main { goto @flow.main }
fn invoke(seed: i64, callback: i64 -> i64) -> i64 { callback(seed) }
flow main() -> i64 {
    let function = invoke
    let tail = function({ log.info("prefix"); 21i64 })
    let first = tail(|value| { log.info("effectful"); value })
    return tail(|value| value) + first
}
'@}
$cases['later-group-prefix-effects']=@{logs=@('prefix','middle','effectful');source=@'
entry cli @entry.main { goto @flow.main }
fn invoke(seed: i64)(left: i64, right: i64)(callback: i64 -> i64) -> i64 {
    callback(seed + left + right)
}
flow main() -> i64 {
    let function = invoke
    let group = function({ log.info("prefix"); 18i64 })
    let middle = group({ log.info("middle"); 1i64 })
    let tail = middle(2i64)
    let first = tail(|value| { log.info("effectful"); value })
    return tail(|value| value) + first
}
'@}
$cases['widened-local-contract']=@{logs=@('prefix');source=@'
entry cli @entry.main { goto @flow.main }
flow main() -> i64 {
    let add: (i64, i64) -> i64 effects { log.write } = |a: i64, b: i64| a + b
    let tail = add({ log.info("prefix"); 40i64 })
    return add(40i64, 2i64) + tail(2i64) - 42i64
}
'@}
$cases['inferred-returned-effects']=@{logs=@('prefix','body','body');source=@'
entry cli @entry.main { goto @flow.main }
fn add(first: i64, second: i64) -> i64 { log.info("body"); first + second }
fn direct(seed: i64) -> i64 -> i64 { add(seed) }
fn indirect(seed: i64) -> i64 -> i64 { let function = add; function(seed) }
flow main() -> i64 {
    let first = direct({ log.info("prefix"); 40i64 })
    let second = indirect(40i64)
    return first(2i64) + second(2i64) - 42i64
}
'@}
$cases['independent-later-types']=@{logs=@('prefix','body','body');source=@'
entry cli @entry.main { goto @flow.main }
fn keep<T>(seed: i64, value: T) -> i64 { log.info("body"); seed }
flow main() -> i64 {
    let function = keep
    let tail = function({ log.info("prefix"); 21i64 })
    let first = tail("later")
    return tail(true) + first
}
'@}
$cases['generic-return-annotation']=@{logs=@('prefix');source=@'
entry cli @entry.main { goto @flow.main }
fn keep<T>(seed: i64, value: T) -> i64 { seed }
fn direct(seed: i64) -> String -> i64 { keep(seed) }
fn indirect(seed: i64) -> bool -> i64 { let function = keep; function(seed) }
flow main() -> i64 {
    let first = direct({ log.info("prefix"); 21i64 })
    let second = indirect(21i64)
    return first("later") + second(true)
}
'@}
$results=[Collections.Generic.List[object]]::new()
foreach($name in $cases.Keys){
    $case=$cases[$name]
    $fixturePath=Join-Path $directory ($name+'.arcw')
    $case.source | Set-Content -LiteralPath $fixturePath -Encoding utf8NoBOM
    foreach($executor in @('bytecode-vm','aot','awbc-product')){
        Confirm-Source
        $output=Join-Path $directory ("$name.$executor.json")
        $stderr=Join-Path $directory ("$name.$executor.stderr")
        $argv=@('run',$fixturePath,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','512','--json')
        & $binary @argv 1> $output 2> $stderr
        $code=$LASTEXITCODE
        $report=$null
        $parseError=$null
        try {$report=Get-Content -Raw -LiteralPath $output|ConvertFrom-Json -AsHashtable} catch {$parseError=$_.Exception.Message}
        $logs=if($report -and $report.steps.Count){@($report.steps[-1].observations.logs|ForEach-Object {$_.message})}else{@()}
        $max=if($report){($report.steps|ForEach-Object {$_.stats.executed_ops}|Measure-Object -Maximum).Maximum}else{$null}
        $violations=if($report){@($report.steps|Where-Object {$_.diagnostics.Count -or $_.assertion_failures.Count -or $_.assertion_diagnostics.Count})}else{@()}
        $ok=$code -eq 0 -and !$parseError -and $report.final_status -ceq 'done Return("42")' -and $max -eq 1 -and ($logs -join '|') -ceq ($case.logs -join '|') -and !$violations.Count -and !$report.diagnostics.Count -and !(Get-Item -LiteralPath $stderr).Length
        $results.Add([ordered]@{name=$name;executor=$executor;command=$argv;exit=$code;status=$report.final_status;stage=$report.stage;steps=$report.steps.Count;maxOps=$max;logs=$logs;diagnostics=$report.diagnostics;violations=$violations.Count;parseError=$parseError;input=(Split-Path $fixturePath -Leaf);inputSha256=Hash $fixturePath;reportSha256=Hash $output;verified=$ok})
        "$name $executor exit=$code status=$($report.final_status) max=$max logs=$($logs -join ',') verified=$ok"
    }
}
Confirm-Source
[ordered]@{version=1;source=$Source;binarySha256=$binaryHash;executions=$results.ToArray()}|
    ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $directory 'receipt.json') -Encoding utf8NoBOM
if(@($results|Where-Object {!$_.verified}).Count){exit 1}
