param([Parameter(Mandatory=$true)][string]$Source)
$ErrorActionPreference='Stop'
$scratch=Join-Path $env:TEMP 'arcweft-coordinate-continuation-20261111'
$acceptance=Join-Path $scratch ('acceptance-'+$Source.Substring(0,12))
$receiptPath=Join-Path $acceptance 'resolved-acceptance.json'
if(!(Test-Path -LiteralPath $receiptPath)){$receiptPath=Join-Path $acceptance 'receipt.json'}
$receipt=Get-Content -LiteralPath $receiptPath -Raw|ConvertFrom-Json
if($receipt.originalReceipt -and (Get-FileHash -LiteralPath (Join-Path $acceptance $receipt.originalReceipt)).Hash.ToLowerInvariant() -cne $receipt.originalReceiptSha256){throw 'Original failed receipt changed'}
if(!$receipt.finished -or @($receipt.results|Where-Object exit -ne 0).Count){throw 'Full acceptance has not passed'}
foreach($result in $receipt.results){
    if((Get-FileHash -LiteralPath (Join-Path $acceptance $result.log)).Hash.ToLowerInvariant() -cne $result.logSha256){throw ('Acceptance log changed: '+$result.name)}
}
if((git rev-parse HEAD) -cne $Source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned source has changed'}
$cliPath=Join-Path $acceptance 'cli-probes-final/receipt.json'
if(!(Test-Path -LiteralPath $cliPath)){$cliPath=Join-Path $acceptance 'cli-probes/receipt.json'}
$cli=Get-Content -LiteralPath $cliPath -Raw|ConvertFrom-Json
if($cli.executions.Count -ne 18 -or @($cli.executions|Where-Object {!$_.verified}).Count){throw 'CLI acceptance has not passed'}
if((Get-FileHash -LiteralPath 'target/debug/arcw.exe').Hash.ToLowerInvariant() -cne $cli.binarySha256){throw 'CLI executable differs from executed acceptance input'}
$previous=@('task-within-group-generic-prefix-foundation.raw.zip','task-within-group-generic-prefix-composition.raw.zip')
$previousHashes=@{}
$sha=[System.Security.Cryptography.SHA256]::Create()
foreach($name in $previous){
    $zip=[System.IO.Compression.ZipFile]::OpenRead((Join-Path 'docs/implementation/acceptance-evidence' $name))
    try{foreach($entry in $zip.Entries){
        $stream=$entry.Open()
        try{$digest=[Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        $previousHashes[$entry.FullName]=$digest
    }}finally{$zip.Dispose()}
}
$files=@()
$excluded=@()
foreach($file in Get-ChildItem -LiteralPath $scratch -File | Sort-Object Name){
    if($file.Name -in @('history.base.exact.md','history.base.md','final-evidence-manifest.json','function-value-effects.raw.zip','function-value-effects.archive.json')){continue}
    $digest=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()
    if($previousHashes.ContainsKey($file.Name) -and $previousHashes[$file.Name] -ceq $digest){$excluded+=@{path=$file.Name;sha256=$digest};continue}
    $files+=@{path=$file.Name;source=$file.FullName;bytes=$file.Length;sha256=$digest}
}
foreach($file in Get-ChildItem -LiteralPath $acceptance -File -Recurse|Sort-Object FullName){
    $relative=[System.IO.Path]::GetRelativePath($scratch,$file.FullName).Replace('\','/')
    $files+=@{path=$relative;source=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
}
$manifestPath=Join-Path $scratch 'final-evidence-manifest.json'
[ordered]@{version=1;source=$Source;tree=(git rev-parse "$Source^{tree}");previousArchives=$previous;excludedUnchanged=$excluded;files=@($files|ForEach-Object{[ordered]@{path=$_.path;bytes=$_.bytes;sha256=$_.sha256}})}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $manifestPath -Encoding utf8NoBOM
$files+=@{path='final-evidence-manifest.json';source=$manifestPath;bytes=(Get-Item -LiteralPath $manifestPath).Length;sha256=(Get-FileHash -LiteralPath $manifestPath).Hash.ToLowerInvariant()}
$destination=Join-Path $scratch 'function-value-effects.raw.zip'
if(Test-Path -LiteralPath $destination){throw 'Archive already exists; preserve it'}
$archive=[System.IO.Compression.ZipFile]::Open($destination,[System.IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.source,$file.path,[System.IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$archive.Dispose()}
$read=[System.IO.Compression.ZipFile]::OpenRead($destination)
try{
    if($read.Entries.Count -ne $files.Count){throw 'Archive entry count mismatch'}
    foreach($file in $files){$entry=$read.GetEntry($file.path);$stream=$entry.Open();try{$digest=[Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($digest -cne $file.sha256 -or $entry.Length -ne $file.bytes){throw ('Archive verification failed: '+$file.path)}}
}finally{$read.Dispose();$sha.Dispose()}
[ordered]@{version=1;source=$Source;archive=$destination;files=$files.Count;uncompressedBytes=($files.bytes|Measure-Object -Sum).Sum;bytes=(Get-Item -LiteralPath $destination).Length;sha256=(Get-FileHash -LiteralPath $destination).Hash.ToLowerInvariant();previousUnchangedExcluded=$excluded.Count}|ConvertTo-Json|Tee-Object -FilePath (Join-Path $scratch 'function-value-effects.archive.json')
