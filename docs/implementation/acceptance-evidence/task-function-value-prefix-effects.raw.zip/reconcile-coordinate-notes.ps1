param([Parameter(Mandatory=$true)][string]$Source)
$ErrorActionPreference='Stop'
$scratch=Join-Path $env:TEMP 'arcweft-coordinate-continuation-20261111'
$directory=Join-Path $scratch ('acceptance-'+$Source.Substring(0,12))
$receiptPath=Join-Path $directory 'resolved-acceptance.json'
if(!(Test-Path -LiteralPath $receiptPath)){$receiptPath=Join-Path $directory 'receipt.json'}
$r=Get-Content -LiteralPath $receiptPath -Raw|ConvertFrom-Json
$cliPath=Join-Path $directory 'cli-probes-final/receipt.json'
if(!(Test-Path -LiteralPath $cliPath)){$cliPath=Join-Path $directory 'cli-probes/receipt.json'}
$cli=Get-Content -LiteralPath $cliPath -Raw|ConvertFrom-Json
$a=Get-Content -LiteralPath (Join-Path $scratch 'function-value-effects.archive.json') -Raw|ConvertFrom-Json
if(!$r.finished -or @($r.results|Where-Object exit -ne 0).Count -or $cli.executions.Count -ne 18 -or @($cli.executions|Where-Object {!$_.verified}).Count){throw 'Acceptance is not complete'}
if((git rev-parse HEAD) -cne $Source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned source changed'}
$passed=[int]($r.results.totals.pass|Measure-Object -Sum).Sum
$skipped=[int]($r.results.totals.skip|Measure-Object -Sum).Sum
$values=[ordered]@{'{{SOURCE}}'=$Source;'{{PASS}}'="$passed";'{{SKIP}}'="$skipped";'{{STAGES}}'="$($r.results.Count)";'{{BINARY}}'=$cli.binarySha256;'{{FILES}}'="$($a.files)";'{{ZIPBYTES}}'="$($a.bytes)";'{{RAWBYTES}}'="$($a.uncompressedBytes)";'{{ARCHIVE}}'=$a.sha256}
function Expand([string]$Value){foreach($key in $values.Keys){$Value=$Value.Replace($key,$values[$key])};$Value}
$encoding=[System.Text.UTF8Encoding]::new($false)
$specPath=(Resolve-Path 'docs/01-language/functions-and-pipeline.md').Path
$spec=[System.IO.File]::ReadAllText($specPath)
$anchor='引数宣言の戻り値型を使い、関数値は元の呼び出し状態と捕捉値を保持する。'
if([regex]::Matches($spec,[regex]::Escape($anchor)).Count -ne 1){throw 'Expected one callable annotation specification anchor'}
$addition=@'


ローカル束縛の関数型注釈にも同じ効果の包含関係を用いる。注釈の許容効果を
広げても、保持済みの引数や実際の関数値の呼び出し状態は置き換えない。

戻り値に注釈した関数型の省略された effect row は、返す関数値の型推論を
終えてから、実際の効果行で補う。既知の型、配列長、明示された効果行の
制約は照合する。注釈での省略を理由に、推論未完了の効果行を受理しない。
'@
$spec=$spec.Replace($anchor,$anchor+$addition)
$statusPath=(Resolve-Path 'docs/implementation/current-status.md').Path
$status=[System.IO.File]::ReadAllText($statusPath)
$matchRow=[regex]::Matches($status,'(?m)^\| Generic Match [^\r\n]*')
if($matchRow.Count -ne 1){throw 'Expected exactly one accepted Generic Match row'}
$beforeMatch=$matchRow[0].Value
$header=Expand '確認日 2026-11-11。この更新の基点の `main` と `origin/main` は `{{SOURCE}}` で一致した。検証時のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 `%SystemDrive%/` を保持した。'
$headerPattern=[regex]::new('(?m)^確認日[^\r\n]*')
if($headerPattern.Matches($status).Count -ne 1){throw 'Expected one status header'}
$status=$headerPattern.Replace($status,[System.Text.RegularExpressions.MatchEvaluator]{param($m)$header},1)
$row=Expand '| 同一グループ内の部分適用 | **宣言・関数値の固定位置prefix、後段の型・効果推論を検証・公開済み** | Source `{{SOURCE}}`。先頭引数を一度だけ保持し、同じ継続の残りの型とcallback効果を各適用で独立に決める。先頭・途中での型確定、反復適用、後続の宣言グループ、異なる保持型から同じ残りの関数型になる文脈を維持する。新たにcallbackの省略効果行、3段の宣言グループの途中prefix、広い効果行のローカル型注釈、省略効果行を持つ関数型の戻り値をNative／AWBCで確認した。待機後の継続とAWBC各ステップの公開JSON保存・復元も通過。関連3バイナリー417件は全件成功。推移的逆依存52パッケージの既定feature検証は{{PASS}}件成功・0件失敗・{{SKIP}}件skipで、CLIは規定の6統合対象を含む。全target・全featureのworkspace check／Clippy、Wasm、所有doctest 82件、整形・構造ゲートは終了0。実CLIは6入力をVM／AOT／AWBC Productで18回実行し、各ステップ最大1操作、期待ログと戻り値42を確認した。以前のcallback・広い効果型・戻り値注釈の失敗記述は同じ入力の成功に基づき訂正した。[仕様](../01-language/functions-and-pipeline.md#spread-arguments-in-partials-and-staged-application)・[実測・訂正理由・全SHA](convergence-evidence-history.md#function-value-prefix-effects-and-result-annotations)・[原本](acceptance-evidence/task-function-value-prefix-effects.raw.zip)。 |'
$rowPattern=[regex]::new('(?m)^\| 同一グループ内の部分適用 [^\r\n]*')
if($rowPattern.Matches($status).Count -ne 1){throw 'Expected one partial application row'}
$status=$rowPattern.Replace($status,[System.Text.RegularExpressions.MatchEvaluator]{param($m)$row},1)
if([regex]::Match($status,'(?m)^\| Generic Match [^\r\n]*').Value -cne $beforeMatch){throw 'Accepted Generic Match row changed'}
$historyPath=(Resolve-Path 'docs/implementation/convergence-evidence-history.md').Path
$historyBefore=[System.IO.File]::ReadAllBytes($historyPath)
if([System.IO.File]::ReadAllText($historyPath).Contains('### Function value prefix effects and result annotations')){throw 'Evidence section already exists'}
$history=Expand @'



### Function value prefix effects and result annotations

2026-11-11、基点 `e5b23e01e3ddae8ffe1cdd78b63dfb3030cf8f84` から既存の `main` で継続した。最終検証Sourceは `{{SOURCE}}`、tree `c481e15906835b7a312ddbbc38e5d2dcfa02700a`。検証前後のtracked差分は0件で、既存の未追跡 `%SystemDrive%/` を保持した。全体の `cargo clean` は前節の実行を再利用し、繰り返していない。Cargoは `CARGO_INCREMENTAL=0`、jobsやprofileの上書きなしで実行した。実行バイナリー生成には既存の `--profile test` を用いた。

Supersedes: 現状一覧の「403件中401件成功・callback効果2件失敗」と、広いローカル効果型・戻り値効果省略の再検証待ちという現在形を、以下の同一入力の成功に基づき置換した。先行節の実結果とfull SHAは当時の履歴として保持する。Generic Matchの受入行は同じ内容を維持し、別境界や全体goalの未達による再開は行わない。

Source `8c6b5ec5c5ee5ca473b5231c6d98ce216f6090c7` では、lexical callable identityが単独の非scoped効果行でなく、binderを含む関数型全体を保持する。generic slotの最初の使用を引数座標・呼出し・結果で区別し、呼出しでしか使わない効果をprefix生成時に確定しない。直接／関数値、全／部分適用、curried、明示効果、genericの7種類の行列を追加した。対象4件は3件成功・1件失敗。Sema、Compilerの関連3バイナリーとライブラリの2,043件は2,042件成功・1件失敗で、残りはcurried関数値のCopy判定だった。Compilerの全target checkと所有3クレートの全target Clippyは終了0、警告あり。対象が重複するため両runを合算しない。

Source `fa43eafae48e2ee83b71061c26cf334fde70418a` では、Copy判定が検査済みproducerと宣言groupの位置をたどり、途中groupの保持値を無視して関数型だけからCopyとしない。VoiceHandleを保持したprefixの再使用を拒否する回帰も加えた。Coreの特殊化codecは、検証と同じ残存結果binderの規則で引数の効果frameを保持する。広いローカル型の選択はbindingの検査済みinterfaceを使い、元の実行値を保持する。仕様のgenericと効果の説明を同一groupの残り引数へ広げた。初回対象9件は6件成功・3件失敗で、行列の宣言間改行漏れはfixtureの誤りとして訂正した。codecの旧test helper参照によるcompile失敗も修復した。後続対象23件は18件成功・5件失敗。curriedのNative／AWBCとcodecは成功し、広いローカル型と戻り値注釈は下流の拒否が残った。このSourceのCoreライブラリ2,351件は全件成功したが、最終Sourceでは下記の全件を別に再実行した。

Source `1be007cb97ae930fdf954efa9f53f24fe9b8a71a` では、Coreの代入とAWBCのbinding patternで既存の関数引数と同じ型適合を使い、AWBC検査は既存の累積step予算を共有する。Semaは省略効果行を持つ期待結果型だけを遅延するequationとして区別し、実際の戻り値の推論を待ってから効果行を埋め、厳密に照合する。未知のsource効果を受け入れない。純粋／log効果、source型の推論待ち、未知のsource行と型・効果・配列長不一致の拒否を回帰で確認した。対象18件は12件成功・6件失敗。広いローカル型の全／部分適用、callback行列、curried、待機prefixは成功した。残る6件は関数値専用の結果経路が通常のequationを通らず、型検査の `UnknownRow` が残った。入力patch SHA-256は `59b419c94ca1ee923eb067e69facc9090abd8880cefd570953dfc39566932861`。

Source `{{SOURCE}}` では、関数値専用の結果制約にも同じ遅延分類を適用した。型検査後の未知行は、元の宣言signatureでなく検査済みresult schemaを使い、終端の効果と推論済み戻り値を一つのtyped interfaceとして投影することで解消した。Compilerの元関数インスタンスも検査済み戻り値ABIを登録し、pendingな投影は構造化エラーで拒否する。終端interfaceの投影修復直後の対象9件は全件成功した。その後、pending分岐を明示的なmatchへ整えた公開Sourceで、所有4クレートの全target Clippyは終了0、警告あり。最終Sourceの全体runにも同じ9 IDが含まれ、全件成功した。全4 Sourceは通常のfast-forward pushとfetchを行い、remote mainのfull SHAとtreeを照合した。ユーザーの途中commit方針に従い、修復途中の失敗を隠さず各cutを公開した。

初回76段階の `light-42` は、Player Native／Player Text Input／Projectのテスト開始前に終了101となった。原因はWindowsのページング領域不足（OS error 1455）によるrlibのmmap失敗で、ソース不具合とは区別する。初回receiptとログは改変せず保持し、同じSourceで対象のlib・bin・統合テストを10段階へ細分して再実行した。jobs・profileの上書き、OS設定変更、artifactの退避は行っていない。以下の集計は初回の成功75段階と再実行の成功10段階で、コンパイル停止した初回に実行テストはない。

最終Sourceを固定して{{STAGES}}段階を終端まで実行した。Cargo metadataとtreeによるホスト52パッケージの推移的逆依存を、既定featureで{{PASS}}件成功・0件失敗・{{SKIP}}件skipまで検証した。先行Sourceの成功を混ぜた合算ではない。全ターゲットのグラフはrender-webを加えた53パッケージで、別途Web PlayerをWasm checkした。Cargo入力の差分0を照合し、グラフのSource `f3b67393f9ee19fb09a21c2f9b66d9b7078b3e04` を再利用した。Coreライブラリ2,351件、Sema 1,476件、RuntimePlan 165件とskip 1件、Compiler関連3バイナリー417件は最終Sourceの直接再実行で、上の全体件数に含む。CLIはlib／binと規定の統合6対象を実行した。全target・全featureのworkspace check／Clippy、整形、構造ゲート、Wasm、所有4クレートのdoctest 82件は終了0。Clippyには警告がある。ignored対象の実行や実ブラウザー描画を今回の通過に含めない。

初回の実CLIも同じ6入力・18実行が成功し、実行ファイルSHA-256 `69c0f8087fcffd96185cb12b0477781ac8f75802869179166130303a2f73e79e` の結果を保持した。規定CLI統合ビルド後に実行ファイルのhashが変わったため、同じ入力を最終バイナリーで再実行した。重複する18実行を合算しない。最終Sourceの実CLIはSHA-256 `{{BINARY}}`。6入力をBytecode VM／AOT／AWBC Productで18回実行し、すべて戻り値42、最大1操作、期待ログ、診断とassertion違反0を確認した。同一groupのcallback効果、3段宣言の途中prefix、広いローカル型、関数型の戻り値の効果省略、共有継続の独立型、戻り値の期待型で後段genericを確定する直接／変数経由を含む。保持prefixは再評価されず、純粋／効果付きcallbackの反復も期待順だった。Native／AWBCの待機回帰では100 msを40 msと60 msに分け、AWBCは各stepで公開JSON保存・復元を行う。

構造ゲートはブロッキング違反0件。既存ownerの検査済み適用の封印とidentity、generic引数inventory、結果制約frontier、累積予算付きAWBC検証、Compiler投影contextを維持した。新しいcrate依存、unsafe、I/O、互換reader、並列の型authorityはない。大きいownerの実測はchecked_application 185,846 bytes／4,958行、schema 182,733 bytes／4,925行（内test 1,250行）、constraint transaction 94,007 bytes／2,471行、AWBC verifier 286,736 bytes／7,324行、Compiler lower 460,878 bytes／10,794行。Cargoのdev／buildを含むworkspace直接fan-in／outはCore 34／13、Sema 12／15、Compiler 5／35で、依存edgeの追加はない。行数だけで分割せず、上記typed責務でcohesionを判断した。

初回失敗、fixture誤り、compileエラー、診断trace、パッチ、公開receipt、最終コマンド・Source・ログhashとCLI入力／出力を原本へ保持した。一時instrumentationは最終Sourceから除去した。広い型の探索中に入力変更が重なったrunは診断資料であり、確定Sourceの受入に数えない。前2原本と同じ内容のファイルを除き、今回の原本は{{FILES}}件、展開時{{RAWBYTES}} bytes、ZIP {{ZIPBYTES}} bytes、SHA-256 `{{ARCHIVE}}`。[検証原本](acceptance-evidence/task-function-value-prefix-effects.raw.zip)。既存の履歴本文と前2原本は変更せず、現状は一か所の一覧に集約した。
'@
$history += [Environment]::NewLine
[System.IO.File]::WriteAllText($statusPath,$status,$encoding)
[System.IO.File]::WriteAllText($specPath,$spec,$encoding)
[System.IO.File]::AppendAllText($historyPath,$history,$encoding)
$historyAfter=[System.IO.File]::ReadAllBytes($historyPath)
$sha=[System.Security.Cryptography.SHA256]::Create()
try{if([Convert]::ToHexString($sha.ComputeHash($historyBefore)) -cne [Convert]::ToHexString($sha.ComputeHash($historyAfter,0,$historyBefore.Length))){throw 'Historical evidence prefix changed'}}finally{$sha.Dispose()}
$destination=Join-Path (Resolve-Path 'docs/implementation/acceptance-evidence').Path 'task-function-value-prefix-effects.raw.zip'
if(Test-Path -LiteralPath $destination){throw 'Published archive destination already exists'}
Copy-Item -LiteralPath $a.archive -Destination $destination
if((Get-FileHash -LiteralPath $destination).Hash.ToLowerInvariant() -cne $a.sha256){throw 'Copied archive hash mismatch'}
[ordered]@{version=1;source=$Source;nextestPass=$passed;nextestSkip=$skipped;cliExecutions=$cli.executions.Count;genericMatchUnchanged=$true;archiveSha256=$a.sha256}|ConvertTo-Json
