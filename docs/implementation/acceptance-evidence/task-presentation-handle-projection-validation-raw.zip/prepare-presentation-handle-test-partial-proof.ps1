$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskT/convergence-image-git-bytes.ps1"
$base=(git rev-parse HEAD).Trim()
if($base -ne 'a08206261463c06c905ebdfa1c551da8d89d7f2f'){throw 'Unexpected source base'}
if(@(git diff --cached --name-only).Count){throw 'Index is not empty'}
$baseline=Get-Content -LiteralPath "$taskT/checkpoint-task-view.source-freeze.json" -Raw|ConvertFrom-Json
$prior=Get-Content -LiteralPath "$taskT/task-dialogue-prefix.cli-preservation-proof.json" -Raw|ConvertFrom-Json -Depth 30
$path=$prior.path
foreach($held in $baseline.held|Where-Object {$_ -ne $path}){if((git hash-object -- $held).Trim() -ne $prior.expectedHeldBlobs.PSObject.Properties[$held].Value){throw ('Other held source changed: '+$held)}}
$oldBytes=Read-GitBytes @('show',($base+':'+$path))
$old=[Text.Encoding]::UTF8.GetString($oldBytes)
$new=$old
foreach($pair in @(@('assert_eq!(json["compiler"]["semantic"]["types"], 7);','assert_eq!(json["compiler"]["semantic"]["types"], 5);'),@('assert_eq!(json["compiler"]["semantic"]["types"], 10);','assert_eq!(json["compiler"]["semantic"]["types"], 6);'))){
 if(([regex]::Matches($new,[regex]::Escape($pair[0]))).Count -ne 1){throw 'Metric source is not unique'}
 $new=$new.Replace($pair[0],$pair[1])
}
$codeFile="$taskT/presentation-handle-contract.cli-head-after.rs"
[IO.File]::WriteAllText($codeFile,$new,[Text.UTF8Encoding]::new($false))
$codeBlob=(git hash-object -w ('--path='+$path) -- $codeFile).Trim()
$workingBlob=(git hash-object -- $path).Trim()
$oracle="$taskT/presentation-handle-contract.oracle-$([Guid]::NewGuid().ToString('N')).index"
$savedIndex=$env:GIT_INDEX_FILE
try{
 $env:GIT_INDEX_FILE=$oracle
 git read-tree $base
 if($LASTEXITCODE -ne 0){throw 'Oracle initialization failed'}
 git update-index --cacheinfo ('100644,'+$codeBlob+','+$path)
 if($LASTEXITCODE -ne 0){throw 'Oracle source staging failed'}
 $residual=Read-GitBytes (@('diff','--binary','--full-index','--')+$baseline.held)
 [IO.File]::WriteAllBytes("$taskT/presentation-handle-contract.expected-residual-wip.patch",$residual)
 git apply --cached --whitespace=nowarn "$taskT/task-dialogue-prefix.original-user.patch"
 if($LASTEXITCODE -ne 0){throw 'Exact original user patch no longer applies'}
 $reconstructed=(git rev-parse (':'+$path)).Trim()
 if($reconstructed -ne $workingBlob){throw 'Original user patch did not reconstruct actual source'}
}finally{$env:GIT_INDEX_FILE=$savedIndex}
$heldBlobs=[ordered]@{}
foreach($held in $baseline.held){$heldBlobs[$held]=(git hash-object -- $held).Trim()}
$proof=[ordered]@{version=1;base=$base;path=$path;priorProof='task-dialogue-prefix.cli-preservation-proof.json';priorProofSha256=(Get-FileHash -LiteralPath "$taskT/task-dialogue-prefix.cli-preservation-proof.json").Hash.ToLowerInvariant();originalWipPatchSha256=$baseline.heldPatchSha256;expectedResidualWipPatchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($residual)).ToLowerInvariant();originalUserPatchPreserved=$true;heldCanonicalBlobDrift=0;stagedCodeBlob=$codeBlob;workingBlob=$workingBlob;expectedHeldBlobs=$heldBlobs;codeFile=$codeFile;oracleIndex=$oracle;originalUserPatch='The immutable original system-info 8-to-32 user patch applied to the new canonical test source in an alternate Git index reconstructs the actual working blob. All other 13 held blobs are unchanged.';at=[DateTime]::UtcNow.ToString('o')}
$proof|ConvertTo-Json -Depth 15|Set-Content -LiteralPath "$taskT/presentation-handle-contract.cli-preservation-proof.json" -Encoding utf8
$prepare=[IO.File]::ReadAllText("$taskT/checkpoint-dialogue-prefix-prepare.ps1").Replace('task-dialogue-prefix.cli-preservation-proof.json','presentation-handle-contract.cli-preservation-proof.json').Replace('task-dialogue-prefix.cli-head-after.rs','presentation-handle-contract.cli-head-after.rs')
[IO.File]::WriteAllText("$taskT/checkpoint-presentation-handle-contract-prepare.ps1",$prepare,[Text.UTF8Encoding]::new($false))
$proof|Select-Object base,stagedCodeBlob,workingBlob,originalWipPatchSha256,expectedResidualWipPatchSha256,originalUserPatchPreserved|ConvertTo-Json -Compress
