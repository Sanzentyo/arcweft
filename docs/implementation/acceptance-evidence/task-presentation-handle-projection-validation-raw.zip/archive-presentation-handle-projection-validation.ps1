$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$arcTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$arcTemp/assert-no-arcweft-build.ps1"
$arcSource='a08206261463c06c905ebdfa1c551da8d89d7f2f'
$arcRepairSource=(git rev-parse HEAD).Trim()
$arcRepairPublication=Get-Content -LiteralPath "$arcTemp/checkpoint-presentation-thread-publication-fixture.verified.json" -Raw|ConvertFrom-Json
if($arcRepairSource -ne $arcRepairPublication.commit){throw 'Final test repair source changed'}
$arcQuality=[IO.File]::ReadAllText("$arcTemp/product-execution-quality.active.txt").Trim()
function Read-Record([string]$name) {Get-Content -LiteralPath "$arcTemp/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$arcFreeze=Read-Record "$arcQuality.source-freeze"
$arcRepairFreeze=Read-Record 'presentation-handle-contract-cli-repair2-20261101.source-freeze'
foreach($arcRow in $arcRepairFreeze.paths){if((Get-FileHash -LiteralPath $arcRow.path).Hash.ToLowerInvariant() -ne $arcRow.sha256){throw ('Repair input differs: '+$arcRow.path)}}
$arcReconciliation=Read-Record 'presentation-handle-contract-repair-reconciliation'
if($arcReconciliation.repairCommit -ne $arcRepairSource -or $arcReconciliation.changedTestInputs.Count -ne 4 -or $arcReconciliation.reconciledNormal.unresolvedFailures -ne 0 -or $arcReconciliation.reconciledAllCli.unresolvedFailures -ne 43){throw 'Exact-case repair reconciliation is incomplete'}
$arcNormal='presentation-handle-projection-reverse-20261101'
$arcExtra='presentation-handle-projection-full-cli-20261101'
$arcMatrix=Read-Record "$arcNormal.matrix"
$arcCliMatrix=Read-Record "$arcExtra.matrix"
$arcGeneric=Read-Record "$arcNormal.generic-coverage"
$arcComparison=Read-Record "$arcExtra.cli-comparison"
$arcAllCli=Read-Record "$arcExtra.all-cli-scope"
if($arcMatrix.status -ne 'terminal' -or $arcMatrix.rows.Count -ne 3 -or $arcCliMatrix.status -ne 'terminal' -or $arcCliMatrix.rows.Count -ne 2){throw 'Matrix is incomplete'}
if($arcGeneric.selected -ne 151 -or $arcGeneric.passed -ne 151 -or $arcGeneric.failed -ne 0){throw 'Accepted Generic Match evidence differs'}
$arcGates=@(foreach($arcName in @('workspace-check','clippy','core-default','core-wasm','structure','fmt')){$arcGate=Read-Record "$arcQuality.$arcName";if($arcGate.exitCode -ne 0 -or $arcGate.sourceDrift -ne 0){throw ('Gate failed: '+$arcName)};[ordered]@{name=$arcName;record="$arcQuality.$arcName.json";result=$arcGate}})
$arcEpochs=@('presentation-handle-projection-focus1-20261101','presentation-handle-projection-focus2-20261101','presentation-handle-projection-focus3-20261101','presentation-handle-explicit-type-focus1-20261101','presentation-handle-explicit-type-focus2-20261101','presentation-handle-explicit-type-focus3-20261101','presentation-type-argument-tooling-before-20261101','presentation-type-argument-tooling-after-20261101','presentation-handle-contract-library-repair1-20261101','presentation-handle-contract-library-repair2-20261101','presentation-handle-contract-cli-repair2-20261101')
$arcFocus=@(foreach($arcEpoch in $arcEpochs){$arcCatalog=Read-Record "$arcEpoch.catalog";$arcTerminal=if(Test-Path -LiteralPath "$arcTemp/$arcEpoch.runtime.terminal-audit.json"){Read-Record "$arcEpoch.runtime.terminal-audit"}else{$null};[ordered]@{epoch=$arcEpoch;catalog=$arcCatalog;runtime=$arcTerminal;runtimeNotRun=($null -eq $arcTerminal)}})
$arcPublications=@(foreach($arcPrefix in @('checkpoint-presentation-handle-projection','checkpoint-presentation-explicit-type-arguments','checkpoint-presentation-type-argument-tooling','checkpoint-presentation-handle-test-contracts','checkpoint-presentation-thread-publication-fixture')){Read-Record "$arcPrefix.verified"})
$arcOwned=@(Get-Content -LiteralPath "$arcTemp/presentation-handle-projection.fmt-owned.txt")
$arcFiles=@(Get-ChildItem -LiteralPath $arcTemp -File|Where-Object {
    $_.Name -match '^presentation-handle-(projection-focus|explicit-type-focus)' -or
    $_.Name -match '^presentation-type-argument-tooling-(before|after)-20261101\.' -or
    $_.Name -match '^presentation-handle-contract-' -or
    $_.Name -match '^presentation-handle-contract\.(cli-preservation-proof\.json|expected-residual-wip\.patch|baseline-update\.json)$' -or
    $_.Name -match '^checkpoint-presentation-(handle-test-contracts|thread-publication-fixture)\.(verified.json|prepared.json|reviewed.patch|message.txt)$' -or
    $_.Name.StartsWith($arcQuality+'.') -or $_.Name.StartsWith($arcNormal+'.') -or $_.Name.StartsWith($arcExtra+'.') -or
    $_.Name -eq 'presentation-handle-projection.owner-review.json' -or
    $_.Name -match '^checkpoint-presentation-(handle-projection|explicit-type-arguments|type-argument-tooling)\.(verified.json|prepared.json|reviewed.patch|message.txt)$' -or
    $_.Name -match '^(run|audit)-presentation-handle-(projection|test-contract).*\.ps1$' -or
    $_.Name -in @('prepare-presentation-handle-test-partial-proof.ps1','checkpoint-presentation-handle-contract-prepare.ps1','reconcile-presentation-handle-test-contract-repairs.ps1','update-presentation-handle-validation-status.ps1','task-dialogue-prefix.cli-preservation-proof.json','task-dialogue-prefix.original-user.patch') -or
    $_.Name -in @('run-source-frozen-nextest.ps1','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','assert-no-arcweft-build.ps1','archive-presentation-handle-projection-validation.ps1')
})
$arcFiles+=@(Get-ChildItem -LiteralPath "$arcTemp/$arcQuality.structure-report" -File)
$arcZipPath='docs/implementation/acceptance-evidence/task-presentation-handle-projection-validation-raw.zip'
$arcManifestPath='docs/implementation/acceptance-evidence/task-presentation-handle-projection-validation.json'
if((Test-Path -LiteralPath $arcZipPath) -or (Test-Path -LiteralPath $arcManifestPath)){throw 'Evidence already exists'}
$arcZip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($arcZipPath),[IO.Compression.ZipArchiveMode]::Create)
$arcEntries=@(try {foreach($arcFile in $arcFiles|Sort-Object FullName){$arcName=if($arcFile.DirectoryName.EndsWith('.structure-report')){'structure/'+$arcFile.Name}else{$arcFile.Name};$arcBytes=[IO.File]::ReadAllBytes($arcFile.FullName);$arcEntry=$arcZip.CreateEntry($arcName,[IO.Compression.CompressionLevel]::Optimal);$arcStream=$arcEntry.Open();try{$arcStream.Write($arcBytes)}finally{$arcStream.Dispose()};[ordered]@{name=$arcName;bytes=$arcBytes.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($arcBytes)).ToLowerInvariant()}}}finally{$arcZip.Dispose()})
$arcManifest=[ordered]@{
    version=1;date='2026-11-01';sourceCommit=$arcSource;sourceTree=(git rev-parse ($arcSource+'^{tree}')).Trim();repairSourceCommit=$arcRepairSource;repairSourceTree=(git rev-parse 'HEAD^{tree}').Trim();workingTree='main with original tracked WIP14 and untracked actual files6 retained; no task-owned Rust dirt';sourceInputs=$arcFreeze.paths.Count;repairSourceInputs=$arcRepairFreeze.paths.Count;
    sourceDrift=0;publications=$arcPublications;changedRust=$arcOwned;
    contract='Exact Core Handle<Resource> opaque producer and family validation; retained generic/explicit argument purpose; selected-call, complete Match transcript and LSP consume retained nominal-resolution authority.';
    focusedAttempts=$arcFocus;gates=$arcGates;repairReconciliation=$arcReconciliation;structureReview=Read-Record 'presentation-handle-projection.owner-review';
    reverseGraph=Read-Record "$arcNormal.graph";normalReverse=$arcMatrix;genericCoverage=$arcGeneric;extendedCli=$arcCliMatrix;cliComparison=$arcComparison;allCliTargets=$arcAllCli;
    originalNormalPassing=$false;reconciledNormalUnresolvedFailures=0;isOneFreshPassingMatrix=$false;
    originalNewCliFailureCount=@($arcComparison.newFailureIds).Count;reconciledNewCliFailureCount=0;unselectedPriorCliFailureCount=@($arcComparison.unselectedPriorFailureIds).Count;
    overallRuntimePassing=(@($arcMatrix.rows+$arcCliMatrix.rows|Where-Object {$_.catalogExit -ne 0 -or $_.runtimeExit -ne 0 -or $_.terminal.failed -ne 0}).Count -eq 0);
    acceptance='Generic Match acceptance/publication is retained. Focused failures preserve their original input and failed consumer; repaired assertions and complete current reverse coverage determine this cut. Distinct focused and reverse commands are not one summed rerun.';
    sourcePresentationExecutionAccepted=$false;scopeLimit='ViewValue construction, presentation command/method execution and driver connection are not established by handle type projection or function ABI compilation.';
    priorMountEvidence='task-presentation-mount-schema-validation.json';priorSharedIdentityEvidence='task-presentation-shared-identities-validation.json';
    raw=[ordered]@{path=(Split-Path $arcZipPath -Leaf);sha256=(Get-FileHash -LiteralPath $arcZipPath).Hash.ToLowerInvariant();entries=$arcEntries}
}
$arcManifest|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $arcManifestPath -Encoding utf8
$arcCheck=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($arcZipPath))
try {if($arcCheck.Entries.Count -ne $arcEntries.Count){throw 'ZIP count differs'};foreach($arcRow in $arcEntries){$arcEntry=$arcCheck.GetEntry($arcRow.name);$arcStream=$arcEntry.Open();try{$arcHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($arcStream)).ToLowerInvariant()}finally{$arcStream.Dispose()};if($arcEntry.Length -ne $arcRow.bytes -or $arcHash -ne $arcRow.sha256){throw 'ZIP entry differs'}}}finally{$arcCheck.Dispose()}
[ordered]@{source=$arcSource;repairSource=$arcRepairSource;rawEntries=$arcEntries.Count;rawBytes=(Get-Item -LiteralPath $arcZipPath).Length;reconciledNormalUnresolved=0;overallRuntimePassing=$arcManifest.overallRuntimePassing;sourceInputs=$arcFreeze.paths.Count}|ConvertTo-Json -Compress
