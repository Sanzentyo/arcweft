param([Parameter(Mandatory)][string]$Prefix)
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$baseline=Get-Content -LiteralPath (Join-Path $e 'checkpoint-task-view.source-freeze.json') -Raw | ConvertFrom-Json
$proof=Get-Content -LiteralPath (Join-Path $e 'presentation-handle-contract.cli-preservation-proof.json') -Raw | ConvertFrom-Json -Depth 30
$owned=@(Get-Content -LiteralPath (Join-Path $e ($Prefix+'.owned.txt')) | Sort-Object -Unique)
$other=@(Get-Content -LiteralPath (Join-Path $e ($Prefix+'.other.txt')) | Where-Object {$_})
$base=(git rev-parse HEAD).Trim()
if($base -ne $baseline.base -or $base -ne $proof.base -or (git branch --show-current).Trim() -ne 'main'){throw 'Unexpected base'}
if(@(git diff --cached --name-only).Count){throw 'Index is not empty'}
if($baseline.heldPatchSha256 -ne $proof.originalWipPatchSha256 -or -not $proof.originalUserPatchPreserved -or $proof.heldCanonicalBlobDrift -ne 0){throw 'Invalid original WIP proof'}
if($proof.path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or $proof.path -notin $owned){throw 'Wrong partial path'}
if(@($owned | Where-Object {($_ -in $baseline.held -and $_ -ne $proof.path) -or -not(Test-Path -LiteralPath $_)}).Count){throw 'Unexpected held or missing owned path'}
$allowed=@($owned+$other+$baseline.held)
if(@(git diff HEAD --name-only | Where-Object {$_ -notin $allowed}).Count){throw 'Unknown tracked changes'}
foreach($path in $baseline.held){
 $expected=$proof.expectedHeldBlobs.PSObject.Properties[$path].Value
 if(-not $expected -or (git hash-object -- $path).Trim() -ne $expected){throw ('Preserved WIP changed: '+$path)}
}
$codeFile=Join-Path $e 'presentation-handle-contract.cli-head-after.rs'
if((git hash-object ('--path='+$proof.path) -- $codeFile).Trim() -ne $proof.stagedCodeBlob){throw 'Reviewed source changed'}
$regular=@($owned | Where-Object {$_ -ne $proof.path})
$pspec=Join-Path $e ($Prefix+'.regular-pathspec')
[IO.File]::WriteAllText($pspec,($regular -join ([string][char]0))+([string][char]0),[Text.UTF8Encoding]::new($false))
git --literal-pathspecs add ('--pathspec-from-file='+$pspec) --pathspec-file-nul
if($LASTEXITCODE -ne 0){throw 'Explicit regular staging failed'}
git update-index --cacheinfo ('100644,'+$proof.stagedCodeBlob+','+$proof.path)
if($LASTEXITCODE -ne 0){throw 'Partial source staging failed'}
if(@(Compare-Object $owned @(git diff --cached --name-only)).Count){throw 'Staged set differs'}
$held=Read-GitBytes (@('diff','--binary','--full-index','--')+$baseline.held)
$heldHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($held)).ToLowerInvariant()
if($heldHash -ne $proof.expectedResidualWipPatchSha256){throw 'Residual original WIP differs'}
$check=@('-c','core.whitespace=trailing-space,space-before-tab,cr-at-eol','diff','--cached','--check','--','.')
foreach($path in $owned | Where-Object {$_ -like '*.log'}){$check+=(':(exclude)'+$path)}
git @check
if($LASTEXITCODE -ne 0){throw 'Whitespace failed'}
$patch=Read-GitBytes @('diff','--cached','--binary','--full-index')
[IO.File]::WriteAllBytes((Join-Path $e ($Prefix+'.reviewed.patch')),$patch)
$rows=@(foreach($line in @(git ls-files --stage -- $owned)){if($line -notmatch '^[0-9]+ ([0-9a-f]{40}) 0\t(.+)$'){throw 'Invalid index entry'};[ordered]@{path=$Matches[2];blob=$Matches[1]}})
$prepared=[ordered]@{version=1;base=$base;tree=(git write-tree).Trim();paths=$rows;other=@(foreach($path in $other){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}});held=$baseline.held;heldPatchSha256=$heldHash;originalHeldPatchSha256=$proof.originalWipPatchSha256;patchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant();partialStagedSource=$proof.stagedCodeBlob;originalWipProof='presentation-handle-contract.cli-preservation-proof.json';preparedAt=[DateTime]::UtcNow.ToString('o')}
$prepared | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath (Join-Path $e ($Prefix+'.prepared.json')) -Encoding utf8
[ordered]@{base=$base;paths=$rows.Count;tree=$prepared.tree;patchSha256=$prepared.patchSha256;held=$baseline.held.Count;heldPatchSha256=$heldHash;partialSourceBlob=$proof.stagedCodeBlob;originalUserWipPreserved=$true} | ConvertTo-Json -Compress

