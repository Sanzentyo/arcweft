$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$repair=(git rev-parse HEAD).Trim()
$v=Get-Content -LiteralPath "$taskT/checkpoint-presentation-thread-publication-fixture.verified.json" -Raw|ConvertFrom-Json
if($repair -ne $v.commit){throw 'Repair source differs'}
$recon=Get-Content -LiteralPath "$taskT/presentation-handle-contract-repair-reconciliation.json" -Raw|ConvertFrom-Json
if($recon.repairCommit -ne $repair -or $recon.reconciledNormal.unresolvedFailures -ne 0){throw 'Repair verification is incomplete'}
$path='docs/implementation/current-status.md'
$s=[IO.File]::ReadAllText((Join-Path (Get-Location) $path))
$intro="確認日: 2026-11-01。広い逆依存・CLI検証の製品Source/mainはa08206261463c06c905ebdfa1c551da8d89d7f2f、後続のテスト修復は$repair。元からの14 tracked／6 untracked WIPを保持するcheckoutの4,038入力を照合し、修復前後の差分はテスト専用の4 pathに限る。公開canonicalと保持WIPの差分を同一視せず、受入と未達は各行の境界・検証範囲で判定する。"
$s=[regex]::Replace($s,'(?m)^確認日: [^\r\n]*',[System.Text.RegularExpressions.MatchEvaluator]{param($m)$intro})
$s=$s.Replace('Sourceの11 callable・mount(ViewValue)・6 method／実driver','SourceのPresentation値生成・callable／method・実driver')
function Replace-Row([string]$prefix,[string]$row){
 $pattern='(?m)^\| '+[regex]::Escape($prefix)+'[^\r\n]*'
 if([regex]::Matches($script:s,$pattern).Count -ne 1){throw ('Ambiguous status row: '+$prefix)}
 $script:s=[regex]::Replace($script:s,$pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($m)$row})
}
Replace-Row 'Generic Match' '| Generic Match `.1.2` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。今回のa08206261463c06c905ebdfa1c551da8d89d7f2f・4,038入力でも同じ151 IDを選択・実行し、151／151 PASS・除外0。完全transcript、uninhabited-domain、Never／let-else、exhaustive-only atomic publicationの受入を維持する。[受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)、[公開記録](acceptance-evidence/accepted-generic-phase-note-publication.json)、[今回の151件照合](acceptance-evidence/task-presentation-handle-projection-validation.json)。 |'
Replace-Row 'Presentation引数schema' '| Presentation引数schema／resource型 | **既受入を維持。mountの意味解析を追加・検証・公開済み** | 共有化9c7690d8f6531b4886fa2a14aa223d27c84f0a8e、汎用Handle修復c4365e40c7e1b6050b4ba3162b367c954b7f07ff、mount追加c16e081596dc7a33721cfd1c6cebad1c4fb9b3a6。共有inventoryは12 callable・6 method・52引数roleで、mountは構築済みViewValueを要求しHandle<View>を返す。直接・local aliasのchecked View callと正確な通常値拒否を含むowner全1,394件PASS、owner Clippy／fmt終了0。初回のUnit戻り値fixture誤りを[原本](acceptance-evidence/task-presentation-mount-schema-validation.json)へ保持する。後続入力の逆依存・CLIは下表に集約し、Source実行ABIはCore行と区別する。 |'
Replace-Row 'Presentation Handleのruntime型投影' "| Presentation Handleのruntime型投影／型引数用途 | **当該型投影・consumer移行は検証・公開済み** | 型投影9c0b5f30143a3a46dae26668212a2414db121702、明示型引数b680d002d0b037f1a4bbba9f222362cc2688f1f3、LSP a08206261463c06c905ebdfa1c551da8d89d7f2f。Coreのexact型ownerが8 resource familyとaffine／snapshot-only条件を検査し、SourceのHandle引数・戻り値へ投影する。型引数のsemantic type／alias情報とruntime値型factを区別し、call binder・Match transcript・hoverを保持された解決情報へ揃えた。異なる入力の対象23件、明示型適用等55件、LSP2件が各PASS。全逆依存で見つかった古いテスト4件は4485e5332162e238ab5fd4bc12c601f7f4fa1871と$repair で修復し、同じ失敗IDの再実行は各2／2 PASS。通常逆依存の未解消0、既存CLIの43失敗は別境界。初回失敗・正確な入力・再検証範囲を[原本](acceptance-evidence/task-presentation-handle-projection-validation.json)へ保持する。値生成・command／driverの接続はCore行の別境界とする。 |"
Replace-Row 'CLI・全 consumer' '| CLI・全 consumer の統合受入 | **既存CLI失敗43件が未解消・統合受入は未完了** | 現行lib／bin／integration全12 targetの実行を下表に集約する。今回増えたdense lenの型fact件数2件は現行契約へ修復して同一IDのPASSを確認した。元の45 FAILを43 FAILの単一再実行へ書き換えず、失敗原本と修復を別に保持する。Presentation ABI・JLREQ geometry等の未達を、個別に受入済みの機能へ戻さない。[入力・全target・失敗ID比較と修復](acceptance-evidence/task-presentation-handle-projection-validation.json)。 |'
$cut=$s.IndexOf('## 横断検証の適用範囲')
if($cut -lt 0){throw 'Missing current validation table'}
$s=$s.Substring(0,$cut)+@'
## 横断検証の適用範囲

| 対象・入力 | 実際の結果 | 適用範囲・原本 |
|---|---|---|
| Presentation共有語彙・型投影の逆依存matrix | **62 package・通常3群：元runは8,997 PASS／2 FAIL／24 ignored。失敗した2 IDの修復再実行は2／2 PASS** | 製品Source a08206261463c06c905ebdfa1c551da8d89d7f2f・4,038入力。解決済みCargo graphからinteraction-modelの推移的逆依存を選択した。library／integrationは8,777 PASS／2 FAIL、CLI lib／binは191 PASS、通常CLIの6 integration targetは29 PASS。後続はテスト専用4 pathだけを変更して同じ失敗IDを再検証し、通常選択の未解消失敗0と照合した。全8,999件を単一の成功runとして合算しない。all-features・locked・default filter、群ごとのfeature union・catalog・case・EXE・入力差分0を[原本](acceptance-evidence/task-presentation-handle-projection-validation.json)へ保持する。 |
| CLI追加check target | **元runは413 PASS／45 FAIL／23 ignored。新規2 IDの修復再実行は2／2 PASS。未解消は既知43 IDと一致** | 同じ製品入力で通常の6 CLI integration targetとは別に実行した。新規2件はtypesがruntime値型factだけを数えるための期待値更新であり、実行命令数7・予算・反復・samples条件は維持する。異なる入力の原因同一性や未選択caseの成功を推定せず、元の失敗と後続の修復を区別する。[比較・stderr・再実行原本](acceptance-evidence/task-presentation-handle-projection-validation.json)。 |
| CLI追加3 integration target／全target照合 | **追加3 targetは14 PASS。元の全12 targetは重複なし692実行・647 PASS／45 FAIL・23 ignored。上記2 IDを修復し、未解消43** | bracket_numeric_batch、environment_callable_tensor、native_host_contractsを同じ入力で実行した。metadata上の現行lib／bin／integration全12 testable targetを4 commandで網羅し、未選択target 0。修復後の全692件を新たに一括実行したとはしない。[target・case照合原本](acceptance-evidence/task-presentation-handle-projection-validation.json)。 |
| workspace check／Clippy・Core default／Wasm・fmt・構造gate | **製品入力の各gate終了0・構造blocking0。後続テスト修復の3 owner Clippy／4 path fmtも終了0** | 製品入力4,038件でworkspace全97 package・全target・全feature・lockedのcheckとClippy、Core default／wasm32-unknown-unknownのlib check、変更Rust 21 pathのfmtを実行した。構造gateは97 package・3,274 file／3,144 Rust file・1,777,878 Rust physical LOC・384 review trigger・blocking0。後続の4 pathはテスト本体とcfg(test) hookに限り、製品gateの再実行へ読み替えない。実行可能doc exampleを追加しておらず、以前のCore doctestは元入力の履歴として保持する。[command・警告・owner review・終端](acceptance-evidence/task-presentation-handle-projection-validation.json)。 |

以前の件数・失敗・full SHAと今回の訂正理由は[検証履歴](convergence-evidence-history.md)と各原本へ保持する。過去の資料整理は[資料整理記録](documentation-cleanup.md)を参照。
'@
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$s,[Text.UTF8Encoding]::new($false))
$history=@"

## Handle型投影の逆依存・全CLI終端とテスト契約の修復 — 2026-11-01

製品Source a08206261463c06c905ebdfa1c551da8d89d7f2f・4,038入力で全62逆依存の通常3群を完走した。library／integration 8,777 PASS／2 FAIL／24 ignored、CLI lib／bin 191 PASS、通常6 integration target 29 PASSであり、元runの8,997 PASS／2 FAILを書き換えない。Generic Matchの同じ151 IDは151／151 PASS・除外0で、受入850534b9e9bc8c8872f6528dd00050a5e6e7699e／公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2を維持する。

同じ製品入力のCLI checkは413 PASS／45 FAIL／23 ignored、追加3 integration targetは14 PASS。全12 testable targetを4 commandで網羅し、重複なし692実行・647 PASS／45 FAIL・23 ignored、未選択target 0。以前の43 IDはすべて同じIDで失敗し、新規2 ID・解消0・未選択0だった。新規2件はdense textual／wide numeric len benchのsemantic typesが7→5／10→6になった差分であり、実行命令数ではない。output.rsのFinalSemanticProfileStatsはanalysis.types().len()を出力するため、semantic-only TypeArgumentをruntime値型factに含めない現行契約へ期待値を揃えた。実行命令数7、元のlocals／expressions、iterations／warmup／samples、steps／max-opsと予算は維持した。

最初のテスト修復は4485e5332162e238ab5fd4bc12c601f7f4fa1871（親a08206261463c06c905ebdfa1c551da8d89d7f2f、tree a19b7fa3f9dfc857a9ba3f86173d8120781bbbaf、patch SHA256 3544704c790d83e54fc9c148b9885020d5ebeb0817ea593d1b0a035481d6c71f）として検証中の区切りで公開した。Compilerのclosed generic投影はsemantic-only typeのexact owner／purposeとruntime型を持たない条件を検査し、値・local行の型assertionを維持する。最初の対象2件再実行はCompiler PASS／Sema FAILの1／2。追加したSemaの無改変positive controlがWrongPayloadFamilyで拒否され、手動call-free再構築がtype resolutionだけでなく受理済みexecution catalogを欠落させることが判明した。この失敗は原本に保持する。

後続$repair（親4485e5332162e238ab5fd4bc12c601f7f4fa1871、tree $($v.tree)、patch SHA256 $($v.patchSha256)）では、既存のcfg(test) mutation ownerに受理直前のThread式の改変を追加し、製品の完全な型解決・execution region等を維持した。無改変の受理と、Structural／別Thread本体／Unit結果への各差し替えのWrongPayloadFamily拒否を同じcaseで確認する。製品validatorは変更していない。最終のライブラリ2 IDとCLI新規2 IDは別commandで各2／2 PASS、各4,038入力・catalog・EXE・source差分0。3 owner全target／全feature Clippyと4 path fmtは終了0。製品入力との差分はこのテスト専用4 pathだけで、通常選択の未解消0、CLIは既知43 IDが未解消と照合した。全8,999件やCLI692件の新しい一括成功runとはしない。

製品入力のworkspace全97 package・全target／全feature／locked checkとClippy、Core default／Wasm lib check、21 Rust path fmt、構造gateは各終了0。構造は3,274 files／3,144 Rust files・1,777,878 physical Rust LOC・384 review trigger・blocking0。nominal/model.rsの1,200行超過は解決済み型nodeモデルとして責務を確認し、Coreの新childは既存opaque owner上の検証で、新しいstate／I/O／代替resolverを作らない。後続のテスト専用hookをこの製品構造測定へ合算しない。doctestは今回追加実行していない。

元tracked WIP14／untracked実ファイル6を保持した。CLIの元system-info 8→32 user hunkはstageせず、新canonical blobへimmutable元patchをalternate indexで適用するとactual working blobを再現する。ほか13 held blobは不変。残WIP patch SHA256は53b95c4ff3fb9ef6080f215b97cf7442033a1ff81f83da3ebe7db441b9d363b6となり、前の5a4f4c1d643645333b459e6b4be6f05b9e2c6d8f4a5f8ad3272ce7660860920aと元6dd4dd235aedbe9a22634d6faeb23754dba0763abf7fcf15f6c0916f43f2e6efを保全証明とともに保持する。

Supersedes: 現状一覧のc4365e40c7e1b6050b4ba3162b367c954b7f07ff・4,036入力の横断表と「型投影の横断検証中」は、後続の実終端・具体的なテスト修復を根拠として置き換えた。以前の8,987 PASS／0 FAIL／24 ignored、CLI check415 PASS／43 FAIL、全CLI692／649 PASS／43 FAIL、構造3,272 files／3,142 Rust files・1,777,137 LOC／382 reviewは[旧原本](acceptance-evidence/task-presentation-shared-identities-validation.json)へ保持し、今回の再実行に転用しない。現状一覧は一か所を維持する。Generic Matchを含む既受入を未完了へ戻さず、Source ViewValue生成・Presentation command／method実行・driver接続やCLI既知43件を別の未達として区別する。[全実行・失敗・公開・保全の原本](acceptance-evidence/task-presentation-handle-projection-validation.json)。
"@
[IO.File]::AppendAllText((Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'),$history,[Text.UTF8Encoding]::new($false))
Write-Output 'Single current status updated; historical prefix and original failed matrices retained.'
