$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$extra=@('crates/arcweft-core/src/awbc/product_step/tests/dialogue_handoff.rs','crates/arcweft-interaction-model/src/presentation/arguments.rs','crates/arcweft-interaction-model/src/presentation/callables.rs','crates/arcweft-lang-sema/src/final_analysis/tests/presentation.rs','crates/arcweft-core/src/pattern/presentation.rs','crates/arcweft-compiler/src/lower/presentation_tests.rs')
$old=Get-Content -LiteralPath "$taskT/presentation-handle-projection-reverse-20261101.libraries.catalog.json" -Raw|ConvertFrom-Json
$args=@($old.command[2..($old.command.Count-4)])
if($args[-1] -ne '-E'){throw 'Unexpected old selection shape'}
$args=$args[0..($args.Count-2)]
$args+=@('-E','rdeps(=arcweft-interaction-model) and (test(=project::tests::generic_display_text_publishes_distinct_closed_method_instances) | test(=final_analysis::tests::local_use::thread_publication_rejects_structural_and_foreign_body_semantics))')
& "$taskT/run-source-frozen-nextest.ps1" -Stem 'presentation-handle-contract-library-repair1-20261101' -Selection $args -ExpectedMatches 2 -AdditionalPaths $extra
if($LASTEXITCODE -ne 0){throw 'Library contract repair failed'}
$cli=@('-p','arcweft-cli','--test','check','--all-features','--locked','-E','test(=check::cli_runtime_bench::bench_json_measures_checked_in_dense_textual_scalar_len_fixture) | test(=check::cli_runtime_bench::bench_json_measures_checked_in_dense_wide_numeric_len_fixture)')
& "$taskT/run-source-frozen-nextest.ps1" -Stem 'presentation-handle-contract-cli-repair1-20261101' -Selection $cli -ExpectedMatches 2 -AdditionalPaths $extra
if($LASTEXITCODE -ne 0){throw 'CLI contract repair failed'}
$stem='presentation-handle-contract-repair-quality1-20261101'
$freeze=Get-Content -LiteralPath "$taskT/presentation-handle-contract-cli-repair1-20261101.source-freeze.json" -Raw|ConvertFrom-Json
function Invoke-Gate([string]$name,[string]$exe,[string[]]$arguments){
 foreach($p in $freeze.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Source drift'}}
 $start=[DateTime]::UtcNow.ToString('o')
 & $exe @arguments *> "$taskT/$stem.$name.log"
 $code=$LASTEXITCODE
 foreach($p in $freeze.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Source drift'}}
 [ordered]@{version=1;base=$freeze.base;command=@($exe)+$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskT/$stem.$name.json" -Encoding utf8
 if($code -ne 0){throw "Gate failed: $name"}
}
Invoke-Gate 'clippy' 'cargo' @('clippy','-p','arcweft-compiler','-p','arcweft-lang-sema','-p','arcweft-cli','--all-targets','--all-features','--locked')
Invoke-Gate 'fmt' 'rustfmt' @('--edition','2024','--config','skip_children=true','--check','crates/arcweft-compiler/src/project/tests.rs','crates/arcweft-lang-sema/src/final_analysis/tests/local_use.rs','crates/arcweft-cli/tests/check/cli_runtime_bench.rs')
Write-Output 'Four test contracts repaired and focused checks passed; original failed matrices retained.'
