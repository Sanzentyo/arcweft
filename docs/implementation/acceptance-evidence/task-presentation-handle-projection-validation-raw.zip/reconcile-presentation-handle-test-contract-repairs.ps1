$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskT='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$taskT/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$old=Read-Record 'presentation-handle-projection-reverse-20261101.source-freeze'
$new=Read-Record 'presentation-handle-contract-cli-repair2-20261101.source-freeze'
if(@(Compare-Object @($old.paths.path) @($new.paths.path)).Count){throw 'Input path set differs'}
$oldHashes=@{};foreach($p in $old.paths){$oldHashes[$p.path]=$p.sha256}
$changed=@($new.paths|Where-Object {$_.sha256 -ne $oldHashes[$_.path]})
$expected=@('crates/arcweft-cli/tests/check/cli_runtime_bench.rs','crates/arcweft-compiler/src/project/tests.rs','crates/arcweft-lang-sema/src/final_analysis/tests/local_use.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer.rs')
if(@(Compare-Object $expected @($changed.path)).Count){throw 'Repair changed more than the four test files'}
foreach($p in $new.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Current repair input changed'}}
$normal=Read-Record 'presentation-handle-projection-reverse-20261101.matrix'
$oldLibrary=@($normal.rows|Where-Object group -eq 'libraries')[0].terminal
$comparison=Read-Record 'presentation-handle-projection-full-cli-20261101.cli-comparison'
$allCli=Read-Record 'presentation-handle-projection-full-cli-20261101.all-cli-scope'
$repairs=@()
$repairGroups=@([pscustomobject]@{group='library';stem='presentation-handle-contract-library-repair2-20261101';failed=@($oldLibrary.failureSet)},[pscustomobject]@{group='cli';stem='presentation-handle-contract-cli-repair2-20261101';failed=@($comparison.newFailureIds)})
foreach($item in $repairGroups){
 $terminal=Read-Record ($item.stem+'.runtime.terminal-audit')
 $inventory=Read-Record ($item.stem+'.catalog.inventory')
 $selected=@($inventory.rows|Where-Object status -eq 'matches')
 $oldKeys=@($item.failed|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object)
 $newKeys=@($selected|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object)
 if($terminal.actualExitCode -ne 0 -or $terminal.executed -ne 2 -or $terminal.passed -ne 2 -or $terminal.failed -ne 0 -or $terminal.sourceDrift -ne 0 -or $terminal.catalogCaseDrift -ne 0 -or @(Compare-Object $oldKeys $newKeys).Count){throw ('Repair does not close the exact failed case set: '+$item.group)}
 $repairs+=[ordered]@{group=$item.group;epoch=$item.stem;exactOldFailureIds=$item.failed;selectedCases=$selected;terminal=$terminal}
}
$normalPass=($normal.rows|ForEach-Object {$_.terminal.passed}|Measure-Object -Sum).Sum
$normalFail=($normal.rows|ForEach-Object {$_.terminal.failed}|Measure-Object -Sum).Sum
if($normalPass -ne 8997 -or $normalFail -ne 2 -or $comparison.currentFailureCount -ne 45 -or @($comparison.sameFailureIds).Count -ne 43 -or $allCli.uniqueExecuted -ne 692){throw 'Original terminal matrix differs'}
$gates=@(foreach($name in @('clippy','fmt')){$g=Read-Record ('presentation-handle-contract-repair-quality2-20261101.'+$name);if($g.exitCode -ne 0 -or $g.sourceDrift -ne 0){throw 'Repair quality gate failed'};$g})
$result=[ordered]@{
 version=1;productionSource=$old.base;repairBase=$new.base;repairCommit=(git rev-parse HEAD).Trim();sourceInputs=$new.paths.Count;changedTestInputs=$changed;productionCargoFixtureChanges=0;sourceDrift=0;
 originalNormal=[ordered]@{passed=$normalPass;failed=$normalFail;ignored=24;executed=8999;unchangedOriginalResult=$true};
 originalAllCli=$allCli;repairs=$repairs;repairGates=$gates;
 reconciledNormal=[ordered]@{unresolvedFailures=0;originalPassed=8997;repairedExactCases=2;coveredDistinctConditions=8999;isSingleFreshMatrix=$false};
 reconciledAllCli=[ordered]@{unresolvedFailures=43;originalPassed=647;repairedExactCases=2;coveredDistinctConditions=692;ignored=23;failureSet=$comparison.sameFailureIds;isSingleFreshMatrix=$false};
 reason='Type-argument nodes remain semantic-only. Compiler fixture now verifies exact semantic owner/purpose, Thread publication fixture mutates the final production input with its complete authority under cfg(test), and CLI metrics count runtime value-type facts (5/6). Execution budgets, runtime op count 7, iteration/sample counts and original user step-count WIP are retained.';
 reusedWorkspaceGates='Workspace check/Clippy, Core default/Wasm and structure at the production source are retained as original evidence. The only later inputs changed are four test files; focused exact-case runs, three-package Clippy and fmt establish the repair.';
 repairOwnerReview='The fourth changed path is analyzer.rs: every added variant, implementation, trait hook and call is under cfg(test). It extends the existing mutation owner, preserving full production publication inputs for the negative test. No Cargo, layer, I/O, runtime authority or production behavior is changed. Other three paths contain only tests.';
 originalFailedMatricesPreserved=$true;overallRuntimePassing=$false;at=[DateTime]::UtcNow.ToString('o')
}
$result|ConvertTo-Json -Depth 40|Set-Content -LiteralPath "$taskT/presentation-handle-contract-repair-reconciliation.json" -Encoding utf8
[ordered]@{productionSource=$old.base;repairCommit=$result.repairCommit;changedTestFiles=$changed.Count;normalUnresolved=0;cliUnresolved=43;singleFreshMatrix=$false}|ConvertTo-Json -Compress
