$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d';$directory="$taskEvidence/jlreq-authored-sizing2"
if(Test-Path -LiteralPath $directory){throw 'Preserve original probe'}
[void](New-Item -ItemType Directory -Path $directory)
$executable='D:/git/arcweft/target/debug/arcw.exe';$pin=(Get-FileHash -LiteralPath $executable).Hash.ToLowerInvariant();$rows=@()
$cases=@(@{name='accented';text='天café人';size=38;height=720},@{name='hyphenated';text='天Web-Test人';size=21;height=900})
foreach($case in $cases){foreach($mode in @('vertical_rl','vertical_lr')){
 $name=$case.name+'-'+$mode;$source="$directory/$name.arcw"
 [IO.File]::WriteAllText($source,("entry cli @entry.probe {{ goto @flow.main }}`npub character alice {{ display = `"Alice`" }}`nflow main {{`n    alice: #layout(.{0}, jlreq=.normal)[#size({1}pt)[{2}]][p]`n}}`n" -f $mode,$case.size,$case.text),[Text.UTF8Encoding]::new($false))
 $arguments=@('agent','observe',$source,'--entry','entry.probe','--json','--image','png','--layer','dialogue.rich_text','--viewport-width','1280','--viewport-height',([string]$case.height),'--page','0','--mode','drain','--steps','4','--max-ops','128')
 $started=[DateTime]::UtcNow.ToString('o');& $executable @arguments > "$directory/$name.stdout.json" 2> "$directory/$name.stderr.log";$code=$LASTEXITCODE
 if((Get-FileHash -LiteralPath $executable).Hash.ToLowerInvariant() -ne $pin){throw 'Probe EXE drift'}
 if($code){throw ('Observe failed: '+$name)}
 $report=Get-Content -LiteralPath "$directory/$name.stdout.json" -Raw|ConvertFrom-Json -Depth 100
 $clusters=@($report.objects|Where-Object role -eq 'rich_text_cluster'|Sort-Object {$_.rich_text_ref.range.start})
 $cells=@($clusters|ForEach-Object {[ordered]@{text=$_.text;range=$_.rich_text_ref.range;bbox=$_.bbox}})
 $first=$clusters[0];$next=$clusters[-1];$middle=$clusters[-2]
 $row=[ordered]@{name=$name;sizePt=$case.size;text=$case.text;height=$case.height;sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();command=$arguments;exitCode=$code;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');bodyAndUnitSameColumn=$first.bbox.x -eq $middle.bbox.x;nextColumn=if($mode -eq 'vertical_rl'){$next.bbox.x -lt $middle.bbox.x}else{$next.bbox.x -gt $middle.bbox.x};nextRestarts=$next.bbox.y -lt $middle.bbox.y;clusters=$cells}
 $rows+=$row;[ordered]@{name=$name;sizePt=$case.size;bodyAndUnitSameColumn=$row.bodyAndUnitSameColumn;nextColumn=$row.nextColumn;nextRestarts=$row.nextRestarts;clusters=$cells}|ConvertTo-Json -Depth 5 -Compress
}}
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();executable=$executable;executableSha256=$pin;scope='Diagnostic probes only. Preserve text, modes, viewports and original report budgets. Explicit authored typography creates the intended column-pressure precondition; all actual tests/assertions still require revalidation.';rows=$rows}|ConvertTo-Json -Depth 15|Set-Content -LiteralPath "$directory/observations.json" -Encoding utf8
