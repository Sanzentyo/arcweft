$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$directory="$taskEvidence/jlreq-unit-frontier1"
if(Test-Path -LiteralPath $directory){throw 'Preserve original observation'}
[void](New-Item -ItemType Directory -Path $directory)
$executable='D:/git/arcweft/target/debug/arcw.exe'
$before=(Get-FileHash -LiteralPath $executable).Hash.ToLowerInvariant();$source="$directory/greek.arcw"
[IO.File]::WriteAllText($source,"entry cli @entry.probe { goto @flow.main }`npub character alice { display = `"Alice`" }`nflow main {`n    alice: #layout(.vertical_rl, jlreq=.normal)[天μm人][p]`n}`n",[Text.UTF8Encoding]::new($false))
$arguments=@('agent','observe',$source,'--entry','entry.probe','--json','--image','png','--layer','dialogue.rich_text','--viewport-width','1280','--viewport-height','720','--page','0','--mode','drain','--steps','4','--max-ops','128')
$started=[DateTime]::UtcNow.ToString('o');& $executable @arguments > "$directory/stdout.json" 2> "$directory/stderr.log";$exit=$LASTEXITCODE
if((Get-FileHash -LiteralPath $executable).Hash.ToLowerInvariant() -ne $before){throw 'Probe executable changed'}
$observation=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();productionSource='cd17eba41b99c837432722c6570f60f4287696e3';scope='Read-only direct CLI observation of the existing Greek+Latin fixture with identical text, viewport, budget and writing mode; a diagnostic probe, not a repair or passing test';executable=$executable;executableSha256=$before;source=$source;sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();command=$arguments;exitCode=$exit;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}
$observation|ConvertTo-Json -Depth 5|Set-Content -LiteralPath "$directory/observation.json" -Encoding utf8
if($exit){throw 'Diagnostic observe failed; preserve raw output'}
$report=Get-Content -LiteralPath "$directory/stdout.json" -Raw|ConvertFrom-Json -Depth 100
$objects=@($report.objects|Where-Object role -in @('rich_text_cluster','rich_text_run','rich_text_line','dialogue_view'))
foreach($row in $objects){[ordered]@{role=$row.role;text=$row.text;content=$row.content;range=$row.rich_text_ref.range;bbox=$row.bbox;layout=$row.presentation.layout}|ConvertTo-Json -Depth 8 -Compress}
