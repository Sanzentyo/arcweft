# Control Transfer: `return`, `out`, `yield`, `break`, `continue`

Arcweft separates five kinds of control transfer.

## `return`

`return expr` leaves the nearest executable frame: `fn`, method, `parser`, `flow`,
explicit closure, selected implicit `_` callable, or `thread` child task. Ordinary blocks, Match
arms, named scopes, and `result` / `option` carrier blocks do not receive it.
Returning a callable value does not invoke that value or create a Return frame.

The value must match the receiving callable's result type. A block ending in
`return` has no normal completion (`Never`); an inserted `Unit` tail does not
replace the callable's declared or inferred result type. Final semantic facts
retain the selected callable boundary, including its accepted coordinate and
implicit callable identity where applicable.

A `thread` body owns its returns independently of the code that creates it.
Its returned values determine the payload `T` of `ThreadHandle<T>`; a normal
fallthrough also contributes `Unit`, while a body without normal completion or
returns has result `Never`. A contextual `ThreadHandle<T>` constrains the child's
return expressions before their facts are published. Nested child tasks and
closures have their own return boundaries. A `try` inside a child propagates to
that child's Result or Option result, or to a nearer carrier block. Returning a
Thread handle from an ordinary function transfers the handle to its caller;
it does not return the child's payload or execute the child as a pure expression.

When inferred returns and normal completion cannot share a result type,
type checking rejects the callable with `sema.callable.result_type`. The
diagnostic identifies the original callable body and its own return-value
sources, including normal completion when it contributes `Unit`. Nested
callables retain separate return boundaries. This rejection does not publish
an accepted verifier generation.

```arcw
pub flow title(state: GameState) -> Result<FlowExit, FlowError> {
    if state.config.skip_title {
        return Ok(FlowExit.Goto(@flow.opening))
    }

    Ok(FlowExit.Done)
}
```

## `out`

`out expr` exports a value from a line plan, cue block, or content scope. It does not return from the enclosing flow.

In a Line plan, a direct Line capability call uses the same typed operation
producer as a binding before its value moves to the result. Other result
expressions retain their normal evaluation order and budgeted value continuation.

```arcw
let (actor, voice) = alice()[おはよう。[p]]
with:
    let actor = alice.stage.acquire(scope=line)
    let voice = line.voice_handle()
    out (actor, voice)
```

Do not use `return` for line-plan values.

## `yield`

`yield expr` produces an item from an explicit generation context. It is a
statement with `Unit` type, and the expression must match the item type of the
surrounding generator-like construct.

```arcw
fn rms_level(frames: Stream<AudioFrame, AudioError>) -> Stream<f32, AudioError> {
    for frame in frames {
        yield frame.rms()
    }
}
```

Allowed contexts:

```text
seq { ... }
stream { ... }
fn ... -> Stream<T, E> { ... yield ... }
```

`yield` is a suspension boundary like `await` and `thread`: non-`'static`
borrows, raw pointers, and borrowed callback buffers may not be captured across
it. `seq` blocks are pure lazy sequences, so they also reject runtime effects
such as `await`, `thread`, signal writes, metric writes, event emission, and
logging.

Live external inputs are ordinary external-capability operations returning
`Stream<T, E>`. They are not declarations or roots, and they do not add a
source-specific grammar role.

Do not use `yield` in a non-generator function, flow, hook, memo function, or
dialogue line plan. An ordinary `fn` becomes a generator only when its own
scope contains `yield`; use `out` for line-plan results.

```arcw
let outcome = alice()[長い台詞です。[p]]
with 'line {
    cancel on input(.SkipLine) {
        text.flush(mode = .Instant)
        out 'line Err(LineCancel.Skipped)
    }
    out 'line Ok(())
}
```

An external capability owns acquisition and host policy; a generator only
consumes an existing stream or granted port.

## `break` and `continue`

`break` leaves the nearest loop.

```arcw
loop {
    if done {
        break
    }
}
```

`break expr` gives a `loop` expression its value.

```arcw
let result = loop {
    if ready {
        break value
    }
}
```

`continue` starts the next iteration.

```arcw
while let .Some(event) = queue.pop_front() {
    if !event.is_relevant() {
        continue
    }

    handle_event(event)
}
```

Loop scopes may be labeled when an explicit target improves diagnostics or avoids ambiguity.
`break 'name value` and `continue 'name` select the innermost enclosing `loop`
with that label, including across inner loops. A nested declaration with the
same label shadows the outer label. An unknown label or a transfer across a
closure, Thread, or callable boundary is rejected.

```arcw
'events: loop {
    let event = await_input_event()

    match event {
        .TextAdvanced => continue 'events
        .ChoiceSelected { id } => break 'events route_for_choice(id)
        _ => ()
    }
}
```

## `break expr` is loop-only

`while` and `for` are statement-oriented and return `Unit`.

```arcw
while cond {
    break 1  // error
}
```

Use `loop` if you need a value.

## Interaction with cancellation

Dialogue `cancel on ...` branches may use `return`, `out`, `goto`, or `continue` depending on their target.

```arcw
alice()[長い台詞です。[p]]
with:
    cancel on input(.SkipLine):
        text.flush(mode = .Instant)
        out .Skipped

    cancel on input(.BackToTitle):
        return Ok(FlowExit.Goto(@flow.title))
```

`out` gives a line result. `return` leaves the flow. `goto` is flow-transition sugar.

Both static and dynamic `goto` end the current Flow and unwind its call frames.
The target starts in its own effect scope; its effects do not become effects of
the transferring Flow. Evaluating the target and arguments still belongs to the
current scope. The target's body, argument contract, and entry capabilities
remain checked. The runtime admits the transfer before it completes the source
scopes. Rejected targets and arguments trigger failure cleanup in those scopes.
Returning calls, including ordinary function calls made by a
Flow, require the callee's exposed effects to be covered by the caller's scope.

A bare `goto @flow.target` and a compact Choice `-> @flow.target` supply no
arguments. In these forms, a statically selected target must have no formal inputs,
including unused or wildcard parameters. Stateful Entry startup supplies its
initial state through its own typed binding; it does not implicitly supply state
to later Flow transfers. Missing inputs are rejected during semantic analysis,
before runtime-plan or AWBC generation.

An explicit static transfer, such as `goto @flow.target(value, label = expression)`,
binds inputs with the shared positional and named argument rules. Arguments are
evaluated once in authored order in the current scope, then transferred to the
target's formal coordinates. Before publication, the RuntimePlan checks each
staged input's type against the original formal at that coordinate. The
application does not return a value to the
transferring Flow. A Flow reference does not grant ordinary returning-call rights;
the same application outside a Goto target is rejected.

A dynamic Goto operand must produce a `Ref<Flow>`. A returning function in
`goto choose_route(arguments)` is evaluated normally, including its arguments
and effects, before the resulting Flow reference selects the transfer target.
Strings, numbers, booleans, and values from other reference families are not
Flow targets.

`out` is only valid for line-plan, cue-block, and content-scope outputs. These scopes may also be labeled:

```arcw
alice()[長い台詞です。[p]]
with 'line {
    cancel on input(.SkipLine):
        text.flush(mode = .Instant)
        out 'line .Skipped
}
```

Diagnostics must state the continuation being exited, for example "this `return` exits flow `flow.opening`" or "this `out` exits line scope `'line`".

