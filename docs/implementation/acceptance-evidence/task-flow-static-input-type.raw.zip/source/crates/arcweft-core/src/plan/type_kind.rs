//! Canonical runtime-plan type projection graph.

mod semantic;

use super::{RuntimeArrayLength, RuntimeBoundTypeReference, RuntimeFunctionTypeContract};
use crate::entry::{RuntimeMapKind, RuntimeNominalTypeId, TypeLayoutHash};
use crate::pattern::{
    RuntimeBuiltinVariantIdentity, RuntimeOpaqueTypeAdmission, RuntimeOpaqueTypeProducerId,
};
use crate::value::{
    RuntimeOpaquePersistence, RuntimeOpaqueValueClass, RuntimeSignedIntWidth,
    RuntimeUnsignedIntWidth,
};
use serde::{Deserialize, Serialize};

/// Closed top-level runtime families owned by the Agent Prelude.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
#[repr(u8)]
pub enum RuntimeAgentOperationalType {
    DebugStatePath = 0,
    ObservationFieldPath = 1,
    Probe = 2,
    Predicate = 3,
    Observation = 4,
    ObservedObject = 5,
    BoundingBox = 6,
    ActionName = 7,
    ActionTarget = 8,
    ActionResult = 9,
    DataShape = 12,
    EntityMetadata = 13,
    SourceAnchor = 14,
    SourcePosition = 31,
    ProjectGraphNeighborhood = 15,
    ProjectGraphSymbol = 16,
    ProjectGraphEdge = 17,
    ProjectFlowControlSummary = 32,
    ProjectGraphSummary = 33,
    CaptureTarget = 18,
    CaptureReference = 19,
    Resource = 20,
    RagContextPack = 22,
    ObservedObjectId = 23,
    Diagnostics = 26,
    WaitError = 27,
    ViewportPoint = 28,
    RagError = 30,
    BinaryResourceBody = 34,
    BinaryData = 35,
}

impl RuntimeAgentOperationalType {
    /// Stable kind tag shared by Agent DTO type and snapshot evidence.
    #[must_use]
    pub const fn semantic_tag(self) -> u8 {
        self as u8
    }

    #[must_use]
    pub const fn from_semantic_tag(tag: u8) -> Option<Self> {
        Some(match tag {
            0 => Self::DebugStatePath,
            1 => Self::ObservationFieldPath,
            2 => Self::Probe,
            3 => Self::Predicate,
            4 => Self::Observation,
            5 => Self::ObservedObject,
            6 => Self::BoundingBox,
            7 => Self::ActionName,
            8 => Self::ActionTarget,
            9 => Self::ActionResult,
            12 => Self::DataShape,
            13 => Self::EntityMetadata,
            14 => Self::SourceAnchor,
            15 => Self::ProjectGraphNeighborhood,
            16 => Self::ProjectGraphSymbol,
            17 => Self::ProjectGraphEdge,
            18 => Self::CaptureTarget,
            19 => Self::CaptureReference,
            20 => Self::Resource,
            22 => Self::RagContextPack,
            23 => Self::ObservedObjectId,
            26 => Self::Diagnostics,
            27 => Self::WaitError,
            28 => Self::ViewportPoint,
            30 => Self::RagError,
            31 => Self::SourcePosition,
            32 => Self::ProjectFlowControlSummary,
            33 => Self::ProjectGraphSummary,
            34 => Self::BinaryResourceBody,
            35 => Self::BinaryData,
            _ => return None,
        })
    }

    /// Digest of the core-owned DTO snapshot contract for this closed kind.
    #[must_use]
    pub fn snapshot_contract_digest(self) -> [u8; 32] {
        let mut hasher = blake3::Hasher::new();
        hasher.update(b"arcweft.agent.dto-snapshot-contract.v1\0");
        hasher.update(&[self.semantic_tag()]);
        *hasher.finalize().as_bytes()
    }

    /// Returns whether this semantic Agent family uses the closed protocol
    /// record carrier at host/runtime boundaries.
    #[must_use]
    pub const fn accepts_protocol_record(self) -> bool {
        matches!(
            self,
            Self::Observation
                | Self::ObservedObject
                | Self::BoundingBox
                | Self::ActionResult
                | Self::EntityMetadata
                | Self::SourceAnchor
                | Self::SourcePosition
                | Self::ProjectGraphNeighborhood
                | Self::ProjectGraphSymbol
                | Self::ProjectGraphEdge
                | Self::ProjectFlowControlSummary
                | Self::ProjectGraphSummary
                | Self::CaptureReference
                | Self::Resource
                | Self::BinaryResourceBody
                | Self::RagContextPack
                | Self::Diagnostics
                | Self::WaitError
                | Self::RagError
        )
    }
}

/// Top-level execution family derived from a complete type projection.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeOperationalType {
    Range,
    Iterator,
    Sequence,
    Tuple,
    Record,
    Choice,
    Result,
    Option,
    Map,
    Need,
    Traversal,
    Stream,
    ThreadHandle,
    Shared,
    Reference,
    Function,
    Agent(RuntimeAgentOperationalType),
}

/// Derived execution class. The checked predicate is resolved separately from
/// the owning table and is never copied into a declaration row.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimePlanTypeClass {
    Checked,
    Operational(RuntimeOperationalType),
}

/// Accepted source sequence family.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub enum RuntimePlanSequenceKind {
    Vec,
    Array,
    Slice,
    Seq,
}

/// Mutation policy is owned by the sequence family, shared by native and AWBC
/// admission. A fixed array and a borrowed slice never grow through a place.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RuntimeSequenceMutation {
    Append,
    PopFront,
    PopBack,
}

impl RuntimePlanSequenceKind {
    pub(crate) const fn admits_mutation(self, operation: RuntimeSequenceMutation) -> bool {
        match operation {
            RuntimeSequenceMutation::Append => matches!(self, Self::Vec | Self::Seq),
            RuntimeSequenceMutation::PopFront | RuntimeSequenceMutation::PopBack => {
                matches!(self, Self::Vec)
            }
        }
    }

    /// Canonical family tag shared by executable codecs and type transcripts.
    #[must_use]
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Vec => 0,
            Self::Array => 1,
            Self::Slice => 2,
            Self::Seq => 3,
        }
    }

    #[must_use]
    pub const fn from_semantic_tag(tag: u8) -> Option<Self> {
        match tag {
            0 => Some(Self::Vec),
            1 => Some(Self::Array),
            2 => Some(Self::Slice),
            3 => Some(Self::Seq),
            _ => None,
        }
    }
}

/// The single runtime-plan type algebra, parameterized by its child-reference
/// domain.
///
/// Pre-admission rows use semantic identities and sealed rows use plan-local
/// type IDs. Keeping one algebra prevents seed and executable projections from
/// acquiring different shapes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimePlanTypeProjection<R> {
    BoundType(RuntimeBoundTypeReference),
    Never,
    Unit,
    Bool,
    Signed(RuntimeSignedIntWidth),
    Unsigned(RuntimeUnsignedIntWidth),
    F32,
    F64,
    String,
    Color,
    Char,
    Bytes,
    Duration,
    Progress,
    DenseNumeric(crate::math::RuntimeDenseNumericType),
    EntityReference(crate::value::RuntimeEntityReferenceType<R>),
    AgentValue,
    /// Owned, program-bound presentation body. Custody belongs to its handle.
    PresentationResource(arcweft_interaction_model::presentation::PresentationResourceKind),
    Range(R),
    Iterator(R),
    Sequence {
        kind: RuntimePlanSequenceKind,
        item: R,
    },
    Array {
        item: R,
        length: RuntimeArrayLength,
    },
    Map {
        kind: RuntimeMapKind,
        key: R,
        value: R,
    },
    Need(R),
    /// Captured source collection and full unary callback type.
    Traversal {
        source: R,
        mapping: R,
    },
    Stream {
        item: R,
        error: R,
    },
    Result {
        value: R,
        error: R,
        value_payload: R,
        error_payload: R,
    },
    Option {
        item: R,
        some_payload: R,
    },
    BuiltinVariant {
        owner: RuntimeBuiltinVariantIdentity,
        cases: Box<[Option<R>]>,
    },
    ThreadHandle(R),
    Shared(R),
    Reference(R),
    Function {
        contract: RuntimeFunctionTypeContract,
        parameters: Box<[R]>,
        result: R,
    },
    Nominal {
        nominal: RuntimeNominalTypeId,
        layout: TypeLayoutHash,
        arguments: Box<[R]>,
    },
    Tuple(Box<[R]>),
    Record(Box<[RuntimePlanRecordField<R>]>),
    Choice(Box<[R]>),
    Opaque {
        producer: RuntimeOpaqueTypeProducerId,
        admission: RuntimeOpaqueTypeAdmission,
        value_class: RuntimeOpaqueValueClass,
        persistence: RuntimeOpaquePersistence,
        arguments: Box<[R]>,
    },
    Agent(RuntimeAgentTypeProjection<R>),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimePlanRecordField<R> {
    diagnostic_name: String,
    ty: R,
}

impl<R> RuntimePlanRecordField<R> {
    pub fn new(diagnostic_name: impl Into<String>, ty: R) -> Self {
        Self {
            diagnostic_name: diagnostic_name.into(),
            ty,
        }
    }

    pub fn diagnostic_name(&self) -> &str {
        &self.diagnostic_name
    }

    pub const fn ty(&self) -> &R {
        &self.ty
    }

    fn try_map<T, E>(
        self,
        map: &mut impl FnMut(R) -> Result<T, E>,
    ) -> Result<RuntimePlanRecordField<T>, E> {
        Ok(RuntimePlanRecordField {
            diagnostic_name: self.diagnostic_name,
            ty: map(self.ty)?,
        })
    }
}

/// Agent-owned projection with the generic `Probe<T>` descendant preserved.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeAgentTypeProjection<R> {
    DebugStatePath,
    ObservationFieldPath,
    Probe(R),
    Predicate,
    Observation,
    ObservedObject,
    BoundingBox,
    ActionName,
    ActionTarget,
    ActionResult,
    DataShape(R),
    EntityMetadata,
    SourceAnchor,
    SourcePosition,
    ProjectGraphNeighborhood,
    ProjectGraphSymbol,
    ProjectGraphEdge,
    ProjectFlowControlSummary,
    ProjectGraphSummary,
    CaptureTarget,
    CaptureReference,
    Resource,
    RagContextPack,
    ObservedObjectId,
    Diagnostics,
    WaitError,
    ViewportPoint,
    RagError,
    BinaryResourceBody,
    BinaryData,
}

impl<R> RuntimePlanTypeProjection<R> {
    /// Permits a pre-evaluated expression to retain its original type and value
    /// when stored under a distinct destination type.
    pub(crate) fn accepts_distinct_expression_type(&self, actual_ty: &R, actual: &Self) -> bool
    where
        R: PartialEq,
    {
        matches!(self, Self::Choice(alternatives) if alternatives.contains(actual_ty))
            || matches!(
                (self, actual),
                (
                    Self::Opaque {
                        producer: expected_producer,
                        admission: RuntimeOpaqueTypeAdmission::ProducerWide,
                        value_class: expected_class,
                        persistence: expected_persistence,
                        arguments: expected_arguments,
                    },
                    Self::Opaque {
                        producer: actual_producer,
                        admission: RuntimeOpaqueTypeAdmission::ExactIdentity,
                        value_class: actual_class,
                        persistence: actual_persistence,
                        arguments: actual_arguments,
                    },
                ) if expected_producer == actual_producer
                    && expected_class == actual_class
                    && expected_persistence == actual_persistence
                    && expected_arguments == actual_arguments
            )
    }

    /// The positional value representation used by tuples and owned Traversal.
    /// This inspects type edges without allocating or duplicating captured values.
    pub(crate) fn tuple_arity(&self) -> Option<usize> {
        match self {
            Self::Tuple(items) => Some(items.len()),
            Self::Traversal { .. } => Some(2),
            _ => None,
        }
    }

    pub(crate) fn tuple_element(&self, ordinal: usize) -> Option<&R> {
        match self {
            Self::Tuple(items) => items.get(ordinal),
            Self::Traversal { source, mapping } => match ordinal {
                0 => Some(source),
                1 => Some(mapping),
                _ => None,
            },
            _ => None,
        }
    }

    /// Validates locally bound references and returns the scope of child edges.
    pub fn child_scope(
        &self,
        incoming: &super::RuntimeTypeScope,
    ) -> Result<super::RuntimeTypeScope, super::RuntimeTypeScopeError> {
        match self {
            Self::BoundType(reference) => incoming.validate_type(*reference)?,
            Self::Array { length, .. } => incoming.validate_length(*length)?,
            Self::Function { contract, .. } => return contract.child_scope(incoming),
            _ => {}
        }
        Ok(incoming.clone())
    }

    /// Checks the traversal relation through borrowed queries on the existing
    /// type table. Callback parameters and effects are never cloned for this
    /// structural check, including when a malformed source references a function.
    pub(crate) fn valid_traversal_contract<'a>(
        &self,
        mut sequence_item: impl FnMut(R) -> Option<R>,
        mut function: impl FnMut(R) -> Option<(&'a [R], R)>,
        mut need: impl FnMut(R) -> Option<R>,
        mut is_result: impl FnMut(R) -> bool,
    ) -> bool
    where
        R: Copy + Eq + 'a,
    {
        let Self::Traversal { source, mapping } = self else {
            return false;
        };
        let Some(input) = sequence_item(*source) else {
            return false;
        };
        let Some((parameters, result)) = function(*mapping) else {
            return false;
        };
        parameters == [input] && need(result).is_some_and(&mut is_result)
    }

    /// Counts canonical direct type references without allocating the child list.
    pub(crate) fn child_count(&self) -> Option<usize> {
        Some(match self {
            Self::EntityReference(reference) => usize::from(reference.payload().is_some()),
            Self::Range(_)
            | Self::Iterator(_)
            | Self::ThreadHandle(_)
            | Self::Shared(_)
            | Self::Reference(_)
            | Self::Need(_)
            | Self::Sequence { .. }
            | Self::Array { .. }
            | Self::Agent(
                RuntimeAgentTypeProjection::Probe(_) | RuntimeAgentTypeProjection::DataShape(_),
            ) => 1,
            Self::BuiltinVariant { cases, .. } => {
                cases.iter().filter(|case| case.is_some()).count()
            }
            Self::Map { .. }
            | Self::Traversal { .. }
            | Self::Stream { .. }
            | Self::Option { .. } => 2,
            Self::Result { .. } => 4,
            Self::Function { parameters, .. } => parameters.len().checked_add(1)?,
            Self::Nominal { arguments, .. }
            | Self::Opaque { arguments, .. }
            | Self::Tuple(arguments)
            | Self::Choice(arguments) => arguments.len(),
            Self::Record(fields) => fields.len(),
            Self::BoundType(_)
            | Self::Never
            | Self::Unit
            | Self::Bool
            | Self::Signed(_)
            | Self::Unsigned(_)
            | Self::F32
            | Self::F64
            | Self::String
            | Self::Color
            | Self::Char
            | Self::Bytes
            | Self::Duration
            | Self::Progress
            | Self::DenseNumeric(_)
            | Self::AgentValue
            | Self::PresentationResource(_)
            | Self::Agent(_) => 0,
        })
    }

    /// Child references in canonical declaration order.
    pub fn children(&self) -> Box<[&R]> {
        match self {
            Self::EntityReference(reference) => reference.payload().into_iter().collect(),
            Self::Range(child)
            | Self::Iterator(child)
            | Self::ThreadHandle(child)
            | Self::Shared(child)
            | Self::Reference(child)
            | Self::Need(child)
            | Self::Sequence { item: child, .. }
            | Self::Array { item: child, .. }
            | Self::Agent(RuntimeAgentTypeProjection::Probe(child))
            | Self::Agent(RuntimeAgentTypeProjection::DataShape(child)) => Box::new([child]),
            Self::BuiltinVariant { cases, .. } => cases.iter().filter_map(Option::as_ref).collect(),
            Self::Map { key, value, .. }
            | Self::Traversal {
                source: key,
                mapping: value,
            }
            | Self::Stream {
                item: key,
                error: value,
            } => Box::new([key, value]),
            Self::Result {
                value: key,
                error: value,
                value_payload,
                error_payload,
            } => Box::new([key, value, value_payload, error_payload]),
            Self::Option { item, some_payload } => Box::new([item, some_payload]),
            Self::Function {
                parameters, result, ..
            } => parameters
                .iter()
                .chain(std::iter::once(result))
                .collect::<Vec<_>>()
                .into_boxed_slice(),
            Self::Nominal { arguments, .. }
            | Self::Opaque { arguments, .. }
            | Self::Tuple(arguments)
            | Self::Choice(arguments) => arguments.iter().collect::<Vec<_>>().into_boxed_slice(),
            Self::Record(fields) => fields
                .iter()
                .map(RuntimePlanRecordField::ty)
                .collect::<Vec<_>>()
                .into_boxed_slice(),
            Self::BoundType(_)
            | Self::Never
            | Self::Unit
            | Self::Bool
            | Self::Signed(_)
            | Self::Unsigned(_)
            | Self::F32
            | Self::F64
            | Self::String
            | Self::Color
            | Self::Char
            | Self::Bytes
            | Self::Duration
            | Self::Progress
            | Self::DenseNumeric(_)
            | Self::AgentValue
            | Self::PresentationResource(_)
            | Self::Agent(_) => Box::new([]),
        }
    }

    /// Rewrites every child reference while retaining the exact projection.
    pub fn try_map<T, E>(
        self,
        mut map: impl FnMut(R) -> Result<T, E>,
    ) -> Result<RuntimePlanTypeProjection<T>, E> {
        Ok(match self {
            Self::PresentationResource(kind) => {
                RuntimePlanTypeProjection::PresentationResource(kind)
            }
            Self::BoundType(reference) => RuntimePlanTypeProjection::BoundType(reference),
            Self::Never => RuntimePlanTypeProjection::Never,
            Self::Unit => RuntimePlanTypeProjection::Unit,
            Self::Bool => RuntimePlanTypeProjection::Bool,
            Self::Signed(width) => RuntimePlanTypeProjection::Signed(width),
            Self::Unsigned(width) => RuntimePlanTypeProjection::Unsigned(width),
            Self::F32 => RuntimePlanTypeProjection::F32,
            Self::F64 => RuntimePlanTypeProjection::F64,
            Self::String => RuntimePlanTypeProjection::String,
            Self::Color => RuntimePlanTypeProjection::Color,
            Self::Char => RuntimePlanTypeProjection::Char,
            Self::Bytes => RuntimePlanTypeProjection::Bytes,
            Self::Duration => RuntimePlanTypeProjection::Duration,
            Self::Progress => RuntimePlanTypeProjection::Progress,
            Self::DenseNumeric(dense) => RuntimePlanTypeProjection::DenseNumeric(dense),
            Self::EntityReference(reference) => {
                RuntimePlanTypeProjection::EntityReference(reference.try_map(map)?)
            }
            Self::AgentValue => RuntimePlanTypeProjection::AgentValue,
            Self::Range(child) => RuntimePlanTypeProjection::Range(map(child)?),
            Self::Iterator(child) => RuntimePlanTypeProjection::Iterator(map(child)?),
            Self::Sequence { kind, item } => RuntimePlanTypeProjection::Sequence {
                kind,
                item: map(item)?,
            },
            Self::Array { item, length } => RuntimePlanTypeProjection::Array {
                item: map(item)?,
                length,
            },
            Self::Map { kind, key, value } => RuntimePlanTypeProjection::Map {
                kind,
                key: map(key)?,
                value: map(value)?,
            },
            Self::Need(item) => RuntimePlanTypeProjection::Need(map(item)?),
            Self::Traversal { source, mapping } => RuntimePlanTypeProjection::Traversal {
                source: map(source)?,
                mapping: map(mapping)?,
            },
            Self::Stream { item, error } => RuntimePlanTypeProjection::Stream {
                item: map(item)?,
                error: map(error)?,
            },
            Self::Result {
                value,
                error,
                value_payload,
                error_payload,
            } => RuntimePlanTypeProjection::Result {
                value: map(value)?,
                error: map(error)?,
                value_payload: map(value_payload)?,
                error_payload: map(error_payload)?,
            },
            Self::Option { item, some_payload } => RuntimePlanTypeProjection::Option {
                item: map(item)?,
                some_payload: map(some_payload)?,
            },
            Self::BuiltinVariant { owner, cases } => RuntimePlanTypeProjection::BuiltinVariant {
                owner,
                cases: cases
                    .into_vec()
                    .into_iter()
                    .map(|payload| payload.map(&mut map).transpose())
                    .collect::<Result<Vec<_>, _>>()?
                    .into_boxed_slice(),
            },
            Self::ThreadHandle(child) => RuntimePlanTypeProjection::ThreadHandle(map(child)?),
            Self::Shared(child) => RuntimePlanTypeProjection::Shared(map(child)?),
            Self::Reference(child) => RuntimePlanTypeProjection::Reference(map(child)?),
            Self::Function {
                contract,
                parameters,
                result,
            } => RuntimePlanTypeProjection::Function {
                contract,
                parameters: try_map_boxed(parameters, &mut map)?,
                result: map(result)?,
            },
            Self::Nominal {
                nominal,
                layout,
                arguments,
            } => RuntimePlanTypeProjection::Nominal {
                nominal,
                layout,
                arguments: try_map_boxed(arguments, &mut map)?,
            },
            Self::Tuple(items) => RuntimePlanTypeProjection::Tuple(try_map_boxed(items, &mut map)?),
            Self::Record(fields) => {
                RuntimePlanTypeProjection::Record(try_map_record_fields(fields, &mut map)?)
            }
            Self::Choice(items) => {
                RuntimePlanTypeProjection::Choice(try_map_boxed(items, &mut map)?)
            }
            Self::Opaque {
                producer,
                admission,
                value_class,
                persistence,
                arguments,
            } => RuntimePlanTypeProjection::Opaque {
                producer,
                admission,
                value_class,
                persistence,
                arguments: try_map_boxed(arguments, &mut map)?,
            },
            Self::Agent(agent) => RuntimePlanTypeProjection::Agent(agent.try_map(map)?),
        })
    }

    /// Operational family selected when the complete checked projection is
    /// unavailable.
    #[must_use]
    pub const fn operational_type(&self) -> Option<RuntimeOperationalType> {
        match self {
            Self::Range(_) => Some(RuntimeOperationalType::Range),
            Self::Iterator(_) => Some(RuntimeOperationalType::Iterator),
            Self::Sequence { .. } | Self::Array { .. } => Some(RuntimeOperationalType::Sequence),
            Self::Tuple(_) => Some(RuntimeOperationalType::Tuple),
            Self::Record(_) => Some(RuntimeOperationalType::Record),
            Self::Choice(_) => Some(RuntimeOperationalType::Choice),
            Self::Result { .. } => Some(RuntimeOperationalType::Result),
            Self::Option { .. } => Some(RuntimeOperationalType::Option),
            Self::Map { .. } => Some(RuntimeOperationalType::Map),
            Self::Need { .. } => Some(RuntimeOperationalType::Need),
            Self::Traversal { .. } => Some(RuntimeOperationalType::Traversal),
            Self::Stream { .. } => Some(RuntimeOperationalType::Stream),
            Self::ThreadHandle(_) => Some(RuntimeOperationalType::ThreadHandle),
            Self::Shared(_) => Some(RuntimeOperationalType::Shared),
            Self::Reference(_) => Some(RuntimeOperationalType::Reference),
            Self::Function { .. } => Some(RuntimeOperationalType::Function),
            Self::Agent(agent) => Some(RuntimeOperationalType::Agent(agent.operational_type())),
            Self::BoundType(_)
            | Self::Never
            | Self::Unit
            | Self::Bool
            | Self::Signed(_)
            | Self::Unsigned(_)
            | Self::F32
            | Self::F64
            | Self::String
            | Self::Color
            | Self::Char
            | Self::Bytes
            | Self::Duration
            | Self::Progress
            | Self::DenseNumeric(_)
            | Self::EntityReference(_)
            | Self::AgentValue
            | Self::PresentationResource(_)
            | Self::BuiltinVariant { .. }
            | Self::Nominal { .. }
            | Self::Opaque { .. } => None,
        }
    }
}

fn try_map_record_fields<R, T, E>(
    fields: Box<[RuntimePlanRecordField<R>]>,
    map: &mut impl FnMut(R) -> Result<T, E>,
) -> Result<Box<[RuntimePlanRecordField<T>]>, E> {
    fields
        .into_vec()
        .into_iter()
        .map(|field| field.try_map(map))
        .collect::<Result<Vec<_>, _>>()
        .map(Vec::into_boxed_slice)
}

fn try_map_boxed<R, T, E>(
    values: Box<[R]>,
    map: &mut impl FnMut(R) -> Result<T, E>,
) -> Result<Box<[T]>, E> {
    values
        .into_vec()
        .into_iter()
        .map(map)
        .collect::<Result<Vec<_>, _>>()
        .map(Vec::into_boxed_slice)
}

impl<R> RuntimeAgentTypeProjection<R> {
    /// Transforms the retained Probe result without changing its Agent owner.
    ///
    /// # Errors
    /// Returns the mapper's error when translating the Probe result fails.
    pub fn try_map<T, E>(
        self,
        mut map: impl FnMut(R) -> Result<T, E>,
    ) -> Result<RuntimeAgentTypeProjection<T>, E> {
        Ok(match self {
            Self::DebugStatePath => RuntimeAgentTypeProjection::DebugStatePath,
            Self::ObservationFieldPath => RuntimeAgentTypeProjection::ObservationFieldPath,
            Self::Probe(value) => RuntimeAgentTypeProjection::Probe(map(value)?),
            Self::Predicate => RuntimeAgentTypeProjection::Predicate,
            Self::Observation => RuntimeAgentTypeProjection::Observation,
            Self::ObservedObject => RuntimeAgentTypeProjection::ObservedObject,
            Self::BoundingBox => RuntimeAgentTypeProjection::BoundingBox,
            Self::ActionName => RuntimeAgentTypeProjection::ActionName,
            Self::ActionTarget => RuntimeAgentTypeProjection::ActionTarget,
            Self::ActionResult => RuntimeAgentTypeProjection::ActionResult,
            Self::DataShape(value) => RuntimeAgentTypeProjection::DataShape(map(value)?),
            Self::EntityMetadata => RuntimeAgentTypeProjection::EntityMetadata,
            Self::SourceAnchor => RuntimeAgentTypeProjection::SourceAnchor,
            Self::SourcePosition => RuntimeAgentTypeProjection::SourcePosition,
            Self::ProjectGraphNeighborhood => RuntimeAgentTypeProjection::ProjectGraphNeighborhood,
            Self::ProjectGraphSymbol => RuntimeAgentTypeProjection::ProjectGraphSymbol,
            Self::ProjectGraphEdge => RuntimeAgentTypeProjection::ProjectGraphEdge,
            Self::ProjectFlowControlSummary => {
                RuntimeAgentTypeProjection::ProjectFlowControlSummary
            }
            Self::ProjectGraphSummary => RuntimeAgentTypeProjection::ProjectGraphSummary,
            Self::CaptureTarget => RuntimeAgentTypeProjection::CaptureTarget,
            Self::CaptureReference => RuntimeAgentTypeProjection::CaptureReference,
            Self::Resource => RuntimeAgentTypeProjection::Resource,
            Self::RagContextPack => RuntimeAgentTypeProjection::RagContextPack,
            Self::ObservedObjectId => RuntimeAgentTypeProjection::ObservedObjectId,
            Self::Diagnostics => RuntimeAgentTypeProjection::Diagnostics,
            Self::WaitError => RuntimeAgentTypeProjection::WaitError,
            Self::ViewportPoint => RuntimeAgentTypeProjection::ViewportPoint,
            Self::RagError => RuntimeAgentTypeProjection::RagError,
            Self::BinaryResourceBody => RuntimeAgentTypeProjection::BinaryResourceBody,
            Self::BinaryData => RuntimeAgentTypeProjection::BinaryData,
        })
    }

    /// Constructs an Agent type with no generic result. A Probe requires its
    /// result child and cannot be represented by a leaf row.
    #[must_use]
    pub const fn try_leaf(kind: RuntimeAgentOperationalType) -> Option<Self> {
        Some(match kind {
            RuntimeAgentOperationalType::DebugStatePath => Self::DebugStatePath,
            RuntimeAgentOperationalType::ObservationFieldPath => Self::ObservationFieldPath,
            RuntimeAgentOperationalType::Probe => return None,
            RuntimeAgentOperationalType::Predicate => Self::Predicate,
            RuntimeAgentOperationalType::Observation => Self::Observation,
            RuntimeAgentOperationalType::ObservedObject => Self::ObservedObject,
            RuntimeAgentOperationalType::BoundingBox => Self::BoundingBox,
            RuntimeAgentOperationalType::ActionName => Self::ActionName,
            RuntimeAgentOperationalType::ActionTarget => Self::ActionTarget,
            RuntimeAgentOperationalType::ActionResult => Self::ActionResult,
            RuntimeAgentOperationalType::DataShape => return None,
            RuntimeAgentOperationalType::EntityMetadata => Self::EntityMetadata,
            RuntimeAgentOperationalType::SourceAnchor => Self::SourceAnchor,
            RuntimeAgentOperationalType::SourcePosition => Self::SourcePosition,
            RuntimeAgentOperationalType::ProjectGraphNeighborhood => Self::ProjectGraphNeighborhood,
            RuntimeAgentOperationalType::ProjectGraphSymbol => Self::ProjectGraphSymbol,
            RuntimeAgentOperationalType::ProjectGraphEdge => Self::ProjectGraphEdge,
            RuntimeAgentOperationalType::ProjectFlowControlSummary => {
                Self::ProjectFlowControlSummary
            }
            RuntimeAgentOperationalType::ProjectGraphSummary => Self::ProjectGraphSummary,
            RuntimeAgentOperationalType::CaptureTarget => Self::CaptureTarget,
            RuntimeAgentOperationalType::CaptureReference => Self::CaptureReference,
            RuntimeAgentOperationalType::Resource => Self::Resource,
            RuntimeAgentOperationalType::RagContextPack => Self::RagContextPack,
            RuntimeAgentOperationalType::ObservedObjectId => Self::ObservedObjectId,
            RuntimeAgentOperationalType::Diagnostics => Self::Diagnostics,
            RuntimeAgentOperationalType::WaitError => Self::WaitError,
            RuntimeAgentOperationalType::ViewportPoint => Self::ViewportPoint,
            RuntimeAgentOperationalType::RagError => Self::RagError,
            RuntimeAgentOperationalType::BinaryResourceBody => Self::BinaryResourceBody,
            RuntimeAgentOperationalType::BinaryData => Self::BinaryData,
        })
    }

    #[must_use]
    pub const fn operational_type(&self) -> RuntimeAgentOperationalType {
        match self {
            Self::DebugStatePath => RuntimeAgentOperationalType::DebugStatePath,
            Self::ObservationFieldPath => RuntimeAgentOperationalType::ObservationFieldPath,
            Self::Probe(_) => RuntimeAgentOperationalType::Probe,
            Self::Predicate => RuntimeAgentOperationalType::Predicate,
            Self::Observation => RuntimeAgentOperationalType::Observation,
            Self::ObservedObject => RuntimeAgentOperationalType::ObservedObject,
            Self::BoundingBox => RuntimeAgentOperationalType::BoundingBox,
            Self::ActionName => RuntimeAgentOperationalType::ActionName,
            Self::ActionTarget => RuntimeAgentOperationalType::ActionTarget,
            Self::ActionResult => RuntimeAgentOperationalType::ActionResult,
            Self::DataShape(_) => RuntimeAgentOperationalType::DataShape,
            Self::EntityMetadata => RuntimeAgentOperationalType::EntityMetadata,
            Self::SourceAnchor => RuntimeAgentOperationalType::SourceAnchor,
            Self::SourcePosition => RuntimeAgentOperationalType::SourcePosition,
            Self::ProjectGraphNeighborhood => RuntimeAgentOperationalType::ProjectGraphNeighborhood,
            Self::ProjectGraphSymbol => RuntimeAgentOperationalType::ProjectGraphSymbol,
            Self::ProjectGraphEdge => RuntimeAgentOperationalType::ProjectGraphEdge,
            Self::ProjectFlowControlSummary => {
                RuntimeAgentOperationalType::ProjectFlowControlSummary
            }
            Self::ProjectGraphSummary => RuntimeAgentOperationalType::ProjectGraphSummary,
            Self::CaptureTarget => RuntimeAgentOperationalType::CaptureTarget,
            Self::CaptureReference => RuntimeAgentOperationalType::CaptureReference,
            Self::Resource => RuntimeAgentOperationalType::Resource,
            Self::RagContextPack => RuntimeAgentOperationalType::RagContextPack,
            Self::ObservedObjectId => RuntimeAgentOperationalType::ObservedObjectId,
            Self::Diagnostics => RuntimeAgentOperationalType::Diagnostics,
            Self::WaitError => RuntimeAgentOperationalType::WaitError,
            Self::ViewportPoint => RuntimeAgentOperationalType::ViewportPoint,
            Self::RagError => RuntimeAgentOperationalType::RagError,
            Self::BinaryResourceBody => RuntimeAgentOperationalType::BinaryResourceBody,
            Self::BinaryData => RuntimeAgentOperationalType::BinaryData,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::RuntimeAgentOperationalType;

    #[test]
    fn agent_operational_type_tags_are_stable_sparse_and_closed() {
        let cases = [
            (RuntimeAgentOperationalType::DebugStatePath, 0),
            (RuntimeAgentOperationalType::ObservationFieldPath, 1),
            (RuntimeAgentOperationalType::Probe, 2),
            (RuntimeAgentOperationalType::Predicate, 3),
            (RuntimeAgentOperationalType::Observation, 4),
            (RuntimeAgentOperationalType::ObservedObject, 5),
            (RuntimeAgentOperationalType::BoundingBox, 6),
            (RuntimeAgentOperationalType::ActionName, 7),
            (RuntimeAgentOperationalType::ActionTarget, 8),
            (RuntimeAgentOperationalType::ActionResult, 9),
            (RuntimeAgentOperationalType::DataShape, 12),
            (RuntimeAgentOperationalType::EntityMetadata, 13),
            (RuntimeAgentOperationalType::SourceAnchor, 14),
            (RuntimeAgentOperationalType::ProjectGraphNeighborhood, 15),
            (RuntimeAgentOperationalType::ProjectGraphSymbol, 16),
            (RuntimeAgentOperationalType::ProjectGraphEdge, 17),
            (RuntimeAgentOperationalType::CaptureTarget, 18),
            (RuntimeAgentOperationalType::CaptureReference, 19),
            (RuntimeAgentOperationalType::Resource, 20),
            (RuntimeAgentOperationalType::RagContextPack, 22),
            (RuntimeAgentOperationalType::ObservedObjectId, 23),
            (RuntimeAgentOperationalType::Diagnostics, 26),
            (RuntimeAgentOperationalType::WaitError, 27),
            (RuntimeAgentOperationalType::ViewportPoint, 28),
            (RuntimeAgentOperationalType::RagError, 30),
            (RuntimeAgentOperationalType::SourcePosition, 31),
            (RuntimeAgentOperationalType::ProjectFlowControlSummary, 32),
            (RuntimeAgentOperationalType::ProjectGraphSummary, 33),
            (RuntimeAgentOperationalType::BinaryResourceBody, 34),
            (RuntimeAgentOperationalType::BinaryData, 35),
        ];

        for (kind, tag) in cases {
            assert_eq!(kind.semantic_tag(), tag);
            assert_eq!(
                RuntimeAgentOperationalType::from_semantic_tag(tag),
                Some(kind)
            );
        }
        assert_eq!(RuntimeAgentOperationalType::from_semantic_tag(10), None);
        assert_eq!(RuntimeAgentOperationalType::from_semantic_tag(21), None);
        assert_eq!(RuntimeAgentOperationalType::from_semantic_tag(36), None);
        assert_eq!(
            RuntimeAgentOperationalType::from_semantic_tag(u8::MAX),
            None
        );
    }
    #[test]
    fn direct_type_child_count_matches_the_canonical_reference_roles() {
        use super::{RuntimeAgentTypeProjection, RuntimePlanTypeProjection as Type};
        let cases: Vec<Type<u8>> = vec![
            Type::Unit,
            Type::Bool,
            Type::Range(1),
            Type::Iterator(1),
            Type::ThreadHandle(1),
            Type::Shared(1),
            Type::Reference(1),
            Type::Need(1),
            Type::Map {
                kind: crate::entry::RuntimeMapKind::Ordered,
                key: 1,
                value: 2,
            },
            Type::Stream { item: 1, error: 2 },
            Type::Result {
                value: 1,
                error: 2,
                value_payload: 3,
                error_payload: 4,
            },
            Type::Option {
                item: 1,
                some_payload: 2,
            },
            Type::Tuple(Box::new([1, 2, 3])),
            Type::Choice(Box::new([1, 2])),
            Type::Agent(RuntimeAgentTypeProjection::Probe(1)),
            Type::Agent(RuntimeAgentTypeProjection::DataShape(1)),
        ];
        for projection in cases {
            assert_eq!(projection.child_count(), Some(projection.children().len()));
        }
    }
}
