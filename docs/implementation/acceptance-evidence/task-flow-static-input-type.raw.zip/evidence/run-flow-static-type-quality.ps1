$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$inputs=Get-Content -LiteralPath (Join-Path $e 'flow-reference-static-type-r1.inputs.json') -Raw | ConvertFrom-Json
function Confirm-Source {
    $patch=Read-GitBytes @('diff','--binary','--full-index','HEAD')
    if ((git rev-parse HEAD).Trim() -ne $inputs.base -or
        [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant() -ne $inputs.patchSha256) {
        throw 'Source differs from targeted nextest input'
    }
}
Confirm-Source
$rustPaths=@(git diff HEAD --name-only -- '*.rs')
$checks=@(
    @{ name='fmt'; command='rustfmt'; args=@('--check','--edition','2024','--config','skip_children=true')+$rustPaths },
    @{ name='check'; command='cargo'; args=@('check','--locked','--workspace','--all-targets','--all-features') },
    @{ name='clippy'; command='cargo'; args=@('clippy','--locked','--workspace','--all-targets','--all-features') }
)
$results=@(foreach ($check in $checks) {
    $log='flow-static-type-'+$check.name+'.log'
    $argsForCheck=$check.args
    $watch=[Diagnostics.Stopwatch]::StartNew()
    & $check.command @argsForCheck *> (Join-Path $e $log)
    $code=$LASTEXITCODE
    $watch.Stop()
    Confirm-Source
    [ordered]@{name=$check.name; command=$check.command; arguments=$argsForCheck; elapsedSeconds=$watch.Elapsed.TotalSeconds; exitCode=$code; log=$log}
})
[ordered]@{version=1;base=$inputs.base;patchSha256=$inputs.patchSha256;checks=$results} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $e 'flow-static-type-quality.json') -Encoding utf8
$results | ConvertTo-Json -Depth 4 -Compress
if (@($results | Where-Object {$_.exitCode -ne 0}).Count) { exit 1 }