$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$pin = Get-Content -Raw -LiteralPath "$root\principal-observation.final-input.json" | ConvertFrom-Json
$list = Get-Content -Raw -LiteralPath "$root\principal-observation.owner-list.json" | ConvertFrom-Json -Depth 80
$events = @(Get-Content -LiteralPath "$root\principal-observation.owner-nextest.jsonl" | ForEach-Object { $_ | ConvertFrom-Json -Depth 25 })
$selected = @(foreach ($suite in $list.'rust-suites'.PSObject.Properties) {
    foreach ($case in $suite.Value.testcases.PSObject.Properties) {
        if ($case.Value.'filter-match'.status -eq 'matches') {
            $suite.Value.'package-name' + '::' + $suite.Value.'binary-name' + '$' + $case.Name
        }
    }
})
$terminal = @($events | Where-Object { $_.type -eq 'test' -and $_.event -in @('ok','failed','ignored') })
if ($selected.Count -ne 1555 -or $terminal.Count -ne $selected.Count) { throw 'Owner count mismatch.' }
if (@($selected | Group-Object | Where-Object Count -ne 1).Count -ne 0 -or @($terminal | Group-Object name | Where-Object Count -ne 1).Count -ne 0) { throw 'Duplicate owner identity.' }
if (@(Compare-Object -CaseSensitive ($selected | Sort-Object) ($terminal.name | Sort-Object)).Count -ne 0) { throw 'Selected and terminal IDs differ.' }
$failures = @($terminal | Where-Object event -eq 'failed' | ForEach-Object name | Sort-Object)
$previous = Get-Content -Raw -LiteralPath "$root\prepared-arrow.owner-summary.json" | ConvertFrom-Json -Depth 20
if (@(Compare-Object -CaseSensitive $previous.Failures $failures).Count -ne 0) { throw 'Owner failure IDs changed.' }
$new = @($terminal | Where-Object { $_.name.Contains('$effect_row::prepared::closure::') })
if ($new.Count -ne 12 -or @($new | Where-Object event -ne 'ok').Count -ne 0) { throw 'New regressions did not pass.' }
if (@($terminal | Where-Object { $_.name.Contains('t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once') -and $_.event -eq 'ok' }).Count -ne 1) { throw '256-candidate boundary did not pass.' }
$summaries = @($events | Where-Object { $_.type -eq 'suite' -and $_.event -in @('ok','failed') })
if ($summaries.Count -ne 5 -or ($summaries | Measure-Object passed -Sum).Sum -ne 1549 -or ($summaries | Measure-Object failed -Sum).Sum -ne 6 -or @($terminal | Where-Object event -eq 'ignored').Count -ne 0) { throw 'Suite summaries disagree.' }
$sources = Get-Content -Raw -LiteralPath "$root\principal-observation.final-sources.json" | ConvertFrom-Json
foreach ($source in $sources) {
    if ((Get-FileHash -LiteralPath (Join-Path 'D:\git\arcweft' $source.Path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $source.SHA256) { throw ('Pinned source moved: ' + $source.Path) }
}
$receipt = Get-Content -Raw -LiteralPath "$root\principal-observation.owner-nextest.receipt.json" | ConvertFrom-Json
$quality = Get-Content -Raw -LiteralPath "$root\principal-observation.quality.json" | ConvertFrom-Json
if ($receipt.Tree -ne $pin.Tree -or $receipt.ExitCode -ne 100 -or $quality.Tree -ne $pin.Tree -or @($quality.Steps | Where-Object ExitCode -ne 0).Count -ne 0) { throw 'Pinned test/quality mismatch.' }
[ordered]@{
    Version=1; Base=$pin.Base; Checkpoint=$pin.Checkpoint; Tree=$pin.Tree
    Selected=$selected.Count; Passed=1549; Failed=6; Skipped=0; Suites=5
    NewTests=$new; FailureIdsUnchanged=$true; Failures=$failures
    SelectedIdsEqualTerminalIds=$true; DuplicateIds=0; CandidateBoundary256Passed=$true
    VerifiedSourcePaths=$sources.Count; ExecutionSeconds=67.205; AuditedAt=(Get-Date).ToString('o')
} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 -LiteralPath "$root\principal-observation.owner-summary.json"
Write-Output ('Audited ' + $terminal.Count + ' distinct owner results; 12 new passes; 6 unchanged failure IDs.')
