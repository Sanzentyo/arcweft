$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$publication = Get-Content -Raw -LiteralPath "$root\principal-observation.publication.json" | ConvertFrom-Json
$summary = Get-Content -Raw -LiteralPath "$root\principal-observation.owner-summary.json" | ConvertFrom-Json
if ($summary.Selected -ne 1555 -or -not $summary.SelectedIdsEqualTerminalIds -or -not $summary.FailureIdsUnchanged -or $summary.Tree -ne $publication.Tree) { throw 'Owner evidence is incomplete.' }
$files = [Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File | Where-Object {
    ($_.Name.StartsWith('principal-observation.') -or $_.Name -in @('audit-principal-observation.ps1','make-principal-observation-archive.ps1')) -and
    $_.Name -notin @('principal-observation.manifest.json','principal-observation.archive.json','principal-observation.docs-publication.json','principal-observation.docs-audit.json')
} | Sort-Object Name | ForEach-Object { $files.Add([ordered]@{name=$_.Name; path=$_.FullName}) }
$manifest = [ordered]@{
    version=1; source=$publication.Source; tree=$publication.Tree; base=$publication.Base
    phases=@(
        [ordered]@{name='initial-owner-check'; source=$publication.Parent; exit=0; note='All targets/all features. Initial inputs, diff and byte-exact new module snapshots are retained.'},
        [ordered]@{name='published-checkpoint-selection'; source=$publication.Parent; selected=46; passed=46; failed=0; exit=0; note='Intermediate publication receipt is retained; no claim of frontend integration.'},
        [ordered]@{name='regression-initial-check'; exit=101; selected=0; note='Six nonexistent EffectRow::pure test calls and one test control error-conversion mismatch; fixed before tests ran. Diff, new source snapshots and diagnostics are retained.'},
        [ordered]@{name='final-focused-selection'; tree=$publication.Tree; selected=58; passed=58; failed=0; exit=0; note='All recorded source hashes agree with final inputs; not added to full-owner counts.'},
        [ordered]@{name='final-owner'; tree=$publication.Tree; selected=1555; passed=1549; failed=6; skipped=0; exit=100; note='All twelve new regressions passed. Actual six recursive-body failure IDs are unchanged.'}
    )
    commands=@(
        'CARGO_INCREMENTAL=0 cargo check --locked -p arcweft-lang-sema --all-targets --all-features (initial inputs)',
        'CARGO_INCREMENTAL=0 cargo nextest list --locked -p arcweft-lang-sema --all-features --message-format json',
        'CARGO_INCREMENTAL=0 NEXTEST_EXPERIMENTAL_LIBTEST_JSON=1 cargo nextest run --locked -p arcweft-lang-sema --all-features --no-tests fail --no-fail-fast --message-format libtest-json --message-format-version 0.1',
        'CARGO_INCREMENTAL=0 cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features',
        'CARGO_INCREMENTAL=0 cargo fmt --all --check',
        'CARGO_INCREMENTAL=0 just structure-audit-gate'
    )
    files=@($files | ForEach-Object { $item=Get-Item -LiteralPath $_.path; [ordered]@{name=$_.name; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant()} })
}
$manifestPath = "$root\principal-observation.manifest.json"
$manifest | ConvertTo-Json -Depth 10 | Set-Content -Encoding utf8 -LiteralPath $manifestPath
$files.Add([ordered]@{name='manifest.json'; path=$manifestPath})
$archivePath = 'D:\git\arcweft\docs\implementation\acceptance-evidence\task-principal-effect-observations.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Refusing to overwrite a frozen archive.' }
$zip = [IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try { foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.path,$file.name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null} }
finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $files.Count) { throw 'Archive entry count mismatch.' }
    foreach ($file in $files) {
        $entry=$zip.GetEntry($file.name); $original=Get-Item -LiteralPath $file.path
        if ($null -eq $entry -or $entry.Length -ne $original.Length) { throw ('Archive length mismatch: '+$file.name) }
        $stream=$entry.Open()
        try { $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() }
        finally { $stream.Dispose() }
        if ($hash -ne (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()) { throw ('Archive hash mismatch: '+$file.name) }
    }
    $rawBytes=($zip.Entries | Measure-Object Length -Sum).Sum
} finally { $zip.Dispose() }
$archive=Get-Item -LiteralPath $archivePath
[ordered]@{version=1; source=$publication.Source; tree=$publication.Tree; entries=$files.Count; rawBytes=$rawBytes; bytes=$archive.Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); verifiedEveryEntryIncludingManifest=$true} | ConvertTo-Json | Set-Content -Encoding utf8 -LiteralPath "$root\principal-observation.archive.json"
Get-Content -LiteralPath "$root\principal-observation.archive.json"
