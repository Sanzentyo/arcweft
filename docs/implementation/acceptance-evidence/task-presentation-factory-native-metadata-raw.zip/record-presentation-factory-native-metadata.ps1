$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100 }
$stem='presentation-factory-native-metadata-reverse-20261101'
$matrix=Read-Record "$stem.matrix"
$publication=Read-Record 'checkpoint-presentation-factory-native-metadata.verified'
$testPublication=Read-Record 'checkpoint-presentation-factory-native-regressions.verified'
$head=(git rev-parse HEAD).Trim()
$source=$publication.commit
if($matrix.base -ne $source -or $matrix.status -ne 'terminal' -or $matrix.rows.Count -ne 5){throw 'Unexpected source or unfinished matrix'}
& git merge-base --is-ancestor $source $head
if($LASTEXITCODE -ne 0){throw 'Published source is not an ancestor of inspected main'}
foreach($row in $publication.paths){if((git rev-parse ('HEAD:'+$row.path)).Trim() -ne $row.blob){throw 'Published implementation blob changed'}}
$library=Read-Record "$stem.libraries.runtime.terminal-audit"
$owner=Read-Record 'presentation-factory-native-metadata-focus2-20261101.runtime.terminal-audit'
$baseline=Read-Record 'presentation-factory-native-metadata-baseline2-20261101.runtime.terminal-audit'
$cli=Read-Record 'presentation-factory-native-metadata.cli-target-coverage'
$comparison=Read-Record 'presentation-factory-native-metadata.cli-failure-comparison'
$generic=Read-Record "$stem.generic-coverage"
if($library.failed -ne 0 -or $owner.passed -ne 180 -or $owner.failed -ne 0 -or $baseline.failed -ne 2 -or $baseline.passed -ne 0 -or $generic.passed -ne 151){throw 'Unexpected owner, baseline or library result'}
$quality=@(foreach($suffix in @('workspace-check','clippy','structure','fmt')) {
    $record=Read-Record "presentation-factory-native-metadata-quality-20261101.$suffix"
    if($record.exitCode -ne 0){throw "Quality failed: $suffix"}
    [ordered]@{gate=$suffix;record=$record}
})
$freeze=Read-Record "$stem.source-freeze"
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Source drift'}
$bridge=@(foreach($name in @('presentation-factory-native-metadata-focus2-20261101','presentation-factory-native-metadata-quality-20261101')) {
    $priorFreeze=Read-Record "$name.source-freeze"
    $priorByPath=@{};foreach($row in $priorFreeze.paths){$priorByPath[$row.path]=$row.sha256}
    if($priorByPath.Count -ne $freeze.paths.Count -or @($freeze.paths|Where-Object {$priorByPath[$_.path] -ne $_.sha256}).Count){throw "Validated input bridge differs: $name"}
    [ordered]@{attempt=$name;base=$priorFreeze.base;publishedSource=$source;inputs=$freeze.paths.Count;pathHashDrift=0}
})
$original=Get-Content 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json' -Raw|ConvertFrom-Json
$changed=@($original.held|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($changed.Count -ne 1 -or $changed[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or (git hash-object -- $changed[0].path).Trim() -ne '4df23c4afc860ca51ff3255befe87b69a16de39b'){throw 'Original WIP changed'}
$untracked=@(git ls-files --others --exclude-standard)
if($untracked.Count -ne 6 -or @($untracked|Where-Object {$_ -notin @($original.held.path)}).Count){throw 'Original untracked set changed'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath=Join-Path $evidence 'task-presentation-factory-native-metadata-raw.zip'
$receiptPath=Join-Path $evidence 'task-presentation-factory-native-metadata.json'
if((Test-Path $zipPath) -or (Test-Path $receiptPath)){throw 'Immutable evidence exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    $_.Name -like 'presentation-factory-native-metadata-*' -or $_.Name -like 'presentation-factory-native-metadata.*' -or
    $_.Name -like 'checkpoint-presentation-factory-native-metadata.*' -or $_.Name -like 'checkpoint-presentation-factory-native-regressions.*' -or
    $_.Name -in @('run-presentation-factory-native-metadata-quality.ps1','run-presentation-factory-native-metadata-reverse.ps1','audit-presentation-factory-native-metadata-generic.ps1','derive-presentation-factory-native-metadata-validation.ps1','record-presentation-factory-native-metadata.ps1','update-presentation-factory-native-metadata-docs.ps1','audit-presentation-factory-native-metadata-docs.ps1','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1')
})+@(Get-ChildItem "$taskTemp/presentation-factory-native-metadata-quality-20261101.structure-report" -File)
$files=@($files|Sort-Object FullName -Unique)
$raw=@(foreach($file in $files){[ordered]@{name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try { for($index=0;$index -lt $files.Count;$index++) {
    $entry=$archive.CreateEntry($raw[$index].name,[IO.Compression.CompressionLevel]::Optimal)
    $stream=$entry.Open();try{$bytes=[IO.File]::ReadAllBytes($files[$index].FullName);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
}}finally{$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {
    if($archive.Entries.Count -ne $raw.Count){throw 'Raw entry count differs'}
    foreach($row in $raw){$entry=$archive.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw "Raw entry differs: $($row.name)"}}
}finally{$archive.Dispose()}
$normal=@($matrix.rows|Where-Object {$_.group -in @('libraries','cli-unit','cli-integration')})
$result=[ordered]@{
    version=1;date='2026-11-01';source=$source;inspectedHead=$head;status='Factory static metadata admission before Native capture evaluation and builder CallExpr publication verified; whole live contour and CLI acceptance remain separate'
    publication=$publication;testOnlyKnownFailingPublication=$testPublication;sourceInputs=$freeze.paths.Count;sourceDrift=0
    validatedInputBridge=$bridge
    initialCatalog=(Read-Record 'presentation-factory-native-metadata-baseline1-20261101.catalog')
    baseline=$baseline;firstOwner=(Read-Record 'presentation-factory-native-metadata-focus1-20261101.runtime.terminal-audit');owner=$owner;quality=$quality
    matrix=$matrix;library=$library;cli=$cli;cliFailureComparison=$comparison;genericCoverage=$generic
    libraryCaseComparison=(Read-Record 'presentation-factory-native-metadata.library-case-comparison')
    normalGroups=[ordered]@{passed=[int]($normal|ForEach-Object {$_.terminal.passed}|Measure-Object -Sum).Sum;failed=[int]($normal|ForEach-Object {$_.terminal.failed}|Measure-Object -Sum).Sum;ignored=[int]($normal|ForEach-Object {$_.terminal.skipped}|Measure-Object -Sum).Sum}
    implementation=@('The existing PlanValueAuthority borrows the real admitted inventory or builder phase tables. Factory retained body, resource, result owner and exact input semantic identities use this authority; equal scalar representation does not make distinct identities interchangeable.','RuntimePresentationFactoryCall validates the physical-to-logical ABI, closed tuple/array spread shapes, overlap, bounds and complete argument coverage before Native capture evaluation or builder CallExpr publication. The original physical operand vector retains source evaluation order.','The shared original-plan/AWBC factory validation still checks body identity in the version-1 retained-product domain. No fake RuntimePlan, reconstructed Source, executable grant or persistent parallel metadata model is introduced.')
    corrections=@('The first baseline catalog tried to invoke a private engine evaluator from a plan test module. The fixture was split between its legitimate engine and builder owners without broadening production visibility.','The valid baseline then reproduced two failures: Native evaluated the capture probe once before rejecting its wrong semantic identity; the builder published a CallExpr with a wrong input identity. This is concrete evidence for the newly repaired boundary, not grounds to revoke previously accepted factory execution or Generic Match.','The test-only checkpoint was intentionally published with both known failures under the user instruction allowing intermediate non-green commits. Production fix and final validation use distinct recorded input snapshots.')
    ownershipReview='Factory owns complete metadata and retained-product admission; existing borrowed phase authority owns original type lookup; builder and Engine call this authority at their publication/evaluation boundaries. The transient optional-semantic-ID vector is bounded by the admitted factory input product and does not retain values or grants. No layer, wire tag, marker or v1 digest change.'
    limits=@('Builder argument subexpressions may be lowered before the CallExpr admission; this does not establish whole-builder failure atomicity.','Later executable-body, registration, resource and whole-live-contour failures remain distinct from the static metadata rejection proven before Native argument evaluation. Explicit scope capability, View/Removed producers, command/method and driver are not completed by this change.','Default/Wasm, doctest, Tier 2 and final Native/Web image parity were not rerun for this input.','CLI failure-ID equality is not evidence of equal causes; source-specific raw results are preserved.')
    priorEvidence='task-presentation-factory-preflight.json'
    originalWip=[ordered]@{tracked=14;actualUntracked=6;unchangedOldHashes=19;benchWorkingBlob='4df23c4afc860ca51ff3255befe87b69a16de39b';heldPatchSha256=$publication.heldPatchSha256}
    raw=[ordered]@{path='task-presentation-factory-native-metadata-raw.zip';sha256=(Get-FileHash $zipPath).Hash.ToLowerInvariant();entryCount=$raw.Count;entryDrift=0;entries=$raw}
    recordedAt=[DateTime]::UtcNow.ToString('o')
}
$result|ConvertTo-Json -Depth 100|Set-Content $receiptPath -Encoding utf8
[ordered]@{source=$source;libraryPassed=$library.passed;libraryFailed=$library.failed;normalPassed=$result.normalGroups.passed;ownerPassed=$owner.passed;genericPassed=$generic.passed;cliPassed=$cli.passed;cliFailed=$cli.failed;rawEntries=$raw.Count;rawSha256=$result.raw.sha256;rawBytes=(Get-Item $zipPath).Length}|ConvertTo-Json -Compress
