use super::*;
use crate::{
    engine::Engine,
    entry::{RuntimeCallableId, RuntimeSchemaLimits},
    pattern::RuntimeSemanticTypeId,
    presentation::RuntimePresentationFactoryCall,
    pure::{RuntimeExternalCallBackend, RuntimeExternalCallContext, VmRuntimePureCallBackend},
    value::{RuntimeCallTarget, RuntimeEvalError},
};
use arcweft_interaction_model::presentation::{
    PresentationArgumentKey, PresentationArgumentRole, PresentationCallableId,
    PresentationResourceKind,
};
use std::{cell::Cell, rc::Rc, sync::Arc};

const BOOL: RuntimeSemanticTypeId = RuntimeSemanticTypeId::from_bytes([91; 32]);
const ALIAS: RuntimeSemanticTypeId = RuntimeSemanticTypeId::from_bytes([92; 32]);
const RESOURCE: RuntimeSemanticTypeId = RuntimeSemanticTypeId::from_bytes([93; 32]);
const HANDLE: RuntimeSemanticTypeId = RuntimeSemanticTypeId::from_bytes([94; 32]);

fn fixture() -> (RuntimePlanBuilder, Arc<RuntimePresentationFactoryCall>) {
    let inputs: Box<[_]> = Box::new([PresentationArgumentKey::try_new(
        PresentationArgumentRole::Parameter,
        Some("channel".into()),
    )
    .unwrap()]);
    let body = RuntimePresentationFactoryCall::retained_body_identity(
        PresentationCallableId::Image,
        &inputs,
        RESOURCE,
        &crate::plan::RuntimeTypeScope::root(),
        1,
        |_| Some(BOOL),
    )
    .unwrap();
    let owner =
        RuntimeOpaqueTypeOwner::presentation_handle(PresentationResourceKind::Image, HANDLE);
    let mut builder = RuntimePlanBuilder::new();
    builder
        .admit_type_batch(
            [
                crate::plan::RuntimePlanTypeSeed::new(BOOL, RuntimePlanTypeProjection::Bool),
                crate::plan::RuntimePlanTypeSeed::new(ALIAS, RuntimePlanTypeProjection::Bool),
                crate::plan::RuntimePlanTypeSeed::new(
                    RESOURCE,
                    RuntimePlanTypeProjection::PresentationResource(
                        PresentationResourceKind::Image,
                    ),
                ),
                crate::plan::RuntimePlanTypeSeed::new(
                    body,
                    RuntimePlanTypeProjection::Tuple(Box::new([BOOL])),
                ),
                crate::plan::RuntimePlanTypeSeed::new(
                    HANDLE,
                    RuntimePlanTypeProjection::Opaque {
                        producer: owner.producer().clone(),
                        admission: owner.admission(),
                        value_class: owner.value_class(),
                        persistence: owner.persistence(),
                        arguments: Box::new([]),
                    },
                ),
            ],
            [],
        )
        .unwrap();
    let call = Arc::new(
        RuntimePresentationFactoryCall::try_new(
            PresentationCallableId::Image,
            inputs,
            RESOURCE,
            body,
            RuntimeSchemaLimits::engine_default(),
        )
        .unwrap(),
    );
    (builder, call)
}

#[test]
fn factory_builder_rejects_wrong_input_and_result_types_before_expression_publication() {
    for (input, result, accepted) in [
        (BOOL, HANDLE, true),
        (ALIAS, HANDLE, false),
        (BOOL, BOOL, false),
    ] {
        let (builder, call) = fixture();
        let expression = builder.lower_expression(RuntimeExprSeed::new(
            result,
            RuntimeExprSeedKind::Call {
                callee: RuntimeCallTarget::PresentationFactory(call),
                args: Box::new([RuntimeCallArgumentSeed::new(
                    RuntimeExprSeed::new(
                        input,
                        RuntimeExprSeedKind::Value(RuntimeValue::Bool(true)),
                    ),
                    RuntimeCallArgumentMode::Value,
                    0,
                )]),
            },
        ));
        assert_eq!(
            expression.is_ok(),
            accepted,
            "input {input:?}, result {result:?}: {expression:?}"
        );
    }
}

struct Probe {
    target: RuntimeCallTarget,
    calls: Rc<Cell<usize>>,
}

impl RuntimeExternalCallBackend for Probe {
    fn call_external(
        &mut self,
        context: &RuntimeExternalCallContext,
        callee: &RuntimeCallTarget,
        args: &[RuntimeValue],
    ) -> Option<Result<RuntimeValue, RuntimeEvalError>> {
        assert_eq!(callee, &self.target);
        assert!(context.is_program_bound());
        assert!(args.is_empty());
        self.calls.set(self.calls.get() + 1);
        Some(Ok(RuntimeValue::Bool(true)))
    }
}

#[test]
fn native_factory_rejects_input_metadata_before_evaluating_the_capture() {
    let (builder, call) = fixture();
    let plan = builder.finish().unwrap();
    let input_type = plan.type_table().id_for_semantic(ALIAS).unwrap();
    let result_type = plan.type_table().id_for_semantic(HANDLE).unwrap();
    let target = RuntimeCallTarget::callable(RuntimeCallableId::from_checked_digest([95; 32]));
    let expression = RuntimeExpr::from_admitted_parts(
        result_type,
        RuntimeExprKind::Call {
            callee: RuntimeCallTarget::PresentationFactory(call),
            args: vec![RuntimeCallArgument::from_admitted_parts(
                RuntimeExpr::from_admitted_parts(
                    input_type,
                    RuntimeExprKind::Call {
                        callee: target.clone(),
                        args: vec![],
                    },
                ),
                RuntimeCallArgumentMode::Value,
                0,
            )],
        },
    );
    let calls = Rc::new(Cell::new(0));
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(Probe {
        target,
        calls: Rc::clone(&calls),
    });
    let mut engine = Engine::new(plan);
    let error = engine
        .evaluate_expr_with_backend(&expression, &mut backend)
        .unwrap_err();
    assert!(error.to_string().contains("requires type"), "{error}");
    assert_eq!(
        calls.get(),
        0,
        "invalid static factory metadata must not evaluate a capture"
    );
}
