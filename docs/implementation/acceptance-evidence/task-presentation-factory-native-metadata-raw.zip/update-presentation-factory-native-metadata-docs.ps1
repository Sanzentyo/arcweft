$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$receipt=Get-Content 'docs/implementation/acceptance-evidence/task-presentation-factory-native-metadata.json' -Raw|ConvertFrom-Json -Depth 100
$source=$receipt.source
$inputs=$receipt.sourceInputs
$lib=$receipt.library
$normal=$receipt.normalGroups
$cli=$receipt.cli
$compare=$receipt.cliFailureComparison
$link='[本Sourceの再現・修復・全逆依存原本](acceptance-evidence/task-presentation-factory-native-metadata.json)'
$check=@($receipt.matrix.rows|Where-Object group -eq 'cli-check')[0].terminal
$extra=@($receipt.matrix.rows|Where-Object group -eq 'cli-extra')[0].terminal
$unit=@($receipt.matrix.rows|Where-Object group -eq 'cli-unit')[0].terminal
$integration=@($receipt.matrix.rows|Where-Object group -eq 'cli-integration')[0].terminal
$statusPath='docs/implementation/current-status.md'
$text=[IO.File]::ReadAllText($statusPath)
$header='確認日: 2026-11-01。公開実装Sourceは{0}。元14 tracked／6 actual untracked WIPを保持し、今回の検証はその作業差分を含む{1:N0}入力で行った。各行の結果はその入力・境界に限り、別runの結果を一つの全PASSへ合算しない。' -f $source,$inputs
$text=[regex]::Replace($text,'(?m)^確認日:.*$',$header)
$genericBefore=(Get-Content "$taskTemp/presentation-factory-native-metadata.docs-before.json" -Raw|ConvertFrom-Json).genericRow
$genericCurrent=$genericBefore.Replace('今回の12180810','受入後の12180810')
if($genericBefore -ceq $genericCurrent -or -not $text.Contains($genericBefore)){throw 'Expected historical Generic Match wording missing'}
$text=$text.Replace($genericBefore,$genericCurrent)
$replacements=[ordered]@{}
$replacements['Presentation resource本体・Source factory実行']='| Presentation resource本体・Source factory実行 | **Source imageのNative／decoded AWBC slice・metadata事前検査を検証・公開。staging全体は受入前** | 公開{0}。元Source・実executable・key・tuple型・元invocationを持つaffine本体を保持する。builderが同じBool表現の別semantic identityを受け入れ、Nativeが型拒否前にcaptureを評価していた2再現を修復。実inventory／builderの借用型authorityでbody・resource・Handle結果型・入力identityとABI dispositionをCallExpr公開前／Native引数評価前に検査する。Core／Compiler 180件PASSはbuilderのSource順を保つ異順ABI・tuple／closed array spread、実Source imageの両backend実行・評価順12・Image／Root Handle・AWBC各step保存復元を含む。以前のAWBC入力移動前10拒否・コピー前metadata上限の受入も維持する。明示scope capability、View生成、command／method・driver、全live候補の構築前検査と後段registrationの失敗原子性は別境界。{1}。 |' -f $source,$link
$replacements['CLI・全 consumer の統合受入']='| CLI・全 consumer の統合受入 | **CLI失敗{0}件を保持・統合受入は未完了** | {1}・{2:N0}入力の現行CLI全12 targetを下表で照合した。前Sourceの失敗IDとの比較は同一{3}・新規{4}・解消{5}・未選択{6}。ID一致を原因同一とはしない。Presentation command／method・driverやJLREQ geometryの未達を、受入済みの別機能へ戻さない。{7}。 |' -f $cli.failed,$source,$inputs,$compare.sameFailureIds.Count,$compare.newFailureIds.Count,$compare.resolvedFailureIds.Count,$compare.unselectedPriorFailures.Count,$link
$replacements['Presentation factory／共有値の逆依存matrix']='| Presentation factory／共有値の逆依存matrix | **Coreの53 package選択。通常3群 {0} PASS／{1} FAIL／{2} ignored** | Source {3}・{4:N0}入力。library／integrationは{5} PASS／{6} FAIL、CLI unit {7} PASS、通常6 integration target {8} PASS。同一入力の3 commandの合計であり、前Sourceと異なる62 package範囲の件数を合算しない。実行case 0のcompile選択は{9} package。同範囲の旧6,909 case ID（ignoredを含む）を保持し、追加3・削除0。既受入Generic Match 151 IDは151／151 PASS。case／Source／EXE差分0。{10}。 |' -f $normal.passed,$normal.failed,$normal.ignored,$source,$inputs,$lib.passed,$lib.failed,$unit.passed,$integration.passed,$lib.noMatchingSelectedTests.Count,$link
$replacements['CLI追加check target']='| CLI追加check target | **{0} PASS／{1} FAIL／{2} ignored** | {3}・{4:N0}入力。前Source e71871a2a2badc8d5346f5d7a7466f627b8de2feの保持43失敗IDとの比較は同一{5}・新規{6}・解消{7}・未選択{8}。入力が異なるため、IDだけから原因同一とは判定しない。{9}。 |' -f $check.passed,$check.failed,$check.skipped,$source,$inputs,$compare.sameFailureIds.Count,$compare.newFailureIds.Count,$compare.resolvedFailureIds.Count,$compare.unselectedPriorFailures.Count,$link
$replacements['CLI追加3 integration target／全target照合']='| CLI追加3 integration target／全target照合 | **追加{0} PASS。全12 targetは{1} unique実行・{2} PASS／{3} FAIL・{4} ignored** | 同じ{5}・{6:N0}入力でbracket_numeric_batch、environment_callable_tensor、native_host_contractsを含む全lib／bin／integrationを計4 commandで照合した。case重複0、zero-case targetのcompile選択をruntimeと区別する。{7}。 |' -f $extra.passed,$cli.executedUnique,$cli.passed,$cli.failed,$cli.ignored,$source,$inputs,$link
$replacements['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **各gate終了0・構造blocking0・警告は残存** | {0}と同一の{1:N0}入力。全97 package・全target・全feature・lockedのcheck／Clippy、変更7 Rust path fmtは終了0。構造は3293 files／3163 Rust files・1785181 physical Rust LOC・384 review trigger・blocking0。default／Wasm・doctest・Tier 2は今回未再実行。{2}。 |' -f $source,$inputs,$link
foreach($name in $replacements.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($name)+' \|.*$'
    if([regex]::Matches($text,$pattern).Count -ne 1){throw "Expected one status row: $name"}
    $text=[regex]::Replace($text,$pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($match) $replacements[$name]})
}
[IO.File]::WriteAllText($statusPath,$text,[Text.UTF8Encoding]::new($false))
$history=[IO.File]::ReadAllText("$taskTemp/presentation-factory-native-metadata.history-template.txt")
$history=$history -f $source,$receipt.testOnlyKnownFailingPublication.commit,$inputs,$lib.passed,$lib.failed,$lib.skipped,$unit.passed,$integration.passed,$normal.passed,$normal.failed,$lib.noMatchingSelectedTests.Count,$cli.executedUnique,$cli.passed,$cli.failed,$cli.ignored,$check.passed,$check.failed,$check.skipped,$extra.passed,$compare.sameFailureIds.Count,$compare.newFailureIds.Count,$compare.resolvedFailureIds.Count,$compare.unselectedPriorFailures.Count,$receipt.raw.entryCount,$receipt.raw.sha256
[IO.File]::AppendAllText('docs/implementation/convergence-evidence-history.md',$history,[Text.UTF8Encoding]::new($false))
Write-Output 'Current status reconciled; historical bytes retained as prefix'
