$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/extracted-effect-read.publication.json"|ConvertFrom-Json
$validation=Get-Content -Raw "$scratch/extracted-effect-read.docs-validation.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or $validation.Source -ne $pub.Source -or !$validation.GenericMatchRowUnchanged -or !$validation.ChangedLinksResolve){throw 'Documentation input changed'}
$paths=@('docs/implementation/current-status.md','docs/implementation/convergence-evidence-history.md','docs/implementation/acceptance-evidence/task-extracted-effect-read.raw.zip')
$pins=@($paths|ForEach-Object {[pscustomobject]@{Path=$_;Blob=(git hash-object -- $_).Trim();SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}})
git add -- @paths
if($LASTEXITCODE){throw 'Documentation stage failed'}
if(@(Compare-Object -CaseSensitive @($paths|Sort-Object) @(git diff --cached --name-only|Sort-Object)).Count){throw 'Unexpected staged paths'}
git diff --cached --check
if($LASTEXITCODE){throw 'Staged documentation whitespace failed'}
git diff --cached --binary > "$scratch/extracted-effect-read.docs-staged.patch"
git diff --cached --stat
git commit -m 'Record extracted effect reads and private admission validation'
if($LASTEXITCODE){throw 'Documentation commit failed'}
$head=(git rev-parse HEAD).Trim()
$tree=(git rev-parse 'HEAD^{tree}').Trim()
if((git rev-parse 'HEAD^') -ne $pub.Source){throw 'Documentation parent differs'}
foreach($pin in @($pub.Paths)+@($pins)){
    if((git rev-parse "${head}:$($pin.Path)") -ne $pin.Blob -or (git hash-object -- $pin.Path) -ne $pin.Blob){throw 'Tested/published bytes differ'}
}
git push origin main
if($LASTEXITCODE){throw 'Documentation push failed'}
$remote=(git ls-remote origin refs/heads/main).Split()[0]
if($remote -ne $head -or (git rev-parse origin/main) -ne $head -or @(git diff --name-only HEAD).Count -or @(git diff --cached --name-only).Count){throw 'Final main state differs'}
[ordered]@{Version=1;Source=$pub.Source;SourceTree=$pub.Tree;DocumentationCommit=$head;DocumentationTree=$tree;DocumentationParent=$pub.Source;RemoteVerified=$remote;NonForcedPush=$true;SourceAndDocumentationBlobsVerified=$pub.Paths.Count+$pins.Count;SourcePaths=$pub.Paths;DocumentationPaths=$pins;TrackedChanges=0;Untracked=@(git ls-files --others --exclude-standard);GenericMatchRowUnchanged=$true;HistoryPrefixPreserved=$true;Finished=(Get-Date -Format o)}|ConvertTo-Json -Depth 9|Set-Content -Encoding utf8 "$scratch/extracted-effect-read.docs-publication.json"
Write-Output "PUBLISHED $head; verified $($pub.Paths.Count+$pins.Count) source/documentation blobs"
git status --short --branch
