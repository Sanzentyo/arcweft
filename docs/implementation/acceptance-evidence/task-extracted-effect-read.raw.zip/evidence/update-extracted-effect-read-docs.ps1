$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/extracted-effect-read.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/extracted-effect-read.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$scratch/extracted-effect-read.impact.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/extracted-effect-read.quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/extracted-effect-read.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/extracted-effect-read.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Documentation base changed'}
if($owner.Selected -ne 1768 -or $owner.Passed -ne 1762 -or $owner.Failed -ne 6 -or !$owner.IdsEqual -or $quality.Steps.Count -ne 2 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.ExitCode -ne 0 -or !$archive.AllEntriesVerified -or $impact.ReverseConsumersRerun){throw 'Final validation differs'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previousStatus=[IO.File]::ReadAllText((Join-Path $PWD $status))
$previousHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previousStatus,'(?m)^\| Generic Match[^\r\n]+').Value
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']="| 再帰関数値の終端効果 | **既受入を維持。型移送・graph所有・候補転送と未公開候補の型保持を検証・公開。本体内の関数値推論は継続** | 最新Source ``$($pub.Source)``。型・const・効果・predicateの移送は共通のscoped foldを使い、置換値をsource環境で再解釈しない。型検査済み本体の効果closureには元のformal・D・実call方程式を扱うscheme代数を接続済み。prepared値componentは別graphを作らず元ownerを保持し、候補の転送は変更journalを使う。live／元base＋抽出deltaの参照解決を一つのread viewへ統合し、未公開のrow・predicate・宣言headerを復元せず型として保持できる。元の準備はaffine payloadとして保持し、完成型への投影には実本体の確定と既存のclosureを使う。caller-bound recursion・共有prefix・Free許可／reifyの既受入を維持する。型検査前の宣言scheme登録、prepared型を含む全関数値port／ΓとAnalyzerの統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[本体closure](convergence-evidence-history.md#callable-body-declaration-scheme-closure)・[型移送](convergence-evidence-history.md#shared-scoped-type-projection)・[所有と転送](convergence-evidence-history.md#shared-prepared-effect-owner-and-mutation-journal)・[抽出候補の読取り](convergence-evidence-history.md#extracted-effect-reads-and-prepared-value-admission)。 |"
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,762 PASS／6 FAIL。後続matrixは元入力の実測を保持** | Source ``$($pub.Source)`` のlocked・全feature Sema lib／tests 1,768件を$($owner.ExecutionSeconds)秒で実行。直前1,765 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeは22 packageで不変。変更はSema privateな効果読取り・header lease・型保持・値admissionに限り、当該consumerを全owner runで検証した。後続21 package／107 targetは今回未再実行で、Source ``$($impact.BaselineConsumerSource)`` の2,510件／2,507 PASS／2 FAIL／1 SKIPを元入力の実測として保持する。公開型・checked出力・codec・Cargo／feature・I/Oは変更しない。[今回のowner・選定理由](acceptance-evidence/task-extracted-effect-read.raw.zip)・[consumer原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **所有Semaの品質・fmt・構造は今回終了0。workspace品質は元入力の実測を保持** | Source ``$($pub.Source)`` のlocked Sema全target／全feature check・Clippy、workspace fmt、構造gateを実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。9 Rust path・$($owner.PhysicalGrowth)物理LOC増。数学ownerのread viewへlive／extractedの参照解決を集約し、型保持を移した。viewは借用だけを許し、公開・完成の権限を与えない。公開API・依存・I/O・codec・version・既定予算は不変、fan-in／out $($owner.FanIn)／$($owner.FanOut)。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。workspace全target／全feature check・ClippyとSema doctest 2件はSource ``$($impact.BaselineConsumerSource)`` の実測を保持し、今回の再実行としない。後続nextest・Tier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入も今回未実行。[今回の品質・構造](acceptance-evidence/task-extracted-effect-read.raw.zip)・[workspace原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$current=$previousStatus
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
    if([regex]::Matches($current,$pattern).Count -ne 1){throw "Missing/duplicate row $key"}
    $replacement=$rows[$key]
    $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-14。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
$entry=@"

## Extracted effect reads and prepared value admission

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの9 Rust pathを通常commit／非force pushし、検証dirty bytes・commit・公開blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- PreparedEffectReadViewは実graphと、必要な場合だけ元の抽出deltaを借りる。exact issuer／baseを元のDecisionControlで検証してから借用を発行し、immutable borrowの間は基点を変更できない。delta全体を保持したまま、そこで導入・変更したfunction／row／predicateと元baseを同じownerの参照として解決する。graph、定義map、checkpoint／deltaのcapabilityを複製せず、読取りのためのrestoreや公開を行わない。live graphの既存readerも同じlookupへ移した。
- 元の宣言header leaseはviewで検証でき、未使用を含む全formalと元のDを保持する。Preparedな型の保持と値componentのadmissionはこのread capabilityを使い、sourceのrow／predicateが未公開でも保持する。元Source Γやproducerの相関は置き換えない。viewは効果の完成や候補の選択を証明せず、単独のborrowed readをAnalyzer全port・joint sealへ接続した判定でもない。
- 新3件は、live baseではDeclaredの宣言が抽出候補内ではBodyPreparedである場合と、候補内で新規に宣言された未完了Sの元header、別候補／foreign issuer／metadataだけ変わったbaseの拒否、全preflight予算点と元の取消信号での原子性を検証する。値componentのケースは実affine payloadを準備として保持し、component解放後だけ元payloadを取り出して一度restoreし、実本体を確定して既存closureからcanonicalな関数型へ投影する。pure body、偽のFree ID、未知効果の代用品、Source復元による補完は作らない。開発check 0とsubset 155 PASSのlogも保持し、完全入力snapshotのない開発runを最終Sourceの証拠にしない。
- 最終ownerは1,768件／1,762 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,765 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6件と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。Sema全target／全feature check・Clippy、workspace fmt、構造gateは終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。9 path・$($owner.PhysicalGrowth)物理LOC増。read moduleは数学ownerの借用・参照解決を所有し、型保持は既存の共通foldとscalar admissionを使う。実LOC・byte size・test分類、fan-in $($owner.FanIn)／fan-out $($owner.FanOut)を保持した。公開API・依存・I/O・codec・version・既定予算は変更せず、CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- fresh full metadata／全target reverse treeの22 packageとCargo入力が不変であることを照合した。変更APIとconsumerはSema内のprivateな読取り・型保持・値admissionに限り、full ownerで確認した。Source ``$($impact.BaselineConsumerSource)`` の後続21 package／107 target・2,510件／2,507 PASS／2 FAIL／1 SKIP、workspace全target／全feature品質、doctest 2件を元入力の実測として保持し、今回の再実行へ合算しない。Tier 2と新しい実機受入は未実行。
- Supersedes: 型の保持がlive graphだけを読んでいた境界を、元baseと抽出済み準備を公開せず読める境界へ訂正する。現状行に重ねていたcut別の説明は、共通fold・scheme代数・graph所有／転送・read admissionという現在の仕組みへまとめ、過去のSHA・実測・訂正理由は履歴に保持した。今回の失敗6件は未解消であり、Generic Match、本体効果closure、型移送、caller-bound recursion、共有prefix、Free許可／reifyの各受入を戻さない。残作業は[current-status.md](current-status.md)の該当行だけへ集約する。

原本 [task-extracted-effect-read.raw.zip](acceptance-evidence/task-extracted-effect-read.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
foreach($document in @($rows.Values)+@($entry)){
    foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
        $target=$match.Groups[1].Value
        if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
        if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link $target"}
    }
}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText((Join-Path $PWD $history),"`n"+$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($previousHistory.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if($after.Length -le $previousHistory.Length -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($previousHistory)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical archive index changed'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$previousHistory.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true;FinalWhitespaceExit=0}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/extracted-effect-read.docs-validation.json"
git diff --stat
