#![allow(dead_code)]
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;

use std::collections::BTreeSet;
use std::convert::Infallible;
use decision::{DecisionControl, DecisionWork, EffectDecision};

#[derive(Default)]
struct Meter(usize);
impl DecisionControl for Meter {
    type Error = Infallible;
    fn charge(&mut self, _: DecisionWork) -> Result<(), Infallible> {
        self.0 += 1;
        Ok(())
    }
}
fn decision(table: u16, width: u8) -> EffectDecision<u8> {
    let mut setup = Meter::default();
    let mut level = (0..1u8 << width)
        .map(|mask| EffectDecision::constant(table & (1 << mask) != 0))
        .collect::<Vec<_>>();
    for variable in (0..width).rev() {
        let branch = EffectDecision::variable(variable, &mut setup).unwrap();
        level = level.chunks_exact(2).map(|pair| {
            branch.conditional(&pair[1], &pair[0], &mut setup).unwrap()
        }).collect();
    }
    level.pop().unwrap()
}
fn main() {
    let mut without_choices = 0;
    let mut with_choices = 0;
    let mut nontrivial_choice_domains = 0;
    let mut avoided = 0;
    let mut max_avoided = 0;
    for table in 0..256 {
        let relation = decision(table, 3);
        for local_mask in 0..8u8 {
            for choice_mask in (0..8u8).filter(|mask| mask & local_mask == 0) {
                let locals = (0..3u8)
                    .filter(|variable| local_mask & (1 << variable) != 0)
                    .collect::<BTreeSet<_>>();
                let choices = (0..3u8)
                    .filter(|variable| choice_mask & (1 << variable) != 0)
                    .collect::<BTreeSet<_>>();
                let mut meter = Meter::default();
                let projected = relation.exists(&choices, &mut meter).unwrap();
                let completed = projected.complete_conditionally(locals.clone(), &mut meter).unwrap();
                let mut instantiate = Meter::default();
                let joint = if locals.is_empty() || relation.node_count() == 0 {
                    relation.clone()
                } else {
                    completed.lower_envelope().instantiate(&relation, &mut instantiate).unwrap()
                };
                if choices.is_empty() {
                    assert_eq!(&joint, completed.principal());
                    without_choices += 1;
                    avoided += instantiate.0;
                    max_avoided = max_avoided.max(instantiate.0);
                } else {
                    assert_eq!(&joint.exists(&choices, &mut meter).unwrap(), completed.principal());
                    if joint.variables().any(|variable| choices.contains(variable)) {
                        nontrivial_choice_domains += 1;
                    }
                    with_choices += 1;
                }
            }
        }
    }
    assert_eq!(without_choices, 2048);
    assert_eq!(with_choices, 4864);
    assert!(nontrivial_choice_domains > 0);
    println!("choice_free={without_choices} with_discrete_choices={with_choices} explicitly_choice_dependent={nontrivial_choice_domains}");
    println!("avoided_charges={avoided} max_avoided_per_choice_free_case={max_avoided}");
}
