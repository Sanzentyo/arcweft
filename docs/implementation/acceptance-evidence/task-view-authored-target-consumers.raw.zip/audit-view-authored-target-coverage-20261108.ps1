$ErrorActionPreference='Stop'
$r=$PSScriptRoot
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$graph=Read-Record 'view-authored-target-20261108.graph.json'
$old=Read-Record 'view-action-ingress-integrated-20261108.noncli-r2.catalog.inventory.json'
$current=Read-Record 'view-authored-target-integrated-20261108.noncli.catalog.inventory.json'
$owner=Read-Record 'view-authored-target-20261108.owner-r2.catalog.inventory.json'
$prior=@($old.rows|Where-Object {$_.package -in $graph.packages.name -and $_.status -eq 'matches'})
$selected=@($current.rows|Where-Object status -eq 'matches')
function Case-Key($row){$row.binary+'::'+$row.test}
$priorKeys=@($prior|ForEach-Object {Case-Key $_}|Sort-Object)
$currentKeys=@($selected|ForEach-Object {Case-Key $_}|Sort-Object)
$delta=@(Compare-Object $priorKeys $currentKeys)
$removed=@($delta|Where-Object SideIndicator -eq '<=')
$added=@($delta|Where-Object SideIndicator -eq '=>')
$required=@($owner.rows|Where-Object status -eq 'matches')
$missing=@(foreach($row in $required){$key=Case-Key $row;if(@($currentKeys|Where-Object {$_ -ceq $key}).Count -ne 1){$key}})
$duplicates=@($currentKeys|Group-Object|Where-Object Count -ne 1)
if($prior.Count -ne 4642 -or $selected.Count -ne 4646 -or $removed.Count -ne 0 -or $added.Count -ne 4 -or $required.Count -ne 90 -or $missing.Count -ne 0 -or $duplicates.Count -ne 0){throw 'Coverage differs from the resolved owner closure and required cases'}
[ordered]@{version=1;source='faa2d2aaf2eef6c7dbd6c76f6757c0e6a4d0b9c1';graphPackages=$graph.packages.Count;runtimePackages=@($selected.package|Sort-Object -Unique).Count;priorSelectedInThisClosure=$prior.Count;currentSelected=$selected.Count;removed=$removed;added=@($added.InputObject);requiredOwnerCases=$required.Count;requiredMissing=$missing;duplicates=$duplicates;notes='Same non-CLI all-features lib/tests feature point as the prior Core matrix, restricted to the current View reverse closure; runtime terminal and source/executable drift audits are separate.'}|ConvertTo-Json -Depth 12|Set-Content "$r/view-authored-target-integrated-20261108.coverage-review.json" -Encoding utf8
Get-Content "$r/view-authored-target-integrated-20261108.coverage-review.json" -Raw
