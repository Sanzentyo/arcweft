$ErrorActionPreference='Stop'
$r=$PSScriptRoot
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$graph=Read-Record 'view-authored-target-20261108.graph.json'
$old=Read-Record 'view-action-ingress-integrated-20261108.noncli-r2.source-freeze.json'
$current=Read-Record 'view-authored-target-integrated-20261108.noncli.source-freeze.json'
$terminal=Read-Record 'view-action-ingress-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
$catalog=Read-Record 'view-action-ingress-integrated-20261108.noncli-r2.catalog.inventory.json'
if($terminal.executed -ne 7361 -or $terminal.failed -ne 0){throw 'Prior run not fully passing'}
$index=@{};foreach($row in $current.paths){$index[$row.path]=$row}
$changes=@(foreach($row in $old.paths){
    if(!$index.ContainsKey($row.path)){throw 'Frozen input removed'}
    if($row.sha256 -ne $index[$row.path].sha256){
        if($row.path -notmatch '^crates/([^/]+)/' -or $Matches[1] -notin $graph.packages.name){throw ('Changed input outside the rerun closure: '+$row.path)}
        [ordered]@{path=$row.path;owner=$Matches[1];before=$row.sha256;after=$index[$row.path].sha256}
    }
})
if($current.paths.Count -ne $old.paths.Count -or $changes.Count -ne 5){throw 'Unexpected source epoch delta'}
$cases=@($catalog.rows|Where-Object {$_.status -eq 'matches' -and $_.package -notin $graph.packages.name})
if($cases.Count -ne 2719){throw 'Unaffected case count differs'}
[ordered]@{version=1;priorBase=$old.base;currentBase=$current.base;frozenInputs=$old.paths.Count;sourceChanges=$changes;changedInputsOutsideRerunClosure=0;reusedPassedCases=$cases.Count;reusedPackages=@($cases.package|Sort-Object -Unique);priorTerminal=$terminal;priorCatalog='view-action-ingress-integrated-20261108.noncli-r2.catalog.inventory.json';priorRawArchive='docs/implementation/acceptance-evidence/task-view-action-ingress-consumers.raw.zip';scope='Reuse only the 2719 passing cases outside the resolved View reverse closure, with unchanged manifests/fixtures/toolchain inputs and all five changed Rust inputs inside the newly executed closure. This is logical coverage, not a fresh all-Core run.'}|ConvertTo-Json -Depth 15|Set-Content "$r/view-authored-target-integrated-20261108.reuse-review.json" -Encoding utf8
Get-Content "$r/view-authored-target-integrated-20261108.reuse-review.json" -Raw
