$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$noncli=Read-Record 'view-authored-target-integrated-20261108.noncli.runtime.terminal-audit.json'
$cli=Read-Record 'view-authored-target-integrated-20261108.cli.runtime.terminal-audit.json'
$probe=Read-Record 'view-authored-target-integrated-20261108.cli-source-probe.json'
$coverage=Read-Record 'view-authored-target-integrated-20261108.coverage-review.json'
$reuse=Read-Record 'view-authored-target-integrated-20261108.reuse-review.json'
$main=Read-Record 'view-authored-target-integrated-20261108.cli.main-audit.json'
$diagnostics=Read-Record 'view-authored-target-integrated-20261108.failure-diagnostics.json'
if($noncli.executed -ne 4646 -or $noncli.failed -ne 0 -or $cli.executed -ne 711 -or $cli.failed -ne 4 -or $probe.exitCode -ne 0 -or $probe.status -ne 'ok' -or $coverage.requiredMissing.Count -ne 0 -or $reuse.reusedPassedCases -ne 2719 -or $probe.mainExecutableSha256 -ne $main.sha256){throw 'Consumer result differs'}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$record=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($record.PSObject.Properties.Name -contains 'viewAuthoredTargetConsumers'){throw 'Consumer evidence exists'}
$oldFailures=@($record.viewNamedActionConsumers.cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)
$newFailures=@($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)
$failureDiff=@(Compare-Object $oldFailures $newFailures)
if($failureDiff.Count){throw 'CLI failure IDs changed; investigate before recording'}
$raw=@(Get-ChildItem -LiteralPath $r -File -Filter 'view-authored-target-integrated-20261108*')+@(
    (Get-Item "$r/view-authored-target-20261108.source.verified.json"),
    (Get-Item "$r/view-authored-target-20261108.owner-evidence.verified.json"),
    (Get-Item "$r/view-authored-target-20261108.graph.json"),
    (Get-Item "$r/audit-view-authored-target-coverage-20261108.ps1"),
    (Get-Item "$r/audit-view-authored-target-reuse-20261108.ps1"),
    (Get-Item "$r/audit-view-authored-target-cli-failures-20261108.ps1"),
    (Get-Item "$r/run-view-authored-target-source-probe-20261108.ps1"),
    (Get-Item "$r/run-retained-input-cli-main-20261108.ps1"),
    (Get-Item $PSCommandPath))
$archive='docs/implementation/acceptance-evidence/task-view-authored-target-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($file in ($raw|Sort-Object FullName -Unique)){
        if($file.Extension -notin @('.log','.json','.patch','.txt','.ps1')){throw 'Unexpected raw entry'}
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    foreach($p in @('arcw.toml','src/main.arcw')){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,"$r/view-authored-target-probe/$p",('probe/'+$p),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|dll|rlib|rmeta|pdb)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$entry=[ordered]@{
    version=1;date='2026-11-08';sourcePublication=(Read-Record 'view-authored-target-20261108.source.verified.json')
    ownerEvidencePublication=(Read-Record 'view-authored-target-20261108.owner-evidence.verified.json')
    nonCli=$noncli;cli=$cli;mainExecutable=$main
    freshUniqueExecuted=($noncli.executed+$cli.executed);freshPassed=($noncli.passed+$cli.passed);failed=($noncli.failed+$cli.failed);freshSkipped=($noncli.skipped+$cli.skipped)
    featurePoints=@('workspace except CLI, all-features, lib/tests, rdeps(View)','CLI default, lib/tests')
    graph=(Read-Record 'view-authored-target-20261108.graph.json');coverageReview=$coverage;reuseReview=$reuse
    logicalExecuted=($noncli.executed+$cli.executed+$reuse.reusedPassedCases);logicalPassed=($noncli.passed+$cli.passed+$reuse.reusedPassedCases)
    priorCliFailureIds=$oldFailures;cliFailureIdChanges=$failureDiff;observedDiagnostics=$diagnostics
    cliSourceProbe=$probe;archive=$archiveInfo;preservedPriorRecords=@($record.PSObject.Properties).Count
    scope='41-package View reverse closure, with 37 actual non-CLI runtime packages. Fresh executions and unchanged outside-closure reuse are distinct. Do not add focused owner repetitions or present logical coverage as a fresh all-Core run. Sample migration, Scroll and Native/Web capture remain separate conditions.'
}
$wrapper=(ConvertTo-Json -InputObject ([ordered]@{viewAuthoredTargetConsumers=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd();$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $record.PSObject.Properties){if((ConvertTo-Json -InputObject $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress)){throw ('History changed: '+$property.Name)}}
[ordered]@{priorRecords=@($record.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;freshExecuted=$entry.freshUniqueExecuted;freshPassed=$entry.freshPassed;failed=$entry.failed;freshSkipped=$entry.freshSkipped;logicalExecuted=$entry.logicalExecuted;logicalPassed=$entry.logicalPassed;archive=$archiveInfo}|ConvertTo-Json -Depth 10|Set-Content "$r/view-authored-target-consumers-record-audit.json" -Encoding utf8
Get-Content "$r/view-authored-target-consumers-record-audit.json" -Raw
