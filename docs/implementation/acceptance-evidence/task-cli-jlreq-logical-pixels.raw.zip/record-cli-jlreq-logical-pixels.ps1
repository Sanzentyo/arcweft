$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -AsHashtable -Depth 100 }
$source=Read-Record 'cli-jlreq-logical-pixels-checkpoint.verified'
$owner=Read-Record 'cli-jlreq-logical-pixels-owner1-20261105.runtime.terminal-audit'
$repair=Read-Record 'cli-jlreq-logical-pixels-repair1-20261105.runtime.terminal-audit'
if((git rev-parse HEAD).Trim() -ne $source.commit -or $owner.executed -ne 246 -or $owner.passed -ne 240 -or $owner.failed -ne 6 -or $repair.passed -ne 2 -or $repair.failed -ne 0){throw 'Unexpected results'}
$quality=[ordered]@{}
foreach($stage in 'check','clippy','structure') {
 $quality[$stage]=Read-Record "cli-jlreq-logical-pixels-quality1-20261105-$stage"
 if($quality[$stage].exitCode -ne 0){throw 'Quality failure'}
}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {$_.Name -like 'cli-jlreq-logical-pixel*'})
$files+=Get-Item -LiteralPath "$taskTemp/record-cli-jlreq-logical-pixels.ps1"
$files+=Get-Item -LiteralPath "$taskTemp/audit-nextest-final-result.ps1"
$files+=Get-Item -LiteralPath "$taskTemp/run-presentation-projection-owner.ps1"
$files+=Get-Item -LiteralPath "$taskTemp/run-action-payload-quality.ps1"
$files+=@(Get-ChildItem -LiteralPath "$taskTemp/cli-jlreq-logical-pixels-quality1-20261105.structure-report" -File -Recurse)
. "$taskTemp/write-verified-evidence-archive.ps1"
$rawPath='docs/implementation/acceptance-evidence/task-cli-jlreq-logical-pixels.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($record.typedTextLengths.Contains('cliLogicalPixelFixtures')){throw 'Preserve existing evidence'}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$prefixHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()
$oldRows=@($status -split "`n" | Where-Object {$_ -match '^\| (RichTextの部分layout指定／source factory|Native JLREQのnumeric|CLI全target照合|workspace check／Clippy)'})
$record.typedTextLengths.cliLogicalPixelFixtures=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source
 reason='Fixed-cell/column fixtures authored pt while asserting logical-pixel geometry under the former unit-dropping bug. Correct pt conversion made30pt become40000milli-px against the original30000 expectation. Express their original geometry in px:45 source size inputs (16 native_vertical,2 class_mix,27 units), preserving all numeric sizes, rendered text/source ranges, viewports, steps/max-ops, budgets and existing geometry/crop/mask assertions. Rename font_points to font_pixels and correct the old30pt comment.'
 owner=$owner;ownerCommand=(Read-Record 'cli-jlreq-logical-pixels-owner1-20261105.runtime').command
 ownerScope='One actual246-case Native observe parent run,240PASS/6FAIL/241skip,599.879s. All4108 source/case/executable pins unchanged. Includes the new CLI unit case, full strict/normal class and unit geometry, exact offsets, raw crops, masks, object-id capture, pixels and tint. Five remaining failures belong to full-grammar current-line selection (3), Scroll shared-callable resolution (1), and the z-index fixture expecting unauthored params (1); these are concrete observed diagnostics, not acceptance claims. The sixth was the ruby collision unit-bearing JSON assertion repaired separately.'
 repair=$repair;repairReason='The1px ruby_collision_gap was correctly reported as {milli:1000,unit:px}; the old assertion compared it to1000. Assert both amount and unit exactly, retaining all original separation/side/geometry assertions. Separate final2/2PASS/485skip verifies this case and the new point/pixel CLI case, not a new246-case run.'
 unitCase='Actual CLI Native18pt/24px sources in horizontal_tb,vertical_rl,vertical_lr: typed context catalog,24k font,32.4k line-height,source0..9,3 glyphs,shape size24,and exact glyph source/bounds/advance equality plus nonempty native layer image. PASS in both runs. Inline flow-colon source is valid; no parser workaround.'
 quality=$quality;qualityScope='CLI package check and Clippy all-targets/all-features/locked exit0; full98 structure exit0. Existing warnings remain. No production or Cargo changes; no repeated full59/workspace quality/doctest/wasm/parity claim.'
 held='Original12 tracked WIP patch SHA25646402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac retained through verified publication; all6 original untracked files retained. Tests observe the working tree with relevant original WIP, not pristine HEAD.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
 correctionReason='Replace the pending CLI unit-fixture current statement with actual source and independent run results. Keep prior full9757/9702PASS/55FAIL unchanged; do not subtract later repairs or combine the two owner runs. Previously accepted JLREQ numeric/accented/Greek-Latin conditions remain accepted; their source now uses the actual logical-pixel unit. Generic Match remains accepted/public.'
 supersededCurrentRows=$oldRows
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$rows=@(foreach($line in ($status -split "`n")) {
 if($line.StartsWith('| RichTextの部分layout指定／source factory |')) {
  '| RichTextの部分layout指定／source factory | **既受入を維持。順序・px／pt・CLI論理px整合を公開・対象検証済み** | 単位保持d693a3fcc4b4716ac9d6089c075d8f1ff96bcdf、共有API0345cb6ed70b8ce83a7b3a200ba790a385efa4e8、CLI fixture '+$source.commit+'。6 owner309／309、Compiler318／318、負例fixture修復の別4／4を保持する。CLI Native observe親moduleは246実行／240 PASS／6 FAIL、単位付きruby JSON検査の修復後は対象2／2 PASS。新CLIは横書き・縦書き左右すべてで18ptと24pxの実glyph geometry一致を確認した。45 size入力を元の数値・text・viewport・予算・全geometry assertionを保ったpxへ訂正した。旧full55 FAILと後続修復を合算しない。typed bare serif、static inline_styles出典、残るCLI条件と最終画像parityは継続する。[訂正理由・全実測・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 } elseif($line.StartsWith('| Native JLREQのnumeric／accented／Greek-Latin fixture |')) {
  '| Native JLREQのnumeric／accented／Greek-Latin fixture | **受入を維持。論理px指定へ同期・対象parent runで再確認** | 初回受入Source15888388a085ab08849f6cc8bdb18d4f5bd39ec4の6／6実測は[履歴](acceptance-evidence/task-cli-jlreq-fixture-sizing.json)に保持する。正しいpt換算の導入後、Source'+$source.commit+'でnumeric36px／accented38px／Greek-Latin42pxへ訂正した。元の数値・text／Source範囲・viewport・steps／max-ops・列送り／原子word／単位／mask／object-id／tintのassertionを維持し、246-case parent runで当該geometry・raw cropがPASS。旧pt表記を現行条件として重複掲載しない。renderer／plannerや全Native-Web parityの受入へ拡張しない。[訂正根拠と実測](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 } elseif($line.StartsWith('| CLI全target照合 |')) {
  '| CLI全target照合 | **統合受入は未完了。全698実測と後続Native親module修復を別記録** | Source0345cb6ed70b8ce83a7b3a200ba790a385efa4e8の全698は646 PASS／52 FAILのまま保持する。後続Source'+$source.commit+'のNative observe親moduleは246実行／240 PASS／6 FAIL、ruby JSON検査修復後の対象2／2は別run。残るfull-grammar3件、Scroll解決1件、z-indexの未記述param期待1件は各診断から修復する。未再実行の全CLI成功やfull runへの修復合算を主張しない。[全失敗・訂正・原本](acceptance-evidence/task-rich-text-property-identity.json)。Generic Matchと他の既受入境界は維持する。 |'
 } elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')) {
  $line.Replace('全98を再実行したとはしない。','全98を再実行したとはしない。CLI fixture '+$source.commit+'は対象CLI all-target／all-feature／locked check・Clippyと全98構造gateが終了0、警告は残る。')
 } else {$line}
})
$rows=@($rows | ForEach-Object {$_.Replace('d693a3fcc4b4716ac9d6089c075d8f1ff96bcdf','d693a3fcc4b4716ac9d608e9c075d8f1ff96bcdf')})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-05 — CLI logical-pixel fixture synchronization

- Source $($source.commit) expresses45 fixed-cell/column size inputs in px after the correct pt-to-px law exposed old unit-dropping assumptions. Preserve original numeric sizes, text/source ranges, viewports, steps/max-ops and all geometry/raw crop/mask/object-id/pixel/tint assertions. Earlier6-condition JLREQ acceptance remains intact; its oldpt spelling is historical, not the current source contract.
- Actual246-case Native observe parent run:240PASS/6FAIL/241skip,599.879s,4108 source/case/EXE drift0. Preserve every failure. The ruby_collision_gap failure compared the new unit-bearing1px JSON to1000; final source asserts amount+unit, with all geometry assertions unchanged. A separate2/2PASS/485skip run verifies ruby collision and actualCLI18pt=24px glyph geometry in all3 writing directions. Never merge these runs or subtract repairs from the prior full9757/55FAIL.
- CLI check/Clippy all-target/all-feature/locked and full98 structure exit0, existing warnings retained. Five observed remaining parent failures concern full-grammar current-line selection3, Scroll shared-callable resolution1 and unauthored z-index params1. [Actual results, source/patch identities and verified raw](acceptance-evidence/task-rich-text-property-identity.json); [current list](current-status.md). Generic Match remains accepted/public.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys) {
 if($key -eq 'typedTextLengths') {foreach($child in $before[$key].Keys){if(($before[$key][$child]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key][$child]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous child changed'}}}
 elseif(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous field changed'}
}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixHash){throw 'History changed'}
[ordered]@{source=$source.commit;priorFieldDrift=0;historyPrefixDrift=0;raw=$record.typedTextLengths.cliLogicalPixelFixtures.raw}|ConvertTo-Json -Depth 6
