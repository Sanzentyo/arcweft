$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '644c5f91b5643bc647802a891f58f67f32d728e9'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'joint-completion-reader.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='Readonly completed application, residual binder and capture transport operate directly on the actual inference branch and its immutable closed effects. The same applications and C proof are required; a joint product is not rebuilt as a single source ConstraintPath. Mutating source restoration and explicit original fixture inputs retain their own source contract. Quantified completed projections return the canonical TypeKind that their owner actually issues. seal_path scopes its immutable source view to each projection before inserting its owned binding, preserving original binding authentication, transitive source bindings, occurs checks, frames, lineage and graph metadata without cloning the effect environment. One new fixture infers and closes two real roots, then seals each actual application and canonical projection from the retained joint branch, checking original member identity and receiver frame restoration. It remains unrun. The previous unrun Named fixture incorrectly included an unprepared Named in the original frozen graph. Existing closure code and final_forest_closure_waits_for_a_body require actual bodies for all original Named declarations, so the fixture is corrected to introduce the untouched declaration only after closure. The reader then has to use the immutable original principal without reclosing the extended graph. This is a correction to unrun test intent, not a runtime acceptance claim or reopening of any accepted feature. No fake source, new type model, fallback reader, source reconstruction, implicit Future value, repeated body preparation or modified production budget is introduced. All changed paths retain exact LOC/bytes/growth/classification and inline module measurements, with the measurement pattern covering named inline cfg(test) modules. The final transaction materialization bridge, complete fixture/consumer migration, Fn-local quantification and guarded headers, and frontend acceptance remain unfinished. Cargo dependencies/features, layer direction, I/O, unsafe, codec/version, jobs and profile are unchanged. Existing resolved graph/reverse-dependency evidence is reused; no scanner or broad acceptance is claimed.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'joint-completion-reader.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'joint-completion-reader.'+$iteration+$suffix}})
$names+=@('joint-completion-reader.source-publication.json','joint-completion-reader.ownership-review.json','joint-completion-reader.staged-review.json','joint-completion-reader.dev01-diagnostic-review.json')
$names+=@('run-joint-completion-reader-check.ps1','archive-joint-completion-reader.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-joint-completion-reader-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-joint-completion-reader-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'joint-completion-reader.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
