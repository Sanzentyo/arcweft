param(
    [string]$Baseline='nested-header-effects.dev03-reverse-tests.log',
    [string]$Observed='declared-rigid-capture.dev02-directed.log'
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSCommandPath
function Read-Results([string]$name) {
    $rows=@{}
    foreach($line in Get-Content -LiteralPath (Join-Path $root $name)) {
        if ($line -match '^\s*Summary \[') { break }
        if ($line -match '^\s*(PASS|FAIL|SKIP) \[.*?\]\s+\(\s*\d+/\d+\) (arcweft-lang-sema \S+)$') {
            $rows[$Matches[2]]=$Matches[1]
        }
    }
    return $rows
}
$before=Read-Results $Baseline
$after=Read-Results $Observed
if (-not $before.Count -or -not $after.Count) { throw 'Expected completed Sema test rows.' }
$changes=@(foreach($key in $after.Keys | Sort-Object) {
    if ($after[$key] -ne $before[$key]) {
        [pscustomobject]@{id=$key;before=$before[$key];after=$after[$key]}
    }
})
@{
    version=1
    baseline=$Baseline
    observed=$Observed
    count=$after.Count
    pass=@($after.Values | Where-Object { $_ -eq 'PASS' }).Count
    fail=@($after.Values | Where-Object { $_ -eq 'FAIL' }).Count
    changes=$changes
} | ConvertTo-Json -Depth 4 | Tee-Object -FilePath (Join-Path $root ([IO.Path]::GetFileNameWithoutExtension($Observed)+'-comparison.json'))

