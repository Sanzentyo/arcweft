$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$publication=Get-Content -Raw "$root/effect-delta.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/effect-delta.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/effect-delta.impact.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/effect-delta.clippy.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/effect-delta.structure.json"|ConvertFrom-Json
if($owner.Source -ne $publication.Source -or $owner.Passed -ne 1733 -or $owner.Failed -ne 6 -or $impact.Source -ne $publication.Source -or $impact.ReverseConsumersRerun -or $quality.ExitCode -or $structure.Source -ne $publication.Source -or $structure.ExitCode -ne 0){throw 'Final evidence differs'}
$files=[Collections.Generic.List[object]]::new()
foreach($file in Get-ChildItem -LiteralPath $root -File|Where-Object {$_.Name -like '*effect-delta*'}){
    if($file.Name -like '*.archive.json'){continue}
    $files.Add([pscustomobject]@{Path=$file.FullName;Entry='evidence/'+$file.Name})
}
foreach($path in $publication.Paths){
    if((Get-FileHash -LiteralPath $path.Path -Algorithm SHA256).Hash -ne $path.SHA256){throw 'Source changed'}
    $files.Add([pscustomobject]@{Path=(Join-Path (Get-Location) $path.Path);Entry='source/'+$path.Path.Replace([char]92,[char]47)})
}
foreach($name in @('effect-primitive-gamma.owner-terminal.json','effect-primitive-gamma.owner-summary.json','effect-primitive-gamma.consumer-summary.json','effect-primitive-gamma.broad-quality.json','effect-primitive-gamma.impact.json','effect-primitive-gamma.archive.json')){
    $files.Add([pscustomobject]@{Path="$root/$name";Entry='baseline/'+$name})
}
if(@($files|Group-Object Entry|Where-Object Count -GT 1).Count){throw 'Duplicate archive names'}
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=@($files|ForEach-Object {[ordered]@{Name=$_.Entry;Bytes=(Get-Item -LiteralPath $_.Path).Length;SHA256=(Get-FileHash -LiteralPath $_.Path -Algorithm SHA256).Hash}})}
$manifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($manifest|ConvertTo-Json -Depth 6))
$destination='D:/git/arcweft/docs/implementation/acceptance-evidence/task-effect-delta.raw.zip'
$stream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try {
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try {
        foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.Path,$file.Entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
        $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal)
        $out=$entry.Open()
        try {$out.Write($manifestBytes)}finally{$out.Dispose()}
    }finally{$zip.Dispose()}
}finally{$stream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($destination)
$rawBytes=0L
try {
    if($zip.Entries.Count -ne $manifest.Entries.Count+1){throw 'Archive entry count differs'}
    foreach($expected in @($manifest.Entries)+@([pscustomobject]@{Name='manifest.json';Bytes=$manifestBytes.Length;SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($manifestBytes))})){
        $entry=$zip.GetEntry($expected.Name)
        if(!$entry -or $entry.FullName.Contains([char]92) -or $entry.Length -ne $expected.Bytes){throw 'Archive entry length/path differs'}
        $entryStream=$entry.Open()
        try {$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($entryStream))}finally{$entryStream.Dispose()}
        if($hash -cne $expected.SHA256){throw 'Archive entry hash differs'}
        $rawBytes+=$entry.Length
    }
    $count=$zip.Entries.Count
}finally{$zip.Dispose()}
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Path=$destination;Entries=$count;RawBytes=$rawBytes;ZIPBytes=(Get-Item -LiteralPath $destination).Length;SHA256=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash;AllEntriesVerified=$true}|ConvertTo-Json|Set-Content -Encoding utf8 "$root/effect-delta.archive.json"
Get-Content "$root/effect-delta.archive.json"




