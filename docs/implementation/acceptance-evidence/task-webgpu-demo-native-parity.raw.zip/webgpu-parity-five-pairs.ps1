param([string]$WebDirectory,[string]$Tag)
$ErrorActionPreference='Stop'
$e=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
$out=Join-Path (Get-Location) 'target/webgpu-parity-live-20261109'
$web=Join-Path $out $WebDirectory
$summary=[System.Collections.Generic.List[object]]::new()
$cases=@('focus-first-choice','hover-second-choice','press-first-choice','compact-focus-first-choice','hidpi-focus-first-choice')
foreach($name in $cases){
  $n=Join-Path $out ('native-'+$name+'.png')
  $w=Join-Path $web ('web-'+$name+'.png')
  $report=Join-Path $out ($Tag+'-parity-'+$name+'.json')
  $metric=Join-Path $out ($Tag+'-imq-'+$name+'.json')
  $extra=switch($name){
    'press-first-choice' {@('--min-psnr','23.9')}
    'compact-focus-first-choice' {@('--min-psnr','21.4','--max-mse','0.0072','--max-mae','0.0108','--max-changed-pixel-ratio','0.03')}
    'hidpi-focus-first-choice' {@('--min-psnr','20.0','--max-mse','0.0101','--max-mae','0.0168','--max-changed-pixel-ratio','0.04')}
    default {@()}
  }
  Write-Output $name
  cargo +nightly -Zscript tools/verify-webgpu-parity.rs --native $n --web $w --report $report @extra
  $gate=$LASTEXITCODE
  imq compare $n $w --metrics psnr,ssim,mse,mae,maxae --format json --output $metric
  $imq=$LASTEXITCODE
  $r=Get-Content $report -Raw | ConvertFrom-Json
  $summary.Add([ordered]@{name=$name;gate=$gate;imq=$imq;native_sha256=(Get-FileHash $n).Hash.ToLowerInvariant();web_sha256=(Get-FileHash $w).Hash.ToLowerInvariant();gate_report=$r})
}
$summary | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $e ('webgpu-parity-'+$Tag+'-pairs.json')) -Encoding utf8
if(@($summary | Where-Object {$_.gate -ne 0 -or $_.imq -ne 0}).Count){exit 1}
exit 0