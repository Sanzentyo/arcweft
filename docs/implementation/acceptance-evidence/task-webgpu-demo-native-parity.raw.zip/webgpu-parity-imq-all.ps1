param([string]$WebDirectory,[string]$Tag)
$ErrorActionPreference='Stop'
$out=Join-Path (Get-Location) 'target/webgpu-parity-live-20261109'
$web=Join-Path $out $WebDirectory
foreach($name in @('focus-first-choice','hover-second-choice','press-first-choice','compact-focus-first-choice','hidpi-focus-first-choice')){
  $n=Join-Path $out ('native-'+$name+'.png')
  $w=Join-Path $web ('web-'+$name+'.png')
  $report=Join-Path $out ($Tag+'-imq-all-'+$name+'.json')
  imq image $n $w --metrics psnr:all,mse:all,mae:all,maxae:all --format json --output $report
  if($LASTEXITCODE){exit $LASTEXITCODE}
  $r=Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
  $m=@($r.metrics | Where-Object {$_.name -in @('mse','mae','maxae')})
  $samples=4*$r.dimensions.width*$r.dimensions.height
  if($r.reference_format.pixel_format -ne 'Rgba8' -or $r.distorted_format.pixel_format -ne 'Rgba8' -or $m.Count -ne 3 -or @($m | Where-Object {$_.details.samples -ne $samples -or $_.score -ne 0}).Count){
    throw "$name did not produce an exact four-channel result"
  }
  [ordered]@{name=$name;width=$r.dimensions.width;height=$r.dimensions.height;samples=$samples;maxae=0} | ConvertTo-Json -Compress
}