$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-returned-prefix-20261110'
$f=Join-Path $d 'fixtures'
$old=Join-Path $env:TEMP 'arcweft-promotion-specialized-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$q=ArcJson (Join-Path $d 'quality.receipt.json')
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($sha -ne $q.cliSha256){throw 'Expected the exact quality CLI build'}
foreach($row in $q.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
$priorDir=Join-Path $old 'next-returned-prefix'
$prior=ArcJson (Join-Path $priorDir 'baseline.receipt.json')
$priorPublication=ArcJson (Join-Path $old 'source.publication.json')
if($prior.cliSha256 -ne $priorPublication.cliSha256 -or $prior.cases.Count -ne 3){throw 'Prior CLI evidence differs'}
foreach($entry in $prior.cases){
    if($entry.inputSha256 -ne (ArcSha (Join-Path $f "$($entry.name).arcw")) -or $entry.reportSha256 -ne (ArcSha (Join-Path $priorDir "$($entry.name).json")) -or $entry.stderrSha256 -ne (ArcSha (Join-Path $priorDir "$($entry.name).stderr.log"))){throw "Prior fixture differs $($entry.name)"}
}
git diff --quiet $priorPublication.commit $q.base -- 'crates/**' Cargo.toml Cargo.lock
if($LASTEXITCODE){throw 'Pinned previous source differs from current base'}
$expect=[ordered]@{
    'returned-prefix-retains'=$true
    'returned-prefix-discards'=$false
    'returned-prefix-storage'=$true
    'poly-prefix-from-closure'=$true
    'poly-shared-returned-prefix'=$true
    'returned-prefix-poly-contextual'=$true
    'returned-prefix-poly-contextual-owned'=$false
}
$verify='returned-prefix-retains','returned-prefix-discards','returned-prefix-storage','returned-prefix-poly-contextual','returned-prefix-poly-contextual-owned'
$cases=@(foreach($name in $expect.Keys){
    $src=Join-Path $f "$name.arcw"
    $commands=if($name -in $verify){'check','verify'}else{'check'}
    foreach($command in $commands){
        $out=Join-Path $d "$name.$command.after.json"
        $err=Join-Path $d "$name.$command.after.stderr.log"
        & $cli $command $src --json > $out 2> $err
        $exit=$LASTEXITCODE
        $report=ArcJson $out
        $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
        $code=$diagnostics[0].code
        $span=$diagnostics[0].span
        $spelling=if($span){(Get-Content -Raw -LiteralPath $src).Substring($span.start,$span.end-$span.start)}else{$null}
        $expectedCode=if($expect[$name]){'sema.lifetime.promotion_receiver'}else{'sema.lifetime.promotion_execution'}
        $expectedSpan=if($expect[$name]){'callback'}else{"callback.promote('flow)"}
        $accepted=$exit -eq 1 -and $report.stage -eq 'type-check' -and $diagnostics.Count -eq 1 -and $code -ceq $expectedCode -and $spelling -ceq $expectedSpan
        [ordered]@{name=$name;command=$command;exit=$exit;stage=$report.stage;code=$code;span=$spelling;accepted=$accepted;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
    }
})
$execution=@(foreach($name in 'returned-prefix-execution','returned-prefix-independent-execution','direct-prefix-shared-execution'){
    $src=Join-Path $f "$name.arcw"
    foreach($tier in 'bytecode-vm','aot','awbc-product'){
        $out=Join-Path $d "$name.$tier.run.after.json"
        $err=Join-Path $d "$name.$tier.run.after.stderr.log"
        & $cli run $src --runner headless --flow main --executor $tier --mode one-op --max-ops 1 --steps 256 --json > $out 2> $err
        $exit=$LASTEXITCODE
        $report=if((Get-Item -LiteralPath $out).Length){ArcJson $out}else{$null}
        $metrics=@($report.steps|ForEach-Object {$_.stats.executed_ops})|Measure-Object -Maximum -Sum
        $returns=@($report.steps|ForEach-Object {$_.flow_events}|Where-Object {$_ -eq 'return 42'})
        $accepted=!$exit -and $report.executor -eq $tier.Replace('-','_') -and $report.final_status -ceq 'done Return("42")' -and $report.steps.Count -le 256 -and $report.steps[-1].stop_reason -eq 'Done' -and $metrics.Maximum -le 1 -and $returns.Count -eq 1 -and !@($report.steps|Where-Object {$_.diagnostics -or $_.assertion_failures -or $_.task_requests}).Count
        [ordered]@{name=$name;tier=$tier;exit=$exit;executor=$report.executor;steps=$report.steps.Count;maxOps=$metrics.Maximum;executedOps=$metrics.Sum;finalStatus=$report.final_status;accepted=$accepted;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
    }
})
$limitations=@(foreach($name in 'returned-prefix-poly-owned','returned-prefix-poly-borrow','returned-prefix-shared-execution','returned-prefix-shared-one-execution','returned-prefix-shared-contextual-execution'){
    $src=Join-Path $f "$name.arcw"; $out=Join-Path $d "$name.limitation.json"; $err=Join-Path $d "$name.limitation.stderr.log"
    & $cli check $src --json > $out 2> $err
    $exit=$LASTEXITCODE
    $report=ArcJson $out
    $diagnostic=$report.diagnostics[0].diagnostic
    [ordered]@{name=$name;command='check';exit=$exit;stage=$report.stage;code=$diagnostic.code;message=$diagnostic.message;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
if((ArcSha $cli) -ne $sha){throw 'CLI changed during verification'}
[ordered]@{
    version=1;base=$q.base;validatedInputs=$q.inputs;cliSha256=$sha
    baseline=[ordered]@{source=$priorPublication.commit;cliSha256=$prior.cliSha256;cases=$prior.cases}
    cases=$cases
    execution=[ordered]@{runner='headless';mode='one-op';operationLimit=1;stepLimit=256;cases=$execution}
    limitations=$limitations
}|ConvertTo-Json -Depth 17|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
$cases|ForEach-Object {[pscustomobject]$_}|Format-Table name,command,stage,code,span,accepted
$execution|ForEach-Object {[pscustomobject]$_}|Format-Table name,tier,exit,accepted,steps,maxOps,finalStatus
$limitations|ForEach-Object {[pscustomobject]$_}|Format-Table name,exit,stage,code,message
if(@($cases+$execution|Where-Object {!$_.accepted}).Count){exit 1}

exit 0
