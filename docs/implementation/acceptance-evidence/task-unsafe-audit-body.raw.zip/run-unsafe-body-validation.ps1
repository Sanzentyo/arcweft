$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='unsafe-body-20261107'
$previous=Get-Content "$taskTemp/scalar-joined-contour-20261107.source-freeze.json" -Raw | ConvertFrom-Json
$paths=@(foreach($row in $previous.paths){[ordered]@{path=$row.path;bytes=(Get-Item -LiteralPath $row.path).Length;sha256=(Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant()}})
$freeze=[ordered]@{version=1;head=(& git rev-parse HEAD).Trim();at=[DateTime]::UtcNow.ToString('o');paths=$paths}
$freeze | ConvertTo-Json -Depth 5 | Set-Content "$taskTemp/$prefix.source-freeze.json" -Encoding utf8
$cargoInputs=@($paths | Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'})
$cargoDrift=@($cargoInputs | Where-Object {$row=$_;@($previous.paths | Where-Object {$_.path -eq $row.path -and $_.sha256 -eq $row.sha256}).Count -ne 1}).Count
if($cargoDrift){throw 'Resolved graph inputs changed'}
& cargo tree --locked --workspace --invert arcweft-runtime-plan *> "$taskTemp/$prefix.reverse.tree.log"
if($LASTEXITCODE -ne 0){throw 'Reverse tree failed'}
$filter='rdeps(=arcweft-runtime-plan)'
$listArgs=@('nextest','list','--locked','--workspace','--lib','--tests','-E',$filter,'--message-format','json')
$started=[DateTime]::UtcNow
& cargo @listArgs > "$taskTemp/$prefix.reverse.list.json" 2> "$taskTemp/$prefix.reverse.list.stderr.log"
$listCode=$LASTEXITCODE
if($listCode -ne 0){throw ('Reverse selection failed: '+$listCode)}
$list=Get-Content "$taskTemp/$prefix.reverse.list.json" -Raw | ConvertFrom-Json -Depth 100
$selected=@(foreach($binary in $list.'rust-suites'.PSObject.Properties){foreach($test in $binary.Value.testcases.PSObject.Properties){if($test.Value.'filter-match'.status -eq 'matches'){[pscustomobject][ordered]@{package=$binary.Value.'package-name';binary=$binary.Value.'binary-name';test=$test.Name}}}})
if($selected.Count -eq 0){throw 'Empty reverse selection'}
$selected | ConvertTo-Json -Depth 5 | Set-Content "$taskTemp/$prefix.reverse.selection.json" -Encoding utf8
$runArgs=@('nextest','run','--locked','--workspace','--lib','--tests','-E',$filter,'--no-tests','fail','--no-fail-fast')
& cargo @runArgs *> "$taskTemp/$prefix.reverse.log"
$code=$LASTEXITCODE
$drift=@($paths | Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
$summary=@(Select-String -LiteralPath "$taskTemp/$prefix.reverse.log" -Pattern 'Summary \[' | ForEach-Object {$_.Line})
[ordered]@{version=1;sourceBase=$freeze.head;filter=$filter;listArguments=$listArgs;arguments=$runArgs;listExitCode=$listCode;filterMatchedTests=$selected.Count;exitCode=$code;sourceInputCount=$paths.Count;sourceDrift=$drift;cargoInputs=$cargoInputs.Count;cargoDrift=$cargoDrift;summary=$summary;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 5 | Set-Content "$taskTemp/$prefix.reverse.receipt.json" -Encoding utf8
$summary | Write-Output
if($drift){throw 'Source changed during matrix'}
foreach($check in @(
 @{name='workspace-check';args=@('check','--locked','--workspace','--all-targets','--all-features')},
 @{name='workspace-clippy';args=@('clippy','--locked','--workspace','--all-targets','--all-features')},
 @{name='structure';args=@('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')}
)){
 $started=[DateTime]::UtcNow
 $cargoArgs=$check.args
 & cargo @cargoArgs *> "$taskTemp/$prefix.$($check.name).log"
 $checkCode=$LASTEXITCODE
 [ordered]@{version=1;arguments=$cargoArgs;exitCode=$checkCode;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 5 | Set-Content "$taskTemp/$prefix.$($check.name).receipt.json" -Encoding utf8
 Write-Output ($check.name+': exit '+$checkCode)
 if($checkCode -ne 0){exit $checkCode}
}
exit $code
