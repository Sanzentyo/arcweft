$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& (Join-Path $t 'assert-no-arcweft-build.ps1')
$epoch='content-style-origin-owner2-20261106'
$freeze=Get-Content -LiteralPath (Join-Path $t ($epoch+'.source-freeze.json')) -Raw | ConvertFrom-Json
function Assert-Inputs {
 foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source changed: '+$row.path)}}
}
function Invoke-Recorded([string]$name,[string[]]$arguments){
 $path=Join-Path $t ($name+'.json')
 if(Test-Path -LiteralPath $path){throw 'Existing immutable receipt'}
 Assert-Inputs
 $started=[DateTime]::UtcNow.ToString('o')
 & cargo @arguments *> (Join-Path $t ($name+'.log'))
 $code=$LASTEXITCODE
 Assert-Inputs
 $record=[ordered]@{version=1;source='3a98722cd92a229fc77f33d4423ef18c171b7596';workingBase=(git rev-parse HEAD).Trim();command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}
 if($name -like '*doctest*'){
  $record.summaries=@(Get-Content -LiteralPath (Join-Path $t ($name+'.log')) | Where-Object {$_ -match '^test result:'})
 }
 $record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $path -Encoding utf8
 $record | ConvertTo-Json -Depth 8
}
$owners=@('arcweft-text-model','arcweft-render-text','arcweft-runtime-driver','arcweft-compiler','arcweft-agent-protocol','arcweft-cli')
$selection=@();foreach($package in $owners){$selection+=@('-p',$package)}
Invoke-Recorded 'content-style-origin-doctest1-20261106' (@('test','--doc')+$selection+@('--all-features','--locked'))
Invoke-Recorded 'content-style-origin-wasm1-20261106' @('check','-p','arcweft-render-web','-p','arcweft-player-web','--lib','--target','wasm32-unknown-unknown','--all-features','--locked')
