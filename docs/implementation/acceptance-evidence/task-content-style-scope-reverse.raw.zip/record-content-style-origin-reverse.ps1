$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$stem='content-style-origin-reverse31-attempt2-20261106'
$audit=Read-Record ($stem+'.consumer-audit')
$doc=Read-Record 'content-style-origin-doctest1-20261106'
$wasm=Read-Record 'content-style-origin-wasm1-20261106'
if($audit.terminal.executed -ne 4824 -or $audit.terminal.passed -ne 4814 -or $audit.terminal.failed -ne 10 -or $audit.nonCli.failed -or $audit.genericMatch.passed -ne 151 -or $doc.exitCode -or $wasm.exitCode){throw 'Unexpected reverse or portable result; preserve failures and repair before publishing completion'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$historyPath='docs/implementation/convergence-evidence-history.md'
$statusPath='docs/implementation/current-status.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('contentStyleScopeReverse')){throw 'Existing immutable result'}
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 $_.Name.StartsWith('content-style-origin-reverse31-') -or $_.Name.StartsWith('content-style-origin-doctest1-') -or $_.Name.StartsWith('content-style-origin-wasm1-')
})
$files+=@(Get-Item -LiteralPath (Join-Path $t 'record-content-style-origin-reverse.ps1'),(Join-Path $t 'audit-content-style-origin-reverse.ps1'),(Join-Path $t 'run-content-style-portable-checks.ps1'),(Join-Path $t 'run-presentation-projection-owner.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'))
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-content-style-scope-reverse.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$record.contentStyleScopeReverse=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');implementationSource='3a98722cd92a229fc77f33d4423ef18c171b7596';inputBase=$audit.source;audit=$audit
 firstCatalogAttempt=[ordered]@{receipt=Read-Record 'content-style-origin-reverse31-20261106.catalog';environment=Read-Record 'content-style-origin-reverse31-build-attempt1';scope='Catalog/build exit101 from actual Windows1455 paging exhaustion and cascading metadata/rlib/ICE errors; runtime not started. Same source/package/features retry succeeds. No cargo clean, job flags, source changes, artifact copies or OS setting changes were used.'}
 portable=[ordered]@{doctest=$doc;actualDoctests=3;doctestCrates=6;zeroCaseDoctestCrates=5;wasm=$wasm;scope='All-feature/locked doctest invocation exit0 with3actual tests. wasm32 render-web/player-web library check exit0, not browser execution, screenshots or Native-Web image parity.'}
 scope='Actual30-package text-model reverse closure plusSema for accepted Generic151 replay:31selected,29runtime,2host-build-only(bundle-assets/render-web). Full4824run4814PASS10FAIL40skip729.118s exit100. CLI700/690PASS10FAIL,nonCLI4124allPASS. Graph and workspace98 quality from owner evidence;4114source/case/executable drift0. Original12tracked/6untracked participated; this is not a pristine-tree test claim.'
 correctionReason='Replace the pending31 terminal and previous current CLI totals with this fresh actual run; preserve every older run unchanged. No new failure IDs; the plan provenance test now passes. The10 actual residual CLI failures remain incomplete owner conditions. Preserve Generic Match accepted/public;151exact IDs pass withmissing0/failed0. Static style provenance, units/factory/font and other accepted features are not reopened because of those independent conditions or the overall goal.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| RichTextの静的style出典／plan公開 |')){
  $line.Replace('30逆依存とSema照合は下表で継続し、','全30逆依存＋Semaの終端は下表に集約し、')
 }elseif($line.StartsWith('| Generic Match `.1.2` C3/C5 |')){
 '| Generic Match `.1.2` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。完全transcript、uninhabited-domain、Never／let-else継続、exhaustive-only atomic publicationの受入を維持する。最新入力d0dd7b9af5c845fc1beeb8398f0a3a1ed9dfb870（実装Source3a98722cd92a229fc77f33d4423ef18c171b7596）の31選択で同じ151 IDが151／151 PASS、missing0／failed0。以前の各151 PASSは履歴へ保持し、現状説明はここへ集約する。[元の受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)、[最新の厳密照合・全実測](acceptance-evidence/task-rich-text-property-identity.json)。別境界や全体goalの未達を理由に未完了へ戻さない。 |'
 }elseif($line.StartsWith('| CLI全target照合 |')){
 '| CLI全target照合 | **最新の全700実測は690 PASS／10 FAIL。plan出典は修復済み** | 入力d0dd7b9af5c845fc1beeb8398f0a3a1ed9dfb870、実装Source3a98722cd92a229fc77f33d4423ef18c171b7596。全31選択内でCLI全700を実行した実測で、新規失敗IDは0。残る10 IDはfull-grammar現在line選択3件、Scroll解決1件、unsafe fixture1件、run-edge1件、負例診断1件、verifier fixture3件。以前の689 PASS／11 FAILと対象修復runは履歴へ保持し、合算・再計算しない。[終端・全ID・入力・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
 '| 共有契約／推移的逆依存matrix | **静的style出典の全30＋Semaを完走。4824実行4814 PASS／10 FAIL／40 skipped** | 入力d0dd7b9af5c845fc1beeb8398f0a3a1ed9dfb870、729.118秒、終了100。実graphの30逆依存にGeneric Match照合用Semaを追加した31選択で、29 packageにruntime case、bundle-assets／render-webはhost buildのみ。CLI以外4124件は全PASS、10失敗は上記CLIのみ。Source4114／case／実行ファイルdrift0。初回catalogはWindows paging不足OS1455で終了101、runtime未開始のまま原本へ保持し、同じ入力の再試行でこの終端を得た。全workspace runtime・最終platform受入を主張しない。[実graph・初回失敗・各終端・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 '| workspace check／Clippy・fmt・構造gate | **静的style出典Sourceの全98 check／Clippy・構造gateは終了0。doctest3 PASS／wasm library checkも終了0** | Source3a98722cd92a229fc77f33d4423ef18c171b7596、4114入力。全98 all-target／all-feature／locked check・Clippy・構造gateと変更Rustのformat checkは終了0、警告は残る。変更owner6 crateのdoctestは実3件PASS／5 crateは0件。wasm32-unknown-unknownのrender-web／player-webはall-feature／locked library check終了0で、ブラウザ実行や最終画像parityとは区別する。以前のSourceの成功を付け替えず、各入力・既存12 tracked／6 untrackedを保持。最終Tier2・Native-Web parityは別境界。[所有測定・全実測・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Style-scope reverse and portable boundary completed

- Implementation Source3a98722cd92a229fc77f33d4423ef18c171b7596, actual input base d0dd7b9af5c845fc1beeb8398f0a3a1ed9dfb870. Complete30-package text-model reverse closure plusSema for accepted Generic Match replay:31selected/29runtime/2host-build-only(bundle-assets/render-web). Actual4824run4814PASS10FAIL40skip729.118s exit100; CLI700/690PASS10FAIL,nonCLI4124allPASS. Source4114/case/executable drift0. Existing12tracked/6untracked WIP participated. No new failure ID; plan_json_lists_runtime_task_graph now passes. Keep all10 residual CLI conditions and older unsuccessful runs; do not construct a green4824 result.
- Generic Match exact151 IDs allPASS,missing0/failed0,reference SHA82b6519b1ccbfcd4aee95d3ef8b69db686037924a7f9137de0fef0201d86b996. Acceptance/publication unchanged. The current list now cites this latest replay; retain earlier full22/full55/Font comparisons as history instead of duplicate current explanations. Static provenance and other completed boundaries remain completed independently of the overall goal.
- The initial catalog/build exited101 with actual Windows1455 paging-file mmap exhaustion and cascading invalid metadata/missing-rlib/ICE diagnostics; no runtime began. Preserve its log/receipt/environment snapshot. An unchanged package/feature/source retry completed; no clean, job flags, artifact copying, source or OS-setting workaround.
- Final workspace98 quality remains exit0 with warnings. Six changed owners' all-feature/locked doctest invocation exit0:3actual testsPASS,5crates have0tests. wasm32-unknown-unknown render-web/player-web all-feature/locked library check exit0. These portable checks are not browser runtime or final Native-Web capture/image parity. [Exact inputs, failed first attempt, terminal, portable commands and immutable raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Prior evidence changed: '+$key)}}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{version=1;implementationSource='3a98722cd92a229fc77f33d4423ef18c171b7596';inputBase=$audit.source;rawPath=$rawPath;rawBytes=$raw.bytes;rawSha256=$raw.sha256;rawEntries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'content-style-origin-reverse-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'content-style-origin-reverse-documentation-audit.json')
