# /// script
# requires-python = "==3.11.*"
# dependencies = []
# ///
"""Capture elapsed metered work for selected LLDB call scopes."""

import json
import os

import lldb


target = None
charge_bp = None
phase_by_id = {}
returns_by_pc = {}
threads = {}
reports = []


def register(frame, name):
    return frame.FindRegister(name).GetValueAsUnsigned()


def unsigned(frame, address):
    error = lldb.SBError()
    result = frame.GetThread().GetProcess().ReadUnsignedFromMemory(address, 8, error)
    if error.Fail():
        raise RuntimeError(str(error))
    return result


def thread_id(frame):
    return frame.GetThread().GetThreadID()


def current_state(frame):
    stack = threads.get(thread_id(frame))
    return stack[-1] if stack else None


def counter(frame, state):
    # The selected Windows artifact's apply_lower_delta reads this field.
    return unsigned(frame, state + 0x130)


def raise_limit(frame, _, __):
    value = frame.FindRegister("rdx")
    if value.GetValueAsUnsigned() == 4096:
        value.SetValueFromCString("16384")
    return False


def starts_state(frame, _, __):
    threads.setdefault(thread_id(frame), []).append({"pointer": None, "stages": [], "open": []})
    charge_bp.SetEnabled(True)
    return False


def find_state(frame, _, __):
    if (state := current_state(frame)) is not None:
        state["pointer"] = register(frame, "rdx")
    charge_bp.SetEnabled(False)
    return False


def phase_entry(frame, location, _):
    state = current_state(frame)
    if state is not None and state["pointer"] is not None:
        name = phase_by_id[location.GetBreakpoint().GetID()]
        state["stages"].append({"phase": name, "counter": counter(frame, state["pointer"])})
    return False


def publishes(frame, _, __):
    state = current_state(frame)
    if state is not None:
        threads[thread_id(frame)].pop()
    report = register(frame, "rcx")
    open_scopes = len(state["open"]) if state is not None else 0
    reports.append(
        {
            "consumed": unsigned(frame, report + 0x50),
            "limit": unsigned(frame, report + 0x58),
            "lower": counter(frame, state["pointer"]) if state is not None and state["pointer"] else 0,
            "open_scopes": open_scopes,
            "stages": state["stages"] if state is not None else [],
        }
    )
    with open(os.environ["ARCWEFT_METER_OUTPUT"], "w", encoding="utf-8") as output:
        json.dump(reports, output, indent=2)
    return False


def add(debugger, text, name):
    debugger.HandleCommand(f"breakpoint set {text} --skip-prologue false")
    bp = target.GetBreakpointAtIndex(target.GetNumBreakpoints() - 1)
    if not bp.GetNumLocations():
        raise RuntimeError(f"No executable location for {text}")
    bp.SetScriptCallbackFunction(f"{__name__}.{name}")
    return bp


def install(debugger):
    global target, charge_bp
    target = debugger.GetSelectedTarget()
    limits = "arcweft_lang_sema::callable::limits::"
    add(debugger, f'--name "{limits}ResolverWork::new"', "raise_limit")
    add(debugger, f'--name "{limits}CandidateConstraintWorkState::new"', "starts_state")
    charge_bp = add(debugger, f'--name "{limits}CandidateConstraintWorkState::apply_lower_delta"', "find_state")
    charge_bp.SetEnabled(False)
    add(debugger, f'--name "{limits}ResolverWorkFullReport::publish_into"', "publishes")
    root = "D:/git/arcweft/crates/arcweft-lang-sema/src"
    markers = (
        ("effect_row/prepared/closure.rs", 765, "solve-inventory"),
        ("effect_row/prepared/closure.rs", 781, "prepare-start"),
        ("effect_row/prepared/closure.rs", 782, "prepare-end"),
        ("effect_row/prepared/closure.rs", 803, "confirm-start"),
        ("effect_row/prepared/closure/component.rs", 485, "layout-start"),
        ("effect_row/prepared/closure/component.rs", 486, "fixed-cells-start"),
        ("effect_row/prepared/closure/component.rs", 488, "lower-imports-start"),
        ("effect_row/prepared/closure/component.rs", 489, "residual-program-start"),
        ("effect_row/prepared/closure/component.rs", 490, "root-compile-start"),
        ("effect_row/prepared/closure/imports.rs", 189, "child-compile-start"),
        ("effect_row/prepared/closure/imports.rs", 196, "child-support-start"),
        ("effect_row/prepared/closure/imports.rs", 197, "child-support-end"),
        ("effect_row/prepared/closure/imports.rs", 198, "child-complete-end"),
        ("types/constraints/transaction/component/original.rs", 214, "original-product-start"),
        ("types/constraints/transaction/component/original.rs", 307, "original-prepare-effects"),
        ("types/constraints/transaction/component/original.rs", 325, "original-unify-start"),
        ("types/constraints/transaction/component/original.rs", 402, "original-unify-end"),
        ("types/constraints/transaction/component/original.rs", 412, "original-freeze-start"),
        ("types/constraints/transaction/component/original.rs", 420, "original-freeze-end"),
        ("types/constraints/transaction/component/original.rs", 424, "original-bind-end"),
        ("types/constraints/transaction/component/original/effects.rs", 133, "joint-roots-start"),
        ("types/constraints/transaction/component/original/effects.rs", 134, "joint-roots-end"),
        ("types/constraints/transaction/component/original/closing.rs", 70, "original-reads"),
        ("types/constraints/transaction/component/original/closing.rs", 81, "original-close-effect"),
        ("types/constraints/transaction/component/original/closing.rs", 91, "original-project-bindings"),
        ("types/constraints/transaction/original_effects.rs", 136, "path-roots-start"),
        ("types/constraints/transaction/original_effects.rs", 137, "path-roots-end"),
        ("effect_row/prepared/read/freeze.rs", 74, "snapshot-start"),
        ("effect_row/prepared/read/freeze.rs", 251, "snapshot-end"),
        ("effect_row/prepared/completion.rs", 111, "compile-scoped-start"),
        ("effect_row/prepared/completion.rs", 121, "support-start"),
        ("effect_row/prepared/completion.rs", 122, "scoped-program-start"),
        ("effect_row/prepared/completion.rs", 126, "compile-scoped-end"),
        ("types/constraints/normalization/effects.rs", 380, "complete-branch-start"),
        ("types/constraints/normalization/effects.rs", 410, "close-original-start"),
        ("types/constraints/normalization/effects.rs", 417, "confirm-source-start"),
        ("effect_row/prepared/completion/closing.rs", 99, "check-unchanged-start"),
        ("effect_row/prepared/completion/closing.rs", 108, "unchanged-inventory"),
        ("effect_row/prepared/completion/closing.rs", 110, "attach-definitions"),
        ("effect_row/prepared/completion/closing.rs", 158, "bind-original"),
    )
    for file, line, name in markers:
        try:
            bp = add(debugger, f'--file "{root}/{file}" --line {line}', "phase_entry")
        except RuntimeError:
            if name in {"prepare-start", "prepare-end", "confirm-start"}:
                raise
            print(f"No executable location for {name}: {file}:{line}")
            continue
        phase_by_id[bp.GetID()] = name



