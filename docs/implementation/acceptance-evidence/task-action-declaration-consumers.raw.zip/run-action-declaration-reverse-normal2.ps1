$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$graph = Get-Content -LiteralPath "$taskTemp/action-declaration.reverse-graph.json" -Raw | ConvertFrom-Json
$selection = @()
foreach ($package in $graph.reversePackages) {
    if ($package -ne 'arcweft-cli') { $selection += @('-p', $package) }
}
$selection += @('--all-targets', '--all-features', '--locked')
$paths = @((Get-Content -LiteralPath "$taskTemp/action-declaration-topology-owner3-20261102.source-freeze.json" -Raw | ConvertFrom-Json).paths.path)
# The failed catalog never executed tests. Retain the same complete 22-package
# Cargo build selection and flags; run owner libraries in this unified feature
# context too, rather than reuse an unproven cross-context executable identity.
& "$taskTemp/run-presentation-projection-owner.ps1" -Stem 'action-declaration-reverse-normal2-20261102' -Selection $selection -ExpectedMatches -1 -AdditionalPaths $paths
