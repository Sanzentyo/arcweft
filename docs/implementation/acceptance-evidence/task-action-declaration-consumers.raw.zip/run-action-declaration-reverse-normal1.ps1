$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$graph = Get-Content -LiteralPath "$taskTemp/action-declaration.reverse-graph.json" -Raw | ConvertFrom-Json
$selection = @()
foreach ($package in $graph.reversePackages) {
    if ($package -ne 'arcweft-cli') { $selection += @('-p', $package) }
}
$selection += @('--all-targets', '--all-features', '--locked', '-E', 'not ((package(=arcweft-lang-hir) or package(=arcweft-lang-sema)) and kind(lib))')
$paths = @((Get-Content -LiteralPath "$taskTemp/action-declaration-sema-owner1-20261102.source-freeze.json" -Raw | ConvertFrom-Json).paths.path)
& "$taskTemp/run-presentation-projection-owner.ps1" -Stem 'action-declaration-reverse-normal1-20261102' -Selection $selection -ExpectedMatches -1 -AdditionalPaths $paths
