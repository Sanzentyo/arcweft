$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze = Get-Content -LiteralPath "$taskTemp/action-declaration-reverse-cli1-20261102.source-freeze.json" -Raw | ConvertFrom-Json
function Assert-Source {
    foreach ($row in $freeze.paths) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
Assert-Source
$exe = 'D:/git/arcweft/target/debug/arcw.exe'
$exeHash = (Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
$source = 'a2688f77338bd0b34a7651d4910312045a59d6bf'
$prefix = "entry cli @entry.action_signature_probe { goto @flow.action_signature_probe }`n"
$plain = "flow action_signature_probe() -> i64 { return 42 }`n"
$declaration = "pub action @action:.feedback.submit submit(value: String)`n"
$cases = [ordered]@{
    plain = $prefix + $plain
    declaration = "pub action submit(value: String)`n" + $prefix + $plain
    explicit_id = $declaration + $prefix + $plain
    construction = $declaration + $prefix + "flow action_signature_probe() -> i64 { let message = submit(value = `"hello`")`nreturn 42 }`n"
    emit = $declaration + $prefix + "flow action_signature_probe() -> i64 { emit(submit(value = `"hello`"))`nreturn 42 }`n"
    receive = $declaration + $prefix + "flow action_signature_probe() -> i64 { let event = await receive(submit)`nreturn 42 }`n"
    dotted_declaration = "pub action feedback.submit(value: String)`n" + $prefix + $plain
}
$rows = @(foreach ($name in $cases.Keys) {
    Assert-Source
    $stem = "action-after-signature-$name-20261102"
    $path = "$taskTemp/$stem.arcw"
    if (Test-Path -LiteralPath $path) { throw "Probe already exists: $path" }
    [IO.File]::WriteAllText($path,$cases[$name],[Text.UTF8Encoding]::new($false))
    & $exe check $path --json 1> "$taskTemp/$stem.stdout.json" 2> "$taskTemp/$stem.stderr.log"
    $code = $LASTEXITCODE
    $output = Get-Content -LiteralPath "$taskTemp/$stem.stdout.json" -Raw | ConvertFrom-Json -Depth 30
    [ordered]@{name=$name;path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();command=@($exe,'check',$path,'--json');exitCode=$code;status=$output.status;stage=$output.stage;diagnostics=$output.diagnostics;stdout="$stem.stdout.json";stderr="$stem.stderr.log"}
})
Assert-Source
if ((Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant() -ne $exeHash) { throw 'CLI executable drift during probes' }
[ordered]@{version=1;head=(git rev-parse HEAD).Trim();productionSource=$source;sourceInputs=$freeze.paths.Count;sourceDrift=0;executable=@{path=$exe;sha256=$exeHash;drift=0};meaning='Standalone CLI check probes; this does not establish Native/AWBC execution or typed Action protocol acceptance.';cases=$rows} | ConvertTo-Json -Depth 40 | Set-Content -LiteralPath "$taskTemp/action-after-signature-matrix-20261102.json" -Encoding utf8
$rows | ForEach-Object { [pscustomobject]@{name=$_.name;exitCode=$_.exitCode;status=$_.status;stage=$_.stage;codes=@($_.diagnostics.code)} } | ConvertTo-Json -Depth 8
