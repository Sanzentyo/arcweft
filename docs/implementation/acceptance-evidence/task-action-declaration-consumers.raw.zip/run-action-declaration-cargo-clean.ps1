$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze = Get-Content -LiteralPath "$taskTemp/action-declaration-reverse-normal1-20261102.source-freeze.json" -Raw | ConvertFrom-Json
function Assert-Source {
    foreach ($row in $freeze.paths) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
Assert-Source
$head = (git rev-parse HEAD).Trim()
$status = @(git --no-optional-locks status --porcelain=v1 -uall)
& cargo metadata --no-deps --format-version 1 --locked --offline 1> "$taskTemp/action-declaration-clean-metadata.json" 2> "$taskTemp/action-declaration-clean-metadata.stderr.log"
if ($LASTEXITCODE) { throw 'Cannot resolve Cargo clean target' }
$metadata = Get-Content -LiteralPath "$taskTemp/action-declaration-clean-metadata.json" -Raw | ConvertFrom-Json -Depth 50
$target = [IO.Path]::GetFullPath($metadata.target_directory)
if ($target.TrimEnd('\') -cne 'D:\git\arcweft\target') { throw "Unexpected Cargo target directory: $target" }
$started = [DateTime]::UtcNow.ToString('o')
$freeBefore = (Get-PSDrive -Name D).Free
[ordered]@{version=1;head=$head;target=$target;command='cargo clean';reason='User explicitly requested a full cargo clean; reverse-normal1 catalog stopped with LNK1180 / disk full, exit 101, before any runtime tests.';status=$status;sourceInputs=$freeze.paths.Count;sourceDrift=0;freeBytes=$freeBefore;startedAt=$started} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskTemp/action-declaration-cargo-clean.before.json" -Encoding utf8
& cargo clean *> "$taskTemp/action-declaration-cargo-clean.log"
$code = $LASTEXITCODE
Assert-Source
$after = @(git --no-optional-locks status --porcelain=v1 -uall)
if ((git rev-parse HEAD).Trim() -ne $head -or @((Compare-Object $status $after)).Count) { throw 'Git state changed across cargo clean' }
[ordered]@{version=1;head=$head;target=$target;command='cargo clean';exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;gitDrift=0;freeBytesBefore=$freeBefore;freeBytesAfter=(Get-PSDrive -Name D).Free;buildArtifactsMovedOrCopied=$false;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');log="$taskTemp/action-declaration-cargo-clean.log"} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskTemp/action-declaration-cargo-clean.json" -Encoding utf8
Get-Content -LiteralPath "$taskTemp/action-declaration-cargo-clean.log" -Raw
Get-Content -LiteralPath "$taskTemp/action-declaration-cargo-clean.json" -Raw
exit $code
