$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$base='e16d141a60faaa4b3c758bb270bcc5ca265691ac'
$source='a2688f77338bd0b34a7651d4910312045a59d6bf'
if((git rev-parse HEAD).Trim() -ne $base){throw 'Unexpected publication base'}
$utf8=[Text.UTF8Encoding]::new($false)
function HashBytes([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
function Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 50}
$normal=Receipt 'action-declaration-reverse-normal2-20261102.runtime.terminal-audit'
$cli=Receipt 'action-declaration-reverse-cli1-20261102.runtime.terminal-audit'
$generic=Receipt 'action-declaration-reverse-genericMatch'
$view=Receipt 'action-declaration-reverse-view40'
if($normal.passed -ne 4327 -or $normal.failed -ne 0 -or $normal.matchedPackages -ne 22 -or $cli.executed -ne 693 -or $cli.passed -ne 660 -or $cli.failed -ne 33 -or $generic.passed -ne 151 -or $view.passed -ne 40){throw 'Unexpected terminal result'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$status=[IO.File]::ReadAllText($statusPath)
$history=[IO.File]::ReadAllBytes($historyPath)
$genericRow=@($status -split [char]10|Where-Object {$_ -like '| Generic Match*'}) -join [char]10
$untracked=Receipt 'task-documentation-final-untracked-before'
foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Original untracked WIP drift: $($row.path)"}}
$raw='docs/implementation/acceptance-evidence/task-action-declaration-consumers.raw.zip'
if(Test-Path -LiteralPath $raw){throw 'Archive exists'}
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object {
    ($_.Name -like 'action-declaration-reverse*' -or $_.Name -like 'action-declaration-cargo-clean*' -or $_.Name -like 'action-declaration-clean-*' -or $_.Name -like 'action-declaration-executable-context*' -or $_.Name -like 'action-after-signature*') -and $_.Extension -in @('.json','.log','.arcw')
})
foreach($name in @('action-declaration.reverse-graph.json','presentation-frame-driver.metadata.json','presentation-frame-driver.metadata-command.json','run-action-declaration-reverse-normal1.ps1','run-action-declaration-reverse-normal2.ps1','run-action-declaration-reverse-cli1.ps1','run-action-declaration-cargo-clean.ps1','probe-action-after-signature.ps1','audit-action-declaration-accepted-boundaries.ps1','audit-action-declaration-cli-delta.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','record-action-declaration-consumers.ps1','checkpoint-action-declaration.verified.json','checkpoint-action-declaration-docs.verified.json')){$files+=Get-Item -LiteralPath "$e/$name"}
$entries=@(foreach($file in ($files|Sort-Object FullName -Unique)){[ordered]@{path=$file.Name;source=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $raw),[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($row in $entries){$output=$zip.CreateEntry($row.path,[IO.Compression.CompressionLevel]::Optimal).Open();$input=[IO.File]::OpenRead($row.source);try{$input.CopyTo($output)}finally{$input.Dispose();$output.Dispose()}}
    $writer=[IO.StreamWriter]::new($zip.CreateEntry('manifest.json').Open(),$utf8);try{$writer.Write((@{version=1;source=$source;runBase=$base;files=$entries}|ConvertTo-Json -Depth 8))}finally{$writer.Dispose()}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $raw))
try{foreach($row in $entries){$stream=$zip.GetEntry($row.path).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw "Archive entry drift: $($row.path)"}};if($zip.Entries.Count -ne $entries.Count+1){throw 'Archive count drift'}}finally{$zip.Dispose()}
$probe=Receipt 'action-after-signature-diagnostics-20261102'
$record=[ordered]@{
    version=1;source=$source;runBase=$base;signatureEvidence='task-action-declaration-signature.json';normal=$normal;cli=$cli
    coverage=(Receipt 'action-declaration-reverse-normal-coverage')
    dependencyGraph=@{roots=@('arcweft-lang-hir','arcweft-lang-sema');reversePackages=23;resolvedPackages=846;workspacePackages=98;graphInputPaths=101;graphInputDrift=0;raw='action-declaration.reverse-graph.json';metadata='presentation-frame-driver.metadata.json';reuse='Unchanged manifests, lockfile, toolchain and configuration retain the prior resolved graph; the exact 101 inputs and complete graph remain in the archive.'}
    initialCatalogFailure=(Receipt 'action-declaration-reverse-normal1-20261102.catalog')
    clean=(Receipt 'action-declaration-cargo-clean')
    cleanUntracked=(Receipt 'action-declaration-clean-untracked-proof')
    executableContext=(Receipt 'action-declaration-executable-context-comparison')
    ownerRerunReason='The isolated and unified owner executable identities differ. The complete 22-package context reran HIR and Sema libraries instead of assuming those earlier executions were equivalent.'
    accepted=@{genericMatch=@{matched=151;passed=$generic.passed;failed=$generic.failed;caseDrift=$generic.caseDrift;raw='action-declaration-reverse-genericMatch.json'};view=@{matched=40;passed=$view.passed;failed=$view.failed;caseDrift=$view.caseDrift;raw='action-declaration-reverse-view40.json'}}
    cliDelta=(Receipt 'action-declaration-reverse-cli-delta')
    currentFailureSamples=(Receipt 'action-declaration-reverse-cli-current-causes')
    probes=@{raw='action-after-signature-matrix-20261102.json';normalization=$probe.normalization;cases=$probe.cases;execution='CLI check only';executable=(Receipt 'action-after-signature-matrix-20261102').executable}
    corrections=@('Replace the pending 23-package consumer statement with the fresh complete normal22 and CLI1 runs.','The fresh CLI universe is 693: 660 PASS and 33 FAIL, not a reconstruction of the prior 692-case run. The failure IDs match the 33 previously unresolved IDs; inspect current stderr for causes.','The initial normal catalog failed with disk-full LNK1180 before runtime tests. Full user-authorized cargo clean removed 242981 files / 287.3 GiB with source and Git drift 0; the successful rerun is a separate epoch.','Action declaration and explicit-ID declaration now pass actual CLI check. Message construction still has no admissible final type; emit and receive have no registered callable target. These are separate unmet protocol boundaries, not a reversal of the repaired signature boundary.','Dotted Action spelling is still rejected by the implementation while the adopted converged surface contains that example. Reconcile the common lexical name/public-ID contract as part of completing the vertical Action implementation.','RAG currently reports unknown text_style. Maintained dialogue chapters still specify text_style/rich_text_style typed calls, so implementation rejection alone does not justify deleting or replacing that source as obsolete.')
    qualityReuse='The source implementation is unchanged since the recorded a2688f77338bd0b34a7651d4910312045a59d6bf signature cut. Workspace check/Clippy/structure and final test-only lint cleanup evidence remain in task-action-declaration-signature.json. This cut changes documentation and evidence only.'
    workingTree=@{heldTracked=12;originalUntracked=$untracked.files.Count;heldPatchSha256='46402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac';originalUntrackedDrift=0}
    historyPrefix=@{bytes=$history.Length;sha256=(HashBytes $history)};genericRowSha256=(HashBytes $utf8.GetBytes($genericRow))
    raw=@{path=$raw;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();payloadEntries=$entries.Count;entryHashDrift=0;buildArtifactsIncluded=$false}
}
$record|ConvertTo-Json -Depth 50|Set-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-action-declaration-consumers.json' -Encoding utf8
$lines=$status -split [char]10
for($index=0;$index -lt $lines.Count;$index++){
    if($lines[$index] -like '確認日:*'){$lines[$index]='確認日: 2026-11-02。最新公開Sourceはa2688f77338bd0b34a7651d4910312045a59d6bf。Action署名変更の影響23 packageを実照合し、通常22は4327 PASS、CLIは下表の実測結果とする。既存12 tracked／6 actual untracked WIPを保持している。前Sourceの全63 package検証は履歴に保持する。'}
    if($lines[$index] -like '| Action宣言のpayload署名解析*'){$lines[$index]='| Action宣言のpayload署名解析 | **宣言・署名の修復は検証・公開済み。送受信の受入は別境界** | Source a2688f77338bd0b34a7651d4910312045a59d6bf。Action自身の引数root・元pattern/localを既存HIR topologyに保持し、Semaが宣言型とchecked意味座標を確定する。通常／明示ID付き宣言は実CLI checkも通過した。message構築は最終型なし、emit／receiveはcallable未登録として拒否され、dotted宣言の採用例との整合も未達である。影響23逆依存の結果は下表へ集約する。[署名修復](acceptance-evidence/task-action-declaration-signature.json)、[実CLIと現在の未達根拠](acceptance-evidence/task-action-declaration-consumers.json)。 |'}
    if($lines[$index] -like '| 共有契約／推移的逆依存matrix*'){$lines[$index]='| 共有契約／推移的逆依存matrix | **現在Sourceの影響23 packageを実照合。通常22は4327／4327 PASS** | base e16d141a60faaa4b3c758bb270bcc5ca265691ac・4082入力、all-target／all-feature／lockedで通常4327 PASS（7 slow）／8 ignored。選択・実行22 package、Source／case／test EXE差分0。単独ownerと統合contextのEXE identityが異なるため、HIR／Sema libraryも同じ統合条件で実行した。Generic Match151／View値40 exact IDは全件PASS。残る1 packageのCLIは次行へ集約する。初回catalogの容量不足と全体clean、前Sourceの全63 runを履歴に保持し、今回の23 packageを全63の再実行とはしない。[現在の照合原本](acceptance-evidence/task-action-declaration-consumers.json)、[前63 run](acceptance-evidence/task-presentation-frame-consumer-closure.json)。 |'}
    if($lines[$index] -like '| CLI全target照合*'){$lines[$index]='| CLI全target照合 | **現在693件を全実行し660 PASS／33 FAIL。新規失敗ID 0** | base e16d141a60faaa4b3c758bb270bcc5ca265691ac・4082入力、all-target／all-feature／lockedで693件を新たに実行した（22 slow、23 ignored）。Source／case／test EXE差分0。失敗33 IDは直前の未修復33 IDと一致するが、原因の同一性はIDから推定せず現在stderrを保持する。旧692件・657 PASS／35 FAILと限定3件修復の途中説明は、新しい全件実測に基づきこの現状欄から整理した。元の結果・改名・追加case・SHAは履歴として保持する。[全件・差分・現在stderr](acceptance-evidence/task-action-declaration-consumers.json)。 |'}
    if($lines[$index] -like '| workspace check／Clippy・fmt・構造gate*'){$lines[$index]='| workspace check／Clippy・fmt・構造gate | **Action署名Sourceの全98 package gate・対象fmtは終了0。警告は残存** | Source a2688f77338bd0b34a7651d4910312045a59d6bfの修復8 pathを対象とし、4082入力でworkspace all-target／all-feature／locked check・Clippyと構造gateを確認した。構造3314 file／3183 Rust／1792937 Rust physical LOC、review trigger384／blocking0。最終差分はtestの空配列assertion 1箇所で、該当testとHIR全target Clippyを再実行し、production差分0により他gateを再利用した。現在のconsumer記録はdocs/evidenceのみの変更である。[gate・入力差分・所有レビュー](acceptance-evidence/task-action-declaration-signature.json)。 |'}
    if($lines[$index] -like '| Source Presentation staging全体*'){$lines[$index]=$lines[$index].Replace('[横断run・修復・現在原因](acceptance-evidence/task-presentation-frame-consumer-closure.json)','[前横断run・修復](acceptance-evidence/task-presentation-frame-consumer-closure.json)、[現在の影響範囲・CLI原因](acceptance-evidence/task-action-declaration-consumers.json)')}
}
$updated=$lines -join [char]10
if((@($updated -split [char]10|Where-Object {$_ -like '| Generic Match*'}) -join [char]10) -cne $genericRow){throw 'Generic row changed'}
[IO.File]::WriteAllText($statusPath,$updated,$utf8)
$append=@"


## 2026-11-02 Action署名Sourceの全23 consumer照合・全体clean・実CLI check

Source a2688f77338bd0b34a7651d4910312045a59d6bf、run base e16d141a60faaa4b3c758bb270bcc5ca265691ac、4082入力でSource／case／test EXE差分0。
通常22 packageは4327／4327 PASS（7 slow）、8 ignored、676.086秒。CLI全targetは693件・660 PASS（22 slow）／33 FAIL、23 ignored、505.485秒。別runとして保持し、全体goalの完了とはしない。
実graphの影響23 packageを通常22とCLI1で照合した。単独ownerと統合contextのEXE identityが異なるため、HIR／Sema libraryも今回の統合条件で実行した。
Generic Matchの既受入151 ID、View値40 IDは同じIDですべてPASS。Generic現状行はbyte不変で、他境界の失敗を理由に受入を戻さない。

初回normal1はcatalogのビルド中にLNK1180／ディスク容量不足で終了101、runtime実行0件。ご指示のcargo cleanでD:\git\arcweft\target全体を削除し、242981 files／287.3 GiBを除去した。
clean終了0、4082 SourceとGit差分0、既存untracked6件のhash差分0。生成物の移動・コピーは行っていない。後続normal2の成功は新たなepochとして記録した。

新しいCLI失敗33 IDは直前の未修復33 IDと一致し、新規失敗ID 0／解消ID 0。元692件・657 PASS／35 FAILと限定3件修復の履歴を保持し、現在693件の全実測へ置換した。ID一致だけで原因まで同一とせず、今回の全raw logと33件のstderr抜粋を保持する。
実CLI checkの最小probeはplain control・Action宣言・明示ID付き宣言が終了0。message構築は最終型なし、emit／receiveはsema.call.unknown_targetで拒否された。
dotted宣言も構文拒否される一方、採用surfaceには同じ例があり、共通local name／public ID規則との整合を実装とともに解決する。署名修復の完了を戻す判定ではなく、送受信protocolの具体的未達条件として記録する。
最初のprobe表示でdiagnosticsの外側からcodeを取りnullとなった点は、stage-wrappedなdiagnosticへ正規化して訂正した。元stdoutとmatrixには完全な診断が保存されており、変更していない。
RAGの現在診断はunknown text_styleである。現行dialogue仕様にはtext_style／rich_text_style呼出しが残っており、実装拒否だけを根拠にshowcaseをobsoleteとして削除・差し替える判定はしない。

現状一覧から23 consumer未実行と古いCLI途中集計を削除した理由は、今回の全件実測である。元の失敗・検証値・full SHAは履歴として保持する。今回のdocs/evidence変更でRust sourceは変更せず、署名cutのworkspace gateを再利用した。
原本は[Action consumer照合](acceptance-evidence/task-action-declaration-consumers.json)。既存12 tracked／6 actual untracked WIPを保持する。
"@
$stream=[IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write);try{$stream.Write($utf8.GetBytes($append))}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($historyPath);if((HashBytes $after[0..($history.Length-1)]) -ne (HashBytes $history)){throw 'Historical prefix changed'}
[ordered]@{version=1;source=$source;normalPassed=4327;cliPassed=660;cliFailed=33;genericUnchanged=$true;historyPrefixUnchanged=$true;archiveEntries=$entries.Count;archiveBytes=(Get-Item -LiteralPath $raw).Length}|ConvertTo-Json|Set-Content -LiteralPath "$e/action-declaration-consumers-doc-audit.json" -Encoding utf8
Get-Content -LiteralPath "$e/action-declaration-consumers-doc-audit.json" -Raw
