$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prior = Get-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-presentation-frame-consumer-closure.json' -Raw | ConvertFrom-Json -Depth 50
$current = Get-Content -LiteralPath "$taskTemp/action-declaration-reverse-cli1-20261102.runtime.terminal-audit.json" -Raw | ConvertFrom-Json -Depth 30
$old = @($prior.remainingCliFailures)
if ($old.Count -ne 33) { throw 'Published comparison baseline differs' }
$oldKeys = @($old | ForEach-Object { $_.binary + "`t" + $_.test })
$newKeys = @($current.failureSet | ForEach-Object { $_.binary + "`t" + $_.test })
$retained = @($current.failureSet | Where-Object { ($_.binary + "`t" + $_.test) -in $oldKeys })
$added = @($current.failureSet | Where-Object { ($_.binary + "`t" + $_.test) -notin $oldKeys })
$resolved = @($old | Where-Object { ($_.binary + "`t" + $_.test) -notin $newKeys })
$result = [ordered]@{
    version=1
    current=$current
    comparisonSource='docs/implementation/acceptance-evidence/task-presentation-frame-consumer-closure.json'
    comparisonMeaning='33 unresolved case IDs from the published 692-case run plus separately verified publication expectation repairs; this is not a prior full 693-case run.'
    baselineFailureCount=$old.Count
    retainedFailureIds=$retained
    newlyFailingIds=$added
    resolvedFailureIds=$resolved
    causeCaution='Matching case IDs do not prove matching causes. Preserve the current complete runtime log and inspect current failure blocks.'
}
$result | ConvertTo-Json -Depth 40 | Set-Content -LiteralPath "$taskTemp/action-declaration-reverse-cli-delta.json" -Encoding utf8
[pscustomobject]@{executed=$current.executed;passed=$current.passed;failed=$current.failed;retained=$retained.Count;added=$added.Count;resolved=$resolved.Count;sourceDrift=$current.sourceDrift;caseDrift=$current.catalogCaseDrift} | ConvertTo-Json
