$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$paths = @((Get-Content -LiteralPath "$taskTemp/action-declaration-reverse-normal2-20261102.source-freeze.json" -Raw | ConvertFrom-Json).paths.path)
& "$taskTemp/run-presentation-projection-owner.ps1" -Stem 'action-declaration-reverse-cli1-20261102' -Selection @('-p','arcweft-cli','--all-targets','--all-features','--locked') -ExpectedMatches 693 -AdditionalPaths $paths
