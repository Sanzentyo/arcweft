$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$publication=Get-Content -Raw "$root/port-authority.publication.json"|ConvertFrom-Json
$summary=Get-Content -Raw "$root/port-authority.owner-summary.json"|ConvertFrom-Json
if($summary.Source -ne $publication.Source -or $summary.Passed -ne 1645 -or $summary.Failed -ne 6){throw 'Owner evidence differs'}
$files=[Collections.Generic.List[object]]::new()
foreach($file in Get-ChildItem -LiteralPath $root -File|Where-Object {$_.Name -like 'port-authority.*' -or $_.Name -in @('run-port-authority-owner.ps1','audit-port-authority-owner.ps1','make-port-authority-archive.ps1')}){
    if($file.Name -like '*.archive.json'){continue}
    $files.Add([pscustomobject]@{Path=$file.FullName;Entry='evidence/'+$file.Name})
}
foreach($path in $publication.Paths){
    if((Get-FileHash -LiteralPath $path.Path -Algorithm SHA256).Hash -ne $path.SHA256){throw 'Source changed'}
    $files.Add([pscustomobject]@{Path=(Join-Path (Get-Location) $path.Path);Entry='source/'+$path.Path.Replace([char]92,[char]47)})
}
foreach($name in @('scheme-instantiation.owner-terminal.json','scheme-instantiation.owner-summary.json','scheme-instantiation.reverse-reuse.json')){
    $files.Add([pscustomobject]@{Path="$root/$name";Entry='baseline/'+$name})
}
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=@($files|ForEach-Object {[ordered]@{Name=$_.Entry;Bytes=(Get-Item -LiteralPath $_.Path).Length;SHA256=(Get-FileHash -LiteralPath $_.Path -Algorithm SHA256).Hash}})}
$manifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($manifest|ConvertTo-Json -Depth 6))
$destination='D:/git/arcweft/docs/implementation/acceptance-evidence/task-operand-port-authority.raw.zip'
$stream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try {
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try {
        foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.Path,$file.Entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
        $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal)
        $out=$entry.Open()
        try {$out.Write($manifestBytes)}finally{$out.Dispose()}
    }finally{$zip.Dispose()}
}finally{$stream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($destination)
$rawBytes=0L
try {
    if($zip.Entries.Count -ne $manifest.Entries.Count+1){throw 'Archive entry count differs'}
    foreach($expected in @($manifest.Entries)+@([pscustomobject]@{Name='manifest.json';Bytes=$manifestBytes.Length;SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($manifestBytes))})){
        $entry=$zip.GetEntry($expected.Name)
        if(!$entry -or $entry.FullName.Contains('\') -or $entry.Length -ne $expected.Bytes){throw 'Archive entry length/path differs'}
        $input=$entry.Open()
        try {$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($input))}finally{$input.Dispose()}
        if($hash -cne $expected.SHA256){throw 'Archive entry hash differs'}
        $rawBytes+=$entry.Length
    }
    $count=$zip.Entries.Count
}finally{$zip.Dispose()}
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Path=$destination;Entries=$count;RawBytes=$rawBytes;ZIPBytes=(Get-Item -LiteralPath $destination).Length;SHA256=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash;AllEntriesVerified=$true}|ConvertTo-Json|Set-Content -Encoding utf8 "$root/port-authority.archive.json"
Get-Content "$root/port-authority.archive.json"
