$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$runDir=$PSScriptRoot
. "$runDir/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$runDir/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$source=Read-Record 'view-authored-target-20261108.source.verified.json'
if($source.commit -ne 'faa2d2aaf2eef6c7dbd6c76f6757c0e6a4d0b9c1' -or (git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected source'}
$owner=Read-Record 'view-authored-target-20261108.owner-r2.runtime.terminal-audit.json'
$baseline=Read-Record 'view-authored-target-20261108.collision-baseline.runtime.terminal-audit.json'
if($owner.passed -ne 90 -or $owner.failed -ne 0 -or $baseline.failed -ne 1){throw 'Owner result differs'}
$quality=@(foreach($name in @('check','clippy','structure','fmt')){Read-Record "view-authored-target-20261108.quality.$name.receipt.json"})
if(@($quality|Where-Object exitCode -ne 0).Count){throw 'Quality failure'}
$archive='docs/implementation/acceptance-evidence/task-view-authored-target-owner.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
$raw=@(Get-ChildItem -LiteralPath $runDir -File -Filter 'view-authored-target-20261108*') + @((Get-Item -LiteralPath "$runDir/run-view-authored-target-quality-20261108.ps1"),(Get-Item -LiteralPath "$runDir/run-retained-input-frozen-matrix-20261108.ps1"),(Get-Item -LiteralPath "$runDir/audit-nextest-final-result.ps1"),(Get-Item -LiteralPath $PSCommandPath))
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($file in ($raw|Sort-Object FullName -Unique)){
        if($file.Extension -notin @('.log','.json','.patch','.txt','.pathspec','.ps1')){throw 'Unexpected raw entry'}
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    foreach($file in Get-ChildItem -LiteralPath "$runDir/view-authored-target-20261108.structure-report" -File){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('structure/'+$file.Name),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|rlib|rmeta|dll|pdb)$').Count){throw 'Build artifact in raw archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$record=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($record.PSObject.Properties.Name -contains 'viewAuthoredTargetOwner'){throw 'Owner record exists'}
$entry=[ordered]@{
    version=1;date='2026-11-08';sourcePublication=$source
    scope='Compile-time PublicId target argument on builtin View elements; checked scalar -> product -> runtime input/style/event identity'
    owner=$owner;collisionBeforeRepair=$baseline
    firstFocusedRun=(Read-Record 'view-authored-target-20261108.owner-r1.runtime.terminal-audit.json')
    workspaceQuality=$quality;graph=(Read-Record 'view-authored-target-20261108.graph.json')
    structuralReview=(Read-Record 'view-authored-target-20261108.structure-review.json')
    behavior=@('Real canonical AWFB round trip, exact style-node targets, mount-scoped text input and button event route, Japanese edit then click reads the current retained field.','Dynamic/non-PublicId/repeated arguments reject before product publication.','A real container/input collision compiled before the repair; the existing bounded bundle traversal now rejects collisions per definition for producers and decoded candidates. Forged canonical encoding and ValidatedViewProduct admission both reject.','The existing keyed-input lifetime test now uses an authored target and keeps all distinct-target, edit/reorder, removal/reintroduction and stale-session assertions.')
    corrections='Replace generated-only target lowering with checked optional authored PublicId. This extends the retained input contract and does not reopen prior Generic Match, input, or Action acceptance.'
    archive=$archiveInfo
    integration='Owner and workspace gates passed. Complete reverse-consumer run is in progress; old samples, Scroll projection and Native/Web display remain separate acceptance boundaries.'
    preservedPriorRecords=@($record.PSObject.Properties).Count
}
$wrapper=(ConvertTo-Json -InputObject ([ordered]@{viewAuthoredTargetOwner=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd();$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $record.PSObject.Properties){if((ConvertTo-Json -InputObject $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[ordered]@{source=$source.commit;priorRecords=@($record.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$archiveInfo}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$runDir/view-authored-target-owner-record-audit.json" -Encoding utf8
Get-Content -LiteralPath "$runDir/view-authored-target-owner-record-audit.json" -Raw
