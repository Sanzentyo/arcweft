$ErrorActionPreference = 'Stop'
$e = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$pin = Get-Content -Raw -LiteralPath (Join-Path $e 'flow-transfer-modern-cli-r1.pin.json') | ConvertFrom-Json
$freeze = Get-Content -Raw -LiteralPath (Join-Path $e 'flow-transfer-modern-sample-r1.inputs.json') | ConvertFrom-Json
if ((& git rev-parse HEAD).Trim() -ne $freeze.base) { throw 'Source HEAD changed' }
foreach ($row in $freeze.paths) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Sample input changed' }
}
$patch = Read-GitBytes @('diff','--binary','--full-index')
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant() -ne $freeze.patchSha256) { throw 'Tracked patch changed' }
$cases = @(
    @{ name='empty-control'; manifest=(Join-Path $e 'stateful-goto-current-20261109.empty-control/arcw.toml') },
    @{ name='bare-self-goto'; manifest=(Join-Path $e 'stateful-goto-current-20261109.self-goto/arcw.toml') },
    @{ name='explicit-self-goto'; manifest=(Join-Path $e 'stateful-goto-explicit-20261109.wip6/arcw.toml') },
    @{ name='modern-feedback'; manifest='D:/git/arcweft/samples/modern-feedback-view/arcw.toml' }
)
$rows = @()
foreach ($case in $cases) {
    if ((Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256) { throw 'CLI binary changed' }
    $output = 'D:/git/arcweft/target/arcweft/flow-transfer-modern-r1-' + $case.name + '.awfb'
    if (Test-Path -LiteralPath $output) { throw 'Probe output already exists' }
    $checkLog = Join-Path $e ('flow-transfer-modern-r1-' + $case.name + '.check.log')
    $bundleLog = Join-Path $e ('flow-transfer-modern-r1-' + $case.name + '.bundle.log')
    $clock = [Diagnostics.Stopwatch]::StartNew()
    & $pin.path check --manifest-path $case.manifest *> $checkLog
    $checkExit = $LASTEXITCODE
    & $pin.path bundle --manifest-path $case.manifest --profile main --output $output *> $bundleLog
    $bundleExit = $LASTEXITCODE
    $clock.Stop()
    $artifact = if (Test-Path -LiteralPath $output) {
        [ordered]@{path=$output;bytes=(Get-Item -LiteralPath $output).Length;sha256=(Get-FileHash -LiteralPath $output).Hash.ToLowerInvariant()}
    } else { $null }
    $row = [ordered]@{name=$case.name;manifest=$case.manifest;checkExit=$checkExit;bundleExit=$bundleExit;seconds=$clock.Elapsed.TotalSeconds;artifact=$artifact}
    $rows += $row
    $row | ConvertTo-Json -Depth 4 -Compress
}
if ((Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256) { throw 'CLI binary drift' }
$patchAfter = Read-GitBytes @('diff','--binary','--full-index')
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patchAfter)).ToLowerInvariant() -ne $freeze.patchSha256) { throw 'Source drift' }
[ordered]@{version=1;base=$freeze.base;cli=$pin;binaryDrift=0;trackedPatchDrift=0;cases=$rows;note='Original executable/output paths only. No copied EXE/AWFB. These are CLI probes, not additions to nextest counts.'} |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $e 'flow-transfer-modern-r1.results.json') -Encoding utf8
