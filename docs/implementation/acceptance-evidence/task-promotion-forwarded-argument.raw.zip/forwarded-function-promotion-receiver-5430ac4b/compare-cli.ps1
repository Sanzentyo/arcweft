$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-forward-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$qa=ArcJson (Join-Path $d 'quality.receipt.json')
$before=ArcJson (Join-Path $d 'baseline.receipt.json')
$extensions=ArcJson (Join-Path $d 'extension-baseline.receipt.json')
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($qa.base -ne $before.base -or $qa.base -ne $extensions.base -or $before.cliSha256 -ne $extensions.cliSha256 -or $qa.cliSha256 -ne $sha -or $sha -eq $before.cliSha256){throw 'Source or CLI build differs'}
foreach($row in $qa.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
function ReadArcResult($name,$command,$source,$expected,$expectedSpan){
    $out=Join-Path $d "$name.$command.after.json"
    $err=Join-Path $d "$name.$command.after.stderr.log"
    if($command -eq 'verify'){
        & $cli verify $source --mode test --backend emit --json > $out 2> $err
    }else{
        & $cli check $source --json > $out 2> $err
    }
    $code=$LASTEXITCODE
    $report=ArcJson $out
    $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
    if($code -ne 1 -or $report.status -ne 'denied' -or $report.stage -ne 'type-check' -or $diagnostics.Count -ne 1 -or $diagnostics[0].code -ne $expected -or $report.obligations -or $report.solver_checks){throw "Unexpected $name $command result $($diagnostics.code -join ',')"}
    $span=$diagnostics[0].span
    $spelling=(Get-Content -LiteralPath $source -Raw).Substring($span.start,$span.end-$span.start)
    if($spelling -cne $expectedSpan){throw "Unexpected $name $command span $spelling"}
    [ordered]@{name=$name;command=$command;exit=$code;stage=$report.stage;code=$diagnostics[0].code;span=$spelling;start=$span.start;end=$span.end;inputSha256=ArcSha $source;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
}
$controls='forward-generic-owned','forward-owned-selected','forward-recursive-rotation'
$inputs=@($before.cases)+@($extensions.cases)
$results=@(foreach($row in $inputs){
    $source=Join-Path $d "$($row.name).arcw"
    if($row.stage -ne 'type-check' -or $row.exit -ne 1 -or ($row.codes -join ',') -ne 'sema.lifetime.promotion_execution' -or (ArcSha $source) -ne $row.inputSha256){throw "Baseline differs $($row.name)"}
    $expected,$spelling=if($row.name -in $controls){'sema.lifetime.promotion_execution',"callback.promote('flow)"}else{'sema.lifetime.promotion_receiver','callback'}
    ReadArcResult $row.name 'check' $source $expected $spelling
    if($row.name -in 'forward-generic-chain','forward-owned-selected','forward-extension'){ReadArcResult $row.name 'verify' $source $expected $spelling}
})
if($inputs.Count -ne 14 -or $results.Count -ne 17 -or (ArcSha $cli) -ne $sha){throw 'CLI receipt differs'}
[ordered]@{version=1;base=$qa.base;cliSha256=$sha;cases=$results}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
$results|ForEach-Object {[pscustomobject]$_}|Format-Table name,command,code,span
exit 0
