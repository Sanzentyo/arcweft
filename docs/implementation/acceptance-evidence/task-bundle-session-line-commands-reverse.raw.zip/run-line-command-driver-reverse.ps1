$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
$source='47535b1c545ff753efa460a14a1a192c8e4256c2'
$tree=(git rev-parse 'HEAD^{tree}').Trim()
$prefix='line-command-driver-reverse-r1'
function Confirm-Source {
    if ((git rev-parse HEAD).Trim() -ne $source -or (git rev-parse 'HEAD^{tree}').Trim() -ne $tree -or @(git diff HEAD --name-only).Count) { throw 'Source/index changed' }
}
Confirm-Source
$graph=Get-Content -LiteralPath (Join-Path $e 'line-command-driver-rdeps.json') -Raw | ConvertFrom-Json
if ($graph.packageCount -ne 12 -or @(git diff $graph.source HEAD --name-only -- Cargo.lock Cargo.toml ':(glob)**/Cargo.toml').Count) {throw 'Dependency input changed'}
$selection=@('--locked','--all-features','-E','rdeps(=arcweft-runtime-driver) or rdeps(=arcweft-compiler)')
foreach ($package in $graph.packages) {$selection+=@('-p',$package)}
$listArgs=@('nextest','list','--message-format','json')+$selection
$runArgs=@('nextest','run','--no-fail-fast','--no-tests','fail')+$selection
[ordered]@{version=1;source=$source;tree=$tree;packages=$graph.packages;listArgs=$listArgs;runArgs=$runArgs} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.inputs.json')) -Encoding utf8
$listLog=Join-Path $e ($prefix+'.list.log')
& cargo @listArgs *> $listLog
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$catalog=([IO.File]::ReadLines($listLog) | Where-Object {$_.StartsWith('{')} | Select-Object -Last 1) | ConvertFrom-Json -AsHashtable
$ids=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$paths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$testedPackages=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($suite in $catalog.'rust-suites'.Values) {
    if ($suite.'package-name' -notin $graph.packages) {throw 'Unexpected reverse test package'}
    foreach ($test in $suite.testcases.Keys) {
        if ($suite.testcases[$test].'filter-match'.status -ne 'matches') { continue }
        if (!$ids.Add($suite.'binary-id'+' '+$test)) {throw 'Duplicate test identity'}
        [void]$paths.Add($suite.'binary-path')
        [void]$testedPackages.Add($suite.'package-name')
    }
}
foreach ($packageBins in $catalog.'rust-build-meta'.'non-test-binaries'.Values) {
    foreach ($binary in $packageBins) {
        if ($binary.kind -eq 'bin-exe') { [void]$paths.Add((Join-Path $catalog.'rust-build-meta'.'target-directory' $binary.path)) }
    }
}
$regression='arcweft-compiler::source_presentation_driver source_dialogue_line_commands_resume_through_the_bundle_session_after_restore'
if (!$ids.Contains($regression)) {throw 'Missing regression test'}
function Read-Pins {
    @(foreach ($p in ($paths | Sort-Object)) {
        [ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}
    })
}
Write-Host ('Selected '+$ids.Count+' tests across '+$testedPackages.Count+' packages.')
$before=Read-Pins
$before | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-before.json')) -Encoding utf8
Confirm-Source
$log=Join-Path $e ($prefix+'.run.log')
$watch=[Diagnostics.Stopwatch]::StartNew()
& cargo @runArgs *> $log
$code=$LASTEXITCODE
$watch.Stop()
$after=Read-Pins
$after | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-after.json')) -Encoding utf8
Confirm-Source
$drift=@(for ($i=0;$i -lt $before.Count;$i++) {
    if ($before[$i].path -ne $after[$i].path -or $before[$i].sha256 -ne $after[$i].sha256 -or $before[$i].bytes -ne $after[$i].bytes) {$before[$i].path}
})
function Test-Statuses([string]$file) {
    $map=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
    foreach ($line in [IO.File]::ReadLines($file)) {
        if ($line -match '^\s+(PASS|FAIL|SKIP|TIMEOUT|LEAK)\s+\[[^\]]+\]\s+\([^)]+\)\s+(\S+)\s+(.+?)\s*$') {
            $map[$Matches[2]+' '+$Matches[3]]=$Matches[1]
        }
    }
    return ,$map
}
$actual=Test-Statuses $log
$baselinePrefix='flow-transfer-convergence-reverse-run-static-type-r2'
$baseline=Test-Statuses (Join-Path $e ($baselinePrefix+'.log'))
$baselineSubset=@($baseline.Keys | Where-Object {($_ -split '::| ',2)[0] -in $graph.packages})
$diff=[ordered]@{
    added=@($actual.Keys | Where-Object {!$baseline.ContainsKey($_)} | Sort-Object);
    removed=@($baselineSubset | Where-Object {!$actual.ContainsKey($_)} | Sort-Object);
    changed=@($actual.Keys | Where-Object {$baseline.ContainsKey($_) -and $baseline[$_] -cne $actual[$_]} | Sort-Object | ForEach-Object {[ordered]@{test=$_;previous=$baseline[$_];actual=$actual[$_]}})
}
$summary=@([IO.File]::ReadLines($log) | Where-Object {$_ -match 'Summary \['})
$diagnosticBaseline=Get-Content -LiteralPath (Join-Path $e 'flow-static-type-reverse-delta.json') -Raw | ConvertFrom-Json
$diagnosticDelta=@(foreach ($item in $diagnosticBaseline.cliDiagnostics) {
    $found=@([IO.File]::ReadLines($log) | Where-Object {$_ -match $item.pattern} | Sort-Object -Unique)
    [ordered]@{pattern=$item.pattern;before=$item.after;after=$found;matches=(@(Compare-Object @($item.after) $found -CaseSensitive).Count -eq 0)}
})
$result=[ordered]@{
    version=1;source=$source;tree=$tree;selected=$ids.Count;packages=@($testedPackages | Sort-Object);exitCode=$code;seconds=$watch.Elapsed.TotalSeconds;
    summary=$summary;executed=$actual.Count;binaryDrift=$drift;sourceDrift=0;regression=$actual[$regression];comparisonBase='e4d736ac55693fb2fae402e079fd465391cb62c7';
    failures=@($actual.Keys | Where-Object {$actual[$_] -ne 'PASS'} | Sort-Object);delta=$diff;cliDiagnostics=$diagnosticDelta
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.results.json')) -Encoding utf8
$result | ConvertTo-Json -Depth 8 -Compress
exit $code