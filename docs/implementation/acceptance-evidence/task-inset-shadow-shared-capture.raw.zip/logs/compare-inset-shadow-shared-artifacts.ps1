$ErrorActionPreference='Stop'
$e=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
$out='target/retained-inset-shadow-shared-20261109'
$repeat='target/retained-inset-shadow-shared-20261109-web-repeat'
$gold='fixtures/visual-smoke-goldens/seq06.13e.1-inset-box-shadow'
$n='seq06_13e1_inset_box_shadow'
$native=Get-Content -Raw -LiteralPath (Join-Path $out "native/$n.observe.json") | ConvertFrom-Json -AsHashtable
$web=Get-Content -Raw -LiteralPath (Join-Path $repeat "web/$n.observe.json") | ConvertFrom-Json -AsHashtable
if($native.bundle_artifact -ne $web.bundle_artifact -or $native.bundle_artifact -cnotmatch '^[a-f0-9]{64}$'){throw 'AWFB identity mismatch'}
foreach($key in @('runtime_surfaces','player_view_scenes','primitives','paint_nodes','outer_shadows','inset_shadows')){
    if($native.stats[$key] -ne $web.stats[$key]){throw "Mismatched plan statistic $key"}
}
$files=[ordered]@{
    native=(Join-Path $out "native/$n.candidate.png")
    web=(Join-Path $repeat "web/$n.candidate.png")
    firstWeb=(Join-Path $out "web/$n.candidate.png")
    nativeRef=(Join-Path $gold "native/$n.png")
    webRef=(Join-Path $gold "web/$n.png")
}
$hashes=[ordered]@{}
foreach($key in $files.Keys){$hashes[$key]=(Get-FileHash -LiteralPath $files[$key]).Hash.ToLowerInvariant()}
if($hashes.web -ne $hashes.firstWeb){throw 'Web repeated PNG differs'}
function Measure-PngPair([string]$name,[string]$reference,[string]$candidate,[string]$metrics){
    $log=Join-Path $e ("inset-shadow-shared-$name.imq.json")
    & imq image $reference $candidate --metrics $metrics --format json > $log
    if($LASTEXITCODE -ne 0){throw "imq failed for $name"}
    $j=Get-Content -Raw -LiteralPath $log | ConvertFrom-Json
    if($j.dimensions.width -ne 320 -or $j.dimensions.height -ne 180){throw "Wrong PNG dimensions for $name"}
    $result=[ordered]@{}
    foreach($entry in $j.metrics){$result[$entry.name]=$entry.score}
    return $result
}
$direct=Measure-PngPair 'native-web' $files.native $files.web 'psnr,ssim,mse,mae,maxae'
$rgba=Measure-PngPair 'native-web-rgba' $files.native $files.web 'psnr:all,mse:all,mae:all,maxae:all'
$nativeBaseline=Measure-PngPair 'native-baseline' $files.nativeRef $files.native 'psnr,ssim,mse,mae,maxae'
$webBaseline=Measure-PngPair 'web-repeat-baseline' $files.webRef $files.web 'psnr,ssim,mse,mae,maxae'
$wasm=Get-Content -Raw -LiteralPath (Join-Path $repeat "web/$n.environment.json") | ConvertFrom-Json -AsHashtable
$bundle=Join-Path $out 'fixture.awfb'
$result=[ordered]@{
    version=1
    bundleSha256=(Get-FileHash -LiteralPath $bundle).Hash.ToLowerInvariant()
    bundleSize=(Get-Item -LiteralPath $bundle).Length
    bundleArtifact=$native.bundle_artifact
    width=320
    height=180
    stats=$native.stats
    sha256=$hashes
    nativeAdapter=$native.adapter
    webBrowser=$wasm.environment.browser
    webRuntime=$wasm.environment.runtime
    webAdapter=$wasm.environment.webgpu
    maxMse=0.002
    maxMae=0.003
    direct=$direct
    allRgba=$rgba
    nativeBaseline=$nativeBaseline
    webBaseline=$webBaseline
    promoted=$false
}
$result | ConvertTo-Json -Depth 9 | Tee-Object -FilePath (Join-Path $e 'inset-shadow-shared-comparison.json')
if($direct.mse -gt $result.maxMse -or $direct.mae -gt $result.maxMae){throw 'Direct Native/Web parity exceeded the current thresholds'}
