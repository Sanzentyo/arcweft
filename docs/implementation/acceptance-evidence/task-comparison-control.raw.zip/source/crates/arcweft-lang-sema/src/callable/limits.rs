//! Inclusive callable catalog and query limits.
use std::sync::atomic::{AtomicBool, Ordering};

use super::{
    CallableBuildLimitError, CallableQueryLimitError, SignatureLimitExceeded, SignatureLimitKind,
    SignatureWorkKind,
};
use crate::types::constraints::context::{
    TypeConstraintAccounting, TypeConstraintContextIssuer, TypeConstraintLimits,
    TypeConstraintWorkReport,
};
use crate::types::constraints::{TypeConstraintAbort, TypeConstraintError};

mod retained;
pub(crate) use retained::RetainedResolverWork;

/// Fixed resource limits shared by callable registration and semantic queries.
#[allow(
    clippy::struct_field_names,
    reason = "the contract names each inclusive bound as an explicit maximum"
)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct CallableLimits {
    max_path_segments: usize,
    max_groups_per_callable: usize,
    max_parameters_per_callable: usize,
    max_overloads_per_key: usize,
    max_candidates_per_call: usize,
    max_nested_calls: usize,
    max_recovery_nodes: usize,
    max_diagnostics: usize,
    max_source_bytes: usize,
    max_project_modules: usize,
    max_catalog_records: usize,
    max_catalog_build_work: u64,
    max_query_work: u64,
    max_call_constraint_branches: u64,
    max_call_constraint_nodes: u64,
    max_call_constraint_source_probes: u64,
    max_call_constraint_materializations: u64,
    max_call_solution_bindings: u64,
}

/// Production callable limits. Every bound is inclusive.
pub const PRODUCTION_CALLABLE_LIMITS: CallableLimits = CallableLimits {
    max_path_segments: 32,
    max_groups_per_callable: 16,
    max_parameters_per_callable: 128,
    max_overloads_per_key: 32,
    max_candidates_per_call: 256,
    max_nested_calls: 32,
    max_recovery_nodes: 256,
    max_diagnostics: 128,
    max_source_bytes: 8_388_608,
    max_project_modules: 4_096,
    max_catalog_records: 262_144,
    max_catalog_build_work: 1_048_576,
    max_query_work: 4_096,
    max_call_constraint_branches: 256,
    max_call_constraint_nodes: 16_384,
    max_call_constraint_source_probes: 512,
    max_call_constraint_materializations: 512,
    max_call_solution_bindings: 128,
};

/// Inclusive public signature-search and result limits.
///
/// These limits are intentionally independent from callable catalog and
/// resolver staging. In particular, resolver facts fail closed at their own
/// diagnostic limit while the public result deterministically truncates its
/// diagnostic projection.
#[allow(
    clippy::struct_field_names,
    reason = "the contract names each inclusive bound as an explicit maximum"
)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignatureQueryLimits {
    candidate_calls: u64,
    overloads: u64,
    parameters_per_signature: u64,
    nested_calls: u64,
    recovery_nodes: u64,
    source_bytes: u64,
    diagnostics: u64,
    work_units: u64,
}

/// Production signature limits. Every bound is inclusive.
pub const PRODUCTION_SIGNATURE_LIMITS: SignatureQueryLimits = SignatureQueryLimits::PRODUCTION;

impl SignatureQueryLimits {
    pub const PRODUCTION: Self = Self {
        candidate_calls: 4_096,
        overloads: 64,
        parameters_per_signature: 128,
        nested_calls: 64,
        recovery_nodes: 512,
        source_bytes: 8_388_608,
        diagnostics: 32,
        work_units: 262_144,
    };

    pub const fn candidate_calls(self) -> u64 {
        self.candidate_calls
    }

    pub const fn overloads(self) -> u64 {
        self.overloads
    }

    pub const fn parameters_per_signature(self) -> u64 {
        self.parameters_per_signature
    }

    pub const fn nested_calls(self) -> u64 {
        self.nested_calls
    }

    pub const fn recovery_nodes(self) -> u64 {
        self.recovery_nodes
    }

    pub const fn source_bytes(self) -> u64 {
        self.source_bytes
    }

    pub const fn diagnostics(self) -> u64 {
        self.diagnostics
    }

    pub const fn work_units(self) -> u64 {
        self.work_units
    }
}

impl CallableLimits {
    pub const fn max_path_segments(self) -> usize {
        self.max_path_segments
    }
    pub const fn max_groups_per_callable(self) -> usize {
        self.max_groups_per_callable
    }
    pub const fn max_parameters_per_callable(self) -> usize {
        self.max_parameters_per_callable
    }
    pub const fn max_overloads_per_key(self) -> usize {
        self.max_overloads_per_key
    }
    pub const fn max_candidates_per_call(self) -> usize {
        self.max_candidates_per_call
    }
    pub const fn max_nested_calls(self) -> usize {
        self.max_nested_calls
    }
    pub const fn max_recovery_nodes(self) -> usize {
        self.max_recovery_nodes
    }
    pub const fn max_diagnostics(self) -> usize {
        self.max_diagnostics
    }
    pub const fn max_source_bytes(self) -> usize {
        self.max_source_bytes
    }
    pub const fn max_project_modules(self) -> usize {
        self.max_project_modules
    }
    pub const fn max_catalog_records(self) -> usize {
        self.max_catalog_records
    }
    pub const fn max_catalog_build_work(self) -> u64 {
        self.max_catalog_build_work
    }
    pub const fn max_query_work(self) -> u64 {
        self.max_query_work
    }

    /// Maximum number of distinct generic constraint branches for one candidate.
    pub const fn max_call_constraint_branches(self) -> u64 {
        self.max_call_constraint_branches
    }

    /// Maximum semantic nodes visited by one candidate constraint relation.
    pub const fn max_call_constraint_nodes(self) -> u64 {
        self.max_call_constraint_nodes
    }

    /// Maximum isolated source probes retained by one lower candidate run.
    pub const fn max_call_constraint_source_probes(self) -> u64 {
        self.max_call_constraint_source_probes
    }

    /// Maximum final source materializations retained by one lower candidate run.
    pub const fn max_call_constraint_materializations(self) -> u64 {
        self.max_call_constraint_materializations
    }

    /// Maximum generic bindings retained by one candidate solution.
    pub const fn max_call_solution_bindings(self) -> u64 {
        self.max_call_solution_bindings
    }

    /// Projects callable policy and an exact remaining resolver budget into
    /// the lower types-owned constraint context limits.
    pub(crate) const fn type_constraint_limits(self, remaining_work: u64) -> TypeConstraintLimits {
        TypeConstraintLimits::new(
            remaining_work,
            self.max_call_constraint_nodes,
            self.max_call_constraint_branches,
            self.max_call_solution_bindings,
        )
        .with_source_limits(
            self.max_call_constraint_source_probes,
            self.max_call_constraint_materializations,
        )
    }

    #[cfg(test)]
    #[allow(
        clippy::too_many_arguments,
        reason = "test fixtures need independent exact and one-over limit controls"
    )]
    pub(crate) const fn for_test(
        max_path_segments: usize,
        max_groups_per_callable: usize,
        max_parameters_per_callable: usize,
        max_overloads_per_key: usize,
        max_candidates_per_call: usize,
        max_nested_calls: usize,
        max_recovery_nodes: usize,
        max_diagnostics: usize,
        max_catalog_build_work: u64,
        max_query_work: u64,
    ) -> Self {
        Self {
            max_path_segments,
            max_groups_per_callable,
            max_parameters_per_callable,
            max_overloads_per_key,
            max_candidates_per_call,
            max_nested_calls,
            max_recovery_nodes,
            max_diagnostics,
            max_source_bytes: 8_388_608,
            max_project_modules: 4_096,
            max_catalog_records: 262_144,
            max_catalog_build_work,
            max_query_work,
            max_call_constraint_branches: PRODUCTION_CALLABLE_LIMITS.max_call_constraint_branches,
            max_call_constraint_nodes: PRODUCTION_CALLABLE_LIMITS.max_call_constraint_nodes,
            max_call_constraint_source_probes: PRODUCTION_CALLABLE_LIMITS
                .max_call_constraint_source_probes,
            max_call_constraint_materializations: PRODUCTION_CALLABLE_LIMITS
                .max_call_constraint_materializations,
            max_call_solution_bindings: PRODUCTION_CALLABLE_LIMITS.max_call_solution_bindings,
        }
    }

    #[cfg(test)]
    pub(crate) const fn with_type_constraint_limits(
        mut self,
        max_call_constraint_branches: u64,
        max_call_constraint_nodes: u64,
        max_call_solution_bindings: u64,
    ) -> Self {
        self.max_call_constraint_branches = max_call_constraint_branches;
        self.max_call_constraint_nodes = max_call_constraint_nodes;
        self.max_call_solution_bindings = max_call_solution_bindings;
        self
    }

    #[cfg(test)]
    pub(crate) const fn with_type_constraint_source_limits(
        mut self,
        max_call_constraint_source_probes: u64,
        max_call_constraint_materializations: u64,
    ) -> Self {
        self.max_call_constraint_source_probes = max_call_constraint_source_probes;
        self.max_call_constraint_materializations = max_call_constraint_materializations;
        self
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct CatalogBuildWork {
    consumed: u64,
    limit: u64,
}

impl CatalogBuildWork {
    pub(crate) const fn new(limit: u64) -> Self {
        Self { consumed: 0, limit }
    }

    pub(crate) fn charge(&mut self, units: u64) -> Result<(), super::CallableCatalogBuildError> {
        let next = self
            .consumed
            .checked_add(units)
            .ok_or(super::CallableCatalogBuildError::WorkOverflow)?;
        if next > self.limit {
            return Err(CallableBuildLimitError::Work {
                requested: units,
                consumed: self.consumed,
                limit: self.limit,
            }
            .into());
        }
        self.consumed = next;
        Ok(())
    }
}

#[derive(Debug, Eq, PartialEq)]
pub(crate) struct ResolverWork {
    consumed: u64,
    limit: u64,
    resolver: u64,
    argument_mapping: u64,
    type_checks: u64,
    type_constraint_report: TypeConstraintWorkReport,
    call: CallResolverAccountingReport,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct ResolverWorkFullReport {
    consumed: u64,
    limit: u64,
    resolver: u64,
    argument_mapping: u64,
    type_checks: u64,
    type_constraint_report: TypeConstraintWorkReport,
    call: CallResolverAccountingReport,
}

impl ResolverWorkFullReport {
    fn from_work(work: &ResolverWork) -> Self {
        Self {
            consumed: work.consumed,
            limit: work.limit,
            resolver: work.resolver,
            argument_mapping: work.argument_mapping,
            type_checks: work.type_checks,
            type_constraint_report: work.type_constraint_report.clone(),
            call: work.call,
        }
    }

    fn publish_into(self, work: &mut ResolverWork) {
        work.consumed = self.consumed;
        work.limit = self.limit;
        work.resolver = self.resolver;
        work.argument_mapping = self.argument_mapping;
        work.type_checks = self.type_checks;
        work.type_constraint_report = self.type_constraint_report;
        work.call = self.call;
    }
}

/// One previous/proposed full resolver report. The reservation is private to
/// the candidate session; no caller can merge an exposed lower delta.
#[derive(Clone, Debug, Eq, PartialEq)]
struct PendingCandidateConstraintReport {
    previous: ResolverWorkFullReport,
    proposed: ResolverWorkFullReport,
}

/// Failure to reserve a candidate's lower constraint accounting session.
#[derive(Clone, Copy, Debug, Eq, thiserror::Error, PartialEq)]
pub(crate) enum CandidateConstraintSessionStartFailure {
    #[error("candidate constraint session accounting overflow")]
    ArithmeticOverflow,
}

/// Exclusively borrowed component-wide lower constraint accounting session.
/// The context owns this reservation while drivers borrow it. Releasing the
/// context commits the checked proposal; dropping an unentered session also
/// commits it, with exactly one publication on success or early return.
pub(crate) struct CandidateConstraintWorkSession<'a> {
    work: Option<&'a mut ResolverWork>,
    cancellation: &'a AtomicBool,
    limits: TypeConstraintLimits,
    reservation: PendingCandidateConstraintReport,
    constraint_work: u64,
    source_probes: u64,
    materializations: u64,
    committed: bool,
}

impl<'a> CandidateConstraintWorkSession<'a> {
    pub(crate) fn new(
        work: &'a mut ResolverWork,
        limits: CallableLimits,
        cancellation: &'a AtomicBool,
    ) -> Result<Self, CandidateConstraintSessionStartFailure> {
        let previous = ResolverWorkFullReport::from_work(work);
        let remaining = previous
            .limit
            .checked_sub(previous.consumed)
            .ok_or(CandidateConstraintSessionStartFailure::ArithmeticOverflow)?;
        let proposed = previous.clone();
        Ok(Self {
            work: Some(work),
            cancellation,
            limits: limits.type_constraint_limits(remaining),
            reservation: PendingCandidateConstraintReport { previous, proposed },
            constraint_work: 0,
            source_probes: 0,
            materializations: 0,
            committed: false,
        })
    }

    fn apply_lower_delta(
        &mut self,
        delta: TypeConstraintWorkReport,
    ) -> Result<(), CallableQueryLimitError> {
        let proposed = &self.reservation.proposed;
        let lower_work = self
            .constraint_work
            .checked_add(delta.work())
            .ok_or(CallableQueryLimitError::ArithmeticOverflow)?;
        if lower_work > self.limits.max_work() {
            return Err(CallableQueryLimitError::Work {
                requested: delta.work(),
                consumed: self.constraint_work,
                limit: self.limits.max_work(),
            });
        }
        let consumed = proposed
            .consumed
            .checked_add(delta.work())
            .ok_or(CallableQueryLimitError::ArithmeticOverflow)?;
        if consumed > proposed.limit {
            return Err(CallableQueryLimitError::Work {
                requested: delta.work(),
                consumed: proposed.consumed,
                limit: proposed.limit,
            });
        }
        let type_checks = proposed
            .type_checks
            .checked_add(delta.work())
            .ok_or(CallableQueryLimitError::ArithmeticOverflow)?;
        let report = proposed
            .type_constraint_report
            .checked_add(&delta)
            .map_err(|_| CallableQueryLimitError::ArithmeticOverflow)?;
        self.reservation.proposed.consumed = consumed;
        self.reservation.proposed.type_checks = type_checks;
        self.reservation.proposed.type_constraint_report = report;
        self.constraint_work = lower_work;
        Ok(())
    }

    fn commit(&mut self) {
        if self.committed {
            return;
        }
        let Some(work) = self.work.take() else {
            self.committed = true;
            return;
        };
        let proposed = core::mem::replace(
            &mut self.reservation.proposed,
            self.reservation.previous.clone(),
        );
        proposed.publish_into(work);
        self.committed = true;
    }

    /// Charges one callback-owned expression check against the proposed outer
    /// resolver work report.  This deliberately does not synthesize lower
    /// source-probe/materialization counters; those remain minted by the
    /// callable driver.
    pub(crate) fn charge_callback_expression(
        &mut self,
        units: u64,
    ) -> Result<(), crate::types::constraints::TypeConstraintAbort> {
        if self.cancellation.load(Ordering::Acquire) {
            return Err(crate::types::constraints::TypeConstraintAbort::Cancelled);
        }
        let proposed = &mut self.reservation.proposed;
        let consumed = proposed
            .consumed
            .checked_add(units)
            .ok_or(crate::types::constraints::TypeConstraintAbort::ArithmeticOverflow)?;
        if consumed > proposed.limit {
            return Err(crate::types::constraints::TypeConstraintAbort::WorkLimit {
                requested: units,
                consumed: proposed.consumed,
                limit: proposed.limit,
            });
        }
        proposed.type_checks = proposed
            .type_checks
            .checked_add(units)
            .ok_or(crate::types::constraints::TypeConstraintAbort::ArithmeticOverflow)?;
        proposed.consumed = consumed;
        Ok(())
    }

    pub(crate) fn check_cancelled(
        &self,
    ) -> Result<(), crate::types::constraints::TypeConstraintAbort> {
        if self.cancellation.load(Ordering::Acquire) {
            Err(crate::types::constraints::TypeConstraintAbort::Cancelled)
        } else {
            Ok(())
        }
    }
}

impl Drop for CandidateConstraintWorkSession<'_> {
    fn drop(&mut self) {
        self.commit();
    }
}

impl crate::effect_row::DecisionControl for CandidateConstraintWorkSession<'_> {
    type Error = TypeConstraintError;

    fn charge(&mut self, _: crate::effect_row::DecisionWork) -> Result<(), Self::Error> {
        // Effect graph operations and type projection share the callback's
        // existing lower-node accounting, including its cancellation signal.
        crate::types::TypeProjectionControl::visit_node(
            self,
            crate::types::TypeProjectionNodeKind::Effect,
            1,
        )
    }
}

impl crate::types::TypeProjectionControl for CandidateConstraintWorkSession<'_> {
    type Error = TypeConstraintError;

    fn check(&mut self) -> Result<(), Self::Error> {
        self.check_cancelled().map_err(TypeConstraintError::Abort)
    }

    fn visit_node(
        &mut self,
        _: crate::types::TypeProjectionNodeKind,
        _: u64,
    ) -> Result<(), Self::Error> {
        self.charge_constraint(
            &TypeConstraintWorkReport {
                work: 1,
                nodes: 1,
                ..TypeConstraintWorkReport::ZERO
            },
            self.limits,
        )
    }

    fn visit_binding(&mut self) -> Result<(), Self::Error> {
        self.visit_node(crate::types::TypeProjectionNodeKind::Type, 1)
    }
}

impl TypeConstraintAccounting for CandidateConstraintWorkSession<'_> {
    fn charge_constraint(
        &mut self,
        delta: &TypeConstraintWorkReport,
        _limits: TypeConstraintLimits,
    ) -> Result<(), TypeConstraintError> {
        if self.cancellation.load(Ordering::Acquire) {
            return Err(TypeConstraintError::Abort(TypeConstraintAbort::Cancelled));
        }
        // Projection during materialization borrows this same reservation.
        // Its nodes and the driver's nodes share the component-wide bound.
        let nodes = self
            .reservation
            .proposed
            .type_constraint_report
            .nodes
            .checked_sub(self.reservation.previous.type_constraint_report.nodes)
            .and_then(|nodes| nodes.checked_add(delta.nodes))
            .ok_or(TypeConstraintError::Abort(
                TypeConstraintAbort::ArithmeticOverflow,
            ))?;
        if nodes > self.limits.max_nodes {
            return Err(TypeConstraintError::Abort(TypeConstraintAbort::NodeLimit {
                actual: nodes,
                limit: self.limits.max_nodes,
            }));
        }
        let source_probes = self
            .source_probes
            .checked_add(delta.source_probes())
            .ok_or(TypeConstraintError::Abort(
                TypeConstraintAbort::ArithmeticOverflow,
            ))?;
        if source_probes > self.limits.max_source_probes() {
            return Err(TypeConstraintError::Abort(
                TypeConstraintAbort::SourceProbeLimit {
                    actual: source_probes,
                    limit: self.limits.max_source_probes(),
                },
            ));
        }
        let materializations = self
            .materializations
            .checked_add(delta.materializations())
            .ok_or(TypeConstraintError::Abort(
                TypeConstraintAbort::ArithmeticOverflow,
            ))?;
        if materializations > self.limits.max_materializations() {
            return Err(TypeConstraintError::Abort(
                TypeConstraintAbort::MaterializationLimit {
                    actual: materializations,
                    limit: self.limits.max_materializations(),
                },
            ));
        }
        self.apply_lower_delta(delta.clone())
            .map_err(|error| match error {
                CallableQueryLimitError::ArithmeticOverflow => {
                    TypeConstraintError::Abort(TypeConstraintAbort::ArithmeticOverflow)
                }
                CallableQueryLimitError::Work {
                    requested,
                    consumed,
                    limit,
                } => TypeConstraintError::Abort(TypeConstraintAbort::WorkLimit {
                    requested,
                    consumed,
                    limit,
                }),
                CallableQueryLimitError::Candidates { .. }
                | CallableQueryLimitError::Parameters { .. }
                | CallableQueryLimitError::NestedCalls { .. }
                | CallableQueryLimitError::RecoveryNodes { .. }
                | CallableQueryLimitError::Diagnostics { .. }
                | CallableQueryLimitError::SourceBytes { .. } => {
                    unreachable!("candidate lower accounting cannot charge non-lower limits")
                }
            })?;
        self.source_probes = source_probes;
        self.materializations = materializations;
        Ok(())
    }

    fn commit(&mut self) {
        CandidateConstraintWorkSession::commit(self);
    }
}

impl<'a> TypeConstraintContextIssuer<'a> for CandidateConstraintWorkSession<'a> {
    fn context_limits(&self) -> TypeConstraintLimits {
        self.limits
    }

    fn context_cancellation(&self) -> &'a AtomicBool {
        self.cancellation
    }
}

/// Closed resolver-work and committed-publication counters for one final Call
/// transaction.
///
/// Candidate probe/replay entries count candidate × authored-argument visits;
/// fixed spread slots deliberately remain separate in the crate-owned
/// `physical_candidate_argument_evaluations` trace. These counters are
/// observations of work already charged through [`ResolverWork`], not a
/// second work budget.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct CallResolverAccountingReport {
    logical_argument_checks: u64,
    resolver_invocations: u64,
    candidate_argument_probes: u64,
    selected_replay_argument_visits: u64,
    retained_argument_fact_publications: u64,
}

impl CallResolverAccountingReport {
    const ZERO: Self = Self {
        logical_argument_checks: 0,
        resolver_invocations: 0,
        candidate_argument_probes: 0,
        selected_replay_argument_visits: 0,
        retained_argument_fact_publications: 0,
    };

    pub const fn logical_argument_checks(self) -> u64 {
        self.logical_argument_checks
    }

    pub const fn resolver_invocations(self) -> u64 {
        self.resolver_invocations
    }

    pub const fn candidate_argument_probes(self) -> u64 {
        self.candidate_argument_probes
    }

    pub const fn selected_replay_argument_visits(self) -> u64 {
        self.selected_replay_argument_visits
    }

    pub const fn retained_argument_fact_publications(self) -> u64 {
        self.retained_argument_fact_publications
    }

    #[cfg(test)]
    pub(crate) fn delta_from(self, before: Self) -> Result<Self, CallableQueryLimitError> {
        Ok(Self {
            logical_argument_checks: self
                .logical_argument_checks
                .checked_sub(before.logical_argument_checks)
                .ok_or(CallableQueryLimitError::ArithmeticOverflow)?,
            resolver_invocations: self
                .resolver_invocations
                .checked_sub(before.resolver_invocations)
                .ok_or(CallableQueryLimitError::ArithmeticOverflow)?,
            candidate_argument_probes: self
                .candidate_argument_probes
                .checked_sub(before.candidate_argument_probes)
                .ok_or(CallableQueryLimitError::ArithmeticOverflow)?,
            selected_replay_argument_visits: self
                .selected_replay_argument_visits
                .checked_sub(before.selected_replay_argument_visits)
                .ok_or(CallableQueryLimitError::ArithmeticOverflow)?,
            retained_argument_fact_publications: self
                .retained_argument_fact_publications
                .checked_sub(before.retained_argument_fact_publications)
                .ok_or(CallableQueryLimitError::ArithmeticOverflow)?,
        })
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum CallResolverAccountingEvent {
    LogicalArgumentCheck,
    ResolverInvocation,
    CandidateArgumentProbe,
    SelectedReplayArgumentVisit,
    RetainedArgumentFactPublication,
}

impl ResolverWork {
    pub(crate) const fn new(limit: u64) -> Self {
        Self {
            consumed: 0,
            limit,
            resolver: 0,
            argument_mapping: 0,
            type_checks: 0,
            type_constraint_report: TypeConstraintWorkReport::ZERO,
            call: CallResolverAccountingReport::ZERO,
        }
    }

    #[cfg(test)]
    pub(crate) fn reset(&mut self) {
        self.consumed = 0;
        self.resolver = 0;
        self.argument_mapping = 0;
        self.type_checks = 0;
        self.type_constraint_report = TypeConstraintWorkReport::ZERO;
        self.call = CallResolverAccountingReport::ZERO;
    }

    pub(crate) fn charge(&mut self, units: u64) -> Result<(), CallableQueryLimitError> {
        self.charge_component(units, ResolverWorkComponent::Resolver)
            .map_err(Into::into)
    }

    pub(crate) fn charge_argument_mapping(
        &mut self,
        units: u64,
    ) -> Result<(), CallableQueryLimitError> {
        self.charge_component(units, ResolverWorkComponent::ArgumentMapping)
            .map_err(Into::into)
    }

    /// Returns the exact unconsumed query-work budget for one projected
    /// candidate relation. Saturation would hide an accounting invariant
    /// violation, so an over-consumed meter is reported as overflow.
    #[cfg(test)]
    pub(crate) fn remaining_budget(&self) -> Result<u64, CallableQueryLimitError> {
        self.limit
            .checked_sub(self.consumed)
            .ok_or(CallableQueryLimitError::ArithmeticOverflow)
    }

    pub(crate) fn begin_candidate_constraint_session<'a>(
        &'a mut self,
        limits: CallableLimits,
        cancellation: &'a AtomicBool,
    ) -> Result<CandidateConstraintWorkSession<'a>, CandidateConstraintSessionStartFailure> {
        CandidateConstraintWorkSession::new(self, limits, cancellation)
    }

    pub(crate) fn record_logical_argument_checks(
        &mut self,
        units: u64,
    ) -> Result<(), CallableQueryLimitError> {
        self.record_call_event(CallResolverAccountingEvent::LogicalArgumentCheck, units)
    }

    pub(crate) fn record_resolver_invocation(&mut self) -> Result<(), CallableQueryLimitError> {
        self.record_call_event(CallResolverAccountingEvent::ResolverInvocation, 1)
    }

    pub(crate) fn record_candidate_argument_probes(
        &mut self,
        units: u64,
    ) -> Result<(), CallableQueryLimitError> {
        self.record_call_event(CallResolverAccountingEvent::CandidateArgumentProbe, units)
    }

    pub(crate) fn record_selected_replay_argument_visits(
        &mut self,
        units: u64,
    ) -> Result<(), CallableQueryLimitError> {
        self.record_call_event(
            CallResolverAccountingEvent::SelectedReplayArgumentVisit,
            units,
        )
    }

    pub(crate) fn record_retained_argument_fact_publications(
        &mut self,
        units: u64,
    ) -> Result<(), CallableQueryLimitError> {
        self.record_call_event(
            CallResolverAccountingEvent::RetainedArgumentFactPublication,
            units,
        )
    }

    pub(crate) const fn call_accounting(&self) -> CallResolverAccountingReport {
        self.call
    }

    #[cfg(test)]
    pub(crate) const fn type_constraint_report(&self) -> &TypeConstraintWorkReport {
        &self.type_constraint_report
    }

    fn record_call_event(
        &mut self,
        event: CallResolverAccountingEvent,
        units: u64,
    ) -> Result<(), CallableQueryLimitError> {
        let counter = match event {
            CallResolverAccountingEvent::LogicalArgumentCheck => {
                &mut self.call.logical_argument_checks
            }
            CallResolverAccountingEvent::ResolverInvocation => &mut self.call.resolver_invocations,
            CallResolverAccountingEvent::CandidateArgumentProbe => {
                &mut self.call.candidate_argument_probes
            }
            CallResolverAccountingEvent::SelectedReplayArgumentVisit => {
                &mut self.call.selected_replay_argument_visits
            }
            CallResolverAccountingEvent::RetainedArgumentFactPublication => {
                &mut self.call.retained_argument_fact_publications
            }
        };
        *counter = counter
            .checked_add(units)
            .ok_or(CallableQueryLimitError::ArithmeticOverflow)?;
        Ok(())
    }

    fn charge_component(
        &mut self,
        units: u64,
        component: ResolverWorkComponent,
    ) -> Result<(), ResolverWorkChargeError> {
        let next = self
            .consumed
            .checked_add(units)
            .ok_or(ResolverWorkChargeError::ArithmeticOverflow)?;
        if next > self.limit {
            return Err(ResolverWorkChargeError::Work {
                requested: units,
                consumed: self.consumed,
                limit: self.limit,
            });
        }
        let next_component = match component {
            ResolverWorkComponent::Resolver => self.resolver.checked_add(units),
            ResolverWorkComponent::ArgumentMapping => self.argument_mapping.checked_add(units),
        }
        .ok_or(ResolverWorkChargeError::ArithmeticOverflow)?;
        self.consumed = next;
        match component {
            ResolverWorkComponent::Resolver => self.resolver = next_component,
            ResolverWorkComponent::ArgumentMapping => self.argument_mapping = next_component,
        }
        Ok(())
    }
}

#[derive(Clone, Copy)]
enum ResolverWorkComponent {
    Resolver,
    ArgumentMapping,
}

/// The work ledger has only arithmetic and work-admission failures. Public
/// query limits and lower continuation accounting preserve those same fields.
#[derive(Debug)]
enum ResolverWorkChargeError {
    ArithmeticOverflow,
    Work {
        requested: u64,
        consumed: u64,
        limit: u64,
    },
}

impl From<ResolverWorkChargeError> for CallableQueryLimitError {
    fn from(error: ResolverWorkChargeError) -> Self {
        match error {
            ResolverWorkChargeError::ArithmeticOverflow => Self::ArithmeticOverflow,
            ResolverWorkChargeError::Work {
                requested,
                consumed,
                limit,
            } => Self::Work {
                requested,
                consumed,
                limit,
            },
        }
    }
}

impl From<ResolverWorkChargeError> for TypeConstraintAbort {
    fn from(error: ResolverWorkChargeError) -> Self {
        match error {
            ResolverWorkChargeError::ArithmeticOverflow => Self::ArithmeticOverflow,
            ResolverWorkChargeError::Work {
                requested,
                consumed,
                limit,
            } => Self::WorkLimit {
                requested,
                consumed,
                limit,
            },
        }
    }
}

/// Work performed while resolving and projecting one semantic signature query.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignatureWorkReport {
    resolver: u64,
    argument_mapping: u64,
    type_checks: u64,
    call: CallResolverAccountingReport,
    recovery_nodes: usize,
    diagnostics: usize,
}

impl SignatureWorkReport {
    /// Builds the public work envelope from immutable final-call facts without
    /// replaying resolution or argument checking.
    pub(crate) fn from_final_call_facts(
        call: CallResolverAccountingReport,
        recovery_nodes: usize,
        diagnostics: usize,
        limits: &CallableLimits,
    ) -> Result<Self, CallableQueryLimitError> {
        Self::try_new(0, 0, 0, call, recovery_nodes, diagnostics, limits)
    }

    pub(crate) fn try_new(
        resolver: u64,
        argument_mapping: u64,
        type_checks: u64,
        call: CallResolverAccountingReport,
        recovery_nodes: usize,
        diagnostics: usize,
        limits: &CallableLimits,
    ) -> Result<Self, CallableQueryLimitError> {
        if recovery_nodes > limits.max_recovery_nodes() {
            return Err(CallableQueryLimitError::RecoveryNodes {
                actual: recovery_nodes,
                limit: limits.max_recovery_nodes(),
            });
        }
        if diagnostics > limits.max_diagnostics() {
            return Err(CallableQueryLimitError::Diagnostics {
                actual: diagnostics,
                limit: limits.max_diagnostics(),
            });
        }
        let report = Self {
            resolver,
            argument_mapping,
            type_checks,
            call,
            recovery_nodes,
            diagnostics,
        };
        let total = report.total_work()?;
        if total > limits.max_query_work() {
            return Err(CallableQueryLimitError::Work {
                requested: total,
                consumed: 0,
                limit: limits.max_query_work(),
            });
        }
        Ok(report)
    }

    pub const fn resolver(&self) -> u64 {
        self.resolver
    }
    pub const fn argument_mapping(&self) -> u64 {
        self.argument_mapping
    }
    pub const fn type_checks(&self) -> u64 {
        self.type_checks
    }
    pub const fn call_accounting(&self) -> CallResolverAccountingReport {
        self.call
    }
    pub const fn recovery_nodes(&self) -> usize {
        self.recovery_nodes
    }
    pub const fn diagnostics(&self) -> usize {
        self.diagnostics
    }

    pub fn total_work(&self) -> Result<u64, CallableQueryLimitError> {
        self.resolver
            .checked_add(self.argument_mapping)
            .and_then(|value| value.checked_add(self.type_checks))
            .ok_or(CallableQueryLimitError::ArithmeticOverflow)
    }
}

/// Search-stage work for the outer position-aware signature query.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignatureQuerySearchWork {
    node_visits: u64,
    candidate_calls: u64,
    nested_calls: u64,
    arguments: u64,
    recovery_nodes: u64,
}

impl SignatureQuerySearchWork {
    pub const fn new(
        node_visits: u64,
        candidate_calls: u64,
        nested_calls: u64,
        arguments: u64,
        recovery_nodes: u64,
    ) -> Self {
        Self {
            node_visits,
            candidate_calls,
            nested_calls,
            arguments,
            recovery_nodes,
        }
    }

    pub const fn node_visits(self) -> u64 {
        self.node_visits
    }
    pub const fn candidate_calls(self) -> u64 {
        self.candidate_calls
    }
    pub const fn nested_calls(self) -> u64 {
        self.nested_calls
    }
    pub const fn arguments(self) -> u64 {
        self.arguments
    }
    pub const fn recovery_nodes(self) -> u64 {
        self.recovery_nodes
    }
}

/// Resolver and checker-transaction work charged by the outer query meter.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignatureQueryResolutionWork {
    resolver: u64,
    argument_bindings: u64,
    specificity_checks: u64,
}

impl SignatureQueryResolutionWork {
    pub const fn new(resolver: u64, argument_bindings: u64, specificity_checks: u64) -> Self {
        Self {
            resolver,
            argument_bindings,
            specificity_checks,
        }
    }

    pub const fn resolver(self) -> u64 {
        self.resolver
    }
    pub const fn argument_bindings(self) -> u64 {
        self.argument_bindings
    }
    pub const fn specificity_checks(self) -> u64 {
        self.specificity_checks
    }
}

/// Public-result projection work charged by the outer query meter.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignatureQueryProjectionWork {
    overloads: u64,
    parameters: u64,
    argument_projections: u64,
    diagnostic_considerations: u64,
}

impl SignatureQueryProjectionWork {
    pub const fn new(
        overloads: u64,
        parameters: u64,
        argument_projections: u64,
        diagnostic_considerations: u64,
    ) -> Self {
        Self {
            overloads,
            parameters,
            argument_projections,
            diagnostic_considerations,
        }
    }

    pub const fn overloads(self) -> u64 {
        self.overloads
    }
    pub const fn parameters(self) -> u64 {
        self.parameters
    }
    pub const fn argument_projections(self) -> u64 {
        self.argument_projections
    }
    pub const fn diagnostic_considerations(self) -> u64 {
        self.diagnostic_considerations
    }
}

/// Exact outer-query operation counts, separated by owning stage.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignatureQueryWorkReport {
    search: SignatureQuerySearchWork,
    resolution: SignatureQueryResolutionWork,
    projection: SignatureQueryProjectionWork,
    total: u64,
}

impl SignatureQueryWorkReport {
    pub const fn search(self) -> SignatureQuerySearchWork {
        self.search
    }
    pub const fn resolution(self) -> SignatureQueryResolutionWork {
        self.resolution
    }
    pub const fn projection(self) -> SignatureQueryProjectionWork {
        self.projection
    }

    pub const fn total_work(self) -> u64 {
        self.total
    }
}

/// Failure while charging caller-owned semantic signature work.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SignatureAccountingError {
    /// A configured signature-query limit was exceeded.
    Limit(SignatureLimitExceeded),
    /// A checked work counter overflowed without mutating the counter.
    Arithmetic { counter: SignatureWorkKind },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SignatureQueryWorkMeter {
    limits: SignatureQueryLimits,
    node_visits: u64,
    candidate_calls: u64,
    nested_calls: u64,
    arguments: u64,
    recovery_nodes: u64,
    resolver: u64,
    argument_bindings: u64,
    specificity_checks: u64,
    overloads: u64,
    parameters: u64,
    argument_projections: u64,
    diagnostic_considerations: u64,
    total: u64,
}

impl SignatureQueryWorkMeter {
    pub(crate) const fn new(limits: SignatureQueryLimits) -> Self {
        Self {
            limits,
            node_visits: 0,
            candidate_calls: 0,
            nested_calls: 0,
            arguments: 0,
            recovery_nodes: 0,
            resolver: 0,
            argument_bindings: 0,
            specificity_checks: 0,
            overloads: 0,
            parameters: 0,
            argument_projections: 0,
            diagnostic_considerations: 0,
            total: 0,
        }
    }

    pub(crate) fn charge(
        &mut self,
        kind: SignatureWorkKind,
        units: u64,
    ) -> Result<(), SignatureAccountingError> {
        let counter = self.counter(kind);
        let next_counter = counter
            .checked_add(units)
            .ok_or(SignatureAccountingError::Arithmetic { counter: kind })?;
        if let Some((limit_kind, maximum)) = self.operation_limit(kind)
            && next_counter > maximum
        {
            return Err(SignatureAccountingError::Limit(SignatureLimitExceeded {
                kind: limit_kind,
                observed: next_counter,
                maximum,
            }));
        }
        let next_total = self
            .total
            .checked_add(units)
            .ok_or(SignatureAccountingError::Arithmetic { counter: kind })?;
        if next_total > self.limits.work_units() {
            return Err(SignatureAccountingError::Limit(SignatureLimitExceeded {
                kind: SignatureLimitKind::WorkUnits,
                observed: next_total,
                maximum: self.limits.work_units(),
            }));
        }
        *self.counter_mut(kind) = next_counter;
        self.total = next_total;
        Ok(())
    }

    pub(crate) fn charge_parameter(
        &mut self,
        parameters_in_signature: &mut u64,
    ) -> Result<(), SignatureAccountingError> {
        let observed =
            parameters_in_signature
                .checked_add(1)
                .ok_or(SignatureAccountingError::Arithmetic {
                    counter: SignatureWorkKind::Parameters,
                })?;
        if observed > self.limits.parameters_per_signature() {
            return Err(SignatureAccountingError::Limit(SignatureLimitExceeded {
                kind: SignatureLimitKind::ParametersPerSignature,
                observed,
                maximum: self.limits.parameters_per_signature(),
            }));
        }
        self.charge(SignatureWorkKind::Parameters, 1)?;
        *parameters_in_signature = observed;
        Ok(())
    }

    pub(crate) fn report(&self) -> SignatureQueryWorkReport {
        SignatureQueryWorkReport {
            search: SignatureQuerySearchWork::new(
                self.node_visits,
                self.candidate_calls,
                self.nested_calls,
                self.arguments,
                self.recovery_nodes,
            ),
            resolution: SignatureQueryResolutionWork::new(
                self.resolver,
                self.argument_bindings,
                self.specificity_checks,
            ),
            projection: SignatureQueryProjectionWork::new(
                self.overloads,
                self.parameters,
                self.argument_projections,
                self.diagnostic_considerations,
            ),
            total: self.total,
        }
    }

    const fn counter(&self, kind: SignatureWorkKind) -> u64 {
        match kind {
            SignatureWorkKind::SourceBytes => 0,
            SignatureWorkKind::NodeVisits => self.node_visits,
            SignatureWorkKind::CandidateCalls => self.candidate_calls,
            SignatureWorkKind::NestedCalls => self.nested_calls,
            SignatureWorkKind::Arguments => self.arguments,
            SignatureWorkKind::RecoveryNodes => self.recovery_nodes,
            SignatureWorkKind::Resolver => self.resolver,
            SignatureWorkKind::ArgumentBindings => self.argument_bindings,
            SignatureWorkKind::SpecificityChecks => self.specificity_checks,
            SignatureWorkKind::Overloads => self.overloads,
            SignatureWorkKind::Parameters => self.parameters,
            SignatureWorkKind::ArgumentProjections => self.argument_projections,
            SignatureWorkKind::DiagnosticConsiderations => self.diagnostic_considerations,
        }
    }

    fn counter_mut(&mut self, kind: SignatureWorkKind) -> &mut u64 {
        match kind {
            SignatureWorkKind::SourceBytes => {
                unreachable!("source bytes are checked before the work meter is created")
            }
            SignatureWorkKind::NodeVisits => &mut self.node_visits,
            SignatureWorkKind::CandidateCalls => &mut self.candidate_calls,
            SignatureWorkKind::NestedCalls => &mut self.nested_calls,
            SignatureWorkKind::Arguments => &mut self.arguments,
            SignatureWorkKind::RecoveryNodes => &mut self.recovery_nodes,
            SignatureWorkKind::Resolver => &mut self.resolver,
            SignatureWorkKind::ArgumentBindings => &mut self.argument_bindings,
            SignatureWorkKind::SpecificityChecks => &mut self.specificity_checks,
            SignatureWorkKind::Overloads => &mut self.overloads,
            SignatureWorkKind::Parameters => &mut self.parameters,
            SignatureWorkKind::ArgumentProjections => &mut self.argument_projections,
            SignatureWorkKind::DiagnosticConsiderations => &mut self.diagnostic_considerations,
        }
    }

    const fn operation_limit(&self, kind: SignatureWorkKind) -> Option<(SignatureLimitKind, u64)> {
        match kind {
            SignatureWorkKind::CandidateCalls => Some((
                SignatureLimitKind::CandidateCalls,
                self.limits.candidate_calls(),
            )),
            SignatureWorkKind::NestedCalls => {
                Some((SignatureLimitKind::NestedCalls, self.limits.nested_calls()))
            }
            SignatureWorkKind::RecoveryNodes => Some((
                SignatureLimitKind::RecoveryNodes,
                self.limits.recovery_nodes(),
            )),
            SignatureWorkKind::Overloads => {
                Some((SignatureLimitKind::Overloads, self.limits.overloads()))
            }
            SignatureWorkKind::SourceBytes
            | SignatureWorkKind::NodeVisits
            | SignatureWorkKind::Arguments
            | SignatureWorkKind::Resolver
            | SignatureWorkKind::ArgumentBindings
            | SignatureWorkKind::SpecificityChecks
            | SignatureWorkKind::Parameters
            | SignatureWorkKind::ArgumentProjections
            | SignatureWorkKind::DiagnosticConsiderations => None,
        }
    }
}

#[cfg(test)]
mod final_call_accounting_tests {
    use super::*;

    #[test]
    fn final_call_counters_remain_separate_and_reset_together() {
        let mut work = ResolverWork::new(PRODUCTION_CALLABLE_LIMITS.max_query_work());
        let before = work.call_accounting();
        work.record_logical_argument_checks(2)
            .expect("logical argument checks");
        work.record_resolver_invocation()
            .expect("one shared resolver entry");
        work.record_candidate_argument_probes(4)
            .expect("two candidates probe two arguments");
        work.record_selected_replay_argument_visits(2)
            .expect("selected replay visits each retained argument");
        work.record_retained_argument_fact_publications(2)
            .expect("fact publication retains each argument");

        let report = work
            .call_accounting()
            .delta_from(before)
            .expect("monotonic accounting delta");
        assert_eq!(report.logical_argument_checks(), 2);
        assert_eq!(report.resolver_invocations(), 1);
        assert_eq!(report.candidate_argument_probes(), 4);
        assert_eq!(report.selected_replay_argument_visits(), 2);
        assert_eq!(report.retained_argument_fact_publications(), 2);

        work.reset();
        assert_eq!(work.call_accounting(), CallResolverAccountingReport::ZERO);
    }

    #[test]
    fn signature_argument_projection_has_a_distinct_counter() {
        let mut meter = SignatureQueryWorkMeter::new(PRODUCTION_SIGNATURE_LIMITS);
        meter
            .charge(SignatureWorkKind::Arguments, 3)
            .expect("surface argument traversal");
        meter
            .charge(SignatureWorkKind::ArgumentProjections, 2)
            .expect("public argument projection");
        let report = meter.report();
        assert_eq!(report.search().arguments(), 3);
        assert_eq!(report.projection().argument_projections(), 2);
        assert_eq!(report.total_work(), 5);
    }

    #[test]
    fn type_constraint_run_is_consumed_by_exactly_one_merge() {
        use std::sync::atomic::AtomicBool;

        use crate::types::{ConstraintAcceptance, TypeKind};

        let limits = PRODUCTION_CALLABLE_LIMITS;
        let mut work = ResolverWork::new(256);
        work.charge(2).expect("initial resolver work");
        let remaining = work.remaining_budget().expect("remaining budget");
        assert_eq!(remaining, 254);
        let cancellation = AtomicBool::new(false);
        let session = work
            .begin_candidate_constraint_session(limits, &cancellation)
            .expect("reserved candidate session");
        let outcome = session
            .with_fixture_driver::<crate::types::NoConstraintClient, _, _>(
                (),
                super::super::constraints::tests::no_constraint_initialization(),
                crate::types::NoConstraintClient,
                |mut driver| {
                    driver.constrain(
                        &TypeKind::I32,
                        &TypeKind::I32,
                        ConstraintAcceptance::PatternAcceptsActual,
                    );

                    driver.finish().expect("constraint outcome")
                },
            )
            .expect("prepared initialization");
        assert_eq!(outcome.component.selected().solution().bindings().len(), 0);
        let committed = work.type_constraint_report.work();
        assert!(committed > 0);
        assert_eq!(
            work.remaining_budget().expect("remaining budget"),
            254 - committed
        );
    }

    #[test]
    fn candidate_session_failure_commits_metered_failure() {
        use std::sync::atomic::AtomicBool;

        let cancellation = AtomicBool::new(true);
        let mut work = ResolverWork::new(16);
        let session = work
            .begin_candidate_constraint_session(PRODUCTION_CALLABLE_LIMITS, &cancellation)
            .expect("reserved candidate session");
        assert!(matches!(
            session.with_fixture_driver::<crate::types::NoConstraintClient, _, _>(
                (),
                super::super::constraints::tests::no_constraint_initialization(),
                crate::types::NoConstraintClient,
                |_driver| (),
            ),
            Err(
                crate::callable::CandidateConstraintDriverStartFailure::Lower(
                    crate::types::constraints::TypeConstraintInitializationFailure::Abort(
                        crate::types::constraints::TypeConstraintAbort::Cancelled,
                    ),
                )
            )
        ));
        assert_eq!(work.type_constraint_report.work(), 0);
        assert_eq!(work.consumed, 0);
    }

    #[test]
    fn candidate_session_start_reports_only_arithmetic_overflow() {
        use std::sync::atomic::AtomicBool;

        let cancellation = AtomicBool::new(false);
        let mut work = ResolverWork::new(0);
        work.consumed = 1;
        assert!(matches!(
            work.begin_candidate_constraint_session(PRODUCTION_CALLABLE_LIMITS, &cancellation),
            Err(CandidateConstraintSessionStartFailure::ArithmeticOverflow)
        ));
    }

    #[test]
    fn candidate_session_commits_when_finished_outcome_is_discarded() {
        use std::sync::atomic::AtomicBool;

        use crate::types::{ConstraintAcceptance, TypeKind};

        let cancellation = AtomicBool::new(false);
        let mut work = ResolverWork::new(16);
        let session = work
            .begin_candidate_constraint_session(PRODUCTION_CALLABLE_LIMITS, &cancellation)
            .expect("reserved candidate session");
        session
            .with_fixture_driver::<crate::types::NoConstraintClient, _, _>(
                (),
                super::super::constraints::tests::no_constraint_initialization(),
                crate::types::NoConstraintClient,
                |mut driver| {
                    driver.constrain(
                        &TypeKind::I32,
                        &TypeKind::I32,
                        ConstraintAcceptance::PatternAcceptsActual,
                    );

                    drop(driver.finish());
                },
            )
            .expect("prepared initialization");
        assert!(work.type_constraint_report.work() > 0);
    }
}
