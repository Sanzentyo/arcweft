$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
$publication=Get-Content -Raw "$root/comparison-control.publication.json"|ConvertFrom-Json
$steps=[Collections.Generic.List[object]]::new()
function Assert-Source {
    if((git rev-parse HEAD) -ne $publication.Source -or (git rev-parse 'HEAD^{tree}') -ne $publication.Tree -or @(git diff --name-only HEAD).Count){throw 'Broad source pin changed'}
}
function Step($name,$arguments,$output,$log){
    Assert-Source
    $start=Get-Date
    Write-Output "START $name"
    & cargo @arguments 1>"$root/$output" 2>"$root/$log"
    $code=$LASTEXITCODE
    Assert-Source
    $steps.Add([pscustomobject]@{Name=$name;Command='cargo';Arguments=$arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;SourcePinsVerified=$true;Output=$output;Log=$log})
    [ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false;Steps=@($steps.ToArray())}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/comparison-control.broad-quality.json"
    Write-Output "END $name exit=$code"
    if($code -ne 0){throw "$name failed"}
}
Assert-Source
rustc -vV > "$root/comparison-control.rustc-vV.txt"
cargo -V > "$root/comparison-control.cargo-V.txt"
Step 'workspace-check' @('check','--workspace','--locked','--all-targets','--all-features') 'comparison-control.workspace-check.stdout' 'comparison-control.workspace-check.log'
Step 'workspace-clippy' @('clippy','--workspace','--locked','--all-targets','--all-features') 'comparison-control.workspace-clippy.stdout' 'comparison-control.workspace-clippy.log'
Step 'sema-doctest' @('test','-p','arcweft-lang-sema','--locked','--all-features','--doc') 'comparison-control.sema-doctest.stdout' 'comparison-control.sema-doctest.log'
Assert-Source
& pwsh -NoProfile -File "$root/comparison-control-reverse/run.ps1" -SourceCommit $publication.Source -SourceTree $publication.Tree
$groupedExit=$LASTEXITCODE
Assert-Source
& pwsh -NoProfile -File "$root/comparison-control-compiler/run.ps1" -SourceCommit $publication.Source -SourceTree $publication.Tree
$compilerExit=$LASTEXITCODE
Assert-Source
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;GroupedExit=$groupedExit;CompilerExit=$compilerExit;Finished=(Get-Date).ToString('o');SourcePinsVerified=$true}|ConvertTo-Json|Set-Content -Encoding utf8 "$root/comparison-control.consumer-driver.json"
Write-Output "CONSUMER TERMINAL grouped=$groupedExit compiler=$compilerExit"



