$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/comparison-control.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/comparison-control.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$scratch/comparison-control.consumer-summary.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/comparison-control.broad-quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/comparison-control.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/comparison-control.archive.json"|ConvertFrom-Json
$checkpoint=Get-Content -Raw "$scratch/comparison-control.checkpoint-publication.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Documentation base changed'}
if($owner.Selected -ne 1758 -or $owner.Passed -ne 1752 -or $owner.Failed -ne 6 -or !$owner.IdsEqual -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or $consumers.Targets -ne 107 -or !$consumers.IdsEqual -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.ExitCode -ne 0 -or !$archive.AllEntriesVerified){throw 'Unexpected final validation'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previousStatus=[IO.File]::ReadAllText((Join-Path $PWD $status))
$previousHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previousStatus,'(?m)^\| Generic Match[^\r\n]+').Value
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']="| 再帰関数値の終端効果 | **既受入を維持。候補比較へ元の予算・取消制御を接続し検証・公開。本体内推論は継続** | 最新Source ``$($pub.Source)``。caller-bound recursion・共有prefix・Free許可／reifyと実owner replayの受入を維持する。sealed branch比較はcallback cleanup後に同じcandidate work sessionを借り、比較dispatchと制御された効果graph操作が共通の予算・node上限・取消信号を使う。比較専用failureはsource ticketを持たず、FatalSourceを発行できない。canonical factの比較法は従来どおりで、その全内部走査の制御化、prepared effect graphのfrontend owner化、prepared型の全port／Γ統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[実owner接続](convergence-evidence-history.md#live-owner-candidate-replay-and-sealed-branch-equivalence)・[予算と取消の接続](convergence-evidence-history.md#sealed-branch-comparison-control)。 |"
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,752 PASS／6 FAIL。後続21 packageも今回再実行** | Source ``$($pub.Source)`` のlocked・全feature Sema lib／tests 1,758件を$($owner.ExecutionSeconds)秒で実行。直前1,755 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行し、全2,510件／2,507 PASS／2 FAIL／1 SKIP。選択／終端ID一致・重複0、Compiler既知2失敗とcompile-only 3 targetも照合した。再帰本体の未解決を今回の比較制御だけで修復済みとしない。[owner・consumer・全SHA原本](acceptance-evidence/task-comparison-control.raw.zip)。 |"
$rows['CLIの規定対象／全 check 照合']="| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source ``$($pub.Source)`` のlocked・既定feature／filterでlibrary 196件と規定の統合6 target 30件を今回実行し、226 PASS。binはcompile済み・runnable test 0件。選択／終端ID一致・重複0。以前の入力・失敗・公開SHAは履歴へ保持する。[今回のCLI原本](acceptance-evidence/task-comparison-control.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace品質・doctest・fmt・構造gateを再実行し終了0** | Source ``$($pub.Source)`` のlocked workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateを実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。13 Rust path・$($owner.PhysicalGrowth)物理LOC増。既存のlower completion、client、candidate accountingの責務を維持し、別state owner・public API・Cargo依存・I/O・codec・version変更はない。fan-in／out $($owner.FanIn)／$($owner.FanOut)は不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。Tier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入は今回未実行。[品質・構造・原本](acceptance-evidence/task-comparison-control.raw.zip)。 |"
$current=$previousStatus
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
    if([regex]::Matches($current,$pattern).Count -ne 1){throw "Current row missing or duplicated: $key"}
    $replacement=$rows[$key]
    $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-14。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
$entry=@"

## Sealed-branch comparison control

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの13 Rust pathを通常commit／非force pushし、検証dirty bytes・commit・公開blobを照合した。owner・workspace品質の完了後、consumer $($checkpoint.CompletedGroups)／20 group完了・Compiler未開始の途中でSourceをpushした時点もcheckpoint原本に保持した。既存の未追跡 ``%SystemDrive%/`` を保持した。

- lowerは完成componentが等しい場合、比較dispatchの1 nodeを課金してから元のaccounting reservationをlive clientへ貸す。clientのfinish／callback cleanupを先に一度だけ実施する順序を維持した。CandidateConstraintWorkSessionのDecisionControlと型投影は同じnode／work予算・取消信号を使い、比較のために予算を作り直さない。
- 比較専用failureはconstraint failureとclient invariantだけを保持し、source ticketなしにFatalSourceを作れない。予算超過と取消しを同値・通常不一致・client invariantへ変換しない。従来のcanonical fact／Exact・Semantic replayの比較規則と物理評価記録は保持した。その全内部走査を今回制御化したという主張はしない。
- 新3件は、実driver内の再帰する効果graph relation比較で、source probeと同じreservation、正確な追加node／work量、比較の全node予算境界、cleanup各1回、比較中の元信号による取消し、失敗後も使用可能な両affine deltaを検証した。assertion・既定budget・評価量・選択filterは弱めていない。
- ownerは1,758件／1,752 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,755 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。開発途中のcheck記録は最終Sourceの品質証拠に流用していない。
- fresh full metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗、CLI規定226 PASSとcompile-only 3 targetを照合した。実行中の検証を完了扱いせず、全20 group・Compiler 31 targetの終端を確認した。
- workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateは今回Sourceで終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。13 path・$($owner.PhysicalGrowth)物理LOC増。lower frontierの完了、clientのlifecycle、candidate accountingという既存ownerを維持し、別state owner・public API・依存・I/O・codec・versionは追加しない。大きな既存moduleもこの責務を保ち、実LOC・byte size・embedded test LOCとfan-in $($owner.FanIn)／fan-out $($owner.FanOut)を原本へ記録した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- Supersedes: 候補比較へ元の制御が渡らなかった境界と最新の実測一覧を更新した。prepared effect graphのfrontend owner化、prepared型の全producer／consumerとΓ統合、body一回準備・一括seal、eager経路の置換、一般量化消去・MGU／rank・Fn局所∀と既知の再帰本体6件は、この比較制御だけで完了にしない。Generic Match、caller-bound recursion、共有prefix、Free許可／reifyと各既受入は維持する。過去の全SHA・実測・失敗・原本は変更せず、現状一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-comparison-control.raw.zip](acceptance-evidence/task-comparison-control.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText((Join-Path $PWD $history),"`r`n"+$entry.Replace("`r`n","`n").Replace("`n","`r`n")+"`r`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($previousHistory.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if($after.Length -le $previousHistory.Length -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($previousHistory)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical archive index changed'}
foreach($document in @($rows.Values)+@($entry)){
    foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
        $target=$match.Groups[1].Value
        if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
        if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link: $target"}
    }
}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$previousHistory.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/comparison-control.docs-validation.json"
git diff --stat
