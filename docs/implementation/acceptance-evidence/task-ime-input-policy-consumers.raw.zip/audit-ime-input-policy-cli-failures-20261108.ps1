$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$log='ime-purpose-enter-key-integrated-20261108.cli-r2.runtime.log'
$lines=@(Get-Content "$r/$log")
$ids=@('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering','spec_valid_run_edge_fixture_now_executes','verify_json_records_required_solver_checks','verify_json_reports_missing_promotion_proof')
$rows=@(foreach($id in $ids){
    $indices=@(for($i=0;$i -lt $lines.Count;$i++){
        if($lines[$i] -match '^\s+FAIL' -and $lines[$i].Contains($id)){$i}
    })
    if(!$indices.Count){throw 'Expected failure block missing'}
    $start=$indices[0]
    $voice=@()
    if($id -like 'agent_observe*'){
        $cause='sema.final_analysis shared callable resolution, expression slot 15'
    }elseif($id -eq 'spec_valid_run_edge_fixture_now_executes'){
        $cause='active dialogue has no voice'
        $voice=@(for($i=0;$i -lt $lines.Count;$i++){
            if($lines[$i].Contains($cause)){[ordered]@{line=($i+1);text=$lines[$i]}}
        })
    }else{
        $cause='type-check denied: sema.final_analysis, expression slot 8 has no admissible final type; solver phase was not reached'
    }
    [ordered]@{binary='arcweft-cli::check';test=$id;observedCause=$cause;logStartLine=($start+1);firstLines=@($lines|Select-Object -Skip $start -First 38);voiceStatusLines=$voice}
})
[ordered]@{version=1;production='76d32c7a3ff15513f2e62120f32a84bf775598af';log=$log;failureDiagnostics=$rows;note='Actual diagnostic excerpts; complete raw log is authoritative. Final failure-set comparison is performed against the terminal audit, not inferred from these excerpts.'}|ConvertTo-Json -Depth 14|Set-Content "$r/ime-purpose-enter-key-integrated-20261108.failure-diagnostics.json" -Encoding utf8
$rows|ForEach-Object {[pscustomobject]@{test=$_.test;cause=$_.observedCause}}|ConvertTo-Json
