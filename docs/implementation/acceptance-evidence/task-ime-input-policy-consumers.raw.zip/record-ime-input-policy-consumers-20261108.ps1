$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$noncli=Read-Record 'ime-purpose-enter-key-integrated-20261108.noncli.runtime.terminal-audit.json'
$cli=Read-Record 'ime-purpose-enter-key-integrated-20261108.cli-r2.runtime.terminal-audit.json'
$main=Read-Record 'ime-purpose-enter-key-integrated-20261108.cli-r2.main-audit.json'
$probe=Read-Record 'ime-purpose-enter-key-integrated-20261108.cli-source-probe.json'
$coverage=Read-Record 'ime-purpose-enter-key-integrated-20261108.coverage-review.json'
$diagnostics=Read-Record 'ime-purpose-enter-key-integrated-20261108.failure-diagnostics.json'
if($noncli.executed -ne 9535 -or $noncli.failed -ne 0 -or $cli.executed -ne 711 -or $cli.failed -ne 4 -or $probe.exitCode -ne 0 -or $probe.status -ne 'ok' -or $probe.mainExecutableSha256 -ne $main.sha256 -or $coverage.requiredMissing.Count -ne 0){throw 'Consumer result differs'}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'viewImeInputPolicyConsumers'){throw 'Consumer record exists'}
$oldIds=@($prior.viewAuthoredTargetConsumers.cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)
$newIds=@($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)
$failureDiff=@(Compare-Object $oldIds $newIds)
if($failureDiff.Count){throw 'Failure set changed; investigate before recording'}
$raw=@(Get-ChildItem -LiteralPath $r -File -Filter 'ime-purpose-enter-key-integrated-20261108*')+@(
    (Get-Item "$r/ime-purpose-enter-key-20261108.source.verified.json"),
    (Get-Item "$r/ime-purpose-enter-key-20261108.owner-evidence.verified.json"),
    (Get-Item "$r/ime-purpose-enter-key-20261108.graph.json"),
    (Get-Item "$r/audit-ime-input-policy-coverage-20261108.ps1"),
    (Get-Item "$r/audit-ime-input-policy-cli-failures-20261108.ps1"),
    (Get-Item "$r/run-ime-input-policy-source-probe-20261108.ps1"),
    (Get-Item "$r/run-retained-input-cli-main-20261108.ps1"),
    (Get-Item $PSCommandPath))
$archive='docs/implementation/acceptance-evidence/task-ime-input-policy-consumers.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($file in ($raw|Sort-Object FullName -Unique)){
        if($file.Extension -notin @('.log','.json','.patch','.txt','.ps1')){throw 'Unexpected raw entry'}
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    foreach($p in @('arcw.toml','src/main.arcw')){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,"$r/ime-purpose-enter-key-probe/$p",('probe/'+$p),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|dll|rlib|rmeta|pdb|awfb)$').Count){throw 'Build artifact in raw archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$entry=[ordered]@{
    version=1;date='2026-11-08';sourcePublication=(Read-Record 'ime-purpose-enter-key-20261108.source.verified.json')
    ownerEvidencePublication=(Read-Record 'ime-purpose-enter-key-20261108.owner-evidence.verified.json')
    nonCli=$noncli;cli=$cli;mainExecutable=$main
    freshUniqueExecuted=($noncli.executed+$cli.executed);passed=($noncli.passed+$cli.passed);failed=($noncli.failed+$cli.failed);skipped=($noncli.skipped+$cli.skipped)
    featurePoints=@('workspace except CLI, all-features, lib/tests, rdeps(Id)','CLI default, lib/tests')
    graph=(Read-Record 'ime-purpose-enter-key-20261108.graph.json');coverageReview=$coverage
    cliFailureIdChanges=$failureDiff;observedDiagnostics=$diagnostics;cliSourceProbe=$probe
    failedPreparation=(Read-Record 'ime-purpose-enter-key-integrated-20261108.cli.catalog.json')
    preparationCause='Initial CLI preparation: E0786 mmap of libarcweft_bundle-02810d89b427c070.rlib refused with Windows OS1455 (paging file). No runtime tests executed. Retry retains the same source/features/profile/default jobs/budgets/selection and reuses completed builds.'
    archive=$archiveInfo;preservedPriorRecords=@($prior.PSObject.Properties).Count
    scope='Fresh 71-package ID reverse closure and default CLI. No prior runs, logical reuse or focused owner repetitions are added. Remaining Source samples/placeholder/navigation/Scroll and actual Native/Web display remain distinct conditions.'
}
$wrapper=(ConvertTo-Json ([ordered]@{viewImeInputPolicyConsumers=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd();$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if((ConvertTo-Json $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json $property.Value -Depth 100 -Compress)){throw ('History changed: '+$property.Name)}}
[ordered]@{priorRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;executed=$entry.freshUniqueExecuted;passed=$entry.passed;failed=$entry.failed;skipped=$entry.skipped;archive=$archiveInfo}|ConvertTo-Json -Depth 10|Set-Content "$r/ime-input-policy-consumers-record-audit.json" -Encoding utf8
Get-Content "$r/ime-input-policy-consumers-record-audit.json" -Raw
