$ErrorActionPreference='Stop'
$r=$PSScriptRoot
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$current=Read-Record 'ime-purpose-enter-key-integrated-20261108.noncli.catalog.inventory.json'
$previous=Read-Record 'view-authored-target-integrated-20261108.noncli.catalog.inventory.json'
$owner=Read-Record 'ime-purpose-enter-key-20261108.owner-r2.catalog.inventory.json'
$generator=Read-Record 'ime-purpose-enter-key-20261108.generator.catalog.inventory.json'
function Case-Key($row){$row.binary+'::'+$row.test}
$selected=@($current.rows|Where-Object status -eq 'matches')
$keys=@($selected|ForEach-Object {Case-Key $_})
$old=@($previous.rows|Where-Object status -eq 'matches')
$missingPrior=@(foreach($row in $old){$key=Case-Key $row;if($key -notin $keys){$key}})
$required=@(@($owner.rows|Where-Object status -eq 'matches')+@($generator.rows|Where-Object status -eq 'matches'))
$missingRequired=@(foreach($row in $required){$key=Case-Key $row;if(@($keys|Where-Object {$_ -ceq $key}).Count -ne 1){$key}})
$duplicates=@($keys|Group-Object|Where-Object Count -ne 1)
if($old.Count -ne 4646 -or $missingPrior.Count -ne 0 -or $required.Count -ne 342 -or $missingRequired.Count -ne 0 -or $duplicates.Count -ne 0){throw 'Required coverage differs'}
[ordered]@{version=1;production='76d32c7a3ff15513f2e62120f32a84bf775598af';selected=$selected.Count;runtimePackages=@($selected.package|Sort-Object -Unique).Count;priorViewClosureCases=$old.Count;priorCasesMissing=$missingPrior;requiredOwnerCases=$required.Count;requiredMissing=$missingRequired;duplicates=$duplicates;note='New ID reverse closure, same all-features non-CLI lib/tests point. Previous View closure and all owner cases each remain selected once; no prior executions are added to the fresh count.'}|ConvertTo-Json -Depth 12|Set-Content "$r/ime-purpose-enter-key-integrated-20261108.coverage-review.json" -Encoding utf8
Get-Content "$r/ime-purpose-enter-key-integrated-20261108.coverage-review.json" -Raw
