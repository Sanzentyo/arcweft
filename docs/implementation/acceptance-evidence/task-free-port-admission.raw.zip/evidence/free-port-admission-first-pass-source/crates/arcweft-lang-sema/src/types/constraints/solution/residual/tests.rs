use crate::types::constraints::test_support::ConstraintTestSetup;
use std::{
    collections::BTreeMap,
    sync::{Arc, atomic::AtomicBool},
};

use crate::{
    effect_row::EffectRow,
    types::{
        ArrayLength, DetachedGenericOwnerId, GenericBinder, GenericConstParameterId,
        GenericConstReference, GenericParameterOwnerId, GenericScope, GenericScopeError,
        GenericTypeParameterId, GenericTypeReference, TypeKind,
        constraints::{
            NoConstraintClient, TypeConstraintConstEligibility, TypeConstraintParameterEligibility,
            TypeConstraintParameterScope, TypeConstraintSolution,
            context::{
                LocalConstraintAccounting, TypeConstraintConstParameterScopeRow,
                TypeConstraintLimits, TypeConstraintTypeParameterScopeRow,
            },
        },
    },
};

type TestContext<'a> = ConstraintTestSetup<'a, LocalConstraintAccounting<'a>, NoConstraintClient>;

fn parameter(slot: u16) -> GenericTypeParameterId {
    GenericTypeParameterId::new(
        GenericParameterOwnerId::Detached(DetachedGenericOwnerId::new(715)),
        slot,
    )
}

fn constant() -> GenericConstParameterId {
    GenericConstParameterId::new(
        GenericParameterOwnerId::Detached(DetachedGenericOwnerId::new(715)),
        0,
    )
}

fn context(scope: TypeConstraintParameterScope, cancellation: &AtomicBool) -> TestContext<'_> {
    TestContext::with_scope(
        TypeConstraintLimits::new(65_536, 32_768, 1024, 1024),
        cancellation,
        scope,
    )
}

fn recursive_scope() -> TypeConstraintParameterScope {
    TypeConstraintParameterScope::seal_call_scope(
        crate::types::GenericBinder::EMPTY,
        [
            TypeConstraintTypeParameterScopeRow::new(
                parameter(0),
                TypeConstraintParameterEligibility::Rigid,
            ),
            TypeConstraintTypeParameterScopeRow::new(
                parameter(0),
                TypeConstraintParameterEligibility::Bindable,
            ),
        ],
        [],
        crate::types::constraints::TypeConstraintEffectScope::seal_call_scope([], [])
            .expect("empty effect scope"),
        [],
        [],
    )
    .expect("caller and callee occupy distinct namespaces")
}

#[test]
fn recursive_binding_to_the_same_declaration_is_free_and_issuer_independent() {
    let cancellation = AtomicBool::new(false);
    let complete = || {
        let (mut context, mut path) = context(recursive_scope(), &cancellation).into_path();
        let callee = path
            .root_scope()
            .parameters()
            .type_reference(&(parameter(0)).clone().into())
            .expect("template slot");
        let caller = GenericTypeReference::Free(parameter(0));
        assert_ne!(callee, caller);
        {
            let original = context
                .fixture_original_context_with_rigid(
                    crate::types::constraints::OriginalRigidScope {
                        types: &[caller.clone()],
                        consts: &[],
                        effects: &[],
                        imported: None,
                    },
                )
                .unwrap();
            let value = context
                .fixture_operand_in(&original, &TypeKind::GenericParam(caller))
                .unwrap();
            path.bindings = [(callee, value)].into();
            path.const_bindings = BTreeMap::new();
            TypeConstraintSolution::complete_application(&path, path.root_id(), &mut context)
        }
        .expect("recursive binding is not an occurs cycle")
    };
    let first = complete();
    let second = complete();
    assert_eq!(
        first, second,
        "a completed solution retains no active issuer"
    );
    let (_, value) = first.bindings().next().expect("one binding");
    let value = value.value();
    assert_eq!(value, &TypeKind::generic_parameter(parameter(0)));
    assert!(value.semantic_identity_digest().is_ok());
}

fn continuation_scope(next: bool) -> TypeConstraintParameterScope {
    TypeConstraintParameterScope::seal_call_scope(
        crate::types::GenericBinder::EMPTY,
        [
            TypeConstraintTypeParameterScopeRow::new(
                parameter(1),
                TypeConstraintParameterEligibility::Rigid,
            ),
            TypeConstraintTypeParameterScopeRow::new(
                parameter(0),
                TypeConstraintParameterEligibility::Bindable,
            ),
            TypeConstraintTypeParameterScopeRow::new(
                parameter(1),
                if next {
                    TypeConstraintParameterEligibility::Bindable
                } else {
                    TypeConstraintParameterEligibility::FutureEligible
                },
            ),
        ],
        [TypeConstraintConstParameterScopeRow::new(
            constant(),
            if next {
                TypeConstraintConstEligibility::Bindable
            } else {
                TypeConstraintConstEligibility::FutureEligible
            },
        )],
        crate::types::constraints::TypeConstraintEffectScope::seal_call_scope([], [])
            .expect("empty effect scope"),
        (if next { vec![parameter(0)] } else { vec![] })
            .into_iter()
            .map(Into::into),
        [],
    )
    .expect("canonical continuation scope")
}

fn prefix(cancellation: &AtomicBool) -> TypeConstraintSolution {
    let (mut context, mut path) = context(continuation_scope(false), cancellation).into_path();
    let local = GenericScope::default()
        .with_binder(GenericBinder::new(1, 0, 0))
        .bound_type(0, 0)
        .expect("function-local bound parameter");
    let remaining = path
        .root_scope()
        .parameters()
        .type_reference(&(parameter(1)).clone().into())
        .expect("future type");
    let remaining_const = path
        .root_scope()
        .parameters()
        .const_reference(&(constant()).clone().into())
        .expect("future length");
    let value = TypeKind::function_with_binder(
        GenericBinder::new(1, 0, 0),
        [TypeKind::GenericParam(local)],
        TypeKind::Tuple(vec![
            TypeKind::GenericParam(remaining),
            TypeKind::generic_parameter(parameter(1)),
            TypeKind::Array {
                item: Box::new(TypeKind::Bool),
                len: ArrayLength::Generic(remaining_const),
            },
        ]),
        EffectRow::closed(crate::effects::EffectSet::new()),
    );
    {
        // This prepared template's contract independently declares its caller
        // capture and the actual application's future parameters.
        let owner = path
            .applications
            .require_application_owner(path.root_id())
            .unwrap();
        let value = crate::types::constraints::transaction::ConstraintOperand::fixture_template(
            value,
            std::sync::Arc::new(context.capture_lexical_scope().unwrap()),
            owner,
        );
        path.bindings = [(
            path.root_scope()
                .parameters()
                .type_reference(&(parameter(0)).clone().into())
                .expect("bound type"),
            value,
        )]
        .into();
        path.const_bindings = BTreeMap::new();
        TypeConstraintSolution::complete_application(&path, path.root_id(), &mut context)
    }
    .expect("future references become residual binders")
}

#[test]
fn nested_function_binders_preserve_inner_variables_and_bind_future_types_and_lengths() {
    let cancellation = AtomicBool::new(false);
    let solution = prefix(&cancellation);
    let (_, value) = solution.bindings().next().expect("prefix binding");
    let value = value.value();
    let TypeKind::Function {
        params,
        return_type,
        ..
    } = value
    else {
        panic!("function binding")
    };
    assert!(
        matches!(params.as_slice(), [TypeKind::GenericParam(GenericTypeReference::Bound(parameter))] if parameter.depth() == 0)
    );
    let TypeKind::Tuple(items) = return_type.as_ref() else {
        panic!("tuple result")
    };
    assert!(
        matches!(&items[0], TypeKind::GenericParam(GenericTypeReference::Bound(parameter)) if parameter.depth() == 1 && parameter.slot() == 0)
    );
    assert_eq!(items[1], TypeKind::generic_parameter(parameter(1)));
    assert!(
        matches!(&items[2], TypeKind::Array { len: ArrayLength::Generic(GenericConstReference::Bound(parameter)), .. } if parameter.depth() == 1 && parameter.slot() == 0)
    );
    assert!(matches!(
        value.semantic_identity_digest(),
        Err(GenericScopeError::UnknownDepth { depth: 1 })
    ));
    assert!(
        value
            .semantic_identity_digest_in_scope(solution.context.value_scope())
            .is_ok()
    );
}

#[test]
fn one_prefix_can_reopen_twice_without_sharing_inference_variables() {
    let cancellation = AtomicBool::new(false);
    let solution = Arc::new(prefix(&cancellation));
    let (mut first, first_path) = context(continuation_scope(true), &cancellation).into_path();
    let (mut second, second_path) = context(continuation_scope(true), &cancellation).into_path();
    let mut first_path = solution
        .restore_inherited_path(first_path.root_id(), first_path, &mut first)
        .expect("first opening");
    let mut second_path = solution
        .restore_inherited_path(second_path.root_id(), second_path, &mut second)
        .expect("second opening");
    let first_key = first_path
        .root_scope()
        .parameters()
        .type_reference(&(parameter(1)).clone().into())
        .expect("first residual variable");
    let second_key = second_path
        .root_scope()
        .parameters()
        .type_reference(&(parameter(1)).clone().into())
        .expect("second residual variable");
    assert_ne!(first_key, second_key);
    first_path
        .bindings
        .insert(first_key, first.fixture_operand(TypeKind::I32));
    second_path
        .bindings
        .insert(second_key, second.fixture_operand(TypeKind::String));
    first_path.const_bindings.insert(
        first_path
            .root_scope()
            .parameters()
            .const_reference(&(constant()).clone().into())
            .expect("length"),
        first.fixture_operand(ArrayLength::Const(3)),
    );
    second_path.const_bindings.insert(
        second_path
            .root_scope()
            .parameters()
            .const_reference(&(constant()).clone().into())
            .expect("length"),
        second.fixture_operand(ArrayLength::Const(5)),
    );
    let first = {
        TypeConstraintSolution::complete_application(&first_path, first_path.root_id(), &mut first)
    }
    .expect("first application closes");
    let second = {
        TypeConstraintSolution::complete_application(
            &second_path,
            second_path.root_id(),
            &mut second,
        )
    }
    .expect("second application closes");
    assert_ne!(first, second);
    for (solution, item, length) in [(&first, TypeKind::I32, 3), (&second, TypeKind::String, 5)] {
        let (_, value) = solution.bindings().next().expect("inherited function");
        let value = value.value();
        let TypeKind::Function { return_type, .. } = value else {
            panic!("function")
        };
        assert_eq!(
            return_type.as_ref(),
            &TypeKind::Tuple(vec![
                item,
                TypeKind::generic_parameter(parameter(1)),
                TypeKind::Array {
                    item: Box::new(TypeKind::Bool),
                    len: ArrayLength::Const(length)
                }
            ])
        );
        assert!(value.semantic_identity_digest().is_ok());
    }
}
