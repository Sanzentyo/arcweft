$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/free-port-admission.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/free-port-admission.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/free-port-admission.impact.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/free-port-admission.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/free-port-admission.structure.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/free-port-admission.consumer-summary.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/free-port-admission.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean'}
if($owner.Passed -ne 1722 -or $owner.Failed -ne 6 -or !$impact.ReverseConsumersRerun -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$archive.AllEntriesVerified -or $structure.ExitCode){throw 'Evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'History prefix changed'}
$rows=@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。型・定数のFree許可とreify保持を検証・公開。本体内推論は継続** | 最新Source `SOURCE`。Native／AWBCの42・各step公開保存復元、Source Γ・import lease・実フレーム移送の既受入を維持。元の量化R、guard付きimport、Future部分代入、nullary条件の同時消去とprincipal条件付きの下限を保持する。一般のcross-label条件・choice・局所∀・非nullary・importは簡約できる範囲を越えたら元のRを保持する。型・定数のFree参照はalias lookup前に対応するportのSource宣言・template owner・parameter lease・alias終端・completed bindingの個別captureで許可を確認し、受け手のinventoryだけでは通さない。異なるSourceのitem／lengthを各portの証拠で合成でき、兄弟Source／completed bindingの許可交換は拒否する。型と定数のcompletion／reifyは実operand・child／alias導出・実フレームを保持する一つのfoldを使う。追加3件と、保存・再開・取消し復元、10,000 alias／10,001 nodeの元上限を確認。effect-onlyのreify、effect参照のFree許可とprimitive effect行のΓ seal、一般量化消去・MGU／rank・Fn型ownerの局所∀、全portのΓ統合、frontend prepared value／effect・body一回準備・一括sealは継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[残余簡約](convergence-evidence-history.md#nullary-effect-residual-reduction)・[今回の型・定数の許可](convergence-evidence-history.md#free-type-and-constant-admission-from-operand-derivations)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,722 PASS／6 FAIL。後続21 packageは2,507 PASS／2 FAIL／1 SKIP** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,728件をSECONDS秒で実行。直前1,725 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。型・定数制約の先行対象301件も全件PASS。最初の全1,727件は1,710 PASS／17 FAILで、既知6件に加わった11件は許可を持たないground Sourceを使ったfixtureだった。実際の宣言・import lease・template contractへ移行し、その拒否結果も原本に保持する。全feature metadata／全target reverse treeの22 packageを確認し、後続21 package／107 targetも同じSourceで再実行した。2,510件中2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19も不変。[現在のowner・全consumer・graph・全SHA原本](acceptance-evidence/task-free-port-admission.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source `SOURCE`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件を今回再実行し、226 PASS。binはcompile済み・runnable test 0件。21 packageの全consumer照合に含め、選択・終端ID一致・重複0を確認した。以前の入力・件数・失敗・公開SHAと再利用範囲は履歴と原本へ保持する。[今回のCLI原本](acceptance-evidence/task-free-port-admission.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace全target／全feature check・Clippy、fmt・doctest・構造gateは終了0** | Source `SOURCE` と同一のRust bytesでlocked workspace全target／全feature checkとClippy、workspace fmt、Sema doctest 2件を今回実行。構造gateはPACKAGES package・FILES files・RUSTFILES Rust files・RUSTLOC Rust LOC・REVIEWS review・blocking 0。16 Rust path・GROWTH物理LOC増。既存の導出保持foldに各portの許可確認を置き、対応するSource／owner／terminal／binding captureを使う。定数の型付きcompletionとreifyへ移行し、旧raw helperを削除した。追加の型walkerやΓの複製catalogは導入せず、fixtureの数学的templateと実Source値を区別した。Cargo graphは22 package、fan-in／outは12／19で不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告も原本へ保持。全体cargo cleanは2026-11-13の9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を維持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・graph・全consumer](acceptance-evidence/task-free-port-admission.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$status=[IO.File]::ReadAllText($statusPath)
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'}
    $replacement=$rows[$key].Replace('SOURCE',$pub.Source).Replace('SECONDS',[string]$owner.ExecutionSeconds).Replace('PACKAGES',[string]$structure.Packages).Replace('RUSTFILES',[string]$structure.RustFiles).Replace('FILES',[string]$structure.Files).Replace('RUSTLOC',[string]$structure.RustPhysicalLOC).Replace('REVIEWS',[string]$structure.ReviewTriggers).Replace('GROWTH',[string]$owner.PhysicalGrowth)
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$date=Get-Date -Format 'yyyy-MM-dd'
$status=[regex]::Replace($status,'確認日 [0-9]{4}-[0-9]{2}-[0-9]{2}。','確認日 '+$date+'。')
$status=[regex]::Replace($status,'この更新の基点の `main` と `origin/main` は `[a-f0-9]{40}`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Free type and constant admission from operand derivations

$date。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの16 Rust pathを通常commit／非force pushし、ownerが検証したdirty bytesと公開全blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- 既存RetainOrigins foldでFreeの型・定数参照をalias lookup前に検証する。対応するportのOriginal Source、実template owner、introduced parameter lease、selected child、alias終端、completed bindingの個別captureを辿る。受け手に見えるRigid参照だけでは許可を発行しない。completed captureは正規化済みのbinding keyで検索し、共有contextのcaptureを借りない。
- 定数completionとreifyも元operandを受ける入口へ置換した。型・定数とも実フレームをsourceにして、成功・取消し時に受け手scopeを復元する。既存constant foldにclosure policyを渡して再利用し、旧raw project_const_argumentを削除した。10,000 aliasの既存テストを実際の型付きfoldへ移し、元の10,001 node上限と次nodeの拒否を保持した。型・定数・effectのframe移送を含む既存テストもassertionを追加した。
- 新3件は、両参照が受け手でRigidでも別Sourceの許可交換を拒否すること、異なるSourceのitem／lengthを各portの証拠で合成できること、完成した2 bindingを実continuationへ復元しても互いのcaptureを借りられないことを検証する。Source宣言とtemplate契約の役割を区別してfixtureを修復し、ground Sourceを許可源へ拡張しない。
- 初回の全1,727件は1,710 PASS／17 FAIL／0 SKIP。既知6件に加わった11件は、数学的templateやcaller captureをground Sourceとして作っていたfixtureだった。明示的なSource宣言・実import lease・template ownerへ移行し、対象300件、追加後301件を全PASSにした。続く全1,728件は1,722 PASS／6 FAIL、旧raw helper削除前の検証入力15 pathも全bytesを別snapshotへ保持した。最終の全feature ownerは1,728件／1,722 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,725 ID保持・新3件PASS・選択／終端ID一致・重複0、既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。devの空effect-scope APIとfixtureの変数shadowingによるcompile拒否も保持した。
- producerが変わるため、fresh full metadata／全target reverse treeの22 packageから、後続21 package／107 targetを同じSourceで再実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19、CLI規定226 PASS、compile-only 3 targetを照合した。workspace全target／全feature checkとClippy、workspace fmt、Sema doctest 2件、構造gateは終了0。Cargo graph、fan-in 12／fan-out 19は不変。
- 16 path・$($owner.PhysicalGrowth)物理LOC増。許可判断は既存operandの導出が、正規化は既存foldが、実フレームと出力ごとのcaptureは既存completed transportが所有する。Supersedes: 現状一覧の定数reifyとFree許可全体の未完了列挙を、検証済みの型・定数の境界と、effect-only reify／effect参照の許可／primitive行のΓ sealへ分けて訂正した。一般量化消去・全portのΓ統合・frontend再帰本体推論の完了とはしない。以前の全SHA・実測・失敗・原本とGeneric Match・caller-bound recursion・共有prefixの受入を保持し、現在の一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-free-port-admission.raw.zip](acceptance-evidence/task-free-port-admission.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended actual type/constant admission evidence.'
