$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/free-port-admission.publication.json"|ConvertFrom-Json
$inputPin=Get-Content -Raw "$root/free-port-admission.input.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/free-port-admission.owner-validation.json"|ConvertFrom-Json
$previous=Get-Content -Raw "$root/operand-reification.owner-summary.json"|ConvertFrom-Json
$baseline=Get-Content -Raw "$root/operand-reification.owner-terminal.json"|ConvertFrom-Json
if($quality.Source -ne $pub.Parent -or $inputPin.Source -ne $pub.Parent -or $quality.Steps.Count -ne 3){throw 'Owner input differs'}
foreach($step in $quality.Steps){
    $expected=if($step.Name -eq 'owner-run'){100}else{0}
    if($step.ExitCode -ne $expected -or !$step.SourcePinsVerified){throw 'Owner step differs'}
}
$log=[IO.File]::ReadAllText("$root/free-port-admission.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1728 tests run: 1722 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Owner terminal summary differs'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1728\) (\S+) (.+)\r?$')|ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/free-port-admission.owner-list.json"|ConvertFrom-Json
$ids=@(foreach($suite in $listing.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Name+'$'+$case.Name}}})
if($ids.Count -ne 1728 -or $terminal.Count -ne 1728 -or @($terminal|Group-Object Id|Where-Object Count -GT 1).Count -or @(Compare-Object -CaseSensitive @($ids|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selected and terminal identities differ'}
$delta=@(Compare-Object -CaseSensitive @($baseline.Id|Sort-Object) @($ids|Sort-Object))
if($delta.Count -ne 3 -or @($delta|Where-Object SideIndicator -CNE '=>').Count){throw 'Baseline test identities changed'}
$new=@($terminal|Where-Object {$delta.InputObject -ccontains $_.Id})
if($new.Count -ne 3 -or @($new|Where-Object Result -CNE 'PASS').Count){throw 'New conditional cases failed'}
$failed=@($terminal|Where-Object Result -CEQ 'FAIL'|ForEach-Object Name|Sort-Object)
if(@(Compare-Object -CaseSensitive $previous.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failure identity/diagnostics changed'}
$measurements=@(foreach($p in $pub.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($pub.Source):$($p.Path)") -ne $p.Blob){throw 'Tested source identity changed'}
    $before=@(git show "$($pub.Parent):$($p.Path)" 2>$null); if($LASTEXITCODE){$before=@()}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    [pscustomobject]@{Path=$p.Path;Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$before.Count;Growth=$lines-$before.Count;Class=if($p.Path -like '*/tests.rs' -or $p.Path -like '*/tests/*'){'test'}else{'production; no embedded tests'};Owner='arcweft-lang-sema';SHA256=$p.SHA256;Blob=$p.Blob}
})
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse 'HEAD^{tree}') -ne $pub.Tree -or @(git diff --name-only HEAD).Count){throw 'Final source identity differs'}
$metadata=Get-Content -Raw "$root/free-port-admission.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$fanOut=@(($metadata.resolve.nodes|Where-Object id -CEQ $owner.id).deps).Count
$fanIn=@($metadata.resolve.nodes|Where-Object {$_.deps.pkg -ccontains $owner.id}).Count
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/free-port-admission.owner-terminal.json"
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;OwnerInputParent=$pub.Parent;TestedDirtyBytesEqualCommittedBlobs=$true;Selected=1728;Passed=1722;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;IdsEqual=$true;Duplicates=0;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;Baseline=$previous.Source;FmtExit=0;Measurements=$measurements;PhysicalGrowth=($measurements|Measure-Object Growth -Sum).Sum;FanIn=$fanIn;FanOut=$fanOut;OwnershipDisposition='The existing RetainOrigins fold admits Free type and constant occurrences through the corresponding value derivation before alias lookup. Source, template, introduced parameter lease, exact alias terminal, selected child and per-binding completed capture authorities remain distinct; a receiving inventory is eligibility only. Constant completion and reification now retain the operand and actual frames through the same controlled fold; the obsolete raw constant wrapper was deleted. Three regressions exercise forged source permission despite visible keys, independently sourced item/length ports and restored sibling captures. Existing frame/cancellation and 10000-alias exact-budget coverage was strengthened without raising limits. Mathematical seed fixtures use actual template contracts or explicit source declarations. Effect-only reification and primitive effect Gamma sealing remain separate unfinished boundaries.'}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/free-port-admission.owner-summary.json"
Get-Content "$root/free-port-admission.owner-summary.json" -TotalCount 18
