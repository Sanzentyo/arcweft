$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/free-port-admission.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/free-port-admission.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {$changed=$false;foreach($node in $metadata.resolve.nodes){if(!$closure.Contains($node.id)){foreach($dependency in $node.deps){if($closure.Contains($dependency.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/operand-reification.impact.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count){throw 'Reverse graph changed'}
$consumers=Get-Content -Raw "$root/free-port-admission.consumer-summary.json"|ConvertFrom-Json
if($consumers.Source -ne $pub.Source -or $consumers.Targets -ne 107 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$consumers.IdsEqual -or $consumers.Duplicates){throw 'Fresh consumer coverage differs'}
$inputs=@(git diff --name-only $previous.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml')
if($inputs.Count){throw 'Cargo graph inputs changed'}
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='free-port-admission.reverse-tree.txt';CargoInputsUnchanged=$true;ReverseConsumersRerun=$true;FreshTargets=$consumers.Targets;FreshPassed=$consumers.Passed;FreshFailed=$consumers.Failed;FreshSkipped=$consumers.Skipped;Reason='Free type and constant admission, constant completion and reification producers changed. Full sema owner, every downstream package in the fresh all-feature resolved reverse closure, all 107 prescribed consumer targets, workspace all-target/all-feature check and Clippy, owner doctests, fmt and structure gate were rerun. Historical target inventories and failure IDs are comparison inputs; no historical execution is relabeled as current.'}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/free-port-admission.impact.json"
Write-Output "Verified fresh reverse closure: $($packages.Count) packages, 107 consumer targets"
