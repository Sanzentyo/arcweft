$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$arcTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$arcTemp/assert-no-arcweft-build.ps1"
$arcFreeze=Get-Content -LiteralPath "$arcTemp/presentation-mount-schema-owner-20261101.source-freeze.json" -Raw|ConvertFrom-Json -Depth 25
function Assert-Inputs { foreach($row in $arcFreeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}} }
Assert-Inputs
$arcStarted=[DateTime]::UtcNow.ToString('o')
$arcArgs=@('clippy','-p','arcweft-interaction-model','-p','arcweft-lang-sema','--all-targets','--all-features','--locked')
& cargo @arcArgs *> "$arcTemp/presentation-mount-schema-owner-20261101.clippy.log"
$arcCode=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$arcFreeze.base;command=$arcArgs;exitCode=$arcCode;sourceInputs=$arcFreeze.paths.Count;sourceDrift=0;startedAt=$arcStarted;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$arcTemp/presentation-mount-schema-owner-20261101.clippy.json" -Encoding utf8
if($arcCode -ne 0){throw 'Owner Clippy failed'}
$arcPaths=@('crates/arcweft-interaction-model/src/presentation/arguments.rs','crates/arcweft-interaction-model/src/presentation/callables.rs','crates/arcweft-lang-sema/src/callable/presentation.rs','crates/arcweft-lang-sema/src/callable/schema/families.rs','crates/arcweft-lang-sema/src/final_analysis/tests/presentation.rs')
& rustfmt --edition 2024 --config skip_children=true --check @arcPaths *> "$arcTemp/presentation-mount-schema-owner-20261101.fmt.log"
$arcCode=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;paths=$arcPaths;exitCode=$arcCode;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$arcTemp/presentation-mount-schema-owner-20261101.fmt.json" -Encoding utf8
if($arcCode -ne 0){throw 'Owner fmt failed'}
Write-Output 'Owner Clippy and fmt exited 0; source drift 0'