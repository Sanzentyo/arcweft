//! Closed family schemas used by the shared callable resolver.

use crate::{
    callable::CharacterDialoguePatchContext,
    character_dialogue::CharacterDialogueFieldCoordinate,
    effect_row::EffectRow,
    effects::{EffectId, EffectSet},
    env::{
        RegisteredTypeCheckEnv,
        nominal::{
            AcceptedNominalCatalog, standard_agent_error_type, standard_arc_error_type,
            standard_dialogue_content_type, standard_nominal_id, standard_reduction_record,
        },
    },
    types::{
        CharacterDialogueCharacterType, CharacterDialogueType, CompileTimeFxType, EntityKind,
        FixedVectorType, GenericConstParameterId, GenericParameterOwnerId, GenericTypeParameterId,
        LanguageIntrinsicGenericOwner, MapKind, TypeKind,
    },
};
use arcweft_character::id::CharacterId;
use arcweft_interaction_model::dialogue::CharacterDialogueRuntimeRole as DialogueRole;
use arcweft_lang_syntax::reference::BorrowKind;

use super::{
    CallableArgumentPolicy, CallableAttachedContentParameter, CallableEffectSchema,
    CallableEvaluatedEffect, CallableExtensionReceiver, CallableGenericParameterIssuer,
    CallableGroupKind, CallableParameter, CallableParameterAdmission, CallableParameterConsumer,
    CallableParameterGroup, CallableParameterPassing, CallableParameterPresence,
    CallableParameterValueRule, CallableResultSchema, CallableSchemaDependency,
    CallableSignatureSchema, CallableValidator, ContentCallableIdentity, SpreadArgumentPolicy,
    UnknownNamedArgumentPolicy,
};
use crate::callable::PromotionCallableId;
use crate::callable::{
    AgentIntrinsicSignatureId, BuiltinCallableId, CallableName, CallableParameterIndex,
    CallableSchemaError, CapabilityCallableId, CapacityMethodId, CollectionMethodId,
    DialogueCallableId, DialogueCallableResultContext, DialogueCalleeIdentity,
    DialogueSchemaContext, DomainMethodId, FloatWidth, FxSourceConstructor, IntegerMethodId,
    LineContextMethodId, LineScheduleCallableId, MathCallableId, OptionConstructorKind,
    PRODUCTION_CALLABLE_LIMITS, PresentationArgumentRole, PresentationArgumentValuePolicy,
    PresentationCallableId, PresentationHandleMethodId, ReductionConstructorKind,
    ResolvedCharacterOwner, ResultConstructorKind, StageMethodId, StandardMapFamily,
    StdFloatCallableId, StdFloatOperation, VectorDimensions,
};
use crate::registration::{CompileTimeScalarTypeRoleId, RegisteredCompileTimeScalarTypes};
use arcweft_presentation::fx::{
    FxEnumDomain, FxRuntimeType, FxSelectorDomain, FxSourceParameterPassing, FxSourceParameterType,
    FxStaticType,
};
use arcweft_presentation::rich_text::{
    PresentationContentCallableDefinitionId, PresentationContentCallableParameterSpec,
};
use arcweft_rich_text_schema::{
    RichTextCallableParameterPassing, RichTextCallableParameterPresence,
    RichTextEnumValueConstraint, RichTextValueKind,
};

pub(in crate::callable) fn dialogue_schema(
    id: DialogueCallableId,
    context: DialogueSchemaContext<'_>,
) -> Result<CallableSignatureSchema, CallableSchemaError> {
    if !id.supports_callee(context.callee) || context.roles.world() != context.custom_fields.world()
    {
        return Err(CallableSchemaError::FamilyInvariant {
            family: crate::callable::CallableFamily::Dialogue,
            code: crate::callable::CallableFamilyInvariantCode::InvalidOwner,
        });
    }
    match (id, context.result) {
        (
            DialogueCallableId::ContentApplication,
            DialogueCallableResultContext::ContentApplication { .. },
        )
        | (
            DialogueCallableId::CharacterFactory
            | DialogueCallableId::CharacterReconfigure
            | DialogueCallableId::ContentCall,
            DialogueCallableResultContext::Declared,
        ) => {}
        _ => {
            return Err(CallableSchemaError::FamilyInvariant {
                family: crate::callable::CallableFamily::Dialogue,
                code: crate::callable::CallableFamilyInvariantCode::InvalidOwner,
            });
        }
    }
    let (parameters, result, policy) = match (id, context.callee) {
        (DialogueCallableId::CharacterFactory, DialogueCalleeIdentity::Character { character })
        | (
            DialogueCallableId::CharacterReconfigure,
            DialogueCalleeIdentity::CharacterDialogue { character },
        ) => {
            let mut parameters = character_dialogue_patch_parameters(character, context.roles);
            if context.patch_context == CharacterDialoguePatchContext::ImmediateContentApplication {
                let next = parameters.len();
                parameters.push(parameter_with_consumer(
                    next,
                    Some("id"),
                    CallableParameterAdmission::checked(TypeKind::entity_ref(
                        EntityKind::DialogueLine,
                    )),
                    CallableParameterPassing::NamedOnly,
                    CallableParameterPresence::Optional,
                    CallableParameterConsumer::DialogueApplicationMetadata(
                        super::DialogueApplicationMetadataCoordinate::Id,
                    ),
                ));
                parameters.push(parameter_with_consumer(
                    next + 1,
                    Some("text_key"),
                    CallableParameterAdmission::checked(TypeKind::entity_ref(EntityKind::Text)),
                    CallableParameterPassing::NamedOnly,
                    CallableParameterPresence::Optional,
                    CallableParameterConsumer::DialogueApplicationMetadata(
                        super::DialogueApplicationMetadataCoordinate::TextKey,
                    ),
                ));
            }
            for (name, descriptor) in context.custom_fields.visible_bindings(context.module) {
                let index = parameters.len();
                parameters.push(dialogue_patch(
                    index,
                    name,
                    descriptor.value_type().clone(),
                    CharacterDialogueFieldCoordinate::Custom(descriptor.id().clone()),
                    descriptor.clearable(),
                ));
            }
            (
                parameters,
                TypeKind::CharacterDialogue(CharacterDialogueType::new(character.clone())),
                closed(),
            )
        }
        (DialogueCallableId::ContentApplication, DialogueCalleeIdentity::Character { .. })
        | (
            DialogueCallableId::ContentApplication,
            DialogueCalleeIdentity::CharacterDialogue { .. },
        ) => {
            let target = match context.callee {
                DialogueCalleeIdentity::Character { .. } => {
                    TypeKind::entity_ref(EntityKind::Character)
                }
                DialogueCalleeIdentity::CharacterDialogue { character } => {
                    TypeKind::CharacterDialogue(CharacterDialogueType::new(character.clone()))
                }
                DialogueCalleeIdentity::Content { .. } => {
                    return Err(CallableSchemaError::FamilyInvariant {
                        family: crate::callable::CallableFamily::Dialogue,
                        code: crate::callable::CallableFamilyInvariantCode::InvalidOwner,
                    });
                }
            };
            let DialogueCallableResultContext::ContentApplication { line_result } = context.result
            else {
                return Err(CallableSchemaError::FamilyInvariant {
                    family: crate::callable::CallableFamily::Dialogue,
                    code: crate::callable::CallableFamilyInvariantCode::InvalidOwner,
                });
            };
            (
                vec![
                    required_positional(0, "target", target),
                    required_positional(
                        1,
                        "content",
                        TypeKind::Named("DialogueContent".to_owned()),
                    ),
                    parameter(
                        2,
                        Some("line_plan"),
                        CallableParameterAdmission::checked(TypeKind::Named("LinePlan".to_owned())),
                        CallableParameterPassing::PositionalOnly,
                        CallableParameterPresence::Optional,
                    ),
                ],
                TypeKind::DialogueLine(Box::new(line_result.clone())),
                closed(),
            )
        }
        (DialogueCallableId::ContentCall, DialogueCalleeIdentity::Content { .. }) => {
            (content_call_parameters(context), TypeKind::Unit, closed())
        }
        _ => {
            return Err(CallableSchemaError::FamilyInvariant {
                family: crate::callable::CallableFamily::Dialogue,
                code: crate::callable::CallableFamilyInvariantCode::InvalidOwner,
            });
        }
    };
    Ok(schema(
        parameters,
        result,
        &[],
        policy,
        CallableValidator::Dialogue(id),
    ))
}

/// Projects one presentation-owned content row into the sema callable
/// schema. The presentation catalog remains the sole authority for row
/// identity, parameter order, body policy, enum constraints, and digest;
/// this function only translates its typed descriptors into callable-layer
/// admissions.
pub(crate) fn presentation_content_schema(
    definition: PresentationContentCallableDefinitionId,
    scalars: &RegisteredCompileTimeScalarTypes,
) -> Result<CallableSignatureSchema, CallableSchemaError> {
    let catalog = arcweft_presentation::rich_text::PRESENTATION_CONTENT_CALLABLE_CATALOG;
    let row = catalog
        .get(definition)
        .ok_or(CallableSchemaError::FamilyInvariant {
            family: crate::callable::CallableFamily::Content,
            code: crate::callable::CallableFamilyInvariantCode::InvalidOwner,
        })?;
    let parameters = row
        .parameters()
        .iter()
        .enumerate()
        .map(|(index, spec)| {
            let index = CallableParameterIndex::try_from_usize(index).map_err(|_| {
                CallableSchemaError::ParameterLimit {
                    actual: row.parameters().len(),
                    limit: PRODUCTION_CALLABLE_LIMITS.max_parameters_per_callable(),
                }
            })?;
            let admission =
                CallableParameterAdmission::checked(content_parameter_type(spec, scalars)?);
            let passing = match spec.passing {
                RichTextCallableParameterPassing::PositionalOnly => {
                    CallableParameterPassing::PositionalOnly
                }
                RichTextCallableParameterPassing::NamedOnly => CallableParameterPassing::NamedOnly,
            };
            let presence = match spec.presence {
                RichTextCallableParameterPresence::Required => CallableParameterPresence::Required,
                RichTextCallableParameterPresence::Optional => CallableParameterPresence::Optional,
                RichTextCallableParameterPresence::Defaulted(_) => {
                    CallableParameterPresence::Defaulted
                }
                RichTextCallableParameterPresence::Conditional { .. } => {
                    CallableParameterPresence::Optional
                }
            };
            CallableParameter::try_new(
                index,
                Some(
                    arcweft_lang_syntax::name::CallArgumentName::try_new(spec.source_name)
                        .map_err(|_| CallableSchemaError::MissingParameterName {
                            group: crate::callable::CallableGroupIndex::ZERO,
                            parameter: index,
                        })?,
                ),
                admission,
                passing,
                presence,
                None,
                None,
            )
        })
        .collect::<Result<Vec<_>, _>>()?;
    let group = CallableParameterGroup::try_new(
        crate::callable::CallableGroupIndex::ZERO,
        CallableGroupKind::Initial,
        parameters,
        &PRODUCTION_CALLABLE_LIMITS,
    )?;
    let identity = ContentCallableIdentity::language(definition, row.schema_digest());
    let attached_content = CallableAttachedContentParameter::from_presentation_row(row);
    CallableSignatureSchema::try_new_with_dependency(
        vec![group],
        CallableResultSchema::ContentEmission(identity),
        CallableEffectSchema::fixed(EffectRow::closed(EffectSet::new())),
        closed(),
        CallableValidator::Content(identity),
        Some(attached_content),
        CallableSchemaDependency::presentation_content(definition, row.schema_digest()),
        CallableGenericParameterIssuer::empty(),
        &PRODUCTION_CALLABLE_LIMITS,
    )
}

fn content_parameter_type(
    spec: &PresentationContentCallableParameterSpec,
    scalars: &RegisteredCompileTimeScalarTypes,
) -> Result<TypeKind, CallableSchemaError> {
    let scalar = |role| scalars.type_for(role).clone();
    let ty = match spec.kind {
        RichTextValueKind::Bool => scalar(CompileTimeScalarTypeRoleId::Bool),
        RichTextValueKind::Int => scalar(CompileTimeScalarTypeRoleId::Int),
        RichTextValueKind::FixedMilli => scalar(CompileTimeScalarTypeRoleId::Milli),
        RichTextValueKind::Ratio => scalar(CompileTimeScalarTypeRoleId::Ratio),
        RichTextValueKind::Length => scalar(CompileTimeScalarTypeRoleId::Length),
        RichTextValueKind::Angle => scalar(CompileTimeScalarTypeRoleId::Angle),
        RichTextValueKind::Duration => scalar(CompileTimeScalarTypeRoleId::Duration),
        RichTextValueKind::ClosedEnum(domain) => match spec.enum_constraint {
            RichTextEnumValueConstraint::Exact(variant) => {
                TypeKind::CompileTimeEnum(crate::types::CompileTimeEnumType::exact(domain, variant))
            }
            RichTextEnumValueConstraint::All => {
                TypeKind::CompileTimeEnum(crate::types::CompileTimeEnumType::any(domain))
            }
            RichTextEnumValueConstraint::Allowed(variants) => TypeKind::CompileTimeEnum(
                crate::types::CompileTimeEnumType::allowed(domain, variants),
            ),
        },
        RichTextValueKind::Selector(arcweft_rich_text_schema::SelectorKind::PublicId)
        | RichTextValueKind::PublicId => scalar(CompileTimeScalarTypeRoleId::PublicId),
        RichTextValueKind::Text => scalar(CompileTimeScalarTypeRoleId::Text),
        RichTextValueKind::Color => scalar(CompileTimeScalarTypeRoleId::Color),
        RichTextValueKind::Vec2 => {
            TypeKind::FixedVector(FixedVectorType::new(VectorDimensions::Two, TypeKind::F32))
        }
        RichTextValueKind::Seed32 => TypeKind::U32,
        RichTextValueKind::Fx => TypeKind::CompileTimeFx(CompileTimeFxType::Abstract),
        RichTextValueKind::Selector(_) => {
            return Err(CallableSchemaError::FamilyInvariant {
                family: crate::callable::CallableFamily::Content,
                code: crate::callable::CallableFamilyInvariantCode::InvalidParameterType,
            });
        }
    };
    Ok(ty)
}

fn character_dialogue_patch_parameters(
    character: &CharacterDialogueCharacterType,
    roles: &crate::character_dialogue::CharacterDialogueRuntimeRoleRegistry,
) -> Vec<CallableParameter> {
    let mut parameters = Vec::new();
    if let CharacterDialogueCharacterType::Exact(character) = character {
        parameters.push(dialogue_patch(
            parameters.len(),
            "look",
            TypeKind::character_look(character.clone()),
            CharacterDialogueFieldCoordinate::Look,
            true,
        ));
    }
    let fixed = [
        (
            "voice",
            TypeKind::Named("DialogueVoice".to_owned()),
            CharacterDialogueFieldCoordinate::Voice,
        ),
        (
            "stage",
            roles.semantic_type(DialogueRole::Stage).clone(),
            CharacterDialogueFieldCoordinate::Stage,
        ),
        (
            "portrait",
            roles.semantic_type(DialogueRole::Portrait).clone(),
            CharacterDialogueFieldCoordinate::Portrait,
        ),
        (
            "focus",
            roles.semantic_type(DialogueRole::Focus).clone(),
            CharacterDialogueFieldCoordinate::Focus,
        ),
        (
            "cleanup",
            roles.semantic_type(DialogueRole::Cleanup).clone(),
            CharacterDialogueFieldCoordinate::Cleanup,
        ),
        (
            "view",
            TypeKind::entity_ref(EntityKind::View),
            CharacterDialogueFieldCoordinate::View,
        ),
        (
            "source_locale",
            TypeKind::String,
            CharacterDialogueFieldCoordinate::SourceLocale,
        ),
        (
            "hooks",
            TypeKind::Seq(Box::new(roles.semantic_type(DialogueRole::Hook).clone())),
            CharacterDialogueFieldCoordinate::Hooks,
        ),
        (
            "style",
            roles.semantic_type(DialogueRole::Style).clone(),
            CharacterDialogueFieldCoordinate::Style,
        ),
        (
            "rich_text",
            roles.semantic_type(DialogueRole::RichText).clone(),
            CharacterDialogueFieldCoordinate::RichText,
        ),
        (
            "inline_error",
            TypeKind::Named("InlineFailure".to_owned()),
            CharacterDialogueFieldCoordinate::InlineFailure,
        ),
        (
            "inline_error_policy",
            TypeKind::Named("InlineFailure".to_owned()),
            CharacterDialogueFieldCoordinate::InlineFailure,
        ),
        (
            "inline_fallback",
            TypeKind::Named("InlineFailure".to_owned()),
            CharacterDialogueFieldCoordinate::InlineFailure,
        ),
    ];
    for (name, ty, coordinate) in fixed {
        let index = parameters.len();
        parameters.push(dialogue_patch(index, name, ty, coordinate, true));
    }
    parameters
}

/// A content call applies a content-owned patch to a dialogue value.  It is
/// intentionally separate from CharacterFactory/Reconfigure: content calls
/// have no concrete character owner, so every visible field is supply-only
/// and unknown names are rejected by the closed argument policy.
fn content_call_parameters(context: DialogueSchemaContext<'_>) -> Vec<CallableParameter> {
    let roles = context.roles;
    let fixed = [
        (
            "voice",
            TypeKind::Named("DialogueVoice".to_owned()),
            CharacterDialogueFieldCoordinate::Voice,
        ),
        (
            "stage",
            roles.semantic_type(DialogueRole::Stage).clone(),
            CharacterDialogueFieldCoordinate::Stage,
        ),
        (
            "portrait",
            roles.semantic_type(DialogueRole::Portrait).clone(),
            CharacterDialogueFieldCoordinate::Portrait,
        ),
        (
            "focus",
            roles.semantic_type(DialogueRole::Focus).clone(),
            CharacterDialogueFieldCoordinate::Focus,
        ),
        (
            "cleanup",
            roles.semantic_type(DialogueRole::Cleanup).clone(),
            CharacterDialogueFieldCoordinate::Cleanup,
        ),
        (
            "view",
            TypeKind::entity_ref(EntityKind::View),
            CharacterDialogueFieldCoordinate::View,
        ),
        (
            "source_locale",
            TypeKind::String,
            CharacterDialogueFieldCoordinate::SourceLocale,
        ),
        (
            "hooks",
            TypeKind::Seq(Box::new(roles.semantic_type(DialogueRole::Hook).clone())),
            CharacterDialogueFieldCoordinate::Hooks,
        ),
        (
            "style",
            roles.semantic_type(DialogueRole::Style).clone(),
            CharacterDialogueFieldCoordinate::Style,
        ),
        (
            "rich_text",
            roles.semantic_type(DialogueRole::RichText).clone(),
            CharacterDialogueFieldCoordinate::RichText,
        ),
        (
            "inline_error",
            TypeKind::Named("InlineFailure".to_owned()),
            CharacterDialogueFieldCoordinate::InlineFailure,
        ),
        (
            "inline_error_policy",
            TypeKind::Named("InlineFailure".to_owned()),
            CharacterDialogueFieldCoordinate::InlineFailure,
        ),
        (
            "inline_fallback",
            TypeKind::Named("InlineFailure".to_owned()),
            CharacterDialogueFieldCoordinate::InlineFailure,
        ),
    ];
    let mut parameters = fixed
        .into_iter()
        .enumerate()
        .map(|(index, (name, ty, coordinate))| dialogue_patch(index, name, ty, coordinate, false))
        .collect::<Vec<_>>();
    for (name, descriptor) in context.custom_fields.visible_bindings(context.module) {
        let index = parameters.len();
        parameters.push(dialogue_patch(
            index,
            name,
            descriptor.value_type().clone(),
            CharacterDialogueFieldCoordinate::Custom(descriptor.id().clone()),
            false,
        ));
    }
    parameters
}

fn dialogue_patch(
    index: usize,
    name: &str,
    declared: TypeKind,
    coordinate: CharacterDialogueFieldCoordinate,
    clearable: bool,
) -> CallableParameter {
    let admission = if clearable {
        CallableParameterAdmission::checked_with_rule(
            declared,
            CallableParameterValueRule::clearable_option(),
        )
    } else {
        CallableParameterAdmission::checked(declared)
    };
    parameter_with_consumer(
        index,
        Some(name),
        admission,
        CallableParameterPassing::PositionalOrNamed,
        CallableParameterPresence::Optional,
        CallableParameterConsumer::DialoguePatch(coordinate),
    )
}

impl BuiltinCallableId {
    /// Returns a schema only for a closed builtin whose identity is complete
    /// without an accepted-world join. Reduction deliberately returns None.
    pub fn closed_signature_schema(&self) -> Option<CallableSignatureSchema> {
        let validator = CallableValidator::Builtin(self.clone());
        Some(match self {
            Self::InlineFailureFallback => return None,
            Self::Panic | Self::Fail | Self::Bail => schema(
                vec![unchecked(
                    0,
                    match self {
                        Self::Fail => "error",
                        Self::Panic | Self::Bail => "message",
                        _ => unreachable!("grouped builtin identity is exhaustive"),
                    },
                    CallableParameterPresence::Required,
                )],
                TypeKind::Never,
                &[],
                closed(),
                validator,
            )
            .with_evaluated_effect(match self {
                Self::Panic => CallableEvaluatedEffect::Panic,
                Self::Fail => CallableEvaluatedEffect::Fail,
                Self::Bail => CallableEvaluatedEffect::Bail,
                _ => unreachable!("grouped builtin identity is exhaustive"),
            })
            .expect("fixed intrinsic schema was sealed before attaching its evaluated effect"),
            Self::Ensure => schema(
                vec![
                    parameter(
                        0,
                        Some("condition"),
                        CallableParameterAdmission::checked(TypeKind::Bool),
                        CallableParameterPassing::PositionalOrNamed,
                        CallableParameterPresence::Required,
                    ),
                    parameter(
                        1,
                        Some("message"),
                        CallableParameterAdmission::unchecked_supply(),
                        CallableParameterPassing::PositionalOrNamed,
                        CallableParameterPresence::Required,
                    ),
                ],
                TypeKind::Unit,
                &[],
                closed(),
                validator,
            )
            .with_evaluated_effect(CallableEvaluatedEffect::Ensure)
            .expect("fixed ensure schema was sealed before attaching its evaluated effect"),
            // `rgb` produces the registered compile-time `Color` scalar.  Its
            // result therefore cannot be represented by this world-free
            // schema; callers must use `world_signature_schema` below.
            Self::Rgb => return None,
            Self::Sin | Self::Cos => homogeneous(1, &TypeKind::F32, TypeKind::F32, validator),
            Self::Vector { dimensions } => {
                let arity = match dimensions {
                    VectorDimensions::Two => 2,
                    VectorDimensions::Three => 3,
                    VectorDimensions::Four => 4,
                };
                homogeneous(
                    arity,
                    &TypeKind::F32,
                    TypeKind::FixedVector(FixedVectorType::new(*dimensions, TypeKind::F32)),
                    validator,
                )
            }
            Self::Math(id) => {
                use arcweft_core::math::{
                    RuntimeDenseNumericType as Dense, RuntimeFloatWidth as Width,
                };
                let dense = match id {
                    MathCallableId::MatMulF32 | MathCallableId::MatrixAddF32 => {
                        Dense::Matrix(Width::F32)
                    }
                    MathCallableId::MatMulF64 | MathCallableId::MatrixAddF64 => {
                        Dense::Matrix(Width::F64)
                    }
                    MathCallableId::TensorAddF32 => Dense::Tensor(Width::F32),
                    MathCallableId::TensorAddF64 => Dense::Tensor(Width::F64),
                };
                let ty = TypeKind::DenseNumeric(dense);
                homogeneous(2, &ty, ty.clone(), validator)
            }
            Self::StdFloat(id) => std_float_schema(*id, validator),
            Self::Capability(CapabilityCallableId::EventEmit) => schema(
                vec![unchecked(0, "event", CallableParameterPresence::Required)],
                TypeKind::Unit,
                &[],
                open_named_supply(),
                validator,
            )
            .with_evaluated_effect(CallableEvaluatedEffect::EmitEvent)
            .expect("fixed event schema was sealed before attaching its evaluated effect"),
            Self::Reduction(_) => return None,
        })
    }

    /// Returns a builtin schema after joining the accepted semantic world.
    ///
    /// `rgb` and the InlineFailure constructor use accepted-world owners;
    /// neither may be assigned an identity by a world-free Named placeholder.
    pub(crate) fn world_signature_schema(
        &self,
        scalars: &crate::registration::RegisteredCompileTimeScalarTypes,
        roles: &crate::character_dialogue::CharacterDialogueRuntimeRoleRegistry,
    ) -> Option<CallableSignatureSchema> {
        if matches!(self, Self::Rgb) {
            return Some(homogeneous(
                1,
                &TypeKind::String,
                scalars
                    .type_for(crate::registration::CompileTimeScalarTypeRoleId::Color)
                    .clone(),
                CallableValidator::Builtin(self.clone()),
            ));
        }
        if matches!(self, Self::InlineFailureFallback) {
            let policy_types = roles.policy_types();
            let inline_failure =
                arcweft_dialogue::CharacterDialoguePolicyTypeGraph::owner_for_language_type(
                    "InlineFailure",
                )?;
            let inline_fallback =
                arcweft_dialogue::CharacterDialoguePolicyTypeGraph::owner_for_language_type(
                    "InlineFallback",
                )?;
            let _ = (
                policy_types.identity(inline_failure),
                policy_types.identity(inline_fallback),
            );
            let input = TypeKind::Choice(vec![
                TypeKind::String,
                TypeKind::Named(inline_fallback.language_type_name().to_owned()),
            ]);
            return Some(homogeneous(
                1,
                &input,
                TypeKind::Named(inline_failure.language_type_name().to_owned()),
                CallableValidator::Builtin(self.clone()),
            ));
        }
        self.closed_signature_schema()
    }
}

fn std_float_schema(
    id: StdFloatCallableId,
    validator: CallableValidator,
) -> CallableSignatureSchema {
    let width = match id.width() {
        FloatWidth::F32 => TypeKind::F32,
        FloatWidth::F64 => TypeKind::F64,
    };
    let bits = match id.width() {
        FloatWidth::F32 => TypeKind::U32,
        FloatWidth::F64 => TypeKind::U64,
    };
    let (arity, input, result) = match id.operation() {
        StdFloatOperation::Powf | StdFloatOperation::Atan2 => (2, width.clone(), width.clone()),
        StdFloatOperation::MulAdd => (3, width.clone(), width.clone()),
        StdFloatOperation::IsNan
        | StdFloatOperation::IsInfinite
        | StdFloatOperation::IsFinite
        | StdFloatOperation::IsSignPositive
        | StdFloatOperation::IsSignNegative => (1, width.clone(), TypeKind::Bool),
        StdFloatOperation::ToBits => (1, width.clone(), bits.clone()),
        StdFloatOperation::FromBits => (1, bits, width.clone()),
        StdFloatOperation::ToF32 => (1, width.clone(), TypeKind::F32),
        StdFloatOperation::ToF64 => (1, width.clone(), TypeKind::F64),
        StdFloatOperation::Abs
        | StdFloatOperation::Floor
        | StdFloatOperation::Ceil
        | StdFloatOperation::Round
        | StdFloatOperation::Trunc
        | StdFloatOperation::Fract
        | StdFloatOperation::Sqrt
        | StdFloatOperation::Sin
        | StdFloatOperation::Cos
        | StdFloatOperation::Tan
        | StdFloatOperation::Exp
        | StdFloatOperation::Exp2
        | StdFloatOperation::Ln
        | StdFloatOperation::Log2
        | StdFloatOperation::Log10 => (1, width.clone(), width),
    };
    homogeneous(arity, &input, result, validator)
}

impl ReductionConstructorKind {
    pub(crate) fn accepted_signature_schema(
        self,
        catalog: &AcceptedNominalCatalog,
    ) -> Option<CallableSignatureSchema> {
        let record = standard_reduction_record(catalog)?;
        let declaration = record.id().clone();
        match self {
            Self::Unchanged => {
                let owner = GenericParameterOwnerId::AcceptedNominal(declaration.clone());
                let state = generic(owner, 0);
                let state_ref = TypeKind::BorrowRef {
                    kind: BorrowKind::Shared,
                    lifetime: None,
                    inner: Box::new(state.clone()),
                };
                Some(schema_with_issuer(
                    vec![parameter(
                        0,
                        Some("state"),
                        CallableParameterAdmission::checked(state_ref),
                        CallableParameterPassing::PositionalOnly,
                        CallableParameterPresence::Required,
                    )],
                    TypeKind::AcceptedNominal(crate::types::AcceptedNominalType::new(
                        declaration.clone(),
                        [state],
                    )),
                    &[],
                    closed(),
                    CallableValidator::ReductionConstructor(self),
                    CallableGenericParameterIssuer::accepted_nominal(declaration.clone(), 1, 0)
                        .expect("accepted reduction issuer"),
                ))
            }
        }
    }
}

impl ResultConstructorKind {
    pub(crate) fn signature_schema(self) -> CallableSignatureSchema {
        let owner = GenericParameterOwnerId::LanguageIntrinsic(
            LanguageIntrinsicGenericOwner::ResultConstructor,
        );
        let ok = generic(owner.clone(), 0);
        let error = generic(owner, 1);
        let payload = match self {
            Self::Ok => ok.clone(),
            Self::Err => error.clone(),
        };
        schema_with_issuer(
            vec![parameter(
                0,
                Some("payload"),
                CallableParameterAdmission::checked(payload),
                CallableParameterPassing::PositionalOnly,
                CallableParameterPresence::Required,
            )],
            TypeKind::Result {
                ok: Box::new(ok),
                error: Box::new(error),
            },
            &[],
            closed(),
            CallableValidator::ResultConstructor(self),
            CallableGenericParameterIssuer::language_intrinsic(
                LanguageIntrinsicGenericOwner::ResultConstructor,
                2,
                0,
            )
            .expect("Result issuer"),
        )
    }
}

impl OptionConstructorKind {
    pub(crate) fn signature_schema(self) -> CallableSignatureSchema {
        let item = generic(
            GenericParameterOwnerId::LanguageIntrinsic(
                LanguageIntrinsicGenericOwner::OptionConstructor,
            ),
            0,
        );
        schema_with_issuer(
            vec![parameter(
                0,
                Some("payload"),
                CallableParameterAdmission::checked(item.clone()),
                CallableParameterPassing::PositionalOnly,
                CallableParameterPresence::Required,
            )],
            TypeKind::Option(Box::new(item)),
            &[],
            closed(),
            CallableValidator::OptionConstructor(self),
            CallableGenericParameterIssuer::language_intrinsic(
                LanguageIntrinsicGenericOwner::OptionConstructor,
                1,
                0,
            )
            .expect("Option issuer"),
        )
    }
}

impl CollectionMethodId {
    pub(crate) fn resolve_for_receiver(
        receiver: &TypeKind,
        method: &CallableName,
        arity: usize,
    ) -> Option<Self> {
        if method.as_str() == "traverse" {
            return (arity == 1
                && matches!(
                    receiver,
                    TypeKind::Vec(_)
                        | TypeKind::Array { .. }
                        | TypeKind::Slice(_)
                        | TypeKind::Seq(_)
                ))
            .then(|| Self::Traverse {
                source: receiver.clone(),
            });
        }
        if method.as_str() == "parallel" {
            return (arity == 1 && matches!(receiver, TypeKind::Traversal { .. })).then(|| {
                Self::Parallel {
                    traversal: receiver.clone(),
                }
            });
        }
        if method.as_str() == "collect" {
            if arity != 0 {
                return None;
            }
            let (TypeKind::Vec(item) | TypeKind::Seq(item)) = receiver else {
                return None;
            };
            return Some(Self::Collect {
                item: item.as_ref().clone(),
            });
        }
        Self::resolve(method)
    }

    pub(crate) fn signature_schema(&self, receiver: &TypeKind) -> Option<CallableSignatureSchema> {
        let validator = CallableValidator::Collection(self.clone());
        if let Self::Traverse { source } = self {
            if source != receiver {
                return None;
            }
            let input = sequence_item(source)?;
            let owner = LanguageIntrinsicGenericOwner::CollectionTraverse;
            let generic_owner = GenericParameterOwnerId::LanguageIntrinsic(owner);
            let output = generic(generic_owner.clone(), 0);
            let error = generic(generic_owner.clone(), 1);
            let effects = EffectRow::open(
                EffectSet::new(),
                crate::types::GenericEffectParameterId::new(generic_owner, 0).into(),
            );
            let mapping = TypeKind::function_with_effects(
                [input],
                TypeKind::Need(Box::new(TypeKind::Result {
                    ok: Box::new(output),
                    error: Box::new(error),
                })),
                effects,
            );
            return Some(one_positional_with_issuer(
                "mapping",
                mapping.clone(),
                TypeKind::Traversal {
                    source: Box::new(source.clone()),
                    mapping: Box::new(mapping),
                },
                &[],
                validator,
                CallableGenericParameterIssuer::language_intrinsic(owner, 2, 0)
                    .expect("traverse owns its result, error and callback effect parameters"),
            ));
        }
        if let Self::Parallel { traversal } = self {
            if traversal != receiver {
                return None;
            }
            let TypeKind::Traversal { source, mapping } = traversal else {
                return None;
            };
            if !matches!(
                source.as_ref(),
                TypeKind::Vec(_) | TypeKind::Array { .. } | TypeKind::Slice(_) | TypeKind::Seq(_)
            ) {
                return None;
            }
            let TypeKind::Function {
                params,
                return_type,
                effects,
                ..
            } = mapping.as_ref()
            else {
                return None;
            };
            if params.len() != 1 {
                return None;
            }
            let TypeKind::Need(payload) = return_type.as_ref() else {
                return None;
            };
            let TypeKind::Result { ok, error } = payload.as_ref() else {
                return None;
            };
            let group = CallableParameterGroup::try_new(
                crate::callable::CallableGroupIndex::ZERO,
                CallableGroupKind::Initial,
                vec![parameter(
                    0,
                    Some("limit"),
                    CallableParameterAdmission::checked(TypeKind::U32),
                    CallableParameterPassing::NamedOnly,
                    CallableParameterPresence::Required,
                )],
                &PRODUCTION_CALLABLE_LIMITS,
            )
            .expect("parallel has one required named limit");
            return Some(
                CallableSignatureSchema::try_new(
                    vec![group],
                    TypeKind::Need(Box::new(TypeKind::Result {
                        ok: Box::new(TypeKind::Vec(ok.clone())),
                        error: error.clone(),
                    })),
                    CallableEffectSchema::fixed(effects.clone()),
                    closed(),
                    validator,
                    CallableGenericParameterIssuer::empty(),
                    &PRODUCTION_CALLABLE_LIMITS,
                )
                .expect(
                    "parallel retains the receiver's exact callback effect and result contract",
                ),
            );
        }
        if let Self::Collect { item } = self {
            let receiver_item = match receiver {
                TypeKind::Vec(receiver_item) | TypeKind::Seq(receiver_item) => {
                    receiver_item.as_ref()
                }
                _ => return None,
            };
            if receiver_item != item {
                return None;
            }
            let owner = LanguageIntrinsicGenericOwner::CollectionCollect;
            let destination = generic(GenericParameterOwnerId::LanguageIntrinsic(owner), 0);
            return Some(schema_with_issuer(
                Vec::new(),
                destination,
                &[],
                closed(),
                validator,
                CallableGenericParameterIssuer::language_intrinsic(owner, 1, 0)
                    .expect("collect owns one explicit destination type parameter"),
            ));
        }

        let item = sequence_item(receiver)?;
        Some(match self {
            Self::Len if !matches!(receiver, TypeKind::String) => {
                empty(TypeKind::USize, &[], validator)
            }
            Self::Filter => one_positional(
                "predicate",
                TypeKind::function([item], TypeKind::Bool),
                receiver.clone(),
                &[],
                validator,
            ),
            Self::Sum if item.is_integer() => empty(TypeKind::I64, &[], validator),
            Self::Contains => one_positional("item", item, TypeKind::Bool, &[], validator),
            Self::Len | Self::Sum => return None,
            Self::Collect { .. } | Self::Traverse { .. } | Self::Parallel { .. } => {
                unreachable!("parameterized collection schemas returned above")
            }
        })
    }
}

impl StandardMapFamily {
    pub(crate) fn signature_schema(self) -> CallableSignatureSchema {
        let generic_owner = LanguageIntrinsicGenericOwner::StandardMap(self);
        let owner = GenericParameterOwnerId::LanguageIntrinsic(generic_owner);
        let input = generic(owner.clone(), 0);
        let output = generic(owner.clone(), 1);
        let error = generic(owner.clone(), 2);
        let length = GenericConstParameterId::new(owner, 0);
        let (receiver, result) = match self {
            Self::Vec => (
                TypeKind::Vec(Box::new(input.clone())),
                TypeKind::Vec(Box::new(output.clone())),
            ),
            Self::Seq => (
                TypeKind::Seq(Box::new(input.clone())),
                TypeKind::Seq(Box::new(output.clone())),
            ),
            Self::Array => (
                TypeKind::Array {
                    item: Box::new(input.clone()),
                    len: crate::types::ArrayLength::generic_parameter(length.clone()),
                },
                TypeKind::Array {
                    item: Box::new(output.clone()),
                    len: crate::types::ArrayLength::generic_parameter(length),
                },
            ),
            Self::Slice => (
                TypeKind::Slice(Box::new(input.clone())),
                TypeKind::Vec(Box::new(output.clone())),
            ),
            Self::Option => (
                TypeKind::Option(Box::new(input.clone())),
                TypeKind::Option(Box::new(output.clone())),
            ),
            Self::Result => (
                TypeKind::Result {
                    ok: Box::new(input.clone()),
                    error: Box::new(error.clone()),
                },
                TypeKind::Result {
                    ok: Box::new(output.clone()),
                    error: Box::new(error),
                },
            ),
            Self::Need => (
                TypeKind::Need(Box::new(input.clone())),
                TypeKind::Need(Box::new(output.clone())),
            ),
            Self::Parser => (
                TypeKind::Parser {
                    item: Box::new(input.clone()),
                    error: Box::new(error.clone()),
                },
                TypeKind::Parser {
                    item: Box::new(output.clone()),
                    error: Box::new(error),
                },
            ),
            Self::Stream => (
                TypeKind::Stream {
                    item: Box::new(input.clone()),
                    error: Box::new(error.clone()),
                },
                TypeKind::Stream {
                    item: Box::new(output.clone()),
                    error: Box::new(error),
                },
            ),
        };
        let (type_count, const_count) = self.generic_arity();
        let groups = vec![
            CallableParameterGroup::try_new(
                crate::callable::CallableGroupIndex::ZERO,
                CallableGroupKind::Initial,
                vec![required_positional(
                    0,
                    "mapping",
                    TypeKind::function([input], output),
                )],
                &PRODUCTION_CALLABLE_LIMITS,
            )
            .expect("standard map callback group is canonical"),
            CallableParameterGroup::try_new(
                crate::callable::CallableGroupIndex::try_from_usize(1)
                    .expect("standard map receiver group is representable"),
                CallableGroupKind::Curried,
                vec![required_positional(0, "self", receiver)],
                &PRODUCTION_CALLABLE_LIMITS,
            )
            .expect("standard map receiver group is canonical"),
        ];
        CallableSignatureSchema::try_new(
            groups,
            result,
            CallableEffectSchema::fixed(EffectRow::closed(EffectSet::new())),
            closed(),
            CallableValidator::StandardMap(self),
            CallableGenericParameterIssuer::language_intrinsic(
                generic_owner,
                type_count,
                const_count,
            )
            .expect("standard map generic inventory is canonical"),
            &PRODUCTION_CALLABLE_LIMITS,
        )
        .and_then(|schema| {
            schema.with_extension_receiver(CallableExtensionReceiver::new(
                crate::callable::CallableGroupIndex::try_from_usize(1)
                    .expect("standard map receiver group is representable"),
                CallableParameterIndex::try_from_usize(0)
                    .expect("standard map receiver parameter is representable"),
            ))
        })
        .and_then(|schema| {
            if self.callback_is_immediate() {
                schema.with_invoked_parameter_effects(
                    crate::callable::CallableGroupIndex::ZERO,
                    CallableParameterIndex::try_from_usize(0)
                        .expect("the callback has one canonical coordinate"),
                )
            } else {
                Ok(schema)
            }
        })
        .expect("standard map schema has one canonical explicit receiver")
    }
}

impl CallableSignatureSchema {
    pub(crate) fn presentation_handle(id: PresentationHandleMethodId) -> Self {
        empty(
            TypeKind::Unit,
            &[],
            CallableValidator::PresentationHandle(id),
        )
    }
}

impl IntegerMethodId {
    pub(crate) fn signature_schema(self, receiver: &TypeKind) -> CallableSignatureSchema {
        let arity = if self == Self::Clamp { 2 } else { 1 };
        homogeneous(
            arity,
            receiver,
            receiver.clone(),
            CallableValidator::Integer(self),
        )
    }
}

impl DomainMethodId {
    pub(crate) fn signature_schema(&self, receiver: &TypeKind) -> Option<CallableSignatureSchema> {
        let validator = CallableValidator::Domain(self.clone());
        Some(match self {
            Self::FxSampleOrdinalPhase => empty(TypeKind::F32, &[], validator),
            Self::ObservedObjectRequireRole => one_positional(
                "role",
                TypeKind::String,
                agent_result(TypeKind::ObservedObject),
                &[],
                validator,
            ),
            Self::MapGet { key, value } => {
                one_positional("key", key.clone(), value.clone(), &[], validator)
            }
            Self::ProbeCompare { value, .. } => one_positional(
                "expected",
                value.clone(),
                TypeKind::Predicate,
                &[],
                validator,
            ),
            Self::DiagnosticsHasError => empty(TypeKind::Predicate, &[], validator),
            Self::RagContextPackSummary => empty(TypeKind::String, &[], validator),
            Self::Context => context_schema(receiver, false, validator)?,
            Self::WithContext => context_schema(receiver, true, validator)?,
        })
    }
}

impl CapacityMethodId {
    pub(crate) fn signature_schema(&self) -> CallableSignatureSchema {
        let result = self.result_type();
        let validator = CallableValidator::Capacity(self.clone());
        match (self.method().as_str(), self.arity()) {
            ("with_capacity", 1) => schema(
                vec![required(0, "capacity", TypeKind::USize)],
                result,
                &[],
                closed(),
                validator,
            ),
            ("trim" | "to_string" | "pop" | "pop_front" | "shrink", 0) => {
                empty(result, &[], validator)
            }
            ("push", 1) => {
                let TypeKind::Vec(item) = self.receiver() else {
                    unreachable!("CapacityMethodId retains Vec as its push receiver")
                };
                schema(
                    vec![required(0, "value", item.as_ref().clone())],
                    result,
                    &[],
                    closed(),
                    validator,
                )
            }
            ("reserve", 1) => schema(
                vec![parameter(
                    0,
                    Some("additional"),
                    CallableParameterAdmission::checked(TypeKind::USize),
                    CallableParameterPassing::PositionalOrNamed,
                    CallableParameterPresence::Required,
                )],
                result,
                &[],
                closed(),
                validator,
            ),
            ("shrink_to", 1) => schema(
                vec![required(0, "min_capacity", TypeKind::USize)],
                result,
                &[],
                closed(),
                validator,
            ),
            _ => unreachable!("CapacityMethodId constructors retain a supported arity"),
        }
    }
}

impl StageMethodId {
    pub(crate) fn signature_schema(self, receiver: &TypeKind) -> CallableSignatureSchema {
        let validator = CallableValidator::Stage(self);
        match self {
            Self::Acquire => {
                let TypeKind::StageApi(character) = receiver else {
                    unreachable!("Stage acquire retains an exact StageApi receiver")
                };
                schema(
                    vec![parameter(
                        0,
                        Some("scope"),
                        CallableParameterAdmission::checked(named("PresentationLifetime")),
                        CallableParameterPassing::PositionalOrNamed,
                        CallableParameterPresence::Required,
                    )],
                    TypeKind::StageActorHandle(crate::types::StageActorHandleType::Exact(
                        character.clone(),
                    )),
                    &[],
                    closed(),
                    validator,
                )
            }
            Self::Look => {
                let TypeKind::StageActorHandle(crate::types::StageActorHandleType::Exact(
                    character,
                )) = receiver
                else {
                    unreachable!("Stage look retains an exact StageActorHandle receiver")
                };
                schema(
                    vec![
                        parameter(
                            0,
                            Some("look"),
                            CallableParameterAdmission::checked(TypeKind::character_look(
                                character.clone(),
                            )),
                            CallableParameterPassing::PositionalOrNamed,
                            CallableParameterPresence::Required,
                        ),
                        parameter(
                            1,
                            Some("crossfade"),
                            CallableParameterAdmission::checked(TypeKind::Duration),
                            CallableParameterPassing::PositionalOrNamed,
                            CallableParameterPresence::Optional,
                        ),
                    ],
                    TypeKind::CueHandle,
                    &[],
                    closed(),
                    validator,
                )
            }
        }
    }
}

impl LineContextMethodId {
    pub(crate) fn signature_schema(self) -> CallableSignatureSchema {
        empty(
            TypeKind::VoiceHandle,
            &[EffectId::DIALOGUE_VOICE_LABEL],
            CallableValidator::LineContext(self),
        )
    }
}

impl LineScheduleCallableId {
    pub fn signature_schema(self) -> CallableSignatureSchema {
        let callback = TypeKind::function_with_effects(
            std::iter::empty(),
            TypeKind::CueHandle,
            EffectRow::closed(EffectSet::new()),
        );
        let groups = vec![
            CallableParameterGroup::try_new(
                crate::callable::CallableGroupIndex::ZERO,
                CallableGroupKind::Initial,
                vec![required_positional(0, "anchor", TypeKind::Duration)],
                &PRODUCTION_CALLABLE_LIMITS,
            )
            .expect("line schedule anchor group is canonical"),
            CallableParameterGroup::try_new(
                crate::callable::CallableGroupIndex::try_from_usize(1)
                    .expect("line schedule callback group is representable"),
                CallableGroupKind::Curried,
                vec![required_positional(0, "callback", callback)],
                &PRODUCTION_CALLABLE_LIMITS,
            )
            .expect("line schedule callback group is canonical"),
        ];
        CallableSignatureSchema::try_new(
            groups,
            TypeKind::CueHandle,
            CallableEffectSchema::fixed(EffectRow::closed(
                [EffectId::dialogue_schedule()].into_iter().collect(),
            )),
            closed(),
            CallableValidator::Ordinary,
            CallableGenericParameterIssuer::empty(),
            &PRODUCTION_CALLABLE_LIMITS,
        )
        .expect("line schedule schema is canonical")
    }
}

impl PromotionCallableId {
    pub(crate) fn signature_schema(self) -> CallableSignatureSchema {
        let result = match self {
            Self::Promote | Self::PromoteUnchecked => named("Promoted"),
            Self::Assume => TypeKind::Unit,
        };
        variadic_unchecked(result, CallableValidator::Promotion(self), &[])
    }
}

fn sequence_item(receiver: &TypeKind) -> Option<TypeKind> {
    match receiver {
        TypeKind::Vec(item)
        | TypeKind::Seq(item)
        | TypeKind::Slice(item)
        | TypeKind::Array { item, .. } => Some(item.as_ref().clone()),
        TypeKind::String => Some(TypeKind::TextCluster),
        _ => None,
    }
}

fn context_result(receiver: &TypeKind) -> Option<TypeKind> {
    match receiver {
        TypeKind::Need(_) => Some(receiver.clone()),
        TypeKind::Option(inner) => Some(TypeKind::Result {
            ok: inner.clone(),
            error: Box::new(standard_arc_error_type()),
        }),
        TypeKind::Result { ok, .. } => Some(TypeKind::Result {
            ok: ok.clone(),
            error: Box::new(standard_arc_error_type()),
        }),
        _ => None,
    }
}

fn context_schema(
    receiver: &TypeKind,
    lazy: bool,
    validator: CallableValidator,
) -> Option<CallableSignatureSchema> {
    let result = context_result(receiver)?;
    let message_type = context_message_type();
    let (name, input) = if lazy {
        (
            "callback",
            TypeKind::function(std::iter::empty(), message_type),
        )
    } else {
        ("message", message_type)
    };
    Some(schema(
        vec![required(0, name, input)],
        result,
        &[],
        closed(),
        validator,
    ))
}

fn context_message_type() -> TypeKind {
    TypeKind::Choice(vec![TypeKind::String, standard_dialogue_content_type()])
}

/// Projects the presentation owner's closed source-constructor schema into
/// the common callable schema.  Constructor identity, parameter order,
/// passing, presence, and static value domains are read from the owner row;
/// this layer only translates those typed descriptors into sema types.
pub(crate) fn fx_callable_schema(
    constructor: FxSourceConstructor,
    scalars: &RegisteredCompileTimeScalarTypes,
    nominal_catalog: &AcceptedNominalCatalog,
) -> Result<CallableSignatureSchema, CallableSchemaError> {
    let parameters = constructor
        .parameter_schema()
        .iter()
        .enumerate()
        .map(|(index, spec)| {
            let index = CallableParameterIndex::try_from_usize(index).map_err(|_| {
                CallableSchemaError::ParameterLimit {
                    actual: constructor.parameter_schema().len(),
                    limit: PRODUCTION_CALLABLE_LIMITS.max_parameters_per_callable(),
                }
            })?;
            let ty = match spec.value_type() {
                FxSourceParameterType::Static(value_type) => {
                    fx_static_type(value_type, scalars, nominal_catalog)?
                }
                FxSourceParameterType::Fx => TypeKind::CompileTimeFx(CompileTimeFxType::Abstract),
                FxSourceParameterType::FxList => TypeKind::Vec(Box::new(TypeKind::CompileTimeFx(
                    CompileTimeFxType::Abstract,
                ))),
                FxSourceParameterType::TransitionKind => fx_static_type(
                    FxStaticType::Selector(FxSelectorDomain::TransitionKind),
                    scalars,
                    nominal_catalog,
                )?,
                FxSourceParameterType::TransitionEasing => fx_static_type(
                    FxStaticType::Selector(FxSelectorDomain::TransitionEasing),
                    scalars,
                    nominal_catalog,
                )?,
            };
            let passing = match spec.passing() {
                FxSourceParameterPassing::PositionalOnly => {
                    CallableParameterPassing::PositionalOnly
                }
                FxSourceParameterPassing::NamedOnly => CallableParameterPassing::NamedOnly,
            };
            let presence = match spec.presence() {
                arcweft_presentation::fx::FxSourceParameterPresence::Required => {
                    CallableParameterPresence::Required
                }
                arcweft_presentation::fx::FxSourceParameterPresence::Optional => {
                    CallableParameterPresence::Optional
                }
            };
            CallableParameter::try_new(
                index,
                Some(
                    arcweft_lang_syntax::name::CallArgumentName::try_new(spec.source_name())
                        .map_err(|_| CallableSchemaError::MissingParameterName {
                            group: crate::callable::CallableGroupIndex::ZERO,
                            parameter: index,
                        })?,
                ),
                CallableParameterAdmission::checked(ty),
                passing,
                presence,
                None,
                None,
            )
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok(schema(
        parameters,
        TypeKind::CompileTimeFx(CompileTimeFxType::Constructor(constructor)),
        &[],
        closed(),
        CallableValidator::FxConstructor(constructor),
    ))
}

fn fx_static_type(
    static_type: FxStaticType,
    scalars: &RegisteredCompileTimeScalarTypes,
    nominal_catalog: &AcceptedNominalCatalog,
) -> Result<TypeKind, CallableSchemaError> {
    let scalar = |role| scalars.type_for(role).clone();
    let invalid = || CallableSchemaError::FamilyInvariant {
        family: crate::callable::CallableFamily::FxConstructor,
        code: crate::callable::CallableFamilyInvariantCode::InvalidParameterType,
    };
    Ok(match static_type {
        FxStaticType::Runtime(runtime) => match runtime {
            FxRuntimeType::Bool => scalar(CompileTimeScalarTypeRoleId::Bool),
            FxRuntimeType::I32 => scalar(CompileTimeScalarTypeRoleId::Int),
            FxRuntimeType::U32 => TypeKind::U32,
            FxRuntimeType::F32 => TypeKind::F32,
            FxRuntimeType::Length => scalar(CompileTimeScalarTypeRoleId::Length),
            FxRuntimeType::Angle => scalar(CompileTimeScalarTypeRoleId::Angle),
            FxRuntimeType::Seconds => scalar(CompileTimeScalarTypeRoleId::Duration),
            FxRuntimeType::Color => scalar(CompileTimeScalarTypeRoleId::Color),
            FxRuntimeType::Vec2 => {
                TypeKind::FixedVector(FixedVectorType::new(VectorDimensions::Two, TypeKind::F32))
            }
            FxRuntimeType::Transform2D => {
                let id = standard_nominal_id("Transform2D");
                let record = nominal_catalog
                    .exact(id.canonical_path())
                    .ok_or_else(invalid)?;
                record.try_instantiate([]).map_err(|_| invalid())?
            }
        },
        FxStaticType::Resource => scalar(CompileTimeScalarTypeRoleId::PublicId),
        FxStaticType::Selector(_) | FxStaticType::FontFamily => {
            scalar(CompileTimeScalarTypeRoleId::Text)
        }
        FxStaticType::Target => TypeKind::CompileTimeEnum(crate::types::CompileTimeEnumType::any(
            FxEnumDomain::Target.domain_id(),
        )),
        FxStaticType::Phase => TypeKind::CompileTimeEnum(crate::types::CompileTimeEnumType::any(
            FxEnumDomain::Phase.domain_id(),
        )),
        FxStaticType::ShaderStage => TypeKind::CompileTimeEnum(
            crate::types::CompileTimeEnumType::any(FxEnumDomain::ShaderStage.domain_id()),
        ),
        FxStaticType::UniformRecord => return Err(invalid()),
    })
}

impl AgentIntrinsicSignatureId {
    #[allow(
        clippy::too_many_lines,
        reason = "the exhaustive closed intrinsic table keeps ID and schema parity auditable"
    )]
    pub fn signature_schema(self) -> CallableSignatureSchema {
        let validator = CallableValidator::Agent(self);
        match self {
            Self::Observe => empty(
                agent_result(TypeKind::Observation),
                &["agent.observe"],
                validator,
            ),
            Self::Expect | Self::Deny => schema(
                vec![
                    required(0, "condition", TypeKind::Bool),
                    optional(1, "message", TypeKind::String),
                ],
                TypeKind::Unit,
                &[],
                closed(),
                validator,
            ),
            Self::Checkpoint => one_positional(
                "name",
                TypeKind::String,
                TypeKind::Unit,
                &["debug.record"],
                validator,
            ),
            Self::Note => one_positional(
                "text",
                TypeKind::String,
                TypeKind::Unit,
                &["debug.record"],
                validator,
            ),
            Self::Attach => one_positional(
                "resource",
                TypeKind::Choice(vec![TypeKind::CaptureRef, TypeKind::AgentResource]),
                TypeKind::Unit,
                &["debug.record"],
                validator,
            ),
            Self::ChoiceAction => one_positional(
                "choice",
                TypeKind::entity_ref(EntityKind::ChoiceOption),
                TypeKind::ActionTarget,
                &[],
                validator,
            ),
            Self::Viewport => empty(TypeKind::CaptureTarget, &[], validator),
            Self::Layer => one_positional(
                "target",
                TypeKind::entity_ref(EntityKind::Layer),
                TypeKind::CaptureTarget,
                &[],
                validator,
            ),
            Self::Object => one_positional(
                "id",
                TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::ObservedObjectId),
                TypeKind::CaptureTarget,
                &[],
                validator,
            ),
            Self::Capture => schema(
                vec![
                    required(0, "target", TypeKind::CaptureTarget),
                    optional_named(1, "name", TypeKind::String),
                    optional_named(
                        2,
                        "format",
                        TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::CaptureFormat),
                    ),
                    optional_named(
                        3,
                        "kind",
                        TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::CaptureKind),
                    ),
                ],
                agent_result(TypeKind::CaptureRef),
                &["agent.capture"],
                closed(),
                validator,
            ),
            Self::ReadResource => schema(
                vec![required(0, "uri", TypeKind::String)],
                agent_result(TypeKind::AgentResource),
                &["agent.resource.read"],
                closed(),
                validator,
            ),
            Self::EntityMeta => schema(
                vec![parameter(
                    0,
                    Some("entity"),
                    CallableParameterAdmission::unchecked_supply(),
                    CallableParameterPassing::PositionalOnly,
                    CallableParameterPresence::Required,
                )],
                agent_result(TypeKind::AgentEntityMetadata),
                &["debug.read"],
                closed(),
                validator,
            ),
            Self::ProjectNeighbors => schema(
                vec![
                    unchecked(0, "root", CallableParameterPresence::Required),
                    optional_named(1, "depth", TypeKind::U32),
                ],
                agent_result(TypeKind::AgentProjectGraphNeighborhood),
                &["debug.read"],
                closed(),
                validator,
            ),
            Self::Signal => probe_schema(EntityKind::Signal, validator),
            Self::Metric => probe_schema(EntityKind::Metric, validator),
            Self::StatePath => one_positional(
                "path",
                TypeKind::String,
                TypeKind::DebugStatePath,
                &[],
                validator,
            ),
            Self::ObservationPath => one_positional(
                "path",
                TypeKind::String,
                TypeKind::ObservationFieldPath,
                &[],
                validator,
            ),
            Self::State => schema(
                vec![required_choice(
                    0,
                    "path",
                    TypeKind::String,
                    TypeKind::DebugStatePath,
                )],
                TypeKind::Probe(Box::new(TypeKind::AgentValue)),
                &["debug.read"],
                closed(),
                validator,
            ),
            Self::Observation => schema(
                vec![required_choice(
                    0,
                    "path",
                    TypeKind::String,
                    TypeKind::ObservationFieldPath,
                )],
                TypeKind::Probe(Box::new(TypeKind::AgentValue)),
                &["agent.observe"],
                closed(),
                validator,
            ),
            Self::Diagnostics => empty(
                TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::Diagnostics),
                &["agent.observe"],
                validator,
            ),
            Self::Exists => one_positional_with_issuer(
                "probe",
                TypeKind::Probe(Box::new(generic(
                    GenericParameterOwnerId::LanguageIntrinsic(
                        LanguageIntrinsicGenericOwner::FxExists,
                    ),
                    0,
                ))),
                TypeKind::Predicate,
                &[],
                validator,
                CallableGenericParameterIssuer::language_intrinsic(
                    LanguageIntrinsicGenericOwner::FxExists,
                    1,
                    0,
                )
                .expect("exists issuer"),
            ),
            Self::ActionEnabled => one_positional(
                "target",
                TypeKind::ActionTarget,
                TypeKind::Predicate,
                &[],
                validator,
            ),
            Self::All | Self::Any => schema(
                vec![parameter(
                    0,
                    Some("predicates"),
                    CallableParameterAdmission::checked(TypeKind::Predicate),
                    CallableParameterPassing::RestPositional,
                    CallableParameterPresence::Required,
                )],
                TypeKind::Predicate,
                &[],
                closed(),
                validator,
            ),
            Self::Not => one_positional(
                "predicate",
                TypeKind::Predicate,
                TypeKind::Predicate,
                &[],
                validator,
            ),
            Self::Wait => schema(
                vec![
                    required_positional(0, "predicate", TypeKind::Predicate),
                    required(1, "timeout", TypeKind::Duration),
                    optional_named(2, "stable_frames", TypeKind::U32),
                    optional_named(3, "poll_frames", TypeKind::U32),
                ],
                TypeKind::Result {
                    ok: Box::new(TypeKind::Observation),
                    error: Box::new(TypeKind::AgentBuiltin(
                        crate::types::AgentBuiltinType::WaitError,
                    )),
                },
                &["agent.wait", "agent.observe"],
                closed(),
                validator,
            ),
            Self::AdvanceText => empty(
                agent_result(TypeKind::ActionResult),
                &["agent.act.semantic"],
                validator,
            ),
            Self::ViewportPoint => schema(
                vec![
                    required(0, "x", TypeKind::U32),
                    required(1, "y", TypeKind::U32),
                ],
                TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::ViewportPoint),
                &[],
                closed(),
                validator,
            ),
            Self::PointerClick => schema(
                vec![
                    required(
                        0,
                        "point",
                        TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::ViewportPoint),
                    ),
                    defaulted_named(
                        1,
                        "button",
                        TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::PointerButton),
                    ),
                ],
                agent_result(TypeKind::ActionResult),
                &["agent.act.physical"],
                closed(),
                validator,
            ),
            Self::Invoke => schema(
                vec![
                    unchecked(0, "target", CallableParameterPresence::Required),
                    required(1, "action", TypeKind::ActionName),
                    parameter(
                        2,
                        Some("args"),
                        CallableParameterAdmission::checked(TypeKind::Map {
                            kind: MapKind::Sorted,
                            key: Box::new(TypeKind::String),
                            value: Box::new(TypeKind::AgentValue),
                        }),
                        CallableParameterPassing::PositionalOrNamed,
                        CallableParameterPresence::Optional,
                    ),
                ],
                agent_result(TypeKind::ActionResult),
                &["agent.act.semantic"],
                closed(),
                validator,
            ),
            Self::RagQuery => schema(
                vec![
                    required_positional(0, "query", TypeKind::String),
                    optional_named_unchecked(1, "roots"),
                    optional_named(2, "graph_depth", TypeKind::U32),
                    optional_named(3, "limit", TypeKind::USize),
                ],
                TypeKind::Result {
                    ok: Box::new(TypeKind::RagContextPack),
                    error: Box::new(TypeKind::AgentBuiltin(
                        crate::types::AgentBuiltinType::RagError,
                    )),
                },
                &["rag.query"],
                closed(),
                validator,
            ),
        }
    }
}

#[allow(
    clippy::unnecessary_wraps,
    reason = "all callable families share a fallible schema construction boundary"
)]
pub(in crate::callable) fn presentation_schema(
    id: PresentationCallableId,
    owner: Option<&ResolvedCharacterOwner>,
    environment: Option<&RegisteredTypeCheckEnv>,
) -> Result<CallableSignatureSchema, CallableSchemaError> {
    let validator = CallableValidator::Presentation(id);
    let result = presentation_result(id);
    let character = owner.and_then(|owner| {
        let character = owner.character();
        environment
            .and_then(|environment| environment.character_manifest(character))
            .filter(|manifest| !manifest.looks().is_empty())
            .map(|_| character)
    });
    let (parameters, policy) = match id {
        PresentationCallableId::View
        | PresentationCallableId::Menu
        | PresentationCallableId::Overlay
        | PresentationCallableId::Mount => (view_parameters(id), open_named_supply()),
        PresentationCallableId::Background => (
            vec![
                required_positional(0, "asset", TypeKind::entity_ref(EntityKind::Asset))
                    .with_consumer(CallableParameterConsumer::Presentation(
                        PresentationArgumentRole::Asset,
                    )),
                optional_presentation_named(id, 1, "target"),
                optional_presentation_named(id, 2, "slot"),
                optional_presentation_named(id, 3, "scope"),
                optional_presentation_named(id, 4, "fade"),
                optional_presentation_named(id, 5, "fit"),
                optional_presentation_named(id, 6, "opacity"),
            ],
            open_named_supply(),
        ),
        PresentationCallableId::Image => (image_parameters(), open_named_supply()),
        PresentationCallableId::PlayerViewport => (
            vec![
                optional_presentation_named(id, 0, "width"),
                optional_presentation_named(id, 1, "height"),
                optional_presentation_named(id, 2, "fit"),
            ],
            open_named_supply(),
        ),
        PresentationCallableId::Show => (
            character_parameters(id, character, true),
            open_named_supply(),
        ),
        PresentationCallableId::RefShow | PresentationCallableId::Hide => (
            character_parameters(id, character, false),
            open_named_supply(),
        ),
        PresentationCallableId::RefBackground | PresentationCallableId::ClearBackground => {
            (background_reference_parameters(id), open_named_supply())
        }
    };
    let reserved_open_names = match (id, character.is_some()) {
        (PresentationCallableId::Show, true) => Vec::new(),
        (PresentationCallableId::Show, false)
        | (PresentationCallableId::RefShow, _)
        | (PresentationCallableId::Hide, _) => {
            vec![CallableName::try_new("look").expect("presentation reserved name is valid")]
        }
        _ => Vec::new(),
    };
    schema(parameters, result, &[], policy, validator)
        .try_with_reserved_open_names(reserved_open_names, &PRODUCTION_CALLABLE_LIMITS)
}

fn presentation_result(id: PresentationCallableId) -> TypeKind {
    use arcweft_interaction_model::presentation::PresentationCallableResult;
    match id.result() {
        PresentationCallableResult::Handle(resource) => {
            TypeKind::presentation_handle(TypeKind::PresentationResource(resource))
        }
        PresentationCallableResult::SlotRef(resource) => {
            TypeKind::SlotRef(Box::new(TypeKind::PresentationResource(resource)))
        }
        PresentationCallableResult::Removed(resource) => {
            TypeKind::Option(Box::new(TypeKind::PresentationResource(resource)))
        }
    }
}

fn image_parameters() -> Vec<CallableParameter> {
    let id = PresentationCallableId::Image;
    vec![
        parameter_with_consumer(
            0,
            Some("source"),
            CallableParameterAdmission::unchecked_supply(),
            CallableParameterPassing::PositionalOnly,
            CallableParameterPresence::Optional,
            CallableParameterConsumer::Presentation(PresentationArgumentRole::Source),
        ),
        optional_presentation_named(id, 1, "asset"),
        optional_presentation_named(id, 2, "lifetime"),
        optional_presentation_named(id, 3, "target"),
        optional_presentation_named(id, 4, "layer"),
        optional_presentation_named(id, 5, "depth"),
        optional_presentation_named(id, 6, "enabled"),
        optional_presentation_named(id, 7, "visible"),
        optional_presentation_named(id, 8, "id"),
        optional_presentation_named(id, 9, "action"),
        optional_presentation_named(id, 10, "actions"),
        optional_presentation_named(id, 11, "fit"),
        optional_presentation_named(id, 12, "opacity"),
        optional_presentation_named(id, 13, "x"),
        optional_presentation_named(id, 14, "y"),
        optional_presentation_named(id, 15, "width"),
        optional_presentation_named(id, 16, "height"),
        optional_presentation_named(id, 17, "focus"),
        optional_presentation_named(id, 18, "input_capture"),
        optional_presentation_named(id, 19, "owner"),
        optional_presentation_named(id, 20, "drop"),
        optional_presentation_named(id, 21, "alignment.x"),
        optional_presentation_named(id, 22, "alignment.y"),
        optional_presentation_named(id, 23, "playback.start"),
        optional_presentation_named(id, 24, "playback.paused_at"),
        optional_presentation_named(id, 25, "playback.local_time"),
        optional_presentation_named(id, 26, "playback.rate"),
        optional_presentation_named(id, 27, "transform.tx"),
        optional_presentation_named(id, 28, "transform.ty"),
        optional_presentation_named(id, 29, "transform.m11"),
        optional_presentation_named(id, 30, "transform.m12"),
        optional_presentation_named(id, 31, "transform.m21"),
        optional_presentation_named(id, 32, "transform.m22"),
        optional_presentation_named(id, 33, "proxy.id"),
        optional_presentation_named(id, 34, "proxy.type"),
        optional_presentation_named(id, 35, "proxy.role"),
        optional_presentation_named(id, 36, "proxy.layer"),
        optional_presentation_named(id, 37, "proxy.depth"),
        optional_presentation_named(id, 38, "proxy.hit_test"),
    ]
}

fn view_parameters(id: PresentationCallableId) -> Vec<CallableParameter> {
    vec![
        required_presentation(id, 0, "view"),
        optional_presentation_named(id, 1, "lifetime"),
        optional_presentation_named(id, 2, "target"),
        optional_presentation_named(id, 3, "layer"),
        optional_presentation_named(id, 4, "id"),
        optional_presentation_named(id, 5, "handle"),
        optional_presentation_named(id, 6, "key"),
        optional_presentation_named(id, 7, "mount"),
        optional_presentation_named(id, 8, "depth"),
        optional_presentation_named(id, 9, "visible"),
        optional_presentation_named(id, 10, "enabled"),
    ]
}

fn character_parameters(
    id: PresentationCallableId,
    character: Option<&CharacterId>,
    include_look: bool,
) -> Vec<CallableParameter> {
    let character = include_look.then_some(character).flatten();
    let mut parameters = vec![
        required(0, "character", TypeKind::entity_ref(EntityKind::Character)).with_consumer(
            CallableParameterConsumer::Presentation(PresentationArgumentRole::Character),
        ),
    ];
    if let Some(character) = character {
        parameters.push(parameter_with_consumer(
            1,
            Some("look"),
            CallableParameterAdmission::checked(TypeKind::character_look(character.clone())),
            CallableParameterPassing::PositionalOrNamed,
            CallableParameterPresence::Optional,
            CallableParameterConsumer::Presentation(PresentationArgumentRole::Look),
        ));
    }
    let offset = usize::from(character.is_some());
    parameters.extend([
        optional_presentation_named(id, 1 + offset, "target"),
        optional_presentation_named(id, 2 + offset, "slot"),
        optional_presentation_named(id, 3 + offset, "scope"),
    ]);
    parameters
}

fn background_reference_parameters(id: PresentationCallableId) -> Vec<CallableParameter> {
    vec![
        optional_presentation_named(id, 0, "target"),
        optional_presentation_named(id, 1, "slot"),
        optional_presentation_named(id, 2, "scope"),
    ]
}

fn probe_schema(kind: EntityKind, validator: CallableValidator) -> CallableSignatureSchema {
    let owner = match kind {
        EntityKind::Signal => LanguageIntrinsicGenericOwner::AgentSignal,
        EntityKind::Metric => LanguageIntrinsicGenericOwner::AgentMetric,
        _ => unreachable!("probe schemas are only published for signal and metric references"),
    };
    let value = TypeKind::generic_parameter(GenericTypeParameterId::new(
        GenericParameterOwnerId::LanguageIntrinsic(owner),
        0,
    ));
    let carrier = match kind {
        EntityKind::Signal => crate::env::nominal::standard_watch_type(value.clone()),
        EntityKind::Metric => value.clone(),
        _ => unreachable!("only Signal and Metric own probe schemas"),
    };
    schema_with_issuer(
        vec![required_positional(
            0,
            "entity",
            TypeKind::entity_ref_with_value(kind, carrier),
        )],
        TypeKind::Probe(Box::new(value)),
        &["agent.observe"],
        closed(),
        validator,
        CallableGenericParameterIssuer::language_intrinsic(owner, 1, 0).expect("probe issuer"),
    )
}

fn agent_result(ok: TypeKind) -> TypeKind {
    TypeKind::Result {
        ok: Box::new(ok),
        error: Box::new(standard_agent_error_type()),
    }
}

fn named(name: &str) -> TypeKind {
    TypeKind::Named(name.to_owned())
}

fn generic(owner: GenericParameterOwnerId, ordinal: u16) -> TypeKind {
    TypeKind::generic_parameter(GenericTypeParameterId::new(owner, ordinal))
}

fn homogeneous(
    arity: usize,
    input: &TypeKind,
    result: TypeKind,
    validator: CallableValidator,
) -> CallableSignatureSchema {
    let parameters = (0..arity)
        .map(|index| required_positional(index, &format!("arg{index}"), input.clone()))
        .collect();
    schema(parameters, result, &[], closed(), validator)
}

fn one_positional(
    name: &str,
    input: TypeKind,
    result: TypeKind,
    effects: &[&str],
    validator: CallableValidator,
) -> CallableSignatureSchema {
    schema(
        vec![required_positional(0, name, input)],
        result,
        effects,
        closed(),
        validator,
    )
}

fn one_positional_with_issuer(
    name: &str,
    input: TypeKind,
    result: TypeKind,
    effects: &[&str],
    validator: CallableValidator,
    issuer: CallableGenericParameterIssuer,
) -> CallableSignatureSchema {
    schema_with_issuer(
        vec![required_positional(0, name, input)],
        result,
        effects,
        closed(),
        validator,
        issuer,
    )
}

fn variadic_unchecked(
    result: TypeKind,
    validator: CallableValidator,
    effects: &[&str],
) -> CallableSignatureSchema {
    schema(
        vec![parameter(
            0,
            Some("args"),
            CallableParameterAdmission::unchecked_supply(),
            CallableParameterPassing::RestPositional,
            CallableParameterPresence::Optional,
        )],
        result,
        effects,
        CallableArgumentPolicy::new(
            UnknownNamedArgumentPolicy::OpenSupply,
            SpreadArgumentPolicy::Unchecked,
        ),
        validator,
    )
}

fn empty(
    result: TypeKind,
    effects: &[&str],
    validator: CallableValidator,
) -> CallableSignatureSchema {
    schema(Vec::new(), result, effects, closed(), validator)
}

fn schema(
    parameters: Vec<CallableParameter>,
    result: TypeKind,
    effects: &[&str],
    argument_policy: CallableArgumentPolicy,
    validator: CallableValidator,
) -> CallableSignatureSchema {
    schema_with_issuer(
        parameters,
        result,
        effects,
        argument_policy,
        validator,
        CallableGenericParameterIssuer::empty(),
    )
}

fn schema_with_issuer(
    parameters: Vec<CallableParameter>,
    result: TypeKind,
    effects: &[&str],
    argument_policy: CallableArgumentPolicy,
    validator: CallableValidator,
    generic_issuer: CallableGenericParameterIssuer,
) -> CallableSignatureSchema {
    let group = CallableParameterGroup::try_new(
        crate::callable::CallableGroupIndex::ZERO,
        CallableGroupKind::Initial,
        parameters,
        &PRODUCTION_CALLABLE_LIMITS,
    )
    .expect("family schema coordinates are contiguous");
    let effects = EffectSet::from_labels(effects).expect("family effect labels are canonical");
    CallableSignatureSchema::try_new(
        vec![group],
        result,
        CallableEffectSchema::fixed(EffectRow::closed(effects)),
        argument_policy,
        validator,
        generic_issuer,
        &PRODUCTION_CALLABLE_LIMITS,
    )
    .expect("family schema satisfies callable invariants")
}

fn required(index: usize, name: &str, ty: TypeKind) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::checked(ty),
        CallableParameterPassing::PositionalOrNamed,
        CallableParameterPresence::Required,
    )
}

fn required_positional(index: usize, name: &str, ty: TypeKind) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::checked(ty),
        CallableParameterPassing::PositionalOnly,
        CallableParameterPresence::Required,
    )
}

fn optional(index: usize, name: &str, ty: TypeKind) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::checked(ty),
        CallableParameterPassing::PositionalOrNamed,
        CallableParameterPresence::Optional,
    )
}

fn optional_named(index: usize, name: &str, ty: TypeKind) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::checked(ty),
        CallableParameterPassing::NamedOnly,
        CallableParameterPresence::Optional,
    )
}

fn optional_presentation_named(
    id: PresentationCallableId,
    index: usize,
    name: &str,
) -> CallableParameter {
    parameter_with_consumer(
        index,
        Some(name),
        presentation_parameter_type(id, name),
        CallableParameterPassing::NamedOnly,
        CallableParameterPresence::Optional,
        CallableParameterConsumer::Presentation(
            id.argument_role(name)
                .expect("presentation parameter has its owner-issued role"),
        ),
    )
}

fn required_presentation(
    id: PresentationCallableId,
    index: usize,
    name: &str,
) -> CallableParameter {
    parameter_with_consumer(
        index,
        Some(name),
        presentation_parameter_type(id, name),
        CallableParameterPassing::PositionalOrNamed,
        CallableParameterPresence::Required,
        CallableParameterConsumer::Presentation(
            id.argument_role(name)
                .expect("presentation parameter has its owner-issued role"),
        ),
    )
}

fn presentation_parameter_type(
    id: PresentationCallableId,
    name: &str,
) -> CallableParameterAdmission {
    let argument = id
        .argument_role(name)
        .expect("presentation schema parameter belongs to the callable argument catalog");
    match PresentationArgumentValuePolicy::for_role(argument) {
        PresentationArgumentValuePolicy::PublicIdReference(family, ty) => {
            CallableParameterAdmission::checked_with_rule(
                ty,
                super::CallableParameterValueRule::supply_public_id_reference(family),
            )
        }
        PresentationArgumentValuePolicy::Exact(ty)
        | PresentationArgumentValuePolicy::TokenScalar(ty) => {
            CallableParameterAdmission::checked(ty)
        }
        PresentationArgumentValuePolicy::Unchecked
        | PresentationArgumentValuePolicy::MetadataScalar => {
            CallableParameterAdmission::unchecked_supply()
        }
    }
}

fn optional_named_unchecked(index: usize, name: &str) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::unchecked_supply(),
        CallableParameterPassing::NamedOnly,
        CallableParameterPresence::Optional,
    )
}

fn defaulted_named(index: usize, name: &str, ty: TypeKind) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::checked(ty),
        CallableParameterPassing::NamedOnly,
        CallableParameterPresence::Defaulted,
    )
}

fn unchecked(index: usize, name: &str, presence: CallableParameterPresence) -> CallableParameter {
    parameter(
        index,
        Some(name),
        CallableParameterAdmission::unchecked_supply(),
        CallableParameterPassing::PositionalOrNamed,
        presence,
    )
}

fn required_choice(index: usize, name: &str, left: TypeKind, right: TypeKind) -> CallableParameter {
    required(index, name, TypeKind::Choice(vec![left, right]))
}

fn parameter(
    index: usize,
    name: Option<&str>,
    admission: CallableParameterAdmission,
    passing: CallableParameterPassing,
    presence: CallableParameterPresence,
) -> CallableParameter {
    let index = CallableParameterIndex::try_from_usize(index)
        .expect("family parameter index fits the production limit");
    let name = name.map(|name| {
        arcweft_lang_syntax::name::CallArgumentName::try_new(name)
            .expect("family parameter name is valid")
    });
    CallableParameter::try_new(index, name, admission, passing, presence, None, None)
        .expect("family parameter satisfies callable invariants")
}

fn parameter_with_consumer(
    index: usize,
    name: Option<&str>,
    admission: CallableParameterAdmission,
    passing: CallableParameterPassing,
    presence: CallableParameterPresence,
    consumer: CallableParameterConsumer,
) -> CallableParameter {
    parameter(index, name, admission, passing, presence).with_consumer(consumer)
}

const fn closed() -> CallableArgumentPolicy {
    CallableArgumentPolicy::new(
        UnknownNamedArgumentPolicy::Reject,
        SpreadArgumentPolicy::Reject,
    )
}

const fn open_named_supply() -> CallableArgumentPolicy {
    CallableArgumentPolicy::new(
        UnknownNamedArgumentPolicy::OpenSupply,
        SpreadArgumentPolicy::Reject,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::callable::{
        CallableGroupIndex, CallableLogLevel, CallableParameterCoordinate, CallableParameterIndex,
        CallableSchemaGenericRole, DropCallableId,
    };

    fn effect_coordinate(group: usize, parameter: usize) -> CallableParameterCoordinate {
        CallableParameterCoordinate::new(
            CallableGroupIndex::try_from_usize(group).unwrap(),
            CallableParameterIndex::try_from_usize(parameter).unwrap(),
        )
    }

    #[test]
    fn evaluated_effect_owner_maps_fixed_operands_without_parameter_names() {
        use crate::callable::schema::CallableEvaluatedEffectOperandRole::{
            Condition, Event, Message, Policy, Target, Value,
        };

        assert_eq!(
            CallableEvaluatedEffect::Log(CallableLogLevel::Info)
                .operand_role(effect_coordinate(0, 0)),
            Some(Message)
        );
        assert_eq!(
            CallableEvaluatedEffect::SignalWrite.operand_role(effect_coordinate(0, 0)),
            Some(Target)
        );
        assert_eq!(
            CallableEvaluatedEffect::MetricWrite.operand_role(effect_coordinate(0, 1)),
            Some(Value)
        );
        assert_eq!(
            CallableEvaluatedEffect::EmitEvent.operand_role(effect_coordinate(0, 0)),
            Some(Event)
        );
        assert_eq!(
            CallableEvaluatedEffect::Ensure.operand_role(effect_coordinate(0, 0)),
            Some(Condition)
        );
        assert_eq!(
            CallableEvaluatedEffect::Drop(DropCallableId::DropWithPolicy)
                .operand_role(effect_coordinate(0, 0)),
            Some(Policy)
        );
        assert_eq!(
            CallableEvaluatedEffect::Drop(DropCallableId::DropWithPolicy)
                .operand_role(effect_coordinate(1, 0)),
            Some(Target)
        );
        assert_eq!(
            CallableEvaluatedEffect::Drop(DropCallableId::OnDrop)
                .operand_role(effect_coordinate(1, 0)),
            None
        );
        assert!(CallableEvaluatedEffect::EmitEvent.accepts_open_fields());
        assert!(!CallableEvaluatedEffect::Ensure.accepts_open_fields());
    }

    #[test]
    fn presentation_schemas_retain_typed_argument_roles_for_every_callable() {
        for id in PresentationCallableId::ALL {
            let schema = presentation_schema(id, None, None).expect("presentation schema");
            for parameter in schema.groups()[0].parameters() {
                assert!(
                    matches!(
                        parameter.consumer(),
                        CallableParameterConsumer::Presentation(_)
                    ),
                    "{id:?}: {parameter:?}"
                );
            }
            let foreign = CallableSignatureSchema::try_new(
                schema.groups().to_vec(),
                TypeKind::Unit,
                CallableEffectSchema::fixed(EffectRow::closed(EffectSet::new())),
                open_named_supply(),
                CallableValidator::Ordinary,
                CallableGenericParameterIssuer::empty(),
                &PRODUCTION_CALLABLE_LIMITS,
            );
            assert!(matches!(
                foreign,
                Err(CallableSchemaError::InvalidParameterConsumer { .. })
            ));
        }
        assert_eq!(
            PresentationCallableId::Background.argument_role("target"),
            Some(PresentationArgumentRole::TargetEntity)
        );
        assert_eq!(
            PresentationCallableId::Image.argument_role("target"),
            Some(PresentationArgumentRole::TargetPublicId)
        );
        assert_eq!(
            PresentationCallableId::Image.argument_role("param.role"),
            Some(PresentationArgumentRole::Parameter)
        );
        assert_eq!(
            PresentationCallableId::Image.argument_role("proxy.param.role"),
            Some(PresentationArgumentRole::ProxyParameter)
        );
    }

    #[test]
    fn presentation_slot_removals_publish_structural_optional_surface_values() {
        for (remove, surface) in [
            (
                PresentationCallableId::ClearBackground,
                arcweft_interaction_model::presentation::PresentationResourceKind::Background,
            ),
            (
                PresentationCallableId::Hide,
                arcweft_interaction_model::presentation::PresentationResourceKind::Character,
            ),
        ] {
            let removed = presentation_schema(remove, None, None).expect("slot removal schema");
            let expected = TypeKind::Option(Box::new(TypeKind::PresentationResource(surface)));
            assert_eq!(removed.value_type(), Some(&expected));
        }
    }

    #[test]
    fn character_any_reserves_look_without_closing_other_open_names() {
        let show = presentation_schema(PresentationCallableId::Show, None, None)
            .expect("Character-Any Show schema");
        let [group] = show.groups() else {
            panic!("Show schema must have one parameter group")
        };
        assert_eq!(
            group
                .parameters()
                .iter()
                .map(|parameter| parameter
                    .name()
                    .map(arcweft_lang_syntax::name::CallArgumentName::as_str))
                .collect::<Vec<_>>(),
            vec![
                Some("character"),
                Some("target"),
                Some("slot"),
                Some("scope")
            ]
        );
        let look = CallableName::try_new("look").expect("look name");
        let look_argument =
            arcweft_lang_syntax::name::CallArgumentName::try_new("look").expect("look argument");
        let custom =
            arcweft_lang_syntax::name::CallArgumentName::try_new("custom").expect("custom name");
        assert_eq!(show.reserved_open_names(), std::slice::from_ref(&look));
        assert!(!show.allows_open_name(&look_argument));
        assert!(show.allows_open_name(&custom));

        let hide = presentation_schema(PresentationCallableId::Hide, None, None)
            .expect("Character-Any Hide schema");
        assert!(!hide.allows_open_name(&look_argument));
    }

    #[test]
    fn reserved_open_names_validate_policy_collisions_and_duplicates() {
        let schema = presentation_schema(PresentationCallableId::Show, None, None)
            .expect("Character-Any Show schema");
        let look = CallableName::try_new("look").expect("look name");
        let duplicate = schema.clone().try_with_reserved_open_names(
            vec![look.clone(), look.clone()],
            &PRODUCTION_CALLABLE_LIMITS,
        );
        assert!(matches!(
            duplicate,
            Err(CallableSchemaError::DuplicateReservedOpenName { .. })
        ));

        let collision = schema.clone().try_with_reserved_open_names(
            vec![CallableName::try_new("character").expect("parameter name")],
            &PRODUCTION_CALLABLE_LIMITS,
        );
        assert!(matches!(
            collision,
            Err(CallableSchemaError::ReservedOpenNameParameterCollision { .. })
        ));

        let closed = OptionConstructorKind::Some
            .signature_schema()
            .try_with_reserved_open_names(vec![look], &PRODUCTION_CALLABLE_LIMITS);
        assert!(matches!(
            closed,
            Err(CallableSchemaError::ReservedOpenNamesRequireOpenPolicy)
        ));
    }

    #[test]
    fn event_emit_builtin_owns_its_evaluated_effect_disposition() {
        let schema = BuiltinCallableId::Capability(CapabilityCallableId::EventEmit)
            .closed_signature_schema()
            .expect("closed event builtin schema");
        assert_eq!(
            schema.evaluated_effect(),
            Some(CallableEvaluatedEffect::EmitEvent)
        );
    }

    #[test]
    fn reduction_has_no_schema_without_an_accepted_catalog_join() {
        assert!(
            BuiltinCallableId::Reduction(ReductionConstructorKind::Unchanged)
                .closed_signature_schema()
                .is_none()
        );
    }

    #[test]
    fn reduction_schema_uses_the_accepted_nominal_issuer() {
        let environment = crate::env::TypeCheckEnv::standard();
        let schema = ReductionConstructorKind::Unchanged
            .accepted_signature_schema(environment.nominal_catalog())
            .expect("standard Reduction catalog row");
        assert_eq!(
            schema
                .generic_inventory()
                .types()
                .iter()
                .filter(|entry| entry.role() == CallableSchemaGenericRole::Candidate)
                .count(),
            1,
        );
        let [parameter] = schema.groups()[0].parameters() else {
            panic!("Reduction.unchanged must accept one state borrow")
        };
        let TypeKind::BorrowRef {
            kind: BorrowKind::Shared,
            lifetime: None,
            inner,
        } = parameter
            .declared_type()
            .expect("Reduction state parameter is checked")
        else {
            panic!("Reduction.unchanged must accept an elided shared state borrow")
        };
        assert!(matches!(inner.as_ref(), TypeKind::GenericParam(_)));
        let TypeKind::AcceptedNominal(reduction) = schema
            .value_type()
            .expect("Reduction.unchanged publishes a value result")
        else {
            panic!("Reduction.unchanged must return the accepted Reduction owner")
        };
        assert_eq!(reduction.arguments(), [inner.as_ref().clone()]);
    }

    #[test]
    fn result_and_option_context_methods_accept_string_or_content_messages() {
        let result_receiver = TypeKind::Result {
            ok: Box::new(TypeKind::String),
            error: Box::new(TypeKind::I64),
        };
        let option_receiver = TypeKind::Option(Box::new(TypeKind::String));
        let expected_result = TypeKind::Result {
            ok: Box::new(TypeKind::String),
            error: Box::new(standard_arc_error_type()),
        };

        for receiver in [&result_receiver, &option_receiver] {
            for (method, input, parameter_name) in [
                (DomainMethodId::Context, context_message_type(), "message"),
                (
                    DomainMethodId::WithContext,
                    TypeKind::function(std::iter::empty(), context_message_type()),
                    "callback",
                ),
            ] {
                let schema = method
                    .signature_schema(receiver)
                    .expect("context method applies to Result and Option");
                assert_eq!(schema.value_type(), Some(&expected_result));
                assert_eq!(
                    schema.argument_policy(),
                    CallableArgumentPolicy::new(
                        UnknownNamedArgumentPolicy::Reject,
                        SpreadArgumentPolicy::Reject,
                    ),
                );
                let [group] = schema.groups() else {
                    panic!("context method has one closed argument group")
                };
                let [parameter] = group.parameters() else {
                    panic!("context method has one required argument")
                };
                assert_eq!(
                    parameter
                        .name()
                        .map(arcweft_lang_syntax::name::CallArgumentName::as_str),
                    Some(parameter_name)
                );
                match parameter.declared_type() {
                    Some(TypeKind::Function {
                        params,
                        return_type,
                        ..
                    }) if parameter_name == "callback" => {
                        assert!(params.is_empty());
                        assert_eq!(return_type.as_ref(), &context_message_type());
                    }
                    declared => assert_eq!(declared, Some(&input)),
                }
                assert_eq!(
                    parameter.passing(),
                    CallableParameterPassing::PositionalOrNamed
                );
                assert_eq!(parameter.presence(), CallableParameterPresence::Required);
            }
        }
    }

    #[test]
    fn signal_and_metric_schemas_share_their_exact_payload_parameter() {
        for (intrinsic, kind, owner) in [
            (
                AgentIntrinsicSignatureId::Signal,
                EntityKind::Signal,
                LanguageIntrinsicGenericOwner::AgentSignal,
            ),
            (
                AgentIntrinsicSignatureId::Metric,
                EntityKind::Metric,
                LanguageIntrinsicGenericOwner::AgentMetric,
            ),
        ] {
            let schema = intrinsic.signature_schema();
            let [group] = schema.groups() else {
                panic!("probe schema must have one parameter group")
            };
            let [parameter] = group.parameters() else {
                panic!("probe schema must have one parameter")
            };
            let Some(TypeKind::Ref(entity)) = parameter.declared_type() else {
                panic!("probe schema must accept one typed entity reference")
            };
            assert_eq!(entity.kind(), &kind);
            match kind {
                EntityKind::Signal => {
                    let Some(TypeKind::AcceptedNominal(carrier)) = entity.value() else {
                        panic!("Signal schema must retain the accepted Watch carrier")
                    };
                    assert_eq!(carrier.declaration(), &standard_nominal_id("Watch"));
                    assert_eq!(carrier.arguments().len(), 1);
                }
                EntityKind::Metric => assert_eq!(entity.value(), entity.observable_payload()),
                _ => unreachable!("the source table contains only observable entity families"),
            }
            let Some(TypeKind::GenericParam(crate::types::GenericTypeReference::Free(parameter))) =
                entity.observable_payload()
            else {
                panic!("probe entity reference must retain its payload parameter")
            };
            assert_eq!(
                parameter.owner(),
                &GenericParameterOwnerId::LanguageIntrinsic(owner)
            );
            assert_eq!(parameter.ordinal(), 0);
            assert_eq!(
                schema.value_type(),
                Some(&TypeKind::Probe(Box::new(TypeKind::generic_parameter(
                    parameter.clone(),
                ))))
            );
        }
    }

    #[test]
    fn constructors_are_context_free_generic_schemas() {
        let option = OptionConstructorKind::Some.signature_schema();
        let TypeKind::Option(item) = option.value_type().expect("Some publishes a value result")
        else {
            panic!("Some must publish an Option result")
        };
        let TypeKind::GenericParam(crate::types::GenericTypeReference::Free(option_item)) =
            item.as_ref()
        else {
            panic!("Some must publish a generic item")
        };
        assert_eq!(
            option_item.owner(),
            &GenericParameterOwnerId::LanguageIntrinsic(
                LanguageIntrinsicGenericOwner::OptionConstructor
            )
        );
        assert_eq!(option_item.ordinal(), 0);
        assert_eq!(
            option.groups()[0].parameters()[0].declared_type(),
            Some(item.as_ref())
        );

        for (kind, ordinal) in [
            (ResultConstructorKind::Ok, 0_u16),
            (ResultConstructorKind::Err, 1_u16),
        ] {
            let schema = kind.signature_schema();
            let TypeKind::Result { ok, error } = schema
                .value_type()
                .expect("Result constructor publishes a value result")
            else {
                panic!("Result constructor must publish a Result result")
            };
            let payload = schema.groups()[0].parameters()[0]
                .declared_type()
                .expect("Result payload is checked");
            let TypeKind::GenericParam(crate::types::GenericTypeReference::Free(payload)) = payload
            else {
                panic!("Result payload must be generic")
            };
            assert_eq!(payload.ordinal(), ordinal);
            assert_eq!(
                payload.owner(),
                &GenericParameterOwnerId::LanguageIntrinsic(
                    LanguageIntrinsicGenericOwner::ResultConstructor
                )
            );
            assert!(matches!(ok.as_ref(), TypeKind::GenericParam(_)));
            assert!(matches!(error.as_ref(), TypeKind::GenericParam(_)));
            assert!(
                !schema
                    .value_type()
                    .expect("Result constructor publishes a value result")
                    .source_label()
                    .contains("_")
            );
        }
    }

    #[test]
    fn standard_map_and_fx_exists_reject_untyped_receiver_fallbacks() {
        let map = StandardMapFamily::Vec.signature_schema();
        let TypeKind::Vec(item) = map.value_type().expect("map publishes a value result") else {
            panic!("map preserves the concrete collection constructor")
        };
        let TypeKind::GenericParam(crate::types::GenericTypeReference::Free(item)) = item.as_ref()
        else {
            panic!("map result item is generic")
        };
        assert_eq!(
            item.owner(),
            &GenericParameterOwnerId::LanguageIntrinsic(
                LanguageIntrinsicGenericOwner::StandardMap(StandardMapFamily::Vec)
            )
        );
        assert_eq!(item.ordinal(), 1);
        let callback = map.groups()[0].parameters()[0]
            .declared_type()
            .expect("map callback is checked");
        let TypeKind::Function { params, .. } = callback else {
            panic!("map callback must be a function")
        };
        assert!(
            matches!(params.as_slice(), [TypeKind::GenericParam(crate::types::GenericTypeReference::Free(input))] if input.ordinal() == 0)
        );
        assert_eq!(
            map.extension_receiver(),
            Some(CallableExtensionReceiver::new(
                crate::callable::CallableGroupIndex::try_from_usize(1).expect("second group"),
                CallableParameterIndex::try_from_usize(0).expect("first parameter"),
            ))
        );

        let exists = AgentIntrinsicSignatureId::Exists.signature_schema();
        let TypeKind::Probe(item) = exists.groups()[0].parameters()[0]
            .declared_type()
            .expect("exists probe is checked")
        else {
            panic!("exists must retain its generic probe payload")
        };
        let TypeKind::GenericParam(crate::types::GenericTypeReference::Free(item)) = item.as_ref()
        else {
            panic!("exists payload is generic")
        };
        assert_eq!(
            item.owner(),
            &GenericParameterOwnerId::LanguageIntrinsic(LanguageIntrinsicGenericOwner::FxExists)
        );
    }

    #[test]
    fn standard_map_family_owns_all_nine_generic_receiver_result_schemas() {
        for family in StandardMapFamily::ALL {
            let schema = family.signature_schema();
            assert_eq!(schema.groups().len(), 2);
            assert_eq!(
                schema.extension_receiver(),
                Some(CallableExtensionReceiver::new(
                    CallableGroupIndex::try_from_usize(1).expect("second group"),
                    CallableParameterIndex::try_from_usize(0).expect("first parameter"),
                ))
            );
            assert_eq!(schema.validator(), &CallableValidator::StandardMap(family));

            let TypeKind::Function {
                params,
                return_type,
                ..
            } = schema.groups()[0].parameters()[0]
                .declared_type()
                .expect("mapping is checked")
            else {
                panic!("mapping must be a typed function")
            };
            let [TypeKind::GenericParam(crate::types::GenericTypeReference::Free(input))] =
                params.as_slice()
            else {
                panic!("mapping has one generic input")
            };
            let TypeKind::GenericParam(crate::types::GenericTypeReference::Free(output)) =
                return_type.as_ref()
            else {
                panic!("mapping has one generic output")
            };
            assert_eq!(input.ordinal(), 0);
            assert_eq!(output.ordinal(), 1);
            assert_eq!(input.owner(), output.owner());
            assert_eq!(
                input.owner(),
                &GenericParameterOwnerId::LanguageIntrinsic(
                    LanguageIntrinsicGenericOwner::StandardMap(family)
                )
            );

            let receiver = schema
                .extension_receiver_type()
                .expect("standard map has one typed receiver");
            match (
                family,
                receiver,
                schema.value_type().expect("map publishes a value result"),
            ) {
                (StandardMapFamily::Vec, TypeKind::Vec(source), TypeKind::Vec(result))
                | (StandardMapFamily::Seq, TypeKind::Seq(source), TypeKind::Seq(result))
                | (StandardMapFamily::Option, TypeKind::Option(source), TypeKind::Option(result))
                | (StandardMapFamily::Need, TypeKind::Need(source), TypeKind::Need(result)) => {
                    assert_eq!(source.as_ref(), &TypeKind::generic_parameter(input.clone()));
                    assert_eq!(
                        result.as_ref(),
                        &TypeKind::generic_parameter(output.clone())
                    );
                }
                (StandardMapFamily::Slice, TypeKind::Slice(source), TypeKind::Vec(result)) => {
                    assert_eq!(source.as_ref(), &TypeKind::generic_parameter(input.clone()));
                    assert_eq!(
                        result.as_ref(),
                        &TypeKind::generic_parameter(output.clone())
                    );
                }
                (
                    StandardMapFamily::Array,
                    TypeKind::Array {
                        item: source,
                        len: source_len,
                    },
                    TypeKind::Array {
                        item: result,
                        len: result_len,
                    },
                ) => {
                    assert_eq!(source.as_ref(), &TypeKind::generic_parameter(input.clone()));
                    assert_eq!(
                        result.as_ref(),
                        &TypeKind::generic_parameter(output.clone())
                    );
                    assert_eq!(source_len, result_len);
                }
                (
                    StandardMapFamily::Result,
                    TypeKind::Result {
                        ok: source,
                        error: source_error,
                    },
                    TypeKind::Result {
                        ok: result,
                        error: result_error,
                    },
                )
                | (
                    StandardMapFamily::Parser,
                    TypeKind::Parser {
                        item: source,
                        error: source_error,
                    },
                    TypeKind::Parser {
                        item: result,
                        error: result_error,
                    },
                )
                | (
                    StandardMapFamily::Stream,
                    TypeKind::Stream {
                        item: source,
                        error: source_error,
                    },
                    TypeKind::Stream {
                        item: result,
                        error: result_error,
                    },
                ) => {
                    assert_eq!(source.as_ref(), &TypeKind::generic_parameter(input.clone()));
                    assert_eq!(
                        result.as_ref(),
                        &TypeKind::generic_parameter(output.clone())
                    );
                    assert_eq!(source_error, result_error);
                    assert!(matches!(
                        source_error.as_ref(),
                        TypeKind::GenericParam(crate::types::GenericTypeReference::Free(error))
                            if error.ordinal() == 2 && error.owner() == input.owner()
                    ));
                }
                actual => panic!("{family:?} published the wrong map shape: {actual:?}"),
            }
        }
    }

    #[test]
    fn typed_rest_is_single_supply_identity_and_both_rest_kinds_are_rejected() {
        let positional = parameter(
            0,
            Some("items"),
            CallableParameterAdmission::checked(TypeKind::String),
            CallableParameterPassing::RestPositional,
            CallableParameterPresence::Required,
        );
        let named = parameter(
            1,
            Some("fields"),
            CallableParameterAdmission::checked(TypeKind::Map {
                kind: MapKind::Sorted,
                key: Box::new(TypeKind::String),
                value: Box::new(TypeKind::String),
            }),
            CallableParameterPassing::RestNamed,
            CallableParameterPresence::Required,
        );
        assert!(matches!(
            CallableParameterGroup::try_new(
                CallableGroupIndex::ZERO,
                CallableGroupKind::Initial,
                vec![positional.clone(), named],
                &PRODUCTION_CALLABLE_LIMITS,
            ),
            Err(CallableSchemaError::InvalidRestParameter { .. })
        ));

        let clearable = parameter(
            0,
            Some("items"),
            CallableParameterAdmission::checked_with_rule(
                TypeKind::String,
                CallableParameterValueRule::clearable_option(),
            ),
            CallableParameterPassing::RestPositional,
            CallableParameterPresence::Required,
        );
        let group = CallableParameterGroup::try_new(
            CallableGroupIndex::ZERO,
            CallableGroupKind::Initial,
            vec![clearable],
            &PRODUCTION_CALLABLE_LIMITS,
        )
        .expect("one rest parameter has a valid shape");
        assert!(matches!(
            CallableSignatureSchema::try_new(
                vec![group],
                TypeKind::Unit,
                CallableEffectSchema::fixed(EffectRow::closed(EffectSet::new())),
                CallableArgumentPolicy::new(
                    UnknownNamedArgumentPolicy::Reject,
                    SpreadArgumentPolicy::TypedRest,
                ),
                CallableValidator::Ordinary,
                CallableGenericParameterIssuer::empty(),
                &PRODUCTION_CALLABLE_LIMITS,
            ),
            Err(CallableSchemaError::InvalidParameterAdmission { .. }
                | CallableSchemaError::InvalidParameterConsumer { .. },)
        ));
    }
}
