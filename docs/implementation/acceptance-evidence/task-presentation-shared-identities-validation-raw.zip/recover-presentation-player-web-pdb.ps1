$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$source = (git rev-parse HEAD).Trim()
if ($source -ne 'c4365e40c7e1b6050b4ba3162b367c954b7f07ff') { throw 'Repaired source changed' }
$matrix = Get-Content "$taskTemp/presentation-shared-identity-repaired-reverse-20261101.matrix.json" -Raw | ConvertFrom-Json -Depth 35
if ($matrix.status -ne 'terminal') { throw 'Original matrix is not closed' }
$quality = [IO.File]::ReadAllText("$taskTemp/product-execution-quality.active.txt")
$freeze = Get-Content "$taskTemp/$quality.source-freeze.json" -Raw | ConvertFrom-Json -Depth 35
foreach ($row in $freeze.paths) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
}
$pdbPath = [IO.Path]::GetFullPath('D:/git/arcweft/target/debug/deps/arcweft_player_web-16af0f2d7783df97.pdb')
$parent = [IO.Path]::GetFullPath('D:/git/arcweft/target/debug/deps')
if (-not [string]::Equals([IO.Path]::GetDirectoryName($pdbPath), $parent, [StringComparison]::OrdinalIgnoreCase)) { throw 'PDB is outside the intended build directory' }
$log = [IO.File]::ReadAllText("$taskTemp/presentation-shared-identity-repaired-reverse-20261101.libraries.catalog.log")
if (-not $log.Contains('LNK1285') -or -not $log.Contains('arcweft_player_web-16af0f2d7783df97.pdb')) { throw 'Exact PDB does not match linker failure' }
$file = Get-Item -LiteralPath $pdbPath
if ($file.PSIsContainer) { throw 'Expected one PDB file' }
$proof = [ordered]@{
    version = 1; source = $source; sourceInputs = $freeze.paths.Count; sourceDrift = 0
    failure = 'LNK1285: corrupt player-web test PDB'; target = $file.FullName
    bytes = $file.Length; lastWrite = $file.LastWriteTimeUtc
    action = 'Delete exactly this rebuildable PDB and relink the failed library cohort; no recursive deletion, source deletion, artifact move or artifact copy.'
    at = [DateTime]::UtcNow.ToString('o')
}
Remove-Item -LiteralPath $pdbPath
if (Test-Path -LiteralPath $pdbPath) { throw 'PDB was not removed' }
$proof | ConvertTo-Json -Depth 6 | Set-Content "$taskTemp/presentation-shared-identity.pdb-recovery.json" -Encoding utf8
$failed = Get-Content "$taskTemp/presentation-shared-identity-repaired-reverse-20261101.libraries.catalog.json" -Raw | ConvertFrom-Json -Depth 20
if ($failed.exitCode -ne 101 -or $failed.command[0] -ne 'nextest' -or $failed.command[1] -ne 'list' -or $failed.command[-2] -ne '--message-format' -or $failed.command[-1] -ne 'json') { throw 'Failed library selection cannot be recovered exactly' }
$selection = @($failed.command[2..($failed.command.Count - 3)])
& "$taskTemp/run-presentation-shared-identity-library-retry.ps1" -Stem 'presentation-shared-identity-libraries-retry1-20261101' -Selection $selection -ExpectedMatches -1 -AdditionalPaths @('crates/arcweft-core/src/awbc/product_step/tests/dialogue_handoff.rs', 'crates/arcweft-interaction-model/src/presentation/arguments.rs', 'crates/arcweft-interaction-model/src/presentation/callables.rs', 'crates/arcweft-lang-sema/src/final_analysis/tests/presentation.rs')
exit $LASTEXITCODE
