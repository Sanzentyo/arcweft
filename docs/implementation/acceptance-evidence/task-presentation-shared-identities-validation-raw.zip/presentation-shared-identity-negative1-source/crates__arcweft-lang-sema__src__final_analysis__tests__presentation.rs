use super::{analyze, fixture};
use crate::callable::{
    CallableCandidateId, CheckedCallReceiverProjection, PresentationHandleMethodId,
};
use crate::types::TypeKind;

#[test]
fn generic_handle_methods_preserve_the_checked_receiver_and_selected_identity() {
    for (name, expected) in [
        ("show", PresentationHandleMethodId::Show),
        ("hide", PresentationHandleMethodId::Hide),
        ("unmount", PresentationHandleMethodId::Unmount),
        ("release", PresentationHandleMethodId::Release),
        ("destroy", PresentationHandleMethodId::Destroy),
    ] {
        let source = format!("fn invoke<T>(handle: Handle<T>) {{ handle.{name}() }}");
        let world = fixture(&source, None);
        let report = analyze(&world).unwrap_or_else(|error| panic!("{name}: {error:?}"));
        let applications = report
            .calls()
            .filter_map(|(_, call)| call.selected_application())
            .collect::<Vec<_>>();
        let [application] = applications.as_slice() else {
            panic!("{name}: exactly one selected method is required")
        };
        assert_eq!(
            application.core().candidates().selected().id(),
            &CallableCandidateId::PresentationHandleMethod(expected),
            "{name}"
        );
        assert_eq!(application.result().value_type(), Some(&TypeKind::Unit));
        assert!(matches!(
            application.core().execution().receiver(),
            CheckedCallReceiverProjection::Operand {
                ty: TypeKind::Handle { item, .. }, ..
            } if matches!(item.as_ref(), TypeKind::GenericParam(_))
        ));
    }
}
