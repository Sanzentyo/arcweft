param([Parameter(Mandatory)][string]$Stem,[Parameter(Mandatory)][string[]]$Selection,[Parameter(Mandatory)][int]$ExpectedMatches,[string[]]$AdditionalPaths=@())
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
if(Test-Path -LiteralPath "$taskTemp/$Stem.source-freeze.json"){throw 'Source epoch already exists; observe its original handle'}
$template=Get-Content -LiteralPath "$taskTemp/presentation-dialogue-receipt-reverse-20261101.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$inputPaths=@(@($template.paths.path)+$AdditionalPaths|Sort-Object -Unique)
$freeze=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();held=$template.held;recordedAt=[DateTime]::UtcNow.ToString('o');paths=@(foreach($path in $inputPaths){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})}
$freeze|ConvertTo-Json -Depth 15|Set-Content -LiteralPath "$taskTemp/$Stem.source-freeze.json" -Encoding utf8
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
function Invoke-Recorded([string]$name,[object[]]$arguments) {
    Assert-Inputs
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> "$taskTemp/$name.log"
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$freeze.base;command=$arguments;log="$taskTemp/$name.log";exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$name.json" -Encoding utf8
    return $code
}
$catalogExit=Invoke-Recorded "$Stem.catalog" (@('nextest','list')+$Selection+@('--message-format','json'))
if($catalogExit -ne 0){throw 'Focused catalog failed'}
$line=[IO.File]::ReadLines("$taskTemp/$Stem.catalog.log")|Where-Object {$_.StartsWith('{"rust-build-meta"')}|Select-Object -Last 1
$catalog=$line|ConvertFrom-Json -Depth 100
$cases=@(foreach($suite in $catalog.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){[ordered]@{package=$suite.Value.'package-name';binary=$suite.Value.'binary-id';test=$case.Name;ignored=$case.Value.ignored;status=$(if($case.Value.ignored){'ignored'}else{$case.Value.'filter-match'.status})}}})
$inventory=[ordered]@{rows=$cases;excluded=@($cases|Where-Object status -ne 'matches').Count}
if(@($cases|Where-Object {$_.status -ne 'matches' -and -not $_.ignored}).Count){throw 'Nonignored reverse case was excluded'}
$inventory|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$Stem.catalog.inventory.json" -Encoding utf8
if(@($cases|Where-Object status -eq 'matches').Count -eq 0){throw 'No owner cases selected'}; if($ExpectedMatches -ge 0 -and @($cases|Where-Object status -eq 'matches').Count -ne $ExpectedMatches){throw 'Focused case count differs'}
$pins=@(foreach($suite in $catalog.'rust-suites'.PSObject.Properties){$path=$suite.Value.'binary-path';[ordered]@{binary=$suite.Value.'binary-id';path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$pins|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/$Stem.binaries-before.json" -Encoding utf8
$runtimeExit=Invoke-Recorded "$Stem.runtime" (@('nextest','run')+$Selection+@('--no-tests','fail','--no-fail-fast','--status-level','all','--final-status-level','all'))
if(@($pins|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Focused executable drift'}
if($runtimeExit -notin @(0,100)){throw 'Focused runtime has no valid terminal'}
& "$taskTemp/audit-nextest-final-result.ps1" -Run "$Stem.runtime" -Catalog "$Stem.catalog" -Freeze $Stem
exit $runtimeExit
