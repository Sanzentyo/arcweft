$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$encoding = [System.Text.UTF8Encoding]::new($false)
function Read-Source([string]$path) { [System.IO.File]::ReadAllText((Join-Path $PWD $path)).Replace("`r`n", "`n") }
function Write-Source([string]$path, [string]$value) { [System.IO.File]::WriteAllText((Join-Path $PWD $path), $value, $encoding) }
function Replace-Once([string]$source, [string]$old, [string]$new) {
    if ($source.IndexOf($old) -lt 0 -or $source.IndexOf($old) -ne $source.LastIndexOf($old)) { throw "Unexpected replacement count: $old" }
    $source.Replace($old, $new)
}
$path = 'crates/arcweft-lang-sema/src/callable/presentation.rs'
$source = Read-Source $path
$enumStart = $source.IndexOf('#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]')
$enumEnd = $source.IndexOf('pub use arcweft_interaction_model', $enumStart)
$enum = $source.Substring($enumStart, $enumEnd - $enumStart).TrimEnd()
$enum = $enum.Replace('#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]', '#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]' + "`n" + '#[serde(rename_all = "snake_case")]')
$implStart = $source.IndexOf('impl PresentationCallableId {')
$schemaStart = $source.IndexOf('    #[allow(', $implStart)
$commonImpl = $source.Substring($implStart, $schemaStart - $implStart)
$commonImpl = $commonImpl.Replace('    const ALL:', '    pub const ALL:')
$resolveStart = $commonImpl.IndexOf('    pub fn resolve(')
$resolveEnd = $commonImpl.IndexOf('    pub(crate) fn resolve_surface_name', $resolveStart)
$commonImpl = $commonImpl.Remove($resolveStart, $resolveEnd - $resolveStart)
$commonImpl = $commonImpl.Replace('pub(crate) fn resolve_surface_name', 'pub fn resolve_surface_name').Replace('pub(crate) const fn surface_name', 'pub const fn surface_name')
$helpersStart = $source.IndexOf('fn view_argument(')
$helpersEnd = $source.IndexOf('fn ratio_or_milli()', $helpersStart)
$helpers = $source.Substring($helpersStart, $helpersEnd - $helpersStart)
$transcriptPath = 'crates/arcweft-lang-sema/src/callable/checked_application.rs'
$transcript = Read-Source $transcriptPath
$tagStart = $transcript.IndexOf('const fn presentation_tag(')
$tagEnd = $transcript.IndexOf('const fn dialogue_tag(', $tagStart)
$tag = $transcript.Substring($tagStart, $tagEnd - $tagStart).Replace('const fn presentation_tag(id: PresentationCallableId)', '    pub const fn semantic_tag(self)').Replace('match id {', 'match self {').Replace('PresentationCallableId::', 'Self::').TrimEnd()
$common = '//! Executable presentation operation identities and their authored argument roles.' + "`n`n" + 'use super::{PresentationArgumentRole, PresentationResourceKind};' + "`n" + 'use serde::{Deserialize, Serialize};' + "`n`n" + $enum + "`n`n" + $commonImpl + $tag + "`n}`n`n" + $helpers
$transcript = $transcript.Remove($tagStart, $tagEnd - $tagStart).Replace('presentation_tag(*id)', 'id.semantic_tag()')
$handleTagStart = $transcript.IndexOf('const fn presentation_handle_tag(')
$handleTagEnd = $transcript.IndexOf('const fn integer_tag(', $handleTagStart)
$handleTag = $transcript.Substring($handleTagStart, $handleTagEnd - $handleTagStart).Replace('const fn presentation_handle_tag(id: PresentationHandleMethodId)', '    pub const fn semantic_tag(self)').Replace('match id {', 'match self {').Replace('PresentationHandleMethodId::', 'Self::').TrimEnd()
$transcript = $transcript.Remove($handleTagStart, $handleTagEnd - $handleTagStart).Replace('presentation_handle_tag(*id)', 'id.semantic_tag()')
Write-Source $transcriptPath $transcript
$identityPath = 'crates/arcweft-lang-sema/src/callable/identity.rs'
$identity = Read-Source $identityPath
$handleStart = $identity.IndexOf('#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]' + "`n" + 'pub enum PresentationHandleMethodId')
$handleEnd = $identity.IndexOf('#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]' + "`n" + 'pub enum IntegerMethodId', $handleStart)
$handle = $identity.Substring($handleStart, $handleEnd - $handleStart)
$handle = $handle.Replace('#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]', '#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]' + "`n" + '#[serde(rename_all = "snake_case")]')
$resolveStart = $handle.IndexOf('    pub fn resolve(')
$matchStart = $handle.IndexOf('        match method.as_str() {', $resolveStart)
$handle = $handle.Remove($resolveStart, $matchStart - $resolveStart).Insert($resolveStart, '    pub fn resolve(resource: PresentationResourceKind, method: &str) -> Option<Self> {' + "`n")
$handle = $handle.Replace('match method.as_str() {', 'match method {')
$popStart = $handle.IndexOf('            "pop"')
$popEnd = $handle.IndexOf('                Some(Self::OverlayPop)', $popStart)
$handle = $handle.Remove($popStart, $popEnd - $popStart).Insert($popStart, '            "pop" if resource == PresentationResourceKind::Overlay => {' + "`n")
$handle = $handle.TrimEnd()
$handle = $handle.Substring(0, $handle.LastIndexOf('}')) + $handleTag + "`n}`n"
$common += $handle
Write-Source 'crates/arcweft-interaction-model/src/presentation/callables.rs' $common
$identity = $identity.Remove($handleStart, $handleEnd - $handleStart).Insert($handleStart, 'pub use arcweft_interaction_model::presentation::PresentationHandleMethodId;' + "`n`n")
Write-Source $identityPath $identity
$source = $source.Remove($helpersStart, $helpersEnd - $helpersStart)
$implEnd = $source.IndexOf('impl PresentationArgumentValuePolicy {', $implStart)
$schema = @'
impl PresentationSchemaContext<'_> {
    pub fn signature_schema(
        &self,
        id: PresentationCallableId,
    ) -> Result<CallableSignatureSchema, CallableSchemaError> {
        super::schema::presentation_schema(id, self.owner, Some(self.environment))
    }

    pub(crate) fn checker_signature_schema(
        id: PresentationCallableId,
    ) -> Result<CallableSignatureSchema, CallableSchemaError> {
        super::schema::presentation_schema(id, None, None)
    }
}

'@
$source = $source.Remove($implStart, $implEnd - $implStart).Insert($implStart, $schema)
$source = $source.Remove($enumStart, $enumEnd - $enumStart)
$source = $source.Replace('use super::{CallablePath, CallableSchemaError, CallableSignatureSchema, ResolvedCharacterOwner};', 'use super::{CallableSchemaError, CallableSignatureSchema, ResolvedCharacterOwner};')
$source = $source.Replace('pub use arcweft_interaction_model::presentation::PresentationArgumentRole;', 'pub use arcweft_interaction_model::presentation::{PresentationArgumentRole, PresentationCallableId};')
Write-Source $path $source
$path = 'crates/arcweft-lang-sema/src/callable/schema/families.rs'
$source = Read-Source $path
$source = Replace-Once $source ('impl PresentationHandleMethodId {' + "`n" + '    pub(crate) fn signature_schema(self) -> CallableSignatureSchema {') ('impl CallableSignatureSchema {' + "`n" + '    pub(crate) fn presentation_handle(id: PresentationHandleMethodId) -> Self {')
# The method body alone contains this validator.
$source = Replace-Once $source 'CallableValidator::PresentationHandle(self),' 'CallableValidator::PresentationHandle(id),'
Write-Source $path $source
$path = 'crates/arcweft-lang-sema/src/callable/resolver/resolution.rs'
$source = Read-Source $path
$source = Replace-Once $source 'if let Some(id) = PresentationHandleMethodId::resolve(receiver_type, method) {' @'
if let TypeKind::Handle { item, .. } = receiver_type
        && let TypeKind::PresentationResource(resource) = item.as_ref()
        && let Some(id) = PresentationHandleMethodId::resolve(*resource, method.as_str())
    {
'@
$source = Replace-Once $source @'
            CallableCandidateId::PresentationHandleMethod(id),
            LanguageCallableFamily::PresentationHandleMethod,
            id.signature_schema(),
'@ @'
            CallableCandidateId::PresentationHandleMethod(id),
            LanguageCallableFamily::PresentationHandleMethod,
            CallableSignatureSchema::presentation_handle(id),
'@
$source = Replace-Once $source 'PresentationCallableId::resolve(path)' 'PresentationCallableId::resolve_surface_name(&path.dotted_name())'
$source = Replace-Once $source @'
let schema = id
            .signature_schema(super::PresentationSchemaContext {
                owner: request.presentation_character_owner,
                environment: world.environment(),
            })
'@ @'
let schema = super::PresentationSchemaContext {
                owner: request.presentation_character_owner,
                environment: world.environment(),
            }
            .signature_schema(id)
'@
Write-Source $path $source
$path = 'crates/arcweft-lang-sema/src/callable/resolver/preparation.rs'
$source = (Read-Source $path).Replace('PresentationCallableId::resolve(&path)', 'PresentationCallableId::resolve_surface_name(&path.dotted_name())')
Write-Source $path $source
$path = 'crates/arcweft-lang-sema/src/final_analysis/analyzer/calls.rs'
$source = (Read-Source $path).Replace('id.checker_signature_schema()', 'crate::callable::PresentationSchemaContext::checker_signature_schema(id)')
Write-Source $path $source
