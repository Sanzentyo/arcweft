$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$encoding = [System.Text.UTF8Encoding]::new($false)
$path = 'crates/arcweft-lang-sema/src/callable/presentation.rs'
$source = [System.IO.File]::ReadAllText((Join-Path $PWD $path))
$enumStart = $source.IndexOf('/// Semantic destination of a presentation argument.')
$enumEnd = $source.IndexOf('#[derive(Clone, Debug, Eq, PartialEq)]', $enumStart)
$enum = $source.Substring($enumStart, $enumEnd - $enumStart).TrimEnd()
$enum = $enum.Replace('#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]', '#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]' + "`n" + '#[serde(rename_all = "snake_case")]')
$implStart = $source.IndexOf('impl PresentationArgumentRole {')
$policyStart = $source.IndexOf('    pub(crate) fn value_policy(self)', $implStart)
$tagImpl = $source.Substring($implStart, $policyStart - $implStart).TrimEnd().Replace('pub(crate) const fn semantic_tag', 'pub const fn semantic_tag') + "`n}"
$shared = '//! Semantic argument coordinates shared by checking and executable commands.' + "`n`n" + 'use serde::{Deserialize, Serialize};' + "`n`n" + $enum + "`n`n" + $tagImpl + "`n"
[System.IO.File]::WriteAllText((Join-Path $PWD 'crates/arcweft-interaction-model/src/presentation/arguments.rs'), $shared, $encoding)
$source = $source.Remove($enumStart, $enumEnd - $enumStart).Insert($enumStart, 'pub use arcweft_interaction_model::presentation::PresentationArgumentRole;' + "`n`n")
$implStart = $source.IndexOf('impl PresentationArgumentRole {')
$policyStart = $source.IndexOf('    pub(crate) fn value_policy(self)', $implStart)
$source = $source.Remove($implStart, $policyStart - $implStart).Insert($implStart, 'impl PresentationArgumentValuePolicy {' + "`n")
$policyStart = $source.IndexOf('    pub(crate) fn value_policy(self)')
$policyEnd = $source.IndexOf("`nfn view_argument", $policyStart)
$policy = $source.Substring($policyStart, $policyEnd - $policyStart)
$policy = $policy.Replace('fn value_policy(self)', 'fn for_role(role: PresentationArgumentRole)').Replace('match self {', 'match role {').Replace('Self::', 'PresentationArgumentRole::')
$source = $source.Substring(0, $policyStart) + $policy + $source.Substring($policyEnd)
[System.IO.File]::WriteAllText((Join-Path $PWD $path), $source, $encoding)
$path = 'crates/arcweft-lang-sema/src/callable/schema/families.rs'
$source = [System.IO.File]::ReadAllText((Join-Path $PWD $path))
if (($source.Split('match argument.value_policy() {').Count - 1) -ne 1) { throw 'unexpected role policy call count' }
$source = $source.Replace('match argument.value_policy() {', 'match PresentationArgumentValuePolicy::for_role(argument) {')
[System.IO.File]::WriteAllText((Join-Path $PWD $path), $source, $encoding)
