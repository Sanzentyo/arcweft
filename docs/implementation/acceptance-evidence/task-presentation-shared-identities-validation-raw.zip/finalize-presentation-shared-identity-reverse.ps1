$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem = 'presentation-shared-identity-repaired-reverse-20261101'
$retry = 'presentation-shared-identity-libraries-retry1-20261101'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100 }
$original = Read-Record "$stem.matrix"
$terminal = Read-Record "$retry.runtime.terminal-audit"
$oldFreeze = Read-Record "$stem.source-freeze"
$newFreeze = Read-Record "$retry.source-freeze"
if ($original.status -ne 'terminal' -or $terminal.actualExitCode -ne 0 -or $terminal.failed -ne 0) { throw 'Reverse inputs are not passing/terminal' }
if ($oldFreeze.base -ne $newFreeze.base -or $oldFreeze.base -ne 'c4365e40c7e1b6050b4ba3162b367c954b7f07ff') { throw 'Reverse sources differ' }
$oldHashes = @($oldFreeze.paths | ForEach-Object { $_.path + [char]0 + $_.sha256 } | Sort-Object)
$newHashes = @($newFreeze.paths | ForEach-Object { $_.path + [char]0 + $_.sha256 } | Sort-Object)
if (@(Compare-Object $oldHashes $newHashes).Count) { throw 'Retry source path/hash drift' }
$oldCommand = (Read-Record "$stem.libraries.catalog").command
$newCommand = (Read-Record "$retry.catalog").command
if (($oldCommand -join [char]0) -ne ($newCommand -join [char]0)) { throw 'Library selection changed during retry' }
$inventory = Read-Record "$retry.catalog.inventory"
$previous = Read-Record 'presentation-dialogue-handoff-reverse-20261101.libraries.catalog.inventory'
$keys = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($row in $inventory.rows | Where-Object status -eq 'matches') { [void]$keys.Add($row.binary + [char]0 + $row.test) }
$missing = @($previous.rows | Where-Object { $_.status -eq 'matches' -and -not $keys.Contains($_.binary + [char]0 + $_.test) })
if ($missing.Count) { throw 'A previous Core reverse case disappeared from the expanded interaction-model closure' }
$proof = [ordered]@{
    version = 1; source = $oldFreeze.base; sourceInputs = $newFreeze.paths.Count; sourceDrift = 0
    retry = $retry; previousCoreSelected = $previous.matched; expandedSelected = $keys.Count
    previousCoreCasesMissing = 0; exactLibraryCommandPreserved = $true
    noNonignoredExclusions = (@($inventory.rows | Where-Object { $_.status -ne 'matches' -and -not $_.ignored }).Count -eq 0)
}
if (-not $proof.noNonignoredExclusions) { throw 'A nonignored reverse case was excluded' }
$proof | ConvertTo-Json -Depth 8 | Set-Content "$taskTemp/presentation-shared-identity.retry-coverage.json" -Encoding utf8
$rows = @([pscustomobject]@{ group = 'libraries'; catalogExit = 0; runtimeExit = 0; terminal = $terminal; epoch = $retry })
foreach ($group in @('cli-unit', 'cli-integration')) {
    $row = @($original.rows | Where-Object group -eq $group)
    if ($row.Count -ne 1 -or $row[0].runtimeExit -ne 0 -or $row[0].terminal.failed -ne 0 -or $row[0].terminal.sourceDrift -ne 0) { throw "CLI row is not reusable: $group" }
    $rows += $row[0]
}
[ordered]@{
    version = 1; base = $oldFreeze.base; status = 'terminal'; rows = $rows
    sourceFreeze = "$stem.source-freeze.json"; graph = "$stem.graph.json"
    originalFailedMatrix = "$stem.matrix.json"; replacementLibraryEpoch = $retry
    selectionAndSourceProof = 'presentation-shared-identity.retry-coverage.json'
    isSingleRuntimeCommand = $false
    policy = 'Distinct feature-union groups remain distinct. The original failed library catalog is retained; only that group was retried after exact PDB deletion. Successful CLI groups are reused only after matching all original source hashes.'
    finishedAt = [DateTime]::UtcNow.ToString('o')
} | ConvertTo-Json -Depth 40 | Set-Content "$taskTemp/$stem.final-matrix.json" -Encoding utf8
$freshOwner = @($inventory.rows | Where-Object { $_.package -in @('arcweft-lang-sema', 'arcweft-interaction-model') })
if (@($freshOwner | Where-Object status -ne 'matches').Count) { throw 'A shared identity owner case was excluded' }
[ordered]@{ version = 1; source = $oldFreeze.base; allOwnerCases = $freshOwner.Count; allPassed = $true; terminal = "$retry.runtime.terminal-audit.json"; sourceInputs = $newFreeze.paths.Count; sourceDrift = 0 } | ConvertTo-Json | Set-Content "$taskTemp/presentation-shared-identity.fresh-owner-coverage.json" -Encoding utf8
[pscustomobject]@{ source = $oldFreeze.base; libraryPassed = $terminal.passed; freshOwnerCases = $freshOwner.Count; priorCoreCasesMissing = 0; reusedCliPassed = ([int]$rows[1].terminal.passed + [int]$rows[2].terminal.passed) } | ConvertTo-Json -Compress
