$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$stem) { Get-Content -LiteralPath "$taskTemp/$stem.json" -Raw | ConvertFrom-Json -Depth 100 }
$source = (Read-Record 'presentation-shared-identity-generic-repair-source.verified').commit
if ((git rev-parse HEAD).Trim() -ne $source) { throw 'Inspected source changed' }
$reverse = Read-Record 'presentation-shared-identity-repaired-reverse-20261101.final-matrix'
$cli = Read-Record 'presentation-shared-identity-repaired-full-cli-20261101.matrix'
$graph = Read-Record 'presentation-shared-identity-repaired-reverse-20261101.graph'
$generic = Read-Record 'presentation-shared-identity-repaired-reverse-20261101.generic-coverage'
$comparison = Read-Record 'presentation-shared-identity-repaired-full-cli-20261101.cli-comparison'
if ($reverse.status -ne 'terminal' -or $cli.status -ne 'terminal' -or $generic.passed -ne 151) { throw 'Current results are incomplete' }
$lib = @($reverse.rows | Where-Object group -eq 'libraries')[0].terminal
$unit = @($reverse.rows | Where-Object group -eq 'cli-unit')[0].terminal
$integration = @($reverse.rows | Where-Object group -eq 'cli-integration')[0].terminal
$check = @($cli.rows | Where-Object group -eq 'check')[0].terminal
$additional = @($cli.rows | Where-Object group -eq 'additional-integration')[0].terminal
$allCli = Read-Record 'presentation-shared-identity.all-cli-coverage'
if ($null -eq $lib -or $null -eq $unit -or $null -eq $integration -or $null -eq $check) { throw 'Required terminal is absent' }
$quality = [IO.File]::ReadAllText("$taskTemp/product-execution-quality.active.txt")
foreach ($suffix in @('workspace-check', 'clippy', 'structure', 'fmt')) {
    if ((Read-Record "$quality.$suffix").exitCode -ne 0) { throw "Quality failed: $suffix" }
}
$normalPass = [int]$lib.passed + [int]$unit.passed + [int]$integration.passed
$normalFail = [int]$lib.failed + [int]$unit.failed + [int]$integration.failed
$normalIgnored = [int]$lib.skipped + [int]$unit.skipped + [int]$integration.skipped
$normalPackages = $graph.reversePackages.Count
$inputs = (Read-Record "$quality.source-freeze").paths.Count
$statusPath = Join-Path $PWD 'docs/implementation/current-status.md'
$script:status = [IO.File]::ReadAllText($statusPath)
$superseded = [Collections.Generic.List[object]]::new()
function Replace-Row([string]$prefix, [string]$replacement) {
    $old = @($script:status -split '\r?\n' | Where-Object { $_.StartsWith($prefix, [StringComparison]::Ordinal) })
    if ($old.Count -ne 1) { throw "Expected one current row: $prefix" }
    $superseded.Add([pscustomobject]@{ prefix = $prefix; historicalText = $old[0] })
    $script:status = $script:status.Replace($old[0], $replacement)
}
$header = @($script:status -split '\r?\n' | Where-Object { $_.StartsWith('確認日:') })
if ($header.Count -ne 1) { throw 'Expected one source header' }
$script:status = $script:status.Replace($header[0], "確認日: 2026-11-01。検証したSource/mainは$source。元からの14 tracked／6 untracked WIPを保持するcheckoutの$inputs 入力で検証した。公開canonicalと保持WIPの差分を同一視せず、受入と未達は各行の境界・検証範囲で判定する。")
$row = @'
| Presentation引数schema／resource型 | **共有識別子・引数schema・resource型の受入を維持。汎用handleの選択を修復・公開済み** | 共有化9c7690d8f6531b4886fa2a14aa223d27c84f0a8e、修復{0}。11 callable・6 method・51引数role、version 1のsemantic tag、戻り値のresource familyと所有形態をinteraction-modelで一つにし、semaの型検査・signature構築が直接使う。移行で狭めた`Handle<T>`の共通method解決はSourceのshow拒否で再現し、5 methodのgeneric receiver保持とOverlayだけのpopを2件で検証した。今回の広い検証は下表の範囲。Source実行ABIの接続は次行と区別する。[移行・再現・修復・検証原本](acceptance-evidence/task-presentation-shared-identities-validation.json)。 |
'@
Replace-Row '| Presentation引数schema／resource型 ' ($row -f $source)
$genericOld = @($script:status -split '\r?\n' | Where-Object { $_.StartsWith('| Generic Match') })
if ($genericOld.Count -ne 1) { throw 'Expected one accepted Generic row' }
$genericNew = $genericOld[0].Replace('今回の4,033入力', ('今回の' + ('{0:N0}' -f $inputs) + '入力')).Replace('acceptance-evidence/task-presentation-dialogue-handoff-validation.json', 'acceptance-evidence/task-presentation-shared-identities-validation.json')
Replace-Row '| Generic Match' $genericNew
$row = @'
| CLI・全 consumer の統合受入 | **CLI失敗{0}件を保持・統合受入は未完了** | 現行CLIのlib／bin／integration全targetを4 commandで照合し、対象別の結果を下表にまとめる。以前この行の現在値とした「全692件・649 PASS／43 FAIL」はSource 1bf138d190c826841935b38bf01c3048fb43c3cbの履歴であり、現在の根拠としては削除した。同じ件数でも今回の入力・commandによる検証と一つのrunに合算しない。元の実行・全SHA・訂正理由は履歴と[原本](acceptance-evidence/task-nominal-c6-reverse-acceptance.json)へ保持する。Presentation ABI・JLREQ geometry等の失敗を、個別に受入済みの機能へ戻さない。[今回の対象・失敗ID比較](acceptance-evidence/task-presentation-shared-identities-validation.json)。 |
'@
Replace-Row '| CLI・全 consumer の統合受入 ' ($row -f $check.failed)
$row = @'
| Presentation共有語彙の逆依存matrix | **{0} package・通常3群：{1:N0} PASS／{2} FAIL／{3} ignored** | Source {4}、同じ{5:N0}入力。解決済みCargo graphからinteraction-modelの推移的逆依存を選択した。library／integrationは{6:N0} PASS、CLI lib／binは{7} PASS、通常CLIの6 integration targetは{8} PASS。all-features・locked・default filterで、feature unionとcommandを群ごとに記録する。catalog・実行case・EXEと入力の照合結果、native matching caseのないpackageも[原本](acceptance-evidence/task-presentation-shared-identities-validation.json)に保持する。 |
'@
Replace-Row '| Core共有契約の逆依存matrix ' ($row -f $normalPackages, $normalPass, $normalFail, $normalIgnored, $source, $inputs, $lib.passed, $unit.passed, $integration.passed)
$row = @'
| CLI追加check target | **{0} PASS／{1} FAIL／{2} ignored。過去43 IDに対し新規{3}・解消{4}・未選択{5}** | 通常の6 CLI integration targetに含まれないcheckを、同じ{6:N0}入力・all-features・locked・default filterで別実行した。異なる入力の失敗IDの一致から原因の同一性を推定せず、通常matrixの成功をこの領域の解決とは扱わない。[比較・現在のstderr原本](acceptance-evidence/task-presentation-shared-identities-validation.json)。 |
'@
Replace-Row '| CLI追加check target ' ($row -f $check.passed, $check.failed, $check.skipped, $comparison.newFailureIds.Count, $comparison.resolvedFailureIds.Count, $comparison.unselectedPriorFailureIds.Count, $inputs)
$row = @'
| workspace check／Clippy・fmt・構造gate | **各gate終了0・構造blocking0** | 同じ{0:N0}入力でworkspace全97 package・全target・全feature・lockedのcheckとClippy、今回変更したRust 12 pathのfmtを実行した。構造gateは97 package・3,272 file／3,142 Rust file・1,777,137 Rust physical LOC・382 review trigger・blocking0。警告、owner disposition、正確なcommandと終端を[原本](acceptance-evidence/task-presentation-shared-identities-validation.json)に保持する。以前のCore default／doctest／Wasm compileは元入力の履歴として保持し、今回の再実行に数えない。 |
'@
Replace-Row '| workspace check／Clippy・Core default／doctest・Wasm compile ' ($row -f $inputs)
$extraRow = '| CLI追加3 integration target | **{0} PASS／{1} FAIL／{2} ignored** | bracket_numeric_batch、environment_callable_tensor、native_host_contractsを同じ入力で実行した。上記のCLI 3群と合わせ、metadata上の現行lib／bin／integration全{3} testable targetを網羅した。重複を除いた実行caseは{4}、ignoredは{5}。異なるcommandとfeature unionを単一runに読み替えない。[全target・case照合原本](acceptance-evidence/task-presentation-shared-identities-validation.json)。 |'
$extraRow = $extraRow -f $additional.passed, $additional.failed, $additional.skipped, $allCli.testableTargets.Count, $allCli.uniqueExecuted, $allCli.ignored
$script:status = $script:status.Replace('| workspace check／Clippy・fmt・構造gate |', $extraRow + ([string][char]10) + '| workspace check／Clippy・fmt・構造gate |')
$encoding = [Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText($statusPath, $script:status, $encoding)
$superseded | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$taskTemp/presentation-shared-identity.superseded-status-rows.json" -Encoding utf8
$historyPath = Join-Path $PWD 'docs/implementation/convergence-evidence-history.md'
$before = [IO.File]::ReadAllBytes($historyPath)
$beforeHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant()
$addition = @'


2026-11-01 — Presentation共有語彙の移行は9c7690d8f6531b4886fa2a14aa223d27c84f0a8e、汎用handle修復は{0}で公開した。11 callable・6 method・51 roleと戻り値のresource／所有形態はinteraction-model、型検査とsignature構築はsemaが所有する。最初の1,363 owner PASSはその入力だけの結果であり、後から追加したGeneric Handle回帰の受入証拠には読み替えない。9c7690d8f6531b4886fa2a14aa223d27c84f0a8eで`Handle<T>`.show()がUnknownCallTargetになる1件を再現し、resource familyが未確定でも5共通methodを選べる形へ修復した。Overlayだけのpop成功、genericと他7 familyの拒否を含む2件がPASSした。最初の再現fixtureのE0583はmodule pathの不備であり、behaviorの検証ではない。最初のreverse62は修復のためcatalog中に中断し、runtime未実行・不完全として原本を保持する。停止したのは当該process treeだけで、無関係なmoyuのbuildは停止していない。修復後のreverse62では、最初のlibrary catalogがplayer-web testの破損PDBによるLNK1285で終了101となりruntime未実行だった。独立したCLI 191＋29件のPASSは保持し、診断で指定されたPDB一ファイル578,023,424 bytesだけを削除してlibrary群を再試行した。失敗、再生成、同一Source・同一選択の照合と最終runtimeを別記し、古い失敗を成功へ書き換えていない。

同じ修復後{1:N0}入力の通常reverse62はlibrary／integration {2:N0} PASS、CLI lib／bin {3} PASS、通常CLI integration {4} PASS。追加CLI checkは別commandで{5} PASS／{6} FAIL／{7} ignored。各群のfeature union・case catalog・binary pin・終端・source hashを別記し、ownerと重複する件数を足さない。通常6 CLI integrationとcheckだけでは、bracket_numeric_batch、environment_callable_tensor、native_host_contractsの3 targetが未選択だったため、追加実行して現行metadataの全testable CLI targetと照合した。Generic Matchの既受入151 IDはすべて選択・実行し151 PASS・除外0を照合した。今回のhandle回帰や全体goalの未完了でGeneric Matchの受入を戻していない。workspace check・Clippy・fmt12 path・構造gateは終了0。詳細、警告、全SHA、停止・失敗・修復と生の記録は[検証原本](acceptance-evidence/task-presentation-shared-identities-validation.json)を参照。

現状一覧のCLI行に残っていたSource 1bf138d190c826841935b38bf01c3048fb43c3cbの「CLI全692・649 PASS／43 FAIL」は、その入力の履歴であり、現在Sourceの検証根拠としていた説明が誤りなので削除した。さらに古いc3b6ea79a7b16674ed0cbcd644b9e7bdd6c95030の同件数とともに、[C6原本](acceptance-evidence/task-nominal-c6-reverse-acceptance.json)、[scope原本](acceptance-evidence/task-presentation-awbc-scopes-reverse-acceptance.json)を保持する。共有引数role／resource型の以前の公開0b5ac5491d245a5386ca1b44547091e50bcb1955、fb04fd878622fac57a22db7e2c005ee6daa829eaとその検証も維持する。現在値の重複を避けるため最新の対象別件数を現状一覧の横断表にまとめた。以前の4,033入力・Core reverse53・doctest78・Wasm compileを、今回の4,036入力・interaction-model reverse62の実行へ合算しない。Source Presentation実行・`mount(ViewValue)`・実driver接続の完成とはしていない。
'@
$addition = $addition -f $source, $inputs, $lib.passed, $unit.passed, $integration.passed, $check.passed, $check.failed, $check.skipped
[IO.File]::AppendAllText($historyPath, $addition + ([string][char]10), $encoding)
$after = [IO.File]::ReadAllBytes($historyPath)
$prefixStream = [IO.MemoryStream]::new($after, 0, $before.Length, $false)
try { $prefixHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefixStream)).ToLowerInvariant() } finally { $prefixStream.Dispose() }
if ($prefixHash -ne $beforeHash) { throw 'Historical byte prefix changed' }
[ordered]@{ version = 1; base = $source; beforeBytes = $before.Length; beforeSha256 = $beforeHash; retainedPrefixSha256 = $prefixHash; prefixPreserved = $true; afterBytes = $after.Length; changedStatusRows = $superseded.Count } | ConvertTo-Json | Set-Content -LiteralPath "$taskTemp/presentation-shared-identity.history-prefix.json" -Encoding utf8
