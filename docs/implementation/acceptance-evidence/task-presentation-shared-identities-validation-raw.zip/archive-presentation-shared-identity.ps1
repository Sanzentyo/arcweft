$ErrorActionPreference = 'Stop'
Set-Location D:/git/arcweft
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$evidenceRoot = Join-Path $PWD 'docs/implementation/acceptance-evidence'
$name = 'task-presentation-shared-identities-validation'
$owner = 'presentation-shared-identity-owner-20261101a'
$quality = [IO.File]::ReadAllText("$taskTemp/product-execution-quality.active.txt")
$reverse = 'presentation-shared-identity-repaired-reverse-20261101'
$cli = 'presentation-shared-identity-repaired-full-cli-20261101'
function Read-Record([string]$stem) { Get-Content -LiteralPath "$taskTemp/$stem.json" -Raw | ConvertFrom-Json -Depth 100 }
$published = Read-Record 'presentation-shared-identity-generic-repair-source.verified'
if ((git rev-parse HEAD).Trim() -ne $published.commit) { throw 'Source publication changed' }
$ownerTerminal = Read-Record "$owner.runtime.terminal-audit"
$repairTerminal = Read-Record 'presentation-shared-identity-generic-repair-20261101.runtime.terminal-audit'
$negativeTerminal = Read-Record 'presentation-shared-identity-generic-negative2-20261101.runtime.terminal-audit'
if ($repairTerminal.passed -ne 2 -or $repairTerminal.failed -ne 0 -or $negativeTerminal.failed -ne 1) { throw 'Generic Handle regression/repair evidence differs' }
$normal = Read-Record "$reverse.final-matrix"
$extended = Read-Record "$cli.matrix"
$generic = Read-Record "$reverse.generic-coverage"
$comparison = Read-Record "$cli.cli-comparison"
if ($normal.status -ne 'terminal' -or $extended.status -ne 'terminal') { throw 'A runtime handle is not terminal' }
$qualityRows = @(foreach ($kind in @('workspace-check', 'clippy', 'structure', 'fmt')) {
    $record = Read-Record "$quality.$kind"
    if ($record.exitCode -ne 0 -or $record.sourceDrift -ne 0) { throw "Quality did not pass: $kind" }
    [pscustomobject]@{ check = $kind; record = "$quality.$kind.json"; exitCode = $record.exitCode; sourceInputs = $record.sourceInputs; sourceDrift = 0 }
})
foreach ($row in @($normal.rows) + @($extended.rows)) {
    if ($row.catalogExit -ne 0 -or $null -eq $row.terminal -or $row.terminal.catalogCaseDrift -ne 0 -or $row.terminal.sourceDrift -ne 0) { throw 'A runtime row is not audited' }
}
if ($generic.selected -ne 151 -or $generic.passed -ne 151 -or $generic.failed -ne 0) { throw 'Accepted Generic inventory is not passing' }
$freeze = Read-Record "$quality.source-freeze"
foreach ($row in $freeze.paths) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
}
$stems = @('presentation-shared-identity')
$files = @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
    $file = $_
    @($stems | Where-Object { $file.Name.StartsWith($_, [StringComparison]::Ordinal) }).Count -gt 0
})
$scripts = @('run-shared-identity-owner.ps1', 'run-presentation-shared-identity-quality.ps1', 'run-presentation-shared-identity-reverse.ps1', 'run-presentation-shared-identity-full-cli.ps1', 'audit-presentation-shared-identity-generic.ps1', 'audit-presentation-shared-identity-cli.ps1', 'run-presentation-shared-identity-repaired-reverse.ps1', 'run-presentation-shared-identity-repaired-full-cli.ps1', 'audit-presentation-shared-identity-repaired-generic.ps1', 'audit-presentation-shared-identity-repaired-cli.ps1', 'audit-presentation-shared-identity-all-cli.ps1', 'run-presentation-shared-identity-library-retry.ps1', 'recover-presentation-player-web-pdb.ps1', 'finalize-presentation-shared-identity-reverse.ps1', 'audit-nextest-final-result.ps1', 'archive-presentation-shared-identity.ps1', 'update-presentation-shared-identity-docs.ps1', 'migrate-presentation-role.ps1', 'migrate-presentation-callables.ps1')
$files += @(foreach ($script in $scripts) { Get-Item -LiteralPath "$taskTemp/$script" })
$files += @(Get-Item -LiteralPath "$taskTemp/presentation-shared-identity.ownership.json")
$reportDirectory = Get-Item -LiteralPath "$taskTemp/$quality.structure-report"
$files += @(Get-ChildItem -LiteralPath $reportDirectory.FullName -Recurse -File)
$files += @(Get-ChildItem -LiteralPath "$taskTemp/presentation-shared-identity-negative1-source" -File)
$files += @(Get-ChildItem -LiteralPath "$taskTemp/presentation-shared-identity-negative2-source" -File)
$files += @(Get-ChildItem -LiteralPath "$taskTemp/presentation-shared-identity-quality-20261031T203227961.structure-report" -File)
$files = @($files | Sort-Object FullName -Unique)
$entries = @(foreach ($file in $files) {
    $relative = [IO.Path]::GetRelativePath($taskTemp, $file.FullName).Replace([char]92, [char]47)
    if ($file.Extension -in @('.exe', '.dll', '.pdb', '.rlib', '.rmeta') -or $relative.StartsWith('target/')) { throw 'Build artifact is not source evidence' }
    [pscustomobject]@{ path = $relative; bytes = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant(); source = $file.FullName }
})
$zipPath = Join-Path $evidenceRoot "$name-raw.zip"
if (Test-Path -LiteralPath $zipPath) { throw 'Evidence archive already exists' }
$zip = [IO.Compression.ZipFile]::Open($zipPath, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($entry in $entries) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $entry.source, $entry.path, [IO.Compression.CompressionLevel]::Optimal) }
} finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    if ($zip.Entries.Count -ne $entries.Count) { throw 'Archive entry count differs' }
    foreach ($entry in $entries) {
        $stored = $zip.GetEntry($entry.path)
        if ($null -eq $stored -or $stored.Length -ne $entry.bytes) { throw 'Archive byte count differs' }
        $stream = $stored.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($hash -ne $entry.sha256) { throw 'Archive entry hash differs' }
    }
} finally { $zip.Dispose() }
$result = [ordered]@{
    version = 1
    recordedAt = [DateTime]::UtcNow.ToString('o')
    sourcePublication = $published
    initialIdentityPublication = Read-Record 'presentation-shared-identity-source.verified'
    inspectedSource = $published.commit
    sourceInputs = $freeze.paths.Count
    heldTrackedWip = 14
    heldUntrackedWip = 6
    sourceDrift = 0
    implementation = 'One shared vocabulary in interaction-model owns all 11 callable IDs, 6 handle method IDs, 51 argument roles, stable semantic tags, and callable resource/result ownership. Sema owns checked signature construction and value policies. Core does not depend on sema or retained View.'
    scopeLimit = 'This publishes the shared identity boundary. Source Presentation execution, mount(ViewValue), Core command evaluation and real driver migration are not claimed complete.'
    owner = $ownerTerminal
    ownerScope = 'Initial identity input only: 1363 interaction-model/sema cases. This run omitted the subsequently added generic Handle regression. Final reverse cases below are fresh on the repaired input.'
    regression = $negativeTerminal
    repairFocus = $repairTerminal
    repairScope = 'Five universal methods retain a generic Handle<T> receiver and selected identity. Pop succeeds for exact Overlay and is rejected for an open generic and all seven other resource families. No Generic Match acceptance is revoked.'
    interruptedReverse = Read-Record 'presentation-shared-identity-reverse-20261101.interrupted'
    failedLibraryBuildMatrix = Read-Record "$reverse.matrix"
    exactPdbRecovery = Read-Record 'presentation-shared-identity.pdb-recovery'
    retryCoverage = Read-Record 'presentation-shared-identity.retry-coverage'
    freshOwnerCoverage = Read-Record 'presentation-shared-identity.fresh-owner-coverage'
    fixtureCompileFailure = Read-Record 'presentation-shared-identity-generic-negative-20261101.fixture-compile'
    quality = $qualityRows
    ownership = Read-Record 'presentation-shared-identity.ownership'
    normalReverse = $normal
    extendedCli = $extended
    acceptedGenericMatch = $generic
    cliFailureComparison = $comparison
    completeCliTargetCoverage = Read-Record 'presentation-shared-identity.all-cli-coverage'
    isPassingCombinedRuntime = (@($normal.rows | Where-Object { $_.terminal.failed -ne 0 }).Count -eq 0 -and @($extended.rows | Where-Object { $_.terminal.failed -ne 0 }).Count -eq 0)
    countPolicy = 'Owner tests and reverse groups remain separate runs. Do not add overlapping owner cases to the reverse count or treat the CLI failures as passing.'
    archive = [ordered]@{ file = "$name-raw.zip"; bytes = (Get-Item -LiteralPath $zipPath).Length; sha256 = (Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant(); entries = @($entries | ForEach-Object { [pscustomobject]@{ path = $_.path; bytes = $_.bytes; sha256 = $_.sha256 } }); verifiedEntries = $entries.Count; entryDrift = 0 }
}
$result | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath (Join-Path $evidenceRoot "$name.json") -Encoding utf8
[pscustomobject]@{ source = $published.commit; inputs = $freeze.paths.Count; entries = $entries.Count; archiveBytes = (Get-Item -LiteralPath $zipPath).Length; ownerPassed = $ownerTerminal.passed; genericPassed = $generic.passed; overallRuntimePassing = $result.isPassingCombinedRuntime } | ConvertTo-Json -Compress
