#![allow(dead_code, unused_imports)]
#[path = "effect-streamed-formulas.dev01.baseline/effect_row.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/declaration.rs"]
mod declaration;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/membership.rs"]
mod membership;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/set.rs"]
mod set;

use arcweft_id::EffectId;
use std::collections::BTreeMap;

use decision::{DecisionControl, DecisionEncoding, DecisionWork, EffectDecision};
use declaration::EffectDeclarationError;
use membership::{EffectFormula, EffectPredicate, MembershipEncoding};
use set::EffectSet;
use current_control::EffectEqualityControl;

macro_rules! meter {
    ($kind:ident, $meter:ident, $work:ty, $control:path, $error:ty) => {
        #[derive(Default)]
        struct $meter { visits: usize, nodes: usize }
        impl $control for $meter {
            type Error = $error;
            fn charge(&mut self, work: $work) -> Result<(), Self::Error> {
                match work {
                    $kind::Visit => self.visits += 1,
                    $kind::Node => self.nodes += 1,
                }
                Ok(())
            }
        }
    };
}
use baseline::DecisionControl as _;
use baseline::DecisionWork as PriorWork;
meter!(PriorWork, Prior, baseline::DecisionWork, baseline::DecisionControl, baseline::EffectDeclarationError);
meter!(DecisionWork, Current, DecisionWork, DecisionControl, EffectDeclarationError);

fn main() {
    for count in [16, 256, 4096] {
        for (layout, period) in [("all-default", 0), ("sparse", 127), ("dense", 1)] {
            let labels: Vec<_> = (0..count).map(|index| {
                EffectId::parse(&format!("bench.label{index:04}")).unwrap()
            }).collect();
            let differs = |index| period != 0 && index % period == 0;

            let mut before = Prior::default();
            let old_default = baseline::EffectDecision::variable(0u8, &mut Prior::default()).unwrap();
            before.charge(PriorWork::Node).unwrap(); // Mapped defaults used a slot too.
            let mut mapped = Vec::new();
            for index in 0..count {
                before.charge(PriorWork::Node).unwrap();
                mapped.push(if differs(index) {
                    baseline::EffectDecision::constant(true)
                } else {
                    old_default.clone()
                });
            }
            let mut labels_before = BTreeMap::new();
            for (label, decision) in labels.iter().zip(mapped) {
                before.charge(PriorWork::Node).unwrap();
                labels_before.insert(label.clone(), decision);
            }
            let old = baseline::EffectFormula::try_from_decisions(old_default, labels_before, &mut before).unwrap();

            let mut after = Current::default();
            let default = EffectDecision::variable(0u8, &mut Current::default()).unwrap();
            let mut builder = EffectFormula::builder(default.clone(), &mut after).unwrap();
            for (index, label) in labels.iter().enumerate() {
                let decision = if differs(index) { EffectDecision::constant(true) } else { default.clone() };
                builder.set(label, decision, &mut after).unwrap();
            }
            after.charge(DecisionWork::Node).unwrap(); // The completed function map entry.
            let current = builder.finish();
            assert_eq!(format!("{old:?}"), format!("{current:?}"));
            assert!(after.nodes < before.nodes);
            println!(
                "labels={count} input={layout} overrides={} visits={}->{} nodes={}->{}",
                current.membership().overrides().len(), before.visits, after.visits,
                before.nodes, after.nodes,
            );
        }
    }
}
mod current_control { use super::*;
pub(super) struct EffectEqualityControl<'a, C>(pub(super) &'a mut C);

impl<V, C: DecisionControl> DecisionEncoding<V> for EffectEqualityControl<'_, C> {
    type Error = C::Error;

    fn tag(&mut self, _: u8) -> Result<(), Self::Error> {
        self.0.charge(DecisionWork::Visit)
    }

    fn count(&mut self, _: usize) -> Result<(), Self::Error> {
        self.0.charge(DecisionWork::Visit)
    }

    fn variable(&mut self, _: &V) -> Result<(), Self::Error> {
        self.0.charge(DecisionWork::Visit)
    }
}

impl<V, C: DecisionControl> MembershipEncoding<V> for EffectEqualityControl<'_, C> {
    fn effect(&mut self, _: &arcweft_id::EffectId) -> Result<(), Self::Error> {
        self.0.charge(DecisionWork::Visit)
    }
}
}
