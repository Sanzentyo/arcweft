$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$pin=Get-Content -Raw -LiteralPath "$root\predicate-extension.final-input.json"|ConvertFrom-Json
$list=Get-Content -Raw -LiteralPath "$root\predicate-extension.owner-list.json"|ConvertFrom-Json -Depth 80
$events=@(Get-Content -LiteralPath "$root\predicate-extension.owner-nextest.jsonl"|ForEach-Object {$_|ConvertFrom-Json -Depth 25})
$selected=@(foreach($suite in $list.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Value.'package-name'+'::'+$suite.Value.'binary-name'+'$'+$case.Name}}})
$terminal=@($events|Where-Object {$_.type -eq 'test' -and $_.event -in @('ok','failed','ignored')})
if($selected.Count -ne 1563 -or $terminal.Count -ne $selected.Count){throw 'Owner counts disagree'}
if(@($selected|Group-Object|Where-Object Count -gt 1).Count -ne 0 -or @($terminal|Group-Object name|Where-Object Count -gt 1).Count -ne 0){throw 'Duplicate IDs'}
if(@(Compare-Object -CaseSensitive ($selected|Sort-Object) ($terminal.name|Sort-Object)).Count -ne 0){throw 'Selected and terminal IDs differ'}
$failures=@($terminal|Where-Object event -eq 'failed'|ForEach-Object name|Sort-Object)
$previous=Get-Content -Raw -LiteralPath "$root\principal-observation.owner-summary.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $previous.Failures $failures).Count -ne 0){throw 'Failure IDs changed'}
$new=@($terminal|Where-Object {$_.name.Contains('$effect_row::prepared::closure::observation::predicate_tests::')})
if($new.Count -ne 5 -or @($new|Where-Object event -ne 'ok').Count -ne 0){throw 'New predicate tests failed'}
$oracle=@($terminal|Where-Object {$_.name.EndsWith('$effect_row::prepared::closure::observation::tests::global_boolean_guards_match_exhaustive_finite_sets_with_distinct_unnamed_labels')})
if($oracle.Count -ne 1 -or $oracle[0].event -ne 'ok'){throw 'Strengthened independent oracle failed'}
if(@($terminal|Where-Object {$_.name.Contains('t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once') -and $_.event -eq 'ok'}).Count -ne 1){throw '256-candidate boundary failed'}
$summaries=@($events|Where-Object {$_.type -eq 'suite' -and $_.event -in @('ok','failed')})
if($summaries.Count -ne 5 -or ($summaries|Measure-Object passed -Sum).Sum -ne 1557 -or ($summaries|Measure-Object failed -Sum).Sum -ne 6 -or @($terminal|Where-Object event -eq 'ignored').Count -ne 0){throw 'Suite summaries disagree'}
$receipt=Get-Content -Raw -LiteralPath "$root\predicate-extension.owner-receipt.json"|ConvertFrom-Json
$quality=Get-Content -Raw -LiteralPath "$root\predicate-extension.quality.json"|ConvertFrom-Json
if($receipt.RunExit -ne 100 -or $receipt.Tree -ne $pin.Tree -or $quality.Tree -ne $pin.Tree -or $quality.ClippyExit -ne 0 -or $quality.FmtExit -ne 0 -or $quality.StructureExit -ne 0){throw 'Receipt mismatch'}
foreach($source in $pin.Sources){if((Get-FileHash -LiteralPath (Join-Path 'D:\git\arcweft' $source.Path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $source.SHA256){throw 'Source changed'}}
$log=Get-Content -Raw -LiteralPath "$root\predicate-extension.owner-nextest.stderr.log"
$duration=[regex]::Match($log,'Summary \[\s*([0-9.]+)s\] 1563 tests run: 1557 passed, 6 failed, 0 skipped')
if(-not $duration.Success){throw 'Human summary disagrees'}
@{Version=1;Base=$pin.Base;Tree=$pin.Tree;Selected=1563;Passed=1557;Failed=6;Skipped=0;Suites=5;NewTests=$new;StrengthenedFiniteSetOraclePassed=$true;FailureIdsUnchanged=$true;Failures=$failures;SelectedIdsEqualTerminalIds=$true;DuplicateIds=0;Candidate256Passed=$true;VerifiedSources=$pin.Sources.Count;ExecutionSeconds=[double]::Parse($duration.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Audited=(Get-Date).ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$root\predicate-extension.owner-summary.json" -Encoding utf8
Get-Content -LiteralPath "$root\predicate-extension.owner-summary.json" -First 12
