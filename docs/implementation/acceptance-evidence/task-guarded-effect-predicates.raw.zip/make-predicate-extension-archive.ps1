$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$publication=Get-Content -Raw -LiteralPath "$root\predicate-extension.publication.json"|ConvertFrom-Json
$summary=Get-Content -Raw -LiteralPath "$root\predicate-extension.owner-summary.json"|ConvertFrom-Json
if($summary.Tree -ne $publication.Tree -or $summary.Selected -ne 1563 -or -not $summary.FailureIdsUnchanged -or -not $summary.SelectedIdsEqualTerminalIds){throw 'Owner audit incomplete'}
$files=[Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File|Where-Object {
    ($_.Name.StartsWith('predicate-extension.') -or $_.Name -in @('audit-predicate-extension.ps1','make-predicate-extension-archive.ps1')) -and
    $_.Name -notin @('predicate-extension.manifest.json','predicate-extension.archive.json','predicate-extension.docs-audit.json','predicate-extension.docs-publication.json')
}|Sort-Object Name|ForEach-Object {$files.Add(@{name=$_.Name;path=$_.FullName})}
$manifest=[ordered]@{
    version=1;source=$publication.Source;tree=$publication.Tree;base=$publication.Parent
    phases=@(
        @{name='initial-check';exit=0;note='Initial all-target/all-feature Sema check before new regressions; separate source input and patch retained.'},
        @{name='test-helper-check';exit=101;selected=0;note='The new independent test oracle called private evaluate twice; repaired using the existing controlled public evaluation API. Patch, hashes, byte-exact new test source and diagnostics retained.'},
        @{name='focused';selected=66;passed=66;failed=0;exit=0;note='Source hashes agree with final inputs; not added to full-owner counts.'},
        @{name='full-owner';selected=1563;passed=1557;failed=6;skipped=0;exit=100;seconds=$summary.ExecutionSeconds;note='All five new tests, strengthened finite-set oracle, prior original-binding tests and 256-candidate boundary passed. Six actual failure IDs remain unchanged.'}
    )
    commands=@('CARGO_INCREMENTAL=0 cargo nextest list --locked -p arcweft-lang-sema --all-features --message-format json','CARGO_INCREMENTAL=0 NEXTEST_EXPERIMENTAL_LIBTEST_JSON=1 cargo nextest run --locked -p arcweft-lang-sema --all-features --no-tests fail --no-fail-fast --message-format libtest-json --message-format-version 0.1','CARGO_INCREMENTAL=0 cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features','CARGO_INCREMENTAL=0 cargo fmt --all --check','CARGO_INCREMENTAL=0 just structure-audit-gate')
    files=@($files|ForEach-Object {$item=Get-Item -LiteralPath $_.path;@{name=$_.name;bytes=$item.Length;sha256=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant()}})
}
$manifest|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$root\predicate-extension.manifest.json" -Encoding utf8
$files.Add(@{name='manifest.json';path="$root\predicate-extension.manifest.json"})
$archivePath='D:\git\arcweft\docs\implementation\acceptance-evidence\task-guarded-effect-predicates.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive exists'}
$zip=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.path,$file.name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    if($zip.Entries.Count -ne $files.Count){throw 'Entry count mismatch'}
    foreach($file in $files){
        $entry=$zip.GetEntry($file.name);$item=Get-Item -LiteralPath $file.path
        if($null -eq $entry -or $entry.Length -ne $item.Length){throw 'Entry length mismatch'}
        $stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -ne (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Entry hash mismatch'}
    }
    $raw=($zip.Entries|Measure-Object Length -Sum).Sum
}finally{$zip.Dispose()}
$archive=Get-Item -LiteralPath $archivePath
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=$files.Count;RawBytes=$raw;Bytes=$archive.Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();EveryEntryVerified=$true}|ConvertTo-Json|Set-Content -LiteralPath "$root\predicate-extension.archive.json" -Encoding utf8
Get-Content -LiteralPath "$root\predicate-extension.archive.json"
