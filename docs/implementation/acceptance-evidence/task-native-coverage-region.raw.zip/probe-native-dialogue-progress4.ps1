$ErrorActionPreference='Stop'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$old=Get-Content -LiteralPath (Join-Path $t 'probe-native-dialogue-progress.ps1') -Raw
$script=$old.Replace("$"+"stem='native-dialogue-progress-probe1'","$"+"stem='native-dialogue-progress-probe4'")
$script=$script.Replace('$index -lt 20','$index -lt 80')
$script=$script.Replace("  [ordered]@{index=`$index;tick=`$report.tick;frame=`$report.frame_id;lines=`$lines;actions=@(`$report.actions).Count} | ConvertTo-Json -Compress", "  [ordered]@{index=`$index;tick=`$report.tick;frame=`$report.frame_id;text=@(`$report.objects | Where-Object role -eq dialogue_view | ForEach-Object text);actions=@(`$report.actions).Count} | ConvertTo-Json -Depth 10 -Compress")
$script=$script.Replace("  if(`$lines -contains 'say.full.005'){break}","  if(@(`$report.objects | Where-Object {`$_.role -eq 'dialogue_view' -and `$_.text.TrimStart().StartsWith('推論:')}).Count -gt 0){break}")
$script=$script.Replace("  `$null=Rpc 'tools/call' @{name='arcweft.action';arguments=@{kind='advance_text'}}", "  if(@(`$report.actions | Where-Object {`$_.action -eq 'advance_text' -and `$_.enabled}).Count -gt 0){`n   `$null=Rpc 'tools/call' @{name='arcweft.action';arguments=@{kind='advance_text'}}`n  } else {`n   `$null=Rpc 'tools/call' @{name='arcweft.session.step_frames';arguments=@{count=4}}`n  }")
Invoke-Expression $script

