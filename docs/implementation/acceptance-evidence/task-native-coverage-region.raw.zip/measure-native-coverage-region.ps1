$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. (Join-Path $t 'convergence-image-git-bytes.ps1')
$prefix='checkpoint-native-coverage-region-20261106'
$prepared=Get-Content -LiteralPath (Join-Path $t ($prefix+'.prepared.json')) -Raw | ConvertFrom-Json
$metadata=Get-Content -LiteralPath (Join-Path $t 'rag-project-summary.metadata.json') -Raw | ConvertFrom-Json -Depth 100
$workspace=@{};foreach($p in $metadata.packages){if($p.id -in $metadata.workspace_members){$workspace[$p.id]=$p.name}}
$edges=@(foreach($n in $metadata.resolve.nodes){if(-not $workspace.ContainsKey($n.id)){continue};foreach($dep in $n.deps){if($workspace.ContainsKey($dep.pkg)){[pscustomobject]@{from=$workspace[$n.id];to=$workspace[$dep.pkg]}}}})
$files=@(foreach($row in $prepared.paths){
 $path=$row.path
 [byte[]]$old=[byte[]]::new(0)
 if(@(git ls-tree --name-only $prepared.base -- $path).Count){$old=Read-GitBytes @('show',($prepared.base+':'+$path))}
 $oldText=[Text.Encoding]::UTF8.GetString($old)
 $text=[IO.File]::ReadAllText((Join-Path $PWD $path))
 $owner=if($path.StartsWith('crates/')){($path -split '/')[1]}else{'maintained Native capture contract'}
 $class=if($path.EndsWith('.md')){'maintained specification'}elseif($path.Contains('/tests/') -or $path.EndsWith('/tests.rs') -or $path.EndsWith('/crop_tests.rs') -or $path.EndsWith('/full_grammar.rs')){'test'}else{'production'}
 [ordered]@{path=$path;owner=$owner;classification=$class;bytes=(Get-Item -LiteralPath $path).Length;loc=([regex]::Matches($text,"`n")).Count;baseBytes=$old.Length;baseLoc=([regex]::Matches($oldText,"`n")).Count;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();stagedBlob=$row.blob;workspaceFanIn=@($edges | Where-Object to -eq $owner | Select-Object -ExpandProperty from -Unique).Count;workspaceFanOut=@($edges | Where-Object from -eq $owner | Select-Object -ExpandProperty to -Unique).Count}
})
$record=[ordered]@{
 version=1;base=$prepared.base;tree=$prepared.tree;patchSha256=$prepared.patchSha256;files=$files
 graph='native-coverage-region.reverse-selection.json; actual retained all-feature resolve, normal/build/dev;101Cargo/toolchain pins0;6complete reverse packages'
 ownership='Offscreen owns typed selection/raster extent, admission/budget and ordered stamping; its budget and GPU comparison tests remain responsibility children. Renderer coverage borrows the canonical ViewCompositorTarget and original painter/font state; no second renderer or public API added. ViewScene derives local/nonlocal behavior only from the selected text ancestry, cached once per item during capture admission. ViewCompositor trims historical root extents per frame so varying crop sizes do not accumulate GPU targets. Existing >1200LOC Offscreen/Renderer/Compositor owners remain cohesive in request/admission, GPU submission and compositor pass scheduling; the new crop submission has its own actual rendering responsibility module. No facade widening for a physical split. Native binds the admitted frame/catalog and omits blank raster work; unit raw attachment readback and MCP PNG progression exercise their actual different publication boundaries. The existing large integration file keeps only the geometry/progression consumer change; unrelated Scroll WIP remains unstaged.'
 geometryReason='Current checked-in multiline source preserves leading LF (ranges28..64/67..72), and standard_view.rs declares25px font/34px lineheight. Actual frame55 has152x101 run and26x26 cells; exact assertions replace retired30px/oldmin120 geometry, while typed style/source identity/strictJLREQ/sidewaysLatin/verticalLR and positive mask/object-ID/tint reads remain tested. Raw positive3reads move to real retained Native frame, because mandatory MCP publication withholds non-color resources; policy remains unchanged.'
 state='Original12tracked/6untracked WIP participates in tests. Only the owned native_samples hunks are staged; original Scroll WIP replay is proven in native-coverage-region.preservation-proof.json. Raw private full snapshots/original-user.patch must not be archived.'
}
$record | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $t 'native-coverage-region-owner-measurements.json') -Encoding utf8
$bytes=0;$loc=0;foreach($file in $files){$bytes+=$file.bytes;$loc+=$file.loc}
[ordered]@{base=$record.base;paths=$files.Count;bytes=$bytes;loc=$loc} | ConvertTo-Json
