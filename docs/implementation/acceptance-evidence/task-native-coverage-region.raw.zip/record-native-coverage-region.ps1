$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$audit=Read-Record 'native-coverage-region-reverse6-20261106.consumer-audit'
$tier2=Read-Record 'native-coverage-region-tier2-20261106.runtime.terminal-audit'
$wasm=Read-Record 'native-coverage-region-wasm1-20261106'
$owner=Read-Record 'native-coverage-region-owner6-20261106.runtime.terminal-audit'
if($audit.failureComparison.newFailureIds.Count -or $audit.nonCli.failed -or $tier2.passed -ne 7 -or $tier2.failed -or $wasm.exitCode -or $owner.passed -ne 1){throw 'Repair new failures before recording this boundary complete'}
$quality=[ordered]@{}
foreach($name in @('check','clippy','structure')){$q=Read-Record ('native-coverage-region-quality1-20261106-'+$name);if($q.exitCode){throw 'Quality failure'};$quality[$name]=$q}
$quality.format=Read-Record 'native-coverage-region-format1-20261106'
if($quality.format.exitCode){throw 'Format failure'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('nativeCoverageRegion')){throw 'Existing result; preserve immutable evidence'}
$before=$record | ConvertTo-Json -Depth 100 -Compress
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 $_.Name.StartsWith('native-coverage-region-') -or $_.Name.StartsWith('native-blank-coverage-owner1-') -or $_.Name.StartsWith('native-dialogue-progress-probe3.') -or $_.Name.StartsWith('native-dialogue-progress-probe4.') -or $_.Name.StartsWith('checkpoint-native-coverage-region-20261106.')
})
$files+=@(Get-Item -LiteralPath (Join-Path $t 'native-coverage-region.reverse-selection.json'),(Join-Path $t 'native-coverage-region.preservation-proof.json'),(Join-Path $t 'record-native-coverage-region.ps1'),(Join-Path $t 'audit-native-coverage-reverse.ps1'),(Join-Path $t 'run-native-coverage-matrix.ps1'),(Join-Path $t 'run-native-coverage-owner.ps1'),(Join-Path $t 'run-action-payload-quality.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'measure-native-coverage-region.ps1'),(Join-Path $t 'prepare-native-coverage-preservation.ps1'),(Join-Path $t 'probe-native-dialogue-progress.ps1'),(Join-Path $t 'probe-native-dialogue-progress2.ps1'),(Join-Path $t 'probe-native-dialogue-progress3.ps1'),(Join-Path $t 'probe-native-dialogue-progress4.ps1'))
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'native-coverage-region-quality1-20261106.structure-report') -File)
if(@($files | Where-Object {$_.Name -like '*head-after.rs' -or $_.Name -like '*original-held*' -or $_.Name -like '*original-user*'}).Count){throw 'Private held source must not be archived'}
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-native-coverage-region.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record.nativeCoverageRegion=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=Read-Record 'checkpoint-native-coverage-region-20261106.verified'
 ownership=Read-Record 'native-coverage-region-owner-measurements';graph=Read-Record 'native-coverage-region.reverse-selection';preservation=Read-Record 'native-coverage-region.preservation-proof'
 owner=[ordered]@{blank=Read-Record 'native-blank-coverage-owner1-20261106.runtime.terminal-audit';combinedBeforeFinalFixtureRepair=Read-Record 'native-coverage-region-owner5-20261106.runtime.terminal-audit';finalRaw=$owner;scope='Owner5 actual33run32PASS1registrar-fixtureFAIL includes public MCP005geometry/PNG and the real9configuration GPU exact alpha parity. Only the new raw fixture then gains the ordinary CLI desktop registrar; owner6 is a separate1PASS, not a fabricated fresh33/33. The full reverse run below executes the final regular owner cases; GPU production/test bytes are unchanged from the retained parity pass.'}
 quality=$quality;reverse=$audit;tier2=$tier2;wasm=$wasm
 attempts=[ordered]@{
  owner1=Read-Record 'native-coverage-region-owner1-20261106.runtime.terminal-audit';owner2=Read-Record 'native-coverage-region-owner2-20261106.runtime.terminal-audit';ignoredInventoryCorrection=Read-Record 'native-coverage-region-owner2-20261106.catalog.inventory-correction';owner3=Read-Record 'native-coverage-region-owner3-20261106.runtime.terminal-audit';owner4=Read-Record 'native-coverage-region-owner4-20261106.catalog'
  reason='Preserve first MCP image read privacy rejection, next wrong helper image.mime_type assertion, and the legitimate non-color MCP publication rewrite/withholding. Keep mandatory publication policy unchanged; move all3 positive Mask/ObjectId reads to the actual retained Native frame owner. Owner4 E0599 was an extra iter() on an Iterator; no runtime began. Owner5 omitted the ordinary desktop registrar and was repaired in owner6. An explicit --run-ignored all catalog projected31 instead32 by overriding ignored=true; reconstruct the inventory from the original filter-match authority, preserve old projection/correction and actual31PASS1FAIL terminal. Its wrapper audit raced the correction and returned1; the original Cargo runtime is100, and the manual exact terminal audit succeeds with Source/case/executable drift0.'
 }
 probes=[ordered]@{blankInsufficient=Read-Record 'native-dialogue-progress-probe3.receipt';boundedProgress=Read-Record 'native-dialogue-progress-probe4.receipt';scope='Blank pruning alone still exceeded67276800 versus66355200 root pixels. Final actual public MCP4steps/128max_ops progression reaches005 at tick55; no extra execution budget, invented aggregate observation or reconstructed capture.'}
 behavior='One typed Region/Frame coverage extent is admitted once per prepared item from its evaluated paint and actual selected painter ancestry. Local glyph coverage uses a crop-sized canonical compositor target, original frame coordinates/font/raster scale and painter order. Item/ancestor nonlocal effects retain full-frame input. Budget charges actual root target pixels and padded readback; existing128pass/66355200rootpixel/64MiB readback limits are unchanged. Blank glyphs preserve layout advance/bounds without a zero-ink pass. The compositor retains only the current root extent/format across frames, avoiding historical crop-sized GPU targets.'
 correctionReason='The maintained standard DialogueView already declares25px/34px, while the current sample retains leadingLF. Correct Source005 ranges27..63 to28..64 and66..71 to67..72; enforce exact152x101 run and26x26 cells plus typed style, strictJLREQ, sideways Latin and verticalLR. Retain all3 positive raw Mask/ObjectId URI/metadata/size/alpha/tint checks at the same issued Native frame. MCP tests keep real progress and actual PNG pixels, with resource-level MIME and authorized fixture privacy reads. These replace stale producer/transport expectations without relaxing geometry or publication policy. Full-grammar constructs/PNG integration conditions and other residual CLI failures remain separately incomplete. Generic Match and static style provenance remain accepted/public.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$cli=$audit.cli[0]
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| CLI全target照合 |')){
  '| Native prepared-textのcoverage負荷／同一frame readback | **当該描画・縦書き条件を修復・検証・公開済み** | Source cf674f51c2dd5169f2e5ee350e615b9b84ed14e6。実際のpaint／選択textの祖先からRegion／Frameを一度だけ決め、局所glyphは必要な物理領域へ描画する。非局所Fxは全frameを保持し、既存128 pass・66355200 root pixels・64MiB readback上限は維持する。9設定のGPU alpha完全一致、公開MCPで005へ進行したgeometry／PNGと、同じNative frameのMask／ObjectId正の3読取を検証。元の改行・標準25px／34pxに従う厳密な寸法へ訂正し、MCP公開policyを変更しない。[全実測・失敗・訂正理由・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
  '| CLI全target照合 | **最新の全'+$cli.executed+'実測は'+$cli.passed+' PASS／'+$cli.failed+' FAIL** | Source cf674f51c2dd5169f2e5ee350e615b9b84ed14e6。Rendererの実6逆依存run内でCLI全件を実行し、元10失敗との新規ID差分0、full-grammar縦書きgeometryがPASSとなった。残るIDは原本の終端に保持し、full-grammarの別2条件や他の未達へこの修復を流用しない。過去の703／693 PASS10 FAILを再計算せず履歴に残す。[終端・全ID・入力・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| Native MCP／scriptのフレーム進行 |')){
  $line.Replace('full-grammarの後続line005は別の描画上限条件が残る。','後続line005の描画・捕捉はcoverage行の受入へ集約する。')
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
  '| 共有契約／推移的逆依存matrix | **最新Renderer実6逆依存は'+$audit.terminal.executed+'実行／'+$audit.terminal.passed+' PASS／'+$audit.terminal.failed+' FAIL** | Source cf674f51c2dd5169f2e5ee350e615b9b84ed14e6、'+$audit.terminal.summary+'。CLI以外'+$audit.nonCli.executed+'件は全PASS、host buildのみのpackageをruntime実行と混同しない。Source4119／case／実行ファイルdrift0。Generic Matchは今回再実行せず、以前の151／151厳密照合・受入を維持する。静的style全30＋Semaの4824件終端を含む過去の実測は履歴へ保持する。[実graph・対象範囲・全実測](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
  '| workspace check／Clippy・fmt・構造gate | **Source cf674f51c2dd5169f2e5ee350e615b9b84ed14e6の全98 check／Clippy・構造gateは終了0。関連Tier2 7 PASS／wasm library check終了0** | 4119入力、all-target／all-feature／locked、警告は残る。prepared-textの関連ignored GPU 7件を実行し、wasm32 render-web／player-webはall-feature／locked library checkを実行した。これをブラウザ実行や最終Native-Web画像parityへ拡張しない。以前のdoctest3 PASSは当時のSourceの履歴として保持する。既存12 tracked／6 untrackedとScrollの未公開編集は保全済み。[測定・入力・実測・保全証明・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Bounded local coverage targets and current vertical sample frame

- Source cf674f51c2dd5169f2e5ee350e615b9b84ed14e6, parent dce4f3da5d64b6edce97fd01431d58e8fed2f260, tree ca2a0b61826e1eb8b984798a381ffc274c8ba500, owned16paths/875add92delete, patch136604eca7c42772751d524fd9c3335e0bbae6566014f09eff35884e1efc392a. Local glyph coverage draws into its actual physical crop; typed item/ancestor locality preserves full-frame samples for nonlocal paint. Original painter/font/scale and exact per-region alpha remain authoritative. Existing pass/root-pixel/padded-readback limits stay unchanged; historical crop-sized GPU pool targets are trimmed each frame. No throughput benchmark claim.
- Final actual6 reverse: $($audit.terminal.summary), exit$($audit.terminal.actualExitCode). CLI$($cli.executed)/$($cli.passed)PASS/$($cli.failed)FAIL, nonCLI$($audit.nonCli.executed)allPASS; new failure IDs0, full-grammar vertical geometry nowPASS. Source4119/case/executable drift0, original12tracked/6untrackedWIP participates. Workspace98 check/Clippy/structure exit0,warnings remain; relevant prepared-text ignoredTier2 7PASS; wasm32 render-web/player-web library check exit0. Not browser runtime or final Native-Web image parity. Generic Match151 is reused from the prior accepted strict replay, not a new run.
- Preserve every unsuccessful input: blank pruning11PASS alone still fails the real public probe's67276800-versus66355200 budget; cropped owner1/2/3 fail distinct MCP fixture assumptions, owner4catalog101(extra iter), owner5 33run32PASS/1missing-registrar fixtureFAIL. Repaired actual Native raw owner6 separately1PASS/6.446s; no invented fresh33/33. Owner5 also contains exact9configuration GPU crop/full-alpha parity and public MCP005 geometry/PNG PASS. Fix the explicit ignored-run catalog projection from actual raw filter-match authority, retaining original31projection/correction/manual32terminal and actual Cargo100.
- Current standard DialogueView25px/34px and preserved leadingLF establish the new exact Source ranges and152x101run/26x26cells. Keep typed style/source/strictJLREQ/sidewaysLatin/verticalLR, and migrate all3 positive Mask/ObjectId URI/alpha/tint reads to the real retained Native frame; mandatory MCP non-color withholding remains unchanged. Probe4 uses real4step/128op progress to005/tick55. Only owned integration hunks are published: replay original Scroll WIP onto the clean candidate and match the complete normalized working source, other11held hashes unchanged. Residual patch8cee4393701fe3faf2cecdd2ef3bb9ced95bdadb824d6630a9193a24605cad0a replaces only index/offset identity of original450c9a0d35f590fa234046cddf9c11acd60e7bf9072569f1c4a3b87cb39f6b5b; no user content discarded or staged. Keep raw full-user snapshots private.
- [Exact source/proofs/all attempts/verified raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md). Full-grammar's separate constructs/PNG conditions and other CLI failures remain incomplete; no completed feature is reopened because the global goal continues.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$after.Remove('nativeCoverageRegion')
if(($after|ConvertTo-Json -Depth 100 -Compress) -ne $before){throw 'Prior evidence changed'}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{source='cf674f51c2dd5169f2e5ee350e615b9b84ed14e6';raw=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'native-coverage-region-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'native-coverage-region-documentation-audit.json')
