$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$epoch='native-coverage-region-owner6-20261106'
$owner=Get-Content -LiteralPath (Join-Path $t ($epoch+'.runtime.terminal-audit.json')) -Raw | ConvertFrom-Json
if($owner.executed -ne 1 -or $owner.passed -ne 1 -or $owner.failed){throw 'Repair owner before matrix'}
& (Join-Path $t 'run-action-payload-quality.ps1') -Epoch $epoch -Stem 'native-coverage-region-quality1-20261106'
$freeze=Get-Content -LiteralPath (Join-Path $t ($epoch+'.source-freeze.json')) -Raw | ConvertFrom-Json
$graph=Get-Content -LiteralPath (Join-Path $t 'native-coverage-region.reverse-selection.json') -Raw | ConvertFrom-Json
$selection=@();foreach($package in $graph.selection){$selection+=@('-p',$package)}
$selection+=@('--all-targets','--all-features','--locked')
& (Join-Path $t 'run-native-coverage-owner.ps1') -Stem 'native-coverage-region-reverse6-20261106' -Selection $selection -ExpectedMatches -1 -AdditionalPaths @($freeze.paths.path)
$reverse=$LASTEXITCODE
if($reverse -notin @(0,100)){throw 'Reverse did not reach a valid terminal'}
& (Join-Path $t 'run-native-coverage-owner.ps1') -Stem 'native-coverage-region-tier2-20261106' -Selection @('-p','arcweft-render-wgpu','--all-targets','--all-features','--locked','--run-ignored','only','-E','binary(=prepared_text)') -ExpectedMatches 7 -AdditionalPaths @($freeze.paths.path)
if($LASTEXITCODE){throw 'Relevant prepared-text Tier2 failed'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source changed: '+$row.path)}}
$stem='native-coverage-region-wasm1-20261106'
if(Test-Path -LiteralPath (Join-Path $t ($stem+'.json'))){throw 'Preserve existing wasm receipt'}
$arguments=@('check','-p','arcweft-render-web','-p','arcweft-player-web','--lib','--target','wasm32-unknown-unknown','--all-features','--locked')
$started=[DateTime]::UtcNow.ToString('o')
& cargo @arguments *> (Join-Path $t ($stem+'.log'))
$code=$LASTEXITCODE
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source changed: '+$row.path)}}
[ordered]@{version=1;inputBase=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='wasm32 library check only; no browser runtime or final image parity claim'} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $t ($stem+'.json')) -Encoding utf8
if($code){throw 'Portable library check failed'}
