$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -Depth 100}
$stem='native-coverage-region-reverse6-20261106'
$terminal=Read-Record ($stem+'.runtime.terminal-audit')
$receipt=Read-Record ($stem+'.runtime')
$inventory=Read-Record ($stem+'.catalog.inventory')
$lines=[IO.File]::ReadAllLines($receipt.log)
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0){throw 'No complete terminal'}
$rows=if($terminal.caseRowSource -eq 'final-status-after-summary'){$lines[($summary+1)..($lines.Length-1)]}else{$lines[0..($summary-1)]}
$cases=@{}
foreach($line in $rows){if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
 $key=$Matches[2]+"`t"+$Matches[3]
 if($cases.ContainsKey($key)){throw 'Duplicate terminal case'}
 $cases[$key]=$Matches[1]
}}
if($cases.Count -ne $terminal.executed){throw 'Incomplete terminal rows'}
$packages=@(foreach($group in ($inventory.rows | Where-Object status -eq matches | Group-Object package)){
 $passed=0;$failed=0
 foreach($row in $group.Group){$key=$row.binary+"`t"+$row.test;if(-not $cases.ContainsKey($key)){throw 'Missing selected case'};if($cases[$key] -in @('PASS','SLOW')){$passed++}else{$failed++}}
 [ordered]@{package=$group.Name;executed=$group.Count;passed=$passed;failed=$failed}
})
$old=Read-Record 'native-session-frame-request-cli-full1-20261106.runtime.terminal-audit'
$oldFailures=@($old.failureSet | ForEach-Object {$_.binary+"`t"+$_.test} | Sort-Object)
$newFailures=@($terminal.failureSet | ForEach-Object {$_.binary+"`t"+$_.test} | Sort-Object)
$freeze=Read-Record ($stem+'.source-freeze')
$quality=Read-Record 'native-coverage-region-owner6-20261106.source-freeze'
$pins=@{};foreach($row in $quality.paths){$pins[$row.path]=$row.sha256}
foreach($row in $freeze.paths){if($pins[$row.path] -ne $row.sha256){throw 'Quality/runtime source mismatch'}}
if($pins.Count -ne $freeze.paths.Count){throw 'Quality/runtime input count mismatch'}
$nonCli=[ordered]@{executed=0;passed=0;failed=0}
foreach($row in $packages | Where-Object package -ne arcweft-cli){$nonCli.executed+=$row.executed;$nonCli.passed+=$row.passed;$nonCli.failed+=$row.failed}
$audit=[ordered]@{
 version=1;source='cf674f51c2dd5169f2e5ee350e615b9b84ed14e6';inputBase=$receipt.base;terminal=$terminal;packages=$packages
 cli=@($packages | Where-Object package -eq arcweft-cli);nonCli=$nonCli
 selection=Read-Record 'native-coverage-region.reverse-selection';hostBuildOnly=$terminal.noMatchingSelectedTests
 failureComparison=[ordered]@{referenceSource=$old.base;referenceRun=$old.run;oldFailureCount=$old.failed;currentFailureCount=$terminal.failed;newFailureIds=@($newFailures | Where-Object {$_ -notin $oldFailures});noLongerFailingIds=@($oldFailures | Where-Object {$_ -notin $newFailures});scope='Exact terminal binary/test IDs, not arithmetic recomputation of the prior CLI total.'}
 sourceInputs=$freeze.paths.Count;qualitySourceDrift=0
 genericMatch='Not replayed for this renderer/private CLI cut; last exact151/151 in contentStyleScopeReverse remains accepted/public. No sema/core source changed or new contradictory evidence.'
 workingTree='Original12tracked/6untracked WIP participates in frozen4119inputs; one owned integration geometry hunk is published separately with original Scroll WIP replay proof. This is not a pristine-tree test claim.'
}
$audit | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath (Join-Path $t ($stem+'.consumer-audit.json')) -Encoding utf8
[ordered]@{source=$audit.source;summary=$terminal.summary;cli=$audit.cli;nonCli=$nonCli;newFailureIds=$audit.failureComparison.newFailureIds;repairedIds=$audit.failureComparison.noLongerFailingIds;hostBuildOnly=$audit.hostBuildOnly;qualitySourceDrift=0} | ConvertTo-Json -Depth 8
