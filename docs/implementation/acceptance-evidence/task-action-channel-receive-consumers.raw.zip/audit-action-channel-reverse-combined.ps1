param([string]$Initial='action-channel-receive-reverse-normal1-20261103',[string]$Current='action-channel-receive-sema-reverse1-20261103')
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$output="$e/action-channel-receive-combined-coverage.json"
if(Test-Path -LiteralPath $output){throw 'Coverage already recorded'}
function Read-Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
function Final-Cases([string]$stem){
    $audit=Read-Receipt "$stem.runtime.terminal-audit";$rows=@{};$after=$false
    foreach($line in [IO.File]::ReadLines("$e/$stem.runtime.log")){
        if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
        if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
            $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test
            if($rows.ContainsKey($key)){throw 'Duplicate case'}
            $rows[$key]=[ordered]@{binary=$binary;test=$test;status=$status;run=$stem}
        }
    }
    if($rows.Count -ne $audit.executed -or $audit.sourceDrift -or $audit.catalogCaseDrift){throw 'Incomplete pinned terminal'}
    return $rows
}
$initialAudit=Read-Receipt "$Initial.runtime.terminal-audit"
$currentAudit=Read-Receipt "$Current.runtime.terminal-audit"
if($initialAudit.failed -ne 2 -or -not $currentAudit.isPassingRun){throw 'Diagnose actual terminals before combining'}
$oldFreeze=Read-Receipt "$Initial.source-freeze";$newFreeze=Read-Receipt "$Current.source-freeze"
$oldByPath=@{};foreach($row in $oldFreeze.paths){$oldByPath[$row.path]=$row}
if($oldFreeze.paths.Count -ne $newFreeze.paths.Count){throw 'Input set changed'}
$delta=@(foreach($row in $newFreeze.paths){
    if(-not $oldByPath.ContainsKey($row.path)){throw 'New unreviewed input'}
    if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Current input drift'}
    if($row.sha256 -ne $oldByPath[$row.path].sha256){[ordered]@{path=$row.path;before=$oldByPath[$row.path].sha256;after=$row.sha256}}
})
$expected=@('crates/arcweft-lang-sema/src/final_analysis/model.rs','crates/arcweft-lang-sema/src/final_analysis/statement_effects.rs','crates/arcweft-lang-sema/tests/ui/checked_statement_authorities_are_not_constructible.rs','crates/arcweft-lang-sema/tests/ui/checked_statement_authorities_are_not_constructible.stderr')
if(@(Compare-Object $expected @($delta.path)).Count){throw 'Unreviewed source delta'}
$graph=Read-Receipt 'action-channel-receive-sema-repair-graph'
foreach($row in $graph.graphInputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Graph input drift'}}
if((Get-FileHash -LiteralPath "$e/$($graph.metadata)").Hash.ToLowerInvariant() -ne $graph.metadataSha256){throw 'Metadata drift'}
$inventory=Read-Receipt "$Initial.catalog.inventory";$currentInventory=Read-Receipt "$Current.catalog.inventory"
$oldRows=Final-Cases $Initial;$newRows=Final-Cases $Current
$inside=@($inventory.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $graph.normalPackages})
$newSelected=@($currentInventory.rows|Where-Object status -eq matches)
if(@(Compare-Object @($inside|ForEach-Object {$_.binary+"`t"+$_.test}) @($newSelected|ForEach-Object {$_.binary+"`t"+$_.test})).Count){throw 'Affected case set differs'}
$outside=@($inventory.rows|Where-Object {$_.status -eq 'matches' -and $_.package -notin $graph.normalPackages})
$coverage=@{}
foreach($case in $newRows.Values){if($case.status -notin @('PASS','SLOW')){throw 'New failure'};$case['kind']='fresh-current-Sema-closure';$coverage[$case.binary+"`t"+$case.test]=$case}
foreach($case in $outside){$key=$case.binary+"`t"+$case.test;if(-not $oldRows.ContainsKey($key) -or $oldRows[$key].status -notin @('PASS','SLOW') -or $coverage.ContainsKey($key)){throw 'Invalid reused case'};$row=$oldRows[$key];$row['kind']='reused-outside-Sema-closure';$coverage[$key]=$row}
if($coverage.Count -ne $initialAudit.executed){throw 'Incomplete distinct coverage'}
$outsideBinaries=@($outside.binary|Sort-Object -Unique)
$pins=Read-Receipt "$Initial.binaries-before"
$reusedPins=@(foreach($pin in $pins){if($pin.binary -in $outsideBinaries){if((Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw 'Reused executable drift'};$pin}})
if($reusedPins.Count -ne $outsideBinaries.Count){throw 'Missing reused binary pins'}
$subsets=[ordered]@{}
foreach($name in @('genericMatch','view40','qualifiedAction11','referenceRegressions7')){
    $prior=Read-Receipt "entity-reference-types-$name";$notSelected=@()
    $observed=@(foreach($case in $prior.cases){$key=$case.binary+"`t"+$case.test;if(-not $coverage.ContainsKey($key)){$notSelected+=,$case;continue};$coverage[$key]})
    $subsets[$name]=[ordered]@{acceptedCases=@($prior.cases).Count;selected=$observed.Count;passed=$observed.Count;failed=0;fresh=@($observed|Where-Object kind -eq 'fresh-current-Sema-closure').Count;reused=@($observed|Where-Object kind -eq 'reused-outside-Sema-closure').Count;notSelectedInCoreClosure=$notSelected;cases=$observed}
}
$previous=Read-Receipt 'action-original-declaration-normal-coverage'
$identity=@(foreach($case in $previous.subsets.actionIdentity7.cases){$key=$case.binary+"`t"+$case.test;if(-not $coverage.ContainsKey($key)){throw 'Missing identity case'};$coverage[$key]})
$subsets['actionIdentity7']=[ordered]@{passed=$identity.Count;failed=0;cases=$identity}
$receiver=@($coverage.Values|Where-Object binary -eq 'arcweft-compiler::action_channel')
if($receiver.Count -ne 12){throw 'Source Action case set differs'}
$subsets['actionChannel12']=[ordered]@{passed=12;failed=0;cases=$receiver}
$value=[ordered]@{version=1;source='9a75564dc58d4c844f2c25a45958a1d081682934';initial=$initialAudit;current=$currentAudit;distinctCases=$coverage.Count;passed=$coverage.Count;failed=0;freshCases=$newRows.Count;reusedCases=$outside.Count;sourceInputs=$newFreeze.paths.Count;sourceDrift=0;caseDrift=0;compileOnly=$initialAudit.noMatchingSelectedTests;subsets=$subsets;reuseProof=[ordered]@{resolvedAffectedGraph='action-channel-receive-sema-repair-graph.json';changedInputs=$delta;unchangedInputs=$newFreeze.paths.Count-$delta.Count;graphInputDrift=0;reusedExecutableDrift=0;reusedExecutables=$reusedPins;reason='All four changed paths belong to Sema. Its complete resolved reverse closure is freshly re-executed; only passing cases in packages outside that closure are reused, with unchanged inputs and identical original executable hashes.'};cases=@($coverage.Values|Sort-Object binary,test);scope='Distinct coverage of the original normal52 Core reverse selection after a Sema-only repair;3398 fresh affected cases and3678 unchanged unaffected passes. This is not a single fresh7076-case pass. CLI is separately recorded. The initial two actual failures and targeted repair remain history.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $output -Encoding utf8
[ordered]@{distinctCases=$value.distinctCases;passed=$value.passed;fresh=$value.freshCases;reused=$value.reusedCases;reusedBinaries=$reusedPins.Count;subsets=@($subsets.Keys|ForEach-Object {[ordered]@{name=$_;passed=$subsets[$_].passed;fresh=$subsets[$_].fresh;reused=$subsets[$_].reused}})}|ConvertTo-Json -Depth 6
