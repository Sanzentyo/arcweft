param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$out="$e/$Stem.failure-comparison.json"
if(Test-Path -LiteralPath $out){throw 'Comparison already recorded'}
$baseline='action-original-declaration-reverse-cli1-20261103'
$before=Get-Content -LiteralPath "$e/$baseline.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 30
$after=Get-Content -LiteralPath "$e/$Stem.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 30
if($after.sourceDrift -or $after.catalogCaseDrift -or $after.actualExitCode -notin @(0,100)){throw 'New run is not a pinned terminal'}
$oldIds=@($before.failureSet|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object -Unique)
$newIds=@($after.failureSet|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object -Unique)
$oldInventory=Get-Content -LiteralPath "$e/$baseline.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 30
$newInventory=Get-Content -LiteralPath "$e/$Stem.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 30
$oldCases=@($oldInventory.rows|Where-Object status -eq matches|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object -Unique)
$newCases=@($newInventory.rows|Where-Object status -eq matches|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object -Unique)
$record=[ordered]@{version=1;source='9a75564dc58d4c844f2c25a45958a1d081682934';inspectedHead=(git rev-parse HEAD).Trim();baseline=$before;current=$after;retained=@($newIds|Where-Object {$_ -in $oldIds});added=@($newIds|Where-Object {$_ -notin $oldIds});resolved=@($oldIds|Where-Object {$_ -notin $newIds});selectedCasesAdded=@($newCases|Where-Object {$_ -notin $oldCases});selectedCasesRemoved=@($oldCases|Where-Object {$_ -notin $newCases});scope='Failure identities only. Retained identities do not establish identical causes, and a failed complete run is not acceptance of CLI integration. Complete stdout/stderr are retained in the raw log.'}
$record|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{executed=$after.executed;passed=$after.passed;failed=$after.failed;retained=$record.retained.Count;added=$record.added.Count;resolved=$record.resolved.Count;selectedCasesAdded=$record.selectedCasesAdded.Count;selectedCasesRemoved=$record.selectedCasesRemoved.Count}|ConvertTo-Json -Depth 5
