param([string]$Normal='action-channel-receive-reverse-normal1-20261103',[string]$Current='action-channel-receive-sema-reverse1-20261103',[string]$Cli='action-channel-receive-reverse-cli1-20261103',[string]$Supplement='action-channel-receive-supplement1-20261103',[string]$Quality='action-channel-receive-quality5-20261103')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
function Read-Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$source='9a75564dc58d4c844f2c25a45958a1d081682934'
$base=(git rev-parse HEAD).Trim()
if($base -ne $source){throw 'Review the moving publication before recording'}
$normalResult=Read-Receipt "$Normal.runtime.terminal-audit"
$cliResult=Read-Receipt "$Cli.runtime.terminal-audit"
$coverage=Read-Receipt 'action-channel-receive-combined-coverage'
$currentResult=Read-Receipt "$Current.runtime.terminal-audit"
$cliSmoke=Read-Receipt 'action-channel-receive-cli-smoke1-20261103.verified'
$comparison=Read-Receipt "$Cli.failure-comparison"
$graph=Read-Receipt 'action-channel-receive-reverse-graph'
$freeze=Read-Receipt "$Current.source-freeze"
if($normalResult.failed -ne 2 -or -not $currentResult.isPassingRun -or $coverage.distinctCases -ne 7076 -or $coverage.failed -or $comparison.added.Count){throw 'Consumer acceptance requires diagnosis, not this recorder'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$supplemental=@(foreach($kind in @('docs','wasm')){$r=Read-Receipt "$Supplement-$kind";if($r.exitCode){throw "Failed supplemental gate: $kind"};$r})
$qualityResults=@(foreach($kind in @('check','clippy','structure')){$r=Read-Receipt "$Quality-$kind";if($r.exitCode){throw "Failed quality gate: $kind"};$r})
$doctests=@(foreach($line in [IO.File]::ReadLines("$e/$Supplement-docs.log")){if($line -match '^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;'){
    [ordered]@{passed=[int]$Matches[1];failed=[int]$Matches[2];ignored=[int]$Matches[3]}
}})
if(-not $doctests.Count){throw 'No doctest terminal results'}
$untracked=Read-Receipt 'task-documentation-final-untracked-before'
foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$history=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md')
$before=[IO.File]::ReadAllBytes($history)
$prefixSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant()
$raw='docs/implementation/acceptance-evidence/task-action-channel-receive-consumers.raw.zip'
$record='docs/implementation/acceptance-evidence/task-action-channel-receive-consumers.json'
if((Test-Path -LiteralPath $raw) -or (Test-Path -LiteralPath $record)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object {$_.Name.StartsWith($Normal+'.') -or $_.Name.StartsWith($Current+'.') -or $_.Name.StartsWith('action-channel-receive-sema-repair1-20261103.') -or $_.Name.StartsWith('action-channel-receive-cli-smoke1-20261103.') -or $_.Name.StartsWith($Cli+'.') -or $_.Name.StartsWith($Supplement+'-') -or $_.Name.StartsWith($Quality+'-') -or $_.Name.StartsWith('checkpoint-action-channel-thread-rejection.')})
$files+=@(Get-Item "$e/action-channel-receive-reverse-graph.json","$e/action-channel-receive-sema-repair-graph.json","$e/action-channel-receive-combined-coverage.json","$e/presentation-frame-driver.metadata.json","$e/audit-action-channel-reverse-combined.ps1","$e/compare-action-channel-cli.ps1","$e/run-presentation-projection-owner.ps1","$e/audit-nextest-final-result.ps1","$e/run-entity-reference-docs-wasm.ps1","$e/run-action-payload-quality.ps1","$e/record-action-channel-consumers.ps1")
$files+=@(Get-ChildItem -LiteralPath "$e/$Quality.structure-report" -File -Recurse)
$files=@($files|Sort-Object FullName -Unique)
$entries=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($e.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Archive entry count differs'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry differs'}}}finally{$zip.Dispose()}
$recordValue=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;inspectedHead=$base;workingTree='main; only original12 tracked and6 actual untracked WIP before this evidence cut';scope='Full Core reverse closure53, split into normal52 and CLI1; all targets/all features/locked, host Windows. Action owner execution is accepted within its recorded contract. CLI integration remains failed on the actual retained cases; all other accepted features retain their independent acceptance.';graph=$graph;initialNormal=$normalResult;currentSema=$currentResult;repairs=(Read-Receipt 'action-channel-receive-sema-repair1-20261103.runtime.terminal-audit');repairPublication=(Read-Receipt 'checkpoint-action-channel-thread-rejection.verified');cli=$cliResult;cliEntryExecution=$cliSmoke;failureIdentityComparison=$comparison;compileOnly=$coverage.compileOnly;distinctCases=$coverage.distinctCases;freshCases=$coverage.freshCases;reusedCases=$coverage.reusedCases;reuseProof=$coverage.reuseProof;acceptedSubsetCoverage=$coverage.subsets;supplemental=$supplemental;quality=$qualityResults;doctests=$doctests;sourceInputs=$freeze.paths.Count;sourceDrift=0;caseAndExecutableDrift=0;originalWip=[ordered]@{tracked=12;untracked=6;heldPatchSha256='46402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac';untrackedHashDrift=0};historyPrefix=[ordered]@{bytes=$before.Length;sha256=$prefixSha;drift=0};raw=[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();entryDrift=0;entries=$entries};currentStatusOrganization='Updates the sole current-status matrix. Previous owner and consumer runs remain historical evidence. The narrower current Core closure does not relabel old Syntax/HIR executions as fresh; accepted Generic Match is never reopened because the overall goal or CLI remains incomplete.'}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($recordValue|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$summary=[ordered]@{source=$source;normalPassed=$coverage.passed;fresh=$coverage.freshCases;reused=$coverage.reusedCases;cliPassed=$cliResult.passed;cliFailed=$cliResult.failed;retained=$comparison.retained.Count;added=$comparison.added.Count;resolved=$comparison.resolved.Count;doctestPassed=($doctests|Measure-Object -Property passed -Sum).Sum;doctestOwners=$doctests.Count;rawEntries=$entries.Count;rawBytes=$recordValue.raw.bytes;rawSha256=$recordValue.raw.sha256;historyPrefixBytes=$before.Length;historyPrefixSha256=$prefixSha}
$summary|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$e/action-channel-receive-consumers.recorded.json" -Encoding utf8
$append=@"


## 2026-11-03 Action送受信の全Core逆依存終端照合

Source $source、検査head $base、4090入力。実Cargo graphの53 packageを通常52とCLI1へ分け、all-target／all-feature／lockedで実行。初回は$($normalResult.executed)件中$($normalResult.passed) PASS／2 FAIL、ignored $($normalResult.skipped)件。Semaの不正Thread factのpanicと非公開field fixtureを修復し、同じ失敗2件は2／2 PASS。その後のSema全21通常逆依存$($currentResult.executed)件を新規PASS、影響外$($coverage.reusedCases)件は入力と元EXEの完全hash一致で成功結果を再利用し、合計$($coverage.distinctCases)件を終端照合した。一つの全件新規成功runとはしない。実行対象49 packageとcompile-only 3 packageを区別し、Source／case／EXE差分0。Generic Match151件とView40件も同じIDですべてPASS。修飾ActionのSyntax側5件は今回のCore逆依存範囲外であり、新規実行へ数えていない。

CLIは$($cliResult.executed)件中$($cliResult.passed) PASS／$($cliResult.failed) FAIL、旧Source7104との失敗ID比較は維持$($comparison.retained.Count)／追加$($comparison.added.Count)／解消$($comparison.resolved.Count)。ID一致から原因一致を推定せず、今回の全stderrを保持する。CLI入口の追加実行はbytecode VM／AOTともFIFO結果2022、27 step、各step最大1操作、正規Program通知1件、Host呼出し0を確認。これはnextest件数へ合算しない。最初のobserverが正規delivery診断も拒否したため、元task IDとsequence1に一致する通知だけを許すよう訂正し、実行自体は再実行していない。doctest $($summary.doctestPassed)件PASS、wasm check終了0。最新Sourceの全98 check／Clippy・構造gateも終了0。owner検証の以前の実測は元の記録を維持する。

現状表はAction ownerの全consumer未検証という一時状態と古い横断件数を今回の実測へ更新し、過去の結果を削除しない。CLI統合と全体goalは未完了であり、それだけでAction・Generic Matchなどの個別受入を未完了へ戻さない。[実graph・全case・CLI差分・raw](acceptance-evidence/task-action-channel-receive-consumers.json)。既存履歴の先頭$($before.Length) bytes（SHA256 $prefixSha）をbyte一致で保持してこの段落だけを追記。既存12 tracked／6 actual untracked WIPを保持。
"@
$stream=[IO.File]::Open($history,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($history);$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixSha){throw 'History prefix changed'}
$summary|ConvertTo-Json -Depth 10
