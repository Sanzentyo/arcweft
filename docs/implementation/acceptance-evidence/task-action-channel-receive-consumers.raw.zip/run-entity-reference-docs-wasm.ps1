param([Parameter(Mandatory)][string]$Stem,[Parameter(Mandatory)][string]$Epoch)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze=Get-Content -LiteralPath "$taskTemp/$Epoch.source-freeze.json" -Raw|ConvertFrom-Json
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}}
function Invoke-Recorded([string]$Name,[string[]]$Arguments){
    if(Test-Path -LiteralPath "$taskTemp/$Name.json"){throw 'Existing validation receipt'}
    Assert-Inputs
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @Arguments *> "$taskTemp/$Name.log"
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$freeze.base;command=$Arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/$Name.json" -Encoding utf8
    Write-Output "$Name exit=$code"
    if($code){throw "$Name failed"}
}
$packages=@('arcweft-id','arcweft-core','arcweft-lang-syntax','arcweft-lang-hir','arcweft-lang-sema','arcweft-runtime-plan','arcweft-compiler','arcweft-dialogue','arcweft-bundle')
$selection=@();foreach($package in $packages){$selection+=@('-p',$package)}
Invoke-Recorded "$Stem-docs" (@('test','--doc')+$selection+@('--all-features','--locked'))
Invoke-Recorded "$Stem-wasm" @('check','-p','arcweft-render-web','--target','wasm32-unknown-unknown','--all-features','--locked')
