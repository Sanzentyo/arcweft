$ErrorActionPreference = 'Stop'
$evidencePath = $PSScriptRoot
$sourceCommit = '518d63e31dd2be9750158004b171a6174b2725a7'
$workspacePath = 'D:\git\arcweft'
$archivePath = Join-Path $workspacePath 'docs\implementation\acceptance-evidence\task-recursive-body-effect-domain.raw.zip'
$expectedPath = [IO.Path]::GetFullPath('D:\git\arcweft\docs\implementation\acceptance-evidence\task-recursive-body-effect-domain.raw.zip')
if ([IO.Path]::GetFullPath($archivePath) -ne $expectedPath) { throw 'Unexpected evidence archive path.' }
if (Test-Path -LiteralPath $archivePath) { throw 'The frozen archive already exists; do not overwrite it.' }
$reverse = Get-Content -LiteralPath (Join-Path $evidencePath 'type-domain-reverse-results.json') -Raw | ConvertFrom-Json
if ($reverse.source -ne $sourceCommit -or $reverse.completedSteps -ne $reverse.plannedSteps -or $reverse.completedSteps -ne 107) {
    throw 'The pinned reverse run is not complete.'
}
$acceptance = Get-Content -LiteralPath (Join-Path $evidencePath 'type-domain-foundation-summary.json') -Raw | ConvertFrom-Json
if ($acceptance.source -ne $sourceCommit -or -not $acceptance.allCommandsTerminal) { throw 'Terminal validation summary is required.' }

# This archive is observed validation evidence, not a new design archive.
$excluded = @('active-solver-boundary-consult.txt', 'type-domain-evidence-manifest.json', 'type-domain-archive.json')
$files = @(Get-ChildItem -LiteralPath $evidencePath -File | Where-Object {
    $_.Name -notin $excluded -and $_.Extension -in @('.arcw','.json','.log','.stderr','.txt','.ps1','.rs')
} | Sort-Object Name)
$entries = foreach ($file in $files) {
    [ordered]@{ path=$file.Name; bytes=$file.Length; sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$manifestPath = Join-Path $evidencePath 'type-domain-evidence-manifest.json'
[ordered]@{ version=1; source=$sourceCommit; entries=@($entries) } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $manifestPath -Encoding utf8
$files += Get-Item -LiteralPath $manifestPath

Add-Type -AssemblyName System.IO.Compression
$stream = [IO.File]::Open($archivePath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
try {
    $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $true)
    try {
        foreach ($file in $files) {
            $entry = $archive.CreateEntry($file.Name, [IO.Compression.CompressionLevel]::Optimal)
            $destination = $entry.Open()
            $inputStream = [IO.File]::OpenRead($file.FullName)
            try { $inputStream.CopyTo($destination) } finally { $inputStream.Dispose(); $destination.Dispose() }
        }
    } finally { $archive.Dispose() }
} finally { $stream.Dispose() }

$readStream = [IO.File]::OpenRead($archivePath)
try {
    $archive = [IO.Compression.ZipArchive]::new($readStream, [IO.Compression.ZipArchiveMode]::Read, $true)
    try {
        if ($archive.Entries.Count -ne $files.Count) { throw 'Archive entry inventory differs.' }
        foreach ($expected in $entries) {
            $entry = $archive.GetEntry($expected.path)
            if ($null -eq $entry -or $entry.Length -ne $expected.bytes) { throw "Archive length mismatch: $($expected.path)" }
            $entryStream = $entry.Open()
            $algorithm = [Security.Cryptography.SHA256]::Create()
            try { $actualHash = [Convert]::ToHexString($algorithm.ComputeHash($entryStream)).ToLowerInvariant() } finally { $algorithm.Dispose(); $entryStream.Dispose() }
            if ($actualHash -ne $expected.sha256) { throw "Archive hash mismatch: $($expected.path)" }
        }
        $manifestEntry = $archive.GetEntry('type-domain-evidence-manifest.json')
        $manifestStream = $manifestEntry.Open()
        $algorithm = [Security.Cryptography.SHA256]::Create()
        try { $manifestHash = [Convert]::ToHexString($algorithm.ComputeHash($manifestStream)).ToLowerInvariant() } finally { $algorithm.Dispose(); $manifestStream.Dispose() }
        if ($manifestHash -ne (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()) { throw 'Archive manifest differs.' }
    } finally { $archive.Dispose() }
} finally { $readStream.Dispose() }

$receipt = [ordered]@{
    version=1
    source=$sourceCommit
    archive=$archivePath
    entries=$files.Count
    rawBytes=($files | Measure-Object Length -Sum).Sum
    zipBytes=(Get-Item -LiteralPath $archivePath).Length
    sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
    everyEntryVerified=$true
}
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidencePath 'type-domain-archive.json') -Encoding utf8
$receipt | ConvertTo-Json -Depth 5
