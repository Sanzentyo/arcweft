//! Effect evidence admitted by one phase of the shared semantic type grammar.

use std::{fmt::Debug, hash::Hash};

use crate::effect_row::{EffectPredicate, EffectRow};

mod sealed {
    pub trait Sealed {}
}

/// Selects the row and predicate evidence carried by a semantic type tree.
///
/// The grammar and every recursive child retain the same domain. Only the
/// canonical domain can issue checked semantic identities and runtime inputs.
pub trait TypeEffectDomain: sealed::Sealed + Clone + Copy + Debug + Eq + Hash {
    type Row: Clone + Debug + Eq + Hash;
    type Predicate: Clone + Debug + Eq + Hash;
}

/// The ordinary effect algebra used by declarations and completed type facts.
///
/// An omitted authored annotation remains an unknown `EffectRow`; membership
/// in this domain alone does not certify that inference has completed.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct CanonicalEffects;

impl sealed::Sealed for CanonicalEffects {}

impl TypeEffectDomain for CanonicalEffects {
    type Row = EffectRow;
    type Predicate = EffectPredicate;
}
