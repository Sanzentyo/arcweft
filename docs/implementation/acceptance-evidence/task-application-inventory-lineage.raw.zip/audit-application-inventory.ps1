$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='D:\git\arcweft'
$publication=Get-Content -Raw "$root\application-inventory.publication.json"|ConvertFrom-Json
$receipt=Get-Content -Raw "$root\application-inventory.owner-receipt.json"|ConvertFrom-Json
$pin=Get-Content -Raw "$root\application-inventory.final-input.json"|ConvertFrom-Json
$log=[IO.File]::ReadAllText("$root\application-inventory.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1569 tests run: 1563 passed \(1 slow\), 6 failed, 0 skipped')
if(-not $summary.Success){throw 'Unexpected owner summary'}
$body=$log.Substring(0,$summary.Index)
$terminal=@([regex]::Matches($body,'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1569\) (\S+) (.+)\r?$')|ForEach-Object {
    [pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}
})
$selected=@($receipt.Selected|ForEach-Object {$_.Binary+'$'+$_.Name})
if($terminal.Count -ne 1569 -or $selected.Count -ne 1569){throw 'Selection or terminal count differs'}
if(@($terminal|Group-Object Id|Where-Object Count -gt 1).Count -ne 0 -or @($selected|Group-Object|Where-Object Count -gt 1).Count -ne 0){throw 'Duplicate identity'}
if(@(Compare-Object -CaseSensitive ($selected|Sort-Object) ($terminal.Id|Sort-Object)).Count -ne 0){throw 'Selection and execution disagree'}
$failures=@($terminal|Where-Object Result -eq 'FAIL'|ForEach-Object Name|Sort-Object)
$previous=Get-Content -Raw "$root\predicate-extension.owner-summary.json"|ConvertFrom-Json
$previousNames=@($previous.Failures|ForEach-Object {$_.Split('$',2)[1]}|Sort-Object)
if(@(Compare-Object -CaseSensitive $previousNames $failures).Count -ne 0){throw 'Failure IDs changed'}
foreach($name in @('descendant_without_parent_receipt_cannot_be_registered_as_an_independent_root','a_child_scope_is_ineligible_on_an_unchosen_sibling_path','t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once')){
    $matches=@($terminal|Where-Object {$_.Name.EndsWith('::'+$name)})
    if($matches.Count -ne 1 -or $matches[0].Result -ne 'PASS'){throw "Regression/budget failed: $name"}
}
foreach($source in $pin.Sources){if((Get-FileHash -LiteralPath (Join-Path $repo $source.Path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $source.SHA256){throw 'Input source changed'}}
if($receipt.RunExit -ne 100 -or $receipt.Source -ne $publication.Source -or $receipt.Tree -ne $publication.Tree -or $pin.Tree -ne $publication.Tree){throw 'Source/receipt identity mismatch'}
$terminal|ConvertTo-Json -Depth 5|Set-Content "$root\application-inventory.owner-terminal.json" -Encoding utf8
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Selected=1569;Passed=1563;Failed=6;Skipped=0;Suites=5;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);SelectedIdsEqualTerminalIds=$true;DuplicateIds=0;FailureIdsUnchanged=$true;FailureBaseline='72fcdc6c0c13315bd909db8182a4183f0e6b0092';Failures=$failures;Candidate256Passed=$true;NewRegressionPassed=$true;MembershipRegressionPassed=$true;VerifiedSources=$pin.Sources.Count}|ConvertTo-Json -Depth 7|Set-Content "$root\application-inventory.owner-summary.json" -Encoding utf8
Get-Content "$root\application-inventory.owner-summary.json" -TotalCount 15
