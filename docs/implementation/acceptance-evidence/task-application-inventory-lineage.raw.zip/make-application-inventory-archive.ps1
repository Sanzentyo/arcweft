$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='D:\git\arcweft'
$publication=Get-Content -Raw "$root\application-inventory.publication.json"|ConvertFrom-Json
$pin=Get-Content -Raw "$root\application-inventory.final-input.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root\application-inventory.owner-summary.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root\application-inventory.quality.json"|ConvertFrom-Json
if($owner.Passed -ne 1563 -or $owner.Failed -ne 6 -or -not $owner.FailureIdsUnchanged -or $quality.ClippyExit -ne 0 -or $quality.FmtExit -ne 0 -or $quality.Tree -ne $publication.Tree){throw 'Evidence incomplete'}
if(@(git -C $repo diff --name-only 518d63e31dd2be9750158004b171a6174b2725a7 -- Cargo.toml Cargo.lock .cargo rust-toolchain.toml ':(glob)**/Cargo.toml').Count -ne 0){throw 'Graph inputs changed'}
$tree=[IO.File]::ReadAllText("$root\application-inventory.reverse-tree.log")
$packages=@([regex]::Matches($tree,'(arcweft-[a-z0-9-]+) v[0-9]').Groups|Where-Object Name -eq '1'|ForEach-Object Value|Sort-Object -Unique)
$previous=@(Get-Content -Raw "$root\value-component.reverse-packages.json"|ConvertFrom-Json)
if($packages.Count -ne 22 -or @(Compare-Object $previous $packages).Count -ne 0){throw 'Reverse package set changed'}
$measures=@(foreach($source in $pin.Sources){
    $before=@(git -C $repo show ($pin.Base+':'+$source.Path))
    [ordered]@{Path=$source.Path;Bytes=$source.Bytes;LOC=$source.LOC;BaseLOC=$before.Count;Growth=$source.LOC-$before.Count;Classification=if($source.Path -match '/tests|_tests'){'test'}elseif($source.Path.EndsWith('/solution.rs')){'production with cfg(test) fixture changes only'}else{'production'}}
})
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Owner='arcweft-lang-sema::types::constraints';Measurements=$measures;Responsibility='The path owns its actual source lineage; a rootless inventory owns only admitted application contracts and imported leases. Clone/fork preserves both without selecting or inventing a parent. Normalization consumes its existing path and rewrites only binding maps.';Cohesion='transaction.rs remains the affine transaction/source/projection/equation finalization owner, 2510 physical LOC versus 2491 at base; the new 19 lines preserve root provenance rather than add unrelated state. The value forest is already a separate 995-LOC owner. No new 300-LOC growth, duplicate relation grammar or production visibility expansion.';Behavior='The sole newly rejected registration is an internal unconnected prepared-value producer whose transaction names a descendant as an independent root even without a parent receipt. It fails before inserting a value or consuming an ordinal. Real root registration still succeeds.';Graph=@{Packages=$packages;CurrentTreeExit=0;MetadataReusedFrom='d20f11a7fa9762662df0cdbbe042670207b0177b';ResolvedModes=3;CargoInputsUnchanged=$true};Selection='Full Sema all-feature lib/integration nextest (1569), all-target/all-feature owner check and Clippy, workspace fmt. The active lower membership/admission/relation behavior is unchanged; affected root/alias/imported/normalization/source/cycle/budget and external compile-boundary tests all run in this owner suite. The changed producer rejection is still private and not connected to the frontend. This cut has no public/Cargo/codec/runtime contract change, so the prior complete 22-package/107-consumer-target evidence is retained for its original source rather than rerun or relabeled.';NotRun=@('consumer nextest','workspace check','workspace Clippy','Wasm','doctest','structure scanner','Tier 2','Native/AWBC acceptance');StructuralEvidenceReusedFrom='72fcdc6c0c13315bd909db8182a4183f0e6b0092';NoDependencyDirectionChange=$true;NoVersionChange=$true;BudgetsRelaxed=0;WholeGoalComplete=$false}|ConvertTo-Json -Depth 10|Set-Content "$root\application-inventory.scope-and-ownership.json" -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $root -File|Where-Object {
    ($_.Name.StartsWith('application-inventory.') -or $_.Name -in @('audit-application-inventory.ps1','make-application-inventory-archive.ps1')) -and $_.Name -notin @('application-inventory.manifest.json','application-inventory.archive.json','application-inventory.docs-audit.json','application-inventory.docs-publication.json')
}|Sort-Object Name)
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Base=$publication.Parent;Phases=@(
    @{Name='initial all-target/all-feature check';Exit=101;Tests=0;Reason='The first normalization implementation destructured and reconstructed the newly private path root from a sibling module (E0451, repeated for lib/test). Fixed by consuming the original path and replacing only binding maps; visibility was not widened.'},
    @{Name='final all-target/all-feature check';Exit=0;Seconds=24.50},
    @{Name='full all-feature owner nextest';Exit=100;Selected=1569;Passed=1563;Failed=6;Skipped=0;Seconds=135.461;Note='Exactly the same six original failure IDs, five ExpressionCycle and one PendingCallableEffectProjection, as source 72fcdc6c0c13315bd909db8182a4183f0e6b0092. New root regression, branch-local membership, and 256-candidate boundary pass.'},
    @{Name='owner Clippy and workspace fmt';ClippyExit=0;FmtExit=0;Note='Warnings retained; not a clean lint claim.'}
);Commands=@('CARGO_INCREMENTAL=0 cargo check --locked -p arcweft-lang-sema --all-targets --all-features','CARGO_INCREMENTAL=0 cargo nextest list --locked -p arcweft-lang-sema --lib --tests --all-features --message-format json','CARGO_INCREMENTAL=0 cargo nextest run --locked -p arcweft-lang-sema --lib --tests --all-features --no-tests fail --no-fail-fast','CARGO_INCREMENTAL=0 cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features','CARGO_INCREMENTAL=0 cargo fmt --all --check','cargo tree --locked --workspace --invert arcweft-lang-sema --edges normal,build,dev --target all --all-features');Files=@($files|ForEach-Object {@{Name=$_.Name;Bytes=$_.Length;SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}})}
$manifest|ConvertTo-Json -Depth 10|Set-Content "$root\application-inventory.manifest.json" -Encoding utf8
$files+=Get-Item "$root\application-inventory.manifest.json"
$archivePath=Join-Path $repo 'docs/implementation/acceptance-evidence/task-application-inventory-lineage.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive already exists'}
$zip=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    if($zip.Entries.Count -ne $files.Count){throw 'Entry count differs'}
    foreach($file in $files){
        $entry=$zip.GetEntry($file.Name)
        if($null -eq $entry -or $entry.Length -ne $file.Length){throw 'Entry length differs'}
        $stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -ne (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Entry hash differs'}
    }
    $raw=($zip.Entries|Measure-Object Length -Sum).Sum
}finally{$zip.Dispose()}
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=$files.Count;RawBytes=$raw;Bytes=(Get-Item $archivePath).Length;SHA256=(Get-FileHash $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();EveryEntryVerified=$true}|ConvertTo-Json|Set-Content "$root\application-inventory.archive.json" -Encoding utf8
Get-Content "$root\application-inventory.archive.json"
