param([Parameter(Mandatory)][string]$ProbeEpoch)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-numeric-values-20261108.source-checkpoint.verified.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit){throw 'Numeric source checkpoint changed'}
$noncli=Read-Record 'style-numeric-values-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
$cli=Read-Record 'style-numeric-values-integrated-20261108.cli-r1.runtime.terminal-audit.json'
$baseline=Read-Record 'string-read-operations-integrated-20261108.cli.runtime.terminal-audit.json'
if($noncli.actualExitCode -ne 0 -or $cli.executed -ne 711 -or $cli.failed -ne 4){throw 'Unexpected final test results'}
if(@(Compare-Object @($baseline.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object) @($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)).Count){throw 'CLI failure identities changed'}
$diagnostics=Read-Record 'style-numeric-values-integrated-20261108.failure-diagnostics.json'
$probe=Read-Record "style-numeric-values-20261108.native-$ProbeEpoch.json"
$main=Read-Record 'style-numeric-values-integrated-20261108.cli-r1.main-audit.json'
if($probe.checkExitCode -ne 0 -or $probe.bundleExitCode -ne 0 -or $probe.main.sha256 -ne $main.sha256){throw 'Actual tested CLI/native probe mismatch'}
$priorProbe=Read-Record 'style-token-construction-20261108.native-r1.json'
$archive='docs/implementation/acceptance-evidence/task-style-native-primitives.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(foreach($filter in @('style-numeric-values-20261108*','style-numeric-values-integrated-20261108*')){Get-ChildItem -LiteralPath $r -File -Filter $filter|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')}})
$files+=@('run-style-numeric-quality-20261108.ps1','run-style-numeric-test-repair-quality-20261108.ps1','run-style-numeric-consumers-20261108.ps1','run-style-numeric-consumers-r2-20261108.ps1','run-style-numeric-cli-consumers-20261108.ps1','run-style-numeric-native-source-probe-20261108.ps1','audit-style-numeric-coverage-final-20261108.ps1','audit-style-numeric-cli-failures-20261108.ps1','record-style-native-primitives-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$entry=[ordered]@{
    version=1;date='2026-11-09';publication=$pub;status='Native numeric/bool/closed-enum Source integration verified. Complete composite Style Source and interactive Native/Web acceptance remain open.'
    model='HIR owns exact decimal scaling; the ordinary scalar reducer reuses it and retains its original profile bounds/errors. StyleNumericType and CheckedStyleNumber own source construction magnitudes without a second complete value model. Signed i32 minima, full unsigned u32 Scalar thousandths, Ratio percentages, px lengths, deg/turn/radian angles and FontWeight 1..1000 use native carriers. Unary magnitudes are semantic-only operands and cannot enter runtime facts. Bool and all 11 closed enum grammars use native owner registries. Static numeric literals are unsuffixed; precision loss, overflow, wrong units/types/domains are rejected.'
    semantic='CompileTimeStyle type tag 104, construction role 9 plus exact native kind; existing StyleOperand transcript tag 0x0226 is retained. Contract markers remain 1. Ordinary runtime quantities are still distinct from specified Style values.'
    owner=(Read-Record 'style-numeric-values-20261108.owner-r1.runtime.terminal-audit.json')
    initialConsumers=(Read-Record 'style-numeric-values-integrated-20261108.noncli-r1.runtime.terminal-audit.json')
    consumerCorrection='Initial all-feature 4591-case run: 4589 pass/2 fail. Dialogue typography expected the replaced CompileTimeScalar Style Length reader. It now checks exact specified type/value, original px literal, effects, codec and source ranges. RuntimePlan used runtime i64 as a Style token annotation and an obsolete gap rule; migrate to Length/px and Column row-gap while preserving attributes, environment, retained locals and all rejection/contiguity checks. Add an explicit negative-literal construction operand and reject its runtime fact. Production drift after the workspace gates is zero; only those two test files change. Final complete 4591-case run passes, not a sum of partial reruns.'
    testRepairScope=(Read-Record 'style-numeric-values-20261108.test-repair-scope.json')
    finalNonCli=$noncli;finalCli=$cli;failureDiagnostics=$diagnostics
    freshTotals=[ordered]@{executed=$noncli.executed+$cli.executed;passed=$noncli.passed+$cli.passed;failed=$noncli.failed+$cli.failed;skipped=$noncli.skipped+$cli.skipped;runtimeRuns=2;featurePoints=2;scope='Final nonCLI-r2 and CLI-r1 only. Do not add owner 27, initial failed 4591, or previous Core-closure totals.'}
    coverage=(Read-Record 'style-numeric-values-20261108.coverage.json')
    graph=(Read-Record 'style-numeric-values-20261108.graph.json');reverseDependencyTree=(Read-Record 'style-numeric-values-20261108.tree-invert.json')
    quality=@(foreach($name in @('check','clippy','structure','fmt')){Read-Record "style-numeric-values-20261108.quality.$name.receipt.json"})
    repairedTestQuality=@((Read-Record 'style-numeric-values-20261108.test-repair-quality.clippy.json'),(Read-Record 'style-numeric-values-20261108.test-repair-quality.fmt.json'))
    ownerReview=[ordered]@{hir=[ordered]@{path='crates/arcweft-lang-hir/src/leaf.rs';bytes=52927;physicalLoc=1603};numeric=[ordered]@{path='crates/arcweft-lang-sema/src/final_analysis/model/style_number.rs';bytes=6038;physicalLoc=156};primitive=[ordered]@{path='crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style/primitives.rs';bytes=6101;physicalLoc=127};disposition='HIR keeps normalized leaf arithmetic with its decimal owner; remove the duplicate Sema scaling algorithm. Source-only numeric construction and primitive grammar are cohesive private owners. Complete values/enum registries remain View-owned. No dependency, I/O, unsafe or layer-direction change; no file splitting visibility workaround.'}
    nativeSourceProbe=$probe;mainAudit=$main;matchesPriorCanonicalNativeBundle=($probe.artifact.sha256 -eq $priorProbe.artifact.sha256)
    pending='Complete BorderRadii, ShadowList, FilterList, Transition and Resource Source construction, non-None Clip/Mask factories, typed token composition/conversions, unannotated-token inference and Environment publication. Preserve sample styles, controls, branches and original actions. Remaining sample migrations, Scroll, focus navigation, voice start, lifetime promotion and Native/Web interactive acceptance remain open. Preserve accepted Generic Match, retained input, named Action, String and other bounded cuts.'
    archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false;containsGeneratedBundles=$false}
}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'styleNativePrimitives'){throw 'Record exists'}
$wrapper=[ordered]@{styleNativePrimitives=$entry}|ConvertTo-Json -Depth 100
$inner=$wrapper.Substring($wrapper.IndexOf('{')+1).TrimEnd();$inner=$inner.Substring(0,$inner.LastIndexOf('}')).TrimEnd()
$next=$base.TrimEnd();$next=$next.Substring(0,$next.LastIndexOf('}')).TrimEnd()+','+"`n"+$inner+"`n}`n"
$after=$next|ConvertFrom-Json -Depth 100 -DateKind String
foreach($p in $prior.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($p.Name)|ConvertTo-Json -Depth 100 -Compress)){throw 'Historical record drift'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$next,[Text.UTF8Encoding]::new($false))
$current='D:/git/arcweft/docs/implementation/current-status.md'
$lines=@([IO.File]::ReadAllLines($current));$generic=@($lines|Where-Object {$_ -match '^\| Generic Match'})
for($i=0;$i -lt $lines.Count;$i++){
    if($lines[$i].StartsWith('確認日 ')){$lines[$i]='確認日 2026-11-09、観察Source `'+$pub.commit+'`。項目ごとの受入・公開Sourceと検証範囲を下表で独立して追跡する。tracked実装WIPは0、4 actual untrackedのローカルcacheは保持している。'}
    if($lines[$i].StartsWith('| Style 指定値・token・構築処理 |')){$lines[$i]='| Style 指定値・token・構築処理 | **基本値・token／font／paletteを統合検証・公開** | 元annotation／cache分離 `3cada521ecac205c76744b09613b9cf519d5ccb5`、元宣言／source range公開 `32277ec5e8bff06feef249e981e3f038c3153ebb`、元sheet参照／font stack／palette `c8fbbd4b1bc92266fc34026138661c71459a945b`。Source `'+$pub.commit+'` で6 numeric・bool・11 closed enumを接続し、計20 native kindの静的Sourceを扱う（Clip／MaskはNone）。HIR所有の正確なdecimal scalingと構築用magnitudeにより、signed最小値・Scalar u32全域・精度／単位／型／enum誤りを検証し、runtime流入を拒否した。native-text-inputの実CLI check／main-profile AWFB生成も再確認。数値suffixは通常runtime型のため、指定値のliteralには使わない。残る5 kindの構築、Clip／Mask factory、token composition／変換・未annotation推論・Environment、残るsampleと実Native／Web操作／表示は継続する。現状から削除した旧FontFamilyList／token未達説明の訂正理由、初回2失敗と元の検証SHAは履歴へ保持。[実測・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
    if($lines[$i].StartsWith('| 共有契約／推移的逆依存matrix |')){$lines[$i]='| 共有契約／推移的逆依存matrix | **新規'+$entry.freshTotals.executed+'実行：'+$entry.freshTotals.passed+' PASS／'+$entry.freshTotals.failed+' FAIL／'+$entry.freshTotals.skipped+' SKIP** | Source `'+$pub.commit+'`。metadata／target-all tree一致のHIR逆依存23 packageを、非CLI 22 package全featureとCLI既定へ分けた。最終非CLIは4591／4591 PASS・9 SKIP、CLIは下行。旧Core範囲から今回の範囲へ投影した3599件は欠落／重複0、名称訂正1件を対応付けた。追加992件のうち979件は以前のCore範囲に含まれなかったHIR自身で、新規作成992件という意味ではない。Source／catalog／実EXE drift0。今回の最終2 run／2 feature pointだけを集計し、初回失敗・owner反復・以前のCore全件件数は加算しない。[終端・選択・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
    if($lines[$i].StartsWith('| CLIの規定対象／全 check 照合 |')){$lines[$i]='| CLIの規定対象／全 check 照合 | **Style基本値統合後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | Source `'+$pub.commit+'`。先行と同じ4失敗ID・実診断で、新規失敗0。Scrollのshared callable拒否、active dialogue has no voice、promotion2件のsolver到達前type-check拒否は未解消。実CLI本体とtest binaryを元pathで前後照合。native-text-inputのcheck／main-profile bundle生成は同じ実CLIの別Source probeとして終了0で、711件へ加算しない。旧text-submit／Core範囲のSHAと実測も履歴へ保持する。[診断・Source・EXE pin・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
    if($lines[$i].StartsWith('| workspace check／Clippy・fmt・構造gate |')){$lines[$i]='| workspace check／Clippy・fmt・構造gate | **Style基本値統合の全workspace gateは終了0** | Source `'+$pub.commit+'` のproductionは全98 package・全target・全feature・locked check／Clippy、構造gate、明示24 Rust pathのfmtが終了0（3912入力drift0、警告あり）。後続の変更は旧Style契約を期待したテスト2ファイルのみで、production drift0を照合し、Compiler／RuntimePlanの全target／feature Clippyと2 pathのfmtも終了0。最終全件・旧oracleの訂正理由は上表と履歴へ集約。[gate・失敗・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
}
if(($generic -join "`n") -cne ((@($lines|Where-Object {$_ -match '^\| Generic Match'})) -join "`n")){throw 'Accepted Generic Match row changed'}
[IO.File]::WriteAllText($current,($lines -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
$history=@'

## 2026-11-09 — Style基本値・正確な数値演算と23逆依存統合

Source `{{SOURCE}}` は6 numeric／bool／11 closed enumを接続し、静的SourceはColor／FontFamilyListを含む20 native kindになった（Clip／MaskはNone）。decimal scalingをHIRの値型へ置き、普通のscalar reducerも同じ演算へ移した。普通のscalar profile上限は保持し、Style側はnative carrier全域を用いる。signed最小値の正のmagnitudeは構築専用型で保持してから符号を適用するため、runtime量や完成propertyへの誤出版を避ける。精度、符号、単位、範囲、suffix、native registryの全enum memberとcodec往復を確認した。type tag104／構築role9、既存StyleOperand tag0x0226とcontract version1を維持する。

owner27件がPASS。初回非CLI4591件は4589 PASS／2 FAILで、対話プロファイルが旧CompileTimeScalar Lengthを期待し、RuntimePlan fixtureがruntime i64をStyle token型に使っていた。指定値・元px literal・型／effect・codec／source rangeを保つ期待へ移し、fixtureはLength／pxとColumn row-gapへ同期した。元のattributes／environment／local／全拒否条件と連続local ID確認は保持し、新しい負数構築operandのruntime流入も拒否する。production変更は0で、この2 test pathだけがworkspace gate後に変わった。修正後の非CLI全4591件は全PASS・9 SKIPで、初回の4589件と修正subsetを足した件数ではない。

metadataとtarget-all treeが一致するHIR逆依存23 packageを、全feature非CLI22 packageとCLI既定へ分けた。最終CLIは711実行／707 PASS／4 FAIL／23 SKIPで、Scroll shared callable Expr15、voice absent、promotion Expr8の2件という元のID・実診断と一致する。全件の新規集計は{{TOTAL}}実行／{{PASS}} PASS／4 FAIL／{{SKIP}} SKIP、最終2 run／2 feature pointのみ。旧Core範囲から3599件を投影して欠落／重複0、Style Length testの改名1件を対応付けた。追加992件には前のCore範囲に無かったHIR979件が含まれるため、新規作成992件とは記さない。元Source、catalog、実test EXE、実CLI本体を前後照合した。

全98 workspaceのlocked／全target／全feature check・Clippy、構造gate、明示24 Rust pathのfmtが終了0。2 test修復後のCompiler／RuntimePlan Clippyと2 pathのfmtも終了0。native-text-inputは同じ実CLIでcheckとmain-profile AWFB生成を再確認した。残る5 value kind、Clip／Mask factory、token composition／変換・未annotation推論・Environment、残るsample移行とNative／Web操作／表示は別の未達として保持し、全体goalを理由にGeneric Match等の既受入を戻さない。

既存143 registry recordを値の全件照合で保持した。原本 `{{ARCHIVE}}` は{{ENTRIES}} entry／{{BYTES}} bytes、SHA256 `{{SHA}}`。実行ファイルと生成AWFBは元build pathへ保持し、ZIPには含めない。詳細はregistryの `styleNativePrimitives`。
'@
foreach($key in @('SOURCE','TOTAL','PASS','SKIP','ARCHIVE','ENTRIES','BYTES','SHA')){$value=switch($key){SOURCE{$pub.commit};TOTAL{$entry.freshTotals.executed};PASS{$entry.freshTotals.passed};SKIP{$entry.freshTotals.skipped};ARCHIVE{$entry.archive.path};ENTRIES{$entry.archive.entries};BYTES{$entry.archive.bytes};SHA{$entry.archive.sha256}};$history=$history.Replace(('{{'+$key+'}}'),[string]$value)}
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+"`n"+$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;fresh=$entry.freshTotals;archive=$entry.archive}|ConvertTo-Json -Depth 10|Set-Content "$r/style-numeric-values-20261108.acceptance-record.json" -Encoding utf8
Get-Content "$r/style-numeric-values-20261108.acceptance-record.json" -Raw
