$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$old=Get-Content "$r/string-read-operations-integrated-20261108.noncli-r2.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$new=Get-Content "$r/style-numeric-values-integrated-20261108.noncli-r2.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$graph=Get-Content "$r/style-numeric-values-20261108.graph.json" -Raw|ConvertFrom-Json -Depth 30
$before=@($old.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $graph.packages.name})
$after=@($new.rows|Where-Object status -eq 'matches')
$oldName='final_analysis::tests::semantic_transcript_acceptance::expression_corpus::contextual_expressions::style_length_values_use_registered_roots_and_shared_scalar_reduction'
$newName='final_analysis::tests::semantic_transcript_acceptance::expression_corpus::contextual_expressions::style_length_values_use_specified_values_and_exact_decimal_scaling'
$current=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $after){if(!$current.Add(($row.binary+"`0"+$row.test))){throw 'Duplicate current case'}}
$previous=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$missing=@(foreach($row in $before){$name=if($row.test -ceq $oldName){$newName}else{$row.test};$key=$row.binary+"`0"+$name;[void]$previous.Add($key);if(!$current.Contains($key)){$row}})
if($missing.Count){$missing|ConvertTo-Json -Depth 8|Set-Content "$r/style-numeric-values-20261108.coverage.missing.json";throw 'Prior case missing from selected closure'}
$added=@($after|Where-Object {!$previous.Contains(($_.binary+"`0"+$_.test))})
$record=[ordered]@{version=1;baselineSource='70a050cc9cd0b94d83b79a295ec688bccd3b1d3b';baselineRetainedInCurrentClosure=$before.Count;missing=0;duplicate=0;additionalCurrentCases=$added.Count;additionalByPackage=@($added|Group-Object package|ForEach-Object {[ordered]@{package=$_.Name;cases=$_.Count}});currentSelected=$after.Count;rename=[ordered]@{old=$oldName;new=$newName;reason='The specified Style value now uses exact shared HIR decimal scaling and the native carrier instead of the ordinary registered scalar profile. Signed/fractional values, rejection conditions and ordinary numeric-root assertions are preserved.'};scope='The former Core closure did not select HIR itself; current HIR tests are additional coverage, not newly authored cases.'}
$record|ConvertTo-Json -Depth 12|Set-Content "$r/style-numeric-values-20261108.coverage.json" -Encoding utf8
$record|ConvertTo-Json -Depth 12
