$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$graph=Get-Content "$r/style-numeric-values-20261108.graph.json" -Raw|ConvertFrom-Json -Depth 30
$packages=@($graph.packages.name|Where-Object {$_ -ne 'arcweft-cli'}|Sort-Object -Unique)
if($packages.Count -ne 22){throw 'Unexpected HIR consumer closure'}
$selection=@('--locked','--all-features','--lib','--tests')
foreach($package in $packages){$selection+=@('-p',$package)}
$selection+=@('-E','rdeps(=arcweft-lang-hir)')
$new=@('crates/arcweft-core/src/awbc/product_step/action.rs','crates/arcweft-presentation/src/text_input/policy.rs','crates/arcweft-compiler/tests/view_product/text_input/placeholder.rs','crates/arcweft-core/src/value/string.rs','crates/arcweft-core/src/awbc/verify/code/string_tests.rs','crates/arcweft-compiler/tests/callable_execution/string_operations.rs','crates/arcweft-lang-sema/src/types/style.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/style.rs','crates/arcweft-lang-sema/src/final_analysis/tests/style_types.rs','crates/arcweft-compiler/tests/view_product/style_tokens.rs','crates/arcweft-lang-sema/src/final_analysis/model/style.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style.rs','crates/arcweft-lang-sema/src/final_analysis/model/style_number.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style/primitives.rs','crates/arcweft-compiler/tests/view_product/style_primitives.rs')
& "$r/run-retained-input-frozen-matrix-20261108.ps1" -Stem 'style-numeric-values-integrated-20261108.noncli-r2' -Selection $selection -AdditionalPaths $new
exit $LASTEXITCODE
