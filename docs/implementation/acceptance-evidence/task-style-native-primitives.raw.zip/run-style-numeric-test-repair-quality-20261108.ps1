$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$stem="$r/style-numeric-values-20261108.test-repair-quality"
$freeze=Get-Content "$r/style-numeric-values-integrated-20261108.noncli-r2.source-freeze.json" -Raw|ConvertFrom-Json -Depth 15
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Repair input drift: '+$row.path)}}}
Assert-Inputs
$arguments=@('clippy','--locked','-p','arcweft-compiler','-p','arcweft-runtime-plan','--all-targets','--all-features')
& cargo @arguments *> ($stem+'.clippy.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0}|ConvertTo-Json -Depth 10|Set-Content ($stem+'.clippy.json') -Encoding utf8
if($code -ne 0){exit $code}
$paths=@('crates/arcweft-compiler/tests/dialogue_profile_admission.rs','crates/arcweft-runtime-plan/src/semantic_facts/tests.rs')
& rustfmt --check --edition 2024 --config skip_children=true $paths *> ($stem+'.fmt.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;paths=$paths;exitCode=$code;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.fmt.json') -Encoding utf8
exit $code
