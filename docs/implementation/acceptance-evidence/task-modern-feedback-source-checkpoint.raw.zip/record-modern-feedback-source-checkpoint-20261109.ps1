$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'modern-feedback-source-checkpoint-20261109.source.verified.json'
$probe=Read-Record 'modern-feedback-source-checkpoint-20261109.probe.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit -or $probe.checkExitCode -ne 0 -or $probe.bundleExitCode -ne 1 -or $probe.artifactExists){throw 'Unexpected sample checkpoint'}
$freeze=Read-Record 'style-environment-integrated-20261109.noncli-r1.source-freeze.json'
$delta=@(foreach($row in $freeze.paths){if((Get-FileHash $row.path).Hash.ToLowerInvariant() -ne $row.sha256){$row.path}})
if($delta.Count -ne 1 -or $delta[0] -ne 'samples/modern-feedback-view/src/main.arcw'){throw 'Unexpected change since engine matrix'}
$archive='docs/implementation/acceptance-evidence/task-modern-feedback-source-checkpoint.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(Get-ChildItem $r -File -Filter 'modern-feedback-source-checkpoint-20261109*'|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')})
$files+=Get-Item "$r/record-modern-feedback-source-checkpoint-20261109.ps1"
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';publication=$pub;actualRepositoryProbe=$probe
 status='Repository modern-feedback Source migrated to current retained View/image/Action/Style APIs and passes actual package check. Main-profile AWFB generation still fails at the known parameterized goto ABI boundary; full sample execution is incomplete.'
 preserved='Original image asset and image.glass_bg metadata, target/layer/bounds/fit/opacity/depth/visibility, complete panel token/rule inventory and font stack, every heading/caption property at the same Text nodes, original input IDs/labels/placeholders/IME roles, both Action declaration identities/payload fields, two lexical mounts, dialogue/rich text/empty and nonempty branches, GameState formal and self-goto.'
 migration='Use ordinary glass_bg() -> Handle<ImageSurface>, retained local String state and current named input arguments, pure handlers returning original Actions, mount(View()) and await receive(Action). Replace unsupported closure-style patches with two shared typed named Style sheets at original node positions. Delete obsolete input factories, action.invoke, view-reference mounting and image declaration syntax. README now describes the two actual views and looping behavior rather than nonexistent single-view/returned-brief behavior, and links execution acceptance to the sole status ledger.'
 validation='Actual original-path tested CLI b33af81ae4d876bc5be2dc83ba8300165006d2e5585379760ab738f83edae61e: package check0/status ok, Source/main hash drift0. Bundle1: block25 expected1/found0, same independently minimized and previously archived defect. Output artifact absent. No Native/Web operation or capture success is claimed.'
 engineMatrixReuse=[ordered]@{source=$probe.engineSource;freeze=$freeze.base;sourceInputs=$freeze.paths.Count;changedPaths=$delta;engineRustCargoDrift=0;scope='Prior Engine View5397 matrix remains evidence for its recorded inputs. Do not claim it was rerun for the modified sample. No new Rust/Cargo gate invocation is needed or claimed for this Source/README-only cut.'}
 pending='Repair typed parameterized Flow transfer admission and Native/AWBC argument/cleanup handling, then complete the sample bundle and real Native/Web operation/capture acceptance. Preserve other accepted cuts.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 151 -or $prior.PSObject.Properties.Name -contains 'modernFeedbackSourceApiCheckpoint'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "modernFeedbackSourceApiCheckpoint": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$row='| modern-feedback-viewのSource/API移行 | **現行APIへの移行を公開・実CLI check成功。AWFBと実操作は未達** | Source '+$pub.commit+'。元画像／metadata、全panel Style・font stack、各Textの見出し／説明property、input target／label／placeholder／IME、2 Action identityとpayload、2 mount scope、全対話／分岐／GameState／自己gotoを保持した。現在のHandle factory・保持String・Action返却・Ref<Style>へ移し、旧APIを削除した。元pathの実CLIでpackage checkが終了0、Source／本体hash差分0。main-profile bundleは下のparameterized gotoと同じblock25の要求1引数／実際0引数で停止し、出力なし。READMEの旧単一view／brief返却の説明を実Sourceへ訂正した。Native／Web操作・画像parityの成功はまだ主張しない。[原本・full SHA・保持範囲](acceptance-evidence/task-flow-registry-execution.json)。 |'
$gotoRow='| 引数を持つFlowへのgoto | **formal／引数のadmissionと転送が未達** | Engine Source ef2679347c14dccee649e5fb716d3a37510cac1fの実CLIを前後pinし、同じGameState formalを持つ最小2入力で再現した。空Flowはcheck／13命令AWFB生成が成功し、自己goto追加だけでcheckは通るがAWBC block0で要求1引数／実際0引数となる。Semaの構造扱いからRuntimePlanの引数なしGoto、AWBCの空argsへ至る接続を調査・修復する。modern-feedbackのSource／生成物の状態は専用行へ集約した。引数なしgoto・scope cleanup・Style等の既受入は維持し、この新しい具体的境界だけを未達として追跡する。[最小対照・失敗原本・CLI pin・訂正理由](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status=(@($status -split $lf|ForEach-Object {
 if($_.StartsWith('| Style 指定値・token・構築処理 ')){$row;$_}
 elseif($_.StartsWith('| 引数を持つFlowへのgoto ')){$gotoRow}
 elseif($_.StartsWith('| 共有契約／推移的逆依存matrix ')){$_.Replace('**今回View範囲5397実行：','**前回EngineのView範囲5397実行：')}
 elseif($_.StartsWith('| 通常 Flow の scoped defer ')){$_.Replace('初期所有入力は次行へ分け','初期所有入力は専用行へ分け')}
 elseif($_.StartsWith('確認日 ')){$_.Replace('ef2679347c14dccee649e5fb716d3a37510cac1f',$pub.commit)}
 else{$_}
})) -join $lf
if(($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — modern-feedbackの現行Source APIへの移行checkpoint

Source $($pub.commit) をmainへ通常公開し、parent／tree／2 pathのblobとpatchを照合した。前回準備した全動作保持の候補を実repoへ反映し、旧image宣言をHandle factoryへ、input factoryを保持Stringへ、handlerを元Action record返却へ、view参照mount／receiveを現行APIへ移した。4つの旧closure-style patchは、全propertyを保持した2共有named Styleを同じText nodeへ適用する形にした。元の画像・metadata、全panel Style／font stack、input metadata、2 Action、2 lexical scope、rich dialogue／分岐／GameState formal／自己gotoを削除していない。

READMEにあった存在しない単一view名、旧mount／receive、text length分岐とbrief返却の説明を、実際の2 view／empty-nonempty分岐／自己転送へ訂正した。Bundleとplayerの包括受入は主張せず、現在の未達を唯一の現状一覧へリンクした。実repo packageを、前回テスト済みの同じCLI SHA256 $($probe.main.sha256) で検証し、checkは終了0／status ok、Source／EXE差分0。main-profile bundleは既に最小化した同じparameterized gotoのblock25、要求1／実際0引数で終了1、出力なし。中間Source checkpointであってsample実行完了ではない。

Engine matrixの3920入力との差分はsample main.arcwの1 pathだけで、Rust／Cargo差分0。以前の5397件はその入力の実測として保持し、今回のsampleを再実行した件数にはしない。現状一覧のsampleを一時候補から公開済みAPI移行／check成功へ更新し、goto一般境界の説明と重複していたsample詳細を専用行へ集約した。行追加で壊れやすい「次行」の参照を「専用行」へ訂正した。以前のfull SHA／失敗／実測と既存151 registry propertyの値を全件保持し、modernFeedbackSourceApiCheckpointを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。EXE／AWFB等のbuild artifactをコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$entry.archive}|ConvertTo-Json -Depth 7|Set-Content "$r/modern-feedback-source-checkpoint-20261109.acceptance-record.json"
Get-Content "$r/modern-feedback-source-checkpoint-20261109.acceptance-record.json"
