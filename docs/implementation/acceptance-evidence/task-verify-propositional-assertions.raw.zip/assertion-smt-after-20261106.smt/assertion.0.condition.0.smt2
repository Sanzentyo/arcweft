; Arcweft obligation: assertion.0.condition.0
(set-logic QF_UF)
(set-option :produce-models true)
; bool_0 <= flag
(declare-const bool_0 Bool)
(assert (and (not bool_0) bool_0))
(check-sat)
(get-value (bool_0))
