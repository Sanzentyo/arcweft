param([Parameter(Mandatory)][string]$Attempt)
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$base=(& git rev-parse HEAD).Trim()
if ($base -ne 'aa836b2fd455042ed963c29e176334e84f65ef57' -or @(git diff --cached --name-only).Count) { throw 'Unexpected base or index' }
$paths=@('crates/arcweft-core/src/value/env.rs','crates/arcweft-core/src/engine/line.rs','crates/arcweft-core/src/engine/rollback.rs','crates/arcweft-core/src/tests/flow/invocation.rs','crates/arcweft-core/src/engine/presentation_tests/flow_transfer.rs')
if (@(Compare-Object @($paths | Sort-Object) @(git diff HEAD --name-only | Sort-Object)).Count) { throw 'Unexpected changed source paths' }
$prefix='flow-transfer-native-immediate-'+$Attempt
$listLog=Join-Path $e ($prefix+'.list.log')
$runLog=Join-Path $e ($prefix+'.run.log')
if (Test-Path -LiteralPath $listLog) { throw 'Attempt already exists' }
$patch=Read-GitBytes @('diff','--binary','--full-index','HEAD')
[IO.File]::WriteAllBytes((Join-Path $e ($prefix+'.patch')),$patch)
$patchHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant()
$pins=@(foreach($p in $paths){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$filter='test(/flow_transfer/) or test(/native_goto/) or binary(=flow_transfer) or test(=bench_json_measures_runtime_match_to_pure_jit_characteristics) or (binary(=scoped_defer) and test(/goto/))'
$cargoSelection=@('--locked','--all-features','-p','arcweft-core','-p','arcweft-compiler','-p','arcweft-cli','--lib','--test','flow_transfer','--test','scoped_defer','--test','check','-E',$filter)
$listArgs=@('nextest','list','--message-format','json')+$cargoSelection
$runArgs=@('nextest','run','--no-fail-fast','--no-tests','fail')+$cargoSelection
[ordered]@{version=1;base=$base;patchSha256=$patchHash;sourceFiles=$pins;listArgs=$listArgs;runArgs=$runArgs}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $e ($prefix+'.inputs.json')) -Encoding utf8
& cargo @listArgs *> $listLog
$listCode=$LASTEXITCODE
if ($listCode -ne 0) { Write-Output ('List exit='+$listCode); exit $listCode }
$raw=[IO.File]::ReadLines($listLog)|Where-Object {$_.StartsWith('{')}|Select-Object -Last 1
if (!$raw) { throw 'Missing catalog' }
$catalog=$raw | ConvertFrom-Json -AsHashtable
$selected=@(foreach($suite in $catalog.'rust-suites'.Values){foreach($name in $suite.testcases.Keys){if($suite.testcases[$name].'filter-match'.status -eq 'matches'){[ordered]@{id=$suite.'binary-id'+' '+$name;package=$suite.'package-name';path=$suite.'binary-path'}}}})
foreach ($key in @('bench_json_measures_runtime_match_to_pure_jit_characteristics','native_flow_transfer_keeps_presentation_inputs_until_the_receiving_flow_ends','rejected_immediate_flow_transfer_receiver_keeps_original_inputs_and_scopes_across_restore','explicit_flow_inputs_reach_the_native_receiving_root','explicit_flow_inputs_reach_the_decoded_awbc_receiving_root','function_goto_drains_its_own_and_callers_cleanup_without_resuming_caller_code')) {
    if (@($selected|Where-Object {$_.id.EndsWith($key,[StringComparison]::Ordinal)}).Count -ne 1) { throw ('Missing or ambiguous required regression '+$key) }
}
$binaries=@($selected.path+'D:\git\arcweft\target\debug\arcw.exe'|Sort-Object -Unique)
function Read-Pins {@(foreach($p in $binaries){[ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})}
$before=Read-Pins
$before|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-before.json')) -Encoding utf8
Write-Output ('Selected '+$selected.Count+' tests across '+@($selected.package|Sort-Object -Unique).Count+' packages.')
& cargo @runArgs *> $runLog
$code=$LASTEXITCODE
$after=Read-Pins
$after|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-after.json')) -Encoding utf8
$actualPatch=Read-GitBytes @('diff','--binary','--full-index','HEAD')
if ((& git rev-parse HEAD).Trim() -ne $base -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($actualPatch)).ToLowerInvariant() -ne $patchHash) { throw 'Source changed during validation' }
$drift=@(for($i=0;$i -lt $before.Count;$i++){if($before[$i].path -ne $after[$i].path -or $before[$i].sha256 -ne $after[$i].sha256){$after[$i].path}})
$terminal=@([IO.File]::ReadLines($runLog)|Where-Object {$_ -match '^\s+(Summary|FAIL|TIMEOUT)\s+\['})
$result=[ordered]@{version=1;base=$base;patchSha256=$patchHash;exitCode=$code;sourceDrift=0;binaryDrift=$drift;selected=$selected;terminal=$terminal}
$result|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $e ($prefix+'.results.json')) -Encoding utf8
[ordered]@{exitCode=$code;selected=$selected.Count;binaryDrift=$drift.Count;terminal=$terminal}|ConvertTo-Json -Depth 5 -Compress
exit $code
