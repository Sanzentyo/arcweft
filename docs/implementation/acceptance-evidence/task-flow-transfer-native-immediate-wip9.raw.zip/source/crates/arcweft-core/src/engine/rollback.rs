//! Borrowed admission of native execution ownership before rollback projection.

use super::NativePendingWork;
use super::code_cursor::NativeSourceOperation;
use super::defer::{NativeDeferBoundary, NativeLexicalExitAction};
use super::work::{NativePendingWorkKind, NativeRuntimeContinuation, NativeStoredWork};
use super::{
    Engine, FlowControlStackEntry, FlowControlStackEntryKind, FlowFiberOwner, FlowFiberStatus,
    FunctionCallFrame, FunctionReturnContinuation, NativeEngineRollbackImage,
    NativeFlowExecutionFrame, NativeFormatAttemptFrame, NativeInvocationRoot, eval,
};
use crate::runtime_id::DialogueActivationId;
use crate::task::TaskPublicationCursor;
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::sync::Arc;

mod await_state;

pub(super) trait NativeInvocationStatus {
    fn retires_invocation_scopes(&self) -> bool;
}

impl<A, M> NativeInvocationStatus for FlowFiberStatus<A, M> {
    fn retires_invocation_scopes(&self) -> bool {
        matches!(self, Self::Done(_) | Self::Failed(_))
    }
}

pub(super) trait SuspendedValues {
    fn admit_suspended_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        binding: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>;

    fn admit_frame_context<V: crate::value::RuntimeStoredValue>(
        &self,
        _env: &crate::value::RuntimeEnv<V>,
        _admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        Self: Sized,
    {
        Ok(())
    }
}

fn admit_default_packet(
    state: crate::runtime_id::RuntimeCallableStateId,
    site: crate::runtime_id::RuntimeFunctionSiteId,
    admission: &mut crate::value::RuntimeRetainedValueAdmission,
    origin: crate::entry::schema::value_encoding::ValueAdmissionOrigin,
    validate: impl FnOnce(
        &crate::task::RuntimeProgramOwner,
        &mut crate::entry::schema::value_encoding::ValueResourceAdmission,
    ) -> Result<(), crate::value::RuntimeCallableValueError>,
) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
    admission.admit_composite(origin, |owner, resources| {
        let owner = owner.ok_or_else(|| crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: "native default packet requires its original executable".into(),
        })?;
        crate::value::RuntimeCallableBodyReference::Plan(site)
            .validate_default_return(owner.types(), state)?;
        validate(owner, resources)?;
        Ok(())
    })
}

pub(super) trait PendingStorage {
    const ORIGIN: crate::entry::schema::value_encoding::ValueAdmissionOrigin;

    fn admit_default(
        &self,
        site: crate::runtime_id::RuntimeFunctionSiteId,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>;
}

impl PendingStorage for crate::value::RuntimeCallablePendingGroup {
    const ORIGIN: crate::entry::schema::value_encoding::ValueAdmissionOrigin =
        crate::entry::schema::value_encoding::ValueAdmissionOrigin::Live;

    fn admit_default(
        &self,
        site: crate::runtime_id::RuntimeFunctionSiteId,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        admit_default_packet(
            self.state(),
            site,
            admission,
            Self::ORIGIN,
            |owner, resources| self.validate_snapshot_inputs(owner, resources),
        )
    }
}

impl PendingStorage for crate::value::RuntimeCallablePendingSnapshot {
    const ORIGIN: crate::entry::schema::value_encoding::ValueAdmissionOrigin =
        crate::entry::schema::value_encoding::ValueAdmissionOrigin::InertSnapshot;

    fn admit_default(
        &self,
        site: crate::runtime_id::RuntimeFunctionSiteId,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        admit_default_packet(
            self.state,
            site,
            admission,
            Self::ORIGIN,
            |owner, resources| self.validate_inputs(owner, resources),
        )
    }
}

impl<P> FunctionReturnContinuation<P> {
    pub(super) fn admit_header_and_packet(
        &self,
        site: crate::runtime_id::RuntimeFunctionSiteId,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        P: PendingStorage,
    {
        let invalid = |message: &str| crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: message.into(),
        };
        match self {
            Self::Expression => {
                if matches!(
                    P::ORIGIN,
                    crate::entry::schema::value_encoding::ValueAdmissionOrigin::InertSnapshot
                ) {
                    return Err(invalid(
                        "a synchronous expression invocation cannot resume without its live evaluator",
                    ));
                }
                let Some(crate::task::RuntimeProgramOwner::Plan(plan)) = admission.program_owner()
                else {
                    return Err(invalid(
                        "native expression invocation requires its plan owner",
                    ));
                };
                if !plan.function_sites().get(site).is_some_and(|site| {
                    matches!(
                        site.body(),
                        crate::plan::RuntimeFunctionSiteBody::Expression(_)
                    )
                }) {
                    return Err(invalid(
                        "native expression invocation differs from its original body",
                    ));
                }
            }
            Self::RootInitializer { entry } | Self::RootReducer { entry } => {
                admission.validate_metadata(entry)?;
                let Some(crate::task::RuntimeProgramOwner::Plan(plan)) = admission.program_owner()
                else {
                    return Err(invalid("native Root continuation requires its plan owner"));
                };
                let roles = plan
                    .entries()
                    .iter()
                    .find(|candidate| candidate.id == *entry)
                    .and_then(|entry| entry.roles.stateful())
                    .ok_or_else(|| invalid("native Root entry is absent from its plan"))?;
                let role = match self {
                    Self::RootInitializer { .. } => &roles.initializer,
                    Self::RootReducer { .. } => &roles.reducer,
                    _ => unreachable!("matched Root continuation"),
                };
                if !plan.callable_executables().iter().any(|executable| {
                    executable.callable == role.callable
                        && executable.contract == role.contract
                        && executable.code
                            == crate::entry::RuntimeCallableExecutableCode::FunctionSite(site)
                }) {
                    return Err(invalid(
                        "native Root continuation does not match its entry role",
                    ));
                }
            }
            Self::Program { program } => {
                admission.validate_metadata(program)?;
                let Some(crate::task::RuntimeProgramOwner::Plan(plan)) = admission.program_owner()
                else {
                    return Err(invalid(
                        "native program continuation requires its plan owner",
                    ));
                };
                if !plan
                    .resolve_pure_program(*program)
                    .is_ok_and(|binding| binding.site() == site)
                {
                    return Err(invalid(
                        "native program continuation is absent from its plan",
                    ));
                }
            }
            Self::Function { site: target } => {
                admission.validate_metadata(&target.get())?;
                let Some(crate::task::RuntimeProgramOwner::Plan(plan)) = admission.program_owner()
                else {
                    return Err(invalid(
                        "native function continuation requires its plan owner",
                    ));
                };
                if *target != site
                    || crate::pure::RuntimePureFunctionRef::resolve(plan, *target).is_err()
                {
                    return Err(invalid(
                        "native function continuation is absent from its plan",
                    ));
                }
            }
            Self::CallableDefault { pending, .. } => pending.admit_default(site, admission)?,
            Self::Bind { .. } => {}
        }
        Ok(())
    }
}

impl<O, P> FunctionCallFrame<O, P> {
    fn admit_code_position(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        let invalid = |message: &str| crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: message.into(),
        };
        admission.validate_metadata(&self.site.get())?;
        let Some(crate::task::RuntimeProgramOwner::Plan(plan)) = admission.program_owner() else {
            return Err(invalid(
                "native function position requires its original Plan executable",
            ));
        };
        if plan.function_sites().get(self.site).is_none() {
            return Err(invalid(
                "native function frame is absent from its original executable",
            ));
        }
        Ok(())
    }
}

impl<V, O> NativeFormatAttemptFrame<V, O> {
    fn admit_owned_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        binding: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        V: crate::value::RuntimeStoredValue,
        O: NativeStoredWork,
    {
        let invalid = |message: &str| crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: message.into(),
        };
        admission.validate_metadata(&(
            self.attempt.get(),
            &self.context,
            self.next_operand,
            &self.first_recoverable,
        ))?;
        admission.validate_metadata_collection(self.values.len())?;
        let owner = admission
            .program_owner()
            .cloned()
            .ok_or_else(|| invalid("native formatter requires its original executable"))?;
        let crate::task::RuntimeProgramOwner::Plan(plan) = owner else {
            return Err(invalid(
                "native formatter requires its original Plan executable",
            ));
        };
        let manifest = plan.format_attempt(self.attempt).ok_or_else(|| {
            invalid("native formatter attempt is absent from its original executable")
        })?;
        if self.values.len() != manifest.operands().len() || self.next_operand > self.values.len() {
            return Err(invalid(
                "native formatter operand inventory differs from its original ABI",
            ));
        }
        if let Some(active) = &self.active {
            admission.validate_metadata(&active.ordinal)?;
            if active.ordinal != self.next_operand || active.ordinal >= self.values.len() {
                return Err(invalid(
                    "native formatter active operand differs from its source-order frontier",
                ));
            }
            O::admit_queue(&active.caller_pending_ops, admission, binding)?;
        }
        for (index, (value, operand)) in self.values.iter().zip(manifest.operands()).enumerate() {
            if (index >= self.next_operand && value.is_some())
                || (index < self.next_operand
                    && self.first_recoverable.is_none()
                    && value.is_none())
            {
                return Err(invalid(
                    "native formatter value presence differs from its completion frontier",
                ));
            }
            if let Some(value) = value {
                let expected = plan
                    .type_table()
                    .get(operand.ty())
                    .ok_or_else(|| {
                        invalid("native formatter operand has an unknown original type")
                    })?
                    .semantic_identity();
                admission.validate_owned_typed_borrowed_in_invocation(
                    value.borrowed_value(),
                    expected,
                    binding,
                )?;
            }
        }
        Ok(())
    }
}

impl<N, P, Q, FV, FP, O, C, A, AS, MS, D>
    Engine<
        N,
        P,
        crate::root::RootRuntime<Q>,
        NativeFlowExecutionFrame<FV, FP, O, C, A, FlowFiberStatus<AS, MS>>,
        D,
    >
{
    pub(super) fn admit_root_execution(
        &self,
        suspended: Option<&NativeFlowExecutionFrame<FV, FP, O, C, A, FlowFiberStatus<AS, MS>>>,
    ) -> Result<(), String>
    where
        C: ScopeControl<O>,
    {
        if !matches!(self.main_fiber().owner, FlowFiberOwner::Executor) {
            return Err("native main fiber does not have its executor owner".into());
        }
        let main = self.session_frame(self.main_fiber(), suspended);
        crate::presentation::resources::PresentationExecutionRole::Root
            .validate_registration_bank(main.presentation_bank)
            .map_err(|error| error.to_string())?;
        main.admit_root_phase(
            self.root.as_ref(),
            &self.main_fiber().owner,
            matches!(main.status, FlowFiberStatus::Failed(_)),
        )?;
        let mut reducer_count = 0;
        for child in self.session_children() {
            let frame = self.session_frame(child, suspended);
            let root = if matches!(child.owner, FlowFiberOwner::RootReducer { .. }) {
                if !matches!(frame.status, FlowFiberStatus::Running) {
                    return Err("native Root reducer is not a running pure frame".into());
                }
                reducer_count += 1;
                self.root.as_ref()
            } else {
                None
            };
            frame.admit_root_phase(root, &child.owner, false)?;
        }
        let evaluating = self.root.as_ref().is_some_and(|root| {
            matches!(
                root.active().phase,
                crate::root::RootPhase::Initialized {
                    reducer: crate::root::RootReducerPhase::Evaluating,
                    ..
                }
            )
        });
        if reducer_count != usize::from(evaluating) {
            return Err(
                "native Root reducer phase does not have exactly its executable fiber".into(),
            );
        }
        if evaluating
            && !self
                .session_children()
                .next()
                .is_some_and(|child| matches!(child.owner, FlowFiberOwner::RootReducer { .. }))
        {
            return Err("native Root reducer lost its executor priority".into());
        }
        Ok(())
    }
}

impl<V, P, O, C, A, S> NativeFlowExecutionFrame<V, P, O, C, A, S> {
    pub(super) fn admit_root_phase<Q>(
        &self,
        root: Option<&crate::root::RootRuntime<Q>>,
        owner: &FlowFiberOwner,
        failed: bool,
    ) -> Result<(), String>
    where
        C: ScopeControl<O>,
    {
        let mut functions = self
            .control_stack
            .iter()
            .filter_map(ScopeControl::function_context);
        let invocation = functions.next().and_then(|context| context.root);
        if functions.any(|context| context.root.is_some()) {
            return Err("native Root role is not the invocation root".into());
        }
        match (owner, root, invocation) {
            (FlowFiberOwner::Executor, Some(root), Some(RootInvocation::Initializer(entry)))
                if root.active().entry == *entry
                    && matches!(
                        root.active().phase,
                        crate::root::RootPhase::Initializing { .. }
                    ) =>
            {
                Ok(())
            }
            (
                FlowFiberOwner::RootReducer { entry: owner_entry },
                Some(root),
                Some(RootInvocation::Reducer(entry)),
            ) if owner_entry == entry
                && root.active().entry == *entry
                && matches!(
                    root.active().phase,
                    crate::root::RootPhase::Initialized {
                        reducer: crate::root::RootReducerPhase::Evaluating,
                        ..
                    }
                ) =>
            {
                Ok(())
            }
            (FlowFiberOwner::Executor, Some(root), None)
                if !matches!(
                    root.active().phase,
                    crate::root::RootPhase::Initializing { .. }
                ) || failed =>
            {
                Ok(())
            }
            (
                FlowFiberOwner::Executor
                | FlowFiberOwner::FlowDefer { .. }
                | FlowFiberOwner::LineTask(_)
                | FlowFiberOwner::DialogueEffectCallback { .. },
                None,
                None,
            ) => Ok(()),
            _ => Err("native Root phase does not match its executable fiber origin".into()),
        }
    }

    pub(super) fn defer_target(&self, boundary: NativeDeferBoundary) -> Option<usize>
    where
        C: ScopeControl<O>,
    {
        self.control_stack
            .iter()
            .enumerate()
            .rev()
            .take_while(|(_, entry)| {
                boundary == NativeDeferBoundary::Flow || entry.function_context().is_none()
            })
            .filter_map(|(index, entry)| {
                entry
                    .defer_scope()
                    .filter(|scope| scope.has_work())
                    .map(|_| index)
            })
            .last()
    }

    pub(super) fn admit_owned_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        V: crate::value::RuntimeStoredValue,
        P: crate::value::RuntimeStoredValue,
        O: NativeStoredWork,
        C: ScopeControl<O>,
        A: SuspendedValues,
        S: SuspendedValues + NativeInvocationStatus,
    {
        let invalid =
            |message: String| crate::value::AwbcRuntimeValueSnapshotError::Message { message };
        admission.status()?;
        let owner_check = match admission.program_owner() {
            Some(owner) => self.ensure_program_owner(owner),
            None => Err("execution frame requires its original executable".into()),
        };
        if let Err(message) = owner_check {
            let error = invalid(message);
            admission.retain_failure(error.clone());
            return Err(error);
        }
        admission.validate_metadata(&(self.line_cursor, self.presentation_bank))?;
        admission.validate_metadata_collection(self.root_cleanups.len())?;
        for cleanup in &self.root_cleanups {
            admission.validate_metadata_string(&cleanup.key)?;
        }
        admission.validate_metadata_collection(self.stream_states.len())?;
        admission.validate_metadata_collection(self.control_stack.len())?;
        if let Some(state) = &self.await_observer {
            state.admit_suspended_values(admission, self.env.function_instantiation())?;
        }
        self.status
            .admit_suspended_values(admission, self.env.function_instantiation())?;
        self.env.admit_retained(admission)?;
        self.status.admit_frame_context(&self.env, admission)?;
        O::admit_queue(
            &self.pending_ops,
            admission,
            self.env.function_instantiation(),
        )?;
        self.admit_function_contexts(admission)?;
        if let Err(message) =
            self.observations
                .admit_values(admission, P::borrowed_value, "retained")
        {
            return Err(admission.status().err().unwrap_or_else(|| invalid(message)));
        }
        for (id, stream) in &self.stream_states {
            admission.validate_metadata(id)?;
            if id != &stream.id {
                return Err(invalid(
                    "native stream key differs from its retained owner".into(),
                ));
            }
            stream.admit_native_retained(admission)?;
        }
        if let Some(value) = &self.selected_dialogue_result {
            admission.validate_owned_borrowed(value.borrowed_value())?;
        }
        if let Some(exit) = &self.lexical_exit {
            if let NativeLexicalExitAction::Return { source, .. } = &exit.action {
                let function = self
                    .env
                    .function_contexts()
                    .next_back()
                    .map(|(site, _)| site);
                if self.defer_target(NativeDeferBoundary::Invocation) != Some(exit.target)
                    || function.is_some_and(|site| {
                        source.owner() != crate::plan::code::RuntimeCodeOwner::Function(site)
                    })
                {
                    return Err(invalid(
                        "native return does not reach its original invocation and defer scope"
                            .into(),
                    ));
                }
            } else if let NativeLexicalExitAction::Fallthrough { site } = &exit.action {
                if self.defer_target(NativeDeferBoundary::Invocation) != Some(exit.target)
                    || self
                        .env
                        .function_contexts()
                        .next_back()
                        .map(|(site, _)| site)
                        != Some(*site)
                    || self.pending_ops.len() > 1
                    || self
                        .pending_ops
                        .iter()
                        .any(|work| work.function_end_site() != Some(*site))
                {
                    return Err(invalid(
                        "native fallthrough does not reach its original invocation end and defer scope"
                            .into(),
                    ));
                }
            } else if matches!(exit.action, NativeLexicalExitAction::Goto { .. }) {
                if self.defer_target(NativeDeferBoundary::Flow) != Some(exit.target) {
                    return Err(invalid(
                        "native goto does not reach its outermost defer scope".into(),
                    ));
                }
            } else if self.control_stack.get(exit.target..).is_none_or(|scopes| {
                scopes.is_empty() || scopes.iter().any(|entry| entry.defer_scope().is_none())
            }) {
                return Err(invalid("native lexical exit target is absent".into()));
            }
            exit.admit(admission, self.env.function_instantiation())?;
            if let NativeLexicalExitAction::Transfer(transfer) = &exit.action
                && !self
                    .control_stack
                    .iter()
                    .rev()
                    .take_while(|entry| entry.function_context().is_none())
                    .any(|entry| entry.loop_source() == Some(&transfer.target))
            {
                return Err(invalid(
                    "native lexical exit has no active loop target".into(),
                ));
            }
        }
        self.admit_invocation_result(admission)?;
        Ok(())
    }

    fn admit_invocation_result(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        V: crate::value::RuntimeStoredValue,
    {
        let Some((root, value)) = &self.invocation_result else {
            return Ok(());
        };
        let invalid =
            |message: String| crate::value::AwbcRuntimeValueSnapshotError::Message { message };
        let crate::task::RuntimeProgramOwner::Plan(plan) = &self.program else {
            return Err(invalid(
                "native invocation result has no original Plan".into(),
            ));
        };
        let expected = match root {
            NativeInvocationRoot::Program(program) => {
                admission.validate_metadata(program)?;
                plan.pure_program_binding(*program)
                    .map_err(|error| invalid(error.to_string()))?
                    .result_type()
            }
            NativeInvocationRoot::Function(site) => {
                admission.validate_metadata(&site.get())?;
                let function = crate::pure::RuntimePureFunctionRef::resolve(plan, *site)
                    .map_err(|error| invalid(error.to_string()))?;
                plan.type_table()
                    .get(function.result_type())
                    .ok_or_else(|| {
                        invalid("native function result has an unknown original type".into())
                    })?
                    .semantic_identity()
            }
            NativeInvocationRoot::Task(launch) => {
                return launch.admit_result(value, admission);
            }
        };
        admission.validate_owned_typed_borrowed(value.borrowed_value(), expected)
    }

    fn admit_function_contexts(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        O: NativeStoredWork,
        C: ScopeControl<O>,
        S: NativeInvocationStatus,
    {
        let invalid = || crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: "native function frames disagree with their retained environment contexts"
                .into(),
        };
        let mut root = O::queued_function_root_owner(&self.pending_ops, admission)?;
        let mut contexts = self.env.function_contexts().rev().peekable();
        let mut body_scope = false;
        let retiring = self.status.retires_invocation_scopes()
            || self
                .lexical_exit
                .as_ref()
                .is_some_and(|exit| matches!(exit.action, NativeLexicalExitAction::Goto { .. }));
        for entry in self.control_stack.iter().rev() {
            if let Some(site) = entry.function_body_site() {
                if body_scope || contexts.peek().map(|(expected, _)| *expected) != Some(site) {
                    return Err(invalid());
                }
                admission.validate_metadata(&site.get())?;
                body_scope = true;
            }
            if let Some(frame) = entry.function_context() {
                if frame.entered && !body_scope && !retiring {
                    return Err(invalid());
                }
                let expected_root = if frame.expression {
                    None
                } else {
                    Some(crate::plan::code::RuntimeCodeOwner::Function(frame.site))
                };
                if root != expected_root {
                    return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                        message: "active function differs from its original code owner".into(),
                    });
                }
                root = None;
                body_scope = false;
                admission.validate_metadata(&(frame.site.get(), frame.entered))?;
                let Some((site, binding)) = contexts.next() else {
                    return Err(invalid());
                };
                if !frame.entered
                    || frame.site != site
                    || frame.instantiation != binding.map(Arc::as_ref)
                {
                    return Err(invalid());
                }
            }
            entry.visit_scope_state(|state| {
                if let ScopeState::Pending(work) = state {
                    let pending_root = O::queued_function_root_owner(work, admission)?;
                    if let Some(pending_root) = pending_root {
                        if root.replace(pending_root).is_some() {
                            return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                                message:
                                    "native code context retains multiple original function roots"
                                        .into(),
                            });
                        }
                    }
                }
                Ok(())
            })?;
            let binding = contexts
                .peek()
                .and_then(|(_, binding)| binding.map(Arc::as_ref));
            entry.admit_control_values(admission, binding)?;
        }
        // A real function root retains its body scope without a return frame.
        // A task kernel may instead retain an ambient function type context:
        // its original task scope owns that body, rather than an invocation of
        // the enclosing function. Nested calls above either root zip exactly.
        let outer = contexts.next();
        if (root.is_some() && outer.is_some() && !body_scope && !retiring)
            || contexts.next().is_some()
            || root.is_some_and(|root| {
                Some(root)
                    != outer.map(|(site, _)| crate::plan::code::RuntimeCodeOwner::Function(site))
            })
        {
            return Err(invalid());
        }
        Ok(())
    }
}

pub(super) enum ScopeBoundary<'a> {
    Open(
        &'a crate::scope::RuntimeScopeIdentity,
        crate::scope::RuntimeScheduledScopeToken,
    ),
    Close(crate::scope::RuntimeScheduledScopeToken),
}

pub(super) trait ScopeOperation {
    fn scope_boundary(&self) -> Option<ScopeBoundary<'_>>;
}

impl<V, I> ScopeOperation for NativePendingWork<V, I> {
    fn scope_boundary(&self) -> Option<ScopeBoundary<'_>> {
        match &self.kind {
            NativePendingWorkKind::Resume(NativeRuntimeContinuation::EnterScheduledScope {
                identity,
                token,
            }) => Some(ScopeBoundary::Open(identity, *token)),
            NativePendingWorkKind::Resume(NativeRuntimeContinuation::ExitScheduledScope {
                token,
            }) => Some(ScopeBoundary::Close(*token)),
            _ => None,
        }
    }
}

pub(super) enum ScopeState<'a, O> {
    Frame(crate::scope::RuntimeScheduledScopeToken),
    Pending(&'a VecDeque<O>),
}

pub(super) struct FunctionContext<'a> {
    site: crate::runtime_id::RuntimeFunctionSiteId,
    entered: bool,
    expression: bool,
    instantiation: Option<&'a crate::program_types::RuntimeFunctionEffectInstantiation>,
    root: Option<RootInvocation<'a>>,
}

enum RootInvocation<'a> {
    Initializer(&'a crate::plan::EntryRuntimeId),
    Reducer(&'a crate::plan::EntryRuntimeId),
}

pub(super) trait ScopeControl<O> {
    type DeferValue: crate::value::RuntimeStoredValue;

    fn defer_scope(&self) -> Option<&super::defer::NativeLexicalDeferScope<Self::DeferValue>>;

    fn loop_source(&self) -> Option<&NativeSourceOperation>;

    fn function_context(&self) -> Option<FunctionContext<'_>>;
    fn function_body_site(&self) -> Option<crate::runtime_id::RuntimeFunctionSiteId>;
    fn admit_control_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        binding: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>;
    fn visit_scope_state<E>(
        &self,
        visit: impl FnMut(ScopeState<'_, O>) -> Result<(), E>,
    ) -> Result<(), E>;
}

impl<O, P, V> ScopeControl<O>
    for FlowControlStackEntryKind<FunctionCallFrame<O, P>, NativeFormatAttemptFrame<V, O>, V>
where
    V: crate::value::RuntimeStoredValue,
    P: PendingStorage,
    O: NativeStoredWork,
{
    type DeferValue = V;

    fn defer_scope(&self) -> Option<&super::defer::NativeLexicalDeferScope<V>> {
        match self {
            Self::Scope { defers, .. } => Some(defers),
            _ => None,
        }
    }

    fn loop_source(&self) -> Option<&NativeSourceOperation> {
        FlowControlStackEntryKind::loop_source(self)
    }

    fn function_body_site(&self) -> Option<crate::runtime_id::RuntimeFunctionSiteId> {
        match self {
            Self::Scope {
                origin: crate::scope::RuntimeScopeFrameOrigin::FunctionBody(site),
                ..
            } => Some(*site),
            _ => None,
        }
    }

    fn admit_control_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        binding: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        match self {
            Self::Scope {
                match_guard,
                defers,
                ..
            } => {
                if let Some(guard) = match_guard {
                    guard.admit_retained(admission)?;
                }
                defers.admit_roots(admission, super::defer::NativeDeferScopeOwner::Control)
            }
            Self::Loop { source }
            | Self::While { source }
            | Self::WhileLet { source }
            | Self::For { source } => {
                source.admit_retained(admission)?;
                let Some(crate::task::RuntimeProgramOwner::Plan(plan)) = admission.program_owner()
                else {
                    unreachable!("an admitted Native source reference has its Plan owner")
                };
                if !matches!(
                    (self, source.operation(plan)),
                    (Self::Loop { .. }, Some(crate::plan::FlowOp::Loop { .. }))
                        | (Self::While { .. }, Some(crate::plan::FlowOp::While { .. }))
                        | (Self::For { .. }, Some(crate::plan::FlowOp::For { .. }))
                        | (
                            Self::WhileLet { .. },
                            Some(crate::plan::FlowOp::WhileLet { .. })
                        )
                ) {
                    return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                        message: "native loop frame differs from its original header".into(),
                    });
                }
                Ok(())
            }
            Self::FormatAttempt(frame) => frame.admit_owned_values(admission, binding),
            Self::FunctionCall(frame) => {
                frame.admit_code_position(admission)?;
                frame
                    .continuation
                    .admit_header_and_packet(frame.site, admission)?;
                O::admit_queue(&frame.caller_pending_ops, admission, binding)
            }
        }
    }

    fn function_context(&self) -> Option<FunctionContext<'_>> {
        match self {
            Self::FunctionCall(frame) => Some(FunctionContext {
                site: frame.site,
                entered: frame.function_scope,
                expression: matches!(frame.continuation, FunctionReturnContinuation::Expression),
                instantiation: frame.type_instantiation.as_deref(),
                root: match &frame.continuation {
                    FunctionReturnContinuation::RootInitializer { entry } => {
                        Some(RootInvocation::Initializer(entry))
                    }
                    FunctionReturnContinuation::RootReducer { entry } => {
                        Some(RootInvocation::Reducer(entry))
                    }
                    _ => None,
                },
            }),
            _ => None,
        }
    }

    fn visit_scope_state<E>(
        &self,
        mut visit: impl FnMut(ScopeState<'_, O>) -> Result<(), E>,
    ) -> Result<(), E> {
        match self {
            Self::Scope {
                origin: crate::scope::RuntimeScopeFrameOrigin::Scheduled(token),
                ..
            } => visit(ScopeState::Frame(*token)),
            Self::FunctionCall(frame) => visit(ScopeState::Pending(&frame.caller_pending_ops)),
            Self::FormatAttempt(frame) => {
                if let Some(active) = &frame.active {
                    visit(ScopeState::Pending(&active.caller_pending_ops))?;
                }
                Ok(())
            }
            _ => Ok(()),
        }
    }
}

impl ScopeControl<NativePendingWork> for FlowControlStackEntry {
    type DeferValue = crate::value::RuntimeValue;

    fn function_body_site(&self) -> Option<crate::runtime_id::RuntimeFunctionSiteId> {
        self.kind.function_body_site()
    }

    fn defer_scope(&self) -> Option<&super::defer::NativeLexicalDeferScope<Self::DeferValue>> {
        self.kind.defer_scope()
    }

    fn loop_source(&self) -> Option<&NativeSourceOperation> {
        self.kind.loop_source()
    }

    fn admit_control_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        binding: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        self.kind.admit_control_values(admission, binding)
    }

    fn function_context(&self) -> Option<FunctionContext<'_>> {
        self.kind.function_context()
    }

    fn visit_scope_state<E>(
        &self,
        visit: impl FnMut(ScopeState<'_, NativePendingWork>) -> Result<(), E>,
    ) -> Result<(), E> {
        self.kind.visit_scope_state(visit)
    }
}

impl<N, P, R, FV, FP, O, C, A, S, D>
    Engine<N, P, R, NativeFlowExecutionFrame<FV, FP, O, C, A, S>, D>
{
    pub(super) fn validate_scheduled_scope_state(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        suspended: Option<&NativeFlowExecutionFrame<FV, FP, O, C, A, S>>,
    ) -> Result<(), String>
    where
        O: ScopeOperation,
        C: ScopeControl<O>,
    {
        // Bound the complete borrowed inventory before constructing validation
        // sets. Saved rows remain inert throughout these same scope laws.
        for fiber in self.session_fibers() {
            let frame = self.session_frame(fiber, suspended);
            admission
                .validate_metadata_collection(frame.pending_ops.len())
                .map_err(|error| error.to_string())?;
            admission
                .validate_metadata_collection(frame.control_stack.len())
                .map_err(|error| error.to_string())?;
            for entry in &frame.control_stack {
                entry.visit_scope_state(|state| match state {
                    ScopeState::Frame(token) => admission
                        .validate_metadata(&token)
                        .map_err(|error| error.to_string()),
                    ScopeState::Pending(ops) => admission
                        .validate_metadata_collection(ops.len())
                        .map_err(|error| error.to_string()),
                })?;
            }
        }
        if self.next_scheduled_scope_sequence == 0 {
            return Err("native control scope allocator is zero".into());
        }
        let mut opened = BTreeSet::new();
        let mut closed = BTreeSet::new();
        for fiber in self.session_fibers() {
            let frame = self.session_frame(fiber, suspended);
            let valid = |token: crate::scope::RuntimeScheduledScopeToken| {
                token.belongs_to(fiber.execution, fiber.persistent_id)
                    && token.ordinal().get() < self.next_scheduled_scope_sequence
            };
            for entry in &frame.control_stack {
                entry.visit_scope_state::<String>(|state| {
                    if let ScopeState::Frame(token) = state
                        && (!valid(token) || !opened.insert(token))
                    {
                        return Err(
                            "native scope frame has a foreign, repeated, or unallocated token"
                                .into(),
                        );
                    }
                    Ok(())
                })?;
            }
            let mut pending = |ops: &VecDeque<O>| -> Result<(), String> {
                for op in ops {
                    match op.scope_boundary() {
                        Some(ScopeBoundary::Open(identity, token)) => {
                            admission
                                .validate_metadata(identity)
                                .map_err(|error| error.to_string())?;
                            if token.kind() == crate::scope::RuntimeScopeFrameKind::Control
                                && !matches!(
                                    identity,
                                    crate::scope::RuntimeScopeIdentity::Anonymous
                                )
                            {
                                return Err(
                                    "native generated scope carries an authored namespace".into()
                                );
                            }
                            if !valid(token) || !opened.insert(token) {
                                return Err("native pending scope open has a foreign, repeated, or unallocated token".into());
                            }
                        }
                        Some(ScopeBoundary::Close(token))
                            if !valid(token) || !closed.insert(token) =>
                        {
                            return Err("native pending scope close has a foreign, repeated, or unallocated token".into());
                        }
                        Some(ScopeBoundary::Close(_)) | None => {}
                    }
                }
                Ok(())
            };
            pending(&frame.pending_ops)?;
            for entry in &frame.control_stack {
                entry.visit_scope_state(|state| match state {
                    ScopeState::Pending(ops) => pending(ops),
                    ScopeState::Frame(_) => Ok(()),
                })?;
            }
            if let Some(exit) = &frame.lexical_exit
                && let NativeLexicalExitAction::Scheduled(token) = exit.action
            {
                let target = frame
                    .control_stack
                    .get(exit.target)
                    .ok_or_else(|| "native lexical exit target is absent".to_owned())?;
                let mut target_matches = false;
                target.visit_scope_state::<String>(|state| {
                    target_matches |=
                        matches!(state, ScopeState::Frame(frame_token) if frame_token == token);
                    Ok(())
                })?;
                if !target_matches || !valid(token) || !closed.insert(token) {
                    return Err("native lexical exit does not own the exact scheduled close".into());
                }
            }
        }
        if opened != closed {
            return Err(
                "native scope frames and queued exact close markers are not bijective".into(),
            );
        }
        Ok(())
    }
}

impl<N, P, R, F, D> Engine<N, P, R, F, D> {
    /// Scheduling parks the original receiver while an attached child uses
    /// its own physical local namespace.
    pub(super) fn published_receiver_execution(&self) -> crate::runtime_id::ExecutionInstanceId {
        self.parked_main.as_ref().unwrap_or(&self.fiber).execution
    }

    pub(super) fn admit_metadata(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        admission.validate_metadata(&(
            self.evaluation_stats.evaluated_exprs,
            self.evaluation_stats.evaluated_calls,
            self.evaluation_stats.evaluated_binary_ops,
        ))?;
        admission.validate_metadata(&self.format_context)?;
        admission.validate_metadata(&(
            self.generation,
            self.task_request_quota_remaining,
            self.main_started,
            self.next_fiber_id,
            self.next_scheduled_scope_sequence,
            self.flow_defer_frontier,
            self.run_child_next,
            self.audio_epoch,
            self.next_audio_sequence,
            self.next_host_call_sequence,
        ))?;
        admission.validate_metadata(&self.scalar_step_charge)?;
        admission.validate_metadata(&self.need_publication_frontiers)?;
        admission.validate_metadata(&self.dialogue_occurrences)?;
        admission.validate_metadata(&self.dialogue_effect_callback_activations)?;
        admission.validate_metadata(&self.pure_i64_batch_inputs)?;
        admission.validate_metadata(&self.pure_i64_batch_outputs)?;
        admission.validate_metadata(&self.pure_helper_i64_call_shapes)?;
        if self.pure_helper_i64_call_shapes.len() != self.plan.pure_helpers.len() {
            return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                message: "native pure-helper cache differs from its original inventory".into(),
            });
        }
        for (shape, helper) in self
            .pure_helper_i64_call_shapes
            .iter()
            .zip(&self.plan.pure_helpers)
        {
            admission.validate_metadata_collection(helper.inputs.len())?;
            if *shape != eval::pure_helper_has_i64_call_shape(helper) {
                return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                    message: "native pure-helper cache differs from its original signature".into(),
                });
            }
        }
        admission.validate_metadata_collection(self.need_publications.len())?;
        for (correlation, queue) in &self.need_publications {
            admission.validate_metadata(correlation)?;
            admission.validate_metadata_collection(queue.len())?;
        }
        admission.validate_metadata_collection(self.latest_need_publications.len())?;
        admission.validate_metadata_collection(self.child_fibers.len())?;
        let invalid_identity = || crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: "native fiber identities do not follow their original allocator".into(),
        };
        if self.main_fiber().id.0 != 0
            || self.main_fiber().parent.is_some()
            || self.main_fiber().launch != super::FlowFiberLaunch::Local
        {
            return Err(invalid_identity());
        }
        let mut fiber_ids = BTreeSet::new();
        for fiber in self.session_fibers() {
            admission.validate_metadata(&(
                fiber.id,
                fiber.parent,
                &fiber.launch,
                fiber.persistent_id,
                fiber.execution,
                &fiber.owner,
            ))?;
            if fiber.id.0 >= self.next_fiber_id
                || !fiber_ids.insert(fiber.id.0)
                || !fiber.id.matches_persistent(fiber.persistent_id)
                || fiber.execution.get().get() != fiber.persistent_id.get()
            {
                return Err(invalid_identity());
            }
        }
        for child in self.session_children() {
            if let FlowFiberOwner::DialogueEffectCallback { activation, .. } = &child.owner
                && !self
                    .dialogue_effect_callback_activations
                    .contains(activation)
            {
                return Err(invalid_identity());
            }
            let Some(parent) = child.parent else {
                return Err(invalid_identity());
            };
            let defer_control = matches!(&child.owner,
                FlowFiberOwner::LineTask(owner)
                    if matches!(owner.defer_parent, Some(super::defer::NativeDeferParent::Control { .. })));
            if parent.0 >= child.id.0
                || (child.owner.has_joined_work() && !fiber_ids.contains(&parent.0))
                || (!defer_control
                    && child.owner.dialogue_activation().is_some_and(|activation| {
                        !parent.matches_persistent(activation.owner_fiber())
                    }))
                || (defer_control
                    && !self.session_children().any(|candidate| {
                        candidate.id == parent
                            && candidate.owner.dialogue_activation()
                                == child.owner.dialogue_activation()
                    }))
            {
                return Err(invalid_identity());
            }
        }
        Ok(())
    }

    pub(super) fn admit_publications(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        P: crate::value::RuntimeStoredValue,
    {
        let invalid = |message: &str| crate::value::AwbcRuntimeValueSnapshotError::Message {
            message: message.to_owned(),
        };
        if self.latest_need_publications.len() != self.need_publication_frontiers.len() {
            return Err(invalid("native latest publications and frontiers differ"));
        }
        for (correlation, latest) in &self.latest_need_publications {
            admission.validate_metadata(correlation)?;
            if latest.correlation() != *correlation
                || self.need_publication_frontiers.get(correlation) != Some(&latest.cursor())
            {
                return Err(invalid(
                    "native latest publication differs from its correlation/frontier",
                ));
            }
            latest.admit_retained(admission)?;
        }
        for (correlation, queue) in &self.need_publications {
            let mut previous = None;
            for publication in queue {
                let cursor = publication.cursor();
                if publication.correlation() != *correlation
                    || previous.is_some_and(|previous: TaskPublicationCursor| {
                        previous.compare_same_source(cursor) != Some(std::cmp::Ordering::Less)
                    })
                {
                    return Err(invalid(
                        "native queued publications are cross-correlation or unordered",
                    ));
                }
                publication.admit_retained(admission)?;
                previous = Some(cursor);
            }
            if previous.is_some()
                && self.need_publication_frontiers.get(correlation) != previous.as_ref()
            {
                return Err(invalid(
                    "native queued publication tail differs from its frontier",
                ));
            }
        }
        Ok(())
    }

    pub(super) fn expected_deferred_children(
        &self,
        inflight: impl Fn(
            &DialogueActivationId,
        ) -> Option<(
            crate::runtime_id::RuntimeDeferRegistrationId,
            crate::runtime_id::RuntimeDeferSiteId,
        )>,
    ) -> Result<
        BTreeMap<
            DialogueActivationId,
            (
                crate::runtime_id::RuntimeDeferRegistrationId,
                crate::runtime_id::RuntimeDeferSiteId,
            ),
        >,
        String,
    > {
        let mut expected_deferred_children = BTreeMap::new();
        for child in self.session_children() {
            let FlowFiberOwner::LineTask(child_owner) = &child.owner else {
                continue;
            };
            let crate::line_task::LineTaskWork::Defer(id) = child_owner.tag.work() else {
                continue;
            };
            if child_owner.defer_parent != Some(super::defer::NativeDeferParent::Root) {
                continue;
            }
            let activation = child_owner.tag.activation_id();
            let Some((inflight_id, site)) = inflight(activation) else {
                return Err("native root defer child has no in-flight registration".into());
            };
            if inflight_id != id
                || expected_deferred_children
                    .insert(activation.clone(), (id, site))
                    .is_some()
            {
                return Err("native deferred child custody is inconsistent".to_owned());
            }
        }
        Ok(expected_deferred_children)
    }
}

impl<N, P, R, V, FP, O, C, A, S, D>
    Engine<N, P, R, NativeFlowExecutionFrame<V, FP, O, C, A, S>, D>
{
    fn validate_lexical_defer_contour<'a>(
        &self,
        reached: impl Fn(&DialogueActivationId) -> Option<super::defer::NativeReachedLineDefers<'a, V>>,
        published: impl Fn(
            &crate::runtime_id::RuntimeLineHandleToken,
        ) -> Option<&'a crate::line_task::RuntimeHandleLease>,
    ) -> Result<(), String>
    where
        V: crate::value::RuntimeStoredValue + 'a,
        C: ScopeControl<O, DeferValue = V>,
    {
        use super::defer::NativeDeferParent;
        use crate::line_task::{LineTaskWork, RuntimeHandleOwnerSlot};
        let invalid =
            || "native defer is not paired with its exact reached lexical owner".to_owned();
        let mut pending = BTreeMap::new();
        let mut registrations = BTreeMap::<_, Vec<_>>::new();
        let mut flow_registrations = BTreeSet::new();
        let mut scoped_tokens = BTreeSet::new();
        for child in self.session_fibers() {
            if let Some(exit) = &child.frame.lexical_exit
                && matches!(exit.action, NativeLexicalExitAction::Goto { .. })
                && !child.owner.owns_flow_defers()
            {
                return Err(invalid());
            }
            if let Some(super::defer::NativeLexicalExit {
                action: NativeLexicalExitAction::Return { result, .. },
                ..
            }) = &child.frame.lexical_exit
            {
                let typed = matches!(child.launch, super::FlowFiberLaunch::Program(_))
                    || child
                        .frame
                        .control_stack
                        .iter()
                        .any(|entry| entry.function_context().is_some());
                if typed != matches!(result, super::defer::NativeReturnResult::Value(_)) {
                    return Err(invalid());
                }
            }
            for (index, entry) in child.frame.control_stack.iter().enumerate() {
                let Some(scope) = entry.defer_scope().filter(|scope| scope.has_work()) else {
                    continue;
                };
                let line = match &child.owner {
                    FlowFiberOwner::LineTask(owner) => {
                        let activation = *owner.tag.activation_id();
                        let (line, _) = reached(&activation).ok_or_else(invalid)?;
                        registrations
                            .entry(activation)
                            .or_default()
                            .extend(scope.ids());
                        Some((activation, line))
                    }
                    FlowFiberOwner::Executor | FlowFiberOwner::FlowDefer { .. } => {
                        if scope.ids().any(|id| {
                            !self.flow_defer_frontier.contains(id) || !flow_registrations.insert(id)
                        }) {
                            return Err(invalid());
                        }
                        None
                    }
                    _ => return Err(invalid()),
                };
                if let Some(inflight) = &scope.inflight {
                    if child.frame.control_stack.len().checked_sub(1) != Some(index)
                        || pending
                            .insert(
                                (line.map(|(activation, _)| activation), child.id, index),
                                (inflight, child.frame.presentation_bank),
                            )
                            .is_some()
                    {
                        return Err(invalid());
                    }
                }
                for registration in &scope.deferred {
                    for (ordinal, value) in registration.packet.captures().iter().enumerate() {
                        let ordinal = u32::try_from(ordinal).map_err(|_| invalid())?;
                        for handle in value
                            .borrowed_view()
                            .line_handle_projection()
                            .map_err(|_| invalid())?
                        {
                            let (lease, expected) = if let Some((activation, line)) = line
                                && handle.token().activation() == &activation
                            {
                                (
                                    line.ledger().lease(handle.token()),
                                    RuntimeHandleOwnerSlot::ScopedDefer(registration.packet.id()),
                                )
                            } else {
                                let slot = match line {
                                    Some((activation, _)) => crate::value::ownership::RuntimeOwnedSlotId::LineDeferCapture {
                                        execution: child.execution,
                                        activation,
                                        registration: registration.packet.id(),
                                        ordinal,
                                    },
                                    None => crate::value::ownership::RuntimeOwnedSlotId::NativeDeferCapture {
                                        execution: child.execution,
                                        fiber: child.persistent_id,
                                        registration: registration.packet.id(),
                                        ordinal,
                                    },
                                };
                                (
                                    published(handle.token()),
                                    RuntimeHandleOwnerSlot::parent_fiber(
                                        self.published_receiver_execution(),
                                        slot,
                                    ),
                                )
                            };
                            if !scoped_tokens.insert(handle.token().clone())
                                || lease.is_none_or(|lease| {
                                    lease.validate_deferred_capture(&handle, &expected).is_err()
                                })
                            {
                                return Err(invalid());
                            }
                        }
                    }
                }
            }
        }
        for (activation, ids) in registrations {
            let (line, activation_scopes) = reached(&activation).ok_or_else(invalid)?;
            line.admit_restored_scoped_defer_registrations(
                activation_scopes
                    .iter()
                    .flat_map(|scope| scope.ids())
                    .chain(ids),
            )
            .map_err(|error| error.to_string())?;
        }
        let mut activation_children = BTreeSet::new();
        for child in self.session_children() {
            if let FlowFiberOwner::FlowDefer {
                scope,
                registration,
                site,
            } = &child.owner
            {
                let parent = child.parent.ok_or_else(invalid)?;
                let (inflight, bank) = pending
                    .remove(&(None, parent, *scope))
                    .ok_or_else(invalid)?;
                let function = self.plan.defer_function_site(*site).ok_or_else(invalid)?;
                if inflight.id != *registration
                    || inflight.site != *site
                    || child.frame.presentation_bank != bank
                    || child
                        .frame
                        .env
                        .function_contexts()
                        .next()
                        .map(|(site, _)| site)
                        != Some(function)
                {
                    return Err(invalid());
                }
                continue;
            }
            let FlowFiberOwner::LineTask(owner) = &child.owner else {
                continue;
            };
            let LineTaskWork::Defer(id) = owner.tag.work() else {
                if owner.defer_parent.is_some() {
                    return Err(invalid());
                }
                continue;
            };
            let activation = owner.tag.activation_id();
            let parent = child.parent.ok_or_else(invalid)?;
            let site = match owner.defer_parent.ok_or_else(invalid)? {
                NativeDeferParent::Root => continue,
                NativeDeferParent::Activation => {
                    let (_, scopes) = reached(activation).ok_or_else(invalid)?;
                    if !activation_children.insert(*activation) {
                        return Err(invalid());
                    }
                    scopes.last().and_then(|scope| scope.inflight.as_ref())
                }
                NativeDeferParent::Control { scope } => pending
                    .remove(&(Some(*activation), parent, scope))
                    .map(|(inflight, _)| inflight),
            }
            .filter(|inflight| inflight.id == id)
            .ok_or_else(invalid)?
            .site;
            let function = self.plan.defer_function_site(site).ok_or_else(invalid)?;
            if child
                .frame
                .env
                .function_contexts()
                .next()
                .map(|(site, _)| site)
                != Some(function)
            {
                return Err(invalid());
            }
        }
        if !pending.is_empty() {
            return Err(invalid());
        }
        Ok(())
    }
}

impl Engine {
    /// The full live owning contour also admits a moved presentation capture
    /// before registration. Metadata, values and custody share this same bank.
    pub(super) fn admit_live_retained_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        self.admit_live_retained_values_for_slot_removal(admission, None)
    }

    pub(super) fn admit_live_retained_values_for_slot_removal(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        removal: Option<crate::presentation::resources::PresentationSlotRemovalAdmission<'_>>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        self.admit_live_fiber_values(admission, removal, None)?;
        if !self.dialogue_activations.inline_stack.is_empty() {
            self.admit_live_dialogue_values(admission)?;
        }
        Ok(())
    }

    pub(super) fn admit_live_dialogue_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        use crate::line_task::RuntimeDialogueRegistrySnapshotError;
        self.dialogue_activations
            .admit_live_with_inline_execution(admission, self.inline_dialogue_execution())
            .map_err(|error| match error {
                RuntimeDialogueRegistrySnapshotError::Value(error) => error,
                error => crate::value::AwbcRuntimeValueSnapshotError::Message {
                    message: error.to_string(),
                },
            })
    }

    pub(super) fn admit_live_fiber_values(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
        removal: Option<crate::presentation::resources::PresentationSlotRemovalAdmission<'_>>,
        transaction: Option<&super::dialogue::DialogueActivationTransaction>,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        use crate::value::AwbcRuntimeValueSnapshotError;
        let suspended = self.inline_dialogue_execution().suspended_frame();
        self.admit_presentation_state_for_slot_removal(admission, removal)?;
        self.admit_metadata(admission)?;
        self.need_producers.admit_retained(admission)?;
        self.actions.admit_retained(admission)?;
        self.admit_publications(admission)?;
        if let Some(root) = &self.root {
            root.admit_retained(admission)?;
        }
        self.admit_root_execution(suspended)
            .map_err(|message| AwbcRuntimeValueSnapshotError::Message { message })?;
        self.validate_scheduled_scope_state(admission, suspended)
            .map_err(|message| AwbcRuntimeValueSnapshotError::Message { message })?;
        for fiber in self.session_fibers() {
            let frame = self.session_frame(fiber, suspended);
            frame.admit_owned_values(admission)?;
            frame.env.validate_presentation_context(
                &frame.program,
                fiber.execution,
                fiber.persistent_id,
            )?;
        }
        self.expected_deferred_children(|activation| {
            transaction
                .into_iter()
                .chain(&self.dialogue_activations.inline_stack)
                .find(|transaction| transaction.activation() == activation)
                .map(super::dialogue::DialogueActivationTransaction::line)
                .or_else(|| self.dialogue_activations.active_line(activation))
                .and_then(crate::line_task::RuntimeDialogueActivationState::deferred_inflight)
        })
        .map_err(|message| AwbcRuntimeValueSnapshotError::Message { message })?;
        self.validate_lexical_defer_contour(
            |activation| {
                transaction
                    .into_iter()
                    .chain(&self.dialogue_activations.inline_stack)
                    .find(|transaction| transaction.activation() == activation)
                    .map(|transaction| (transaction.line(), transaction.frame().scopes.as_slice()))
                    .or_else(|| self.dialogue_activations.active_defer_state(activation))
            },
            |token| self.dialogue_activations.published_lease(token),
        )
        .map_err(|message| AwbcRuntimeValueSnapshotError::Message { message })?;
        Ok(())
    }
}

impl NativeEngineRollbackImage {
    pub(super) fn admit_rollback_values(
        &self,
        owner: &crate::task::RuntimeProgramOwner,
        limits: crate::entry::RuntimeSchemaLimits,
    ) -> Result<(), String> {
        let crate::task::RuntimeProgramOwner::Plan(expected) = owner else {
            return Err("native rollback requires its original Plan executable".into());
        };
        if !Arc::ptr_eq(expected, &self.plan) {
            return Err("native rollback belongs to a different original executable".into());
        }
        let mut admission =
            crate::value::RuntimeRetainedValueAdmission::for_program(owner.clone(), limits);
        self.dialogue_activations.admit_inline_order(
            self.fiber.persistent_id,
            limits,
            &mut admission,
        )?;
        self.admit_presentation_state(&mut admission)
            .map_err(|error| error.to_string())?;
        self.admit_metadata(&mut admission)
            .map_err(|error| error.to_string())?;
        self.need_producers
            .admit_retained(&mut admission)
            .map_err(|error| error.to_string())?;
        self.actions
            .admit_retained(&mut admission)
            .map_err(|error| error.to_string())?;
        self.admit_publications(&mut admission)
            .map_err(|error| error.to_string())?;
        if let Some(root) = &self.root {
            root.admit_retained(&mut admission)
                .map_err(|error| error.to_string())?;
        }
        self.admit_root_execution(None)?;
        self.validate_scheduled_scope_state(&mut admission, None)?;
        for fiber in self.session_fibers() {
            fiber
                .frame
                .admit_owned_values(&mut admission)
                .map_err(|error| error.to_string())?;
            fiber
                .frame
                .env
                .validate_presentation_context(
                    &fiber.frame.program,
                    fiber.execution,
                    fiber.persistent_id,
                )
                .map_err(|error| error.to_string())?;
            if let FlowFiberStatus::WaitingMany(super::WaitingManyStatus::Native(state)) =
                &fiber.frame.status
            {
                for flight in &state.in_flight {
                    if let Some(observed) = flight.observed_through {
                        let correlation =
                            crate::value::RuntimeNeedView::from(&flight.handle).correlation();
                        if !self
                            .need_publication_frontiers
                            .get(&correlation)
                            .is_some_and(|frontier| {
                                matches!(
                                    frontier.compare_same_source(observed),
                                    Some(std::cmp::Ordering::Equal | std::cmp::Ordering::Greater)
                                )
                            })
                        {
                            return Err(
                                "native fanout observer exceeds its retained publication frontier"
                                    .into(),
                            );
                        }
                    }
                }
            }
        }
        let expected_deferred_children = self.expected_deferred_children(|activation| {
            self.dialogue_activations
                .active_line(activation)
                .and_then(crate::line_task::RuntimeDialogueActivationState::deferred_inflight)
        })?;
        self.validate_lexical_defer_contour(
            |activation| self.dialogue_activations.active_defer_state(activation),
            |token| self.dialogue_activations.published_lease(token),
        )?;
        self.dialogue_activations
            .admit_values(&mut admission, &expected_deferred_children, |parent| {
                self.session_fibers()
                    .find(|fiber| fiber.id == parent)
                    .map(|fiber| fiber.execution)
            })
            .map_err(|error| error.to_string())?;
        admission
            .finish_presentation_custody()
            .map_err(|error| error.to_string())
    }
}
