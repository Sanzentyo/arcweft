function Write-VerifiedEvidenceArchive([string]$Root,[string]$Destination,[object[]]$Files) {
    if(Test-Path -LiteralPath $Destination){throw 'Preserve existing archive'}
    $files=@($Files|Sort-Object FullName -Unique);$entries=@()
    $zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($Destination),[IO.Compression.ZipArchiveMode]::Create)
    try{foreach($file in $files){
        if(-not $file.FullName.StartsWith($Root+'\',[StringComparison]::OrdinalIgnoreCase) -and -not $file.FullName.StartsWith($Root+'/',[StringComparison]::OrdinalIgnoreCase)){throw 'Archive source outside exact evidence root'}
        $entry=$file.FullName.Substring($Root.Length+1).Replace('\','/')
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)
        $entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
    }}finally{$zip.Dispose()}
    $zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($Destination))
    try{
        if($zip.Entries.Count -ne $entries.Count){throw 'Archive count mismatch'}
        foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry mismatch'}}
    }finally{$zip.Dispose()}
    return [ordered]@{path=$Destination;bytes=(Get-Item -LiteralPath $Destination).Length;sha256=(Get-FileHash -LiteralPath $Destination).Hash.ToLowerInvariant();entryDrift=0;entries=$entries}
}
