$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$prefix = 'line-initial-inputs-20261108'
$source = Get-Content "$taskTemp/$prefix.initial-save-source.verified.json" -Raw | ConvertFrom-Json
$passed = Get-Content "$taskTemp/$prefix.initial-save-r2.receipt.json" -Raw | ConvertFrom-Json
$failed = Get-Content "$taskTemp/$prefix.initial-save.receipt.json" -Raw | ConvertFrom-Json
if ($passed.exitCode -ne 0 -or $failed.exitCode -ne 100) { throw 'Actual custody receipts differ' }
$archivePath = 'docs/implementation/acceptance-evidence/task-initial-line-input-custody.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Archive already exists' }
$names = @(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix.initial-save*" | ForEach-Object Name) + 'record-initial-input-custody-20261108.ps1' | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object { Join-Path $taskTemp $_ }) -DestinationPath $archivePath -CompressionLevel Optimal
$entries = @(foreach ($name in $names) {
    [ordered]@{ entry = $name; bytes = (Get-Item -LiteralPath "$taskTemp/$name").Length; sha256 = (Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant() }
})
$zip = [IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try {
    if ($zip.Entries.Count -ne $entries.Count) { throw 'Archive entry count differs' }
    foreach ($entry in $zip.Entries) {
        $expected = $entries | Where-Object entry -eq $entry.FullName
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256) { throw 'Archive entry differs' }
    }
} finally { $zip.Dispose() }
$record = [ordered]@{
    version = 1; date = '2026-11-08'; source = $source
    status = 'Accepted additional saved-custody regression; production is unchanged from the prior initial-input acceptance.'
    actual = [ordered]@{ run = 1; passed = 1; failed = 0; skipped = 116; receipt = $passed }
    scope = @(
        'The original Actor input crosses an actual pending Dialogue packet and the actual receiving activation frame, both observed through the public save API.'
        'Ten well-formed save changes are refused: packet execution/fiber/frame/content/input ordinal, removal of its original inputs, and activation execution/fiber/frame/register.'
        'Every refused save leaves the original snapshot equal; the original executor finishes with two reveals, one acquire/release, original log order and one-op/512-step bounds.'
    )
    development = [ordered]@{
        run = 1; passed = 0; failed = 1; skipped = 116; receipt = $failed
        reason = 'The first test wrongly required a missing input packet to fail at bind alone. The admitted container is refused during owned restore. The corrected test accepts refusal at either stage and verifies original-state preservation and successful original continuation.'
    }
    reuse = 'Earlier Compiler 146 PASS remains its original 116-case evaluated_effects plus 30-case scoped_defer run. The new catalog has 117 evaluated_effects cases; only its added regression ran here. Do not claim a full 147-case rerun.'
    remaining = 'The shared-contract workspace matrix and Core reverse closure remain separate validation. No accepted Generic Match, Line/init, Native or ordinary-defer condition is reopened.'
    raw = [ordered]@{ path = 'task-initial-line-input-custody.raw.zip'; sha256 = (Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant(); entries = $entries }
}
$ledgerPath = 'docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger = [IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if ($ledger.Contains('"initialLineInputCustody"')) { throw 'Custody evidence already exists' }
$fragment = ([ordered]@{ initialLineInputCustody = $record } | ConvertTo-Json -Depth 40).Trim().Replace("`r`n", "`n")
$last = $ledger.LastIndexOf('}')
$after = $ledger.Substring(0, $last).TrimEnd() + ",`n  " + $fragment.Substring(1, $fragment.Length - 2).Trim() + "`n}`n"
$null = $after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath), $after, [Text.UTF8Encoding]::new($false))
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$history = [IO.File]::ReadAllText((Join-Path (Get-Location) $historyPath))
$addition = @"

## 2026-11-08 — 初期 Line 入力の公開保存における実 slot 認証

追加テスト Source **$($source.commit)** を既存 main へ通常 commit/push し、親・tree・全 blob・完全差分を照合した。production は変更せず、同じ Actor 再返却の公開保存で実待機 packet と実 activation の両方を観測した。packet の execution／fiber／frame／content／入力 ordinal、その入力 packet の削除、activation の execution／fiber／frame／register の計10改変を拒否。拒否ごとに元 snapshot の同一性を確認し、その executor の元入力は1-op／512-step、2 reveal、取得・解放各1回と元log順で完走した。追加1件は **1 PASS／116 SKIP**。先行146 PASSと合成して全147件runとはしない。

初回の **0 PASS／1 FAIL／116 SKIP** は、packet欠落をbind時だけに拒否するというテスト期待の誤りだった。実際にはowned restoreで拒否される。修正後は両admission段階の拒否を認め、元状態保全と元実行の成功を確認した。初回ログ・修正後ログ・全SHAを保持する。既受入を戻す新規不具合とは扱わない。[実測・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIP は$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText((Join-Path (Get-Location) $historyPath), $history.TrimEnd() + "`n" + $addition.Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$statusPath = 'docs/implementation/current-status.md'
$status = [IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$old = '元入力の未分離・入口／verifier拒否はこの具体的根拠で現状から削除した。'
if (-not $status.Contains($old)) { throw 'Current input row differs' }
$new = $old + '追加Source ' + $source.commit + ' は実packet／activationの10座標・欠落改変を拒否し、元状態保全と元実行完走を1件の選択runで確認した。'
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath), $status.Replace($old, $new), [Text.UTF8Encoding]::new($false))
[ordered]@{ source = $source.commit; entries = $entries.Count; sha256 = $record.raw.sha256 } | ConvertTo-Json -Compress
