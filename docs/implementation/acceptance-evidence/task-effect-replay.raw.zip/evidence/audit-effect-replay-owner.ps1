$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/effect-replay.publication.json"|ConvertFrom-Json
$inputPin=Get-Content -Raw "$root/effect-replay.input.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/effect-replay.owner-validation.json"|ConvertFrom-Json
$previous=Get-Content -Raw "$root/effect-delta.owner-summary.json"|ConvertFrom-Json
$baseline=Get-Content -Raw "$root/effect-delta.owner-terminal.json"|ConvertFrom-Json
if($quality.Source -ne $pub.Parent -or $inputPin.Source -ne $pub.Parent -or $quality.Steps.Count -ne 3){throw 'Owner input differs'}
foreach($step in $quality.Steps){
    $expected=if($step.Name -eq 'owner-run'){100}else{0}
    if($step.ExitCode -ne $expected -or !$step.SourcePinsVerified){throw 'Owner step differs'}
}
$log=[IO.File]::ReadAllText("$root/effect-replay.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1751 tests run: 1745 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Owner terminal summary differs'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1751\) (\S+) (.+)\r?$')|ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/effect-replay.owner-list.json"|ConvertFrom-Json
$ids=@(foreach($suite in $listing.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Name+'$'+$case.Name}}})
if($ids.Count -ne 1751 -or $terminal.Count -ne 1751 -or @($terminal|Group-Object Id|Where-Object Count -GT 1).Count -or @(Compare-Object -CaseSensitive @($ids|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selected and terminal identities differ'}
$delta=@(Compare-Object -CaseSensitive @($baseline.Id|Sort-Object) @($ids|Sort-Object))
if($delta.Count -ne 12 -or @($delta|Where-Object SideIndicator -CNE '=>').Count){throw 'Baseline test identities changed'}
$new=@($terminal|Where-Object {$delta.InputObject -ccontains $_.Id})
if($new.Count -ne 12 -or @($new|Where-Object Result -CNE 'PASS').Count){throw 'New conditional cases failed'}
$failed=@($terminal|Where-Object Result -CEQ 'FAIL'|ForEach-Object Name|Sort-Object)
if(@(Compare-Object -CaseSensitive $previous.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failure identity/diagnostics changed'}
$measurements=@(foreach($p in $pub.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($pub.Source):$($p.Path)") -ne $p.Blob){throw 'Tested source identity changed'}
    $before=@(git show "$($pub.Parent):$($p.Path)" 2>$null); if($LASTEXITCODE){$before=@()}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    [pscustomobject]@{Path=$p.Path;Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$before.Count;Growth=$lines-$before.Count;Class=if($p.Path -like '*/tests.rs' -or $p.Path -like '*/tests/*'){'test'}else{'production'};EmbeddedUnitTestLOC=0;Owner='arcweft-lang-sema';SHA256=$p.SHA256;Blob=$p.Blob}
})
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse 'HEAD^{tree}') -ne $pub.Tree -or @(git diff --name-only HEAD).Count){throw 'Final source identity differs'}
$metadata=Get-Content -Raw "$root/effect-replay.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$fanOut=@(($metadata.resolve.nodes|Where-Object id -CEQ $owner.id).deps).Count
$fanIn=@($metadata.resolve.nodes|Where-Object {$_.deps.pkg -ccontains $owner.id}).Count
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/effect-replay.owner-terminal.json"
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;OwnerInputParent=$pub.Parent;TestedDirtyBytesEqualCommittedBlobs=$true;Selected=1751;Passed=1745;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;IdsEqual=$true;Duplicates=0;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;Baseline=$previous.Source;FmtExit=0;Measurements=$measurements;PhysicalGrowth=($measurements|Measure-Object Growth -Sum).Sum;FanIn=$fanIn;FanOut=$fanOut;OwnershipDisposition='Prepared-effect candidate replay belongs to the existing graph transaction owner. Actual paired owner ports anchor new functions; functions and global choices are bijective, immutable row/predicate DAG sharing is not. Baseline declarations and frozen import relation owners retain their actual identities; declared domains, scoped obligations, dependency signatures, unknown roles and actual fixed inputs remain distinct. The iterative traversal meters allocations, parameters and canonical equality and leaves both affine deltas and the live base unchanged on every exit. The five private Rust paths and their exact physical growth are measured below; the replay module owns this one exhaustive grammar comparison, with tests in its own child. No public API, crate dependency, I/O owner, persisted contract, canonical producer or runtime boundary changes. Frontend ownership, prepared value/type ports and replacing eager body inference remain unfinished.'}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/effect-replay.owner-summary.json"
Get-Content "$root/effect-replay.owner-summary.json" -TotalCount 18
