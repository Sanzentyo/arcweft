$ErrorActionPreference='Stop'
$taskScratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$taskInput=Get-Content -Raw "$taskScratch/effect-replay.input.json"|ConvertFrom-Json
function Assert-Source {
    if((git rev-parse HEAD).Trim() -ne $taskInput.Source){throw 'Quality HEAD changed'}
    foreach($path in $taskInput.Paths){if((Get-FileHash -LiteralPath $path.Path -Algorithm SHA256).Hash -ne $path.SHA256){throw 'Quality source bytes changed'}}
}
Assert-Source
$taskStarted=Get-Date
Write-Output 'START owner-clippy'
& cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features > "$taskScratch/effect-replay.clippy.stdout" 2> "$taskScratch/effect-replay.clippy.log"
$taskCode=$LASTEXITCODE
Assert-Source
[ordered]@{Version=1;InputSource=$taskInput.Source;Input='effect-replay.input.json';Command='cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features';Started=$taskStarted.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$taskCode;SourcePinsVerified=$true}|ConvertTo-Json|Set-Content -Encoding utf8 "$taskScratch/effect-replay.clippy.json"
Write-Output "END owner-clippy exit=$taskCode"
if($taskCode){Get-Content "$taskScratch/effect-replay.clippy.log" -Tail 30;throw 'Owner Clippy failed'}
$taskStarted=Get-Date
Write-Output 'START structure'
& cargo +nightly -Zscript tools/structure-audit.rs --root . --fail-on-blocking > "$taskScratch/effect-replay.structure.log" 2> "$taskScratch/effect-replay.structure.stderr"
$taskCode=$LASTEXITCODE
Assert-Source
$taskLog=[IO.File]::ReadAllText("$taskScratch/effect-replay.structure.log")
function Number($name){$match=[regex]::Match($taskLog,'(?m)^'+[regex]::Escape($name)+': ([0-9]+)\r?$');if(!$match.Success){throw "Missing $name"};[int]$match.Groups[1].Value}
[ordered]@{Version=1;InputSource=$taskInput.Source;Input='effect-replay.input.json';Started=$taskStarted.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$taskCode;SourcePinsVerified=$true;Log='effect-replay.structure.log';Files=(Number 'files scanned');RustFiles=(Number 'Rust files');RustPhysicalLOC=(Number 'Rust physical LOC');Packages=(Number 'workspace packages');ReviewTriggers=(Number 'review triggers');Blocking=(Number 'blocking violations')}|ConvertTo-Json|Set-Content -Encoding utf8 "$taskScratch/effect-replay.structure.json"
Write-Output "END structure exit=$taskCode"
if($taskCode){throw 'Structure gate failed'}
Get-Content "$taskScratch/effect-replay.structure.json"
