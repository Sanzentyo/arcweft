$ErrorActionPreference='Stop'
$taskScratch=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$publication=Get-Content -Raw "$taskScratch/effect-replay.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$taskScratch/effect-replay.owner-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$taskScratch/effect-replay.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$taskScratch/effect-replay.structure.json"|ConvertFrom-Json
if((git rev-parse HEAD).Trim() -ne $publication.Source -or (git rev-parse origin/main).Trim() -ne $publication.Source -or !$publication.Pushed){throw 'Source is not published'}
$currentPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$current=[IO.File]::ReadAllText($currentPath)
$history=[IO.File]::ReadAllBytes($historyPath)
$historyHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history))
$matchRow=[regex]::Match($current,'(?m)^\| Generic Match[^\r\n]*')
if(!$matchRow.Success){throw 'Generic Match row missing'}
$evidenceBefore=@(git ls-files -s -- 'docs/implementation/acceptance-evidence/*.zip')
$before=[ordered]@{Version=1;InspectedHead=$publication.Source;TrackedDirty=@(git diff --name-only HEAD).Count;HistoryBytes=$history.Length;HistorySHA256=$historyHash;GenericMatch=$matchRow.Value;PriorArchiveIndex=$evidenceBefore}
$before|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$taskScratch/effect-replay.docs-before.json"
$sha=$publication.Source
$newRows=@(
    "| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。Free許可・reify保持とprepared候補のrelation比較を検証・公開。本体内推論は継続** | 最新Source ``$sha``。型／定数／effectのFree許可、実Source Γ・import lease・フレーム移送とNative／AWBCの既受入を維持する。prepared候補は実baseと対応するowner portから比較し、宣言条件・再帰body・未知効果の依存と役割・choiceの相関・whole-row obligation・import元と実固定入力を保持する。行／predicateの内部ID、生成順、DAG共有や既存ノードの再利用だけでは不一致にしない。これは同じ実baseと元のimport relation ownerでの比較であり、frontendへの接続や一般の量化relationの同値判定の完了ではない。一般量化消去・MGU／rank・Fn局所∀、prepared型を含む全portのΓ統合、frontend prepared value／effect・body一回準備・一括sealは継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[Γ保持](convergence-evidence-history.md#scoped-effect-primitive-gamma-and-header-admission)・[候補比較](convergence-evidence-history.md#prepared-effect-candidate-replay)。 |",
    "| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,745 PASS／6 FAIL。後続21 packageの以前の実測を再利用** | Source ``$sha`` のlocked・全feature Sema lib／tests 1,751件を$($owner.ExecutionSeconds)秒で実行。直前1,739 ID保持・新12件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。private prepared graphの候補比較と差分のbase inventoryのみを変更し、最終canonical型／callのproducer・public API・Cargo構成・runtimeは変更していない。fresh metadata／全target reverse treeの22 packageは不変。Source ``04d196e6ac47db99a8fbfe16bdaf77227630550a`` の後続21 package／107 target・2,507 PASS／2 FAIL／1 SKIPを再利用し、新Sourceでの再実行とはしない。Compiler既知2失敗のExpressionCycle slot 17／19も元Sourceの実測として保持する。[今回のowner・graph・全SHA原本](acceptance-evidence/task-effect-replay.raw.zip)・[全consumer実行の原本](acceptance-evidence/task-effect-primitive-gamma.raw.zip)。 |",
    "| workspace check／Clippy・fmt・構造gate | **最新Sourceのowner Clippy・fmt・構造gateは終了0。workspace品質・doctestは以前の実測を再利用** | Source ``$sha`` のlocked Sema全target／全feature Clippyとworkspace fmt、構造gateを今回実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking 0。5 Rust path・$($owner.PhysicalGrowth)物理LOC増。比較は既存prepared graphのtransaction ownerに集約し、canonical等価比較・パラメーター走査・割当も同じcontrolで課金する。operationalなstate IDは実baseの確認だけに使う。Cargo graph・fan-in／out 12／19は不変。workspace全target／全feature check・Clippy・Sema doctest 2件はSource ``04d196e6ac47db99a8fbfe16bdaf77227630550a`` の終了0を再利用。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。全体cargo cleanは2026-11-14に履行し、必要な検証でtargetを再生成した。今回のTier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・再利用](acceptance-evidence/task-effect-replay.raw.zip)・[以前のworkspace実測](acceptance-evidence/task-effect-primitive-gamma.raw.zip)。 |"
)
foreach($newRow in $newRows){
    $label=$newRow.Split('|')[1].Trim()
    $found=[regex]::Matches($current,'(?m)^\| '+[regex]::Escape($label)+' \|[^\r\n]*')
    if($found.Count -ne 1){throw "Current row is not unique: $label"}
    $current=$current.Replace($found[0].Value,$newRow)
}
$oldHeader=$current.Split("`n")[2]
$newHeader=$oldHeader.Replace('c70a9548710bc7523e90dba3ae908d128e937bd0',$sha)
if($newHeader -eq $oldHeader){throw 'Current header base differs'}
$current=$current.Replace($oldHeader,$newHeader)
[IO.File]::WriteAllText($currentPath,$current,[Text.UTF8Encoding]::new($false))
$append=@"

## Prepared effect candidate replay

2026-11-14。基点 ``$($publication.Parent)``、実装・公開Source ``$sha``、tree ``$($publication.Tree)``。既存mainの5 Rust pathを通常commit／非force pushし、検証したdirty bytesと公開blobを照合した。既存の未追跡 ``%SystemDrive%/`` を保持した。

- 同じ実baseに属する候補を、実際に対応するowner portから比較する。新functionとglobal choiceは共有関係を保つ一対一対応とし、基点の宣言identity、宣言D、再帰body、未知効果の依存signature・Bindable／Future、whole-rowのDとCを保持する。未対応のfunctionを観測されないという理由で消さず、ordinal順でownerを推測しない。
- 行／predicateのimmutable DAG共有は意味上のidentityとしない。基点の既存term、候補の新term、生成順や破棄された未観測termに依存せず、同じ文法で反復比較する。最初の全件実行後のレビューで既存termをID一致としていた比較を修正し、基点の2ノードと新ノードの再利用を追加検証した。importは同じ元のfrozen relation owner・選択functionと実際の固定入力／Future bindingを比較し、別のpartial-specialization wrapperでも同じ元relationと値なら受理する。任意の別ownerの量化relation同値判定を主張しない。
- canonical row／predicate／formulaの等価比較、パラメーター走査と一時割当も周囲のDecisionControlで課金する。8,000段の反復比較、比較に必要な予算の各境界での失敗、候補2個と元graphの不変・再適用、choice相関、未対応owner、役割変更、Dの保持、importの固定入力変更、全prepared row／predicate文法を検証する。開発時のprivate fieldアクセスとfixture API誤用のcompile拒否を原本に保持した。
- 最初の対象18件は18 PASS。最初の全件は1,750件／1,744 PASS／6 FAIL、228.134秒、品質・構造は終了0。その当時の全5 pathのbytesと実測を保持する。修正後の最終ownerは1,751件／1,745 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,739 ID保持・新12件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変で、再帰本体推論の完了とはしない。
- 最終Sema全target／全feature Clippy、workspace fmt、構造gateは今回実行して終了0。警告は保持する。5 path・$($owner.PhysicalGrowth)物理LOC増。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking 0。比較は既存prepared graph transactionの一つの文法とstate ownerに置き、public API、別の型／effect authority、I/O、Cargo依存を追加しない。module 701 LOCはこの網羅的比較を所有し、専用childが振る舞いテストを所有する。
- fresh full metadata／全target reverse treeの22 packageとfan-in 12／fan-out 19は不変。private準備graphの変更であり、最終canonical型／call producer・public API・Cargo feature・codec・runtimeは変更していない。Source ``04d196e6ac47db99a8fbfe16bdaf77227630550a`` の後続21 package／107 target・2,507 PASS／2 FAIL／1 SKIP、workspace全target／全feature check・Clippy、Sema doctest 2件を再利用し、新Sourceでの再実行とはしない。CARGO_INCREMENTAL=0、jobs／profile上書きなし。2026-11-14 03:13の全体cargo cleanは終了0、30,600 files／87.3 GiBを削除してtarget消失を確認した。その後の必要な検証でtargetを再生成した。
- Supersedes: prepared graph自体の候補relation比較の未完了列挙を、この範囲の検証済みへ訂正した。frontend owner、prepared型の実producer／consumer、body一回準備と一括sealへの接続は未完了。一般量化消去・MGU／rank・Fn局所∀・全portのΓ統合も今回の比較だけで完了としない。Generic Match、caller-bound recursion、共有prefixと、Free許可／reifyの受入を保持する。過去の全SHA・実測・失敗・原本を変更せず、現在の一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-effect-replay.raw.zip](acceptance-evidence/task-effect-replay.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,($append.Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false))
$actualHistory=[IO.File]::ReadAllBytes($historyPath)
$prefix=[byte[]]::new($history.Length)
[Buffer]::BlockCopy($actualHistory,0,$prefix,0,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -cne $historyHash){throw 'Historical prefix changed'}
if([regex]::Match([IO.File]::ReadAllText($currentPath),'(?m)^\| Generic Match[^\r\n]*').Value -cne $matchRow.Value){throw 'Generic Match acceptance changed'}
if(@(Compare-Object -CaseSensitive $evidenceBefore @(git ls-files -s -- 'docs/implementation/acceptance-evidence/*.zip')).Count){throw 'Prior archive index changed'}
$links=@([regex]::Matches(($newRows -join "`n")+"`n"+$append,'\]\(([^)]+)\)')|ForEach-Object {$_.Groups[1].Value}|Sort-Object -Unique)
foreach($link in $links){$target=Join-Path 'docs/implementation' $link.Split('#')[0];if(!(Test-Path -LiteralPath $target)){throw "Broken changed link: $link"}}
if(!([IO.File]::ReadAllText($historyPath).Contains('## Prepared effect candidate replay'))){throw 'New history anchor missing'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace differs'}
[ordered]@{Version=1;Source=$sha;UpdatedRows=3;HistoryPrefixUnchanged=$true;GenericMatchAcceptanceUnchanged=$true;PriorArchiveIndexUnchanged=$true;ChangedLinksVerified=$links;Paths=@($currentPath,$historyPath,'docs/implementation/acceptance-evidence/task-effect-replay.raw.zip')}|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$taskScratch/effect-replay.docs-validation.json"
Write-Output 'Updated three current rows; retained all prior history, archives and Generic Match acceptance'
