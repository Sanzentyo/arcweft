$ErrorActionPreference='Stop'
$taskScratch=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$publication=Get-Content -Raw "$taskScratch/effect-replay.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$taskScratch/effect-replay.metadata.json"|ConvertFrom-Json
$previous=Get-Content -Raw "$taskScratch/effect-delta.impact.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$parents=@{}
foreach($node in $metadata.resolve.nodes){foreach($edge in $node.deps){if(!$parents.ContainsKey($edge.pkg)){$parents[$edge.pkg]=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)};[void]$parents[$edge.pkg].Add($node.id)}}
$closure=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$pending=[Collections.Generic.Queue[string]]::new()
[void]$closure.Add($owner.id)
$pending.Enqueue($owner.id)
while($pending.Count){$id=$pending.Dequeue();if($parents.ContainsKey($id)){foreach($parent in $parents[$id]){if($closure.Add($parent)){$pending.Enqueue($parent)}}}}
$ids=@($closure|Sort-Object -CaseSensitive)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|ForEach-Object name|Sort-Object -CaseSensitive)
if($packages.Count -ne 22 -or @(Compare-Object -CaseSensitive $previous.PackageIds $ids).Count -or @(Compare-Object -CaseSensitive $previous.Packages $packages).Count){throw 'Reverse closure changed'}
$cargoChanges=@(git diff --name-only $publication.Parent $publication.Source -- Cargo.toml Cargo.lock ':(glob)**/Cargo.toml' .cargo)
if($cargoChanges.Count){throw 'Cargo inputs changed'}
$result=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Packages=$packages;PackageIds=$ids;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='effect-replay.reverse-tree.txt';CargoInputsUnchanged=$true;FanIn=$parents[$owner.id].Count;FanOut=@(($metadata.resolve.nodes|Where-Object id -CEQ $owner.id).deps).Count;ReverseConsumersRerun=$false;ReusedExecutionSource='04d196e6ac47db99a8fbfe16bdaf77227630550a';ReusedConsumerSummary='effect-primitive-gamma.consumer-summary.json';ReusedTargets=107;ReusedPassed=2507;ReusedFailed=2;ReusedSkipped=1;Reason='Private graph candidate-replay comparison and its affine-delta baseline inventory only. The new comparator has not been connected to frontend producers. Final canonical type/call producers, public APIs, Cargo configuration, codecs and runtime consumers are unchanged. The complete owner is freshly executed; previous consumer/workspace/doctest evidence is explicitly reused, not presented as a fresh run.'}
$result|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$taskScratch/effect-replay.impact.json"
$result|Select-Object Source,PackageCount,FanIn,FanOut,ReverseConsumersRerun|ConvertTo-Json
