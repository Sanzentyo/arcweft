$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$input=Get-Content -Raw "$root/effect-replay.input.json"|ConvertFrom-Json
if((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $input.Source){throw 'Unexpected commit input'}
foreach($path in $input.Paths){if((Get-FileHash -LiteralPath $path.Path -Algorithm SHA256).Hash -ne $path.SHA256){throw 'Tested source changed'}}
& git add -- @($input.Paths.Path)
if($LASTEXITCODE){throw 'Stage failed'}
if(@(Compare-Object -CaseSensitive @($input.Paths.Path|Sort-Object) @(git diff --cached --name-only|Sort-Object)).Count){throw 'Staged paths differ'}
git diff --cached --check
if($LASTEXITCODE){throw 'Staged whitespace check failed'}
git diff --cached --binary > "$root/effect-replay.staged.patch"
git diff --cached --stat
git commit -m 'Compare prepared effect candidates through their actual owner ports'
if($LASTEXITCODE){throw 'Commit failed'}
$source=(git rev-parse HEAD).Trim()
$tree=(git rev-parse 'HEAD^{tree}').Trim()
foreach($path in $input.Paths){if((git rev-parse "${source}:$($path.Path)").Trim() -ne $path.Blob -or (git hash-object -- $path.Path).Trim() -ne $path.Blob){throw 'Committed bytes differ from tested input'}}
[ordered]@{Version=1;Source=$source;Tree=$tree;Parent=$input.Source;ChangeBase=$input.Source;OwnerInput='effect-replay.input.json';OwnerTestedUncommittedBytesEqual=$true;Paths=$input.Paths;Pushed=$false}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/effect-replay.publication.json"
Write-Output "COMMITTED $source tree=$tree"


