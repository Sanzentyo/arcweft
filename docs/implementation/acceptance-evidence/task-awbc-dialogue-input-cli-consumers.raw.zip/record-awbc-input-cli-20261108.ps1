$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='awbc-dialogue-input-integrated-20261108'
$base=(git rev-parse HEAD).Trim()
if($base -ne '0ed7a4b093caaac1bf65c51812f9d215018dc25c'){throw 'Unexpected evidence base'}
$audit=Get-Content "$taskTemp/$stem.combined-audit.json" -Raw|ConvertFrom-Json -Depth 100
if($audit.executed -ne 8056 -or $audit.passed -ne 8052 -or $audit.failed -ne 4 -or $audit.skipped -ne 41 -or $audit.newFailures.Count -or $audit.caseOverlap -ne 0){throw 'Observed matrix differs; inspect before recording'}
$archive='docs/implementation/acceptance-evidence/task-awbc-dialogue-input-cli-consumers.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
$names=@("$stem.combined-audit.json",'audit-awbc-input-integrated-20261108.ps1','run-awbc-input-cli-main-20261108.ps1','audit-nextest-final-result.ps1','record-awbc-input-cli-20261108.ps1',"$stem.noncli-evidence.verified.json",'existing-consumer-fixture-checkpoint-20261108.verified.json','existing-presentation-fixture-checkpoint-20261108.verified.json','existing-presentation-fixture-checkpoint-20261108.inventory-after.json')
$files=@(Get-ChildItem $taskTemp -File|Where-Object {$_.Name.StartsWith("$stem.cli.") -or $_.Name -in $names}|Sort-Object Name)
$entries=@(foreach($file in $files){[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash $file.FullName).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256 -or $entry.Length -ne $row.bytes){throw 'Archive drift'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$base;production='c96539d2fa8107fac34b03bf7568cbb4ce7b16a5';featureSource='17e34d99e32c4618ac6ed866a7ee9ccdcff441c5';fixtureCheckpoints=@('3ec9934b355c88193229818b84a4ef20b16f07c9',$base)
 validation=[ordered]@{executed=$audit.executed;passed=$audit.passed;failed=$audit.failed;skipped=$audit.skipped;uniqueCases=$audit.uniqueCases;caseOverlap=$audit.caseOverlap;matchedPackages=$audit.matchedPackages;compileOnlyPackages=$audit.compileOnlyPackages;requiredRegressions=$audit.requiredRegressions;failures=$audit.failures;newFailures=$audit.newFailures;baselineFailuresNotPresent=$audit.baselineFailuresNotPresent}
 runs=$audit.runs
 executableIdentity=[ordered]@{actualTestExecutables=$audit.actualExecutablePins.Count;cliMain=$audit.cliMain;fullPinInventory='combined-audit.json and per-epoch binaries-before.json in raw';sourceDrift=0}
 sourceIdentity='The non-CLI epoch froze c96539d2fa8107fac34b03bf7568cbb4ce7b16a5 and the CLI epoch froze 3ec9934b355c88193229818b84a4ef20b16f07c9. Current files match both frozen inventories; the later Git checkpoints preserve every original source byte and clear all twelve tracked WIP paths. CLI freezes 3641 inputs, including 24 .awfagent files in addition to the original Rust/Cargo/config/toolchain and sample/fixture inputs. Four local untracked cache files remain unchanged.'
 acceptance='Two invocations / two feature points, 8056 unique executed cases, zero overlap: non-CLI 7345 pass / 18 skipped; default CLI 707 pass / four existing failures / 23 skipped. The four new dialogue-ingress regressions and earlier init/scoped regressions each occur once. Focused runs and preparation failures are not added to primary totals. Current workspace check/Clippy/structure/seven-path format results are preserved in awbcDialogueInputNonCliConsumers.'
 correction='No new failure ID appeared. The generic held=14 receipt label remains historical; the final tracked tree is clean, with four preserved local untracked cache files. Earlier 8052-case source results, the interrupted older CLI run, Windows1455 preparation refusal, and all old results/SHAs remain unchanged in their prior records.'
 remaining='The four observed CLI failures still concern Scroll input.text admission, an unavailable required VoiceHandle, and two receiverless old promotion inputs. Actual promotion implementation, Native public Save, platform/Tier2 and final Native-Web parity remain separately tracked. Generic Match and other accepted boundaries stay accepted.'
 nonCliRaw='task-awbc-dialogue-input-noncli-consumers.raw.zip'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledger='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledger));$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'awbcDialogueInputIntegratedConsumers'){throw 'Record exists'}
$fragment=([ordered]@{awbcDialogueInputIntegratedConsumers=$record}|ConvertTo-Json -Depth 100).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}');$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($p in $old.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($p.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Earlier evidence changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledger),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md';$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| 共有契約／推移的逆依存matrix |')){
 "| 共有契約／推移的逆依存matrix | **対話入力修復後：8056件中8052 PASS／4 FAIL／41 SKIP** | Rust Source c96539d2fa8107fac34b03bf7568cbb4ce7b16a5、fixture checkpoint 3ec9934b355c88193229818b84a4ef20b16f07c9／$base。Core逆依存53の非CLI全feature lib／testsは7345 PASS／18 SKIP、CLI既定lib／testsは707 PASS／4 FAIL／23 SKIP。2 run／2 feature point、8056件の重複0。実行50 package、compile-only3はarcweft／arcweft-bundle-assets／arcweft-render-web。3417 Rust／Cargo／config／toolchain入力とCLI3641入力、実test executable $($audit.actualExecutablePins.Count)本・CLI本体を元pathで前後照合した。4新regressionと先行init／scoped regressionを各1回含み、owner run・準備失敗を合算しない。失敗4件はCLI行で追跡する。旧8052件・中断・OS1455・全SHAは履歴へ保持。[全選択・各終端・実binary・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| CLIの規定対象／全 check 照合 |')){
 "| CLIの規定対象／全 check 照合 | **対話入力修復後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | 凍結Source 3ec9934b355c88193229818b84a4ef20b16f07c9 と内容不変の現在Source $base を照合。新規失敗0で、4 IDは先行Sourceと一致した。Scroll入力生成のshared callable意味解析、必要なvoice開始状態がない必須VoiceHandle、receiverなし旧promotion入力2件で拒否する。実CLI本体・test binaryを元pathで前後hash照合し、.awfagentを追加した3641入力drift0。個別の既受入は保持し、promotion本体は専用行で追跡する。[失敗ID・診断・実入力・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| 対話取消入力のstep保留／保存admission |')){
 $_.Replace('**Native／保存AWBCのowner・非CLI全逆依存・gateを検証・公開。CLIは照合中**','**Native／保存AWBCの追加owner条件を検証・公開。全逆依存・gateの実測を確定**')
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$addition=@"

## 2026-11-08 — 対話入力修復後の全Core逆依存・CLI終端

確認Source **$base**、production **c96539d2fa8107fac34b03bf7568cbb4ce7b16a5**、feature **17e34d99e32c4618ac6ed866a7ee9ccdcff441c5**。非CLI7345 PASS／18 SKIPと、凍結Source **3ec9934b355c88193229818b84a4ef20b16f07c9** のCLI711件中707 PASS／4 FAIL／23 SKIPを照合し、**8056件中8052 PASS／4 FAIL／41 SKIP**、2 run／2 feature point・重複0。Core逆依存53中50 packageを実行し、3はcompile-only。9個の新旧required regressionを各1回含み、focused ownerを合算しない。実test executable $($audit.actualExecutablePins.Count)本とCLI本体を元pathで前後照合した。3417 Rust等入力とCLI3641入力（.awfagent24件を追加）のdrift0。

最終4失敗のIDは先行Sourceと一致し、新規失敗0。Scroll入力生成、必須VoiceHandleの開始状態、旧receiverless promotion入力2件の境界を引き続き各ownerで追跡する。元12ファイルのcheckpointは内容を変えず、tracked WIPは0、4 local cacheは保持する。generic held=14 labelは旧templateとして保持し、現状へ転記しない。先行8052件、中断した旧CLI run、OS1455準備失敗、全SHA／実測は保持する。全体goalの未達でGeneric Matchなど完了cutを戻さない。[全選択・終端・diagnostics・公開receipt](acceptance-evidence/task-flow-registry-execution.json)。raw $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::AppendAllText($historyPath,"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$base;earlierRecordsPreserved=$old.PSObject.Properties.Name.Count;executed=$audit.executed;passed=$audit.passed;failed=$audit.failed;newFailures=$audit.newFailures;rawEntries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json -Depth 10
