$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$exe=(Resolve-Path -LiteralPath 'D:/git/arcweft/target/debug/arcw.exe').Path
$exeHash=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
$results=@(foreach($kind in @('direct','alias')){
    $source="$e/optional-external-$kind-probe.arcw"
    $output="$e/optional-bindings-source-probe-$kind.plan.json"
    $log="$e/optional-bindings-source-probe-$kind.log"
    $arguments=@('compile',$source,'--emit','plan','--output',$output,'--json')
    $started=[DateTime]::UtcNow.ToString('o')
    & $exe @arguments *> $log
    $code=$LASTEXITCODE
    $report=Get-Content $log -Raw|ConvertFrom-Json -AsHashtable -Depth 100
    $row=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();source=$source;sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();executable=$exe;executableSha256=$exeHash;command=$arguments;exitCode=$code;report=$report;output=$output;outputExists=(Test-Path -LiteralPath $output);startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Compile-only source probe; no runtime or factory acceptance is inferred.'}
    $row|ConvertTo-Json -Depth 100|Set-Content "$e/optional-bindings-source-probe-$kind.json" -Encoding utf8
    $row
})
if((Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant() -ne $exeHash){throw 'Probe executable drift'}
if($results[0].exitCode -ne 0 -or -not $results[0].outputExists -or $results[1].exitCode -ne 1 -or $results[1].report.stage -ne 'runtime-plan-lower'){throw 'Investigate changed source probe outcome'}
[ordered]@{version=1;source=(git rev-parse HEAD).Trim();direct=$results[0];alias=$results[1];executableDrift=0;conclusion='Core optional binding is not yet projected from this external function-value call. Direct source compile succeeds; omitted alias source compile is still rejected.'}|ConvertTo-Json -Depth 100|Set-Content "$e/optional-bindings-source-probe-comparison.json" -Encoding utf8
[ordered]@{directExit=$results[0].exitCode;aliasExit=$results[1].exitCode;aliasStage=$results[1].report.stage;executableDrift=0}|ConvertTo-Json -Compress
