$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& cargo metadata --format-version 1 --all-features --locked 1> "$e/optional-bindings.metadata.json" 2> "$e/optional-bindings.metadata.log"
if($LASTEXITCODE){throw 'metadata failed'}
& cargo tree --invert arcweft-core --workspace --all-features --target all --edges normal,build,dev --prefix none --format '{p}' --locked 1> "$e/optional-bindings.tree.txt" 2> "$e/optional-bindings.tree.log"
if($LASTEXITCODE){throw 'tree failed'}
$m=Get-Content "$e/optional-bindings.metadata.json" -Raw | ConvertFrom-Json -Depth 100
$selected=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$workspace=@($m.packages | Where-Object id -in $m.workspace_members)
foreach($p in $workspace){if($p.name -eq 'arcweft-core'){[void]$selected.Add($p.id)}}
do {
    $changed=$false
    foreach($n in $m.resolve.nodes){
        if($selected.Contains($n.id)){continue}
        foreach($d in $n.deps){if($selected.Contains($d.pkg)){[void]$selected.Add($n.id);$changed=$true;break}}
    }
} while($changed)
$packages=@($workspace | Where-Object {$selected.Contains($_.id)} | Sort-Object name)
$tree=@(Get-Content "$e/optional-bindings.tree.txt" | ForEach-Object {if($_ -match '^(\S+) v'){ $Matches[1] }} | Where-Object {$_ -in $workspace.name} | Sort-Object -Unique)
$diff=@(Compare-Object @($packages.name) $tree)
if($diff.Count){throw 'metadata/tree reverse closure differs'}
$graph=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();roots=@('arcweft-core');workspacePackages=$workspace.Count;selection=@($packages.name);selectedPackages=$packages.Count;target='all';features='all';dependencyKinds=@('normal','build','dev');metadataTreeDrift=0}
$graph | ConvertTo-Json -Depth 8 | Set-Content "$e/optional-bindings.graph.json" -Encoding utf8
[pscustomobject]$graph | Select-Object base,roots,workspacePackages,selectedPackages,metadataTreeDrift | ConvertTo-Json -Compress
