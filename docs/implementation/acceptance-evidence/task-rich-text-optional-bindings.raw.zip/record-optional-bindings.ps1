$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Receipt([string]$name){Get-Content "$e/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$publication=Read-Receipt 'optional-bindings-source.verified'
if((git rev-parse HEAD).Trim() -ne $publication.commit){throw 'Unexpected published source'}
$terminal=Read-Receipt 'optional-bindings-reverse1-20261104.runtime.terminal-audit'
$owner=Read-Receipt 'optional-bindings-owner6-20261104.runtime.terminal-audit'
if($owner.executed -ne 67 -or $owner.passed -ne 67 -or $owner.sourceDrift -ne 0){throw 'Owner evidence differs'}
$comparison=Read-Receipt 'optional-bindings-result-comparison'
$coverage=Read-Receipt 'optional-bindings-final-coverage'
if($terminal.executed -ne 7800 -or $terminal.failed -ne 14 -or $terminal.sourceDrift -ne 0 -or $comparison.normal.failed -ne 0 -or $coverage.failedIdsAdded -ne 0 -or $coverage.failedIdsRemoved -ne 0){throw 'Investigate changed full-run results before recording acceptance'}
$freeze=Read-Receipt 'optional-bindings-reverse1-20261104.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift before evidence publication'}}
$quality=@(foreach($gate in @('check','clippy','structure')){
    $receipt="optional-bindings-quality3-20261104-$gate"
    $r=Read-Receipt $receipt
    if($r.exitCode -ne 0 -or $r.sourceDrift -ne 0){throw "Required gate failed: $receipt"}
    [ordered]@{gate=$gate;receipt="$receipt.json";exitCode=0;sourceDrift=0}
})
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$beforeRecord=Get-Content $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($beforeRecord.Contains('optionalBindings')){throw 'Preserve existing optional binding evidence'}
$beforeRows=@([IO.File]::ReadAllLines((Join-Path $PWD $statusPath))|Where-Object {
    $_.StartsWith('| RichTextの部分layout指定／source factory |') -or $_.StartsWith('| Generic Match ') -or $_.StartsWith('| 共有契約／推移的逆依存matrix |') -or $_.StartsWith('| CLI全target照合 |') -or $_.StartsWith('| workspace check／Clippy・fmt・構造gate |')
})
if($beforeRows.Count -ne 5){throw 'Canonical status rows are missing or duplicated'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
[ordered]@{version=1;source=$publication.commit;supersededCurrentRows=$beforeRows;historyPrefix=$historyPrefix;reason='A new Core binding boundary is verified. Keep the concrete unimplemented Source omission projection separate and preserve all prior accepted features and actual evidence.'}|ConvertTo-Json -Depth 10|Set-Content "$e/optional-bindings-status-before.json" -Encoding utf8
foreach($row in (Read-Receipt 'task-documentation-final-untracked-before').files){if(-not(Test-Path -LiteralPath $row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object {$_.Name -like 'optional-bindings-*' -or $_.Name -eq 'audit-optional-bindings-tests.ps1' -or $_.Name -eq 'record-optional-bindings.ps1'})
foreach($name in @('optional-bindings-quality1-20261104.structure-report','optional-bindings-quality2-20261104.structure-report','optional-bindings-quality3-20261104.structure-report')){$files+=@(Get-ChildItem -LiteralPath "$e/$name" -File -Recurse)}
foreach($name in @('run-presentation-projection-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1','probe-optional-bindings-source.ps1','optional-external-direct-probe.arcw','optional-external-alias-probe.arcw')){$files+=Get-Item -LiteralPath "$e/$name"}
$root=[IO.Path]::GetFullPath($e)
$index=@(foreach($file in @($files|Sort-Object FullName -Unique)){[ordered]@{entry=$file.FullName.Substring($root.Length+1).Replace([IO.Path]::DirectorySeparatorChar,[char]'/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$index|ConvertTo-Json -Depth 8|Set-Content "$e/optional-bindings-archive-inputs.json" -Encoding utf8
$files+=Get-Item "$e/optional-bindings-archive-inputs.json"
. "$e/write-verified-evidence-archive.ps1"
$archive='docs/implementation/acceptance-evidence/task-rich-text-optional-bindings.raw.zip'
$raw=Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record=$beforeRecord
$record.optionalBindings=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$publication.commit
    source=$publication
    state='Core optional ordinary binding boundary verified and published; Source external omission application and RichText factories remain unfinished.'
    implementation=@(
        'One callable-state parameter kind admits ABI T with canonical Option<T> binding, independently of attached Content and positional-prefix arity.'
        'Checked fixed group materialization carries a complete binding. Scalar arrow inputs and retained positional prefixes are wrapped once as Some; explicit None remains omission.'
        'Plan admission, AWBC verification, copy proofs, semantic metadata and strict version-one Source/AWBC codecs share this state authority. No compatibility reader or second function type was introduced.'
    )
    validation=[ordered]@{
        owner=$owner;fullReverse=$terminal
        graph=[ordered]@{receipt='optional-bindings.graph.json';workspacePackages=98;selectedPackages=53;metadataTreeDrift=0}
        caseResults='optional-bindings-reverse1-20261104.runtime.cases.json'
        ownerCoverage=[ordered]@{receipt='optional-bindings-final-coverage.json';ownerCases=67;newCases=5}
        normal=$comparison.normal;cli=$comparison.cli
        acceptedGeneric=[ordered]@{cases=151;freshPassed=151;receipt='optional-bindings-result-comparison.json'}
        retainedBoundaries=[ordered]@{externalDescriptor=25;requiredArgumentAliasesAndCapture=4;constructorFresh=19;constructorUnselected=5;receipt='optional-bindings-boundary-coverage.json'}
        immediatePriorFailureComparison=[ordered]@{priorSource='4a3400586e018b734e9d724c31106027256ce068';failedIdsAdded=0;failedIdsRemoved=0;causeClaim='Matching failed IDs alone do not establish identical causes.'}
        quality=$quality;formatReview='optional-bindings-final-quality-review.json'
    }
    attempts=@(
        [ordered]@{run='optional-bindings-owner1-20261104';executed=61;passed=59;failed=2;reason='New fixture lacked a formal ownership row; extending a shared fixture displaced a specialization fixture coordinate.'}
        [ordered]@{run='optional-bindings-owner2-20261104';executed=62;passed=61;failed=1;reason='The new VM fixture budget covered two instructions but not the call terminator; the assertion expected callee ingress too early.'}
        [ordered]@{run='optional-bindings-owner3-20261104';executed=63;passed=63;failed=0}
        [ordered]@{run='optional-bindings-owner4-20261104';executed=3;passed=3;failed=0;reason='Recheck after checked fixture index conversions.'}
        [ordered]@{run='optional-bindings-owner5-20261104';executed=0;stage='catalog-count';reason='A substring filter selected 67 rather than the predicted 65 cases; no runtime executed. The unchanged observed selection was rerun.'}
        [ordered]@{run='optional-bindings-owner6-20261104';executed=67;passed=67;failed=0;reason='Final source bytes, including the shared fixture cleanup, with complete source/case/executable checks.'}
    )
    environment=[ordered]@{
        packageClean='optional-bindings-core-clean-20261104.json';wholeClean='optional-bindings-whole-clean-20261104.json'
        reason='After final owner/quality validation, limited free disk required Cargo-owned cache cleanup before the complete reverse build. All 4097 source inputs and Git state stayed unchanged.'
        changedBuildOrRuntimeLimits=$false
    }
    ownership=[ordered]@{authority='RuntimeCallableStateDefinition parameter grammar';physicalInput='One complete fixed binding or existing rest pack';optionalBinding='Canonical Option owned by the original program type table';affineBehavior='Existing move and copy admission retained; values are wrapped without cloning their payload';fixtureReview='The existing cohesive partial-state fixture is generalized rather than duplicated; its size lint remains.'}
    scope=[ordered]@{
        accepted=@('Core ordinary optional ABI/binding grammar','Prefix retention and native callable snapshot restoration','Strict Source graph replay and semantic digest','Decoded AWBC group/arrow execution, frame save/restore and malformed binding rejection')
        remaining=@('Project checked external optional/defaulted source calls onto the admitted binding law','Preserve external source operand composition order through function values','Register text_style/ruby_style/rich_text_style and connect original call context to construction','Carry static inline-style provenance and length units through the consuming owners')
        genericMatch='Accepted/public; same 151 cases pass freshly. No completed feature is reopened because the whole goal remains unfinished.'
        sourceOmissionProbe=[ordered]@{receipt='optional-bindings-source-probe-comparison.json';result=(Read-Receipt 'optional-bindings-source-probe-comparison');claim='The fresh compile-only direct/alias comparison keeps the missing Source projection concrete. It does not reopen required-argument aliases or Generic Match.'}
    }
    correctionReason='Add this verified lower-layer boundary without presenting it as completion of Source aliases or factories; replace the prior current summaries while retaining all old results and full SHAs.'
    supersededCurrentRows=$beforeRows;historyPrefix=$historyPrefix
    raw=[ordered]@{path=$archive;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0;indexEntry='optional-bindings-archive-inputs.json'}
}
$record|ConvertTo-Json -Depth 100|Set-Content $recordPath -Encoding utf8
$sha=$publication.commit
$rows=[IO.File]::ReadAllLines((Join-Path $PWD $statusPath))
$rows=@(foreach($line in $rows){
    if($line.StartsWith('| RichTextの部分layout指定／source factory |')){"| RichTextの部分layout指定／source factory | **既受入を維持・省略束縛のCore境界も検証／公開済み。Source接続は継続中** | Source ${sha}で、通常引数のABI T／束縛Option<T>を同じcallable stateへ接続した。最終owner 67／67 PASS、Source往復、部分適用・保存復元、decoded AWBCのSome／Noneと生のarrow入力、不正束縛の拒否を確認。全53逆依存でも同じ67件と従来の外部座標25件がPASS。部分layout・共通property・生成 APIの受入を維持する。Sourceの省略引数alias投影、factory登録・元call context接続、合成順・static inline_stylesの出典・長さ単位の消費は継続範囲。cues.stopの具体的な直接成功／alias拒否は原本へ保持し、このCore追加だけで修復済みとしない。[各cutの全SHA・検証・未達の具体例](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| Generic Match ')){$line.Replace('Source 4a3400586e018b734e9d724c31106027256ce068の全53逆依存',"Source ${sha}の全53逆依存")}
    elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){"| 共有契約／推移的逆依存matrix | **全53 packageの終端を確認。通常系7,102／7,102 PASS・CLI失敗は別行** | Source ${sha}、4097入力。normal／build／dev・全targetの実Cargo graphとtree照合は差分0、53 package中50で実テストあり。all-target／all-feature／lockedの同じ一回のrunは7,800件中7,786 PASS／14 FAIL、40 skipped。テストのない3 packageはbuildのみとして区別する。Source／case／EXE drift 0。owner 67、外部座標25、Generic Matchの同じ151 IDを含む。[全件・graph・終端とraw](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| CLI全target照合 |')){"| CLI全target照合 | **統合受入は未完了。最新の全698件は684 PASS／14 FAIL** | Source ${sha}、4097入力、全53逆依存の同じ実runに含む全target／all-feature／locked。直前の14 failed IDと一致し、追加・解消IDは0。ID一致から原因同一とは推定しない。[全件・全失敗・以前の実測](acceptance-evidence/task-rich-text-property-identity.json)。全体の未達を理由にGeneric Matchや既受入のtyped ownerを未完了へ戻さない。 |"}
    elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){"| workspace check／Clippy・fmt・構造gate | **最新Sourceの全98 gateは終了0。既存警告は残存** | Source ${sha}の最終4097入力で、全98 packageのcheck／Clippy（all-target／all-feature／locked）と構造gateが終了0。Rust16件のfmt・staged whitespaceも終了0。検証後のCore package cleanは5,980 files／17.5 GiB、全体cleanは83,084 files／115.0 GiB削除・source／Git状態drift 0。その後に全53逆依存を再構築して終端まで確認した。以前のclean・ICE・paging不足の結果も履歴へ保持する。[全receipt・owner review・raw](acceptance-evidence/task-rich-text-property-identity.json)。doctest／wasm専用検証は未再実行。 |"}
    else{$line}
})
[IO.File]::WriteAllLines((Join-Path $PWD $statusPath),$rows,[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-04 — Optional ordinary callable binding

- Source $sha (parent $($publication.parent)) publishes canonical optional ordinary bindings in the existing callable-state grammar. Positional T inputs and retained prefixes become Some; checked group materialization can carry None. Source/AWBC codecs and metadata remain version 1.
- Final owner execution is 67/67 PASS on 4097 frozen inputs; all 98-package check/Clippy/all-target/all-feature gates and structure exit 0. The five new cases cover Core prepared groups/prefix/save, strict Source replay, decoded AWBC group and arrow ingress/save/restore, and malformed binding rejection. Preserve the earlier fixture failures and the catalog-count correction as separate attempts.
- The complete 53-package run executes 7800 cases: 7786 PASS / 14 FAIL, 40 skipped. Non-CLI is 7102/7102 PASS; CLI is 684/698 PASS. The immediate prior 14 failed IDs are unchanged; matching IDs do not prove matching causes. Same accepted Generic 151, descriptor 25 and required-argument alias/capture/restore 4 cases pass freshly.
- The original 12 tracked WIP paths and six untracked files remain held. After validation, package clean removes 5980 files/17.5 GiB; the subsequent whole clean removes 83084 files/115.0 GiB. Every 4097-source and Git-state comparison is unchanged, and the full reverse suite is rebuilt afterward without changing jobs, features, profiles, budgets or OS configuration.
- This accepts the Core binding boundary, not Source external optional/defaulted application, factory registration, caller composition order, inline-style provenance or length-unit consumption. Preserve earlier Generic Match, sparse layout, property identity and construction acceptance. No whole-goal inference reopens them.
- All prior JSON fields and this history prefix are preserved. Full SHAs, failed attempts, actual per-case results, exact graph and source/executable receipts are retained in [the existing property evidence](acceptance-evidence/task-rich-text-property-identity.json); the sole current list remains [current-status.md](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append,[Text.UTF8Encoding]::new($false))
$after=Get-Content $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in @($beforeRecord.Keys|Where-Object {$_ -ne 'optionalBindings'})){if(($beforeRecord[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw "Prior evidence changed: $key"}}
$afterHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$prefixBytes=[byte[]]::new($history.Length)
[Array]::Copy($afterHistory,$prefixBytes,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefixBytes)).ToLowerInvariant() -ne $historyPrefix.sha256){throw 'History prefix changed'}
[ordered]@{version=1;source=$sha;raw=$record.optionalBindings.raw;priorFieldsDrift=0;historyPrefixDrift=0;currentRows=5;heldTracked=12}|ConvertTo-Json -Depth 10|Set-Content "$e/optional-bindings-documentation-qa.json" -Encoding utf8
[ordered]@{source=$sha;rawEntries=$raw.entries.Count;rawBytes=$raw.bytes;rawSha256=$raw.sha256;priorFieldsDrift=0;historyPrefixDrift=0}|ConvertTo-Json -Compress
