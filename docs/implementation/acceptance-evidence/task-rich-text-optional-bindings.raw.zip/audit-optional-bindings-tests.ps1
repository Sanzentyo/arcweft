$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='optional-bindings-reverse1-20261104'
$terminal=Get-Content -Raw "$taskTemp/$stem.runtime.terminal-audit.json"|ConvertFrom-Json -Depth 100
$catalog=Get-Content -Raw "$taskTemp/$stem.catalog.inventory.json"|ConvertFrom-Json -Depth 100
$lines=[IO.File]::ReadAllLines("$taskTemp/$stem.runtime.log")
$summaryIndex=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summaryIndex -lt 0){throw 'No terminal summary'}
$selected=@($catalog.rows|Where-Object status -eq 'matches')
$index=@{}
foreach($row in $selected){$key=$row.binary+[char]9+$row.test;if($index.ContainsKey($key)){throw 'Duplicate selected test'};$index[$key]=$row}
$sourceLines=if($terminal.caseRowSource -eq 'final-status-after-summary'){$lines[($summaryIndex+1)..($lines.Length-1)]}else{$lines[0..($summaryIndex-1)]}
$rows=@(foreach($line in $sourceLines){
 if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
  $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+[char]9+$test
  if(-not $index.ContainsKey($key)){throw 'Unexpected result'}
  [pscustomobject]@{package=$index[$key].package;binary=$binary;test=$test;status=$status}
 }
})
if($rows.Count -ne $terminal.executed -or $rows.Count -ne $selected.Count){throw 'Incomplete result inventory'}
$actual=@{};foreach($row in $rows){$key=$row.binary+[char]9+$row.test;if($actual.ContainsKey($key)){throw 'Duplicate actual test'};$actual[$key]=$row}
$rows|ConvertTo-Json -Depth 10|Set-Content "$taskTemp/$stem.runtime.cases.json"
$prior=Get-Content -Raw "$taskTemp/layout-presence-result-comparison.json"|ConvertFrom-Json -Depth 100
$generic=@(foreach($row in $prior.generic){
 $key=$row.binary+[char]9+$row.test
 if(-not $actual.ContainsKey($key)){throw "Accepted Generic case missing: $key"}
 $observed=$actual[$key]
 if($observed.status -notin @('PASS','SLOW')){throw "Accepted Generic case failed: $key"}
 [ordered]@{group=$row.group;binary=$row.binary;test=$row.test;status=$observed.status}
})
if($generic.Count -ne 151){throw 'Accepted Generic coverage changed'}
$critical=@($rows|Where-Object {$_.test -match '^rich_text::content_catalog::reusable_style::tests::|^character_dialogue::schema::role_payload::tests::|^character_dialogue_style::tests::'})
if($critical.Count -ne 9 -or @($critical|Where-Object status -notin @('PASS','SLOW')).Count){throw 'Property identity owner regression not accepted'}
$dynamic=@($rows|Where-Object {$_.package -eq 'arcweft-runtime-driver' -and $_.test -match 'dynamic_character_dialogue_context_tests::'})
if($dynamic.Count -eq 0 -or @($dynamic|Where-Object status -notin @('PASS','SLOW')).Count){throw 'Dynamic display consumer absent or failing'}
$cli=@($rows|Where-Object package -eq 'arcweft-cli')
$normal=@($rows|Where-Object package -ne 'arcweft-cli')
$baseline=Get-Content -Raw "$taskTemp/semantic-properties-reverse1-20261104.runtime.terminal-audit.json"|ConvertFrom-Json -Depth 100
$baselineIds=@($baseline.failureSet|ForEach-Object {$_.binary+[char]9+$_.test}|Sort-Object)
$failedIds=@($rows|Where-Object status -notin @('PASS','SLOW')|ForEach-Object {$_.binary+[char]9+$_.test}|Sort-Object)
$added=@($failedIds|Where-Object {$_ -notin $baselineIds})
$removed=@($baselineIds|Where-Object {$_ -notin $failedIds})
[ordered]@{version=1;base=$terminal.base;total=$rows.Count;generic=$generic;critical=$critical;dynamicDisplay=$dynamic;normal=[ordered]@{executed=$normal.Count;passed=@($normal|Where-Object status -in @('PASS','SLOW')).Count;failed=@($normal|Where-Object status -notin @('PASS','SLOW')).Count};cli=[ordered]@{executed=$cli.Count;passed=@($cli|Where-Object status -in @('PASS','SLOW')).Count;failed=@($cli|Where-Object status -notin @('PASS','SLOW')).Count};baselineFailedIds=$baselineIds;currentFailedIds=$failedIds;addedFailedIds=$added;removedFailedIds=$removed;causeClaim='ID comparison only; matching IDs do not establish identical causes.'}|ConvertTo-Json -Depth 100|Set-Content "$taskTemp/optional-bindings-result-comparison.json"
if(@($normal|Where-Object status -notin @('PASS','SLOW')).Count){throw 'Non-CLI failures require investigation'}
if($added.Count -or $removed.Count){throw 'Changed failure set requires investigation'}
if($cli.Count -ne 698){throw 'CLI inventory changed'}
[ordered]@{executed=$rows.Count;critical=$critical.Count;dynamic=$dynamic.Count;generic=$generic.Count;normal=$normal.Count;cli=$cli.Count;failed=$failedIds.Count;added=$added.Count;removed=$removed.Count}|ConvertTo-Json -Compress
$descriptorCases=@{}
$owner=Get-Content -Raw "$taskTemp/external-operands-owner2-20261104.catalog.inventory.json"|ConvertFrom-Json -Depth 100
foreach($case in @($owner.rows|Where-Object status -eq 'matches')){
 $key=$case.binary+[char]9+$case.test
 if(-not $actual.ContainsKey($key) -or $actual[$key].status -notin @('PASS','SLOW')){throw "Descriptor owner missing/failing: $key"}
 $descriptorCases[$key]=$actual[$key]
}
$newCases=@($rows|Where-Object {$_.test -match '::external_source_preflight_rejects_overlapping_borrowed_operand_ranges$|::external_source_admission_rejects_layouts_that_do_not_match_original_arguments$'})
if($newCases.Count -ne 2 -or @($newCases|Where-Object status -notin @('PASS','SLOW')).Count){throw 'Final admission regression is missing/failing'}
$aliases=@($rows|Where-Object {$_.package -eq 'arcweft-compiler' -and $_.test -match '(^|::)static_selectors::'})
if($aliases.Count -ne 4 -or @($aliases|Where-Object status -notin @('PASS','SLOW')).Count){throw 'Direct/alias/capture/restoration fixture missing/failing'}
foreach($row in @($newCases+$aliases)){$descriptorCases[$row.binary+[char]9+$row.test]=$row}
if($descriptorCases.Count -ne 25){throw 'Unexpected descriptor boundary membership'}
$constructor=Get-Content -Raw "$taskTemp/plain-role-construction-owner5-20261104.catalog.inventory.json"|ConvertFrom-Json -Depth 100
$graph=Get-Content -Raw "$taskTemp/optional-bindings.graph.json"|ConvertFrom-Json
$constructorFresh=@();$constructorUnselected=@()
foreach($case in @($constructor.rows|Where-Object status -eq 'matches')){
 $key=$case.binary+[char]9+$case.test
 if($case.package -in $graph.selection){
  if(-not $actual.ContainsKey($key) -or $actual[$key].status -notin @('PASS','SLOW')){throw "Constructor regression missing/failing: $key"}
  $constructorFresh+=$actual[$key]
 }else{$constructorUnselected+=$case}
}
if($constructorFresh.Count -ne 19 -or $constructorUnselected.Count -ne 5){throw 'Constructor impact membership differs'}
[ordered]@{version=1;base=$terminal.base;descriptorCases=@($descriptorCases.Values|Sort-Object binary,test);directAliasesAndCapture=$aliases;constructorFresh=$constructorFresh;constructorUnselected=$constructorUnselected;reuseClaim='The 4 Presentation and 1 rich-text-schema cases are prior-input evidence, not fresh execution in the Core reverse selection. Their accepted scope remains retained.'}|ConvertTo-Json -Depth 100|Set-Content "$taskTemp/optional-bindings-boundary-coverage.json"
[ordered]@{descriptor=$descriptorCases.Count;aliases=$aliases.Count;constructorFresh=$constructorFresh.Count;constructorUnselected=$constructorUnselected.Count;generic=$generic.Count}|ConvertTo-Json -Compress
$owner=Get-Content -Raw "$taskTemp/optional-bindings-owner6-20261104.catalog.inventory.json"|ConvertFrom-Json -Depth 100
$optionalOwner=@(foreach($case in @($owner.rows|Where-Object status -eq 'matches')){
 $key=$case.binary+[char]9+$case.test
 if(-not $actual.ContainsKey($key) -or $actual[$key].status -notin @('PASS','SLOW')){throw "Optional binding owner missing/failing: $key"}
 $actual[$key]
})
if($optionalOwner.Count -ne 67){throw 'Optional binding owner inventory differs'}
$latest=Get-Content -Raw "$taskTemp/external-operands-reverse2-20261104.runtime.terminal-audit.json"|ConvertFrom-Json -Depth 100
$latestIds=@($latest.failureSet|ForEach-Object {$_.binary+[char]9+$_.test}|Sort-Object)
if(@(Compare-Object $latestIds $failedIds).Count){throw 'Failed IDs differ from immediate prior full run'}
$new=@($rows|Where-Object {$_.test -match '::optional_callable_binding::|::optional_binding_preserves_presence_in_arrow_prefix_and_saved_callable$|::callable_sources_preserve_optional_ordinary_binding_and_its_executable_owner$'})
if($new.Count -ne 5){throw 'New optional boundary test membership differs'}
[ordered]@{version=1;base=$terminal.base;owner=$optionalOwner;newCases=$new;immediatePriorRun='external-operands-reverse2-20261104';failedIdsAdded=0;failedIdsRemoved=0;causeClaim='Matching failed IDs alone do not establish identical causes.'}|ConvertTo-Json -Depth 100|Set-Content "$taskTemp/optional-bindings-final-coverage.json"
[ordered]@{owner=$optionalOwner.Count;newCases=$new.Count;total=$rows.Count;normal=$normal.Count;cli=$cli.Count;failed=$failedIds.Count;generic=$generic.Count}|ConvertTo-Json -Compress
