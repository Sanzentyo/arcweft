$ErrorActionPreference = 'Stop'
$e = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
if ((& git rev-parse HEAD).Trim() -ne '6061bedb3c68279d287de35904a631bb583a0329') { throw 'Unexpected Source HEAD' }
if (@(git diff HEAD --name-only).Count -or @(git diff --cached --name-only).Count) { throw 'Source/index is not frozen' }
$inputRecord = Get-Content -Raw -LiteralPath (Join-Path $e 'flow-transfer-convergence-reverse-r3.inputs.json') | ConvertFrom-Json
$targets = @('release_trust_e2e','input','windowed_ingress_runtime','release_trust_json','web_text_input_glue','descriptor_invariants','parity','repl_command','environment_callable_tensor')
$results = @()
foreach ($target in $targets) {
    $cargoArgs = @($inputRecord.cargoArgs) + @('--test', $target)
    $prefix = 'flow-transfer-convergence-warm-' + $target
    $log = Join-Path $e ($prefix + '.log')
    if (Test-Path -LiteralPath $log) { throw ('Existing log: ' + $log) }
    [ordered]@{version=1;source=$inputRecord.source;purpose='Cache preparation only; final full reverse selection still required';cargoArgs=$cargoArgs;packageCount=54;target=$target;startedAt=[DateTimeOffset]::Now.ToString('o')} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.inputs.json')) -Encoding utf8
    $watch = [Diagnostics.Stopwatch]::StartNew()
    & cargo @cargoArgs *> $log
    $code = $LASTEXITCODE
    $watch.Stop()
    $results += [ordered]@{target=$target;exitCode=$code;seconds=$watch.Elapsed.TotalSeconds;log=($prefix+'.log')}
    $results | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $e 'flow-transfer-convergence-warm-targets.results.json') -Encoding utf8
    Write-Output ($target + ': exit=' + $code + ', seconds=' + [Math]::Round($watch.Elapsed.TotalSeconds, 2))
}
if (@($results | Where-Object {$_.exitCode -ne 0}).Count) { exit 1 }
exit 0
