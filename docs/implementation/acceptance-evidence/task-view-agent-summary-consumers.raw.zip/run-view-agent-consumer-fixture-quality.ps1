$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='view-agent-consumer-fixtures-quality1-20261106'
& "$t/assert-no-arcweft-build.ps1"
$freeze=Get-Content -LiteralPath "$t/view-agent-consumer-fixtures-owner1-20261106.source-freeze.json" -Raw | ConvertFrom-Json
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
foreach($operation in @('check','clippy')){
 $name=$stem+'-'+$operation
 if(Test-Path -LiteralPath "$t/$name.json"){throw 'Preserve existing quality receipt'}
 $command=@($operation,'-p','arcweft-compiler','-p','arcweft-lang-sema','-p','arcweft-runtime-host','--all-targets','--all-features','--locked')
 Assert-Inputs
 $started=[DateTime]::UtcNow.ToString('o')
 & cargo @command *> "$t/$name.log"
 $code=$LASTEXITCODE
 Assert-Inputs
 [ordered]@{version=1;base=$freeze.base;command=$command;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Three changed test owners. Production Rust, manifests, dependencies, public contracts and budgets are unchanged; use complete-source workspace quality from the preceding owner epoch only for its original bytes.'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$t/$name.json" -Encoding utf8
 Write-Output "$name exit=$code"
 if($code){throw 'Changed test-owner quality check failed'}
}
