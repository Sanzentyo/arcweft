$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$full=Get-Content -LiteralPath "$t/view-agent-summary-reverse55-20261106.runtime.terminal-audit.json" -Raw | ConvertFrom-Json
$ownerStem='view-agent-consumer-fixtures-owner1-20261106'
$owner=Get-Content -LiteralPath "$t/$ownerStem.runtime.terminal-audit.json" -Raw | ConvertFrom-Json
$receipt=Get-Content -LiteralPath "$t/$ownerStem.runtime.json" -Raw | ConvertFrom-Json
$lines=[IO.File]::ReadAllLines($receipt.log)
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0 -or $owner.caseRowSource -ne 'final-status-after-summary'){throw 'Inspect actual terminal format before matching repairs'}
$cases=@{}
foreach($line in $lines[($summary+1)..($lines.Length-1)]){if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){$key=$Matches[2]+"`t"+$Matches[3];if($cases.ContainsKey($key)){throw 'Duplicate terminal case'};$cases[$key]=$Matches[1]}}
if($cases.Count -ne 15 -or $owner.passed -ne 15 -or $owner.failed){throw 'Unexpected repair result'}
$coverage=@(foreach($failure in $full.failureSet | Where-Object binary -ne 'arcweft-cli::check'){
 $test=if($failure.test -eq 'final_analysis::tests::view_modifier_without_an_accepted_catalog_fails_at_the_call_owner'){'final_analysis::tests::unregistered_view_modifier_fails_at_the_call_owner'}else{$failure.test}
 $key=$failure.binary+"`t"+$test
 if(-not $cases.ContainsKey($key) -or $cases[$key] -notin @('PASS','SLOW')){throw ('No passing repair for original failure: '+$failure.test)}
 [ordered]@{originalBinary=$failure.binary;originalTest=$failure.test;repairBinary=$failure.binary;repairTest=$test;status=$cases[$key];renamed=($test -ne $failure.test)}
})
if($coverage.Count -ne 14){throw 'Original nonCLI failure set differs'}
$before=Get-Content -LiteralPath "$t/view-agent-summary-reverse55-20261106.source-freeze.json" -Raw | ConvertFrom-Json
$after=Get-Content -LiteralPath "$t/$ownerStem.source-freeze.json" -Raw | ConvertFrom-Json
$old=@{};foreach($row in $before.paths){$old[$row.path]=$row.sha256}
$changed=@($after.paths | Where-Object {-not $old.ContainsKey($_.path) -or $old[$_.path] -ne $_.sha256} | Select-Object -ExpandProperty path | Sort-Object)
$expected=@('crates/arcweft-compiler/tests/dialogue_profile_admission.rs','crates/arcweft-compiler/tests/project_cache_transaction.rs','crates/arcweft-lang-sema/src/final_analysis/tests.rs','crates/arcweft-runtime-host/src/bundle_runner.rs' | Sort-Object)
if($before.paths.Count -ne $after.paths.Count -or @(Compare-Object $expected $changed).Count){throw 'Unexpected Source changes outside the reviewed test owners'}
[ordered]@{version=1;originalSource=$full.base;repairBase=$owner.base;originalRun=$full.run;repairRun=$owner.run;coverage=$coverage;covered=14;missing=0;renamedTests=1;actualOwnerCases=15;actualOwnerPassed=15;sourceInputs=$after.paths.Count;changedSourcePaths=$changed;productionStatement='All changed Rust hunks are in the existing tests or cfg(test) fixture block; review the explicit owned patch. Production input/dependency/wire/runtime identities and original held WIP are unchanged.';recordedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$t/view-agent-consumer-fixtures-coverage.json" -Encoding utf8
[ordered]@{covered=14;missing=0;renamed=1;actualOwnerCases=15;changedSourcePaths=$changed} | ConvertTo-Json -Compress
