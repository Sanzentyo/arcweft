$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$fullStem='view-agent-summary-reverse55-20261106'
$ownerStem='view-agent-consumer-fixtures-owner1-20261106'
$hostStem='view-agent-consumer-fixtures-host-extra1-20261106'
$qualityStem='view-agent-consumer-fixtures-quality1-20261106'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$source=Read-Record 'checkpoint-view-agent-consumer-fixtures-20261106.verified'
$audit=Read-Record ($fullStem+'.consumer-audit')
$terminal=$audit.terminal
$owner=Read-Record ($ownerStem+'.runtime.terminal-audit')
$extra=Read-Record ($hostStem+'.runtime.terminal-audit')
$quality=[ordered]@{check=Read-Record ($qualityStem+'-check');clippy=Read-Record ($qualityStem+'-clippy')}
if((git rev-parse HEAD).Trim() -ne $source.commit -or $terminal.failed -ne 26 -or $audit.nonCli.failed -ne 14 -or $audit.genericMatch.passed -ne 151 -or $owner.passed -ne 15 -or $owner.failed -ne 0 -or $extra.passed -ne 5 -or $extra.failed -ne 0 -or $quality.check.exitCode -or $quality.clippy.exitCode){throw 'Inspect unexpected actual input/result before recording status'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$historyPath='docs/implementation/convergence-evidence-history.md'
$statusPath='docs/implementation/current-status.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('viewAgentSummaryConsumers')){throw 'Preserve existing consumer evidence'}
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 ($_.Name.StartsWith($fullStem+'.') -or $_.Name.StartsWith($ownerStem+'.') -or $_.Name.StartsWith($hostStem+'.') -or $_.Name.StartsWith($qualityStem+'-') -or $_.Name.StartsWith('checkpoint-view-agent-consumer-fixtures-20261106.') -or $_.Name -in @('view-agent-consumer-fixtures-owner-measurements.json','view-agent-consumer-fixtures-coverage.json','view-agent-consumer-fixture-fmt-check.log')) -and $_.Extension -in @('.json','.log','.txt','.pathspec','.patch')
})
$files+=@(Get-Item -LiteralPath (Join-Path $t 'audit-view-agent-summary-reverse.ps1'),(Join-Path $t 'audit-view-agent-consumer-repairs.ps1'),(Join-Path $t 'run-presentation-projection-owner.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'rag-project-summary-graph.ps1'),(Join-Path $t 'run-view-agent-consumer-fixture-quality.ps1'),(Join-Path $t 'record-view-agent-summary-consumer-results.ps1'))
$files+=@(Get-ChildItem -LiteralPath $t -File | Where-Object {$_.Name -match '^rag-project-summary(?:\.(?:graph|metadata)|-arcweft-.+\.tree\.|-quality2-20261106-.+\.json$)' -and $_.Extension -in @('.json','.log','.txt')})
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-view-agent-summary-consumers.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$record.viewAgentSummaryConsumers=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;scope='Complete55-package execution and separate follow-up consumer fixture repair. The only current item list is current-status.md.'
 completeRun=$audit;genericMatch=Read-Record ($fullStem+'.generic-match');repair=$owner;repairAdditionalHost=$extra;repairCoverage=Read-Record 'view-agent-consumer-fixtures-coverage';repairQuality=$quality;ownership=Read-Record 'view-agent-consumer-fixtures-owner-measurements'
 repairReasons=@('Ten Compiler failures stopped at duplicate local binding Mobile after Style joined the shared retained declaration authority. These fixtures select Style by public ID and do not test a lexical Style name. Use ID-only pub style @style.Mobile, retaining exactly style.Mobile, view.Mobile, typography numbers/types, source-range/codec checks and every rejection assertion. Named Style retains the same module value namespace as other declarations; do not add an alternate resolver or rename the accepted public IDs.','The old Sema negative input used .x(10px), which is now a registered standard modifier and is valid. Keep rejection at the exact Call owner and UnknownCallKind::Method for a genuinely unregistered member; do not revoke .x support to keep the stale negative green.','Three runtime-host fixture failures replaced the accepted complete View/Style product with an isolated compiled Style resource and correctly failed the exact generation fingerprint check. Attach the original CompiledSource validated product through the existing public bundle API. Keep Source/generation admission, actual flow-event/session/task-retirement assertions and the original step/operation budgets.')
 interpretation=@('The complete run actually exits100:9579run9553PASS26FAIL48skip1260.752s. CLI700run688PASS12FAIL; nonCLI8879run8865PASS14FAIL. Retain those actual totals unchanged.','The follow-up run separately verifies15/15PASS, covering all14 nonCLI failure IDs through the updated cases plus the complete10-case profile suite. This is not a new full55 run and its result is not added to the failed full-run total.','Exact accepted Generic Match151 identities all pass in the full run, with no missing IDs. Its accepted/public status and other unrelated completed boundaries remain intact.','The original full workspace98 check/Clippy/structure exit0 belongs to the complete-run4113 input epoch, whose recorded hash set matches the earlier quality input exactly. After test-only repair, run fresh check/Clippy for the three changed test owners. Production Rust, dependency graph, wire/schema/version and runtime algorithms are unchanged; warnings remain. Dedicated wasm/doctest/Tier2/final Native-Web parity is not inferred.','Original12 tracked WIP and6 untracked remain. The full run contains the held working-tree input; do not claim a pristine committed-tree execution or publish user WIP snapshots in raw evidence.')
 correctionReason='Replace the preceding in-progress consumer status with actual terminal totals and separately validated repairs. A provisional nonCLI-pass assumption was contradicted by the terminal inventory and was never published as acceptance. Preserve all prior failed/passed attempts and full SHAs. Remaining CLI12 conditions stay in the single current list; overall goal status does not reopen accepted Generic Match or other completed owners.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
 '| 共有契約／推移的逆依存matrix | **全55 packageの終端は26 FAIL。追加14件は後続ownerで修復・検証済み** | Source '+$audit.source+'。実Cargo graphは55 packageで一致し、52 packageに9579実行9553 PASS／26 FAIL／48 skipped、1260.752秒。非CLI8879は8865 PASS／14 FAIL、CLI700は688 PASS／12 FAIL。host buildのみはarcweft／arcweft-bundle-assets／arcweft-render-web。source4113／case／EXE drift0。後続Source '+$source.commit+'は同じStyle公開IDを明示ID-only宣言へ揃え、登録済みxの旧負例を訂正し、host fixtureへ完全な受理済みView productを渡す。14失敗を含む対象15／15 PASSは独立したowner runであり、全55の成功へ合算しない。[全終端・失敗ID・修復と検証範囲・raw](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| CLI全target照合 |')){
 '| CLI全target照合 | **新しい全700実測は688 PASS／12 FAIL。RAG・z-indexは修復済み** | Source '+$audit.source+'の全55 consumer runで全700件を実行した結果。旧Source afdf8773b3743df2fd16691e0ea4deec6183db46の686 PASS／14 FAILも実測のまま履歴へ保持する。残る12 IDはfull-grammar現在line選択3件、Scroll解決1件、旧plan／unsafe fixture2件、run-edge1件、負例診断1件、verifier fixture4件。RAGの複数Source・kind別件数・保存session、z-indexのpresentation／geometry／captureは元のquery／limit／予算と検査を保って全runでもPASS。[全失敗ID・各owner修復・全run原本](acceptance-evidence/task-rich-text-property-identity.json)。Generic Matchと他の既受入境界は維持する。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 '| workspace check／Clippy・fmt・構造gate | **本体Sourceの全98 gateと、後続fixture3 ownerのcheck／Clippyは終了0。警告は残る** | 全55実行のSource '+$audit.source+'と同じ4113入力で、全98 all-target／all-feature／locked check・Clippyと構造gateは終了0。後続Source '+$source.commit+'は本体Rust／依存／公開契約／実行予算を変えず、3 test ownerを同じfeature条件のcheck／Clippyで新規検証した。fmt全体checkも終了0。既存12 tracked／6 untracked WIPを保持。専用wasm・doctest・Tier2・最終Native-Web parityは別境界。[各入力・所有測定・部分stage証明・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| Generic Match `.1.2` C3/C5 |')){
 '| Generic Match `.1.2` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。完全transcript、uninhabited-domain、Never／let-else継続、exhaustive-only atomic publicationの受入を維持。[元の受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)。Source '+$audit.source+'の全55逆依存で同じ151 IDが151／151新規PASS、欠落0。先行Font48の151 PASSも別入力の履歴に保持。[最新case照合・全実測](acceptance-evidence/task-rich-text-property-identity.json)。別境界や全体goalの未達を理由に未完了へ戻さない。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Complete55-package View/Agent consumer run and separate fixture repair

- Frozen Source $($audit.source): $($terminal.summary), exit100. CLI700/688PASS12FAIL; nonCLI8879/8865PASS14FAIL. All52 runtime packages and3 host-build-only packages are accounted for; source4113/case/EXE drift0. Compared with the old Font48 run,14 additional failure IDs appeared and the RAG/z-index IDs no longer fail. Preserve older7140/14FAIL,700/14FAIL and9757/55FAIL unchanged.
- Source $($source.commit) repairs the14 additional consumer conditions in existing test owners. Compiler fixtures retain style.Mobile/view.Mobile and all geometry/type/source/codec assertions with explicit ID-only Style declarations; no second name resolver is added. Sema retains exact owner/method rejection for an unregistered modifier, while registered x remains accepted. Runtime-host attaches the original complete validated View product instead of replacing its Style with an isolated fragment; fingerprint validation and real session/task budgets remain intact. Separate owner: $($owner.summary). Other callers of the same host fixture: $($extra.summary), covering Native terminal request retirement and four existing negative admission conditions. Do not reconstruct a green full55 run from the focused repair.
- Accepted Generic Match exact set151/151PASS, missing0, failed0 (115transcript24coverage5public-query7Native/AWBC). Acceptance850534b9e9bc8c8872f6528dd00050a5e6e7699e and publicationf0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2 remain in force. The additional failures are concrete separate consumer conditions, not a reason to reopen accepted Generic Match.
- The pre-repair full workspace98 check/Clippy/structure exit0 is tied to the complete-run Source hash set. The test-only follow-up has fresh three-owner check/Clippy exit0 and fmt check0. Production Rust and dependency/wire/runtime contracts are unchanged; warnings remain. Dedicated wasm/doctest/Tier2/final Native-Web parity is not inferred. Original12 tracked WIP and6 untracked remain; the frozen run includes held input and is not a pristine committed-tree claim.
- Supersedes the preceding dated checkpoint's in-progress consumer status. A provisional nonCLI-pass draft was contradicted by the terminal inventory and was not published as acceptance. Actual failed/passed attempts, full SHAs and partial validation limits remain in the existing record. [Full terminal, case comparison, separate repair, ownership and verified raw](acceptance-evidence/task-rich-text-property-identity.json); [only current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Prior evidence changed: '+$key)}}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'Historical bytes changed'}
[ordered]@{version=1;source=$source.commit;rawPath=$rawPath;rawBytes=$raw.bytes;rawSha256=$raw.sha256;rawEntries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0;originalTracked=12;originalUntracked=6} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'view-agent-consumer-results-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'view-agent-consumer-results-documentation-audit.json')
