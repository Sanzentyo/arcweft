$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/prepared-effect-scope.publication.json"|ConvertFrom-Json
$inputPin=Get-Content -Raw "$root/prepared-effect-scope.input.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/prepared-effect-scope.owner-validation.json"|ConvertFrom-Json
$previous=Get-Content -Raw "$root/extracted-effect-read.owner-summary.json"|ConvertFrom-Json
$baseline=Get-Content -Raw "$root/extracted-effect-read.owner-terminal.json"|ConvertFrom-Json
if($quality.Source -ne $pub.Parent -or $inputPin.Source -ne $pub.Parent -or $quality.Steps.Count -ne 3){throw 'Owner input differs'}
foreach($step in $quality.Steps){
    $expected=if($step.Name -eq 'owner-run'){100}else{0}
    if($step.ExitCode -ne $expected -or !$step.SourcePinsVerified){throw 'Owner step differs'}
}
$log=[IO.File]::ReadAllText("$root/prepared-effect-scope.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1776 tests run: 1770 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Owner terminal summary differs'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1776\) (\S+) (.+)\r?$')|ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/prepared-effect-scope.owner-list.json"|ConvertFrom-Json
$ids=@(foreach($suite in $listing.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Name+'$'+$case.Name}}})
if($ids.Count -ne 1776 -or $terminal.Count -ne 1776 -or @($terminal|Group-Object Id|Where-Object Count -GT 1).Count -or @(Compare-Object -CaseSensitive @($ids|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selected and terminal identities differ'}
$delta=@(Compare-Object -CaseSensitive @($baseline.Id|Sort-Object) @($ids|Sort-Object))
if($delta.Count -ne 8 -or @($delta|Where-Object SideIndicator -CNE '=>').Count){throw 'Baseline test identities changed'}
$new=@($terminal|Where-Object {$delta.InputObject -ccontains $_.Id})
if($new.Count -ne 8 -or @($new|Where-Object Result -CNE 'PASS').Count){throw 'New conditional cases failed'}
$failed=@($terminal|Where-Object Result -CEQ 'FAIL'|ForEach-Object Name|Sort-Object)
if(@(Compare-Object -CaseSensitive $previous.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failure identity/diagnostics changed'}
$measurements=@(foreach($p in $pub.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($pub.Source):$($p.Path)") -ne $p.Blob){throw 'Tested source identity changed'}
    $before=@(git show "$($pub.Parent):$($p.Path)" 2>$null); if($LASTEXITCODE){$before=@()}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    [pscustomobject]@{Path=$p.Path;Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$before.Count;Growth=$lines-$before.Count;Class=if($p.Path -like '*/tests.rs' -or $p.Path -like '*/tests/*'){'test'}else{'production'};EmbeddedUnitTestLOC=$(if($p.Path -notlike '*/tests.rs' -and $p.Path -notlike '*/tests/*'){ $text=[IO.File]::ReadAllText($p.Path); $m=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod tests \{'); if($m.Success){$lines-($text.Substring(0,$m.Index).Split([char]10).Length-1)}else{0}}else{0});Owner='arcweft-lang-sema';SHA256=$p.SHA256;Blob=$p.Blob}
})
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse 'HEAD^{tree}') -ne $pub.Tree -or @(git diff --name-only HEAD).Count){throw 'Final source identity differs'}
$metadata=Get-Content -Raw "$root/prepared-effect-scope.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$fanOut=@(($metadata.resolve.nodes|Where-Object id -CEQ $owner.id).deps).Count
$fanIn=@($metadata.resolve.nodes|Where-Object {$_.deps.pkg -ccontains $owner.id}).Count
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/prepared-effect-scope.owner-terminal.json"
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;OwnerInputParent=$pub.Parent;TestedDirtyBytesEqualCommittedBlobs=$true;Selected=1776;Passed=1770;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;IdsEqual=$true;Duplicates=0;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;Baseline=$previous.Source;FmtExit=0;Measurements=$measurements;PhysicalGrowth=($measurements|Measure-Object Growth -Sum).Sum;FanIn=$fanIn;FanOut=$fanOut;OwnershipDisposition='One mathematical graph owns identities and mutation accounting. An owned read scope shares immutable original source facts and whole obligations without holding affine publication tokens. A scoped edit reads those inputs, journals only its own writes, and extracts or rolls back to the exact original base. Flat source chunks and flat input ordinals avoid recursive owned dependency chains. Single and batch restore use one preflight/publication path; every transitive layer needs its actual affine permit and conflicting sibling body definitions are rejected before mutation. Replay validates original input origins before comparing the real new relation, and shared term substitution reads the same owner view. Prepared type projection accepts an affine term edit so the existing structural fold works within the scope without another traversal. Seven scope cases and one type projection case cover canonical closure, preserved formals and domain, unpublished sources, all budget cut points, original cancellation, rollback, conflicts, replay and 256 transitive layers. The frontend value ports and six recursive-body failures remain unresolved; this private ownership cut does not reopen accepted functionality or claim analyzer integration. No public contract, Cargo input, I/O, unsafe, version, profile or default budget change.'}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/prepared-effect-scope.owner-summary.json"
Get-Content "$root/prepared-effect-scope.owner-summary.json" -TotalCount 18

