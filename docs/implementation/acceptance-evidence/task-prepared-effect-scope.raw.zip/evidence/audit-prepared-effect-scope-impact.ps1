$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/prepared-effect-scope.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/prepared-effect-scope.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {$changed=$false;foreach($node in $metadata.resolve.nodes){if(!$closure.Contains($node.id)){foreach($dependency in $node.deps){if($closure.Contains($dependency.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/extracted-effect-read.impact.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/scoped-structural-fold.consumer-summary.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count -or @(Compare-Object -CaseSensitive @($previous.PackageIds|Sort-Object) @($packages.id)).Count){throw 'Resolved reverse graph changed'}
if(@(git diff --name-only $previous.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml').Count){throw 'Cargo graph inputs changed'}
$tree=[IO.File]::ReadAllText("$root/prepared-effect-scope.reverse-tree.txt")
$workspace=@($metadata.packages|Where-Object {$metadata.workspace_members -ccontains $_.id}|ForEach-Object name)
$treePackages=@([regex]::Matches($tree,'(?m)([a-z][a-z0-9-]+) v[0-9][^\s]*')|ForEach-Object {$_.Groups[1].Value}|Where-Object {$workspace -ccontains $_}|Sort-Object -Unique)
if(@(Compare-Object -CaseSensitive @($packages.name|Sort-Object) $treePackages).Count){throw 'Reverse tree differs from resolved metadata'}
if($consumers.Source -ne $previous.BaselineConsumerSource -or $consumers.Targets -ne 107 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or $consumers.Skipped -ne 1){throw 'Baseline consumer evidence differs'}
[ordered]@{
    Version=1;Source=$pub.Source;Tree=$pub.Tree;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='prepared-effect-scope.reverse-tree.txt';CargoInputsUnchanged=$true
    ReverseConsumersRerun=$false;BaselineConsumerSource=$consumers.Source;BaselineConsumerTargets=$consumers.Targets;BaselineConsumerPassed=$consumers.Passed;BaselineConsumerFailed=$consumers.Failed;BaselineConsumerSkipped=$consumers.Skipped
    Scope='One mathematical graph owns identities and mutation accounting. An owned read scope shares immutable original source facts and whole obligations without holding affine publication tokens. A scoped edit reads those inputs, journals only its own writes, and extracts or rolls back to the exact original base. Flat source chunks and flat input ordinals avoid recursive owned dependency chains. Single and batch restore use one preflight/publication path; every transitive layer needs its actual affine permit and conflicting sibling body definitions are rejected before mutation. Replay validates original input origins before comparing the real new relation, and shared term substitution reads the same owner view. Prepared type projection accepts an affine term edit so the existing structural fold works within the scope without another traversal. Seven scope cases and one type projection case cover canonical closure, preserved formals and domain, unpublished sources, all budget cut points, original cancellation, rollback, conflicts, replay and 256 transitive layers. The frontend value ports and six recursive-body failures remain unresolved; this private ownership cut does not reopen accepted functionality or claim analyzer integration. No public contract, Cargo input, I/O, unsafe, version, profile or default budget change. No fresh reverse-consumer, workspace-quality, doctest or Tier 2 run is claimed; preserved downstream receipts retain their original source.'
}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/prepared-effect-scope.impact.json"
Write-Output "Verified unchanged reverse closure: $($packages.Count) packages; owner-only scope recorded"
