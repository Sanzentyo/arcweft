$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/prepared-effect-scope.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/prepared-effect-scope.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$scratch/prepared-effect-scope.impact.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/prepared-effect-scope.quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/prepared-effect-scope.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/prepared-effect-scope.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git ls-remote origin refs/heads/main).Split()[0] -ne $pub.Source -or !$pub.Pushed){throw 'Source publication not observed'}
if($owner.Passed -ne 1770 -or $owner.Failed -ne 6 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.Blocking -ne 0 -or !$archive.AllEntriesVerified){throw 'Final receipts differ'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previous=[IO.File]::ReadAllText((Join-Path $PWD $status))
$historyBytes=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previous,'(?m)^\| Generic Match[^\r\n]+').Value
if(!$generic){throw 'Generic Match authority row missing'}
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']="| 再帰関数値の終端効果 | **既受入を維持。未公開入力を読むスコープ編集・依存の一括確定まで検証・公開。本体内の関数値推論は継続** | Source ``$($pub.Source)``。型・const・効果・predicateの移送は共通のscoped foldを使い、型検査済み本体の効果closureは元formal・D・実call方程式のscheme代数を使う。prepared値componentは元graphを借り、候補は変更journalで転送する。未公開の元入力をimmutableなread scopeとして共有し、その上の編集は自分の差分だけを抽出・巻き戻す。型の効果投影も同じterm editを受け取る。確定には推移的な全入力の元affine tokenが必要で、借用だけでは確定できない。caller-bound recursion・共有prefix・Free許可／reifyの既受入を維持する。型検査前の宣言scheme登録、prepared型を含む全関数値port／ΓとAnalyzerの統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[本体closure](convergence-evidence-history.md#callable-body-declaration-scheme-closure)・[現在の所有境界と検証](convergence-evidence-history.md#scoped-effect-edits-and-affine-dependency-publication)。 |"
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,770 PASS／6 FAIL。後続matrixは元入力の実測を保持** | Source ``$($pub.Source)`` のlocked・全feature lib／tests 1,776件を$($owner.ExecutionSeconds)秒で実行。直前1,768 ID保持・新8件PASS、選択／終端ID一致・重複0。保持6失敗のIDと5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeは22 packageで不変。変更はSema privateな数学owner・read scope・差分確定・型の効果投影で、全ownerを検証した。後続21 package／107 targetは今回未再実行。Source ``$($impact.BaselineConsumerSource)`` の2,510件／2,507 PASS／2 FAIL／1 SKIPを元入力の実測として保持する。[今回のowner・選定理由](acceptance-evidence/task-prepared-effect-scope.raw.zip)・[consumer原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **所有Semaの品質・fmt・構造は今回終了0。workspace品質は元入力の実測を保持** | Source ``$($pub.Source)`` のlocked Sema全target／全feature check・Clippy、workspace fmt、構造gateは終了0。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。$($pub.Paths.Count) Rust path・$($owner.PhysicalGrowth)物理LOC増、fan-in／out $($owner.FanIn)／$($owner.FanOut)。数学ownerのscopeと出版前検証に責任を集約し、既存の共通型foldを使う。公開API・依存・I/O・codec・version・既定予算は不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。workspace全target／全feature品質とSema doctest 2件はSource ``$($impact.BaselineConsumerSource)`` の実測を保持する。後続nextest・Tier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入は今回未実行。[今回の品質・構造](acceptance-evidence/task-prepared-effect-scope.raw.zip)・[workspace原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$current=$previous
foreach($key in $rows.Keys){
 $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
 if([regex]::Matches($current,$pattern).Count -ne 1){throw "Authority row missing or duplicated: $key"}
 $replacement=$rows[$key]
 $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-14。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
$entry=@"

## Scoped effect edits and affine dependency publication

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの$($pub.Paths.Count) Rust pathを通常commit／非force pushし、検証したdirty bytesとcommit・公開blobを照合した。未追跡 ``%SystemDrive%/`` は保持した。

- read scopeは同じissuer／exact baseの元source定義と元Cをimmutableに共有し、公開用affine delta tokenは所有しない。scope editはその入力をrestoreせずに読み、自分のfunction／row／predicate／choice／obligationだけをjournalへ記録し、finishで自分の差分を抽出して元baseへ戻す。失敗・取消・dropも巻き戻す。source chunkと依存IDはflatな所有関係で、深い依存が再帰的なArc解放にならない。
- 単独／一括restoreは同じpreflightと確定処理を使う。推移的な全source chunkに対応する元affine permitを要求し、元headerの因果的なDeclared→BodyPrepared以外の競合を拒否する。全検査・control chargeより前にlive graphを変えない。元のC／formal／Dを保持し、readonly scopeから確定権限を作らない。replayは元入力のoriginを検証してから実際の新しい関係を比較し、ordinal順を意味上の同値性には使わない。
- 既存のterm substitutionを同じread viewへ移し、prepared型の効果投影はaffine term editを受け取る。これにより既存の共通structural foldが未公開sourceを読める。新8件は、実closureとcanonical型への投影、未使用formalとD、全予算点の原子性、元の取消エラー、nested edit／outer rollback、依存不足とsibling競合、元入力を固定したreplay、256段の推移的依存を検証する。これは数学ownerと型投影の境界であり、Analyzerのprepared値portを接続した証拠ではない。
- 最終ownerは1,776件／1,770 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,768 ID保持・新8件PASS、選択／終端ID一致・重複0。失敗IDと5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。Sema全target／全feature check・Clippy、workspace fmt、構造gateは終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。$($pub.Paths.Count) path・$($owner.PhysicalGrowth)物理LOC増。各pathの実byte／物理LOCと分類、ownerの責任分離、fan-in／out $($owner.FanIn)／$($owner.FanOut)を記録した。unsafe・公開契約・Cargo入力・I/O・version・既定予算は変更せず、CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- fresh full metadata／全target reverse treeの22 packageは不変。privateなownerとSema内consumerの変更として全ownerと品質を選定した。Source ``$($impact.BaselineConsumerSource)`` の後続21 package／107 target・2,510件／2,507 PASS／2 FAIL／1 SKIP、workspace品質、doctest 2件は元入力の実測として保持し、今回の再実行へ合算しない。Tier 2と新しい実機受入は未実行。
- 開発checkの最初のE0609と、初回owner-listのtest import不足6件／終了101を原本に保持した。後者はproductionの不要なimportを除いた際にtest側の暗黙importが失われたもので、testの明示importを修復してから全ownerを再実行した。開発check終了0は最新変更前の開発証拠で、最終の固定入力検証と区別する。
- ユーザーの全体削除指定に従い、11:17:57–11:18:11 JSTにworkspace rootで ``cargo clean`` を実行し終了0。30,600 files／88.1 GiBを削除し、target不存在と作業ツリーstatus不変を確認した。ビルド生成物の移動・退避は行わず、その後の検証で再ビルドした。前のcleanの実測は書き換えない。
- Supersedes: 読取りが抽出delta一つの借用までだった説明を、元入力のreadonly scope上で差分だけを作り、全affine依存を一括確定する現在の境界へ更新する。重複したcut別説明は現状行から除き、過去のSHA・検証結果・訂正理由を履歴に保持した。保持6失敗は未解消であり、Generic Matchや再帰・共有prefix・型移送の既受入を未完了へ戻さない。残作業の現状一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-prepared-effect-scope.raw.zip](acceptance-evidence/task-prepared-effect-scope.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
foreach($document in @($rows.Values)+@($entry)){
 foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
  $target=$match.Groups[1].Value
  if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
  if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link $target"}
 }
}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText((Join-Path $PWD $history),"`n"+$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($historyBytes.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBytes)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical evidence index changed'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$historyBytes.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true;FinalWhitespaceExit=0}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/prepared-effect-scope.docs-validation.json"
git diff --stat
