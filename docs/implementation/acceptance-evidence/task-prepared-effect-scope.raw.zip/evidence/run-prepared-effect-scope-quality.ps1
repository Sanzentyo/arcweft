$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$inputPin=Get-Content -Raw "$root/prepared-effect-scope.input.json"|ConvertFrom-Json
$steps=[Collections.Generic.List[object]]::new()
function Assert-Source {
    if((git rev-parse HEAD) -ne $inputPin.Source){throw 'Quality HEAD changed'}
    if(@(Compare-Object -CaseSensitive @($inputPin.Paths.Path|Sort-Object) @(@(git diff --name-only HEAD)+@(git ls-files --others --exclude-standard|Where-Object { $_.StartsWith('crates/arcweft-lang-sema/') -and $_.EndsWith('.rs') })|Sort-Object -Unique)).Count){throw 'Quality paths changed'}
    foreach($p in $inputPin.Paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Quality source bytes changed'}}
}
foreach($step in @(@{Name='sema-check';Arguments=@('check','--locked','-p','arcweft-lang-sema','--all-targets','--all-features')},@{Name='sema-clippy';Arguments=@('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features')})){
    Assert-Source
    $start=Get-Date
    Write-Output "START $($step.Name)"
    & cargo @($step.Arguments) 1>"$root/prepared-effect-scope.$($step.Name).stdout" 2>"$root/prepared-effect-scope.$($step.Name).log"
    $code=$LASTEXITCODE
    Assert-Source
    $steps.Add([pscustomobject]@{Name=$step.Name;Arguments=$step.Arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;SourcePinsVerified=$true})
    [ordered]@{Version=1;Source=$inputPin.Source;CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false;Steps=@($steps.ToArray())}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/prepared-effect-scope.quality.json"
    Write-Output "END $($step.Name) exit=$code"
    if($code){throw 'Owner quality failed'}
}
