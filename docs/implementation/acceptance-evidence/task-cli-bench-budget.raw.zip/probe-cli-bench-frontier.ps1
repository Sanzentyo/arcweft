$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$directory="$taskEvidence/cli-bench-frontier1"
if(Test-Path -LiteralPath $directory){throw 'Preserve prior observations'}
[void][IO.Directory]::CreateDirectory($directory)
$binary='D:/git/arcweft/target/debug/arcw.exe';$binaryHash=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant()
$source=[IO.File]::ReadAllText('D:/git/arcweft/crates/arcweft-cli/tests/check/cli_runtime_bench.rs')
$probes=@(
 @{Name='branch';Test='bench_json_measures_branching_for_loop_pure_jit_characteristics';Args=@('--iterations','2','--warmup','1','--steps','48','--max-ops','8','--pure-backend','jit')},
 @{Name='match';Test='bench_json_measures_runtime_match_to_pure_jit_characteristics';Args=@('--iterations','2','--warmup','1','--steps','24','--max-ops','8','--pure-backend','jit')},
 @{Name='scalar';Path='D:/git/arcweft/tests/fixtures/arcw/spec_should_pass/bench/003_for_pure_jit.arcw';Args=@('--iterations','3','--warmup','1','--samples','3','--steps','64','--max-ops','64','--pure-backend','jit')},
 @{Name='mixed';Path='D:/git/arcweft/tests/fixtures/arcw/spec_should_pass/bench/033_mixed_for_iter_pure_jit.arcw';Args=@('--iterations','2','--warmup','1','--samples','1','--steps','128','--max-ops','128','--pure-backend','jit')},
 @{Name='validate';Test='bench_json_validates_headless_script_benches';Args=@()},
 @{Name='adapter';Test='bench_json_skips_adapter_only_script_benches';Args=@()}
)
$results=@(foreach($probe in $probes){
 $path=$probe.Path
 if(-not $path){
  $pattern='(?s)fn '+[regex]::Escape($probe.Test)+'\(\).*?r(?<hash>#?)"(?<body>.*?)"\k<hash>,'
  $fixture=[regex]::Match($source,$pattern).Groups['body'].Value
  if(-not $fixture){throw ('Missing exact test fixture: '+$probe.Test)}
  $path="$directory/$($probe.Name).arcw";[IO.File]::WriteAllText($path,$fixture,[Text.UTF8Encoding]::new($false))
 }
 $arguments=@('bench',$path)+$probe.Args+@('--json');$started=[DateTime]::UtcNow.ToString('o')
 & $binary @arguments 1> "$directory/$($probe.Name).stdout.json" 2> "$directory/$($probe.Name).stderr.log"
 $code=$LASTEXITCODE
 $report=Get-Content -LiteralPath "$directory/$($probe.Name).stdout.json" -Raw|ConvertFrom-Json -Depth 100
 [ordered]@{name=$probe.Name;command=$arguments;sourceSha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();exitCode=$code;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');report=$report;stdoutSha256=(Get-FileHash -LiteralPath "$directory/$($probe.Name).stdout.json").Hash.ToLowerInvariant();stderrSha256=(Get-FileHash -LiteralPath "$directory/$($probe.Name).stderr.log").Hash.ToLowerInvariant()}
})
if((Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant() -ne $binaryHash){throw 'CLI executable changed during observations'}
[ordered]@{version=1;head=(git rev-parse HEAD).Trim();workingTree='Pending Thread10-path patch plus original WIP';binarySha256=$binaryHash;binaryDrift=0;observations=$results;scope='Actual direct CLI observations, using each existing test workload/options unchanged. No Cargo execution, no threshold-based timing claim.'}|ConvertTo-Json -Depth 100|Set-Content -LiteralPath "$directory/observations.json" -Encoding utf8
foreach($row in $results){[ordered]@{name=$row.name;exitCode=$row.exitCode;benches=@($row.report.benches|ForEach-Object {[ordered]@{id=$_.id;status=$_.status;diagnostics=$_.diagnostics;sections=@($_.sections|ForEach-Object {[ordered]@{name=$_.name;status=$_.status;diagnostics=$_.diagnostics;deterministic=$_.measurement.deterministic}})}})}|ConvertTo-Json -Depth 15 -Compress}
