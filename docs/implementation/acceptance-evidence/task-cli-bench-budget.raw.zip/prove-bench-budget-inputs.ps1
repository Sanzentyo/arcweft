$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskEvidence/convergence-image-git-bytes.ps1"
$head=(git rev-parse HEAD).Trim();$path='crates/arcweft-cli/tests/check/cli_runtime_bench.rs'
$beforeBytes=Read-GitBytes @('show',"${head}:$path");$nowBytes=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($path))
$before=[Text.Encoding]::UTF8.GetString($beforeBytes).Replace("`r`n","`n");$now=[Text.Encoding]::UTF8.GetString($nowBytes).Replace("`r`n","`n")
function Sha([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
function Test-Block([string]$source,[string]$name){$start=$source.IndexOf("fn $name()");if($start -lt 0){throw 'Missing benchmark test'};$end=$source.IndexOf("`n#[test]`nfn ",$start);if($end -lt 0){$end=$source.Length};$source.Substring($start,$end-$start)}
$cases=@(foreach($name in @('bench_json_measures_branching_for_loop_pure_jit_characteristics','bench_json_measures_runtime_match_to_pure_jit_characteristics','bench_json_measures_checked_in_scalar_for_pure_jit_perf_guard','bench_json_measures_checked_in_mixed_for_iter_pure_jit_fixture')){
 $oldBlock=Test-Block $before $name;$newBlock=Test-Block $now $name
 $oldCommand=[regex]::Match($oldBlock,'(?s)let output = Command::new.*?\.output\(\)').Value
 $newCommand=[regex]::Match($newBlock,'(?s)let output = Command::new.*?\.output\(\)').Value
 if(-not $oldCommand -or $oldCommand -cne $newCommand){throw 'Original benchmark command/options changed'}
 $oldFixture=[regex]::Match($oldBlock,'(?s)\br#"(?<body>.*?)"#,').Groups['body'].Value
 $newFixture=[regex]::Match($newBlock,'(?s)\br#"(?<body>.*?)"#,').Groups['body'].Value
 if($oldFixture -cne $newFixture){throw 'Authored benchmark workload changed'}
 [ordered]@{test=$name;commandSha256=(Sha ([Text.Encoding]::UTF8.GetBytes($oldCommand)));commandDrift=0;inlineFixture=$(if($oldFixture){[ordered]@{sha256=(Sha ([Text.Encoding]::UTF8.GetBytes($oldFixture)));drift=0}}else{$null})}
})
$freeze=Get-Content -LiteralPath "$taskEvidence/thread-indent-reverse1-20261103.source-freeze.json" -Raw|ConvertFrom-Json;$hashes=@{};foreach($row in $freeze.paths){$hashes[$row.path]=$row.sha256}
$fixtures=@(foreach($fixturePath in @('tests/fixtures/arcw/spec_should_pass/bench/003_for_pure_jit.arcw','tests/fixtures/arcw/spec_should_pass/bench/033_mixed_for_iter_pure_jit.arcw')){$hash=(Get-FileHash -LiteralPath $fixturePath).Hash.ToLowerInvariant();if(-not $hashes.ContainsKey($fixturePath) -or $hash -ne $hashes[$fixturePath]){throw 'Checked-in benchmark workload changed'};[ordered]@{path=$fixturePath;sha256=$hash;drift=0}})
$loc=[regex]::Matches([Text.Encoding]::UTF8.GetString($nowBytes),"`n").Count;$baseLoc=[regex]::Matches([Text.Encoding]::UTF8.GetString($beforeBytes),"`n").Count
$value=[ordered]@{version=1;base=$head;productionSource='cdcda93e5aedb446c88167d6079ab0e5ca48d9c1';productionChanges=0;cases=$cases;checkedInFixtures=$fixtures;normalization='Compare Rust fixture and command source with CRLF normalized to LF; preserve literal content, iterations/warmup/samples/steps/max-ops and backend arguments. Actual emitted fixture hashes and native executable hashes are pinned separately by the direct probes.';runtimeEvidence='cli-bench-frontier1 contains original benchmark and Drain run observations. Scalar completes16 calls, all16 logs and done under64op dispatches64+36; mixed completes40 calls,19 logs and done under128+9. Branch8 total calls and4 logs span8+8+8+8+8+8+8+7, match logs12 and returnsdone under8+1.';ownerReview=[ordered]@{path=$path;crate='arcweft-cli';classification='integration-test responsibility module';bytes=$nowBytes.Length;physicalLoc=$loc;basePhysicalLoc=$baseLoc;growth=$loc-$baseLoc;embeddedTestLoc=$loc;workspaceFanIn=0;workspaceFanOut=55;disposition='Above8000LOC; retain the existing benchmark fixture/result owner. The one private helper is used only by these4 tests to verify the same source workload, exact final logs/return and per-step budgets. No unrelated state, shared production helper, public API widening, dependency or I/O ownership change; growth is below300LOC. Reuse the unchanged dependency disposition while the canonical gate is freshly0.'}}
$value|ConvertTo-Json -Depth 30|Set-Content -LiteralPath "$taskEvidence/bench-budget.inputs-proof.json" -Encoding utf8
[ordered]@{cases=$cases.Count;unchangedCommands=$cases.Count;unchangedInlineFixtures=@($cases|Where-Object inlineFixture).Count;unchangedCheckedFixtures=$fixtures.Count;physicalLoc=$loc;baseLoc=$baseLoc;growth=$loc-$baseLoc;productionChanges=0}|ConvertTo-Json -Compress
