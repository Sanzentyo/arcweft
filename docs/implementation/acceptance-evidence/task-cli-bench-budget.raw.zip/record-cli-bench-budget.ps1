$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskEvidence/assert-no-arcweft-build.ps1"
. "$taskEvidence/convergence-image-git-bytes.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$taskEvidence/$name.json" -Raw|ConvertFrom-Json -Depth 100}
function Sha([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
$head=(git rev-parse HEAD).Trim();$publication=Receipt 'checkpoint-cli-bench-budget.verified'
if($head -ne $publication.commit -or $publication.parent -ne '4a72b9a6fdf88656554f455ed5530dea2a486f3d' -or $publication.paths.Count -ne 3){throw 'Review source publication'}
$run=Receipt 'bench-budget-owner1-20261103.runtime.terminal-audit'
if(-not $run.isPassingRun -or $run.executed -ne 4){throw 'Focused benchmark conditions failed'}
$quality=@(foreach($kind in @('check','clippy','structure')){$row=Receipt "bench-budget-quality1-20261103-$kind";if($row.exitCode -or $row.sourceDrift){throw 'Required quality gate failed'};$row})
$fmt=Receipt 'bench-budget-fmt';if($fmt.exitCode){throw 'Formatting failed'}
$freeze=Receipt 'bench-budget-owner1-20261103.source-freeze';foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$proof=Receipt 'bench-budget.inputs-proof';if($proof.productionChanges -or $proof.cases.Count -ne 4){throw 'Workload proof incomplete'}
$baseline=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-thread-indentation.json -Raw|ConvertFrom-Json -Depth 100
$failKeys=@($baseline.combined.cli.failureSet|ForEach-Object {$_.test})
foreach($row in $proof.cases){if($row.test -notin $failKeys){throw 'A targeted case was not an observed baseline failure'}}
$untracked=Receipt 'task-documentation-final-untracked-before';foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$history='docs/implementation/convergence-evidence-history.md';$before=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));$committed=Read-GitBytes @('show',"HEAD:$history")
if((Sha $before) -ne (Sha $committed)){throw 'History already has unpublished edits'}
$raw='docs/implementation/acceptance-evidence/task-cli-bench-budget.raw.zip';$record='docs/implementation/acceptance-evidence/task-cli-bench-budget.json'
if((Test-Path -LiteralPath $raw) -or (Test-Path -LiteralPath $record)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $taskEvidence -File|Where-Object {$_.Name.StartsWith('bench-budget-') -or $_.Name.StartsWith('bench-budget.') -or $_.Name.StartsWith('checkpoint-cli-bench-budget.')})
$files+=@(Get-ChildItem -LiteralPath "$taskEvidence/cli-bench-frontier1" -File)
$files+=@(Get-ChildItem -LiteralPath "$taskEvidence/bench-budget-quality1-20261103.structure-report" -File -Recurse)
$files+=@(foreach($name in @('record-cli-bench-budget.ps1','prove-bench-budget-inputs.ps1','probe-cli-bench-frontier.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','run-action-payload-quality.ps1')){Get-Item -LiteralPath "$taskEvidence/$name"})
$files=@($files|Sort-Object FullName -Unique);$entries=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($taskEvidence.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw));try{if($zip.Entries.Count -ne $entries.Count){throw 'Archive count mismatch'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry mismatch'}}}finally{$zip.Dispose()}
$value=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$head;productionSource=$proof.productionSource;workingTree='main; original12 tracked and6 actual untracked WIP retained';scope='Four existing CLI benchmark expectations and complete original-Flow result checks; clarify source-work admission for executable scalar native completion. No runtime/compiler/workload/budget implementation changed.';publication=$publication;graph=(Receipt 'bench-budget.graph');focused=$run;inputsProof=$proof;quality=$quality;format=$fmt;rootCause=[ordered]@{owner='Engine::evaluate_budgeted_scalar_function_site in crates/arcweft-core/src/engine/eval/callable.rs';invariant='Compiled executable completion must fit its whole control-work cost in the current owning dispatch remaining allowance. OneOp and other ineligible contexts keep the ordinary source function frame. No fresh or uncharged work is granted by the backend selection.';expectedVsActual=@(
 @{case='branch';totalCalls=8;jit=4;vm=4;fallbacks=4;nativeBorrowedBytes=96;logs=@('4','16','58','70');stepOps=@(8,8,8,8,8,8,8,7)},
 @{case='scalar';totalCalls=16;jit=15;vm=1;fallbacks=1;nativeBorrowedBytes=240;logs='all16 values4..64';stepOps=@(64,36);nativeCacheHits=15},
 @{case='mixed';totalCalls=40;jit=39;vm=1;fallbacks=1;nativeBorrowedBytes=312;batchCalls=3;batchItems=24;stepOps=@(128,9);logs='all19 values, including every original loop result and three collection lengths'},
 @{case='match';totalCalls=1;jit=1;executedOps=9;stepOps=@(8,1);logs=@('12')}
 );correction='Retain the observed JIT/VM split and exact counters rather than increasing budgets or deleting source work. Verify original final return and exact complete logs, per-dispatch operations, zero diagnostics and Done for all4 cases. Keep all benchmark command options and source fixtures unchanged.'};validationScope='Focused4 tests pass in2.255s under actual CLI reverse closure1, all-target/all-feature/locked.714 skipped are691 unselected nonignored cases and23 ignored. Each case also executes its original Flow through CLI run at the same step/operation budget; these extra executions are not new nextest case IDs. No fresh fullCLI/workspace runtime or Generic151 run is claimed.';baseline=[ordered]@{path='docs/implementation/acceptance-evidence/task-thread-indentation.json';source=$baseline.source;fullCli=[ordered]@{executed=695;passed=666;failed=29};normalPassed=5158;genericAccepted=151;targetedPreviouslyFailedCases=$proof.cases.test;laterFocusedPasses=4;remainingFullRunFailuresNotRerun=25;scope='Preserve the full695 result with29 failures. Four of its failure IDs now pass in the focused run. Do not relabel the earlier run or synthesize a new fullCLI670/25 result. The MCP repeat1PASS remains a separate timing observation, not a general repair.'};probeScope='Original frontier outputs pin exact binary/input hashes under the pending Thread source epoch. The first adapter extraction was invalid; adapter-extraction-correction.json explicitly corrects it and verifies the other inline fixtures. Neither adapter probe is part of these4 accepted conditions.';sourceInputs=$freeze.paths.Count;sourceDrift=0;caseDrift=0;originalWip=[ordered]@{tracked=12;actualUntracked=6;heldPatchSha256=$publication.heldPatchSha256;untrackedHashDrift=0};historyPrefix=[ordered]@{bytes=$before.Length;sha256=(Sha $before);drift=0};raw=[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();entryDrift=0;entries=$entries}}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($value|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$append=@"


## 2026-11-03 CLIベンチ4件のcaller budget・完全結果の照合

Source $head、parent4a72b9a6fdf88656554f455ed5530dea2a486f3d。productionはcdcda93e5aedb446c88167d6079ab0e5ca48d9c1のまま。通常function frameはsource workのcaller allowanceを維持し、native scalar completionは現在のdispatchの残りに本体全control workが収まるときだけ置き換えられる。OneOpや残量不足でVM frameを保持する既存の型付き境界を維持した。元benchmarkの入力、2 inline fixture、2 checked-in fixture、4つの元commandのiterations／warmup／samples／steps／max-ops／backend引数は差分0。旧期待の全件JITや旧operation数を、実際のbudgeted frameでの内訳へ訂正し、runtimeを変更して上限を飛び越えたり単にbudgetを増やすことはしない。

branchは総8呼出しの4JIT／4VM、native借用96bytes、4つの結果logを維持する。scalarは総16の15JIT／1VM・借用240・cache hit15で、64＋36操作の2 dispatchから全16 logとdoneへ到達する。mixedは総40の39JIT／1VM、3 batch／24 items、借用312、128＋9操作で全19 logとdone。matchは1JIT、8＋1の計9操作、log12とdone。追加のCLI run検査は全件で完全な元log・戻り値・予算以内のstep・診断0をassertし、観測を失敗しない件数へ縮める修復ではない。維持仕様のJIT／CLI章へ、backend指定が追加budgetを与えない条件を明記した。

実CLI逆依存1 package、all-target／all-feature／locked、4090入力。既存4 IDが4／4 PASS、2.255秒、714 skippedは691選択外＋23 ignored。各test内の追加Flow実行をnextestの新規case数へ加算しない。CLI check／Clippy、変更fmt、canonical構造gateは終了0、警告は残る。test ownerは9528 LOC、base9443、増加85、埋込test9528、fan-in0／fan-out55。private helperはこの4件だけの元Flowとbudget／結果を照合し、既存のベンチ責任を維持する。構造や公開APIを広げるための分割は行わない。

最新の全件runは前SourceのCLI695件666 PASS／29 FAIL・通常5158 PASS・Generic151 PASSのまま履歴へ保持し、その29失敗中の4 IDが今回focusedでPASSした事実を追記する。残る25 IDの新規実行や合成の全CLI670／25を主張しない。元adapter probeの抽出ミスと訂正も原出力ごと保持し、4件の受入へ転用しない。[元失敗・入力差分0・追加結果assertion・公開full SHA・gate・raw](acceptance-evidence/task-cli-bench-budget.json)。既存履歴先頭$($before.Length) bytes（SHA256 $($value.historyPrefix.sha256)）を保持して追記する。元12 tracked／6 actual untracked WIPのhash差分0。
"@
$appendBytes=[Text.Encoding]::UTF8.GetBytes($append.Replace("`r`n","`n")+"`n");$stream=[IO.File]::Open([IO.Path]::GetFullPath($history),[IO.FileMode]::Append);try{$stream.Write($appendBytes)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));if((Sha $after[0..($before.Length-1)]) -ne $value.historyPrefix.sha256){throw 'Historical prefix changed'}
[ordered]@{source=$head;focusedPassed=4;rawEntries=$entries.Count;rawBytes=$value.raw.bytes;rawSha256=$value.raw.sha256;prefixBytes=$before.Length;prefixSha256=$value.historyPrefix.sha256;prefixDrift=0}|ConvertTo-Json -Compress
