$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/projection-input-context.final-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/projection-input-context.final-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/projection-input-context.final-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1620 tests run: 1614 passed, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1620\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/projection-input-context.final-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1620 -or $terminal.Count -ne 1620 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$failed=@($terminal | Where-Object Result -eq 'FAIL' | ForEach-Object Name | Sort-Object)
$baseline=Get-Content -Raw "$root/original-context-retention-fixed.owner-summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$new=@($terminal | Where-Object Name -Match 'a_completed_projection_input_keeps_its_type_const_and_effect_environment')
if($new.Count -ne 1 -or @($new | Where-Object Result -ne 'PASS').Count){throw 'Owner regressions missing'}
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Source changed'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    $baseText=@(git show "$($pin.Base):$($p.Path)" 2>$null); $baseLines=if($LASTEXITCODE -eq 0){$baseText.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '/tests(?:/|\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=0;SHA256=$p.SHA256;Blob=$p.Blob}
})
$terminal | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/projection-input-context.final-terminal.json"
[ordered]@{Version=1;Base=$pin.Base;Selected=1620;Passed=1614;Failed=6;Skipped=0;IdsEqual=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;SourcePinsVerified=$true;ClippyExit=0;FmtExit=0;Measurements=$measurements;Ownership='Pending results and open projection inputs share the scoped ConstraintOperand through Arc, preserving the exact resolved result owner and request. Completed input types share CompletedGenericContext with their output and expose only ScopedTypeView. Specialization seal and completed equality consume scoped inputs. Raw request input capture uses the actual current frames and original source context before cloning. No separate input context table or shape reconstruction, Cargo edge, public export, unsafe, I/O, version or budget change. Checked frontend value ownership, binding/alias evidence and strict Free authorization remain unfinished.';ReverseEvidence='The crate-private input producer and both concrete consumers were migrated in the same crate. Full Sema covers frontend and API compile consumers. Cargo inputs and the three-mode 22-package reverse closure remain unchanged; 21-consumer results stay pinned to 8b5e375a9c7b3096fe5ed2f65df556a463741a8d, not claimed as rerun. No external wire, public shape or generated artifact change.';Development='Initial production all-target/all-feature check passed (24.76 seconds). The new test initially used Array.length instead of the actual Array.len field and failed to compile with E0559/E0026/E0027; corrected only the fixture field spelling. The next selected run passed all 109 tests (0.897 seconds), with 1487 filter-excluded not run. Final full-owner and quality inputs are pinned separately.'} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$root/projection-input-context.summary.json"
Get-Content "$root/projection-input-context.summary.json" -TotalCount 16
