$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
$paths=@(@(git diff --name-only HEAD -- crates) + @(git ls-files --others --exclude-standard -- crates) | Sort-Object -Unique)
$pin=[ordered]@{Version=1;Base=(git rev-parse HEAD);Paths=@($paths | ForEach-Object {[pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash;Blob=(git hash-object -- $_)}})}
$pin | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$root/projection-input-context.final-input.json"
$steps=@()
function Step($name,$arguments,$output,$log) {
    foreach($p in $pin.Paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256){throw 'Source changed'}}
    $start=Get-Date
    & cargo @arguments 1>"$root/$output" 2>"$root/$log"
    $code=$LASTEXITCODE
    foreach($p in $pin.Paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256){throw 'Source changed'}}
    $script:steps+= [pscustomobject]@{Name=$name;Arguments=$arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;PinsVerified=$true}
    [ordered]@{Version=1;Base=$pin.Base;CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false;Steps=$script:steps} | ConvertTo-Json -Depth 7 | Set-Content -Encoding utf8 "$root/projection-input-context.final-validation.json"
    Write-Output "$name exit=$code"
    if($code -ne 0 -and $name -ne 'owner-run'){throw "$name failed"}
}
Step 'owner-list' @('nextest','list','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--message-format','json') 'projection-input-context.final-owner-list.json' 'projection-input-context.final-owner-list.log'
Step 'owner-run' @('nextest','run','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--no-fail-fast','--message-format','libtest-json-plus') 'projection-input-context.final-owner-results.jsonl' 'projection-input-context.final-owner-run.log'
Step 'clippy' @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features') 'projection-input-context.final-clippy.stdout' 'projection-input-context.final-clippy.log'
Step 'fmt' @('fmt','--all','--','--check') 'projection-input-context.final-fmt.stdout' 'projection-input-context.final-fmt.log'
