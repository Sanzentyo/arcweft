param([ValidateSet('Directed','Wide')][string]$Phase,[string]$Commit)
$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$d=Split-Path -Parent $PSCommandPath
$prefix='lexical-pattern-call.dev02'
function Invoke-Validation {
    param([string]$Name,[string]$Command,[string[]]$Arguments,[int[]]$Allowed=@(0))
    if ($Commit -and (git rev-parse HEAD) -ne $Commit) { throw 'HEAD moved during validation.' }
    Write-Output "Starting $Name"
    $log=Join-Path $d "$prefix-$Name.log"
    $started=Get-Date -Format o
    & $Command @Arguments *> $log
    $exitCode=$LASTEXITCODE
    $summary=@(Select-String -LiteralPath $log -Pattern '^error|^ *Finished|^ *Summary \[' | Select-Object -Last 12 -ExpandProperty Line)
    @{
        version=1;head=(git rev-parse HEAD);command=@($Command)+$Arguments;exit=$exitCode;
        working_tree=@(git status --porcelain=v1 --untracked-files=no);started=$started;ended=(Get-Date -Format o);summary=$summary
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $d "$prefix-$Name.result.json") -Encoding utf8NoBOM
    $summary
    Write-Output "Finished $Name with $exitCode"
    if ($exitCode -notin $Allowed) { throw "$Name exited $exitCode." }
}
$filter='rdeps(=arcweft-lang-sema) | rdeps(=arcweft-compiler)'
$argsNextest=@('-E',$filter,'--no-fail-fast','--no-tests','fail')
if ($Phase -eq 'Directed') {
    Invoke-Validation 'compiler-directed' cargo @(
        'nextest','run','--locked','-p','arcweft-compiler','--test','callable_execution','-E',
        'test(calls_an_effectful_captured_value_from_a_tuple_binding) | test(string_operations_and_captures_survive_each_awbc_step_public_cold_restore) | test(inferred_callback_effect_in_a_tuple_parameter_reaches_the_instance) | test(curried_function_value_retains_independent_callback_effects) | test(named_function_values_replace_mutable_callables) | test(assigning_a_function_with_different_closed_effects_is_rejected)',
        '--no-fail-fast','--no-tests','fail'
    )
} else {
    Invoke-Validation 'dependency-sema' cargo @('tree','--locked','--workspace','--invert','arcweft-lang-sema','--prefix','none','--edges','normal,dev,build','--no-dedupe')
    Invoke-Validation 'dependency-compiler' cargo @('tree','--locked','--workspace','--invert','arcweft-compiler','--prefix','none','--edges','normal,dev,build','--no-dedupe')
    Invoke-Validation 'workspace-check' cargo @('check','--locked','--workspace','--all-targets','--all-features')
    Invoke-Validation 'workspace-clippy' cargo @('clippy','--locked','--workspace','--all-targets','--all-features')
    Invoke-Validation 'reverse-tests' cargo (@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli')+$argsNextest) -Allowed @(0,100)
    Invoke-Validation 'reverse-cli' cargo (@('nextest','run','--locked','-p','arcweft-cli','--lib','--bins')+$argsNextest)
    Invoke-Validation 'reverse-cli-fixtures' cargo (@('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')+$argsNextest)
}

