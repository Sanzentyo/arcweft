param([Parameter(Mandatory)][string]$Commit)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$base = 'e4d0f4afddffcb48cae0497e420969f5a3d85d21'
$ref = 'refs/heads/main'
if ((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $Commit) {
    throw 'Checkout differs from validated source.'
}
git merge-base --is-ancestor $base $Commit
if ($LASTEXITCODE -ne 0) { throw 'Validated source is outside the expected publication base.' }
if (@(git status --porcelain --untracked-files=no -- crates).Count) { throw 'Source paths contain local changes.' }
$paths = @(git diff --name-only $base HEAD)
$expected = @(
    'crates/arcweft-compiler/tests/callable_execution.rs',
    'crates/arcweft-compiler/tests/callable_execution/string_operations.rs',
    'crates/arcweft-compiler/tests/support/execution.rs',
    'crates/arcweft-lang-sema/src/callable/continuation.rs',
    'crates/arcweft-lang-sema/src/callable/resolver.rs',
    'crates/arcweft-lang-sema/src/final_analysis/analyzer/calls.rs',
    'crates/arcweft-lang-sema/src/final_analysis/analyzer/statements.rs',
    'crates/arcweft-lang-sema/src/final_analysis/statement_seal.rs',
    'crates/arcweft-lang-sema/src/final_analysis/tests.rs',
    'docs/01-language/block-scopes.md',
    'docs/01-language/functions-and-pipeline.md'
)
if ($paths.Count -ne $expected.Count -or @(Compare-Object -ReferenceObject $expected -DifferenceObject $paths).Count) {
    throw 'Unexpected source publication paths.'
}
git diff --check $base HEAD
if ($LASTEXITCODE -ne 0) { throw 'Source diff check failed.' }
$remote = git ls-remote --exit-code origin $ref
if ($LASTEXITCODE -ne 0) { throw 'Remote ref lookup failed.' }
$before = $remote.Split()[0]
if ($before -ne $base) { throw 'Remote source base moved.' }
git push origin "HEAD:$ref"
if ($LASTEXITCODE -ne 0) { throw 'Source push failed.' }
$remote = git ls-remote --exit-code origin $ref
if ($LASTEXITCODE -ne 0) { throw 'Published ref lookup failed.' }
$after = $remote.Split()[0]
git fetch --no-tags origin $ref
if ($LASTEXITCODE -ne 0) { throw 'Published source fetch failed.' }
$fetched = git rev-parse FETCH_HEAD
if ($after -ne $Commit -or $fetched -ne $Commit) { throw 'Published commit differs.' }
$blobs = [ordered]@{}
foreach ($path in $paths) {
    $local = git rev-parse "HEAD:$path"
    $published = git rev-parse "FETCH_HEAD:$path"
    if ($LASTEXITCODE -ne 0 -or $published -ne $local) { throw "Published blob differs for $path." }
    $blobs[$path] = $published
}
@{
    version = 1
    base = $before
    source = $Commit
    remote = $after
    fetched = $fetched
    ref = $ref
    blobs = $blobs
    observed_at = Get-Date -Format o
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $root 'lexical-pattern-call.dev03-source-publication.json') -Encoding utf8NoBOM
"Verified $Commit, $($blobs.Count) source blobs."




