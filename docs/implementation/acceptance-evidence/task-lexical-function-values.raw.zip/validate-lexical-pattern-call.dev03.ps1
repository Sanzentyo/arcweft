$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$stem='lexical-pattern-call.dev03'
$source='f0d45f7286847010a1c8a51e8523f1e98994a5ce'
$testPath='crates/arcweft-lang-sema/src/final_analysis/tests.rs'
$env:CARGO_INCREMENTAL='0'
function Validate-Revision {
    $changed=@(git diff --name-only $source)
    if($changed.Count -ne 1 -or $changed[0] -ne $testPath){throw 'Test-only repair no longer has its exact scope.'}
    $blob=git hash-object -- $testPath
    if($LASTEXITCODE -ne 0){throw 'Test file could not be identified.'}
    $blob
}
$testBlob=Validate-Revision
function Invoke-Verification([string]$name,[string]$command,[string[]]$commandArgs){
    if((Validate-Revision) -ne $testBlob){throw 'The test changed before validation.'}
    $log=Join-Path $d "$stem-$name.log"
    $started=Get-Date -Format o
    Write-Output "Starting $name"
    & $command @commandArgs *> $log
    $code=$LASTEXITCODE
    $summary=@(Select-String -LiteralPath $log -Pattern '^error|^ *Finished|^ *Summary \[' | Select-Object -Last 9 -ExpandProperty Line)
    @{
        version=1;product_source=$source;test_path=$testPath;test_blob=$testBlob;checked_head=(git rev-parse HEAD);
        started=$started;finished=(Get-Date -Format o);command=@($command)+$commandArgs;exit=$code;summary=$summary
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $d "$stem-$name.result.json") -Encoding utf8NoBOM
    $summary
    if($code -ne 0 -or (Validate-Revision) -ne $testBlob){throw "$name did not verify the tested bytes."}
    Write-Output "Finished $name"
}
$filter='package(=arcweft-lang-sema) & (test(assignment_semantics_) | test(checked_statement_producer_assignment_row_n16_rejects_hir_owned_mutation) | test(checked_match_assignments_retain_same_typed_field_identity_and_digest))'
Invoke-Verification 'format' rustfmt @('--check','--edition','2024','--config','skip_children=true',$testPath)
Invoke-Verification 'assignment-nextest' cargo @('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli','-E',$filter,'--no-fail-fast','--no-tests','fail')
Invoke-Verification 'sema-clippy' cargo @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features')

