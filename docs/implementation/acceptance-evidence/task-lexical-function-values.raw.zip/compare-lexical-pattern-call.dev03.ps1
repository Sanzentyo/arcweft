$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
function Read-Results([string]$name) {
    $path=Join-Path $d $name
    $rows=[ordered]@{}
    foreach($line in Get-Content -LiteralPath $path){
        if($line -match '^\s*Summary \['){break}
        if($line -match '^\s*(PASS|FAIL|SKIP) \[.*?\]\s+\(\s*\d+/\d+\) (arcweft[-\w]+)(?:::([^ ]+))? (\S+)$'){
            $id='{0}::{1} {2}' -f $Matches[2],$Matches[3],$Matches[4]
            if($rows.Contains($id)){throw ('Duplicate result for '+$id)}
            $rows[$id]=$Matches[1]
        }
    }
    return ,$rows
}
function Differences($before,$after) {
    $keys=@(@($before.Keys)+@($after.Keys) | Sort-Object -Unique)
    foreach($id in $keys){if($before[$id] -ne $after[$id]){@{id=$id;before=$before[$id];after=$after[$id]}}}
}
function Summary($rows) {
    @{total=$rows.Count;pass=@($rows.Values | Where-Object {$_ -eq 'PASS'}).Count;fail=@($rows.Values | Where-Object {$_ -eq 'FAIL'}).Count}
}
$baseline=Read-Results 'contextual-callback-containers.dev09-reverse-tests.log'
$first=Read-Results 'lexical-pattern-call.dev02-reverse-tests.log'
$checked=Read-Results 'lexical-pattern-call.dev03-assignment-nextest.log'
$initialChanges=@(Differences $baseline $first)
$id='arcweft-lang-sema:: final_analysis::tests::assignment_semantics_reject_non_direct_or_non_nominal_places_and_type_mismatch'
$unexpected=@($initialChanges | Where-Object {$_.after -ne 'PASS'})
if($baseline.Count -ne 4336 -or $first.Count -ne 4341 -or $unexpected.Count -ne 1 -or $unexpected[0].id -ne $id -or $unexpected[0].before -ne 'PASS' -or $unexpected[0].after -ne 'FAIL'){
    throw 'The first run must contain exactly the measured stale expectation.'
}
if($checked.Count -ne 3 -or @($checked.Values | Where-Object {$_ -ne 'PASS'}).Count -or $checked[$id] -ne 'PASS'){
    throw 'The final assertion coverage differs.'
}
$repaired=[ordered]@{}
foreach($key in $first.Keys){$repaired[$key]=$first[$key]}
foreach($key in $checked.Keys){
    if(-not $repaired.Contains($key)){throw ('Unexpected test ID '+$key)}
    $repaired[$key]=$checked[$key]
}
$changes=@(Differences $baseline $repaired)
if(@($changes | Where-Object {$_.after -ne 'PASS'}).Count){throw 'An initial change-caused failure remains.'}
@{baseline=(Summary $baseline);initial=(Summary $first);targeted=(Summary $checked);current=(Summary $repaired);initial_changes=$initialChanges;changes=$changes} |
    ConvertTo-Json -Depth 5 | Tee-Object -FilePath (Join-Path $d 'lexical-pattern-call.dev03-reverse-comparison.json')

