param([string]$Iteration,[string]$ExpectedBinary,[switch]$OnlyVm,[string[]]$Selection)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$cases=Get-Content -LiteralPath (Join-Path $d 'lexical-pattern-call-cases.json') -Raw | ConvertFrom-Json -AsHashtable
$exe=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$hash=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
if($ExpectedBinary -and $hash -ne $ExpectedBinary) { throw 'CLI changed before the run.' }
$executors=@('bytecode-vm','aot','awbc-product')
if($OnlyVm) { $executors=@('bytecode-vm') }
$results=@(
    foreach($entry in $cases.GetEnumerator()) {
        if($Selection -and $entry.Key -notin $Selection) { continue }
        foreach($executor in $executors) {
            $case=$entry.Value
            $name=$entry.Key
            $stdout=Join-Path $d "lexical-pattern-call.$Iteration.$name.$executor.stdout.log"
            $stderr=Join-Path $d "lexical-pattern-call.$Iteration.$name.$executor.stderr.log"
            $args=@('run',$case.path,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','256','--json')
            & $exe @args 1> $stdout 2> $stderr
            $exit=$LASTEXITCODE
            $diagnostic=[string](Get-Content -LiteralPath $stderr -Raw)
            $json=$null
            if ((Get-Item -LiteralPath $stdout).Length) { $json=Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json }
            $messages=@()
            if($json -and $json.steps.Count) { $messages=@($json.steps[-1].observations.logs | ForEach-Object message) }
            $sameLogs=(ConvertTo-Json -InputObject @($messages) -Compress) -ceq (ConvertTo-Json -InputObject @($case.logs) -Compress)
            $diagnosticSteps=@($json.steps | Where-Object { $_.stats.diagnostics -gt 0 -or $_.diagnostics.Count -gt 0 -or $_.assertion_failures.Count -gt 0 }).Count
            $maxOps=($json.steps.stats.executed_ops | Measure-Object -Maximum).Maximum
            $ok=$exit -eq 0 -and $json.final_status -ceq 'done Return("42")' -and $sameLogs -and $diagnosticSteps -eq 0 -and $maxOps -eq 1
            if($case.reject){ $ok=$exit -eq 1 -and $null -eq $json -and $diagnostic.Contains("error[$($case.diagnostic)]") }
            @{
                case=$name;expect_reject=[bool]$case.reject;executor=$executor;args=$args;exit=$exit;diagnostic=$diagnostic;
                final_status=$json.final_status;steps=$json.steps.Count;max_ops=$maxOps;diag_steps=$diagnosticSteps;
                input_sha256=(Get-FileHash -LiteralPath $case.path -Algorithm SHA256).Hash.ToLowerInvariant();
                stdout=[IO.Path]::GetFileName($stdout);stderr=[IO.Path]::GetFileName($stderr);logs=$messages;passed=$ok
            }
        }
    }
)
if((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash) { throw 'CLI changed during the run.' }
@{version=1;binary_sha256=$hash;head=(git rev-parse HEAD);source_paths=@(git diff --name-only -- crates);runs=$results;observed_at=(Get-Date -Format o)} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $d "lexical-pattern-call.$Iteration.json") -Encoding utf8NoBOM
$results | ForEach-Object {
    '{0} {1} exit={2} pass={3} {4} {5}' -f $_.case,$_.executor,$_.exit,$_.passed,$_.final_status,(($_.diagnostic -split [Environment]::NewLine)[0])
}

