fn main() {
    let source = r#"
#[pure]
fn increment(item: i64) -> i64 { return item + 1i64 }
#[pure]
pub fn root(values: Result<i64, String>) -> Result<i64, String> { { let mapper: Result<i64, String> -> Result<i64, String> effects {} = map(increment); mapper(values) } }
flow main() -> String { return "unused" }
"#;
    match arcweft_compiler::source::compile_source(source) {
        Ok(_) => println!("Result::Ok map source compiled"),
        Err(error) => {
            eprintln!("{error:?}");
            std::process::exit(1);
        }
    }
}
