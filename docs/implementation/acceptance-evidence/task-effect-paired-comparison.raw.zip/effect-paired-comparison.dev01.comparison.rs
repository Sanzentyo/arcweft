#![allow(dead_code, unused_imports)]
#[path = "effect-paired-comparison.dev01.baseline/effect_row.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/declaration.rs"]
mod declaration;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/membership.rs"]
mod membership;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/set.rs"]
mod set;

use arcweft_id::EffectId;
use std::collections::BTreeMap;

use decision::{DecisionControl, DecisionEncoding, DecisionWork, EffectDecision};
use declaration::EffectDeclarationError;
use membership::{EffectFormula, EffectPredicate, MembershipEncoding};
use set::EffectSet;

macro_rules! meter {
    ($kind:ident, $meter:ident, $work:ty, $control:path, $error:ty) => {
        #[derive(Default)]
        struct $meter { visits: usize, nodes: usize }
        impl $control for $meter {
            type Error = $error;
            fn charge(&mut self, work: $work) -> Result<(), Self::Error> {
                match work {
                    $kind::Visit => self.visits += 1,
                    $kind::Node => self.nodes += 1,
                }
                Ok(())
            }
        }
    };
}
use baseline::DecisionWork as PriorWork;
meter!(PriorWork, Prior, baseline::DecisionWork, baseline::DecisionControl, baseline::EffectDeclarationError);
meter!(DecisionWork, Current, DecisionWork, DecisionControl, EffectDeclarationError);

fn prior_row(labels: &[EffectId], other: Option<usize>, period: usize, meter: &mut Prior) -> baseline::EffectFormula<u8> {
    let default = baseline::EffectDecision::variable(0, &mut Prior::default()).unwrap();
    let alternate = baseline::EffectDecision::variable(1, &mut Prior::default()).unwrap();
    let mut builder = baseline::EffectFormula::builder(default.clone(), meter).unwrap();
    for (index, label) in labels.iter().enumerate() {
        let decision = if other == Some(index) {
            alternate.clone()
        } else if period > 0 && index % period == 0 {
            baseline::EffectDecision::constant(true)
        } else {
            default.clone()
        };
        builder.set(label, decision, meter).unwrap();
    }
    builder.finish()
}

fn current_row(labels: &[EffectId], other: Option<usize>, period: usize, meter: &mut Current) -> EffectFormula<u8> {
    let default = EffectDecision::variable(0, &mut Current::default()).unwrap();
    let alternate = EffectDecision::variable(1, &mut Current::default()).unwrap();
    let mut builder = EffectFormula::builder(default.clone(), meter).unwrap();
    for (index, label) in labels.iter().enumerate() {
        let decision = if other == Some(index) {
            alternate.clone()
        } else if period > 0 && index % period == 0 {
            EffectDecision::constant(true)
        } else {
            default.clone()
        };
        builder.set(label, decision, meter).unwrap();
    }
    builder.finish()
}

fn main() {
    for count in [16, 256, 4096] {
        let labels: Vec<_> = (0..count).map(|index| {
            EffectId::parse(&format!("bench.label{index:04}")).unwrap()
        }).collect();
        for (layout, period) in [("all-default", 0), ("sparse", 127), ("dense", 1)] {
            let mut before = Prior::default();
            let mut after = Current::default();
            let prior = prior_row(&labels, None, period, &mut before);
            let current = current_row(&labels, None, period, &mut after);
            assert_eq!(format!("{prior:?}"), format!("{current:?}"));
            assert_eq!(before.nodes, after.nodes);
            assert!(after.visits < before.visits);
            println!(
                "assembly labels={count} input={layout} overrides={} visits={}->{} nodes={}->{}",
                current.membership().overrides().len(), before.visits, after.visits, before.nodes, after.nodes,
            );
        }
        let prior_empty = baseline::EffectFormula::empty();
        let current_empty = EffectFormula::empty();
        let prior_left = prior_row(&labels, None, 1, &mut Prior::default())
            .subset(&prior_empty, &mut Prior::default()).unwrap();
        let current_left = current_row(&labels, None, 1, &mut Current::default())
            .subset(&current_empty, &mut Current::default()).unwrap();
        for (layout, change) in [("equal", None), ("first-mismatch", Some(0)), ("last-mismatch", Some(count - 1))] {
            let prior_right = prior_row(&labels, change, 1, &mut Prior::default())
                .subset(&prior_empty, &mut Prior::default()).unwrap();
            let current_right = current_row(&labels, change, 1, &mut Current::default())
                .subset(&current_empty, &mut Current::default()).unwrap();
            let mut before = Prior::default();
            let mut after = Current::default();
            let prior_same = prior_left.equal_with(&prior_right, &mut before).unwrap();
            let current_same = current_left.equal_with(&current_right, &mut after).unwrap();
            assert_eq!(prior_same, change.is_none());
            assert_eq!(current_same, current_left == current_right);
            assert_eq!(prior_same, current_same);
            assert_eq!(before.nodes, after.nodes);
            assert!(after.visits < before.visits);
            println!(
                "predicate labels={count} input={layout} equal={current_same} visits={}->{} nodes={}->{}",
                before.visits, after.visits, before.nodes, after.nodes,
            );
        }
    }
}
