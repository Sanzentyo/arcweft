$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\git\arcweft'
$root=$PSScriptRoot
$publication=Get-Content -Raw "$root/original-producer-context.header-publication.json" | ConvertFrom-Json
$validation=Get-Content -Raw "$root/original-producer-context.header-final-validation.json" | ConvertFrom-Json
$listing=Get-Content -Raw "$root/original-producer-context.header-owner-list.json" | ConvertFrom-Json
$wanted=@(foreach ($suite in $listing.'rust-suites'.PSObject.Properties) { foreach ($case in $suite.Value.testcases.PSObject.Properties) { if ($case.Value.'filter-match'.status -eq 'matches') { $suite.Value.'package-name'+'::'+$suite.Value.'binary-name'+'$'+$case.Name } } })
$terminal=@(Get-Content "$root/original-producer-context.header-final-results.jsonl" | ForEach-Object { $event=$_ | ConvertFrom-Json; if ($event.type -eq 'test' -and $event.event -in @('ok','failed')) { [pscustomobject]@{Id=$event.name;Result=$event.event} } })
if ($validation.Source -ne $publication.Source -or $validation.TestsExit -ne 0 -or $validation.ClippyExit -ne 0 -or !$validation.SourcePinsEqual) { throw 'Header validation identity differs' }
if ($wanted.Count -ne 47 -or $terminal.Count -ne 47 -or @($terminal | Where-Object Result -ne 'ok').Count -or @(Compare-Object -CaseSensitive @($wanted | Sort-Object) @($terminal.Id | Sort-Object)).Count -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count) { throw 'Header case coverage differs' }
if (@($terminal | Where-Object Id -Match 'effect_row::prepared::declaration::tests::').Count -ne 3) { throw 'Header regressions missing' }
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-original-effect-declaration-authority.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Frozen header archive already exists' }
$files=@(Get-ChildItem -LiteralPath $root -File | Where-Object Name -Like 'original-producer-context.header-*')
$files+=Get-Item -LiteralPath $PSCommandPath
$entries=@($files | Sort-Object FullName -Unique | ForEach-Object { [pscustomobject]@{Path=$_.Name;Bytes=$_.Length;SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Parent=$publication.Parent;Selected=47;Passed=47;Failed=0;Filtered=1531;NewTests=3;IdsEqual=$true;Duplicates=0;ClippyExit=0;Scope='Only the private declaration-header API and its existing effect/arrow owner tests. The prior 107-target consumer run remains pinned to 9fd25d236a0c1e38731b16bbc753c8a43b12da7a.';Entries=$entries}
$manifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($manifest | ConvertTo-Json -Depth 8))
Add-Type -AssemblyName System.IO.Compression
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite)
try {
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try {
        foreach ($record in $entries) {
            $bytes=[IO.File]::ReadAllBytes((Join-Path $root $record.Path))
            $entry=$zip.CreateEntry($record.Path,[IO.Compression.CompressionLevel]::Optimal)
            $target=$entry.Open()
            try { $target.Write($bytes) } finally { $target.Dispose() }
        }
        $target=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal).Open()
        try { $target.Write($manifestBytes) } finally { $target.Dispose() }
    } finally { $zip.Dispose() }
} finally { $stream.Dispose() }
$read=[IO.Compression.ZipFile]::OpenRead($archivePath)
$raw=0L
try {
    if ($read.Entries.Count -ne $entries.Count+1) { throw 'Header archive count differs' }
    foreach ($entry in $read.Entries) {
        $inputStream=$entry.Open()
        $memory=[IO.MemoryStream]::new()
        try { $inputStream.CopyTo($memory); $bytes=$memory.ToArray() } finally { $inputStream.Dispose(); $memory.Dispose() }
        $expected=if ($entry.FullName -eq 'manifest.json') { [pscustomobject]@{Bytes=$manifestBytes.Length;SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($manifestBytes)).ToLowerInvariant()} } else { @($entries | Where-Object Path -CEQ $entry.FullName)[0] }
        if ($bytes.Length -ne $expected.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $expected.SHA256) { throw 'Header archive readback differs' }
        $raw+=$bytes.Length
    }
} finally { $read.Dispose() }
[ordered]@{Version=1;Source=$publication.Source;Path=$archivePath;Entries=$entries.Count+1;RawBytes=$raw;Bytes=(Get-Item -LiteralPath $archivePath).Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();AllEntriesReadbackVerified=$true} | ConvertTo-Json | Set-Content -Encoding utf8 "$root/original-producer-context.header-archive.json"
Get-Content "$root/original-producer-context.header-archive.json"
