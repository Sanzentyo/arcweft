
$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-retained-result-binder-20261110'
$prior=Join-Path $env:TEMP 'arcweft-promotion-returned-prefix-20261110'
$f=Join-Path $prior 'fixtures'
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$sha=ArcSha $cli
$checks=@(foreach($name in 'returned-prefix-shared-one-execution','returned-prefix-shared-contextual-execution','returned-prefix-shared-execution','returned-prefix-poly-borrow','returned-prefix-poly-owned','returned-prefix-poly-contextual','returned-prefix-poly-contextual-owned'){
    $src=Join-Path $f "$name.arcw"; $out=Join-Path $d "$name.check.json"; $err=Join-Path $d "$name.check.stderr.log"
    & $cli check $src --json > $out 2> $err
    $exit=$LASTEXITCODE
    $report=if((Get-Item -LiteralPath $out).Length){ArcJson $out}else{$null}
    $diagnostic=$report.diagnostics | ForEach-Object {$_.diagnostic} | Select-Object -First 1
    $span=$diagnostic.span
    $spelling=if($span){(Get-Content -Raw -LiteralPath $src).Substring($span.start,$span.end-$span.start)}else{$null}
    [ordered]@{name=$name;exit=$exit;stage=$report.stage;code=$diagnostic.code;span=$spelling;message=$diagnostic.message;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
$execution=@(foreach($name in 'returned-prefix-shared-one-execution','returned-prefix-shared-contextual-execution'){
    $src=Join-Path $f "$name.arcw"
    foreach($tier in 'bytecode-vm','aot','awbc-product'){
        $out=Join-Path $d "$name.$tier.run.json"; $err=Join-Path $d "$name.$tier.run.stderr.log"
        & $cli run $src --runner headless --flow main --executor $tier --mode one-op --max-ops 1 --steps 256 --json > $out 2> $err
        $exit=$LASTEXITCODE
        $report=if((Get-Item -LiteralPath $out).Length){ArcJson $out}else{$null}
        $metrics=@($report.steps|ForEach-Object {$_.stats.executed_ops})|Measure-Object -Maximum -Sum
        $returns=@($report.steps|ForEach-Object {$_.flow_events}|Where-Object {$_ -eq 'return 42'})
        $accepted=!$exit -and $report.executor -eq $tier.Replace('-','_') -and $report.final_status -ceq 'done Return("42")' -and $report.steps.Count -le 256 -and $report.steps[-1].stop_reason -eq 'Done' -and $metrics.Maximum -le 1 -and $returns.Count -eq 1 -and !@($report.steps|Where-Object {$_.diagnostics -or $_.assertion_failures -or $_.task_requests}).Count
        [ordered]@{name=$name;tier=$tier;exit=$exit;executor=$report.executor;steps=$report.steps.Count;maxOps=$metrics.Maximum;executedOps=$metrics.Sum;finalStatus=$report.final_status;accepted=$accepted;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
    }
})
if((ArcSha $cli) -ne $sha){throw 'CLI changed during verification'}
[ordered]@{version=1;cliSha256=$sha;checks=$checks;execution=[ordered]@{runner='headless';mode='one-op';operationLimit=1;stepLimit=256;cases=$execution}}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
$checks|ForEach-Object {[pscustomobject]$_}|Format-Table name,exit,stage,code,span
$execution|ForEach-Object {[pscustomobject]$_}|Format-Table name,tier,exit,accepted,steps,maxOps,finalStatus
$required=@($execution|Where-Object {$_.name -eq 'returned-prefix-shared-one-execution' -and $_.accepted})
if($required.Count -ne 3){exit 1}
exit 0


