$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$d=Join-Path $env:TEMP 'arcweft-retained-result-binder-20261110'
$base='16ca8cf134cc7fa40ae95618410960ccda80ee47'
$paths=@(git diff --name-only $base -- 'crates/**' 'docs/02-runtime/executable-runtime-core.md' Cargo.toml Cargo.lock)
if($paths.Count -ne 4){throw "Unexpected source paths: $($paths -join ', ')"}
function ArcSha($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
$inputs=@($paths | ForEach-Object {[ordered]@{path=$_;sha256=ArcSha $_}})
$published=Get-Content -LiteralPath (Join-Path $d 'source.publication.json') -Raw|ConvertFrom-Json -AsHashtable
if($published.base -cne $base -or (Compare-Object @($published.blobs.path) $paths)){throw 'Published source scope differs'}
foreach($row in $published.blobs){if((ArcSha $row.path) -cne $row.sha256){throw "Published source byte drift $($row.path)"}}
function Test-ArcInputs {
    if(Compare-Object $paths @(git diff --name-only $base -- 'crates/**' 'docs/02-runtime/executable-runtime-core.md' Cargo.toml Cargo.lock)){throw 'Source path drift'}
    foreach($row in $inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source byte drift $($row.path)"}}
}
$graphPath=Join-Path $d 'rdeps.log'
$packages=@(Get-Content -LiteralPath $graphPath|ForEach-Object{if($_ -match '^(arcweft-[\w-]+) v'){$Matches[1]}}|Sort-Object -Unique)
$groups=[ordered]@{

    'core-owner'=@('arcweft-core')
    'bundle-view'=@('arcweft-bundle','arcweft-bundle-assets','arcweft-character-view','arcweft-dialogue','arcweft-save','arcweft-view')
    'runtime-foundation'=@('arcweft-host-adapter','arcweft-lang-jit-cranelift','arcweft-runtime-accelerator','arcweft-runtime-codegen','arcweft-runtime-scheduler')
    'render'=@('arcweft-browser-bench','arcweft-glyphon','arcweft-player-text-input','arcweft-render-text','arcweft-render-wgpu','arcweft-text-layout','arcweft-text-model')
    'project-foundation'=@('arcweft-adapter-desktop','arcweft-launch','arcweft-project','arcweft-resource-manifest','arcweft-resource-model')
    'agent-data'=@('arcweft-agent-policy','arcweft-agent-protocol','arcweft-debug-model','arcweft-debug-sqlite','arcweft-rag')

    'owners'=@('arcweft-lang-sema')
    'runtime-plan'=@('arcweft-runtime-plan')
    'compiler'=@('arcweft-compiler')
    'runtime-host'=@('arcweft-runtime-host')
    'driver-scene'=@('arcweft-runtime-driver','arcweft-player-scene')
    'player-native'=@('arcweft-player-native')
    'player-web'=@('arcweft-player-web')
    'agent-execution'=@('arcweft-agent-repl','arcweft-agent-runner')
    'agent-transport'=@('arcweft-agent-mcp','arcweft-agent-mcp-client','arcweft-adapter-sema')
    'tools-lsp'=@('arcweft-project-loader','arcweft-tooling','arcweft-lsp','arcweft-test')
    'verify'=@('arcweft-verify','arcweft-verify-oxiz','arcweft-verify-z3','arcweft-verify-lsp')
}
$partition=@(foreach($group in $groups.Values){$group})+@('arcweft-cli')
if($partition.Count -ne $packages.Count -or (Compare-Object $partition $packages)){throw 'Run partition does not match resolved Cargo graph'}
$next=@('cargo','nextest','run','--locked','--no-fail-fast','--no-tests','fail')
$stages=[ordered]@{
    'fmt'=@('cargo','fmt','--all','--','--check')
    'workspace-check'=@('cargo','check','--locked','--workspace','--all-targets','--all-features')
    'workspace-clippy'=@('cargo','clippy','--locked','--workspace','--all-targets','--all-features')
    'structure'=@('just','structure-audit-gate')
    'owner-doctests'=@('cargo','test','--locked','--doc','-p','arcweft-core')
    'cli-build'=@('cargo','build','--locked','-p','arcweft-cli','--bin','arcw')
}
$metadataPath=Join-Path $d 'workspace-metadata.json'
$metadata=Get-Content -Raw -LiteralPath $metadataPath|ConvertFrom-Json -AsHashtable
$compiler=@($metadata.packages|Where-Object name -eq 'arcweft-compiler')
if($compiler.Count -ne 1){throw 'Compiler Cargo package count differs'}
$testTargets=@($compiler[0].targets|Where-Object {$_.kind -contains 'test'}|Sort-Object name)
$compilerTargets=@($testTargets.name)
if($compilerTargets.Count -ne 30 -or @($compilerTargets|Sort-Object -Unique).Count -ne $compilerTargets.Count -or @($testTargets|Where-Object {$_.'required-features'.Count}).Count){throw 'Compiler test inventory differs'}
foreach($name in $groups.Keys){
    if($name -ne 'compiler'){
        $stages[$name]=$next+@('--lib','--tests')+@(foreach($pkg in $groups[$name]){'-p';$pkg})
        continue
    }
    $compilerNext=$next+@('-p','arcweft-compiler')
    $stages['compiler-lib']=$compilerNext+@('--lib')
    for($first=0;$first -lt $compilerTargets.Count;$first+=5){
        $last=[Math]::Min($first+4,$compilerTargets.Count-1)
        $stages['compiler-tests-'+($first+1)]=$compilerNext+@(foreach($target in $compilerTargets[$first..$last]){'--test';$target})
    }
}
$stages['cli-library-binaries']=$next+@('-p','arcweft-cli','--lib','--bins')
$stages['cli-integration']=$next+@('-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')
$path=Join-Path $d 'quality.receipt.json'
$receipt=[ordered]@{
    version=1; base=$base; inputs=$inputs; target='x86_64-pc-windows-msvc'; graphSha256=ArcSha $graphPath
    packages=$packages; compilerTargets=$compilerTargets; metadataSha256=ArcSha $metadataPath; active=$null; remaining=$stages.Count; results=@()
}
function Save-ArcReceipt {
    $tmp=Join-Path $d 'quality.receipt.new.json'
    $receipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $tmp -Encoding utf8
    [IO.File]::Move($tmp,$path,$true)
}
Save-ArcReceipt
$failed=0
foreach($name in $stages.Keys){
    Test-ArcInputs
    $command=$stages[$name]
    $log=Join-Path $d "quality-$name.log"
    $receipt.active=$name
    Save-ArcReceipt
    $exe=$command[0]
    $argv=$command[1..($command.Length-1)]
    $reused=@{
        'workspace-check'='workspace-check.log'
        'workspace-clippy'='workspace-clippy.log'
        'core-owner'='core-owner.log'
        'runtime-plan'='runtime-plan.log'
        'owner-doctests'='core-doctests.log'
        'structure'='structure.log'
    }[$name]
    if($reused){
        $previous=Join-Path $d $reused
        $accepted=@{
            'workspace-check'='Finished .+ profile'
            'workspace-clippy'='Finished .+ profile'
            'core-owner'='2401 tests run: 2401 passed'
            'runtime-plan'='165 tests run: 165 passed'
            'owner-doctests'='test result: ok\. 80 passed'
            'structure'='blocking violations: 0'
        }[$name]
        if(!(Test-Path -LiteralPath $previous) -or (Get-Content -Raw -LiteralPath $previous) -notmatch $accepted){throw "The completed source gate $name is absent"}
        Copy-Item -LiteralPath $previous -Destination $log
        $code=0
    }else{
        & $exe @argv *> $log
        $code=$LASTEXITCODE
    }
    Test-ArcInputs
    $summary=@(Select-String -LiteralPath $log -Pattern 'Summary \[|test result:|Finished .+ profile|^ +FAIL \[|Blocking.*:'|ForEach-Object {$_.Line.Trim()}|Select-Object -Last 22)
    $receipt.results+=@([ordered]@{name=$name;command=$command;exitCode=$code;reusedLog=$reused;summary=$summary;logSha256=ArcSha $log})
    if($name -eq 'cli-build' -and !$code){$receipt.cliSha256=ArcSha 'target/debug/arcw.exe'}
    $receipt.active=$null
    $receipt.remaining--
    Save-ArcReceipt
    "$name exit $code"
    $summary
    if($code){$failed++}
}
if($failed){exit 1}






