
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
function Read-SemaResults([string]$name) {
    $index=[ordered]@{}
    foreach($line in Get-Content -LiteralPath (Join-Path $d $name)){
        if($line -match '^\s*Summary \['){break}
        if($line -match '^\s*(PASS|FAIL) \[.*?\]\s+\(\s*\d+/\d+\) arcweft-lang-sema (\S+)$') {
            if($index.Contains($Matches[2])){throw ('Duplicate test '+$Matches[2])}
            $index[$Matches[2]]=$Matches[1]
        }
    }
    return ,$index
}
function Summary($rows) {
    @{executed=$rows.Count;passed=@($rows.Values | Where-Object {$_ -eq 'PASS'}).Count;failed=@($rows.Values | Where-Object {$_ -eq 'FAIL'}).Count}
}
$base=Read-SemaResults 'lexical-pattern-call.dev02-reverse-tests.log'
$updated=Read-SemaResults 'lexical-pattern-call.dev03-assignment-nextest.log'
if($base.Count -ne 2022 -or $updated.Count -ne 3){throw 'Baseline inventory differs.'}
foreach($id in $updated.Keys){
    if(-not $base.Contains($id) -or $updated[$id] -ne 'PASS'){throw 'Baseline retest differs.'}
    $base[$id]=$updated[$id]
}
$final=Read-SemaResults 'constraint-budget.dev03-nextest.log'
$ids=@(@($base.Keys)+@($final.Keys) | Sort-Object -Unique)
$changes=@(
    foreach($id in $ids){
        if($base[$id] -ne $final[$id]){@{id=$id;before=$base[$id];after=$final[$id]}}
    }
)
$result=@{
    version=1; baseline=(Summary $base); final=(Summary $final); changes=$changes;
    prior_broad='f0d45f7286847010a1c8a51e8523f1e98994a5ce';
    prior_test_correction='10794b346efd5a81e831ce6ac478ea17b668ee73';
    observed_at=(Get-Date -Format o)
}
$result | ConvertTo-Json -Depth 5 | Tee-Object -FilePath (Join-Path $d 'constraint-budget.dev03-comparison.json')
if($final.Count -ne 2022 -or @($changes | Where-Object {$_.before -ne 'FAIL' -or $_.after -ne 'PASS'}).Count){
    throw 'Unexpected test change.'
}

