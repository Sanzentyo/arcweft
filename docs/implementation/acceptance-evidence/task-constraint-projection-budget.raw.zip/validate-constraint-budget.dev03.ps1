
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$env:CARGO_INCREMENTAL='0'
$base='ea25a208a53ce71473745a1905f904f070748bcd'
$path='crates/arcweft-lang-sema/src/types/constraints/transaction/operand/projection/tests/bindings.rs'
$blob=git hash-object -- $path
function Invoke-Check([string]$name,[string]$command,[string[]]$commandArgs,[int[]]$allowed=@(0)){
    $changed=@(git diff --name-only)
    if((git rev-parse HEAD) -ne $base -or $changed.Count -ne 1 -or $changed[0] -ne $path -or (git hash-object -- $path) -ne $blob){throw 'Validation source differs.'}
    $log=Join-Path $d "constraint-budget.dev03-$name.log"
    $started=Get-Date -Format o
    "Starting $name"
    & $command @commandArgs *> $log
    $code=$LASTEXITCODE
    $summary=@(Select-String -LiteralPath $log -Pattern '^error|^ *Finished|^ *Summary \[' | Select-Object -Last 12 -ExpandProperty Line)
    @{version=1;base=$base;path=$path;blob=$blob;command=@($command)+$commandArgs;started=$started;finished=(Get-Date -Format o);summary=$summary;exit=$code} |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $d "constraint-budget.dev03-$name.result.json") -Encoding utf8NoBOM
    $summary
    "Finished $name exit $code"
    if($code -notin $allowed){throw "$name failed."}
}
$all=@(git diff --name-only 'ac7512e6551d0024863cb0180dc78660d65536a9' -- '*.rs')
Invoke-Check 'format' rustfmt (@('--check','--edition','2024','--config','skip_children=true')+$all)
Invoke-Check 'nextest' cargo @('nextest','run','--locked','-p','arcweft-lang-sema','--lib','--no-fail-fast','--no-tests','fail') @(0,100)
Invoke-Check 'check' cargo @('check','--locked','-p','arcweft-lang-sema','--all-targets','--all-features')
Invoke-Check 'clippy' cargo @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features')

