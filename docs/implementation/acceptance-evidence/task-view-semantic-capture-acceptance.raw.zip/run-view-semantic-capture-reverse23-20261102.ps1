$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='presentation-view-semantic-capture-reverse23-20261102'
& "$taskTemp/assert-no-arcweft-build.ps1"
if(Test-Path -LiteralPath "$taskTemp/$stem.source-freeze.json"){throw 'Shared epoch exists'}
$previous=Get-Content "$taskTemp/presentation-view-semantic-capture-rejection3-20261102.source-freeze.json" -Raw | ConvertFrom-Json -Depth 30
$freeze=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();implementation=(git rev-parse HEAD).Trim();held=$previous.held;recordedAt=[DateTime]::UtcNow.ToString('o');paths=@(foreach($row in $previous.paths){[ordered]@{path=$row.path;bytes=(Get-Item -LiteralPath $row.path).Length;sha256=(Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant()}})}
$freeze | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath "$taskTemp/$stem.source-freeze.json" -Encoding utf8
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
$rows=[Collections.Generic.List[object]]::new()
$state=[ordered]@{version=1;base=$freeze.base;implementation=$freeze.implementation;status='running';stage='';rows=@();startedAt=[DateTime]::UtcNow.ToString('o')}
function Save-State {$state.rows=$rows.ToArray();$state | ConvertTo-Json -Depth 40 | Set-Content -LiteralPath "$taskTemp/$stem.matrix.json" -Encoding utf8}
function Invoke-Recorded([string]$name,[object[]]$arguments) {
    if(Test-Path -LiteralPath "$taskTemp/$name.log"){throw 'Attempt exists'}
    $state.stage=$name;Save-State
    Assert-Inputs
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> "$taskTemp/$name.log"
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$freeze.base;implementation=$freeze.implementation;command=$arguments;log="$taskTemp/$name.log";exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$taskTemp/$name.json" -Encoding utf8
    return $code
}
foreach($gate in @(
    [pscustomobject]@{name='tree';args=@('tree','--workspace','--invert','arcweft-lang-hir','--all-features','--target','all','--locked')},
    [pscustomobject]@{name='metadata';args=@('metadata','--format-version','1','--all-features','--locked')}
)) {
    $code=Invoke-Recorded "$stem.$($gate.name)" $gate.args
    $rows.Add([ordered]@{gate=$gate.name;exitCode=$code});Save-State
    Write-Output "$($gate.name) exit=$code"
    if($code -ne 0){throw ('Required shared gate failed: '+$gate.name)}
}
$line=[IO.File]::ReadLines("$taskTemp/$stem.metadata.log") | Where-Object {$_.StartsWith('{"packages"')} | Select-Object -Last 1
if(-not $line){throw 'Cargo metadata missing'}
$metadata=$line | ConvertFrom-Json -Depth 100
$workspace=[Collections.Generic.HashSet[string]]::new([string[]]$metadata.workspace_members)
$names=@{};foreach($package in $metadata.packages){$names[$package.id]=$package.name}
$root=@($metadata.packages | Where-Object {$_.name -eq 'arcweft-lang-hir' -and $workspace.Contains($_.id)})
if($root.Count -ne 1){throw 'Actual graph root missing'}
$reverse=[Collections.Generic.HashSet[string]]::new();[void]$reverse.Add($root[0].id)
do {$added=$false;foreach($node in $metadata.resolve.nodes){if(@($node.dependencies | Where-Object {$reverse.Contains($_)}).Count -and $reverse.Add($node.id)){$added=$true}}}while($added)
$packages=@($reverse | Where-Object {$workspace.Contains($_)} | ForEach-Object {$names[$_]} | Sort-Object)
if($packages.Count -ne 23 -or 'arcweft-cli' -notin $packages){throw 'Resolved reverse closure changed; inspect graph'}
[ordered]@{version=1;base=$freeze.base;root=$root[0].id;workspacePackages=$workspace.Count;reversePackages=$packages;count=$packages.Count;sourceInputs=$freeze.paths.Count;selection='actual Cargo resolve transitive reverse closure; all features, target-all tree; complete library/integration and all CLI targets'} | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath "$taskTemp/$stem.graph.json" -Encoding utf8
$groups=@(
    [pscustomobject]@{name='libraries';selection=@('--lib','--tests')+@($packages | Where-Object {$_ -ne 'arcweft-cli'} | ForEach-Object {'-p';$_})},
    [pscustomobject]@{name='cli-unit';selection=@('-p','arcweft-cli','--lib','--bins')},
    [pscustomobject]@{name='cli-integration';selection=@('-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')},
    [pscustomobject]@{name='cli-check';selection=@('-p','arcweft-cli','--test','check')},
    [pscustomobject]@{name='cli-extra';selection=@('-p','arcweft-cli','--test','bracket_numeric_batch','--test','environment_callable_tensor','--test','native_host_contracts')}
)
foreach($group in $groups) {
    $name="$stem.$($group.name)"
    $selection=@($group.selection)+@('--all-features','--locked','-E','rdeps(=arcweft-lang-hir)')
    $catalog=Invoke-Recorded "$name.catalog" (@('nextest','list')+$selection+@('--message-format','json'))
    if($catalog -ne 0){$rows.Add([ordered]@{group=$group.name;catalogExit=$catalog;runtime='not run'});Save-State;continue}
    $line=[IO.File]::ReadLines("$taskTemp/$name.catalog.log") | Where-Object {$_.StartsWith('{"rust-build-meta"')} | Select-Object -Last 1
    if(-not $line){throw 'Nextest catalog JSON missing'}
    $catalogJson=$line | ConvertFrom-Json -Depth 100
    $cases=@(foreach($suite in $catalogJson.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){[pscustomobject]@{package=$suite.Value.'package-name';binary=$suite.Value.'binary-id';test=$case.Name;ignored=$case.Value.ignored;status=$(if($case.Value.ignored){'ignored'}else{$case.Value.'filter-match'.status})}}})
    $inventory=[ordered]@{version=1;name="$name.catalog";all=$cases.Count;matched=@($cases | Where-Object status -eq 'matches').Count;excluded=@($cases | Where-Object status -ne 'matches').Count;rows=$cases}
    if(-not $inventory.matched){throw 'Empty reverse selection'}
    if(@($cases | Where-Object {$_.status -ne 'matches' -and -not $_.ignored}).Count){throw 'Unexpected nonignored reverse exclusions'}
    $inventory | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath "$taskTemp/$name.catalog.inventory.json" -Encoding utf8
    $pins=@(foreach($suite in $catalogJson.'rust-suites'.PSObject.Properties){$path=$suite.Value.'binary-path';[ordered]@{binary=$suite.Value.'binary-id';path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
    $pins | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/$name.binaries-before.json" -Encoding utf8
    $runtime=Invoke-Recorded "$name.runtime" (@('nextest','run')+$selection+@('--no-tests','fail','--no-fail-fast','--status-level','all','--final-status-level','all'))
    if(@($pins | Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Reverse executable drift'}
    if($runtime -in @(0,100)) {
        & "$taskTemp/audit-nextest-final-result.ps1" -Run "$name.runtime" -Catalog "$name.catalog" -Freeze $stem *> "$taskTemp/$name.audit.log"
        $terminal=Get-Content "$taskTemp/$name.runtime.terminal-audit.json" -Raw | ConvertFrom-Json -Depth 30
        $rows.Add([ordered]@{group=$group.name;catalogExit=$catalog;runtimeExit=$runtime;terminal=$terminal})
        Write-Output "$($group.name): $($terminal.passed) passed, $($terminal.failed) failed, $($terminal.skipped) skipped"
    } else {$rows.Add([ordered]@{group=$group.name;catalogExit=$catalog;runtimeExit=$runtime;terminal=$null})}
    Save-State
}
Assert-Inputs
$state.status='terminal';$state.stage='closed';$state.finishedAt=[DateTime]::UtcNow.ToString('o');Save-State
Write-Output 'shared quality and reverse matrix terminal'
