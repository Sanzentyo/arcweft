$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
$stem='presentation-view-semantic-capture-reverse23-20261102'
$prior='presentation-view-final-reverse71-20261102'
$matrix=Get-Content "$taskTemp/$stem.matrix.json" -Raw|ConvertFrom-Json -Depth 50
$graph=Get-Content "$taskTemp/$stem.graph.json" -Raw|ConvertFrom-Json -Depth 30
if($matrix.status -ne 'terminal' -or $graph.count -ne 23){throw 'Reverse run not terminal'}
$groups=@('libraries','cli-unit','cli-integration','cli-check','cli-extra')
$selected=[Collections.Generic.List[object]]::new()
$oldSelected=[Collections.Generic.List[object]]::new()
$failures=[Collections.Generic.List[object]]::new()
$results=[Collections.Generic.List[object]]::new()
$cliBinaries=[Collections.Generic.List[string]]::new()
foreach($group in $groups){
    $catalog=Get-Content "$taskTemp/$stem.$group.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 30
    $terminal=Get-Content "$taskTemp/$stem.$group.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 35
    if($terminal.catalogCaseDrift -or $terminal.sourceDrift -or $terminal.actualExitCode -notin @(0,100)){throw "Invalid terminal: $group"}
    $matches=@($catalog.rows|Where-Object status -eq 'matches')
    if($matches.Count -ne $terminal.executed){throw "Executed selection differs: $group"}
    foreach($row in $matches){$selected.Add($row)}
    foreach($row in $terminal.failureSet){$failures.Add($row)}
    if($group -like 'cli-*'){
        $line=[IO.File]::ReadLines("$taskTemp/$stem.$group.catalog.log")|Where-Object {$_.StartsWith('{"rust-build-meta"')}|Select-Object -Last 1
        $suiteJson=$line|ConvertFrom-Json -Depth 100
        foreach($suite in $suiteJson.'rust-suites'.PSObject.Properties){$cliBinaries.Add($suite.Value.'binary-id')}
    }
    $old=Get-Content "$taskTemp/$prior.$group.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 30
    foreach($row in @($old.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $graph.reversePackages})){$oldSelected.Add($row)}
    $results.Add([ordered]@{group=$group;passed=$terminal.passed;failed=$terminal.failed;ignored=@($catalog.rows|Where-Object ignored).Count;executed=$terminal.executed;exitCode=$terminal.actualExitCode;sourceInputs=$terminal.sourceInputs;sourceDrift=0;caseDrift=0})
}
function Key($row){return $row.binary+'|'+$row.test}
$keys=@($selected|ForEach-Object {Key $_})
if(@($keys|Sort-Object -Unique).Count -ne $keys.Count){throw 'Duplicate selected cases'}
$oldKeys=@($oldSelected|ForEach-Object {Key $_}|Sort-Object -Unique)
$missing=@($oldKeys|Where-Object {$_ -notin $keys})
$added=@($keys|Where-Object {$_ -notin $oldKeys})
if($missing.Count){throw 'Previously selected reverse cases are missing'}
$runtimePackages=@($selected.package|Sort-Object -Unique)
$compileOnly=@($graph.reversePackages|Where-Object {$_ -notin $runtimePackages})
$oldCli=Get-Content "$taskTemp/$prior.cli-check.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 25
$oldFailed=@($oldCli.failureSet|ForEach-Object {Key $_})
$cliFailures=@($failures|Where-Object {$_.binary -like 'arcweft-cli*'}|ForEach-Object {Key $_})
$cliKeys=@($selected|Where-Object package -eq 'arcweft-cli'|ForEach-Object {Key $_})
$comparison=[ordered]@{priorSource=$oldCli.base;common=@($oldFailed|Where-Object {$_ -in $cliFailures});new=@($cliFailures|Where-Object {$_ -notin $oldFailed});resolved=@($oldFailed|Where-Object {$_ -in $cliKeys -and $_ -notin $cliFailures});unselected=@($oldFailed|Where-Object {$_ -notin $cliKeys});identityEqualityDoesNotProveCauseEquality=$true}
$line=[IO.File]::ReadLines("$taskTemp/$stem.metadata.log")|Where-Object {$_.StartsWith('{"packages"')}|Select-Object -Last 1
$metadata=$line|ConvertFrom-Json -Depth 100
$cli=@($metadata.packages|Where-Object name -eq 'arcweft-cli')[0]
$declared=@($cli.targets|Where-Object {$_.test -and (@($_.kind|Where-Object {$_ -in @('lib','bin','test')}).Count)})
$targetBinaries=@($declared|ForEach-Object {if($_.kind -contains 'lib'){'arcweft-cli'}elseif($_.kind -contains 'bin'){'arcweft-cli::bin/'+$_.name}else{'arcweft-cli::'+$_.name}})
$actualBinaries=@($cliBinaries|Sort-Object -Unique)
$targetDiff=@(Compare-Object $targetBinaries $actualBinaries)
if($targetDiff.Count){$targetDiff|ConvertTo-Json|Write-Output;throw 'CLI declared targets differ'}
$audit=[ordered]@{version=1;source=$matrix.base;graphPackages=$graph.count;actualRuntimePackages=$runtimePackages.Count;compileOnlyPackages=$compileOnly;uniqueSelected=$keys.Count;duplicateSelection=0;groups=$results.ToArray();priorSelected=$oldKeys.Count;newCaseCount=$added.Count;newCases=$added;missingPriorCases=$missing;failures=$failures.ToArray();cliUnique=$cliKeys.Count;cliDeclaredTargets=$declared;cliTargetCount=$declared.Count;cliTargetDrift=0;cliComparison=$comparison;recordedAt=[DateTime]::UtcNow.ToString('o')}
$audit|ConvertTo-Json -Depth 40|Set-Content "$taskTemp/$stem.complete-audit.json" -Encoding utf8
[pscustomobject]@{source=$matrix.base;packages=$graph.count;runtimePackages=$runtimePackages.Count;compileOnly=$compileOnly.Count;unique=$keys.Count;newCases=$added.Count;missing=$missing.Count;cliTargets=$declared.Count;cliFailures=$cliFailures.Count;newCliFailures=$comparison.new.Count;resolved=$comparison.resolved.Count}|ConvertTo-Json -Compress
