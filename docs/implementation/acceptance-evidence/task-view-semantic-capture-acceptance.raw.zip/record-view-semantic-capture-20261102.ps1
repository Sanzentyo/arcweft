$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='task-view-semantic-capture-acceptance'
$reverse='presentation-view-semantic-capture-reverse23-20261102'
$publication=Get-Content "$taskTemp/checkpoint-view-semantic-capture.verified.json" -Raw|ConvertFrom-Json -Depth 25
$source=$publication.commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source head changed'}
$audit=Get-Content "$taskTemp/$reverse.complete-audit.json" -Raw|ConvertFrom-Json -Depth 60
if($audit.source -ne $source){throw 'Audit source differs'}
$libCatalog=Get-Content "$taskTemp/$reverse.libraries.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 30
$ownerLibraries=@($libCatalog.rows|Where-Object {$_.status -eq 'matches' -and $_.binary -in @('arcweft-lang-hir','arcweft-lang-sema','arcweft-runtime-plan','arcweft-compiler')})
$viewCases=@($libCatalog.rows|Where-Object {$_.status -eq 'matches' -and $_.binary -eq 'arcweft-compiler::callable_execution' -and $_.test -like 'presentation_view_values::*'})
if($viewCases.Count -ne 36){throw 'Source View case inventory differs'}
$before=Get-Content "$taskTemp/view-semantic-capture.docs-before.json" -Raw|ConvertFrom-Json
$output="docs/implementation/acceptance-evidence/$stem.json"
$zipPath="docs/implementation/acceptance-evidence/$stem.raw.zip"
if((Test-Path $output) -or (Test-Path $zipPath)){throw 'Immutable evidence exists'}
$paths=@(rg --files $taskTemp -g 'presentation-view-semantic-capture-*')
$paths+=@(rg --files $taskTemp -g 'capture-inference-*.json' -g 'capture-inference-*.log')
foreach($probeRoot in @('capture-inference-probe-20261102','capture-inference-probe-retry3-20261102','capture-inference-probe-retry4-20261102')){$paths+=@(rg --files (Join-Path $taskTemp $probeRoot) -g '*.arcw' -g arcw.toml)}
$paths+=@(rg --files "$taskTemp/presentation-view-semantic-capture-quality-20261102.structure-report")
$paths+=@('run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','run-view-semantic-capture-quality-20261102.ps1','run-view-semantic-capture-reverse23-20261102.ps1','audit-view-semantic-capture-reverse23-20261102.ps1','checkpoint-view-semantic-capture.prepared.json','checkpoint-view-semantic-capture.verified.json','view-semantic-capture.docs-before.json','record-view-semantic-capture-20261102.ps1')|ForEach-Object {Join-Path $taskTemp $_}
$paths=@($paths|Sort-Object -Unique)
$manifest=@(foreach($path in $paths){[ordered]@{path=[IO.Path]::GetRelativePath($taskTemp,$path).Replace('\','/');bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path $PWD $zipPath),[IO.Compression.ZipArchiveMode]::Create)
try{
    for($index=0;$index -lt $paths.Count;$index++){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$paths[$index],$manifest[$index].path,[IO.Compression.CompressionLevel]::Optimal)}
    $entry=$zip.CreateEntry('manifest.json');$writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false));try{$writer.Write(($manifest|ConvertTo-Json -Depth 8))}finally{$writer.Dispose()}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path $PWD $zipPath))
try{
    foreach($row in $manifest){$entry=$zip.GetEntry($row.path);if($null -eq $entry -or $entry.Length -ne $row.bytes){throw 'Archive entry missing'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry drift'}}
    $entryCount=$zip.Entries.Count
}finally{$zip.Dispose()}
function Read-Json([string]$name){Get-Content "$taskTemp/$name" -Raw|ConvertFrom-Json -Depth 60}
$record=[ordered]@{
    version=1;source=$source;publication=$publication;recordedAt=[DateTime]::UtcNow.ToString('o')
    boundary='Source View aliases captured by ordinary and nested closures; semantic captures erased, runtime data captures retain one owning type projection'
    model=@('HIR includes Capture in its common value-type owner algebra. Sema seals semantic capture proof under the exact executable reachability; the full source capture inventory is retained.','Global and closed RuntimePlan facts own capture data in the existing type projection. The replaced separate capture catalogs and dedicated visitors are deleted.','Runtime closure ABI rows share the exact Arc-owned checked capture in that projection; an independently copied capture cannot replace the accepted authority.','Sema removes data-free captures before assigning runtime ABI ordinals. Semantic tokens allocate no Core value, frame, local slot or capture slot; actual data captures retain source order.')
    sourceViewCases=[ordered]@{previousAccepted=28;added=8;totalAccepted=36;programInvocation=12;ordinaryFlow=24;conditions=@('Alias-only closure capture','Semantic capture before and after real runtime data','Nested closure semantic capture');closureParameterEvidence='The newly accepted closure fixtures explicitly annotate their String parameters';backends=@('Native','canonical decoded AWBC');maxOps=1;maxTicks=256;publicSaveOwnedRestore='Every AWBC product step; existing bounds unchanged'}
    initialOwnerLibraries=(Read-Json 'presentation-view-semantic-capture-libraries1-20261102.runtime.terminal-audit.json')
    finalOwnerLibraries=[ordered]@{selected=$ownerLibraries.Count;source=$source;featureUnion='Full 23-package HIR reverse library/integration group';passed=$ownerLibraries.Count;proof='All 4322 selected library/integration cases passed in the fresh final run'}
    finalRejection=(Read-Json 'presentation-view-semantic-capture-rejection3-20261102.runtime.terminal-audit.json')
    finalIntegrations=(Read-Json 'presentation-view-semantic-capture-integrations2-20261102.runtime.terminal-audit.json')
    reverse=$audit
    followupCompileProbes=[ordered]@{initialUsage=(Read-Json 'capture-inference-probes-20261102.json');manifestRetry=(Read-Json 'capture-inference-probes-retry2-20261102.json');semanticProbes=(Read-Json 'capture-inference-probes-retry3-20261102.json');contextualProbes=(Read-Json 'capture-inference-probes-retry4-20261102.json');scope='Isolated temp packages checked with the already-built CLI, with executable SHA256 before/after. Not Native/AWBC execution acceptance. Initial CLI argument misuse and missing top-level declaration newlines are retained as fixture failures. Unannotated View/function closures both reach final-type-unavailable diagnostics. The direct ViewValue annotation probe fails nominal resolution; no public spelling contract is inferred. Expected String-to-i64 and generic callback View construction both compile.'}
    quality=[ordered]@{check=(Read-Json 'presentation-view-semantic-capture-quality-check-20261102.json');clippy=(Read-Json 'presentation-view-semantic-capture-quality-clippy-20261102.json');format=(Read-Json 'presentation-view-semantic-capture-format1-20261102.json');structure=(Read-Json 'presentation-view-semantic-capture-quality-structure-20261102.json');structureSummary=[ordered]@{files=3302;rustFiles=3172;physicalRustLoc=1791520;workspacePackages=97;reviewTriggers=385;blocking=0};warnings='Existing compiler/Clippy warnings remain'}
    failuresRetained=@('The unannotated initial closure probe failed Sema ExpressionTypeUnavailable; it is not claimed accepted by the typed-parameter fixtures.','The annotated baseline probe at 493163e5c57ce32c85d62594d30bd1d82b87443a failed runtime type projection of CompileTimeCallable<View>.','The first migrated owner run kept all 28 existing cases passing and failed the 6 new capture conditions at the final closure/HIR validation boundary. After distinguishing source and runtime captures it passed 34/34.','Early compile checks failed during API migration, then check3 succeeded. Raw logs are retained.','Two new rejection-test fixtures selected no runtime capture in their helper inventory; the test now uses the actual source HIR capture identity and passes. Production rejection was retained.','The first five-target selection was stopped before runtime by an incorrect expected count of 300. Its actual catalog contained 310 cases; the unchanged complete selection subsequently passed 310/310.')
    validationScope='Initial 2621/2621 owner evidence predates the final global malformed-capture guard and visitor deletion. Final rejection, 310 integrations, workspace gates and the full 23-package reverse run use the final inputs. Each original source/feature union remains separately recorded.'
    ownershipReview='Capture belongs to HIR identity and Sema projection classification; RuntimePlan owns its checked runtime shape and lexical origin. The ABI references that authority rather than maintaining a second owned normalized type. Existing large-file ownership review triggers remain nonblocking; no unsafe, dependency, version, runtime budget or assertion relaxation was introduced.'
    limits=@('Reactive defaults, Source-to-renderer/driver integration and actual Native/Web image parity remain separately bounded current-status items.','No blanket acceptance of unannotated standalone closure inference or every possible capture/propagation combination is claimed.','CLI failure identities are compared with the preceding actual run; identity equality does not establish cause equality.','Tests include the preserved original 14 tracked WIP changes; a clean public checkout is not claimed to be the exact tested input.')
    held=[ordered]@{tracked=14;patchSha256=$publication.heldPatchSha256;actualUntracked=6}
    raw=[ordered]@{path="$stem.raw.zip";entryCount=$entryCount;payloadEntries=$manifest.Count;bytes=(Get-Item $zipPath).Length;sha256=(Get-FileHash $zipPath).Hash.ToLowerInvariant();entryDrift=0}
}
$record|ConvertTo-Json -Depth 80|Set-Content $output -Encoding utf8
[ordered]@{source=$source;rawEntries=$entryCount;rawBytes=$record.raw.bytes;rawSha256=$record.raw.sha256}|ConvertTo-Json -Compress
