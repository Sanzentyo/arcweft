$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$base='5f3aac31eb92750c07f9ce249c0ac319e7f75515'
if ((git rev-parse HEAD).Trim() -ne $base) { throw 'Frozen build head changed' }
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$probe=Join-Path $t 'awbc-nested-reexport-baseline-20261106'
if (Test-Path -LiteralPath $probe) { throw 'Preserve original probe' }
$null=New-Item -ItemType Directory -Path $probe
$src='crates/arcweft-compiler/tests/evaluated_effects.rs'
$source=[IO.File]::ReadAllText((Resolve-Path -LiteralPath $src))
$freeze=Get-Content -LiteralPath "$t/awbc-nested-look-reverse-noncli-20261106.source-freeze.json" -Raw | ConvertFrom-Json
$sourceHash=(Get-FileHash -LiteralPath $src).Hash.ToLowerInvariant()
if ($sourceHash -ne ($freeze.paths | Where-Object path -eq $src).sha256) { throw 'Compiler fixture drift' }
$root=(Resolve-Path -LiteralPath 'crates/arcweft-compiler/tests').Path.Replace([char]92,[char]47)
$source=$source.Replace('#[path = "evaluated_effects/', ('#[path = "'+$root+'/evaluated_effects/'))
$source=$source.Replace('#[path = "support/', ('#[path = "'+$root+'/support/'))
$from=@"
            let actor = alice()[Inner[p]] with {
                let lease = alice.stage.acquire(scope=line)
                out lease
            }
"@ -replace '\r?\n', ([string][char]10)
$to=@"
            let actor = alice()[Middle[p]] with {
                let received = alice()[Inner[p]] with {
                    let lease = alice.stage.acquire(scope=line)
                    out lease
                }
                out received
            }
"@ -replace '\r?\n', ([string][char]10)
$source=$source -replace '\r?\n', ([string][char]10)
if ([regex]::Matches($source,[regex]::Escape($from)).Count -ne 1) { throw 'Nested fixture changed' }
$source=$source.Replace($from,$to)
$source=$source.Replace('let [inner, outer] = lines.as_slice()', 'let [inner, middle, outer] = lines.as_slice()')
$source=$source.Replace('assert_ne!(inner, outer);', 'assert_ne!(inner, middle); assert_ne!(inner, outer); assert_ne!(middle, outer);')
$source=$source.Replace('native_nested_line_handle_moves_into_the_receiving_activation','native_nested_line_handle_reexports_from_receiving_activation')
$source=$source.Replace('decoded_awbc_nested_line_handle_moves_through_save','decoded_awbc_nested_line_handle_reexports_through_save')
$probeSrc=Join-Path $probe 'reexport.rs'
[IO.File]::WriteAllText($probeSrc,$source,[Text.UTF8Encoding]::new($false))
$fpRoot=(Resolve-Path -LiteralPath 'target/debug/.fingerprint').Path
$depsRoot=(Resolve-Path -LiteralPath 'target/debug/deps').Path
$input=Join-Path $fpRoot 'arcweft-compiler-b1b330338c2818fd/test-integration-test-evaluated_effects.json'
$inputHash=(Get-FileHash -LiteralPath $input).Hash.ToLowerInvariant()
$test=Get-Content -LiteralPath $input -Raw | ConvertFrom-Json
$links=Get-ChildItem -LiteralPath $fpRoot -Directory
$required=@([regex]::Matches($source, '(?m)^use (arcweft_\w+)') | ForEach-Object {$_.Groups[1].Value} | Sort-Object -Unique)
$externs=@(foreach ($dep in $test.deps) {
    $name=$dep[1]
    $fingerprint=[Convert]::ToHexString([BitConverter]::GetBytes([uint64]$dep[3])).ToLowerInvariant()
    $markers=@(foreach ($dir in $links) {
        $marker=Join-Path $dir.FullName "lib-$name"
        if ((Test-Path -LiteralPath $marker) -and (Get-Content -LiteralPath $marker -Raw).Trim() -eq $fingerprint) { $dir }
    })
    if ($markers.Count -ne 1) { throw "Dependency fingerprint match count for $name is $($markers.Count)" }
    $hash=($markers[0].Name -split '-')[-1]
    $files=@(Get-Item -ErrorAction SilentlyContinue -LiteralPath (Join-Path $depsRoot "lib$name-$hash.rlib"), (Join-Path $depsRoot "$name-$hash.dll"))
    if ($files.Count -ne 1) { throw "Cargo binary missing or ambiguous for $name" }
    [ordered]@{name=$name;fingerprint=$fingerprint;path=$files[0].FullName;sha256=(Get-FileHash -LiteralPath $files[0].FullName).Hash.ToLowerInvariant()}
})
if (@($required | Where-Object {$_ -notin $externs.name}).Count) { throw 'Required extern not recorded' }
$native=@(Get-ChildItem -LiteralPath 'target/debug/build' -Directory | ForEach-Object {
    $dir=Join-Path $_.FullName 'out'
    if ((Test-Path -LiteralPath $dir) -and @(Get-ChildItem -LiteralPath $dir -Filter '*.lib' -File).Count) { $dir }
})
$rustc=(rustup which rustc).Trim()
$exe=Join-Path $probe 'reexport.exe'
$args=@('--crate-name','arcweft_nested_reexport_probe','--edition=2024','--test','--color','never','-C','debuginfo=0','-L',"dependency=$depsRoot",'-o',$exe)
foreach ($path in $native) { $args+=@('-L',"native=$path") }
foreach ($ext in $externs) { $args+=@('--extern',($ext.name+'='+$ext.path)) }
$args+=@($probeSrc)
$PSNativeCommandUseErrorActionPreference=$false
$env:CARGO_MANIFEST_DIR=(Resolve-Path -LiteralPath 'crates/arcweft-compiler').Path
& $rustc @args > "$probe/build.stdout.log" 2> "$probe/build.stderr.log"
$build=$LASTEXITCODE
if ($build -ne 0) { Get-Content -LiteralPath "$probe/build.stderr.log" -Tail 35; exit $build }
$runs=@(foreach ($name in @('native_nested_line_handle_reexports_from_receiving_activation','decoded_awbc_nested_line_handle_reexports_through_save')) {
    & $exe --exact $name --nocapture > "$probe/$name.stdout.log" 2> "$probe/$name.stderr.log"
    $code=$LASTEXITCODE
    [ordered]@{name=$name;exitCode=$code;stdoutSha256=(Get-FileHash -LiteralPath "$probe/$name.stdout.log").Hash.ToLowerInvariant();stderrSha256=(Get-FileHash -LiteralPath "$probe/$name.stderr.log").Hash.ToLowerInvariant()}
})
if ((git rev-parse HEAD).Trim() -ne $base -or (Get-FileHash -LiteralPath $input).Hash.ToLowerInvariant() -ne $inputHash -or (Get-FileHash -LiteralPath $src).Hash.ToLowerInvariant() -ne $sourceHash) { throw 'Probe inputs changed' }
foreach ($ext in $externs) { if ((Get-FileHash -LiteralPath $ext.path).Hash.ToLowerInvariant() -ne $ext.sha256) { throw ('Cargo artifact changed: '+$ext.name) } }
[ordered]@{version=1;source='64829f5d62302e2d658e88494655c7cef2cc96aa';head=$base;cargoTestFingerprint=$inputHash;repositoryFixtureSha256=$sourceHash;probeSourceSha256=(Get-FileHash -LiteralPath $probeSrc).Hash.ToLowerInvariant();binarySha256=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant();compileArgs=$args;externs=$externs;runs=$runs} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath "$probe/receipt.json" -Encoding utf8
foreach ($run in $runs) {
    "$($run.name) exit=$($run.exitCode)"
    Get-Content -LiteralPath "$probe/$($run.name).stderr.log" -Tail 10
}