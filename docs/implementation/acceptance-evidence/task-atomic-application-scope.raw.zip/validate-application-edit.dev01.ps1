param([ValidateSet('Owner','Reverse')][string]$Phase)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$env:CARGO_INCREMENTAL='0'
$env:CARGO_TERM_COLOR='never'
$env:NO_COLOR='1'
$base='043d800a54839b4b10aba0334b16d3da9f66c2c5'
$paths = @(
    'crates/arcweft-lang-sema/src/types/constraints/application/effect_functions_tests.rs',
    'crates/arcweft-lang-sema/src/types/constraints/context.rs',
    'crates/arcweft-lang-sema/src/types/constraints/transaction.rs',
    'crates/arcweft-lang-sema/src/types/constraints/transaction/operand/function_scheme.rs'
)
function Get-ValidationBlobs {
    if((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $base){throw 'Unpinned branch or base.'}
    $changed=@(git diff --name-only $base --)
    if($changed.Count -ne $paths.Count -or @(Compare-Object $paths $changed).Count){throw 'Unexpected validation paths.'}
    $blobs=[ordered]@{}
    foreach($path in $paths){$blobs[$path]=git hash-object --path=$path -- $path}
    $blobs
}
$initial=Get-ValidationBlobs
function Invoke-Validation {
    param([string]$Name,[string]$Command,[string[]]$Arguments,[int[]]$Allowed=@(0))
    $atStart=Get-ValidationBlobs
    foreach($path in $paths){if($initial[$path] -ne $atStart[$path]){throw "Changed validation blob $path."}}
    $log=Join-Path $d "application-edit.dev01-$Name.log"
    $started=Get-Date -Format o
    "Starting $Name"
    & $Command @Arguments *> $log
    $code=$LASTEXITCODE
    $summary=@(Select-String -LiteralPath $log -Pattern '^error|^ *Finished|^ *Summary \[' | Select-Object -Last 15 -ExpandProperty Line)
    $atEnd=Get-ValidationBlobs
    foreach($path in $paths){if($initial[$path] -ne $atEnd[$path]){throw "Changed validation blob $path."}}
    [ordered]@{version=1;base=$base;blobs=$initial;command=@($Command)+$Arguments;exit=$code;started=$started;finished=(Get-Date -Format o);summary=$summary} |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $d "application-edit.dev01-$Name.result.json") -Encoding utf8NoBOM
    $summary
    "Finished $Name with $code"
    if($code -notin $Allowed){throw "$Name exited $code."}
}
$common=@('--no-fail-fast','--no-tests','fail')
if($Phase -eq 'Owner'){
    Invoke-Validation 'format' rustfmt (@('--check','--edition','2024','--config','skip_children=true')+$paths)
    Invoke-Validation 'sema' cargo (@('nextest','run','--locked','-p','arcweft-lang-sema','--lib')+$common) -Allowed @(0,100)
} else {
    $filter=@('-E','rdeps(=arcweft-lang-sema)')+$common
    Invoke-Validation 'dependency-sema' cargo @('tree','--locked','--workspace','--invert','arcweft-lang-sema','--prefix','none','--edges','normal,dev,build','--no-dedupe')
    Invoke-Validation 'workspace-check' cargo @('check','--locked','--workspace','--all-targets','--all-features')
    Invoke-Validation 'workspace-clippy' cargo @('clippy','--locked','--workspace','--all-targets','--all-features')
    Invoke-Validation 'reverse' cargo (@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli')+$filter) -Allowed @(0,100)
    Invoke-Validation 'cli' cargo (@('nextest','run','--locked','-p','arcweft-cli','--lib','--bins')+$filter) -Allowed @(0,100)
    Invoke-Validation 'cli-fixtures' cargo (@('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')+$filter) -Allowed @(0,100)
}


