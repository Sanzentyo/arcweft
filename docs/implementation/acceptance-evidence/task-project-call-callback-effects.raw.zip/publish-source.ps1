$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$pin=Get-Content -LiteralPath (Join-Path $d 'source.final.local.json') -Raw | ConvertFrom-Json
$quality=Get-Content -LiteralPath (Join-Path $d 'quality-receipt.json') -Raw | ConvertFrom-Json
$structure=Get-Content -LiteralPath (Join-Path $d 'structure-final-receipt.json') -Raw | ConvertFrom-Json
$cli=Get-Content -LiteralPath (Join-Path $d 'cli-receipt.json') -Raw | ConvertFrom-Json
$split=Get-Content -LiteralPath (Join-Path $d 'reverse-split-receipt.json') -Raw | ConvertFrom-Json
$required=@('format','focused-core','cli-build','reverse-dependencies','cli-unit-binary','cli-integration','workspace-check','workspace-clippy','wasm-check','doc-tests')
if ($quality.source -cne $pin.source -or (Compare-Object @($quality.results.name) $required) -or @($quality.results | Where-Object { $_.name -cne 'reverse-dependencies' -and $_.exit -ne 0 }).Count) { throw 'Pinned quality checks incomplete' }
$ignored=Get-Content -LiteralPath (Join-Path $d 'render-wgpu-ignored-receipt.json') -Raw | ConvertFrom-Json
$empty=$split.results | Where-Object name -ceq 'arcweft-render-wgpu-integration-4'
if ($ignored.source -cne $pin.source -or $ignored.name -cne $empty.name -or $ignored.exit -ne 0 -or
    $empty.exit -ne 4 -or $empty.totals.run -ne 0 -or $empty.totals.skip -ne 3 -or $ignored.cases.Count -ne 3 -or
    @($ignored.cases | Where-Object {!$_.ignored}).Count) { throw 'The ignored-only GPU slice is unproven' }
if ($split.source -cne $pin.source -or !$split.finished -or $split.packages.Count -ne 51 -or $split.results.Count -ne $split.planned -or @($split.results | Where-Object { $_.name -cne $ignored.name -and $_.exit -ne 0 }).Count) { throw 'Pinned split dependency checks incomplete' }
if ($structure.source -cne $pin.source -or $structure.exit -ne 0) { throw 'Pinned structural check failed' }
if ($cli.source -cne $pin.source -or $cli.executions.Count -ne 10 -or @($cli.executions | Where-Object {!$_.accepted}).Count -or $cli.checks[0].exit -ne 1 -or $cli.checks[0].stage -cne 'type-check') { throw 'Pinned CLI evidence incomplete' }
if ((git rev-parse HEAD) -cne $pin.source -or (git branch --show-current) -cne 'main' -or (git diff --name-only) -or (git diff --cached --name-only)) { throw 'Unexpected worktree changes' }
function RemoteMain {
    $line=git ls-remote --exit-code origin refs/heads/main
    if ($LASTEXITCODE -ne 0) { throw 'Remote lookup failed' }
    ($line -split '\s+')[0]
}
if ((RemoteMain) -cne $pin.parent) { throw 'Remote base moved' }
git push origin HEAD:refs/heads/main
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
git fetch origin main
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if ((RemoteMain) -cne $pin.source -or (git rev-parse 'origin/main^{tree}') -cne $pin.tree) { throw 'Remote source or tree mismatch' }
$checked = foreach ($row in $pin.paths) {
    $path=$row.path
    $blob=git rev-parse "origin/main:$path"
    if ($LASTEXITCODE -ne 0 -or $blob -cne $row.blob -or (git hash-object "--path=$path" -- $path) -cne $blob) { throw "Blob mismatch at $path" }
    [ordered]@{path=$path;blob=$blob}
}
[ordered]@{version=1;source=$pin.source;base=$pin.parent;tree=$pin.tree;remote='origin/main';blobs=@($checked)} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $d 'source.published.json') -Encoding utf8NoBOM
"$($pin.source) tree=$($pin.tree) blobs=$(@($checked).Count)"
