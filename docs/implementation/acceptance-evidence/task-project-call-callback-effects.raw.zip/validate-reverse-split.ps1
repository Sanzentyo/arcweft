$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$d=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$pin=Get-Content -LiteralPath (Join-Path $d 'source.final.local.json') -Raw | ConvertFrom-Json
function Test-Pin {
  if((git rev-parse HEAD) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned reverse dependency source changed'}
}
Test-Pin
$deadline=[DateTime]::UtcNow.AddMinutes(65)
do {
  $q=$null
  try {$q=Get-Content -LiteralPath (Join-Path $d 'quality-receipt.json') -Raw | ConvertFrom-Json} catch {}
  $ready=$q.source -ceq $pin.source -and ($q.results.name -contains 'doc-tests')
  if(!$ready){Start-Sleep -Seconds 15; Test-Pin}
} until($ready -or [DateTime]::UtcNow -gt $deadline)
if(!$ready){throw 'Previous quality runner has not reached its terminal stage'}
$closure=(Get-Content -LiteralPath (Join-Path $d 'cargo-closure.json') -Raw | ConvertFrom-Json).closure.'metadata-host'
$expected=@($closure|Where-Object {$_ -cne 'arcweft-cli'})
$inventory=cargo metadata --locked --no-deps --format-version 1 | ConvertFrom-Json
if($LASTEXITCODE){exit $LASTEXITCODE}
$packages=@($inventory.packages | Where-Object name -in $expected | Sort-Object name)
if(Compare-Object $expected @($packages.name)){throw 'Cargo package selection changed'}
$plan=[Collections.Generic.List[object]]::new()
$light=[Collections.Generic.List[string]]::new()
$lightCount=0
function Add-Slice([string] $Name, [string[]] $Packages, [string[]] $Targets) {
  $flags=@($Packages|ForEach-Object {'-p';$_})
  $plan.Add([ordered]@{name=$Name;packages=$Packages;targets=$Targets;args=@('nextest','run','--locked')+$flags+$Targets+@('--no-tests','fail','--no-fail-fast')})
}
function Add-Light {
  if($light.Count){Add-Slice ('light-{0:d2}' -f $plan.Count) ($light.ToArray()) @('--lib','--tests');$light.Clear()}
}
foreach($package in $packages){
  $targets=@($package.targets|Where-Object {$_.kind -contains 'test'}|ForEach-Object name|Sort-Object)
  if($targets.Count -gt 4){
    Add-Slice ($package.name+'-lib') @($package.name) @('--lib')
    for($i=0;$i -lt $targets.Count;$i+=3){
      $j=[math]::Min($i+2,$targets.Count-1)
      $flags=@($targets[$i..$j]|ForEach-Object {'--test';$_})
      Add-Slice ($package.name+'-integration-'+[int]($i/3+1)) @($package.name) $flags
    }
  } else {
    $weight=@($package.targets|Where-Object test).Count
    if($light.Count -ge 3 -or $lightCount+$weight -gt 8){Add-Light;$lightCount=0}
    $light.Add($package.name)
    $lightCount+=$weight
  }
}
Add-Light
if(Compare-Object $expected @($plan|ForEach-Object packages|Sort-Object -Unique)){throw 'Split selection omitted a reverse dependency'}
[ordered]@{version=1;source=$pin.source;packages=$expected;stages=$plan.ToArray()}|
  ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $d 'reverse-split-plan.json') -Encoding utf8NoBOM
$results=[Collections.Generic.List[object]]::new()
$receipt=Join-Path $d 'reverse-split-receipt.json'
function Save-Results([bool] $Finished,[string] $Active) {
  [ordered]@{version=1;source=$pin.source;finished=$Finished;active=$Active;packages=$expected;planned=$plan.Count;results=$results.ToArray()} |
    ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receipt -Encoding utf8NoBOM
}
foreach($stage in $plan){
  Test-Pin
  Save-Results $false $stage.name
  $l=Join-Path $d "split-$($stage.name).log"
  $a=$stage.args
  & cargo @a *> $l
  $code=$LASTEXITCODE
  Test-Pin
  $line=(Select-String -LiteralPath $l -Pattern 'Summary.*\btests? run:'|Select-Object -Last 1).Line
  $totals=$null
  if($line -match '([\d,]+) tests? run: ([\d,]+) passed(?: \([^)]+\))?(?:, ([\d,]+) failed)?, ([\d,]+) skipped'){
    $totals=[ordered]@{run=[int]($Matches[1]-replace ',');pass=[int]($Matches[2]-replace ',');fail=if($Matches.ContainsKey(3)){[int]($Matches[3]-replace ',')}else{0};skip=[int]($Matches[4]-replace ',')}
  }
  if(!$code -and !$totals){$code=1}
  $free=(Get-PSDrive D).Free
  $results.Add([ordered]@{name=$stage.name;packages=$stage.packages;command=$a;exit=$code;totals=$totals;summary=$line;logSha256=(Get-FileHash -LiteralPath $l).Hash.ToLowerInvariant();freeBytes=$free})
  Save-Results $false ''
  "$($stage.name) exit=$code $line"
  if($code){Select-String -LiteralPath $l -Pattern '^error'|Select-Object -First 6|ForEach-Object Line}
  if($free -lt 24GB){throw 'Insufficient free space for another test build'}
}
Save-Results $true ''
if(@($results|Where-Object exit -ne 0).Count){exit 1}
