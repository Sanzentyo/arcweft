$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$pin=Get-Content -LiteralPath (Join-Path $d 'source.final.local.json') -Raw | ConvertFrom-Json
$published=Get-Content -LiteralPath (Join-Path $d 'source.published.json') -Raw | ConvertFrom-Json
$quality=Get-Content -LiteralPath (Join-Path $d 'quality-receipt.json') -Raw | ConvertFrom-Json
$cli=Get-Content -LiteralPath (Join-Path $d 'cli-receipt.json') -Raw | ConvertFrom-Json
$split=Get-Content -LiteralPath (Join-Path $d 'reverse-split-receipt.json') -Raw | ConvertFrom-Json
$nested=Get-Content -LiteralPath (Join-Path $d 'nested-result-validated.json') -Raw | ConvertFrom-Json
if ((git rev-parse HEAD) -cne $pin.source -or (git rev-parse origin/main) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only)) { throw 'Unexpected starting state' }
foreach ($receipt in $published,$quality,$cli,$nested,$split) {
    if ($receipt.source -cne $pin.source) { throw 'Evidence source mismatch' }
}
if ($cli.executions.Count -ne 10 -or $nested.executions.Count -ne 4 -or @($quality.results | Where-Object { $_.name -cne 'reverse-dependencies' -and $_.exit -ne 0 }).Count) {throw 'Evidence missing'}
$summaries=foreach ($name in 'cli-unit-binary','cli-integration') {
    $log=Join-Path $d "$name.log"
    $line=(Select-String -LiteralPath $log -Pattern 'Summary.*\btests? run:' | Select-Object -Last 1).Line
    if ($line -notmatch '(?<run>[\d,]+) tests? run: (?<passed>[\d,]+) passed(?:, (?<failed>[\d,]+) failed)?, (?<skipped>[\d,]+) skipped') { throw "Cannot parse nextest summary from $name" }
    $numbers=$Matches.Clone()
    $pass=[int]($numbers.passed.Replace(',',''))
    $run=[int]($numbers.run.Replace(',',''))
    $skip=[int]($numbers.skipped.Replace(',',''))
    if ($pass -ne $run -or $numbers.failed) {throw "Nextest failure in $name"}
    [ordered]@{name=$name;run=$run;pass=$pass;skip=$skip;summary=$line}
}
$ignored=Get-Content -LiteralPath (Join-Path $d 'render-wgpu-ignored-receipt.json') -Raw | ConvertFrom-Json
$empty=$split.results | Where-Object name -ceq 'arcweft-render-wgpu-integration-4'
if ($ignored.source -cne $pin.source -or $ignored.name -cne $empty.name -or $ignored.exit -ne 0 -or
    $empty.exit -ne 4 -or $empty.totals.run -ne 0 -or $empty.totals.skip -ne 3 -or $ignored.cases.Count -ne 3 -or
    @($ignored.cases | Where-Object {!$_.ignored}).Count) { throw 'The ignored-only GPU slice is unproven' }
if (!$split.finished -or $split.results.Count -ne $split.planned -or @($split.results | Where-Object { $_.name -cne $ignored.name -and $_.exit -ne 0 }).Count) {throw 'Split checks incomplete'}
$summaries += [ordered]@{
    name='reverse-dependencies-split'
    run=($split.results | ForEach-Object {$_.totals.run} | Measure-Object -Sum).Sum
    pass=($split.results | ForEach-Object {$_.totals.pass} | Measure-Object -Sum).Sum
    skip=($split.results | ForEach-Object {$_.totals.skip} | Measure-Object -Sum).Sum
    stages=$split.results.Count
}
$passed=($summaries | ForEach-Object {$_.pass} | Measure-Object -Sum).Sum
$skipped=($summaries | ForEach-Object {$_.skip} | Measure-Object -Sum).Sum
[ordered]@{version=1;source=$pin.source;passed=$passed;failed=0;skipped=$skipped;stages=@($summaries);cliExecutions=14} |
    ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $d 'validation-summary.json') -Encoding utf8NoBOM
$archive='docs/implementation/acceptance-evidence/task-project-call-callback-effects.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Evidence destination already exists'}
$files=@(Get-ChildItem -LiteralPath $d -File | Where-Object Extension -in @('.log','.json','.stderr','.arcw','.patch','.ps1') | Sort-Object Name | ForEach-Object FullName)
Compress-Archive -LiteralPath $files -DestinationPath $archive -CompressionLevel Optimal
$archiveFile=Get-Item -LiteralPath $archive
$hash=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()
$zip=[IO.Compression.ZipFile]::OpenRead($archiveFile.FullName)
try { $count=$zip.Entries.Count } finally { $zip.Dispose() }
if ($count -ne $files.Count) {throw 'Archive entry count mismatch'}
$receipt=[ordered]@{source=$pin.source;archive=$archive;sha256=$hash;entries=$count;bytes=$archiveFile.Length;passed=$passed;skipped=$skipped}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $d 'docs.local.json') -Encoding utf8NoBOM
$receipt
