$ErrorActionPreference = 'Stop'
$d = Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$binary = (Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
function Hash($p) { (Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant() }
$sha = Hash $binary
$source = git rev-parse HEAD
if (git diff --name-only) { throw 'Uncommitted validation inputs' }
$cases = [ordered]@{
  'explicit-effect-superset-direct' = @()
  'explicit-effect-superset-curried' = @()
  'explicit-effect-equal-direct' = @('callback')
  'shared-default-explicit-callback' = @('prefix','text','default','default')
  'shared-default-explicit-callback-forward' = @('prefix','text','default','default')
}
$results = foreach ($name in $cases.Keys) {
    foreach ($executor in 'bytecode-vm','awbc-product') {
        $input = Join-Path $d "$name.arcw"
        $stdout = Join-Path $d "$name.$executor.run.json"
        $stderr = Join-Path $d "$name.$executor.run.stderr"
        $argv = @('run',$input,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','512','--json')
        & $binary @argv 1> $stdout 2> $stderr
        $exitCode = $LASTEXITCODE
        $report = Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json -AsHashtable
        $logs = if ($report.steps.Count) { @($report.steps[-1].observations.logs | ForEach-Object {$_.message}) } else { @() }
        $maxOps = ($report.steps | ForEach-Object {$_.stats.executed_ops} | Measure-Object -Maximum).Maximum
        $violations = @($report.steps | Where-Object {$_.diagnostics.Count -or $_.assertion_failures.Count -or $_.assertion_diagnostics.Count})
        [ordered]@{
            name=$name; executor=$executor; command=$argv; exit=$exitCode;
            status=$report.final_status; stage=$report.stage; diagnostic=$report.diagnostics;
            steps=$report.steps.Count; maxOps=$maxOps; logs=$logs; violations=$violations.Count;
            inputSha256=Hash $input; reportSha256=Hash $stdout;
            accepted=$exitCode -eq 0 -and $report.final_status -ceq 'done Return("42")' -and
                ($logs -join '|') -ceq ($cases[$name] -join '|') -and $maxOps -eq 1 -and
                !$violations.Count -and !(Get-Item -LiteralPath $stderr).Length
        }
    }
}
$checks = foreach ($name in 'callback-exceeds-effects','narrower-callback-within-group-partial') {
    $input = Join-Path $d "$name.arcw"
    $stdout = Join-Path $d "$name.check.json"
    $stderr = Join-Path $d "$name.check.stderr"
    $argv = @('compile',$input,'--emit','check','--json')
    & $binary @argv 1> $stdout 2> $stderr
    $exitCode = $LASTEXITCODE
    $report = Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json -AsHashtable
    [ordered]@{
        name=$name; command=$argv; exit=$exitCode; status=$report.status; stage=$report.stage;
        diagnostics=$report.diagnostics; inputSha256=Hash $input; reportSha256=Hash $stdout
    }
}
$partial = foreach ($executor in 'bytecode-vm','awbc-product') {
    $name = 'narrower-callback-within-group-partial'
    $input = Join-Path $d "$name.arcw"
    $stdout = Join-Path $d "$name.$executor.run.json"
    $stderr = Join-Path $d "$name.$executor.run.stderr"
    $argv = @('run',$input,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','512','--json')
    & $binary @argv 1> $stdout 2> $stderr
    $exitCode = $LASTEXITCODE
    $report = Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json -AsHashtable
    [ordered]@{executor=$executor;command=$argv;exit=$exitCode;stage=$report.stage;
        status=$report.final_status;diagnostics=$report.diagnostics;inputSha256=Hash $input;reportSha256=Hash $stdout}
}
if ((Hash $binary) -cne $sha -or (git rev-parse HEAD) -cne $source -or (git diff --name-only)) {
    throw 'Pinned CLI source or binary changed'
}
[ordered]@{version=1; source=$source; binarySha256=$sha; executions=@($results); checks=@($checks);partial=@($partial)} |
    ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $d 'cli-receipt.json') -Encoding utf8NoBOM
$results | ForEach-Object {"$($_.name) $($_.executor) exit=$($_.exit) status=$($_.status) stage=$($_.stage) steps=$($_.steps) max=$($_.maxOps) logs=$($_.logs -join ',') pass=$($_.accepted)"}
$checks | ForEach-Object {"$($_.name) exit=$($_.exit) $($_.stage) $($_.diagnostics[0].diagnostic.message)"}
if (@($results | Where-Object {!$_.accepted}).Count) { exit 1 }
if ($checks[0].exit -ne 1 -or $checks[0].stage -ne 'type-check') { exit 1 }
