$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$d = Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$source = git rev-parse HEAD
$results = [Collections.Generic.List[object]]::new()
function Check-Pin {
    if ((git rev-parse HEAD) -cne $source -or (git diff --name-only) -or (git diff --cached --name-only)) {
        throw 'Validation source changed'
    }
}
function Invoke-Stage([string] $Name, [string] $Tool, [string[]] $Argv) {
    Check-Pin
    $start = Get-Date
    $log = Join-Path $d "$Name.log"
    & $Tool @Argv *> $log
    $code = $LASTEXITCODE
    Check-Pin
    $end = Get-Date
    $summary = @(Select-String -LiteralPath $log -Pattern 'tests? run:|Summary|error:|blocking violations|Finished' | Select-Object -Last 10 | ForEach-Object Line)
    $available = (Get-PSDrive -Name D).Free
    $results.Add([ordered]@{name=$Name;tool=$Tool;command=$Argv;exit=$code;elapsedSeconds=[math]::Round(($end-$start).TotalSeconds,2);freeBytes=$available;summary=$summary;logSha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant()})
    [ordered]@{version=1;source=$source;results=$results.ToArray()} | ConvertTo-Json -Depth 8 |
        Set-Content -LiteralPath (Join-Path $d 'quality-receipt.json') -Encoding utf8NoBOM
    "$Name exit=$code freeGiB=$([math]::Round($available/1GB,2))"
    $summary
    if ($available -lt 24GB) { throw 'Insufficient free space to start a subsequent build' }
}
Invoke-Stage 'format' 'cargo' @('fmt','--all','--check')
Invoke-Stage 'focused-core' 'cargo' @('nextest','run','--locked','-p','arcweft-core','--lib','-E','test(=program_types::function_contract::tests::callable_operand_proof_respects_direction_and_the_owning_frame_predicate) + test(=awbc::tests::project_call_verifier_rejects_rest_shape_and_spread_type_mismatches)','--no-tests','fail')
Invoke-Stage 'cli-build' 'cargo' @('build','--locked','-p','arcweft-cli','--bin','arcw')
$metadata = Get-Content -LiteralPath (Join-Path $d 'cargo-closure.json') -Raw | ConvertFrom-Json -AsHashtable
$hostPackages = $metadata.closure['metadata-host']
$packages = @($hostPackages | Where-Object {$_ -ne 'arcweft-cli'} | ForEach-Object {'-p'; $_})
Invoke-Stage 'reverse-dependencies' 'cargo' (@('nextest','run','--locked') + $packages + @('--lib','--tests','--no-tests','fail'))
Invoke-Stage 'cli-unit-binary' 'cargo' @('nextest','run','--locked','-p','arcweft-cli','--lib','--bins','--no-tests','fail')
Invoke-Stage 'cli-integration' 'cargo' @('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens','--no-tests','fail')
Invoke-Stage 'workspace-check' 'cargo' @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Stage 'workspace-clippy' 'cargo' @('clippy','--locked','--workspace','--all-targets','--all-features')
Invoke-Stage 'wasm-check' 'cargo' @('check','--locked','-p','arcweft-player-web','-p','arcweft-render-web','--target','wasm32-unknown-unknown')
Invoke-Stage 'doc-tests' 'cargo' @('test','--locked','--doc','-p','arcweft-core','-p','arcweft-compiler','-p','arcweft-runtime-plan')
if (@($results | Where-Object exit -ne 0).Count) { exit 1 }
