$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$proof=Get-Content -LiteralPath (Join-Path $d 'docs.local.json') -Raw | ConvertFrom-Json
$source=$proof.source
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$archive=$proof.archive
$paths=@($status,$history,$archive)
if ((git rev-parse HEAD) -cne $source -or (git rev-parse origin/main) -cne $source -or (git branch --show-current) -cne 'main') {throw 'Unexpected publication base'}
if ((Get-FileHash -LiteralPath $archive).Hash -ine $proof.sha256) {throw 'Archive hash changed'}
if (Compare-Object @($status,$history) @(git diff --name-only)) {throw 'Unexpected tracked paths'}
if (git diff --cached --name-only) {throw 'Unexpected staged changes'}
$oldGeneric=@(git show ('{0}:{1}' -f $source,$status) | Where-Object {$_ -match '^\| Generic Match'})
$newGeneric=@(Get-Content -LiteralPath $status | Where-Object {$_ -match '^\| Generic Match'})
if(!$oldGeneric.Count -or (Compare-Object $oldGeneric $newGeneric -CaseSensitive)){throw 'Generic Match evidence changed'}
if(!(Select-String -LiteralPath $status -SimpleMatch 'convergence-evidence-history.md#callable-operand-effect-compatibility') -or
   !(Select-String -LiteralPath $history -SimpleMatch '### Callable operand effect compatibility') -or
   !(Select-String -LiteralPath $history -SimpleMatch (Split-Path -Leaf $archive))){
    throw 'Evidence links are incomplete'
}
git diff --check
if($LASTEXITCODE){exit $LASTEXITCODE}
git add -- @paths
if($LASTEXITCODE){exit $LASTEXITCODE}
if(Compare-Object $paths @(git diff --cached --name-only)){throw 'Staged paths differ'}
git diff --cached --check
if($LASTEXITCODE){exit $LASTEXITCODE}
git diff --cached --stat
git commit -m 'docs: record callable operand effect validation'
if($LASTEXITCODE){exit $LASTEXITCODE}
git push origin HEAD:refs/heads/main
if($LASTEXITCODE){exit $LASTEXITCODE}
git fetch origin main
if($LASTEXITCODE){exit $LASTEXITCODE}
$head=git rev-parse HEAD
$parent=git rev-parse 'HEAD^'
$tree=git rev-parse 'HEAD^{tree}'
$remote=((git ls-remote --exit-code origin refs/heads/main) -split '\s+')[0]
if($LASTEXITCODE){exit $LASTEXITCODE}
if($head -cne $remote -or $head -cne (git rev-parse origin/main) -or $parent -cne $source -or $tree -cne (git rev-parse 'origin/main^{tree}')){throw 'Evidence publication mismatch'}
$rows=foreach($path in $paths){
    $blob=git rev-parse "origin/main:$path"
    if($LASTEXITCODE -or $blob -cne (git hash-object "--path=$path" -- $path)){throw "Evidence blob mismatch $path"}
    [ordered]@{path=$path;blob=$blob}
}
[ordered]@{version=1;commit=$head;source=$source;tree=$tree;blobs=@($rows)}|
   ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $d 'docs.published.json') -Encoding utf8NoBOM
"$head tree=$tree evidenceBlobs=$(@($rows).Count)"
git status --short
