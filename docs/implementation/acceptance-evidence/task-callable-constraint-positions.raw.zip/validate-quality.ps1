$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$env:CARGO_INCREMENTAL='0'
$d=Join-Path $env:TEMP 'arcweft-declared-partial-20261111'
$prior=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$pin=Get-Content -LiteralPath (Join-Path $d 'source.local.json') -Raw | ConvertFrom-Json
$closure=(Get-Content -LiteralPath (Join-Path $d 'cargo-closure.json') -Raw | ConvertFrom-Json).closure.'host-metadata'
$pastPlan=(Get-Content -LiteralPath (Join-Path $prior 'reverse-split-plan.json') -Raw | ConvertFrom-Json).stages
$receiptPath=Join-Path $d 'quality-receipt.json'
$results=[Collections.Generic.List[object]]::new()
$plan=[Collections.Generic.List[object]]::new()

function Confirm-Source {
    if ((git rev-parse HEAD) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only)) {
        throw 'Pinned source changed'
    }
}
function Add-Command([string] $Name,[string] $Program,[string[]] $Arguments,[string[]] $Packages=@()) {
    $plan.Add([ordered]@{name=$Name;program=$Program;args=$Arguments;packages=$Packages})
}
function Add-Nextest([string] $Name,[string[]] $Packages,[string[]] $Targets) {
    $flags=@($Packages | ForEach-Object {'-p';$_})
    Add-Command $Name 'cargo' (@('nextest','run','--locked')+$flags+$Targets+@('--no-tests','fail','--no-fail-fast')) $Packages
}
function Save-Results([string] $Active,[bool] $Finished) {
    $temp=Join-Path $d 'quality-receipt.pending.json'
    [ordered]@{version=1;source=$pin.source;packages=$closure;active=$Active;finished=$Finished;results=$results.ToArray()} |
        ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $temp -Encoding utf8NoBOM
    [IO.File]::Move($temp,$receiptPath,$true)
}
function Read-Result($stage,[string] $log,[int] $code) {
    $summary=@(Select-String -LiteralPath $log -Pattern 'Summary .*tests? run:|^test result:' | ForEach-Object {$_.Line.Trim()})
    $totals=$null
    $line=$summary | Where-Object {$_ -like 'Summary *'} | Select-Object -Last 1
    if($line -match '([\d,]+) tests? run: ([\d,]+) passed(?: \([^)]+\))?(?:, ([\d,]+) failed)?, ([\d,]+) skipped'){
        $totals=[ordered]@{run=[int]($Matches[1]-replace ',');pass=[int]($Matches[2]-replace ',');fail=if($Matches.ContainsKey(3)){[int]($Matches[3]-replace ',')}else{0};skip=[int]($Matches[4]-replace ',')}
    }
    if($stage.args[0] -ceq 'nextest' -and $stage.args[1] -ceq 'run' -and !$totals -and !$code){$code=1}
    $free=(Get-PSDrive -Name D).Free
    $results.Add([ordered]@{name=$stage.name;command=@($stage.program)+$stage.args;packages=$stage.packages;exit=$code;totals=$totals;summary=$summary;log=(Split-Path $log -Leaf);logSha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant();freeBytes=$free})
    "$($stage.name) exit=$code $($summary -join ' | ')"
    if($code){Get-Content -LiteralPath $log -Tail 20}
    if($free -lt 40GB){throw 'Insufficient free space for another test build'}
}

Confirm-Source
Add-Nextest 'sema' @('arcweft-lang-sema') @('--lib','--tests')
Add-Nextest 'compiler-focused' @('arcweft-compiler') @('--test','callable_execution','--test','flow_wait')
Add-Command 'format' 'cargo' @('fmt','--all','--','--check')
Add-Command 'workspace-check' 'cargo' @('check','--locked','--workspace','--all-targets','--all-features')
Add-Command 'workspace-clippy' 'cargo' @('clippy','--locked','--workspace','--all-targets','--all-features')
Add-Command 'structure' 'just' @('structure-audit-gate')

Add-Nextest 'runtime-plan' @('arcweft-runtime-plan') @('--lib','--tests')

Add-Command 'cli-build' 'cargo' @('build','--locked','--profile','test','-p','arcweft-cli','--bin','arcw')
Add-Command 'cli-execution' 'pwsh' @('-NoProfile','-File',(Join-Path $d 'validate-cli.ps1'))
Add-Command 'wasm-check' 'cargo' @('check','--locked','--target','wasm32-unknown-unknown','-p','arcweft-player-web')
Add-Command 'doc-tests' 'cargo' @('test','--locked','--doc','-p','arcweft-lang-sema')

foreach($stage in $pastPlan) {
    if($stage.name -ceq 'arcweft-core-lib'){continue}
    $packages=@($stage.packages | Where-Object {$_ -in $closure -and $_ -notin @('arcweft-lang-sema','arcweft-runtime-plan')})
    if(!$packages.Count){continue}
    $targets=@($stage.targets)
    if($targets[0] -ceq '--test' -and $packages -contains 'arcweft-compiler'){
        $targets=@($targets | Where-Object {$_ -cne '--test' -and $_ -cne 'flow_wait' -and $_ -cne 'callable_execution'} | ForEach-Object {'--test';$_})
    }
    if($stage.name -ceq 'arcweft-render-wgpu-integration-4'){
        $flags=@('-p','arcweft-render-wgpu')+$targets
        Add-Command 'gpu-ignored-list' 'cargo' (@('nextest','list','--locked')+$flags+@('--message-format','json'))
        Add-Command $stage.name 'cargo' (@('nextest','run','--locked')+$flags+@('--no-tests','pass','--no-fail-fast')) $packages
    } elseif($targets.Count){
        Add-Nextest $stage.name $packages $targets
    }
}
Add-Nextest 'cli-lib-bins' @('arcweft-cli') @('--lib','--bins')
Add-Nextest 'cli-integration' @('arcweft-cli') @('--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')
$plannedPackages=@(@('arcweft-lang-sema')+@($plan | ForEach-Object {$_.packages}) | Sort-Object -Unique)
if(Compare-Object $closure $plannedPackages){throw 'Resolved package selection changed'}
[ordered]@{version=1;source=$pin.source;packages=$closure;stages=$plan.ToArray()} |
    ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $d 'quality-plan.json') -Encoding utf8NoBOM
foreach($stage in $plan){
    Confirm-Source
    Save-Results $stage.name $false
    $log=Join-Path $d ('quality-'+$stage.name+'.log')
    $program=$stage.program
    $argv=$stage.args
    if($stage.name -ceq 'gpu-ignored-list'){
        & $program @argv 1> $log 2> (Join-Path $d 'quality-gpu-ignored-list.stderr')
    } else {
        & $program @argv *> $log
    }
    $code=$LASTEXITCODE
    if($stage.name -ceq 'gpu-ignored-list' -and !$code){
        $listing=Get-Content -Raw -LiteralPath $log|ConvertFrom-Json -AsHashtable
        $cases=@($listing['rust-suites'].Values | ForEach-Object {$_['testcases'].Values})
        if($cases.Count -ne 3 -or @($cases | Where-Object {!$_.ignored}).Count){throw 'Unexpected GPU ignore selection'}
    }
    Confirm-Source
    Read-Result $stage $log $code
    Save-Results '' $false
}
Save-Results '' $true
if(@($results | Where-Object exit -ne 0).Count){exit 1}




