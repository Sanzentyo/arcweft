param([Parameter(Mandatory)][ValidateSet('baseline','final')][string] $Label)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$d=Join-Path $env:TEMP 'arcweft-declared-partial-20261111'
$binary=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
function Hash([string] $Path){(Get-FileHash -LiteralPath $Path).Hash.ToLowerInvariant()}
$binaryHash=Hash $binary
if($Label -ceq 'baseline'){
    if($binaryHash -cne 'e4ed2e0651053d4da266f03254de3ab52d1c8db1a73622546f4a2a9e4bf623bf'){
        throw 'The previous CLI was rebuilt before the baseline could be captured'
    }
} else {
    $cli=Get-Content -Raw -LiteralPath (Join-Path $d 'cli-receipt.json') | ConvertFrom-Json
    if($binaryHash -cne $cli.binarySha256 -or (git rev-parse HEAD) -cne $cli.source){throw 'Final CLI identity changed'}
}
$inputs=Join-Path $env:TEMP 'arcweft-value-partial-20261111'
$position=Join-Path $env:TEMP 'arcweft-within-group-model-20261111'
$effects=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$cases=[ordered]@{
    'closure-spread'=(Join-Path $inputs 'closure-spread.arcw')
    'widened-parameter'=(Join-Path $inputs 'widened-parameter.arcw')
    'shared-generic-next-group'=(Join-Path $position 'shared-generic-next-group.arcw')
    'shared-default-explicit-callback-forward'=(Join-Path $effects 'shared-default-explicit-callback-forward.arcw')
}
$results=foreach($name in $cases.Keys){
    $input=$cases[$name]
    $artifact=Join-Path $d "$name.$Label.plan"
    $out=Join-Path $d "$name.$Label.emit-plan.json"
    $err=Join-Path $d "$name.$Label.emit-plan.stderr"
    $argv=@('compile',$input,'--emit','plan','--output',$artifact,'--json')
    & $binary @argv 1> $out 2> $err
    $code=$LASTEXITCODE
    if($code -ne 0 -or !(Test-Path -LiteralPath $artifact)){throw "Plan emission failed: $name"}
    $r=Get-Content -Raw -LiteralPath $out | ConvertFrom-Json
    if($r.status -cne 'ok' -or (Get-Item -LiteralPath $err).Length){throw "Plan emission report failed: $name"}
    [ordered]@{name=$name;command=$argv;exit=$code;inputSha256=Hash $input;artifactSha256=Hash $artifact;size=(Get-Item -LiteralPath $artifact).Length}
}
if((Hash $binary) -cne $binaryHash){throw 'CLI changed during plan emission'}
$receipt=[ordered]@{version=1;source=if($Label -ceq 'final'){$cli.source}else{'c7a4d36dff782610e939e3b7c35353dfd006939c'};binarySha256=$binaryHash;results=@($results)}
if($Label -ceq 'final'){
    $baseline=Get-Content -Raw -LiteralPath (Join-Path $d 'plan-baseline.json')|ConvertFrom-Json
    foreach($row in $results){
        $old=$baseline.results | Where-Object name -CEQ $row.name
        $row['matchesBaseline']=$old.inputSha256 -ceq $row.inputSha256 -and $old.artifactSha256 -ceq $row.artifactSha256
    }
}
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $d "plan-$Label.json") -Encoding utf8NoBOM
$results | ForEach-Object {"$($_.name) plan sha256=$($_.artifactSha256) baseline-match=$($_.matchesBaseline)"}
if($Label -ceq 'final' -and @($results | Where-Object {!$_.matchesBaseline}).Count){exit 1}
exit 0
