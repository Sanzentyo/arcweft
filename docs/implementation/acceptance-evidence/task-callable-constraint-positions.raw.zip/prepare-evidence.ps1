$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-declared-partial-20261111'
$prior=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$pin=Get-Content -LiteralPath (Join-Path $d 'source.local.json') -Raw | ConvertFrom-Json
$quality=Get-Content -LiteralPath (Join-Path $d 'quality-receipt.json') -Raw | ConvertFrom-Json
$plan=Get-Content -LiteralPath (Join-Path $d 'quality-plan.json') -Raw | ConvertFrom-Json
if(!$quality.finished -or $quality.source -cne $pin.source -or $quality.results.Count -ne $plan.stages.Count -or @($quality.results | Where-Object exit -ne 0).Count){throw 'Quality receipt is incomplete'}
if((git rev-parse HEAD) -cne $pin.source -or (git rev-parse origin/main) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Published source changed'}
$totals=[ordered]@{pass=0;fail=0;skip=0}
foreach($row in $quality.results){
    $log=Join-Path $d $row.log
    if((Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant() -cne $row.logSha256){throw "Changed validation log $log"}
    if($row.totals){foreach($key in 'pass','fail','skip'){$totals[$key]+=$row.totals.$key}}
}
$sourceFiles=@(Get-ChildItem -LiteralPath $d -File | Where-Object {
    $_.Extension -in '.log','.json','.stderr','.arcw','.ps1','.txt' -and
    $_.Name -notin @('archive-receipt.json','cargo-metadata.json')
})
$priorFiles=@(Get-Item -LiteralPath (Join-Path $prior 'explicit-effect-superset-curried.arcw'),(Join-Path $prior 'shared-default-explicit-callback-forward.arcw'))
$position=Join-Path $env:TEMP 'arcweft-within-group-model-20261111'
$comparisonFiles=@(Get-Item -LiteralPath (Join-Path $position 'shared-generic-next-group.arcw'),(Join-Path $position 'shared-generic-same-group.arcw'))
$valuePartial=Join-Path $env:TEMP 'arcweft-value-partial-20261111'
$valueFiles=@(Get-Item -LiteralPath (@('widened-parameter','closure-spread','immediate','twice','typed-parameter','triple-immediate','effects','direct-project','wide-effects','wide-effects-exact') | ForEach-Object {Join-Path $valuePartial "$_.arcw"}))
$inputs=@($sourceFiles+$priorFiles+$comparisonFiles+$valueFiles | Sort-Object Name)
if(@($inputs.Name | Group-Object | Where-Object Count -ne 1).Count){throw 'Conflicting archive names'}
$archive=Join-Path (Resolve-Path -LiteralPath 'docs/implementation/acceptance-evidence').Path 'task-callable-constraint-positions.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Evidence archive already exists'}
Compress-Archive -LiteralPath @($inputs.FullName) -DestinationPath $archive -CompressionLevel Optimal
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try {
    if(Compare-Object @($inputs.Name) @($zip.Entries.FullName)){throw 'Archive contents differ'}
    foreach($item in $inputs){
        $entry=$zip.GetEntry($item.Name)
        $stream=$entry.Open()
        try {
            $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))
            if($hash -cne (Get-FileHash -LiteralPath $item.FullName).Hash){throw "Archive hash mismatch $($item.Name)"}
        } finally {$stream.Dispose()}
    }
} finally {$zip.Dispose()}
$receipt=[ordered]@{version=1;source=$pin.source;files=$inputs.Count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();nextest=$totals;qualityStages=$quality.results.Count;packages=$quality.packages.Count}
$receipt|ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $d 'archive-receipt.json') -Encoding utf8NoBOM
$receipt|ConvertTo-Json -Depth 6




