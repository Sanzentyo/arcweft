$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$source=Read-Record 'cli-presentation-z-index-checkpoint.verified'
$runtime=Read-Record 'cli-presentation-z-index-owner1-20261105.runtime.terminal-audit'
$check=Read-Record 'cli-presentation-z-index-quality1-20261105-check'
$clippy=Read-Record 'cli-presentation-z-index-quality1-20261105-clippy'
if((git rev-parse HEAD).Trim() -ne $source.commit -or $runtime.passed -ne 3 -or $runtime.failed -ne 0 -or $check.exitCode -ne 0 -or $clippy.exitCode -ne 0){throw 'Unexpected source/results'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like 'cli-presentation-z-index*'})
$files+=@(Get-Item -LiteralPath "$taskTemp/record-cli-presentation-z-index.ps1","$taskTemp/run-cli-presentation-quality.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/audit-nextest-final-result.ps1")
. "$taskTemp/write-verified-evidence-archive.ps1"
$rawPath='docs/implementation/acceptance-evidence/task-cli-presentation-z-index.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$before=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('cliPresentationZIndex')){throw 'Preserve existing evidence'}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$oldRows=@($status -split "`n"|Where-Object {$_ -match '^\| (CLI全target照合|共有契約／推移的逆依存matrix|workspace check／Clippy)'})
$record.cliPresentationZIndex=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source
 reason='The unchanged source authors only layer=hud,z_index=7,opacity=0.5; no object-proxy declaration/call or role/hover/weight values exist. RichTextPresentation has typed fields and no generic params map. Both actual full48 and previous CLI parent runs failed on the fabricated caption expectation. Do not introduce an unowned map or infer unauthored values to satisfy that stale assertion.'
 correction='Replace the five params role/hover/weight expectations with exact absence of params and object proxies plus typed layer/z_index/opacity assertions on all three run/page/line objects. This strengthens page/line scalar coverage. Preserve every original valid layer/depth/geometry/capture/hit-test assertion, exact source, viewport and4-step/64-op bounds. No production/Cargo/API change.'
 runtime=$runtime;command=(Read-Record 'cli-presentation-z-index-owner1-20261105.runtime').command
 runtimeScope='One actual3/3PASS485skip15.379s run: original z-index case, depth-sorted typed rich-text proxy hit-test, and explicit rich_text_proxy struct declaration/default/override observation with image metadata and hit-test. Positive authored proxies still retain schema/declaration/field metadata; the no-proxy z-index source cannot acquire it.4110 source/case/EXE drift0.'
 quality=[ordered]@{check=$check;clippy=$clippy}
 qualityScope='CLI package all-target/all-feature/locked check and Clippy exit0; existing warnings remain. Format changed Rust. Reuse unaffected production/shared/structure evidence: this only repairs one CLI test expectation, with no dependency/ownership change; do not claim a fresh workspace/full48/structure/doctest/wasm/parity run.'
 previousFailure=[ordered]@{run='font-family-reverse1-20261105.runtime';source='afdf8773b3743df2fd16691e0ea4deec6183db46';binary='arcweft-cli::check';test='agent_observe_native::agent_observe_reports_text_presentation_z_index_depth';result='FAIL;presentation.params.role was Null, stale expectation caption'}
 correctionReason='Supersedes only the current outstanding z-index assertion condition. Preserve actual full7140=7126PASS14FAIL and CLI700=686PASS14FAIL; this later3-case source/run is independent, not a recomputed700/13FAIL result. The13 other failure IDs have unchanged inputs and remain the current repair scope. Generic Match and all other accepted boundaries remain accepted.'
 supersededCurrentRows=$oldRows
 workingTree='Original12 tracked WIP patch SHA25646402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac retained through verified publication; original6 untracked files retained.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| CLI全target照合 |')){
  '| CLI全target照合 | **統合受入は未完了。全700実測とz-indexの別owner修復を保持** | Source afdf8773b3743df2fd16691e0ea4deec6183db46の全CLI700は686 PASS／14 FAIL。後続'+$source.commit+'は、Sourceにないparams期待を型付きpresentationの検査へ訂正し、元の全layer／depth／capture／hit-testと4-step／64-opを保って対象3／3 PASS、CLI check／Clippyは終了0。旧full runを700／13 FAILへ再計算しない。未修復の13 IDはfull-grammar現在line選択3件、Scroll解決1件、RAG1件、旧plan／unsafe fixture2件、run-edge1件、負例診断1件、verifier fixture4件。各以前の入力・件数・失敗と訂正理由は履歴に保持する。[全失敗・独立した再検査・原本](acceptance-evidence/task-rich-text-property-identity.json)。Generic Matchと他の既受入境界は維持する。 |'
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
  $line.Replace('最新のCLI14失敗を修復中','後続のCLI owner修復を継続')
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
  $line.Replace('変更Rustをfmtし、','後続z-index fixtureのみの'+$source.commit+'はCLI check／Clippyが終了0。変更Rustをfmtし、')
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefixHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()
$append=@"

## 2026-11-05 — CLI z-index fixture aligned with typed presentation

- Source $($source.commit): the unchanged fixture authors layer/hud,z_index7,opacity0.5 and no object proxy or role/hover/weight. Replace five fabricated params expectations with exact absence of the removed map/unauthored proxies and typed run/page/line scalar checks. Keep original valid layer/depth/geometry/capture/hit-test assertions, exact text/source, viewport and4-step/64-op bounds. No production/Cargo change.
- Actual3/3PASS485skip15.379s: original z-index case plus positive Source depth-sorted proxy and explicit rich_text_proxy struct/default/override observation/image/hit checks.4110 source/case/EXE drift0; CLI all-target/all-feature/locked check/Clippy exit0, existing warnings. Source/ownership/structure are otherwise unchanged, so no invented broader rerun.
- Supersedes the outstanding z-index fixture condition only. Preserve full7140/14FAIL and CLI700/14FAIL as actual earlier runs; do not subtract this repair to invent700/13FAIL. The other13 failed IDs retain unchanged inputs and remain repair scope. [Exact result, correction reason, published full SHA and verified raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md). Generic Match acceptance/publication and other accepted boundaries remain intact.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous evidence changed'}}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixHash){throw 'History changed'}
[ordered]@{source=$source.commit;runtime=$runtime.summary;priorFieldDrift=0;historyPrefixDrift=0;raw=$record.cliPresentationZIndex.raw}|ConvertTo-Json -Depth 5
