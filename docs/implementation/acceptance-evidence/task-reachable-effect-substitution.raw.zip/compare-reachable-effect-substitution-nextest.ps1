param([string]$Iteration = 'dev01',[string]$Attempt = '-retry01')
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$p=Join-Path $d 'reachable-effect-substitution'
$previous=Join-Path $d 'named-source-body-read-view.dev01-nextest.log'
$current=$p+'.'+$Iteration+'-compiler-nextest'+$Attempt+'.log'
function Read-TestResults([string]$path){
    $tests=[ordered]@{}
    foreach($line in [IO.File]::ReadLines($path)){
        if($line -match '^\s*(PASS|FAIL|SKIP)\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+arcweft-compiler::(\S+)\s+(\S+)'){
            $tests[$Matches[2]+'::'+$Matches[3]]=$Matches[1]
        }
    }
    $tests
}
$old=Read-TestResults $previous
$new=Read-TestResults $current
if($old.Count -ne 152 -or $new.Count -ne 152 -or (Compare-Object @($old.Keys | Sort-Object) @($new.Keys | Sort-Object))){throw 'Compiler test inventory differs'}
$delta=@($new.Keys | Where-Object {$new[$_] -ne $old[$_]} | ForEach-Object {@{test=$_;before=$old[$_];after=$new[$_]}})
$oldCatalog=@(Select-String -LiteralPath $previous -SimpleMatch 'semantic_error: Some(CheckedCallableCatalog)').Count
$newCatalog=@(Select-String -LiteralPath $current -SimpleMatch 'semantic_error: Some(CheckedCallableCatalog)').Count
$result=@{version=1;previous='ad12f74311a1e89696a25bae5b7102d9c3f79f4b';cases=$new.Count;baseline_counts=@($old.Values|Group-Object|Select-Object Name,Count);current_counts=@($new.Values|Group-Object|Select-Object Name,Count);checked_callable_catalog_before=$oldCatalog;checked_callable_catalog_after=$newCatalog;changed=$delta;remaining=@($new.Keys | Where-Object {$new[$_] -eq 'FAIL'})}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($p+'.nextest-comparison.json') -Encoding utf8NoBOM
$result.Remove('changed')
$result | ConvertTo-Json -Depth 5





