use std::{collections::BTreeMap, path::PathBuf, sync::Arc};

use arcweft_character::catalog::{CharacterCatalog, CharacterVisualManifestEvidence};
use arcweft_compiler::project::{
    AcceptedLaunchProfileInput, CompiledProject, ProjectCompilationContext,
    ProjectCompilationSession, ProjectCompileError, compile_project,
};
use arcweft_core::{
    awbc::{codec::AwbcDecodeBudget, schema::{AwbcEntryId, AwbcProgram}},
    effect::RuntimeArtifactFingerprint,
    engine::{Engine, FlowFiberStatus},
    executor::ArcweftRuntimeExecutor,
    plan::FlowEvent,
    pure::VmRuntimePureCallBackend,
    runtime_id::{DialogueActivationId, RuntimeDialogueMarkId},
    step::{RuntimeDialogueContentEvent, RuntimeDialogueContentEventKind, RuntimeStepInput, RuntimeStepOptions, RuntimeStepResult},
    time::TickId,
};
use arcweft_lang_hir::symbol::{CallablePackageId, ProjectSymbolWorldId};
use arcweft_lang_sema::{env::TypeCheckEnv, registration::ProjectRegistrationFacts};
use arcweft_lang_syntax::{
    ast::module_path::CanonicalModulePath,
    incremental::{ParsedSource, SyntaxDatabase},
    parser::ParseOptions,
};
use arcweft_launch::{LaunchProfileSelection, ProfileId, accepted::SourceBackedManifest};
use arcweft_manifest_model::{BuildSpec, PackageId, PackageSpec, PackageVersion};
use arcweft_project::sources::{ProjectSourceFile, ProjectSources};
use arcweft_resource_model::registry::ResourceTypeRegistry;
use arcweft_runtime_plan::awbc_lower::AwbcLowerer;
use arcweft_source::{
    SourceDocument, SourceDocumentId, SourceName, SourceSetRevision, identity::SourceSnapshotId,
};


fn has_pending_lexical_registration(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::Object(fields) => {
            fields.get("defers").and_then(serde_json::Value::as_array).is_some_and(|rows| !rows.is_empty())
                || fields.values().any(has_pending_lexical_registration)
        }
        serde_json::Value::Array(rows) => rows.iter().any(has_pending_lexical_registration),
        _ => false,
    }
}

fn main() {
    use arcweft_core::{
        awbc::product_step::AwbcProductExecutorSaveSnapshot,
        executor::ArcweftRuntimeExecutorSnapshot,
    };
    let compiled = compile_attached_dialogue_project(r#"
pub character alice { display = "Alice" }
flow main() -> Unit {
    alice()[hello[p]] with {
        init {
            defer { log.info("cleanup") }
            log.info("body")
        }
    }
}
entry cli @entry.main { goto @flow.main }
"#).unwrap();
    let runtime = compiled.runtime_plan();
    let bytes = AwbcLowerer::new(&runtime.plan, &runtime.dialogue_content_catalog, "scope-id-probe.arcw")
        .lower().unwrap().program.encode_canonical().unwrap();
    let decoded = AwbcProgram::decode_canonical(&bytes, AwbcDecodeBudget::default()).unwrap();
    let mut executor = ArcweftRuntimeExecutor::from_awbc_product(decoded, AwbcEntryId(0)).unwrap();
    let schema = bind_test_character_dialogue_schema(&compiled, executor.program_owner());
    let mut backend = VmRuntimePureCallBackend::default().with_external_calls(
        arcweft_dialogue::CharacterDialogueRuntimeExternalCallBackend::new(&schema),
    );
    let mut observed_pending = false;
    let mut observed_inflight = false;
    for tick in 0..128 {
        let result = executor.step_with_pure_backend(
            RuntimeStepInput { tick: TickId(tick), ..RuntimeStepInput::default() },
            RuntimeStepOptions::default(),
            &mut backend,
        );
        assert!(result.output.diagnostics.is_empty(), "{:?}", result.output.diagnostics);
        let ArcweftRuntimeExecutorSnapshot::AwbcProduct(snapshot) = executor.snapshot().unwrap();
        let pristine = AwbcProductExecutorSaveSnapshot::from_live(
            &snapshot, executor.admitted_product_awbc_program().unwrap(),
        ).unwrap();
        let saved = serde_json::to_value(&pristine).unwrap();
        let inflight = saved["child_fibers"].as_array().unwrap().iter()
            .any(|child| child["owner"].get("ScopedDeferred").is_some());
        let pending = has_pending_lexical_registration(&saved["dialogues"]);
        let phase = if inflight && !observed_inflight {
            observed_inflight = true;
            Some("inflight")
        } else if pending && !observed_pending {
            observed_pending = true;
            Some("pending")
        } else {
            None
        };
        if let Some(phase) = phase {
            let mut forged = saved;
            let line = forged["dialogues"]["entries"].as_array_mut().unwrap().iter_mut()
                .find_map(|entry| entry.pointer_mut("/Active/line"))
                .unwrap();
            let original_frontier = line["next_defer_registration"].as_u64().unwrap();
            assert!(original_frontier > 1);
            line["next_defer_registration"] = serde_json::json!(1);
            let forged = serde_json::from_value(forged).unwrap();
            let forged = executor.bind_product_save_snapshot(forged).unwrap();
            executor = match executor.restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(forged)) {
                Ok(restored) => {
                    println!("FORGED ACCEPTED {phase} {tick} frontier={original_frontier}->1");
                    restored
                }
                Err(error) => {
                    let (executor, reason) = error.into_parts();
                    println!("FORGED REJECTED {phase} {tick} frontier={original_frontier}->1 {reason}");
                    executor
                }
            };
            let pristine = executor.bind_product_save_snapshot(pristine).unwrap();
            executor = executor.restore_snapshot(ArcweftRuntimeExecutorSnapshot::AwbcProduct(pristine)).unwrap();
            println!("PRISTINE RESTORED {phase} {tick}");
        }
        if observed_pending && observed_inflight { break; }
    }
    assert!(observed_pending && observed_inflight);
}


fn bind_test_character_dialogue_schema(
    compiled: &CompiledProject,
    owner: arcweft_core::task::RuntimeProgramOwner,
) -> arcweft_dialogue::CharacterDialogueRuntimeSchema {
    let generation = compiled
        .runtime_plan()
        .character_dialogue_generation
        .as_ref()
        .expect("the dialogue fixture publishes a CharacterDialogue generation");
    let environment = compiled.analysis_lease().registered_environment();
    let characters =
        CharacterCatalog::try_from_declarations(generation.characters().keys().map(|character| {
            let visual = environment.character_manifest(character).cloned().map_or(
                CharacterVisualManifestEvidence::Absent,
                CharacterVisualManifestEvidence::Present,
            );
            (character.clone(), visual)
        }))
        .expect("the accepted Character inventory and visual evidence form a catalog");

    let product = compiled.dialogue_profile().product();
    let program = product
        .program()
        .expect("the accepted dialogue profile retains its View program");
    let mut views = arcweft_view::ViewRegistry::default();
    program
        .register_runtime_views(&mut views)
        .expect("the accepted dialogue View registry");
    let style_digest = product.style().map(|style| {
        style
            .resource()
            .canonical_digest()
            .map(|digest| arcweft_core::entry::RuntimeValueDigest::from_bytes(digest.as_bytes()))
            .expect("the accepted dialogue Style fingerprint")
    });

    generation
        .bind_runtime(Arc::new(views), Arc::new(characters), style_digest, owner)
        .expect("the schema binds to this exact executable generation")
}

fn compile_attached_dialogue_project(source: &str) -> Result<CompiledProject, ProjectCompileError> {
    with_attached_dialogue_project(source, compile_project)
}

fn with_attached_dialogue_project<T>(
    source: &str,
    run: impl FnOnce(
        &mut ProjectCompilationSession,
        &ProjectSources,
        &BTreeMap<CanonicalModulePath, ParsedSource>,
        &ProjectCompilationContext,
    ) -> T,
) -> T {
    with_attached_dialogue_project_and_visual(source, None, run)
}

fn with_attached_dialogue_project_and_visual<T>(
    source: &str,
    visual: Option<&str>,
    run: impl FnOnce(
        &mut ProjectCompilationSession,
        &ProjectSources,
        &BTreeMap<CanonicalModulePath, ParsedSource>,
        &ProjectCompilationContext,
    ) -> T,
) -> T {
    use arcweft_character::{
        manifest::registration::SourceBackedCharacterManifest,
        registration_catalog::SourceBackedCharacterCatalog,
    };

    let source_document = Arc::new(
        SourceDocument::try_new(
            SourceDocumentId::try_new("arcweft-test://evaluated-effects/source")
                .expect("dialogue source document ID"),
            SourceName::path("src/main.arcw"),
            source,
        )
        .expect("dialogue source document"),
    );
    let manifest_document = Arc::new(
        SourceDocument::try_new(
            SourceDocumentId::try_new("arcweft-test://evaluated-effects/manifest")
                .expect("dialogue manifest document ID"),
            SourceName::path("arcw.toml"),
            "schema = 1\n\
[package]\n\
id = \"local.arcweft.evaluated-effects\"\n\
version = \"0.0.0\"\n\
\n\
[profiles.dev]\n\
kind = \"game\"\n\
source = \"src/main.arcw\"\n",
        )
        .expect("dialogue manifest document"),
    );
    let project = ProjectSources::new(
        PathBuf::from("arcw.toml"),
        PathBuf::new(),
        PackageSpec {
            id: PackageId::new("local.arcweft.evaluated-effects").expect("package ID"),
            version: PackageVersion::new("0.0.0").expect("package version"),
        },
        BuildSpec::default(),
        Arc::clone(&manifest_document),
        [ProjectSourceFile::new(
            CanonicalModulePath::crate_root(),
            PathBuf::from("src/main.arcw"),
            Arc::clone(&source_document),
            [],
        )],
    )
    .expect("dialogue project sources");
    let package =
        CallablePackageId::try_new(project.package().id.as_str()).expect("callable package ID");
    let world = ProjectSymbolWorldId::try_new(
        package,
        source_document.identity().id().clone(),
        "evaluated-effects-test",
    )
    .expect("dialogue symbol world");
    let mut registration_documents =
        vec![Arc::clone(&source_document), Arc::clone(&manifest_document)];
    let character_catalogs = visual.map(|json| {
        let document = Arc::new(
            SourceDocument::try_new(
                SourceDocumentId::try_new("arcweft-test://evaluated-effects/alice-visual").unwrap(),
                SourceName::path("alice.json"),
                json,
            )
            .unwrap(),
        );
        let manifest = SourceBackedCharacterManifest::decode_registration_json(&document).unwrap();
        let catalog =
            SourceBackedCharacterCatalog::try_new(document.identity().clone(), vec![manifest])
                .unwrap();
        registration_documents.push(document);
        catalog
    });
    let facts = ProjectRegistrationFacts::try_new(
        world,
        registration_documents,
        Vec::new(),
        character_catalogs.into_iter().collect(),
        Vec::new(),
    )
    .expect("dialogue registration facts");
    let resource_types = Arc::new(ResourceTypeRegistry::empty());
    let accepted = Arc::new(
        SourceBackedManifest::decode(Arc::clone(&manifest_document))
            .expect("accepted dialogue manifest"),
    );
    let profile_id = ProfileId::new("dev").expect("dialogue profile ID");
    let resolved = accepted
        .resolve_profile(LaunchProfileSelection::Explicit(profile_id.as_str()))
        .expect("resolved dialogue profile");
    let topology_revision = SourceSetRevision::try_for_identities([
        manifest_document.identity(),
        source_document.identity(),
    ])
    .expect("dialogue topology revision");
    let context = ProjectCompilationContext::new(
        Arc::new(TypeCheckEnv::standard()),
        Arc::new(facts),
        Arc::clone(&resource_types),
        None,
        None,
    )
    .with_accepted_launch_profile(AcceptedLaunchProfileInput::new(
        accepted,
        profile_id,
        resolved,
        topology_revision,
        resource_types,
    ));
    let mut syntax = SyntaxDatabase::try_new().expect("dialogue syntax database");
    let parsed = syntax
        .parse_initial(
            SourceSnapshotId::initial(source_document.display_name().clone()),
            Arc::clone(&source_document),
            ParseOptions::default(),
        )
        .expect("dialogue attached source");
    let parsed_sources = BTreeMap::<CanonicalModulePath, ParsedSource>::from([(
        CanonicalModulePath::crate_root(),
        parsed,
    )]);
    let mut session = ProjectCompilationSession::try_new().expect("dialogue HIR database");
    run(&mut session, &project, &parsed_sources, &context)
}

