$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$publication=Get-Content "$taskTemp/checkpoint-action-payload-nominal-source.verified.json" -Raw|ConvertFrom-Json
$source=$publication.commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source publication changed'}
$owner=Get-Content "$taskTemp/action-payload-nominal-owner6-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$execution=Get-Content "$taskTemp/action-payload-nominal-execution1-20261102.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if(-not $owner.isPassingRun -or -not $execution.isPassingRun){throw 'Owner or execution did not pass'}
$gateNames=@('quality1','quality2')|ForEach-Object {$q=$_; @('check','clippy','structure')|ForEach-Object {"action-payload-nominal-$q-20261102-$_"}}
$gates=@(foreach($name in $gateNames){$receipt=Get-Content "$taskTemp/$name.json" -Raw|ConvertFrom-Json;if($receipt.exitCode -ne 0){throw "Required gate failed: $name"};[ordered]@{name=$name;receipt=$receipt}})
$graph=Get-Content "$taskTemp/action-payload-nominal.reverse-graph.json" -Raw|ConvertFrom-Json
$freeze=Get-Content "$taskTemp/action-payload-nominal-execution1-20261102.source-freeze.json" -Raw|ConvertFrom-Json
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$before=Get-Content "$taskTemp/action-payload-nominal-owner6-20261102.source-freeze.json" -Raw|ConvertFrom-Json
$old=@{};foreach($row in $before.paths){$old[$row.path]=$row.sha256}
$delta=@($freeze.paths|Where-Object {$old[$_.path] -ne $_.sha256}|ForEach-Object path)
if(@(Compare-Object $delta @('crates/arcweft-lang-hir/src/symbol/table/nominal.rs','crates/arcweft-compiler/tests/callable_execution.rs')).Count){throw 'Unexpected post-workspace-gate change'}
$untracked=@((Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json).files)
foreach($row in $untracked){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked content changed'}}
$stem='task-action-payload-owner'
$zipPath="docs/implementation/acceptance-evidence/$stem.raw.zip"
$recordPath="docs/implementation/acceptance-evidence/$stem.json"
if((Test-Path $zipPath) -or (Test-Path $recordPath)){throw 'Existing acceptance evidence'}
$files=@(Get-ChildItem $taskTemp -File|Where-Object {$_.Name -like 'action-payload-nominal-*' -or $_.Name -like 'checkpoint-action-payload-nominal-source.*'})
$files+=@(Get-ChildItem "$taskTemp/action-payload-nominal-quality1-20261102.structure-report" -File)
$files+=@(Get-ChildItem "$taskTemp/action-payload-nominal-quality2-20261102.structure-report" -File)
$files+=@(Get-Item "$taskTemp/run-action-payload-quality.ps1","$taskTemp/run-action-payload-reverse.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/audit-nextest-final-result.ps1","$taskTemp/record-action-payload-owner.ps1")
$manifest=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in ($files|Sort-Object FullName -Unique)){
    $entryName=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/')
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entryName,[IO.Compression.CompressionLevel]::Optimal)
    $manifest+=[ordered]@{entry=$entryName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try{foreach($row in $manifest){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw "Archive drift: $($row.entry)"}}}finally{$zip.Dispose()}
$record=[ordered]@{
    version=1;source=$source;publication=$publication;recordedAt=[DateTime]::UtcNow.ToString('o')
    boundary='Action-owned implicit nominal record, persistent PublicId type identity, typed channel value, shared record field/schema projection.'
    owner=$owner;nativeAndDecodedAwbc=$execution;backendConditions=2;requiredGates=$gates
    workspaceGateReuse=[ordered]@{finalInputDelta=$delta;reason='Only equivalent private method-pointer cleanup and one new compiler execution test followed the full workspace check/Clippy. Both changed owners were rechecked/linted across all targets/features; the final compiler execution case ran on the final source.'}
    reverseGraph=$graph;consumerExecution='23-package graph established; complete consumer runtime execution remains pending on this source.'
    unresolvedActionBoundary='Common callable message construction, emit/receive and their suspension/restore acceptance remain separate from record construction. No Action executable body or detached payload schema was introduced.'
    sourceInputs=$freeze.paths.Count;sourceDrift=0;originalTrackedWip=12;originalUntracked=$untracked.Count;untrackedDrift=0
    ownershipReview='HIR retains the original item/parameter/local/type anchors and one retained lexical binding. The nominal ID owns the payload definition, Sema owns field admission and persistent type identity, RuntimePlan validates the original Action PublicId/item, and LSP consumes the same declaration. Proof-header access remains crate-private. Existing large owners retain their admission/publication responsibilities; no I/O, duplicate catalog, source parser or physical-split API was added.'
    historicalCorrections=@('The original missing nominal payload regression failed before the implementation.','Two test API compile errors and the malformed-pattern fixture failure are retained; syntax correctly rejected malformed Action parameters before HIR linking.','An unannotated lower-case named-record test input recovered; the common type-directed record literal is the valid construction used by the passing semantic and Native/AWBC cases. These corrections do not weaken an existing accepted test.')
    rawArchive=[ordered]@{path=$zipPath;sha256=(Get-FileHash $zipPath).Hash.ToLowerInvariant();entries=$manifest;entryDrift=0}
}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($recordPath),($record|ConvertTo-Json -Depth 35)+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText([IO.Path]::GetFullPath($statusPath))
$generic=@($status.Split("`n")|Where-Object {$_.StartsWith('| Generic Match')})
function Replace-Row([string]$Prefix,[string]$Replacement){
    $lines=$script:status.Split("`n");$matches=0
    for($i=0;$i -lt $lines.Count;$i++){if($lines[$i].StartsWith($Prefix)){$suffix=if($lines[$i].EndsWith("`r")){"`r"}else{''};$lines[$i]=$Replacement+$suffix;$matches++}}
    if($matches -ne 1){throw "Expected one current row: $Prefix"};$script:status=$lines -join "`n"
}
Replace-Row '確認日:' "確認日: 2026-11-02。最新公開Sourceは$source。Actionの宣言署名に続き、元宣言に紐づくpayload recordと型付きチャンネル値を公開した。影響23 packageのruntime再照合は次の検証対象として確定している。既存12 tracked／6 actual untracked WIPを保持している。"
Replace-Row '| Action宣言のpayload署名解析 |' "| Action宣言・payload record／型付きチャンネル値 | **当該ownerは検証・公開済み。call構築・送受信は別境界** | Source $source。Action自身の引数・元pattern/local/typeを一つのnominal recordへ接続し、retainedの単一bindingから型を解決する。永続PublicIdが型identityを所有し、channel値は元payload型を保持する。対象10件PASS、型注釈付きrecord literal・generic関数・captureを通したNative／canonical decoded AWBCの実戻り値42を確認した。callによるmessage構築、emit／receiveの登録・停止復帰とdotted宣言例の整合は、このrecord実行から受入としない。[検証・元失敗・公開記録](acceptance-evidence/$stem.json)。 |"
Replace-Row '| 共有契約／推移的逆依存matrix |' "| 共有契約／推移的逆依存matrix | **最新payload Sourceの23 package graphを確定。runtime照合は未実行** | HIR／Sema／RuntimePlan／LSPから全normal・dev・build・target edgeを辿った23 packageを次の実行範囲とする。直前の署名Sourceで得た通常22 packageの4327 PASS、Generic Match151／View値40 PASSは[履歴原本](acceptance-evidence/task-action-declaration-consumers.json)に保持し、今回の再実行件数へ合算しない。[現在のgraphとowner入力](acceptance-evidence/$stem.json)。 |"
Replace-Row '| CLI全target照合 |' '| CLI全target照合 | **直前Sourceは660 PASS／33 FAIL。最新payload Sourceは未再実行** | 直前の署名Sourceはbase e16d141a60faaa4b3c758bb270bcc5ca265691ac・4082入力、all-target／all-feature／lockedで693件を全実行（22 slow、23 ignored）、Source／case／EXE差分0だった。失敗33 IDと現在stderrを[原本](acceptance-evidence/task-action-declaration-consumers.json)へ保持する。最新payload Sourceの結果と取り違えず、別機能の受入済み判定も維持する。 |'
Replace-Row '| workspace check／Clippy・fmt・構造gate |' "| workspace check／Clippy・fmt・構造gate | **payload契約の全98 package gateと、最終2 pathのowner gateは終了0。警告は残存** | 4082入力でworkspace all-target／all-feature／locked check・Clippy・構造gateを確認した。続く差分はHIR private実装の等価なmethod-pointer整理とCompiler実行testの2 pathだけで、最終入力のHIR／Compiler all-target・all-feature check／Clippy・構造gateも終了0。対象fmtとNative／decoded AWBC実行を確認し、全98の再実行とは区別する。[各epoch・入力差分・ownerレビュー](acceptance-evidence/$stem.json)。 |"
if(@(Compare-Object $generic @($status.Split("`n")|Where-Object {$_.StartsWith('| Generic Match')})).Count){throw 'Accepted Generic Match row changed'}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($statusPath),$status,[Text.UTF8Encoding]::new($false))
$historyPath=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md')
$historyBefore=[IO.File]::ReadAllBytes($historyPath)
$append="`n`n## Action payload recordのowner公開 — 2026-11-02`n`nSource $source（親$($publication.parent)）を通常commit／non-forced pushし、21 pathのblob・tree・patchを照合した。元のAction nominal未公開は再現失敗後に修復し、対象10件とNative／decoded AWBCの実戻り値42を確認した。共通record、generic関数、capture、宣言と異なるfield順を通した実行である。callによるmessage構築・emit／receive・保存復元の受入へ広げない。全98 gateの後の2 path差分は限定再検証と区別し、全23 consumer runtimeは次の入力で未実行と記録する。`n`n訂正理由: 宣言署名の公開済み判定を維持した上で、payload ownerの新しい成立範囲を現状一覧へ追加した。旧23 package／CLI 693件の実測は前Sourceの履歴であり、最新Sourceの実行済み件数として重複掲示しない。Generic Match受入行は変更していない。初回失敗・テストfixture/API修正・全full SHA・実rawは[owner原本](acceptance-evidence/$stem.json)に保持する。`n"
$bytes=[Text.Encoding]::UTF8.GetBytes($append);$stream=[IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write);try{$stream.Write($bytes)}finally{$stream.Dispose()}
$historyAfter=[IO.File]::ReadAllBytes($historyPath)
$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
[ordered]@{source=$source;archiveEntries=$manifest.Count;archiveBytes=(Get-Item $zipPath).Length;historyPrefixDrift=0;genericRowDrift=0;sourceInputDrift=0;consumerRuntime='pending'}|ConvertTo-Json
