$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -AsHashtable -Depth 100 }
$sources=[ordered]@{
 model=Read-Record 'font-family-model-checkpoint.verified'
 associatedConstructors=Read-Record 'font-family-associated-constructor-checkpoint.verified'
 consumers=Read-Record 'font-family-consumer-tests-checkpoint.verified'
}
if((git rev-parse HEAD).Trim() -ne $sources.consumers.commit){throw 'Unexpected source HEAD'}
$runs=@(foreach($stem in @('font-family-source-owner2-20261105','font-family-source-owner3-20261105','font-family-source-owner5-20261105','font-family-source-owner6-20261105','font-family-source-owner7-20261105','font-family-source-owner8-20261105','font-family-data-owner1-20261105','font-family-data-owner2-20261105','font-family-cli-owner1-20261105','font-family-codec-rejections2-20261105')) {
 [ordered]@{stem=$stem;command=(Read-Record "$stem.runtime").command;terminal=Read-Record "$stem.runtime.terminal-audit"}
})
if($runs[5].terminal.passed -ne 10 -or $runs[6].terminal.failed -ne 4 -or $runs[7].terminal.passed -ne 354 -or $runs[8].terminal.passed -ne 1 -or $runs[9].terminal.passed -ne 1){throw 'Unexpected owner results'}
$compileAttempts=@(foreach($name in @('font-family-context1-20261105','font-family-context2-20261105','font-family-context3-20261105','font-family-owner1-20261105.catalog','font-family-source-owner4-20261105.catalog','font-family-codec-rejections1-20261105.catalog')) {Read-Record $name})
$files=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {$_.Name -like 'font-family*' -and $_.Name -notlike 'font-family-workspace-quality*'})
$files+=@(Get-Item -LiteralPath "$taskTemp/record-font-family-owners.ps1","$taskTemp/run-font-family-check.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/audit-nextest-final-result.ps1")
. "$taskTemp/write-verified-evidence-archive.ps1"
$rawPath='docs/implementation/acceptance-evidence/task-rich-text-font-family-owners.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('fontFamily')){throw 'Preserve existing evidence'}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$oldRow=@($status -split "`n" | Where-Object { $_.StartsWith('| RichTextの部分layout指定／source factory |') })
$record.fontFamily=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$sources.consumers.commit;sources=$sources
 state='Typed FontFamily source/model/codec and owner consumers published and validated at the stated boundaries. Full48 reverse closure, workspace quality and Native-Web parity are separate pending validation; do not infer whole-engine completion.'
 ownership='Presentation owns RichTextFontFamily<S>, the five generic cases and named(String) case, ordinals and256 UTF-8-byte name bound. TextModel reexports this type. Direct and reusable Content font schemas share one FontFamily kind and limit policy. Source bare serif/sans_serif/monospace/cursive/fantasy remain distinct from quoted named values including "serif". All owned contract markers remain1.'
 projection='Sema registers the accepted closed FontFamily domain and preserves literal/constructor identity through typed/alias/generic calls, generated instances and all-six-case match. Compiler projects actual closed nominal types/values from the analysis schema; Dialogue stores tuple(U32 ordinal,String name), borrows and validates before copying; TextModel, renderer and proxy fields preserve the same family distinction. No source-text guessing, font-name special cases, Core RuntimeValue addition, compatibility reader or Cargo dependency change.'
 associatedConstructorRepair='Shared registered closed-enum associated resolution now uses the actual type receiver and existing EnumConstructor owner. Owner/schema/result constraints, C2 VariantHead facts, semantic-only type receiver admission, accepted type reports and execution projection agree. Ordinary retained type receivers are not rewritten as variant heads. Applies to registered enum constructors generally, not FontFamily factory names.'
 limits='Use the original direct-font256-byte maximum for the shared typed named family, rather than the former reusable-font generic4096-byte String allowance. This prevents direct/reusable/runtime factories from disagreeing about one family domain. Names must be nonempty; exact256 bytes admitted,257 and86 three-byte Japanese characters rejected. Original4097-byte negative, program/result ownership, production property-input maximum and small max_string_bytes checks remain.'
 runs=$runs;compileAttempts=$compileAttempts
 failureHistory=@(
  'Context1 check101:13 missing exhaustive scalar/kind consumers; migrated all typed encoders and unsupported Fx classifications. Context2 check101:proxy scalar query match missing; added typed JSON comparison. Context3 check0 predates final limits/match/tests and is not final-source workspace quality.',
  'First broad owner catalog101:rustc reported arcweft_lang_sema rlib not found while building untouched Compiler generic_continuation_snapshot. No runtime executed; cause unestablished. No ICE/cache/resource explanation is asserted.',
  'Source2:8PASS2FAIL unknown associated named constructor. Source3:8PASS2FAIL MalformedSchemaInventory. Source4 catalog101 Arc candidate borrowing E0308. Source5:8PASS2FAIL WrongPayloadFamily. Source6:8PASS2FAIL TypeResolutionReportMismatch. Shared typed owner/constraint/receiver fixes preserve the complete failure logs.',
  'Source7:9PASS1FAIL. All-six-case match passed; the remaining case was an extra FontFamily::named test form I introduced after the model cut. This untyped namespace path is not the adopted associated-dot grammar. Restore canonical FontFamily.named(name), retaining dynamic named, foreign enum and all invalid-name rejection assertions. Source8 is10/10PASS with Native and decoded AWBC public JSON restore after every OneOp step.',
  'Data-owner1:352run348PASS4FAIL, old Font Text fixtures3 and old direct Text/enum_values expectation1. Migrate fixtures to typed Named and schema to FontFamily, preserve original ownership/save/resource assertions. Separate data-owner2:354/354PASS, not a recomputed352 run.',
  'Actual Native CLI:1/1PASS487skip, seven sources (all five generic families, quoted serif and quoted Noto Sans JP), exact typed catalog family plus nonempty image and original source range. Does not require distinct pixels for fallback fonts.',
  'Malformed stored-font rejection test first catalog101:E0283 from redundant Into on an impl Into argument. Remove only the ambiguous conversion. Separate final1/1PASS75skip rejects erased Text, generic-with-name, empty named, unknown/max ordinals, oversized name, missing tuple field and wrong integer width through owned and borrowed codecs.'
 )
 graph=Read-Record 'font-family.graph'
 validationScope='Source8 ten cases: original five source-factory cases plus four new generic/named constructor/function/generated-instance/match cases and one compiler template JSON case. Native and canonical decoded AWBC keep the existing512-step/OneOp bounds; AWBC public JSON save/restore occurs after every step. Data354 and later codec1 are independent runs. No synthetic aggregate or full-closure claim.'
 workingTree='Original12 tracked WIP patch SHA25646402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac and6 original untracked files retained; tests observe the working tree, not pristine HEAD.'
 correctionReason='Supersedes the current-list pending typed bare serif statement with published typed source/owner results. Retain every failed attempt and full commit identity as history; static inline_styles provenance and other CLI/parity conditions remain separate. Generic Match acceptance/publication is unchanged; a new six-case FontFamily test is additional coverage, not reopening accepted Generic Match.'
 supersededCurrentRows=$oldRow
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$fontRow='| RichTextの型付きFontFamily | **Source・codec・owner consumerを検証・公開済み。全逆依存は検証中** | 型owner '+$sources.model.commit+'、共通associated constructor修復 '+$sources.associatedConstructors.commit+'、fixture／consumer検査 '+$sources.consumers.commit+'。generic 5種とnamedを区別し、Source direct／alias／typed・generic関数／生成instance／全6case matchをNative・各step公開JSON保存復元するAWBCで10／10 PASS。下位5 owner354／354、実Native CLIの7指定を含む1／1、改変codec拒否の別1／1がPASS。元の所有権・保存・予算・リソース制限を維持し、旧Text fixtureの4失敗と各途中失敗は履歴に保持する。全48逆依存・workspace quality・Native-Web parityをこのowner結果だけで完了としない。[訂正理由・全実測・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
$rows=@(foreach($line in ($status -split "`n")) {
 if($line.StartsWith('| RichTextの部分layout指定／source factory |')) {$line.Replace('typed bare serif、static inline_styles出典','static inline_styles出典')}
 elseif($line.StartsWith('| Generic Match `.1.2` C3/C5 |')) {$fontRow;$line}
 else {$line}
})
if(@($rows | Where-Object {$_ -eq $fontRow}).Count -ne 1){throw 'Missing unique Font current row'}
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$prefixHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()
$append=@"

## 2026-11-05 — Typed FontFamily source and owner consumers

- Published model $($sources.model.commit), shared associated-constructor repair $($sources.associatedConstructors.commit), and consumer fixtures/tests $($sources.consumers.commit). Presentation owns the single generic/named family algebra and256-byte bound; quoted serif remains Named. Shared enum owner/constraint/receiver/projection rules support dynamic FontFamily.named(name) without factory-name special cases.
- Preserve all actual attempts: context checks101/101/0; first owner catalog101 with missing rlib (cause unknown, no runtime); Source2/3/5/6 each8PASS2FAIL; Source4 catalog101; Source7 9PASS1FAIL from the extra unadopted ::named fixture, corrected to canonical dot grammar with every rejection retained; Source8 10/10PASS. Data-owner1 348PASS4FAIL out of352: three Text fixtures and one Text schema expectation were stale. Separate data-owner2 354/354PASS retains ownership/save/resource assertions. Native CLI1/1PASS covers seven font sources, actual catalog and nonempty images. Codec rejection catalog first failed on redundant ambiguous Into; final1/1PASS rejects malformed payloads through both owned and borrowed codecs. Never combine these runs or erase failures.
- Supersedes only the old pending typed bare serif statement in the current list. Static inline provenance, remaining CLI conditions and final parity remain separate. Fresh metadata and invert trees agree on48 reverse packages; workspace quality and that full runtime selection are not yet accepted. Generic Match remains accepted/public under850534b9e9bc8c8872f6528dd00050a5e6e7699e / f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2. [Exact receipts, full source/patch identities and raw archive](acceptance-evidence/task-rich-text-property-identity.json); [one current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous evidence changed'}}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixHash){throw 'History changed'}
[ordered]@{sources=@($sources.Values | ForEach-Object {$_.commit});priorFieldDrift=0;historyPrefixDrift=0;raw=$record.fontFamily.raw}|ConvertTo-Json -Depth 6
