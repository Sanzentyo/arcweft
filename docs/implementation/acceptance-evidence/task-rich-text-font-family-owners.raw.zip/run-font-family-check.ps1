param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
if(Test-Path -LiteralPath "$taskTemp/$Stem.json"){throw 'Receipt already exists'}
$previous=Get-Content -LiteralPath "$taskTemp/cli-jlreq-logical-pixels-repair1-20261105.source-freeze.json" -Raw | ConvertFrom-Json
$paths=@($previous.paths.path)+@('crates/arcweft-presentation/src/rich_text/font_family.rs','crates/arcweft-compiler/src/lower/literal.rs') | Sort-Object -Unique
$freeze=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();held=$previous.held;paths=@(foreach($path in $paths){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})}
$freeze|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/$Stem.source-freeze.json" -Encoding utf8
$arguments=@('check','-p','arcweft-compiler','-p','arcweft-text-model','--all-targets','--all-features','--locked')
$started=[DateTime]::UtcNow.ToString('o')
& cargo @arguments *> "$taskTemp/$Stem.log"
$code=$LASTEXITCODE
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Frozen source changed: $($row.path)"}}
[ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath "$taskTemp/$Stem.json" -Encoding utf8
Get-Content -LiteralPath "$taskTemp/$Stem.json" -Raw
exit $code
