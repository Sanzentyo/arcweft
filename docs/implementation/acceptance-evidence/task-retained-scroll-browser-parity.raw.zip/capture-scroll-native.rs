use arcweft_core::plan::EntryRuntimeId;
use arcweft_layout::ScalePolicy;
use arcweft_player_scene::{
    fonts::{DEFAULT_PLAYER_EMOJI_FONT_BYTES, DEFAULT_PLAYER_JAPANESE_FONT_BYTES},
    frame::{PlayerFrameFit, PlayerFramePlannerState, PlayerFrameRequest, PlayerFrameTime},
    images::BundleImageCatalog,
    input::InputController,
};
use arcweft_render_wgpu::{
    geometry::{PreparedFrame, RenderPreferences, RenderViewport},
    offscreen::{CaptureAttachment, CaptureRequest, SharedOffscreenCapture},
};
use arcweft_runtime_driver::{
    clock::RuntimeClockStep,
    session::{BundleSession, BundleSessionOptions, BundleStepInput},
};
use std::{error::Error, fs, path::Path};
const STEP_MILLIS: u32 = 16;

fn main() -> Result<(), Box<dyn Error>> {
    let directory = std::env::args_os().nth(1).ok_or("missing capture directory")?;
    let directory = Path::new(&directory);
    let bundle = fs::read(directory.join("scroll-fixture-probe2-typed.awfb"))?;
    let options = BundleSessionOptions {
        entry: Some(EntryRuntimeId::from_source_entity_body("entry.scroll_agent_parity")?),
        ..BundleSessionOptions::default()
    };
    let (mut session, artifact) = BundleSession::from_awfb_bytes_with_bundle(&bundle, options)?;
    let images = BundleImageCatalog::from_bundle(artifact.bundle())?;
    let fonts = [
        DEFAULT_PLAYER_JAPANESE_FONT_BYTES.to_vec(),
        DEFAULT_PLAYER_EMOJI_FONT_BYTES.to_vec(),
        fs::read("web/assets/arcweft-demo.ttf")?,
    ];
    let mut planner = PlayerFramePlannerState::new();
    let mut input = InputController::default();
    let mut capture = pollster::block_on(SharedOffscreenCapture::new(wgpu::TextureFormat::Rgba8Unorm))?;
    for font in fonts {
        planner.register_font_bytes(font.clone())?;
        capture.register_font_bytes(font)?;
    }
    let viewport = RenderViewport {
        logical_width: 1280.0,
        logical_height: 720.0,
        physical_width: 1280,
        physical_height: 720,
        scale_factor: 1.0,
    };
    let mut region_id = None;
    for tick in 1..=5 {
        session.step_with_clock(RuntimeClockStep::from_millis(tick, STEP_MILLIS)?, BundleStepInput::default());
        let style_environment = session.presentation_environment();
        let candidate = planner.prepare_candidate(
            &input,
            PlayerFrameRequest {
                presentation: session.presentation(),
                fx_definitions: session.fx_definitions(),
                images: &images,
                style_program: session.view_style_program(),
                style_environment: &style_environment,
                style_palettes: session.view_style_palettes(),
                viewport,
                fit: PlayerFrameFit::design_1280x720(ScalePolicy::Contain),
                time: PlayerFrameTime::runtime(tick * u64::from(STEP_MILLIS)),
                preferences: RenderPreferences::default(),
            },
        )?;
        let (frame, ()) = planner.publication_guard().publish_with(candidate, &mut input, |_| ())?;
        if tick == 3 {
            let region = frame.frame.scroll_regions.iter().find(|region| region.id.ends_with(".feedback"))
                .ok_or("authored Scroll region is absent")?;
            println!("before tick={tick} region={} bounds={:?} offset={}", region.id, region.bounds, input.scroll_offset_y(&region.id));
            write_capture(&mut capture, &frame.frame, &directory.join("native-awfb-before.png"))?;
            input.scroll_region_by_id(&frame.frame, &region.id, 0.0, -80.0);
            region_id = Some(region.id.clone());
        } else if tick == 5 {
            let id = region_id.as_deref().ok_or("missed Scroll input")?;
            let offset = input.scroll_offset_y(id);
            if offset <= 0.0 {
                return Err("native Scroll offset did not advance".into());
            }
            println!("after tick={tick} region={id} offset={offset}");
            write_capture(&mut capture, &frame.frame, &directory.join("native-awfb-after.png"))?;
        }
    }
    Ok(())
}

fn write_capture(
    capture: &mut SharedOffscreenCapture,
    frame: &PreparedFrame,
    path: &Path,
) -> Result<(), Box<dyn Error>> {
    let image = capture.capture(frame, &CaptureRequest::whole_frame_color())?;
    let rgba = image.attachment_rgba(CaptureAttachment::Color).ok_or("missing color attachment")?;
    let mut png = png::Encoder::new(fs::File::create(path)?, image.width, image.height);
    png.set_color(png::ColorType::Rgba);
    png.set_depth(png::BitDepth::Eight);
    png.write_header()?.write_image_data(rgba)?;
    Ok(())
}
