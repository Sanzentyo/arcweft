import { createReadStream } from "node:fs";
import { stat, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { createRequire } from "node:module";
import { join, extname, relative, isAbsolute, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { once } from "node:events";

const webRoot = resolve(process.argv[2], "web");
const output = resolve(process.argv[3]);
const require = createRequire(join(webRoot, "package.json"));
const { chromium } = require("playwright");
const { installManualLogicalClock, advanceLogicalClockSteps } = await import(
  pathToFileURL(join(webRoot, "tests", "manual-logical-clock.mjs"))
);
const formats = new Map([
  [".html", "text/html"], [".js", "text/javascript"], [".css", "text/css"],
  [".wasm", "application/wasm"], [".ttf", "font/ttf"], [".awfb", "application/octet-stream"],
]);
const server = createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
    if (pathname === "/favicon.ico") {
      response.writeHead(204).end();
      return;
    }
    const bundleRequest = pathname === "/fixture.awfb";
    const path = bundleRequest
      ? join(output, "scroll-fixture-probe2-typed.awfb")
      : resolve(webRoot, "." + pathname);
    const withinRoot = relative(webRoot, path);
    if ((!bundleRequest && (withinRoot === ".." || withinRoot.startsWith(".." + (process.platform === "win32" ? "\\" : "/")) || isAbsolute(withinRoot)))
      || !await stat(path).then((file) => file.isFile(), () => false)) {
      response.writeHead(404).end();
      return;
    }
    response.writeHead(200, { "content-type": formats.get(extname(path)) ?? "application/octet-stream" });
    createReadStream(path).pipe(response);
  } catch {
    response.writeHead(400).end();
  }
});
server.listen(0, "127.0.0.1");
await once(server, "listening");
let browser;
const errors = [];
const reports = [];
try {
  browser = await chromium.launch({ channel: "chrome", headless: true, args: ["--enable-unsafe-webgpu", "--use-angle=d3d11"] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
  await installManualLogicalClock(page);
  await page.goto("http://127.0.0.1:" + server.address().port + "/index.html?bundle=/fixture.awfb&entry=entry.scroll_agent_parity");
  await page.waitForFunction(() => Boolean(window.__arcweftFatal) || (
    document.querySelector("#arcweft-canvas")?.dataset.arcweftReady === "true" &&
    Number.isSafeInteger(window.__arcweftLastObservation?.logical_tick)
  ), null, { timeout: 30_000 });
  let state = await page.evaluate(() => ({
    fatal: window.__arcweftFatal ?? null,
    observation: window.__arcweftLastObservation,
    gpu: Boolean(navigator.gpu),
    browser: navigator.userAgent,
  }));
  if (state.fatal || !state.gpu) throw new Error(JSON.stringify(state.fatal ?? state));
  const capture = async (name) => {
    const canvas = page.locator("#arcweft-canvas");
    await canvas.screenshot({ path: join(output, name + ".png"), omitBackground: true });
    const snapshot = await page.evaluate(() => ({
      fatal: window.__arcweftFatal ?? null,
      observation: window.__arcweftLastObservation,
      frame: window.__arcweftLastFrameObservation,
      geometry: {
        canvasWidth: document.querySelector("#arcweft-canvas").width,
        canvasHeight: document.querySelector("#arcweft-canvas").height,
        devicePixelRatio: window.devicePixelRatio,
      },
    }));
    if (snapshot.fatal || !snapshot.frame) throw new Error(JSON.stringify(snapshot.fatal ?? snapshot));
    reports.push({ name, ...snapshot });
  };
  const remaining = 3 - state.observation.logical_tick;
  if (remaining < 0) throw new Error("startup passed tick 3");
  if (remaining > 0) await advanceLogicalClockSteps(page, remaining);
  await capture("web-before");
  await page.mouse.move(82, 86);
  await page.mouse.wheel(0, 80);
  await advanceLogicalClockSteps(page, 2);
  await capture("web-after");
  if (errors.length) throw new Error(errors.join("\n"));
  await writeFile(join(output, "web.json"), JSON.stringify({ browser: browser.version(), userAgent: state.browser, reports }, null, 2));
  for (const report of reports) {
    console.log(JSON.stringify({ name: report.name, tick: report.observation.logical_tick, ...report.geometry, frameKeys: Object.keys(report.frame) }));
  }
} catch (error) {
  await writeFile(join(output, "web-error.json"), JSON.stringify({ error: String(error), errors, reports }, null, 2));
  throw error;
} finally {
  if (browser) await browser.close();
  server.close();
}
