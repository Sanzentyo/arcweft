//! Consuming agreement of correlated original roots, before value-use Fits.

#[cfg(test)]
mod tests;

use super::super::{ConstraintInferenceBranch, DeferredCycleWitness};
use super::*;
use crate::effect_row::{EffectConstraintEnvironment, EffectConstraintVariable};
use crate::types::{
    compatibility::binding_plan::{unify_original_binding, unify_original_length},
    constraints::{
        application::ConstraintApplicationInventory, lexical::ConstraintLexicalScope,
        normalization::seal_path,
    },
};

/// Addresses the actual retained path. Diagnostic branches cannot inhabit it.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct OriginalProductMember {
    pub(super) producer: u64,
    pub(super) frontier: usize,
    pub(super) path: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) enum OriginalProductCheck {
    TypeBinding {
        member: OriginalProductMember,
        parameter: GenericTypeReference,
    },
    ConstBinding {
        member: OriginalProductMember,
        parameter: GenericConstReference,
    },
    EffectRelation(OriginalProductMember),
    Completion,
}

pub(super) struct OriginalProductRejection {
    pub(super) check: OriginalProductCheck,
    pub(super) reason: TypeConstraintRejection,
}

type JointBranch<D> = ConstraintInferenceBranch<D, Arc<[OriginalProductMember]>>;

pub(super) struct OriginalProductSolution<D: ConstraintDomain> {
    pub(super) branch: JointBranch<D>,
    pub(super) effects: crate::effect_row::EffectConstraintCompletion,
}

pub(super) struct OriginalProductInference<D: ConstraintDomain> {
    pub(super) members: Arc<[OriginalProductMember]>,
    pub(super) scope: ConstraintLexicalScope,
    pub(super) result: Result<Box<[OriginalProductSolution<D>]>, OriginalProductRejection>,
}

/// Owns the unchanged original producer/source forest and its separate inferred
/// products. No later use is an inference input, selector or applicability fact.
pub(crate) struct OriginalConstraintForest<D: ConstraintDomain, P> {
    pub(super) original: OpenConstraintComponent<D, P>,
    pub(super) products: Box<[OriginalProductInference<D>]>,
}

impl<D: ConstraintDomain, P> OpenConstraintComponent<D, P> {
    /// Enumerates only complete products of real original candidate paths.
    /// Rejected/ambiguous producer states are derived diagnostics, never extra
    /// witnesses with an empty effect row. Original rejections retain addresses.
    pub(crate) fn infer_original_products<A: TypeConstraintAccounting>(
        self,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<OriginalConstraintForest<D, P>, PreparedValueFailure> {
        context.check_cancelled()?;
        if self.has_live_uses() {
            return Err(PreparedValueFailure::UseState);
        }
        let mut axes = Vec::new();
        for (producer, value) in &self.values {
            context.enter_node()?;
            let ValueDefinition::Constraint { frontiers, .. } = &value.definition else {
                continue;
            };
            let mut members = Vec::new();
            for (frontier, root) in frontiers.iter().enumerate() {
                for path in 0..root.transaction.frontier.len() {
                    context.enter_node()?;
                    members.push(OriginalProductMember {
                        producer: *producer,
                        frontier,
                        path,
                    });
                }
            }
            context.enter_node()?;
            axes.push(members);
        }
        let mut products = Vec::new();
        if axes.iter().all(|axis| !axis.is_empty()) {
            for _ in &axes {
                context.enter_node()?;
            }
            let mut positions = vec![0; axes.len()];
            loop {
                let mut members = Vec::new();
                for (axis, position) in axes.iter().zip(&positions) {
                    context.enter_node()?;
                    members.push(axis[*position]);
                }
                context.enter_node()?;
                let members: Arc<[OriginalProductMember]> = members.into();
                let mut scope = ConstraintLexicalScope::default();
                for member in members.iter() {
                    scope.merge(&self.original_path(*member)?.lineage.scope, context)?;
                }
                for _ in scope.shape().binders() {
                    context.enter_node()?;
                }
                let result = match context.with_original_scope(scope.clone(), |context| {
                    self.infer_original_product(&members, &scope, context)
                }) {
                    Ok(solutions) => Ok(solutions),
                    Err(OriginalInferenceFailure::Rejected(rejection)) => Err(rejection),
                    Err(OriginalInferenceFailure::Constraint(error)) => return Err(error.into()),
                    Err(OriginalInferenceFailure::Instantiation(error)) => return Err(error.into()),
                };
                context.enter_node()?;
                products.push(OriginalProductInference {
                    members,
                    scope,
                    result,
                });
                let mut depth = positions.len();
                while depth > 0 {
                    context.enter_node()?;
                    depth -= 1;
                    positions[depth] += 1;
                    if positions[depth] < axes[depth].len() {
                        break;
                    }
                    positions[depth] = 0;
                }
                if positions.iter().all(|position| *position == 0) {
                    break;
                }
            }
        }
        context.check_cancelled()?;
        Ok(OriginalConstraintForest {
            original: self,
            products: products.into_boxed_slice(),
        })
    }

    fn original_path(
        &self,
        member: OriginalProductMember,
    ) -> Result<&ConstraintPath<D>, TypeConstraintError> {
        let value = self
            .values
            .get(&member.producer)
            .expect("product member is issued from this frozen inventory");
        let ValueDefinition::Constraint { frontiers, .. } = &value.definition else {
            unreachable!("product axes contain only original constraints")
        };
        Ok(&frontiers[member.frontier].transaction.frontier[member.path])
    }

    fn infer_original_product<A: TypeConstraintAccounting>(
        &self,
        members: &Arc<[OriginalProductMember]>,
        scope: &ConstraintLexicalScope,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<Box<[OriginalProductSolution<D>]>, OriginalInferenceFailure> {
        let mut applications = ConstraintApplicationInventory::empty();
        for member in members.iter() {
            applications.merge_original(&self.original_path(*member)?.applications, context)?;
        }
        let mut variables = BTreeMap::new();
        for member in members.iter() {
            for variable in self.original_path(*member)?.effects.original_variables() {
                context.enter_node()?;
                let eligibility = applications.effect_eligibility(variable).ok_or_else(|| crate::types::constraints::effect_invariant(crate::types::constraints::TypeConstraintEffectInvariantKind::ForeignVariable, Some(variable.clone())))?;
                variables.insert(variable.clone(), eligibility);
            }
        }
        let mut rows = Vec::new();
        for (variable, eligibility) in variables {
            context.enter_node()?;
            rows.push(EffectConstraintVariable::new(variable, eligibility));
        }
        let mut effects =
            EffectConstraintEnvironment::new(&rows).map_err(TypeConstraintError::from)?;
        for member in members.iter() {
            let path = self.original_path(*member)?;
            let predicate = scope
                .transport_predicate(
                    &path.lineage.scope,
                    path.effects.original_predicate(),
                    context,
                )
                .map_err(projection_failure)?;
            effects
                .restore_predicate(&predicate, context)
                .map_err(|error| reject(OriginalProductCheck::EffectRelation(*member), error))?;
        }
        context.enter_node()?;
        let seed = ConstraintInferenceBranch {
            lineage: Arc::clone(members),
            applications: Arc::new(applications),
            bindings: BTreeMap::new(),
            const_bindings: BTreeMap::new(),
            effects,
            equations: Vec::new(),
            choice_key: Vec::new(),
            deferred_cycles: DeferredCycleWitness::default(),
        };
        let mut branches = vec![seed];
        for member in members.iter() {
            let original = self.original_path(*member)?;
            for (parameter, value) in &original.bindings {
                context.enter_node()?;
                let value = scope
                    .transport_type(&original.lineage.scope, value, context)
                    .map_err(projection_failure)?;
                let check = OriginalProductCheck::TypeBinding {
                    member: *member,
                    parameter: parameter.clone(),
                };
                let mut next = Vec::new();
                for branch in branches {
                    match unify_original_binding(
                        &TypeKind::GenericParam(parameter.clone()),
                        &value,
                        branch,
                        context,
                    ) {
                        Ok(paths) => next.extend(paths),
                        Err(error) => return Err(reject(check, error)),
                    }
                }
                if next.is_empty() {
                    return Err(reject(check, TypeConstraintRejection::Mismatch.into()));
                }
                branches = next;
            }
            for (parameter, value) in &original.const_bindings {
                context.enter_node()?;
                let value = scope
                    .transport_length(&original.lineage.scope, value, context)
                    .map_err(projection_failure)?;
                let check = OriginalProductCheck::ConstBinding {
                    member: *member,
                    parameter: parameter.clone(),
                };
                let mut next = Vec::new();
                for branch in branches {
                    match unify_original_length(
                        &ArrayLength::Generic(parameter.clone()),
                        &value,
                        branch,
                        context,
                    ) {
                        Ok(Some(path)) => next.push(path),
                        Ok(None) => {}
                        Err(error) => return Err(reject(check, error)),
                    }
                }
                if next.is_empty() {
                    return Err(reject(check, TypeConstraintRejection::Mismatch.into()));
                }
                branches = next;
            }
        }
        let mut solutions = Vec::new();
        for branch in branches {
            let branch = seal_path(branch, context)
                .map_err(|error| reject(OriginalProductCheck::Completion, error))?;
            context
                .validate_type_and_const_completion(&branch)
                .map_err(|error| reject(OriginalProductCheck::Completion, error))?;
            let effects = branch
                .effects
                .complete(context)
                .map_err(|error| reject(OriginalProductCheck::Completion, error))?;
            self.validate_original_bindings(
                &branch,
                members,
                scope,
                &effects.substitution,
                context,
            )?;
            context.enter_node()?;
            solutions.push(OriginalProductSolution { branch, effects });
        }
        Ok(solutions.into_boxed_slice())
    }

    fn validate_original_bindings<A: TypeConstraintAccounting>(
        &self,
        branch: &JointBranch<D>,
        members: &[OriginalProductMember],
        scope: &ConstraintLexicalScope,
        effects: &crate::effect_row::EffectSubstitution,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<(), OriginalInferenceFailure> {
        let project = |ty: &TypeKind, context: &mut TypeConstraintContext<'_, A, D>| {
            crate::types::constraints::seal_type(ty, branch.projection_view(), &mut std::collections::BTreeSet::new(), context)?
                .substitute_effect_rows(effects)
                .map_err(|_| crate::types::constraints::effect_invariant(crate::types::constraints::TypeConstraintEffectInvariantKind::NonCanonicalInherited, None))
        };
        for member in members {
            let original = self.original_path(*member)?;
            for (parameter, value) in &original.bindings {
                context.enter_node()?;
                let check = OriginalProductCheck::TypeBinding {
                    member: *member,
                    parameter: parameter.clone(),
                };
                let value = scope
                    .transport_type(&original.lineage.scope, value, context)
                    .map_err(projection_failure)?;
                let left = project(&TypeKind::GenericParam(parameter.clone()), context)?;
                let right = project(&value, context)?;
                if !crate::types::constraints::completed_types_equal(&left, &right, context)? {
                    return Err(reject(check, TypeConstraintRejection::Mismatch.into()));
                }
            }
            for (parameter, value) in &original.const_bindings {
                context.enter_node()?;
                let check = OriginalProductCheck::ConstBinding {
                    member: *member,
                    parameter: parameter.clone(),
                };
                let value = scope
                    .transport_length(&original.lineage.scope, value, context)
                    .map_err(projection_failure)?;
                let left = crate::types::constraints::normalization::seal_const(
                    &ArrayLength::Generic(parameter.clone()),
                    branch.projection_view(),
                    &mut std::collections::BTreeSet::new(),
                    context,
                )?;
                let right = crate::types::constraints::normalization::seal_const(
                    &value,
                    branch.projection_view(),
                    &mut std::collections::BTreeSet::new(),
                    context,
                )?;
                if left != right {
                    return Err(reject(check, TypeConstraintRejection::Mismatch.into()));
                }
            }
        }
        Ok(())
    }
}

enum OriginalInferenceFailure {
    Rejected(OriginalProductRejection),
    Constraint(TypeConstraintError),
    Instantiation(TypeInstantiationError),
}

impl From<TypeConstraintError> for OriginalInferenceFailure {
    fn from(error: TypeConstraintError) -> Self {
        Self::Constraint(error)
    }
}

fn reject(check: OriginalProductCheck, error: TypeConstraintError) -> OriginalInferenceFailure {
    match error {
        TypeConstraintError::Rejected(reason) => {
            OriginalInferenceFailure::Rejected(OriginalProductRejection { check, reason })
        }
        error => OriginalInferenceFailure::Constraint(error),
    }
}

fn projection_failure(error: TypeProjectionError<TypeConstraintError>) -> OriginalInferenceFailure {
    match error {
        TypeProjectionError::Control(error) => OriginalInferenceFailure::Constraint(error),
        TypeProjectionError::Instantiation(error) => OriginalInferenceFailure::Instantiation(error),
    }
}
