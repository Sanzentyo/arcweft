use super::*;
use crate::{
    effect_row::EffectRow,
    effects::EffectSet,
    types::{
        DetachedGenericOwnerId, GenericBinder, GenericConstParameterId, GenericParameterOwnerId,
        GenericTypeParameterId,
        constraints::{
            ConstraintAcceptance, NoConstraintClient, TypeConstraintConstEligibility,
            TypeConstraintEffectScope, TypeConstraintParameterEligibility,
            TypeConstraintParameterScope, TypeConstraintProjectionClosure,
            context::{
                LocalConstraintAccounting, TypeConstraintConstParameterScopeRow,
                TypeConstraintLimits, TypeConstraintTypeParameterScopeRow,
            },
            test_support::ConstraintTestSetup,
            transaction::TypeConstraintTransaction,
        },
    },
};
use std::sync::atomic::{AtomicBool, Ordering};

type Context<'a> = TypeConstraintContext<'a, LocalConstraintAccounting<'a>, NoConstraintClient>;
type Component = OpenConstraintComponent<NoConstraintClient, &'static str>;

fn context(cancellation: &AtomicBool) -> Context<'_> {
    ConstraintTestSetup::new(
        TypeConstraintLimits::new(65536, 65536, 1024, 1024),
        cancellation,
    )
    .into_parts()
    .0
}

fn parameters(
    types: u16,
    lengths: u16,
) -> (
    TypeConstraintParameterScope,
    Vec<GenericTypeReference>,
    Vec<GenericConstReference>,
) {
    let owner = GenericParameterOwnerId::Detached(DetachedGenericOwnerId::new(9481));
    let types: Vec<_> = (0..types)
        .map(|slot| GenericTypeParameterId::new(owner.clone(), slot))
        .collect();
    let lengths: Vec<_> = (0..lengths)
        .map(|slot| GenericConstParameterId::new(owner.clone(), slot))
        .collect();
    let scope = TypeConstraintParameterScope::seal_call_scope(
        GenericBinder::EMPTY,
        types.iter().map(|parameter| {
            TypeConstraintTypeParameterScopeRow::new(
                parameter.clone(),
                TypeConstraintParameterEligibility::Bindable,
            )
        }),
        lengths.iter().map(|parameter| {
            TypeConstraintConstParameterScopeRow::new(
                parameter.clone(),
                TypeConstraintConstEligibility::Bindable,
            )
        }),
        TypeConstraintEffectScope::seal_call_scope([], []).unwrap(),
        [],
        [],
    )
    .unwrap();
    let types = types
        .into_iter()
        .map(|parameter| scope.type_reference(&parameter.into()).unwrap())
        .collect();
    let lengths = lengths
        .into_iter()
        .map(|parameter| scope.const_reference(&parameter.into()).unwrap())
        .collect();
    (scope, types, lengths)
}

fn frontier(
    context: &mut Context<'_>,
    scope: TypeConstraintParameterScope,
    equations: &[(TypeKind, TypeKind)],
) -> SuspendedConstraintFrontier<NoConstraintClient> {
    let mut lower = TypeConstraintTransaction::initialize(context, (), scope, None).unwrap();
    for (pattern, actual) in equations {
        lower.constrain(
            context,
            pattern,
            actual,
            ConstraintAcceptance::PatternAcceptsActual,
        );
    }
    lower.request_projection(
        context,
        (),
        &TypeKind::I64,
        TypeConstraintProjectionClosure::Closed,
    );
    lower.suspend_result(context, ()).unwrap()
}

fn array(length: ArrayLength) -> TypeKind {
    TypeKind::Array {
        item: Box::new(TypeKind::Bool),
        len: length,
    }
}

#[test]
fn shared_original_type_and_const_aliases_are_unified_without_overwriting_either_root() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let (scope, ty, length) = parameters(2, 2);
    let first = frontier(
        &mut context,
        scope.clone(),
        &[
            (
                TypeKind::GenericParam(ty[0].clone()),
                TypeKind::GenericParam(ty[1].clone()),
            ),
            (
                array(ArrayLength::Generic(length[0].clone())),
                array(ArrayLength::Generic(length[1].clone())),
            ),
        ],
    );
    let first = component
        .admit_roots(&mut context, vec![first], "T=U,N=M")
        .unwrap();
    let second = frontier(
        &mut context,
        scope,
        &[
            (TypeKind::GenericParam(ty[0].clone()), TypeKind::Bool),
            (
                array(ArrayLength::Generic(length[0].clone())),
                array(ArrayLength::Const(7)),
            ),
        ],
    );
    component
        .admit_roots(&mut context, vec![second], "T=bool,N=7")
        .unwrap();
    let forest = component.infer_original_products(&mut context).unwrap();
    assert_eq!(forest.products.len(), 1);
    let product = &forest.products[0];
    assert_eq!(product.members.len(), 2);
    let solutions = product.result.as_ref().ok().expect("one joint MGU exists");
    assert_eq!(solutions.len(), 1);
    let solved = &solutions[0];
    assert!(Arc::ptr_eq(&solved.branch.lineage, &product.members));
    for parameter in &ty {
        assert_eq!(solved.branch.bindings.get(parameter), Some(&TypeKind::Bool));
    }
    for parameter in &length {
        assert_eq!(
            solved.branch.const_bindings.get(parameter),
            Some(&ArrayLength::Const(7))
        );
    }
    assert!(solved.effects.predicate.is_unconstrained());
    let ValueDefinition::Constraint { frontiers, .. } =
        &forest.original.value(&first).unwrap().definition
    else {
        unreachable!()
    };
    let original = &frontiers[0].transaction.frontier[0];
    assert_eq!(
        original.bindings.get(&ty[0]),
        Some(&TypeKind::GenericParam(ty[1].clone()))
    );
    assert_eq!(
        original.const_bindings.get(&length[0]),
        Some(&ArrayLength::Generic(length[1].clone()))
    );
    assert!(!original.bindings.contains_key(&ty[1]));
    assert!(!original.const_bindings.contains_key(&length[1]));
}

#[test]
fn original_products_keep_conflict_addresses_and_exclude_diagnostic_witnesses() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let (scope, ty, length) = parameters(1, 1);
    let equations = |value, count| {
        vec![
            (TypeKind::GenericParam(ty[0].clone()), value),
            (
                array(ArrayLength::Generic(length[0].clone())),
                array(ArrayLength::Const(count)),
            ),
        ]
    };
    let root = frontier(&mut context, scope.clone(), &equations(TypeKind::Bool, 3));
    component
        .admit_roots(&mut context, vec![root], "first")
        .unwrap();
    let mut roots = Vec::new();
    for (value, count) in [
        (TypeKind::Bool, 3),
        (TypeKind::String, 3),
        (TypeKind::Bool, 4),
    ] {
        roots.push(frontier(
            &mut context,
            scope.clone(),
            &equations(value, count),
        ));
    }
    let second = component
        .admit_roots(&mut context, roots, "second")
        .unwrap();
    let forest = component.infer_original_products(&mut context).unwrap();
    assert_eq!(forest.products.len(), 3);
    assert!(forest.products[0].result.is_ok());
    let failure = forest.products[1].result.as_ref().err().unwrap();
    assert!(
        matches!(&failure.check, OriginalProductCheck::TypeBinding {member,parameter} if member.producer == second.ordinal && member.frontier == 1 && parameter == &ty[0])
    );
    assert_eq!(failure.reason, TypeConstraintRejection::Mismatch);
    let failure = forest.products[2].result.as_ref().err().unwrap();
    assert!(
        matches!(&failure.check, OriginalProductCheck::ConstBinding {member,parameter} if member.producer == second.ordinal && member.frontier == 2 && parameter == &length[0])
    );
    assert_eq!(failure.reason, TypeConstraintRejection::Mismatch);
}

#[test]
fn cross_root_structural_occurs_cycles_remain_original_product_rejections() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let (scope, ty, _) = parameters(2, 0);
    for (left, right) in [(0, 1), (1, 0)] {
        let root = frontier(
            &mut context,
            scope.clone(),
            &[(
                TypeKind::GenericParam(ty[left].clone()),
                TypeKind::Tuple(vec![TypeKind::GenericParam(ty[right].clone())]),
            )],
        );
        component
            .admit_roots(&mut context, vec![root], "acyclic original")
            .unwrap();
    }
    let forest = component.infer_original_products(&mut context).unwrap();
    assert_eq!(forest.products.len(), 1);
    assert!(matches!(
        forest.products[0].result.as_ref().err().unwrap().reason,
        TypeConstraintRejection::CyclicInstantiation { .. }
    ));
    assert_eq!(forest.products[0].members.len(), 2);
}

#[test]
fn an_unchosen_original_cannot_lend_required_parameters_to_another_product() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let first = frontier(&mut context, TypeConstraintParameterScope::empty(), &[]);
    let first_id = first.transaction.application;
    let (scope, ty, _) = parameters(1, 0);
    let second = frontier(&mut context, scope, &[]);
    let second_id = second.transaction.application;
    component
        .admit_roots(&mut context, vec![first, second], "initializer")
        .unwrap();
    let forest = component.infer_original_products(&mut context).unwrap();
    assert_eq!(forest.products.len(), 2);
    let solved = &forest.products[0].result.as_ref().ok().unwrap()[0];
    assert!(solved.branch.applications.application(first_id).is_some());
    assert!(solved.branch.applications.application(second_id).is_none());
    assert!(
        matches!(&forest.products[1].result.as_ref().err().unwrap().reason,TypeConstraintRejection::IncompleteInstantiation {parameter: crate::types::constraints::ConstraintGenericParameterId::Type(parameter)} if parameter == &ty[0])
    );
    let mut component = Component::new(&mut context).unwrap();
    component
        .admit_roots(&mut context, Vec::new(), "rejected original")
        .unwrap();
    assert!(
        component
            .infer_original_products(&mut context)
            .unwrap()
            .products
            .is_empty()
    );
}

#[test]
fn identical_scope_arities_do_not_identify_independently_opened_ambient_binders() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let (scope, ty, _) = parameters(1, 0);
    for _ in 0..2 {
        let enclosing = context.enter_binder_scope(GenericBinder::new(1, 0, 0));
        let value = TypeKind::GenericParam(context.lexical_scope().bound_type(0, 0).unwrap());
        let root = frontier(
            &mut context,
            scope.clone(),
            &[(TypeKind::GenericParam(ty[0].clone()), value)],
        );
        component
            .admit_roots(&mut context, vec![root], "ambient")
            .unwrap();
        context.restore_binder_scope(enclosing);
    }
    let forest = component.infer_original_products(&mut context).unwrap();
    assert_eq!(forest.products[0].scope.shape().binders().len(), 2);
    assert_eq!(
        forest.products[0].result.as_ref().err().unwrap().reason,
        TypeConstraintRejection::Mismatch
    );
    assert!(context.lexical_scope().binders().is_empty());
}

fn scoped_function(scope: &GenericScope, ambient_depth: u32) -> TypeKind {
    let binder = GenericBinder::new(1, 1, 1);
    let nested = scope.with_binder(binder);
    TypeKind::function_with_binder(
        binder,
        [
            TypeKind::GenericParam(nested.bound_type(0, 0).unwrap()),
            TypeKind::Array {
                item: Box::new(TypeKind::GenericParam(
                    nested.bound_type(ambient_depth, 0).unwrap(),
                )),
                len: ArrayLength::Generic(nested.bound_const(ambient_depth, 0).unwrap()),
            },
        ],
        TypeKind::Array {
            item: Box::new(TypeKind::Bool),
            len: ArrayLength::Generic(nested.bound_const(0, 0).unwrap()),
        },
        EffectRow::open(
            EffectSet::new(),
            nested.bound_effect(ambient_depth, 0).unwrap(),
        ),
    )
}

#[test]
fn shared_ambient_frames_transport_under_own_binders_across_different_scope_shapes() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let (scope, ty, _) = parameters(1, 0);
    let root_scope = context.enter_binder_scope(GenericBinder::new(1, 1, 1));
    let value = scoped_function(context.lexical_scope(), 1);
    let first = frontier(
        &mut context,
        scope.clone(),
        &[(TypeKind::GenericParam(ty[0].clone()), value)],
    );
    component
        .admit_roots(&mut context, vec![first], "outer")
        .unwrap();
    let outer = context.enter_binder_scope(GenericBinder::new(1, 0, 0));
    let expected = scoped_function(context.lexical_scope(), 2);
    let second = frontier(
        &mut context,
        scope,
        &[(TypeKind::GenericParam(ty[0].clone()), expected.clone())],
    );
    component
        .admit_roots(&mut context, vec![second], "outer beneath another frame")
        .unwrap();
    context.restore_binder_scope(outer);
    context.restore_binder_scope(root_scope);
    let forest = component.infer_original_products(&mut context).unwrap();
    let product = &forest.products[0];
    assert_eq!(product.scope.shape().binders().len(), 2);
    let solution = &product
        .result
        .as_ref()
        .ok()
        .expect("same original ambient binder")[0];
    assert_eq!(solution.branch.bindings.get(&ty[0]), Some(&expected));
    assert!(context.lexical_scope().binders().is_empty());
}

#[test]
fn live_use_tickets_and_cancellation_cannot_publish_a_partial_original_forest() {
    let cancellation = AtomicBool::new(false);
    let mut context = context(&cancellation);
    let mut component = Component::new(&mut context).unwrap();
    let root = frontier(&mut context, TypeConstraintParameterScope::empty(), &[]);
    let value = component
        .admit_roots(&mut context, vec![root], "initializer")
        .unwrap();
    let use_ = component.issue_use(&mut context, &[value]).unwrap();
    assert!(matches!(
        component.infer_original_products(&mut context),
        Err(PreparedValueFailure::UseState)
    ));
    drop(use_);
    let component = Component::new(&mut context).unwrap();
    cancellation.store(true, Ordering::Relaxed);
    assert!(matches!(
        component.infer_original_products(&mut context),
        Err(PreparedValueFailure::Constraint(
            TypeConstraintError::Abort(_)
        ))
    ));
    cancellation.store(false, Ordering::Relaxed);
    assert!(context.lexical_scope().binders().is_empty());
}
