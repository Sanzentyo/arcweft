$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='D:\git\arcweft'
$publication=Get-Content -Raw "$root\joint-original.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root\joint-original.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root\joint-original.consumer-summary.json"|ConvertFrom-Json -Depth 40
$quality=Get-Content -Raw "$root\joint-original.quality.json"|ConvertFrom-Json
if($owner.Passed -ne 1577 -or $owner.Failed -ne 6 -or $consumers.consumerPassed -ne 2507 -or $consumers.consumerFailed -ne 2 -or $consumers.consumerSkipped -ne 1 -or $consumers.completedSteps -ne 107 -or -not $consumers.failureIdsUnchanged){throw 'Terminal evidence differs'}
foreach($name in @('WorkspaceCheckExit','WorkspaceClippyExit','FmtExit','StructureExit','DoctestExit')){if($quality.$name -ne 0){throw "Quality failure $name"}}
if($quality.Source -ne $publication.Source -or $consumers.source -ne $publication.Source -or $owner.Source -ne $publication.Source){throw 'Source identities differ'}
$files=[Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File|Where-Object {
    ($_.Name.StartsWith('joint-original.') -or $_.Name -in @('audit-joint-original.ps1','audit-joint-original-consumers.ps1','make-joint-original-archive.ps1')) -and
    $_.Name -notin @('joint-original.manifest.json','joint-original.archive.json','joint-original.docs-audit.json','joint-original.docs-publication.json')
}|Sort-Object Name|ForEach-Object {$files.Add(@{Name=$_.Name;Path=$_.FullName})}
Get-ChildItem -LiteralPath "$root\joint-original-reverse" -File|Sort-Object Name|ForEach-Object {$files.Add(@{Name='consumers/'+$_.Name;Path=$_.FullName})}
$manifest=[ordered]@{
    Version=1;Source=$publication.Source;Tree=$publication.Tree;Base=$publication.Parent
    Owner=@{Selected=1583;Passed=1577;Failed=6;Skipped=0;NewTests=14;Seconds=73.812;Exit=100;IdsEqual=$true;FailureIdsUnchanged=$true}
    Consumers=@{Packages=21;Targets=107;Passed=2507;Failed=2;Skipped=1;ZeroRunnableTargets=3;FailureIdsUnchanged=$true;IdsEqual=$true;FeatureMode='host-default prescribed consumers'}
    Combined=@{Passed=4084;Failed=8;Skipped=1}
    Quality=$quality
    Phases=@(
        @{Name='initial algebra check';Exit=101;Tests=0;Note='First generic migration had imports before inner module docs plus an unnecessary Clone requirement; initial tracked patch/hash inventory retained.'},
        @{Name='intermediate compiler diagnostics';Note='An import accidentally inherited cfg(test), then one missing TypeInstantiationError conversion, one closure index inference, and an exhaustive error mapper were repaired. Logs are retained; not every intermediate compiler invocation has a complete byte pin.'},
        @{Name='first private regressions';Selected=7;Passed=5;Failed=2;Exit=100;Note='Retained tracked patch and three byte-exact new source snapshots. Added the existing deferred-cycle rejection rule to joint closure. Corrected the incomplete-binding fixture to the original declaration key rather than an opened inference key; no assertion/budget weakened.'},
        @{Name='preliminary component suite';Passed=27;Failed=0;Note='Development input before final scope seal, without a complete byte pin; not relabeled as the final source suite.'},
        @{Name='final check';Exit=0;Seconds=24.40;Note='Pinned 19 source paths; all-target/all-feature Sema check.'},
        @{Name='final source validation';Note='Full owner/consumer identities, immutable input hashes and published blobs are retained. Unit/integration tests use nextest; Sema all-feature doctests use the dedicated runner. Scope inspection/consultation does not prove the remaining full feature.'}
    )
    Commands=@('CARGO_INCREMENTAL=0 cargo nextest list/run --locked -p arcweft-lang-sema --lib --tests --all-features [full commands in owner receipt]','CARGO_INCREMENTAL=0 cargo check --locked --workspace --all-targets --all-features','CARGO_INCREMENTAL=0 cargo clippy --locked --workspace --all-targets --all-features','cargo fmt --all --check','just structure-audit-gate','CARGO_INCREMENTAL=0 cargo test --locked -p arcweft-lang-sema --doc --all-features','107 pinned per-target nextest list/run commands from consumers/joint-original-reverse-results.json')
    Files=@($files|ForEach-Object {$item=Get-Item -LiteralPath $_.Path;@{Name=$_.Name;Bytes=$item.Length;SHA256=(Get-FileHash -LiteralPath $_.Path -Algorithm SHA256).Hash.ToLowerInvariant()}})
}
$manifest|ConvertTo-Json -Depth 12|Set-Content "$root\joint-original.manifest.json" -Encoding utf8
$files.Add(@{Name='manifest.json';Path="$root\joint-original.manifest.json"})
$archivePath=Join-Path $repo 'docs/implementation/acceptance-evidence/task-joint-original-inference.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive exists'}
$zip=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.Path,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    if($zip.Entries.Count -ne $files.Count){throw 'Entry count differs'}
    foreach($file in $files){
        $entry=$zip.GetEntry($file.Name);$source=Get-Item -LiteralPath $file.Path
        if($null -eq $entry -or $entry.Length -ne $source.Length){throw 'Entry length differs'}
        $stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -ne (Get-FileHash -LiteralPath $file.Path -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Entry hash differs'}
    }
    $raw=[long]($zip.Entries|Measure-Object Length -Sum).Sum
}finally{$zip.Dispose()}
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=$files.Count;RawBytes=$raw;Bytes=(Get-Item $archivePath).Length;SHA256=(Get-FileHash $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();EveryEntryVerified=$true}|ConvertTo-Json|Set-Content "$root\joint-original.archive.json" -Encoding utf8
Get-Content "$root\joint-original.archive.json"
