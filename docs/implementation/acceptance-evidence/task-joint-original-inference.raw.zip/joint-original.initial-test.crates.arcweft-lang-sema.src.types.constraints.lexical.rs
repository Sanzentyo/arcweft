//! Original lexical frames and metered transport into a joint inference scope.

use std::sync::Arc;

use super::{
    ConstraintDomain, TypeConstraintError,
    context::{TypeConstraintAccounting, TypeConstraintContext},
};
use crate::types::{
    ArrayLength, GenericBinder, GenericConstReference, GenericEffectReference, GenericScope,
    GenericTypeReference, TypeInstantiationError, TypeKind, TypeProjectionError,
};

struct LexicalFrame;

/// Shape alone is not provenance. Clones retain the actual opening of every
/// ambient frame; entering another equally shaped binder mints another frame.
#[derive(Clone, Default)]
pub(super) struct ConstraintLexicalScope {
    shape: GenericScope,
    frames: Vec<Arc<LexicalFrame>>,
}

impl ConstraintLexicalScope {
    pub(super) fn transport_length<A: TypeConstraintAccounting, D: ConstraintDomain>(
        &self,
        original: &Self,
        length: &ArrayLength,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<ArrayLength, TypeProjectionError<TypeConstraintError>> {
        context.enter_node().map_err(TypeProjectionError::Control)?;
        match length {
            ArrayLength::Generic(GenericConstReference::Bound(bound)) => {
                original.shape.bound_const(bound.depth(), bound.slot())?;
                Ok(ArrayLength::Generic(self.shape.bound_const(
                    self.depth(original, original.shape(), bound.depth(), context)?,
                    bound.slot(),
                )?))
            }
            ArrayLength::Generic(_) | ArrayLength::Const(_) => Ok(length.clone()),
            ArrayLength::Error(_) | ArrayLength::Inferred => {
                Err(TypeInstantiationError::UnresolvedType.into())
            }
        }
    }

    pub(super) fn transport_predicate<A: TypeConstraintAccounting, D: ConstraintDomain>(
        &self,
        original: &Self,
        predicate: &crate::effect_row::EffectPredicate,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<crate::effect_row::EffectPredicate, TypeProjectionError<TypeConstraintError>> {
        super::solution::map_predicate_with_control(predicate, 1, context, &|reference, context| {
            let reference = match reference {
                GenericEffectReference::Bound(bound) => {
                    original.shape.bound_effect(bound.depth(), bound.slot())?;
                    self.shape.bound_effect(
                        self.depth(original, original.shape(), bound.depth(), context)?,
                        bound.slot(),
                    )?
                }
                _ => reference.clone(),
            };
            Ok(crate::effect_row::EffectRow::open(
                crate::effects::EffectSet::new(),
                reference,
            ))
        })
    }

    pub(super) fn shape(&self) -> &GenericScope {
        &self.shape
    }

    pub(super) fn with_binder(&self, binder: GenericBinder) -> Self {
        let mut scope = self.clone();
        if !binder.is_empty() {
            scope.shape = self.shape.with_binder(binder);
            scope.frames.push(Arc::new(LexicalFrame));
        }
        scope
    }

    /// A template traversal is isolated from the actual operands. Its arities
    /// cannot certify an alignment with an independently retained actual scope.
    pub(super) fn template(shape: GenericScope) -> Self {
        let frames = shape
            .binders()
            .iter()
            .map(|_| Arc::new(LexicalFrame))
            .collect();
        Self { shape, frames }
    }

    pub(super) fn merge<A: TypeConstraintAccounting, D: ConstraintDomain>(
        &mut self,
        original: &Self,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<(), TypeConstraintError> {
        for (frame, binder) in original.frames.iter().zip(original.shape.binders()) {
            context.enter_node()?;
            let mut found = false;
            for existing in &self.frames {
                context.enter_node()?;
                if Arc::ptr_eq(existing, frame) {
                    found = true;
                    break;
                }
            }
            if !found {
                for _ in &self.frames {
                    context.enter_node()?;
                }
                context.enter_node()?;
                self.shape = self.shape.with_binder(*binder);
                self.frames.push(Arc::clone(frame));
            }
        }
        Ok(())
    }

    fn depth<A: TypeConstraintAccounting, D: ConstraintDomain>(
        &self,
        original: &Self,
        occurrence: &GenericScope,
        depth: u32,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<u32, TypeProjectionError<TypeConstraintError>> {
        let nested = occurrence
            .binders()
            .len()
            .checked_sub(original.frames.len())
            .ok_or(TypeInstantiationError::SpecializationScopeMismatch)?;
        let depth_index =
            usize::try_from(depth).map_err(|_| TypeInstantiationError::DepthOverflow)?;
        if depth_index < nested {
            return Ok(depth);
        }
        let index = original
            .frames
            .len()
            .checked_sub(depth_index - nested + 1)
            .ok_or(TypeInstantiationError::SpecializationScopeMismatch)?;
        let frame = &original.frames[index];
        for (target, existing) in self.frames.iter().enumerate() {
            context.enter_node().map_err(TypeProjectionError::Control)?;
            if Arc::ptr_eq(existing, frame) {
                return u32::try_from(self.frames.len() - target - 1 + nested)
                    .map_err(|_| TypeInstantiationError::DepthOverflow.into());
            }
        }
        Err(TypeInstantiationError::SpecializationScopeMismatch.into())
    }

    pub(super) fn transport_type<A: TypeConstraintAccounting, D: ConstraintDomain>(
        &self,
        original: &Self,
        ty: &TypeKind,
        context: &mut TypeConstraintContext<'_, A, D>,
    ) -> Result<TypeKind, TypeProjectionError<TypeConstraintError>> {
        super::solution::map_term_with_control(
            ty,
            original.shape(),
            self.shape(),
            1,
            context,
            &|reference, source, target, _, context| {
                Ok(TypeKind::GenericParam(match reference {
                    GenericTypeReference::Bound(bound) => {
                        source.bound_type(bound.depth(), bound.slot())?;
                        target.bound_type(
                            self.depth(original, source, bound.depth(), context)?,
                            bound.slot(),
                        )?
                    }
                    _ => reference.clone(),
                }))
            },
            &|length, source, target, _, context| match length {
                ArrayLength::Generic(GenericConstReference::Bound(bound)) => {
                    source.bound_const(bound.depth(), bound.slot())?;
                    Ok(ArrayLength::Generic(target.bound_const(
                        self.depth(original, source, bound.depth(), context)?,
                        bound.slot(),
                    )?))
                }
                ArrayLength::Generic(_) | ArrayLength::Const(_) => Ok(length.clone()),
                ArrayLength::Error(_) | ArrayLength::Inferred => {
                    Err(TypeInstantiationError::UnresolvedType.into())
                }
            },
            &|row, source, target, depth, context| {
                super::solution::map_effects_with_control(
                    row,
                    depth,
                    context,
                    &|reference, context| {
                        let reference = match reference {
                            GenericEffectReference::Bound(bound) => {
                                source.bound_effect(bound.depth(), bound.slot())?;
                                target.bound_effect(
                                    self.depth(original, source, bound.depth(), context)?,
                                    bound.slot(),
                                )?
                            }
                            _ => reference.clone(),
                        };
                        Ok(crate::effect_row::EffectRow::open(
                            crate::effects::EffectSet::new(),
                            reference,
                        ))
                    },
                )
            },
        )
    }
}
