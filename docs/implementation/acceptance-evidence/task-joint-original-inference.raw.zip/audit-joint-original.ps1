$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='D:\git\arcweft'
$publication=Get-Content -Raw "$root\joint-original.publication.json"|ConvertFrom-Json
$receipt=Get-Content -Raw "$root\joint-original.owner-receipt.json"|ConvertFrom-Json
$pin=Get-Content -Raw "$root\joint-original.final-input.json"|ConvertFrom-Json
$log=[IO.File]::ReadAllText("$root\joint-original.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1583 tests run: 1577 passed, 6 failed, 0 skipped')
if(-not $summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1583\) (\S+) (.+)\r?$')|ForEach-Object {
    [pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}
})
$selected=@($receipt.Selected|ForEach-Object {$_.Binary+'$'+$_.Name})
if($terminal.Count -ne 1583 -or $selected.Count -ne 1583){throw 'Selection or terminal count differs'}
if(@($terminal|Group-Object Id|Where-Object Count -gt 1).Count -ne 0 -or @($selected|Group-Object|Where-Object Count -gt 1).Count -ne 0){throw 'Duplicate identity'}
if(@(Compare-Object -CaseSensitive ($selected|Sort-Object) ($terminal.Id|Sort-Object)).Count -ne 0){throw 'Selection and execution disagree'}
$failures=@($terminal|Where-Object Result -eq 'FAIL'|ForEach-Object Name|Sort-Object)
$previous=Get-Content -Raw "$root\application-inventory.owner-summary.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $previous.Failures $failures).Count -ne 0){throw 'Failure IDs changed'}
$new=@($terminal|Where-Object {$_.Name.Contains('::component::original::tests::') -or $_.Name.EndsWith('::imported_opening_cannot_change_semantic_application_when_original_roots_join')})
if($new.Count -ne 14 -or @($new|Where-Object Result -ne 'PASS').Count -ne 0){throw 'New regressions missing or failed'}
if(@($terminal|Where-Object {$_.Name.Contains('t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once') -and $_.Result -eq 'PASS'}).Count -ne 1){throw '256 candidate boundary failed'}
if([regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Actual failure diagnostics changed'}
foreach($source in $pin.Sources){if((Get-FileHash -LiteralPath (Join-Path $repo $source.Path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $source.SHA256){throw 'Input source changed'}}
if($receipt.RunExit -ne 100 -or $receipt.Source -ne $publication.Source -or $receipt.Tree -ne $publication.Tree -or $pin.Tree -ne $publication.Tree){throw 'Source identity mismatch'}
$terminal|ConvertTo-Json -Depth 5|Set-Content "$root\joint-original.owner-terminal.json" -Encoding utf8
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Selected=1583;Passed=1577;Failed=6;Skipped=0;Suites=5;NewTests=$new;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);SelectedIdsEqualTerminalIds=$true;DuplicateIds=0;FailureIdsUnchanged=$true;FailureBaseline='c611023e3a5fa67be7748ce2b25a1f8784e78d51';Failures=$failures;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};Candidate256Passed=$true;VerifiedSources=$pin.Sources.Count}|ConvertTo-Json -Depth 7|Set-Content "$root\joint-original.owner-summary.json" -Encoding utf8
Get-Content "$root\joint-original.owner-summary.json" -TotalCount 14
