$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$runDir=$PSScriptRoot
. "$runDir/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$runDir/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$source=Read-Record 'view-action-ingress-20261108.source.verified.json'
if($source.commit -ne '8c123e75092eedb0aa1893a4c5847ca93f422e74' -or (git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected source'}
$owner=Read-Record 'view-action-ingress-20261108.owner-r4.runtime.terminal-audit.json'
$core=Read-Record 'view-action-ingress-20261108.core-owner.runtime.terminal-audit.json'
$capacity=Read-Record 'view-action-ingress-20261108.capacity-r2.runtime.terminal-audit.json'
if($owner.passed -ne 98 -or $core.passed -ne 7 -or $capacity.passed -ne 1 -or $owner.failed -ne 0 -or $core.failed -ne 0 -or $capacity.failed -ne 0){throw 'Owner result differs'}
$quality=@(foreach($name in @('check','clippy','structure','fmt')){Read-Record "view-action-ingress-20261108.quality.$name.receipt.json"})
$additionalQuality=@(foreach($name in @('clippy','fmt')){Read-Record "view-action-ingress-20261108.capacity-quality.$name.receipt.json"})
if(@(($quality+$additionalQuality)|Where-Object exitCode -ne 0).Count){throw 'Quality failure'}
$metrics=Import-Csv -LiteralPath "$runDir/view-action-ingress-20261108.structure-report/file_metrics.csv"
$packages=Import-Csv -LiteralPath "$runDir/view-action-ingress-20261108.structure-report/package_metrics.csv"
$rustPaths=@($source.paths.path |Where-Object {$_ -like '*.rs'})
$review=[ordered]@{version=1;source=$source.commit;baseline=$source.parent;files=@(foreach($path in $rustPaths){$metric=$metrics|Where-Object path -eq $path;if(!$metric){throw "Missing metric: $path"};$metric});packages=@($packages|Where-Object package -in @('arcweft-core','arcweft-view','arcweft-lang-sema','arcweft-bundle','arcweft-compiler','arcweft-runtime-driver'));disposition=@('Core owns original declaration lookup, complete live admission and the existing FIFO; Native/AOT and AWBC supply their actual retained execution contour. The new 27-line AWBC child names that ingress responsibility.','View owns the closed handler result algebra. Sema authenticates the Action declaration and exact payload semantic identity; Compiler uses the existing event-time mutation ABI. Bundle checks the tuple result against the original Core type table.','Driver owns the exclusive commit across admitted View updates and Core emission. It creates no second queue or callback catalog. Core refusal occurs before the infallible View commit.','Existing large owners retain their responsibility; no arbitrary source split, Cargo/feature/dependency change, unsafe or version marker change. All Arcweft-owned markers remain 1.');additionalTest=[ordered]@{path='crates/arcweft-compiler/tests/view_product/text_input.rs';base=$source.commit;bytes=(Get-Item -LiteralPath 'crates/arcweft-compiler/tests/view_product/text_input.rs').Length;sha256=(Get-FileHash -LiteralPath 'crates/arcweft-compiler/tests/view_product/text_input.rs').Hash.ToLowerInvariant();note='One later test addition, compiled/run/linted/formatted separately. Prior workspace quality covers unchanged production; do not relabel its frozen test bytes.'}}
$review|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$runDir/view-action-ingress-20261108.structure-review.json" -Encoding utf8
$testPatch=Read-GitBytes @('diff','--binary','--full-index','--','crates/arcweft-compiler/tests/view_product/text_input.rs')
[IO.File]::WriteAllBytes("$runDir/view-action-ingress-20261108.capacity-test.patch",$testPatch)
$raw=@(Get-ChildItem -LiteralPath $runDir -File -Filter 'view-action-ingress*') + @((Get-Item -LiteralPath "$runDir/run-view-action-ingress-quality-20261108.ps1"),(Get-Item -LiteralPath $PSCommandPath))
$archive='docs/implementation/acceptance-evidence/task-view-action-ingress-owner.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($file in ($raw|Sort-Object FullName -Unique)){if($file.Extension -notin @('.log','.json','.patch','.txt','.pathspec','.ps1')){throw 'Unexpected raw entry'};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    foreach($file in Get-ChildItem -LiteralPath "$runDir/view-action-ingress-20261108.structure-report" -File){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('structure/'+$file.Name),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    $probe="$runDir/view-action-ingress-probe"
    foreach($file in Get-ChildItem -LiteralPath $probe -File -Recurse){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('probe/'+[IO.Path]::GetRelativePath($probe,$file.FullName).Replace('\','/')),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|rlib|rmeta|dll|pdb)$').Count){throw 'Build artifact in raw archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$record=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($record.PSObject.Properties.Name -contains 'viewNamedActionOwner'){throw 'Owner record exists'}
$epochs=@(foreach($number in 1..3){$stem="view-action-ingress-20261108.owner-r$number";[ordered]@{epoch=$stem;preparation=(Read-Record "$stem.catalog.json");terminal=$(if(Test-Path -LiteralPath "$runDir/$stem.runtime.terminal-audit.json"){Read-Record "$stem.runtime.terminal-audit.json"}else{$null})}})
$entry=[ordered]@{version=1;date='2026-11-08';sourcePublication=$source;scope='View event-time named Action result -> original Core session FIFO, atomic with retained updates';owner=$owner;core=$core;additionalProductionLimitCase=$capacity;uniqueOwnerCases=106;workspaceQuality=$quality;additionalTestQuality=$additionalQuality;developmentEpochs=$epochs;corrections=@('Owner-r1: attempted session save before pending adapter text write-back was drained. Preserve quiescence; separate actual submit and drained-change/click/save/restore tests.','Owner-r2: test tried a private nominal constructor. Keep it private and use existing original-program try_record_value. No runtime tests executed.','Owner-r3: Native/AOT facade test did not select its entry. Start the real entry explicitly; keep OneOp and 64 steps unchanged.');capacity='Use real max_string_bytes=1048576 and encoded-byte group limit=8388608; second four-field Action is refused with typed encoded_bytes, complete BundleSessionSnapshot equality, and smaller-payload retry succeeds.';graph=(Read-Record 'view-action-ingress-20261108.graph-review.json');structuralReview=$review;archive=$archiveInfo;integration='Owner and workspace gates passed. Complete reverse consumers, CLI Source probe, old sample migration, Scroll and Native/Web capture are not yet accepted.';preservedPriorRecords=@($record.PSObject.Properties).Count}
$wrapper=(ConvertTo-Json -InputObject ([ordered]@{viewNamedActionOwner=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd();$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $record.PSObject.Properties){if((ConvertTo-Json -InputObject $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[ordered]@{source=$source.commit;priorRecords=@($record.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$archiveInfo}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$runDir/view-action-ingress-owner-record-audit.json" -Encoding utf8
Get-Content -LiteralPath "$runDir/view-action-ingress-owner-record-audit.json" -Raw
