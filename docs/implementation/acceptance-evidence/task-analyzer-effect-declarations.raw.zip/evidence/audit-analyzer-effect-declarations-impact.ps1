$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/analyzer-effect-declarations.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/analyzer-effect-declarations.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {$changed=$false;foreach($node in $metadata.resolve.nodes){if(!$closure.Contains($node.id)){foreach($dependency in $node.deps){if($closure.Contains($dependency.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/prepared-effect-scope.impact.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count){throw 'Reverse graph changed'}
$consumers=Get-Content -Raw "$root/analyzer-effect-declarations.consumer-summary.json"|ConvertFrom-Json
if($consumers.Source -ne $pub.Source -or $consumers.Targets -ne 107 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$consumers.IdsEqual -or $consumers.Duplicates){throw 'Fresh consumer coverage differs'}
$inputs=@(git diff --name-only $previous.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml')
if($inputs.Count){throw 'Cargo graph inputs changed'}
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='analyzer-effect-declarations.reverse-tree.txt';CargoInputsUnchanged=$true;ReverseConsumersRerun=$true;FreshTargets=$consumers.Targets;FreshPassed=$consumers.Passed;FreshFailed=$consumers.Failed;FreshSkipped=$consumers.Skipped;Reason='One prepared call graph owns the actual source declaration effect graph, installed by staging before body expression typing. Catalog checked IDs and exact schema digests bind original scheme headers, all formals including unused parameters, and D. On-demand and final callable effect equations reuse those same original headers; the previous closure-local graph construction and declaration reissuance are deleted. Query body equations are journaled under one owned checkpoint and always rolled back before the complete canonical result becomes observable. Reachability selects the actual function dependency component while retaining every original graph obligation and its dependencies. Unselected declarations stay Declared; no pure or unknown body is substituted. The existing finite closure, residual program, import lowering, canonical reification and confirmation share an explicit function inventory instead of introducing another solver. Canonical projection outside the selected component returns a typed stale-reference error. Four new cases cover preregistration before invalid sibling body typing, exact scheme reuse across queries, dependency closure and projection scope, all original C including rejection, and every budget cut point. The private named-source registry and pending canonical projection request cache serve distinct roles; the eager prepared-value path and six recursive-body failures are not claimed fixed. Frontend body preparation and generated canonical consumers are affected, so the complete resolved downstream matrix, workspace quality and owner doctests are rerun. No Graph/checkpoint/delta cloning, source reconstruction, unsafe, I/O, Cargo/feature, version, profile or default budget change.'}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/analyzer-effect-declarations.impact.json"
Write-Output "Verified fresh reverse closure: $($packages.Count) packages, 107 consumer targets"

$tree=[IO.File]::ReadAllText("$root/analyzer-effect-declarations.reverse-tree.txt")
$workspace=@($metadata.packages|Where-Object {$metadata.workspace_members -ccontains $_.id}|ForEach-Object name)
$treePackages=@([regex]::Matches($tree,'(?m)([a-z][a-z0-9-]+) v[0-9][^\s]*')|ForEach-Object {$_.Groups[1].Value}|Where-Object {$workspace -ccontains $_}|Sort-Object -Unique)
if(@(Compare-Object -CaseSensitive @($packages.name|Sort-Object) $treePackages).Count){throw 'Resolved closure differs from all-target reverse tree'}
Write-Output "Verified tree/metadata package identities: $($treePackages.Count)"