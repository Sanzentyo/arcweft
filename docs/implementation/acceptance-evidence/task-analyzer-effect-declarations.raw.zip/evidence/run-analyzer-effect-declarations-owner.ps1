$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
function Source-Paths { @(@(git diff --name-only 8494d6601dd46f695d20ec7d945ec43e30a30f68) + @(git ls-files --others --exclude-standard | Where-Object { $_.StartsWith('crates/arcweft-lang-sema/') -and $_.EndsWith('.rs') })) | Sort-Object -Unique }
$source=(git rev-parse HEAD).Trim()
$paths=@(Source-Paths | ForEach-Object { [ordered]@{Path=$_;Blob=(git hash-object -- $_).Trim();SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash} })
[ordered]@{Version=1;Source=$source;TouchedRustPaths=$paths.Count;Paths=$paths}|ConvertTo-Json -Depth 6|Set-Content -Encoding utf8 "$root/analyzer-effect-declarations.input.json"
git diff --binary HEAD > "$root/analyzer-effect-declarations.source.patch"
$steps=[Collections.Generic.List[object]]::new()
function Assert-Source {
    if((git rev-parse HEAD).Trim() -ne $source){throw 'Owner HEAD changed'}
    if(@(Source-Paths).Count -ne $paths.Count){throw 'Owner tracked paths changed'}
    foreach($p in $paths){if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path).Trim() -ne $p.Blob){throw 'Owner source bytes changed'}}
}
function Step($name,$arguments,$output,$log) {
    Assert-Source
    $start=Get-Date
    Write-Output "START $name"
    & cargo @arguments 1>"$root/$output" 2>"$root/$log"
    $code=$LASTEXITCODE
    Assert-Source
    $steps.Add([ordered]@{Name=$name;Arguments=$arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;SourcePinsVerified=$true;Output=$output;Log=$log})
    [ordered]@{Version=1;Source=$source;Input='analyzer-effect-declarations.input.json';CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false;Steps=@($steps.ToArray())}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/analyzer-effect-declarations.owner-validation.json"
    Write-Output "END $name exit=$code"
    Get-Content -LiteralPath "$root/$log" -Tail 7
    if($code -ne 0 -and $name -ne 'owner-run'){throw "$name failed"}
}
Step 'owner-list' @('nextest','list','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--message-format','json') 'analyzer-effect-declarations.owner-list.json' 'analyzer-effect-declarations.owner-list.log'
Step 'owner-run' @('nextest','run','--locked','-p','arcweft-lang-sema','--all-features','--lib','--tests','--no-fail-fast','--no-tests','fail','--message-format','libtest-json-plus') 'analyzer-effect-declarations.owner-results.jsonl' 'analyzer-effect-declarations.owner-run.log'
Step 'fmt' @('fmt','--all','--','--check') 'analyzer-effect-declarations.fmt.stdout' 'analyzer-effect-declarations.fmt.log'

