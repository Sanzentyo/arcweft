$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/analyzer-effect-declarations.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/analyzer-effect-declarations.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$scratch/analyzer-effect-declarations.impact.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/analyzer-effect-declarations.broad-quality.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$scratch/analyzer-effect-declarations.consumer-summary.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/analyzer-effect-declarations.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/analyzer-effect-declarations.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git ls-remote origin refs/heads/main).Split()[0] -ne $pub.Source -or !$pub.Pushed){throw 'Source publication differs'}
if($owner.Passed -ne 1774 -or $owner.Failed -ne 6 -or $quality.Steps.Count -ne 3 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or !$impact.ReverseConsumersRerun -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$consumers.IdsEqual -or $structure.Blocking -ne 0 -or !$archive.AllEntriesVerified){throw 'Final receipts differ'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previous=[IO.File]::ReadAllText((Join-Path $PWD $status))
$historyBytes=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previous,'(?m)^\| Generic Match[^\r\n]+').Value
if(!$generic){throw 'Generic Match authority row missing'}
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']="| 再帰関数値の終端効果 | **既受入を維持。実Analyzerの宣言scheme事前登録・同一graphでの効果closureを検証・公開。本体内の関数値推論は継続** | Source ``$($pub.Source)``。実際のprepared call graphが元formal・D・schema digestとchecked宣言IDに対応する数学graphを所有し、本体の式型検査より前に全body宣言のschemeを登録する。オンデマンド／最終closureはその同じ宣言を使い、元Cと依存を保った関数群を閉じる。対象外の宣言はDeclaredのまま残し、query中の本体方程式は結果確定前に巻き戻す。型・const・効果・predicateの移送は共通scoped fold、未公開の準備はreadonly scopeとaffine差分を使う。caller-bound recursion・共有prefix・Free許可／reifyの既受入を維持する。prepared型を含む全関数値port／ΓとAnalyzerの統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[今回の所有境界・検証](convergence-evidence-history.md#analyzer-owned-declaration-effect-schemes)。 |"
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,774 PASS／6 FAIL。後続21 packageも新しい入力で検証済み** | Source ``$($pub.Source)`` のlocked・全feature lib／tests 1,780件は$($owner.ExecutionSeconds)秒、1,774 PASS／6 FAIL／0 SKIP。直前1,776 IDを保持し、新4件は全PASS。保持6失敗のIDと5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeの22 packageを照合し、後続21 package・107 target・2,510件を再実行して2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0を確認した。Compilerの保持2失敗は同じExpressionCycle、CLIは規定6対象を含む226 PASS。3 targetはtest 0件のcompile対象として区別する。初回1,773 PASS／7 FAILと修正理由も原本に保持し、最終結果へ合算しない。[owner・consumer・実行範囲](acceptance-evidence/task-analyzer-effect-declarations.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **今回のworkspace品質・owner doctest・fmt・構造は終了0** | Source ``$($pub.Source)`` のlocked workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateを新しく実行した。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。基点 ``$($pub.ChangeBase)`` から17 Rust path・$($owner.PhysicalGrowth)物理LOC増、fan-in／out $($owner.FanIn)／$($owner.FanOut)。実call graphに数学ownerを集約し、全体／対象関数群のclosureは同じ関係・canonical再検証を使う。公開契約・Cargo入力・I/O・codec・version・既定予算は不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。中断した初回workspace checkは成功扱いにしない。Tier 2と再帰本体の新しいNative／AWBC・Native／Web最終受入は今回未実行。[今回の品質・構造](acceptance-evidence/task-analyzer-effect-declarations.raw.zip)。 |"
$current=$previous
foreach($key in $rows.Keys){
 $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
 if([regex]::Matches($current,$pattern).Count -ne 1){throw "Authority row missing or duplicated: $key"}
 $replacement=$rows[$key]
 $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-17。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
$entry=@"

## Analyzer-owned declaration effect schemes

2026-11-14に実装・検証し、2026-11-17の再開時に既存process handleの消失、cargo／rustc非稼働、20 groupとCompiler 31 targetの終端を確認して監査した。検証の実行日を監査日へ付け替えず、同じ入力の再実行はしていない。基点 ``$($pub.ChangeBase)``、中間Source ``bfc4caadc45b0c13114daffb59a0c61543aac818``、修正・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの2実装commitを通常pushし、累積17 Rust pathの検証dirty bytes・commit・公開blobを照合した。未追跡 ``%SystemDrive%/`` は保持した。

- 実prepared call graphがPreparedCallableEffectDeclarationsを所有する。staging時に実catalogのchecked宣言ID・schema digest・元formal全体・Dから元schemeを一度登録し、その同じ数学graphを本体式の型検査より前にAnalyzerへ渡す。closureのたびに別graphを作って宣言を再発行していた経路は削除した。元Dのdecision graphは既存の数学ownerでcontrolを課してから複製する。unused formalを本体の観測から復元せず、名前・source・ordinal順から宣言の同一性を推測しない。
- オンデマンドと最終の実body方程式は元headerを借り、同じ数学graphのcheckpoint内で準備・解決する。元Cとその全依存を必ず含む関数群を閉じ、対象外の宣言をDeclaredのまま保持する。全体／関数群のclosureは共通のfunction inventory、元のresidual関係、import lowering、canonical投影・独立再検証を使う。対象外のapplicationをcanonical化しようとすると型付きStaleReferenceで拒否する。失敗・取消・成功のすべてでqueryの方程式を巻き戻してから、完成したcanonical結果だけを返す。未準備bodyをpure／unknownで代用しない。
- 新4件は、式の型の合わない未参照bodyを持つ実fixtureでもその型検査前に全headerを登録できること、同じscheme ID／formal／Dを2 queryで維持すること、推移的な実application依存と投影scope、元Cのunknown依存と不充足の拒否、全予算点での元controlを確認した。既存の宣言closureテストも同じ実ownerを使い、unused formalと予算／取消の原子性を確認する。これは宣言の準備順・数学ownerと実closureの接続であり、prepared型の全値port／Γやjoint sealの完了ではない。
- 最終ownerは1,780件／1,774 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,776 ID保持・新4件PASS、選択／終端ID一致・重複0。保持6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateは今回終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。累積17 path・$($owner.PhysicalGrowth)物理LOC増。各pathの実byte／物理LOC・production／test分類とembedded test LOC、ownerの責任・fan-in／out $($owner.FanIn)／$($owner.FanOut)を記録した。既存call graphは宣言と候補を所有し、数学ownerはdependency選択と元関係の解釈を所有する。依存方向・公開契約・Cargo入力・I/O・codec・version・既定予算は変えず、CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- fresh full metadata／全target reverse treeの22 packageを照合し、後続21 package・107 target・2,510件を新しく実行した。2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0、CLIは規定6対象を含む226 PASS。20 groupとCompilerの31単独targetをすべて実行し、compileだけの3 targetをtest件数へ水増ししない。Compilerの2失敗は元のExpressionCycleと同じ実slot 17／19で、過去のrunは比較入力としてのみ使う。今回も再帰本体の新しいNative／AWBC受入、画像parity、Tier 2は未実行。
- 中間 ``bfc4caadc45b0c13114daffb59a0c61543aac818`` の初回ownerは1,773 PASS／7 FAILだった。追加fixture内で2関数宣言を同じ行に置いたためRecoveredModuleとなり、宣言登録前に失敗していた。宣言間に改行を入れてassertionを維持し、単体PASS後に全ownerを再実行した。最初に1,774 PASS／6 FAILとした会話上の件数説明は監査で否定され、訂正した。中間commitは正常動作を必須としないユーザー方針に従って履歴に保持し、修正commitと一緒に公開した。初回workspace checkは修正前の固定入力を検証し続けないため、観測した自分のcargo／rustcだけを停止した。終了-1を成功扱いにせず、修正後に全workspace品質を再実行した。初回の入力・log・receiptはattempt01として元bytesと名前の対応表を保持し、開発checkのエラーと単体PASSも最終入力の証拠へ合算しない。置換で不要になったimport lowering wrapperを削除し、全体component constructorのtest専用利用を限定した。
- Supersedes: 数学schemeの登録が本体の型検査後だった境界を、実Analyzer所有の元graphへ事前登録する境界へ更新した。現状行からこの達成済み項目を残作業として削除し、cut別の重複説明は現在の所有関係へまとめた。過去のSHA・実測・失敗・訂正理由は履歴に保持する。今回も残る6失敗を理由にGeneric Match、再帰・共有prefix・型移送の既受入を未完了へ戻さない。残作業の現状一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-analyzer-effect-declarations.raw.zip](acceptance-evidence/task-analyzer-effect-declarations.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
foreach($document in @($rows.Values)+@($entry)){
 foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
  $target=$match.Groups[1].Value
  if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
  if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link $target"}
 }
}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText((Join-Path $PWD $history),"`n"+$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($historyBytes.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBytes)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical evidence index changed'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$historyBytes.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true;FinalWhitespaceExit=0}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/analyzer-effect-declarations.docs-validation.json"
git diff --stat
