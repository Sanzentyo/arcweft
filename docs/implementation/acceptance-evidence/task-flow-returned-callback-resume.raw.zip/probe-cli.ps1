$ErrorActionPreference = 'Stop'
$scratch = Split-Path -Parent $PSCommandPath
$producer = '1ffe528d8e92c8eacc4635c088c62f5bc4cc1a72'
$cli = (Resolve-Path 'target/debug/arcw.exe').Path
$flowSource = Join-Path $scratch 'validDefault.arcw'
$zeroWait = Join-Path $scratch 'zeroWait.arcw'
$effectMismatch = Join-Path $scratch 'effectMismatch.arcw'
$text = Get-Content -LiteralPath $flowSource -Raw
$text.Replace('wait(0.1s)', 'wait(0s)') | Set-Content -LiteralPath $zeroWait -Encoding utf8NoBOM
$text.Replace('let text: String -> i64 =', 'let text: String -> i64 effects {} =') | Set-Content -LiteralPath $effectMismatch -Encoding utf8NoBOM
$cases = @()
function Invoke-ArcwJson {
    param([string]$Name, [string[]]$Arguments)
    $path = Join-Path $scratch "$Name.json"
    & $cli @Arguments > $path
    $exitCode = $LASTEXITCODE
    $doc = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -Depth 100
    [pscustomobject]@{ Exit = $exitCode; Doc = $doc; Name = $Name; Args = $Arguments }
}
$result = Invoke-ArcwJson 'after-valid-default-check' @('check', '--json', $flowSource)
if ($result.Exit -ne 0 -or $result.Doc.status -ne 'ok' -or $result.Doc.semantic.call_diagnostics -or $result.Doc.verifier_diagnostics) {
    throw 'Annotated Flow failed check'
}
$cases += [ordered]@{ name=$result.Name; args=$result.Args; exit=$result.Exit; status=$result.Doc.status }
$result = Invoke-ArcwJson 'after-effect-mismatch-check' @('check','--json',$effectMismatch)
if ($result.Exit -eq 0 -or $result.Doc.status -ne 'denied') {
    throw 'Effectful callback accepted by a pure explicit annotation'
}
$cases += [ordered]@{ name=$result.Name; args=$result.Args; exit=$result.Exit; status=$result.Doc.status; diagnostic=@($result.Doc.diagnostics.diagnostic.code) }
foreach ($tier in @('bytecode-vm','awbc-product')) {
    foreach ($scenario in @('wait','zero')) {
        if ($scenario -eq 'wait') {
            $fixture = $flowSource
            $steps = '256'
            $expected = 'duration_waiting 100000000ns'
            $logs = @('prefix','text argument','default','number argument','default')
        } else {
            $fixture = $zeroWait
            $steps = '512'
            $expected = 'done Return("42")'
            $logs = @('prefix','text argument','default','number argument','default','captured')
        }
        $result = Invoke-ArcwJson "after-$tier-$scenario-run" @('run','--runner','headless','--executor',$tier,'--entry','entry.main','--steps',$steps,'--max-ops','1','--json',$fixture)
        $doc = $result.Doc
        $actualLogs = @($doc.steps[-1].observations.logs.message)
        $maxOps = ($doc.steps.stats.executed_ops | Measure-Object -Maximum).Maximum
        $diagnostics = ($doc.steps.stats.diagnostics | Measure-Object -Sum).Sum
        $assertionFailures = @($doc.steps | ForEach-Object { $_.assertion_failures }).Count
        if ($result.Exit -or $doc.final_status -ne $expected -or $maxOps -ne 1 -or $diagnostics -or $assertionFailures -or (Compare-Object $logs $actualLogs -SyncWindow 0)) {
            throw ($result.Name + ': ' + $doc.final_status)
        }
        $cases += [ordered]@{ name=$result.Name; args=$result.Args; exit=$result.Exit; final_status=$doc.final_status; steps=$doc.steps.Count; max_ops=$maxOps; diagnostics=$diagnostics; assertion_failures=$assertionFailures; logs=$actualLogs }
    }
}
$summary = [ordered]@{
    version=1
    source=$producer
    cli_sha256=(Get-FileHash -LiteralPath $cli -Algorithm SHA256).Hash.ToLowerInvariant()
    cases=$cases
}
$summary | ConvertTo-Json -Depth 8 | Tee-Object -FilePath (Join-Path $scratch 'after-cli-summary.json')


