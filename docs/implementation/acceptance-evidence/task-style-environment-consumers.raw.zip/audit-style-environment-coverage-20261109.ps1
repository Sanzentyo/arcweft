$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$current=Get-Content "$r/style-environment-integrated-20261109.noncli-r1.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$graph=Get-Content "$r/style-environment-20261109.graph.json" -Raw|ConvertFrom-Json -Depth 30
$after=@($current.rows|Where-Object status -eq 'matches')
$keys=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $after){if(!$keys.Add(($row.binary+[char]0+$row.test))){throw 'Duplicate current case'}}
$known=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$baselines=@(
 [pscustomobject]@{source='eb4b9a820e7e74a106e4ca17405e50b642cb579b';catalog='style-composites-integrated-20261109.noncli-r1.catalog.inventory.json'},
 [pscustomobject]@{source='f8c17506c05ee9df614581d8df12e46a2c178464';catalog='style-token-inference-integrated-20261109.noncli-r1.catalog.inventory.json'}
)
$records=@(foreach($baseline in $baselines){
 $inventory=Get-Content "$r/$($baseline.catalog)" -Raw|ConvertFrom-Json -Depth 20
 $before=@($inventory.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $graph.packages.name})
 $missing=@(foreach($row in $before){
  $key=$row.binary+[char]0+$row.test
  [void]$known.Add($key)
  if(!$keys.Contains($key)){$row}
 })
 if($missing.Count){$missing|ConvertTo-Json -Depth 8|Set-Content "$r/style-environment-20261109.coverage.missing.json";throw ('Retained case missing: '+$baseline.source)}
 [ordered]@{source=$baseline.source;catalog=$baseline.catalog;retainedInCurrentClosure=$before.Count;missing=0}
})
$additional=@($after|Where-Object {!$known.Contains(($_.binary+[char]0+$_.test))})
[ordered]@{
 version=1;source='ef2679347c14dccee649e5fb716d3a37510cac1f';currentSelected=$after.Count
 baselines=$records;baselineCountsAreOverlapping=$true;baselineUnionRetained=$known.Count;missing=0;duplicates=0
 additionalCurrentCases=$additional.Count;additionalByPackage=@($additional|Group-Object package|ForEach-Object {[ordered]@{package=$_.Name;cases=$_.Count}})
 rename=@()
 selection=[ordered]@{selectedNonCliPackages=40;matchedPackages=@($after.package|Sort-Object -Unique).Count;buildOnlyPackages=@($graph.packages.name|Where-Object {$_ -ne 'arcweft-cli' -and $_ -notin $after.package})}
 scope='Preserve the preceding complete View catalog and the subsequent Sema inference catalog. Their counts overlap: compare each baseline independently and use the union for retained coverage. Do not label previously authored cases as new. Three selected packages with no cases have compile evidence only. Fresh runtime totals come only from the final current nonCLI/CLI runs.'
}|ConvertTo-Json -Depth 12|Set-Content "$r/style-environment-20261109.coverage.json"
Get-Content "$r/style-environment-20261109.coverage.json"
