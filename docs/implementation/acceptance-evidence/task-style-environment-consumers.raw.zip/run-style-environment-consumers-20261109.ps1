$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$graph=Get-Content "$r/style-environment-20261109.graph.json" -Raw|ConvertFrom-Json -Depth 30
$packages=@($graph.packages.name|Where-Object {$_ -ne 'arcweft-cli'}|Sort-Object -Unique)
if($packages.Count -ne 40){throw 'Unexpected View consumer closure'}
$selection=@('--locked','--all-features','--lib','--tests')
foreach($package in $packages){$selection+=@('-p',$package)}
$selection+=@('-E','rdeps(=arcweft-view)')
$new=@(Get-Content "$r/style-environment-20261109.additional-paths.json" -Raw|ConvertFrom-Json)
& "$r/run-retained-input-frozen-matrix-20261108.ps1" -Stem 'style-environment-integrated-20261109.noncli-r1' -Selection $selection -AdditionalPaths $new
exit $LASTEXITCODE