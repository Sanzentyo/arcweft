$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-environment-20261109.source-checkpoint.verified.json'
$noncli=Read-Record 'style-environment-integrated-20261109.noncli-r1.runtime.terminal-audit.json'
$cli=Read-Record 'style-environment-integrated-20261109.cli-r1.runtime.terminal-audit.json'
$old=Read-Record 'style-token-inference-integrated-20261109.cli-r1.runtime.terminal-audit.json'
$main=Read-Record 'style-environment-integrated-20261109.cli-r1.main-audit.json'
$probe=Read-Record 'style-environment-20261109.native-r1.json'
$priorProbe=Read-Record 'style-token-inference-20261109.native-r1.json'
$coverage=Read-Record 'style-environment-20261109.coverage.json'
$diagnostics=Read-Record 'style-environment-integrated-20261109.failure-diagnostics.json'
if((git rev-parse HEAD).Trim() -ne 'c5a4c901473354a3cc87d122b85ac47096fb1b6e'){throw 'Matrix base changed'}
if($noncli.actualExitCode -ne 0 -or $noncli.executed -ne 4686 -or $cli.executed -ne 711 -or $cli.failed -ne 4){throw 'Unexpected matrix result'}
if(@(Compare-Object @($old.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object) @($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)).Count){throw 'CLI failure IDs changed'}
if($probe.checkExitCode -ne 0 -or $probe.bundleExitCode -ne 0 -or $probe.main.sha256 -ne $main.sha256 -or $main.binaryDrift -ne 0 -or $probe.artifact.sha256 -ne $priorProbe.artifact.sha256){throw 'Actual CLI or Source probe changed'}
if($coverage.missing -ne 0 -or $coverage.duplicates -ne 0 -or $coverage.currentSelected -ne $noncli.executed){throw 'Coverage mismatch'}
if(@(Compare-Object @($noncli.noMatchingSelectedTests|Sort-Object) @($coverage.selection.buildOnlyPackages|Sort-Object)).Count){throw 'Build-only selection mismatch'}
$archive='docs/implementation/acceptance-evidence/task-style-environment-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(foreach($filter in @('style-environment-integrated-20261109*','style-environment-20261109.native-r1*')){Get-ChildItem -LiteralPath $r -File -Filter $filter|Where-Object {$_.Extension -in @('.json','.log')}})
$files+=@('style-environment-20261109.coverage.json','run-style-environment-consumers-20261109.ps1','run-style-environment-cli-consumers-20261109.ps1','audit-style-environment-coverage-20261109.ps1','audit-style-environment-cli-failures-20261109.ps1','run-style-environment-native-source-probe-20261109.ps1','record-style-environment-consumers-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';productionPublication=$pub;recordingBase=(git rev-parse HEAD).Trim()
 status='Source-bound Style Environment passed the complete View consumer execution apart from the same four diagnosed CLI failures. Full sample and real Native/Web operation/capture acceptance remain open.'
 qualityReuse='Reuse styleEnvironmentSourceCheckpoint all98 workspace gates and final integration-test lint/fmt for unchanged bytes. The complete runs here validate the final test spelling corrections too.'
 nonCli=$noncli;cli=$cli;coverage=$coverage
 freshTotals=[ordered]@{executed=$noncli.executed+$cli.executed;passed=$noncli.passed+$cli.passed;failed=$noncli.failed+$cli.failed;skipped=$noncli.skipped+$cli.skipped;runs=2;featurePoints=2}
 failureDiagnostics=$diagnostics;actualCli=$main;nativeSourceProbe=$probe
 scope='View41 = nonCLI40 all-features + CLI1 defaults. Runtime cases belong to37 nonCLI packages; arcweft/bundle-assets/render-web have compile evidence only. Prior View4677 and Sema3622 catalog counts overlap: retain their union4681 with missing/duplicate0, plus5 new cases Compiler3/Sema1/View1. Fresh5397 executions exclude owner55, previous runs, separate probes and skipped cases. No newly selected existing cases are counted as newly authored tests.'
 independentInvestigation='While the matrix was live, separate temporary modern-feedback migration and minimal stateful-goto probes discovered a target-formal/argument defect. These are separate inputs and are not included in the5397 count. Preserve the raw probes and exact CLI pins; do not present the whole goal or sample migration as complete. Record their detailed current state separately.'
 pending='Remaining samples, stateful Flow transfer target/argument admission and execution, actual Native/Web operation/capture parity, and the four existing CLI failures. Preserve accepted explicit construction, inference, Generic Match and other completed boundaries.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 149 -or $prior.PSObject.Properties.Name -contains 'styleEnvironmentConsumers'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "styleEnvironmentConsumers": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$source=$pub.commit
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$styleRow='| Style 指定値・token・構築処理 | **構築・推論の既受入を維持。EnvironmentのSource接続を全View consumerで検証・公開** | Source '+$source+'。元sheet・body path・clause・ExprIdの検査結果をnative条件型へ渡し、入れ子のpredicate／body／scope／clauseのSourceと全ルールの記述順を保持する。閉じた値の等値条件、text-scaleの6比較と正確な0.5〜4.0、最大4 wrapper／4非重複fieldを扱う。owner55件の後、最終SourceのView逆依存41 packageを実行した。横断実測・既知CLI4失敗・品質は下表に集約する。残るsampleと実Native／Web操作／表示は継続し、以前の構築・推論の受入を戻さない。[全SHA・実測・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$matrixRow='| 共有契約／推移的逆依存matrix | **今回View範囲5397実行：5393 PASS／4 FAIL／41 SKIP** | Source '+$source+'。metadata／target-all tree一致のView逆依存41 packageを、非CLI全feature40とCLI既定へ分けた。非CLIは4686／4686 PASS・18 SKIP・416.657秒で、37 packageがruntime caseを持つ。arcweft／bundle-assets／render-webの3 packageはcompile検証の範囲。旧View4677件と後続Sema3622件はそれぞれ欠落0、重複する和集合4681件の欠落／重複0、追加5件はCompiler3／Sema1／View1。Source／catalog／実EXE drift0。最終2 run／2 feature pointのみ集計し、owner55件・旧run・別Source probeは加算しない。[終端・coverage・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$cliRow='| CLIの規定対象／全 check 照合 | **Environment統合後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | Source '+$source+'、524.277秒。先行と同じ4失敗IDと実診断を照合し、新規失敗0。Scrollのshared callable Expr15拒否、active dialogue has no voice、promotion2件のsolver到達前Expr8 type-check拒否は未解消。元pathの実CLI本体とtest EXEを前後照合し、CLI SHA256は'+$main.sha256+'。同じ実CLIによるnative-text-input check／main-profile bundle生成も終了0、89命令／81840 bytes、生成物hashは前回と一致する。このprobeや別のgoto probeを711件へ加算しない。[診断・EXE pin・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status=(@($status -split $lf|ForEach-Object {
 if($_.StartsWith('| Style 指定値・token・構築処理 ')){$styleRow}
 elseif($_.StartsWith('| 共有契約／推移的逆依存matrix ')){$matrixRow}
 elseif($_.StartsWith('| CLIの規定対象／全 check 照合 ')){$cliRow}
 else{$_}
})) -join $lf
if(($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — Style Environmentの全View consumer検証

Source $source、記録base c5a4c901473354a3cc87d122b85ac47096fb1b6e を固定した。最終test表記まで含むView逆依存41 packageを、非CLI全feature40＋CLI既定1で実行した。非CLIは4686／4686 PASS・18 SKIP・416.657秒、37 packageにruntime caseがあり、arcweft／bundle-assets／render-webの3 packageはcompile証拠のみ。3920入力／catalog／実EXE差分0。前回View4677件と後続Sema3622件はそれぞれ欠落0、重複する和集合4681件の欠落／重複0、追加5件はCompiler3／Sema1／View1。renameはない。

CLIは $($cli.summary)。先行の4失敗IDと実診断を照合し、Scrollのshared callable Expr15、voice不在、promotion2件のsolver前type-check Expr8拒否は継続し、新しい失敗はない。3944入力／catalog／実EXE差分0。元target/debug/arcw.exeの前後pinはSHA256 $($main.sha256) で一致する。今回の最終2 run／2 feature pointは5397実行／5393 PASS／4 FAIL／41 SKIPで、owner55件・旧run・別Source probeを加算しない。

同じ実CLIを追加buildなしで使い、native-text-input checkはstatus ok、main-profile bundleは終了0・89命令・81840 bytes。元path $($probe.artifact.path) のSHA256 $($probe.artifact.sha256) は前回と一致し、3920入力／実CLI差分0。Source受付・生成物の検証であり、実Native／Web操作・画像parityの受入とは区別する。

並行した一時Source fixtureの調査では、modern-feedbackの現行API移行案がcheckを通る一方、GameState付き自己gotoはAWBCで要求1引数／実際0引数となる別の未達を再現した。同じformalを持つ空Flowの対照は13命令のbundle生成に成功する。この別入力の失敗は5397件の集計へ混ぜず、原本とCLI pinを保持して別項目として調査・修復する。引数なしgoto、Style、Generic Matchなどの既受入を未完了に戻さない。

現状一覧のEnvironmentを「全consumer実行中」から今回の終端結果へ訂正した。以前のSource／失敗／full SHA／実測を保持し、旧現状の重複は履歴へ集約した。既存149 registry propertyの値を全件照合して保持し、styleEnvironmentConsumersを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。EXE／AWFB等のbuild artifactをZIPへコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;freshTotals=$entry.freshTotals;archive=$entry.archive}|ConvertTo-Json -Depth 6|Set-Content "$r/style-environment-20261109.consumer-acceptance-record.json"
Get-Content "$r/style-environment-20261109.consumer-acceptance-record.json"
