$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$runs=@('presentation-factory-native-context-focus1-20261101','presentation-factory-native-context-complement-20261101')
function Read-Record([string]$name) { Get-Content "$taskTemp/$name.json" -Raw|ConvertFrom-Json -Depth 100 }
$first=Read-Record ($runs[0]+'.catalog.inventory')
$second=Read-Record ($runs[1]+'.catalog.inventory')
$other=@{};foreach($row in $second.rows){$key=$row.binary+"`t"+$row.test;if($other.ContainsKey($key)){throw 'Repeated complement case'};$other[$key]=$row}
if($other.Count -ne $first.rows.Count){throw 'Catalog universes differ'}
$selected=[Collections.Generic.HashSet[string]]::new()
$cases=@(foreach($row in $first.rows){
    $key=$row.binary+"`t"+$row.test
    if(-not $selected.Add($key) -or -not $other.ContainsKey($key)){throw 'Case identity drift'}
    $next=$other[$key]
    if($row.ignored -or $next.ignored){throw 'Unexpected ignored owner case'}
    $left=$row.status -eq 'matches';$right=$next.status -eq 'matches'
    if($left -eq $right){throw 'Case is repeated or omitted by the partition'}
    [ordered]@{binary=$row.binary;test=$row.test;run=$(if($left){$runs[0]}else{$runs[1]});passed=$true}
})
$freeze=Read-Record ($runs[0]+'.source-freeze')
$reference=@{};foreach($row in $freeze.paths){$reference[$row.path]=$row.sha256}
$executables=Read-Record ($runs[0]+'.binaries-before')
$pins=@{};foreach($row in $executables){$pins[$row.binary]=$row.sha256}
$terminals=@(foreach($run in $runs){
    $current=Read-Record "$run.source-freeze"
    if($current.paths.Count -ne $reference.Count -or @($current.paths|Where-Object {$reference[$_.path] -ne $_.sha256}).Count){throw 'Source input drift between partitions'}
    $binary=Read-Record "$run.binaries-before"
    if($binary.Count -ne $pins.Count -or @($binary|Where-Object {$pins[$_.binary] -ne $_.sha256}).Count){throw 'Executable drift between partitions'}
    $terminal=Read-Record "$run.runtime.terminal-audit"
    if($terminal.failed -or $terminal.actualExitCode -or $terminal.sourceDrift -or $terminal.catalogCaseDrift){throw 'Non-passing owner partition'}
    $terminal
})
$passed=[int]($terminals|ForEach-Object passed|Measure-Object -Sum).Sum
if($passed -ne $cases.Count -or $passed -ne 2577){throw 'Unexpected combined coverage'}
if(@(git diff 9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3 --name-only -- '*Cargo.toml' Cargo.lock rust-toolchain.toml .cargo/config.toml).Count){throw 'Resolved graph input drift'}
$result=[ordered]@{version=1;base=$freeze.base;runs=$runs;passed=$passed;failed=0;ignored=0;duplicateCases=0;omittedCases=0;sourceInputs=$freeze.paths.Count;sourceInputDrift=0;executableDrift=0;byBinary=@($cases|Group-Object {$_['binary']}|ForEach-Object {[ordered]@{binary=$_.Name;passed=$_.Count}});terminals=$terminals;cases=$cases;resolvedReverseClosure='presentation-factory-native-metadata.reverse-closure.json';reversePackages=53;dependencyInputDrift=0;scope='Private Native Engine origin checks; complete Core library and Compiler library/callable_execution. Other runtime consumers and CLI were not rerun. The prior 53-package matrix remains evidence only for source 9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3.';selectionRationale='Only private Engine call/registration admission changes. Public types, serialized contracts, schema tags, Source/metadata grammar, AWBC and Cargo inputs are unchanged. Owner tests cover the five invalid-context paths and actual Native/decoded-AWBC Source image execution, source order and per-step save/restore. The remainder of the same three executables is selected once, as a disjoint complement.';recordedAt=[DateTime]::UtcNow.ToString('o')}
$output="$taskTemp/presentation-factory-native-context.owner-partition.json"
if(Test-Path $output){throw 'Partition audit exists'}
$result|ConvertTo-Json -Depth 25|Set-Content $output -Encoding utf8
[ordered]@{passed=$passed;duplicates=0;omitted=0;sourceDrift=0;executableDrift=0;byBinary=$result.byBinary}|ConvertTo-Json -Depth 5 -Compress
