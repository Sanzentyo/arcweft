$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$before=Get-Content "$taskTemp/presentation-factory-native-context.docs-before.json" -Raw|ConvertFrom-Json
$history=[IO.File]::ReadAllBytes($before.path)
$prefix=[byte[]]::new($before.bytes)
[Array]::Copy($history,$prefix,$before.bytes)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $before.sha256){throw 'Historical prefix changed'}
$status=[IO.File]::ReadAllText('docs/implementation/current-status.md')
if([regex]::Match($status,'(?m)^\| Generic Match.*$').Value -cne $before.genericRow){throw 'Generic Match row changed'}
$links=[Collections.Generic.List[object]]::new()
foreach($path in @('docs/implementation/current-status.md','docs/implementation/convergence-evidence-history.md')) {
    $text=[IO.File]::ReadAllText($path)
    if(@([regex]::Matches($text,'(?m)^```')).Count % 2){throw "Unbalanced fence: $path"}
    foreach($match in [regex]::Matches($text,'\[[^\]\r\n]+\]\(([^)\r\n]+)\)')) {
        $target=$match.Groups[1].Value.Trim().Trim('<','>')
        if($target -match '^[a-zA-Z][a-zA-Z0-9+.-]*:' -or $target.StartsWith('#')){continue}
        $target=($target -split '#',2)[0]
        $target=[Uri]::UnescapeDataString($target)
        $resolved=[IO.Path]::GetFullPath((Join-Path (Split-Path $path -Parent) $target))
        if(-not(Test-Path -LiteralPath $resolved)){throw "Broken local link: $path -> $target"}
        $links.Add([ordered]@{source=$path;target=$target})
    }
}
& git diff --check
if($LASTEXITCODE -ne 0){throw 'Whitespace validation failed'}
$receipt=Get-Content 'docs/implementation/acceptance-evidence/task-presentation-factory-native-context.json' -Raw|ConvertFrom-Json -Depth 100
$audit=[ordered]@{version=1;source=$receipt.source;inspectedHead=(git rev-parse HEAD).Trim();checkedDocuments=@('docs/implementation/current-status.md','docs/implementation/convergence-evidence-history.md');localLinks=$links.Count;brokenLinks=0;fencesBalanced=$true;historicalPrefixBytes=$before.bytes;historicalPrefixDrift=0;oldCommitShaLoss=0;acceptedGenericMatchRowUnchanged=$true;rawEntryCount=$receipt.raw.entryCount;rawEntryDrift=$receipt.raw.entryDrift;rawZipSha256=$receipt.raw.sha256;diffCheckExit=0;recordedAt=[DateTime]::UtcNow.ToString('o')}
$output='docs/implementation/acceptance-evidence/task-presentation-factory-native-context-doc-audit.json'
if(Test-Path $output){throw 'Immutable documentation audit exists'}
$audit|ConvertTo-Json -Depth 10|Set-Content $output -Encoding utf8
$audit|ConvertTo-Json -Compress
