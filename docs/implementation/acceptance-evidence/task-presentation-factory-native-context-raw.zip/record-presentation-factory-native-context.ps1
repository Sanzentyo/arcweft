$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Record([string]$name) { Get-Content "$taskTemp/$name.json" -Raw|ConvertFrom-Json -Depth 100 }
$publication=Read-Record 'checkpoint-presentation-factory-native-context.verified'
$tests=Read-Record 'checkpoint-presentation-factory-native-context-regressions.verified'
$source=$publication.commit
$head=(git rev-parse HEAD).Trim()
if($head -ne $source){throw 'Record the exact published source before its documentation commit'}
foreach($row in $publication.paths){if((git rev-parse ('HEAD:'+$row.path)).Trim() -ne $row.blob){throw 'Published blob drift'}}
$owner=Read-Record 'presentation-factory-native-context.owner-partition'
if($owner.passed -ne 2577 -or $owner.failed -or $owner.duplicateCases -or $owner.omittedCases){throw 'Unverified owner partition'}
$ownerSummary=[ordered]@{};foreach($property in $owner.PSObject.Properties){if($property.Name -ne 'cases'){$ownerSummary[$property.Name]=$property.Value}}
$quality=@(foreach($suffix in @('default-core','workspace-check','clippy','structure','fmt')){
    $record=Read-Record "presentation-factory-native-context-quality-20261101.$suffix"
    if($record.exitCode -ne 0 -or $record.sourceDrift){throw "Failed quality gate: $suffix"}
    [ordered]@{gate=$suffix;record=$record}
})
$freeze=Read-Record 'presentation-factory-native-context-quality-20261101.source-freeze'
$reference=@{};foreach($row in $freeze.paths){$reference[$row.path]=$row.sha256;if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$bridge=@(foreach($run in $owner.runs){
    $prior=Read-Record "$run.source-freeze"
    if($prior.paths.Count -ne $reference.Count -or @($prior.paths|Where-Object {$reference[$_.path] -ne $_.sha256}).Count){throw 'Validated source bridge differs'}
    [ordered]@{run=$run;base=$prior.base;publishedSource=$source;inputs=$reference.Count;pathHashDrift=0}
})
$changedRust=@(git diff 9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3 HEAD --name-only -- crates ':!**/AGENTS.md')
$expected=@('crates/arcweft-core/src/engine/eval/calls.rs','crates/arcweft-core/src/engine/presentation.rs','crates/arcweft-core/src/engine/eval/calls/presentation_tests.rs')
if(@(Compare-Object ($expected|Sort-Object) ($changedRust|Sort-Object)).Count){throw 'Private change scope differs'}
if(@(git diff 9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3 --name-only -- '*Cargo.toml' Cargo.lock rust-toolchain.toml .cargo/config.toml).Count){throw 'Dependency inputs drifted'}
$original=Get-Content 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json' -Raw|ConvertFrom-Json
$changed=@($original.held|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($changed.Count -ne 1 -or $changed[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or (git hash-object -- $changed[0].path).Trim() -ne '4df23c4afc860ca51ff3255befe87b69a16de39b'){throw 'Original WIP drift'}
$untracked=@(git ls-files --others --exclude-standard)
if($untracked.Count -ne 6 -or @($untracked|Where-Object {$_ -notin @($original.held.path)}).Count){throw 'Original untracked set changed'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath=Join-Path $evidence 'task-presentation-factory-native-context-raw.zip'
$receiptPath=Join-Path $evidence 'task-presentation-factory-native-context.json'
if((Test-Path $zipPath) -or (Test-Path $receiptPath)){throw 'Immutable evidence exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like '*presentation-factory-native-context*' -or $_.Name -in @('run-shared-identity-owner.ps1','audit-nextest-final-result.ps1')})+@(Get-ChildItem "$taskTemp/presentation-factory-native-context-quality-20261101.structure-report" -File)
$files=@($files|Sort-Object FullName -Unique)
$raw=@(foreach($file in $files){[ordered]@{name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try {for($index=0;$index -lt $files.Count;$index++){$entry=$archive.CreateEntry($raw[$index].name,[IO.Compression.CompressionLevel]::Optimal);$stream=$entry.Open();try{$bytes=[IO.File]::ReadAllBytes($files[$index].FullName);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}}finally{$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try{if($archive.Entries.Count -ne $raw.Count){throw 'Raw entry count differs'};foreach($row in $raw){$entry=$archive.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw 'Raw entry drift'}}}finally{$archive.Dispose()}
$result=[ordered]@{
    version=1;date='2026-11-01';source=$source;inspectedHead=$head;publication=$publication;testOnlyKnownFailingPublication=$tests
    status='Native factory execution origin checked before capture; broader staging is not completed by this private change'
    initialCatalog=(Read-Record 'presentation-factory-native-context-baseline1-20261101.catalog');baseline=(Read-Record 'presentation-factory-native-context-baseline2-20261101.runtime.terminal-audit')
    owner=$ownerSummary;quality=$quality;sourceInputs=$reference.Count;sourceDrift=0;validatedInputBridge=$bridge
    implementation=@('One Engine-owned context check validates the exact original plan Arc, execution/fiber identity, all lexical scope-header contexts, absent Engine bank storage while any scoped grant remains, and the original artifact. Both pre-capture evaluation and final registration use it.','The check borrows the actual frame and returns its artifact binding; it does not copy captures, allocate banks, mint grants or reconstruct Source. Static input/body/result identity validation still runs first.','The baseline reproduces one capture evaluation in each of five rejected contexts. The repaired tests prove zero evaluations, absent new ledger and unchanged original lexical grants, including an orphaned parent scope.')
    ownershipReview='Execution origin belongs to Engine and its actual frame/environment. The old registration-only guards are removed in favor of one shared method. RuntimeEnv remains the authority for scope-header context matching. No public type, wire/codec shape, schema, version marker, Cargo input or AWBC behavior is changed.'
    corrections=@('The first catalog failed because the new fixture omitted the RuntimePayload import; fixed in the fixture without widening production visibility.','The first partition-report per-binary grouping used PowerShell property reflection on OrderedDictionary keys. Its initial aggregate and correction are retained in the owner audit. The exact same 2577 case records, runtime results, partition and hashes were retained; no tests were rerun for that reporting correction.')
    limits=@('This proves pre-capture rejection for Native execution-origin invariants. Payload construction, later ledger/site capacity and complete live evaluation temporaries/all-fiber failure atomicity remain separate. Capacity can change during valid argument evaluation, so it is not rejected speculatively before arguments.','No new full 53-package runtime matrix or CLI run was performed. The latest full matrix/CLI evidence remains attached to source 9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3 and is not relabeled as a result on this source.','Wasm, doctest, Tier 2 and final Native/Web image parity were not rerun for this private change.','Generic Match remains accepted. The prior exact 151-case verification is retained; this owner partition is not presented as a new full Generic Match run.')
    priorEvidence='task-presentation-factory-native-metadata.json'
    originalWip=[ordered]@{tracked=14;actualUntracked=6;unchangedOldHashes=19;benchWorkingBlob='4df23c4afc860ca51ff3255befe87b69a16de39b';heldPatchSha256=$publication.heldPatchSha256}
    raw=[ordered]@{path='task-presentation-factory-native-context-raw.zip';entryCount=$raw.Count;entryDrift=0;sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$raw};recordedAt=[DateTime]::UtcNow.ToString('o')
}
$result|ConvertTo-Json -Depth 100|Set-Content $receiptPath -Encoding utf8
[ordered]@{source=$source;ownerPassed=$owner.passed;sourceInputs=$reference.Count;rawEntries=$raw.Count;rawSha256=$result.raw.sha256;rawBytes=(Get-Item $zipPath).Length}|ConvertTo-Json -Compress
