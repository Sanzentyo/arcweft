$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$receipt=Get-Content 'docs/implementation/acceptance-evidence/task-presentation-factory-native-context.json' -Raw|ConvertFrom-Json -Depth 100
$source=$receipt.source
$link='[再現・修復・入力照合の原本](acceptance-evidence/task-presentation-factory-native-context.json)'
$path='docs/implementation/current-status.md'
$text=[IO.File]::ReadAllText($path)
$header='確認日: 2026-11-01。公開実装Sourceは {0}。元14 tracked／6 actual untracked WIPを保持し、今回のprivate owner検証は4,057入力で行った。直近の全逆依存／CLI実行は9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3の結果であり、本Sourceの再実行結果とは区別する。各行の結果は記載した入力・境界に限る。' -f $source
$text=[regex]::Replace($text,'(?m)^確認日:.*$',$header)
$rows=[ordered]@{}
$rows['Presentation resource本体・Source factory実行']='| Presentation resource本体・Source factory実行 | **Source image slice・metadata／Native実行元の事前拒否を検証・公開。staging全体は受入前** | 公開{0}。元Source・実executable・key・tuple型・元invocationを持つaffine本体、CallExpr公開前／Native引数評価前のbody・resource・Handle結果型・入力identity／ABI検査を維持する。Nativeは同じEngineの検査で元planの実Arc、実行ID、artifact、全lexical scopeのcontext headerを確認し、grantがあるのにbank storageが無い状態も引数評価前に拒否する。等しいbytesの別program、実行ID不一致、artifact欠如、現在／親scopeのledger欠如の5再現を修復し、capture 0回・既存grant不変・新規ledgerなしを確認。Core library全2,201件とCompilerの対象376件、計2,577 unique PASSは実Source imageのNative／decoded AWBC・評価順12・Image／Root Handle・AWBC各step保存復元を含む。明示scope capability、View生成、command／method・driver、全live候補の構築前検査と後段registrationの失敗原子性は別境界。{1}。 |' -f $source,$link
$rows['CLI・全 consumer の統合受入']='| CLI・全 consumer の統合受入 | **直近の全CLI実行は43失敗・本Sourceでは未再実行。統合受入は未完了** | 全12 targetの最新実測は9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3の結果として下表に保持する。今回のprivate origin修復のowner結果から全CLIの成否を推定しない。[直近の全CLI原本](acceptance-evidence/task-presentation-factory-native-metadata.json)、{0}。 |' -f $link
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **default Coreと各gate終了0・構造blocking0・警告は残存** | {0}と同一の4,057入力。default Core全target・locked check、workspace全97 package・全target・全feature・locked check／Clippy、変更3 Rust path fmtは終了0。構造は3293 files／3163 Rust files・1785336 physical Rust LOC・384 review trigger・blocking0。Wasm・doctest・Tier 2は今回未再実行。{1}。 |' -f $source,$link
foreach($name in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($name)+' \|.*$'
    if([regex]::Matches($text,$pattern).Count -ne 1){throw "Expected one row: $name"}
    $text=[regex]::Replace($text,$pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($match) $rows[$name]})
}
$text=$text.Replace('**Coreの53 package選択。通常3群 7116 PASS／0 FAIL／16 ignored**','**直近の全53 package実行（以前のSource）。通常3群 7116 PASS／0 FAIL／16 ignored**')
$ownerRow='| Native factory originのprivate owner | **2,577 unique PASS／0 FAIL・重複0／未選択0** | Source {0}・4,057入力。同じ3実行ファイルを185件と残り2,392件に分け、Core library全2,201件、Compiler library 175件／callable_execution 201件を一度ずつ実行した。case／Source／EXE差分0。実resolved逆依存は53 packageと確認し、public型・wire・Source grammar・AWBC・Cargo入力に変更のないprivate Engine検査としてownerを選択した。全53 runtimeと全CLIは再実行していない。{1}。 |' -f $source,$link
if($text.Contains('| Native factory originのprivate owner |')){throw 'Owner status already exists'}
$marker='| Presentation factory／共有値の逆依存matrix |'
if(-not $text.Contains($marker)){throw 'Full matrix row missing'}
$text=$text.Replace($marker,$ownerRow+"`n"+$marker)
[IO.File]::WriteAllText($path,$text,[Text.UTF8Encoding]::new($false))
$history=[IO.File]::ReadAllText("$taskTemp/presentation-factory-native-context.history-template.txt")
$history=$history -f $source,$receipt.testOnlyKnownFailingPublication.commit,$receipt.raw.entryCount,$receipt.raw.sha256
[IO.File]::AppendAllText('docs/implementation/convergence-evidence-history.md',$history,[Text.UTF8Encoding]::new($false))
Write-Output 'Private origin status updated; prior full-matrix results remain attached to their source'
