$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prefix='flow-transfer-presentation-20261109.wip4'
$base=(& git rev-parse HEAD).Trim()
if($base -ne '10474f06766f05b4583ba45086f69115e38b3371'){throw 'Unexpected base'}
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$rust=@(git diff --name-only -- '*.rs')+@('crates/arcweft-core/src/engine/presentation_tests/flow_transfer.rs')
$rows=@(foreach($p in $rust){$item=Get-Item -LiteralPath $p;[ordered]@{path=$p;bytes=$item.Length;physicalLoc=[IO.File]::ReadAllLines($item.FullName).Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$list=[IO.File]::ReadAllText((Join-Path $e 'flow-transfer-presentation-owners-list-r3.json'))|ConvertFrom-Json -Depth 100
$binary=($list.'rust-suites'.PSObject.Properties.Value|Where-Object {$_.'binary-id' -eq 'arcweft-core'}).'binary-path'
$patch=Read-GitBytes @('diff','--binary','--full-index',$base)
$patchName=$prefix+'.r3.patch';[IO.File]::WriteAllBytes((Join-Path $e $patchName),$patch)
$metadata=[ordered]@{version=1;base=$base;kind='intermediate-unaccepted-source-checkpoint';r3SourcesObservedAfterRun=$rows;untrackedSource='crates/arcweft-core/src/engine/presentation_tests/flow_transfer.rs';trackedPatch=$patchName;patchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant();r3BinaryObservedAfterRun=[ordered]@{path=$binary;sha256=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant()};binaryPinScope='post-run observation only; no before/after drift claim';r1=[ordered]@{executed=1;passed=0;failed=1;skipped=2395;seconds=0.046};r2=[ordered]@{executed=46;passed=46;failed=0;skipped=2350;seconds=0.462;testBuildSeconds=58.45};r3=[ordered]@{executed=47;passed=47;failed=0;skipped=2350;seconds=0.431;testBuildSeconds=42.16;filter='test(engine::presentation_tests) | test(engine::defer) | test(flow_transfer) | test(engine::function_scope)'};checkR2=[ordered]@{exit=0;allTargets=$true;allFeatures=$true;seconds=56.25};clippyR3=[ordered]@{exit=0;allTargets=$true;allFeatures=$true;warnings=$true;seconds=65};graphReused='flow-transfer-plan-rdeps.json: Core closure 53, manifests/lock/features unchanged';notRun=@('final 53-package reverse-dependency matrix','workspace quality gates','explicit Source arguments','affine arguments across function calls and all cancellation/failure cases','Native/Web visual acceptance')}
$name=$prefix+'.metadata.json';[IO.File]::WriteAllText((Join-Path $e $name),($metadata|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
$archive='docs/implementation/acceptance-evidence/task-flow-transfer-presentation-wip4.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$names=@('record-flow-transfer-presentation-wip4.ps1',$name,$patchName,'flow-transfer-presentation-r1-r2.sources.json','flow-transfer-presentation-r1.patch','flow-transfer-presentation-r2.patch','flow-transfer-presentation-original-tests.rs','flow-transfer-presentation-owner-list-r1.log','flow-transfer-presentation-owner-list-r1.json','flow-transfer-presentation-owner-r1.log','flow-transfer-presentation-check-r2.log','flow-transfer-presentation-owners-list-r2.log','flow-transfer-presentation-owners-list-r2.json','flow-transfer-presentation-owners-r2.log','flow-transfer-presentation-owners-list-r3.log','flow-transfer-presentation-owners-list-r3.json','flow-transfer-presentation-owners-r3.log','flow-transfer-presentation-clippy-r3.log')
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($p in $rust){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,[IO.Path]::GetFullPath($p),'source/'+$p)};foreach($n in $names){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $e $n),'evidence/'+$n)}}finally{$zip.Dispose()}
$hash=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();$size=(Get-Item -LiteralPath $archive).Length
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($archive));try{$entries=$zip.Entries.Count;if(@($zip.Entries|Where-Object {$_.FullName -match '\.(exe|awfb|dll|pdb)$'}).Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$p='docs/implementation/current-status.md';$status=[IO.File]::ReadAllText($p)
$start=$status.IndexOf('途中Source b146a7490ac78f413505f8755148ef86c6048384を基点に、',[StringComparison]::Ordinal)
$end=$status.IndexOf('診断の原文位置表示が現CLIで省略される問題も未達。',$start,[StringComparison]::Ordinal)
if($start -lt 0 -or $end -lt 0){throw 'Current goto checkpoint changed'}
$replacement='途中Source 10474f06766f05b4583ba45086f69115e38b3371のPlan公開前検査・借用codec preflight・Native一括入力Moveを維持して実装中。deferなしGotoが渡すView handleまで解放する新規回帰を実際に再現し、転送先の実rootへ事前検査付きで寿命を移す処理へ修復した。Gotoはdeferの有無によらず元の実スコープで入力を保持し、移管拒否時も保留入力／scope／grantを変更しない。毎step private rollbackを通すView handle転送と、RetirementCapacity拒否前後の完全image一致を含む47件PASS、Core全target／全feature check・Clippy終了0（警告あり）。先行runは別Sourceの履歴として保持し、加算しない。全53逆依存、呼出しframeを跨ぐaffine入力・全取消し／失敗matrix、Sourceの明示bindingと型の完全admissionは未完了。[再現失敗・修復・原本](acceptance-evidence/task-flow-transfer-presentation-wip4.raw.zip)。'
$status=$status.Substring(0,$start)+$replacement+$status.Substring($end);[IO.File]::WriteAllText($p,$status,[Text.UTF8Encoding]::new($false))
$addition=@'

## 2026-11-09 Native Flow rootの描画資源転送途中checkpoint（受入未了）

先行Plan途中Source 10474f06766f05b4583ba45086f69115e38b3371をmainへ公開済み。parent b146a7490ac78f413505f8755148ef86c6048384、tree 3571eea8f822bbc28b17b7d701e87baa30f818a0、patch SHA256 bb6d35019524ef82b7f0da537ad3fc53d0e8a39f81b4cf580ea4b4745ac17aff。14明示pathのblob・差分・非forced remote refを照合し、index空、held tracked WIP 0、registryの153既存propertyとGeneric Match行を維持した。今回もユーザーの途中保存指示によるcheckpointである。

新規回帰r1を実行し、deferのない引数付きGotoでView handleが転送先の開始前に解放される1 FAILを再現した（0 PASS／1 FAIL／2395 filter SKIP、0.046秒）。実際の元Engine／scope／ledgerで発行したhandleをtuple入力へ渡し、元スコープに残る別資源と区別して観測した。原因は、defer_targetがworkのあるscopeだけを対象にするため、空scopeのGotoは入力を保持する終了継続を経由せず、activateのunwindで渡すhandleもretireしていたこと。最初のfixtureとその基点差分・失敗ログを保持した。

Flow境界はworkの有無にかかわらず実scopeを選び、元のNativeLexicalExitに全入力を保持する。最終scopeをpopしたり入力を束縛へ移したりする前に、元Planの完全入力契約、元function instantiation、受入済みbody work、全source contourと実際のreceiving rootのgrant／retirement容量を借用検査する。ephemeralなNativePreparedFlowRootは実Env・元Plan・元work queueを排他的に保持し、Clone／codec／別schemaを持たない。検査成功後だけledgerの一つのtransitionで渡すleaseを受け取り先へ移し、残る元資源をretireし、同じ実rootをframeへ設置する。Envの移動ではsource stepのdiscard authorizationを維持する。元のABI／pattern authorityとSans-I/Oを変えず、架空のSource IDやlive能力を発行していない。

Coreのlocked／全target／全feature checkは終了0／56.25秒。r2のnextest listはbuild終了0／58.45秒、関連46件のrunは46 PASS／2350 filter SKIP／0.462秒。r1失敗fixtureの成功、元scopeの別資源だけが先にretireし、渡すView handleは転送先終了まで保持されること、毎step private rollback復元を確認した。r3で実際の先行retirementにより容量を満たした拒否ケースを追加。RetirementCapacityが発生する前後で完全なprivate imageが一致し、保留入力・source scopes・両handleの元grantが保持されることを、復元を挟んだ2回の拒否で検査する。元のassertionやbudgetは弱めず、各stepは1 op以下。r3 listはbuild終了0／42.16秒、runは47 PASS／2350 filter SKIP／0.431秒。Coreの同構成Clippyは終了0／1分05秒、警告あり。fmtを変更8 Rust pathへ限定した。

r1は基点10474f06766f05b4583ba45086f69115e38b3371＋module宣言patch＋元fixture、r2は同基点＋修復patch＋同じ元fixture、r3は同基点＋最終tracked patch＋現fixtureで再現する。r2／r3後にそれぞれ観測した元pathの実test EXE hashとsource hashを保存した。r1本体hashは未記録、実行前後のbinary drift 0は主張しない。EXE／AWFBをコピー・退避していない。異なるSourceの1失敗、46件、47件、先行Core全件／二ownerを一つのmatrixへ加算しない。

Cargo／lock／featureは変わらず、前回のCore53推移的reverse closureを影響調査に再利用する。全53 packageとworkspace品質gate、affine入力のcall-frame横断・取消し／失敗の完全matrix、Sourceの明示binding・型admission、実Native／Web操作／描画parityは未達。Native公開saveを対応済みとしない。これは作業中の引数付き転送で再現した不具合であり、Generic Match等の受入済み機能を全体goalの未達で戻す判定ではない。重複する途中件数を現状一覧から履歴へ移し、goto行へ今回の限定結果だけを集約した。

所有境界の確認：追加scope refは実ストレージの借用だけでgrantを発行しない。Envは元の認証状態を保持したroot設置、Native終了継続は保留入力、presentation bankは一括preflight／commitを所有する。既存の大きいEnvへ別のregistryやI/Oを増やさず、Rootの物理移動をそのownerへ置いた。新しいテストは専用の描画転送moduleに置き、関係のないscope／resource機能の設計変更は行わない。
'@
$addition += [char]10+'原本 '+$archive+'：'+$entries+' entries／'+$size+' bytes／SHA256 '+$hash+'。ソース・patch・ログ・catalog・metadataのみで、EXE／AWFBは含めない。'+[char]10
$historyPath='docs/implementation/convergence-evidence-history.md';$old=[IO.File]::ReadAllBytes($historyPath);$extra=[Text.UTF8Encoding]::new($false).GetBytes($addition);$bytes=[byte[]]::new($old.Length+$extra.Length);[Array]::Copy($old,0,$bytes,0,$old.Length);[Array]::Copy($extra,0,$bytes,$old.Length,$extra.Length);[IO.File]::WriteAllBytes($historyPath,$bytes)
[IO.File]::WriteAllLines((Join-Path $e ($prefix+'.owned.txt')),($rust+@($archive,$p,$historyPath)),[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $e ($prefix+'.other.txt')),'',[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $e ($prefix+'.message.txt')),'wip(core): transfer presentation custody into the receiving Flow root'+[char]10,[Text.UTF8Encoding]::new($false))
[ordered]@{rustPaths=$rust.Count;entries=$entries;archive=$archive;bytes=$size;sha256=$hash}|ConvertTo-Json -Compress
