$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/effect-residual-reduction.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/effect-residual-reduction.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {
    $changed=$false
    foreach($node in $metadata.resolve.nodes){if(-not $closure.Contains($node.id)){foreach($dep in $node.deps){if($closure.Contains($dep.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}
}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/conditional-component.impact.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count){throw 'Reverse graph changed'}
$consumers=Get-Content -Raw "$root/conditional-component.consumer-summary.json"|ConvertFrom-Json
$cargoInputs=@(git diff --name-only $consumers.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml')
if($cargoInputs.Count){throw 'Cargo graph inputs changed'}
$archive=Get-Content -Raw "$root/conditional-component.archive.json"|ConvertFrom-Json
if((Get-FileHash -LiteralPath $archive.Path -Algorithm SHA256).Hash -cne $archive.SHA256){throw 'Reused frozen evidence changed'}
[ordered]@{Version=1;Source=$pub.Source;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='effect-residual-reduction.reverse-tree.txt';CargoInputsUnchanged=$true;ReverseConsumersRerun=$false;ReusedSource=$consumers.Source;ReusedTargets=$consumers.Targets;ReusedPassed=$consumers.Passed;ReusedFailed=$consumers.Failed;ReusedSkipped=$consumers.Skipped;ReusedArchive=$archive.Path;ReusedArchiveSHA256=$archive.SHA256;Reason='The change stays in the crate-private prepared-effect owner. Nullary residual reduction reads the exact retained relation without changing existing finite completion or independent original replay. Existing prepared producers, public cross-crate APIs, codecs, syntax, fixtures, Cargo manifests/features and generated artifacts did not change. Full owner tests rerun all old cases and eight new cases. Residual reduction is not yet used by a producer outside this owner. The full resolved reverse graph remains 22 packages. Reuse the prior complete consumer and workspace quality runs at their original Source 0691efa11175cadc7c0850278cd1a7ef4be45f62; owner all-target/all-feature Clippy, doctests, fmt and the structural gate were rerun for the current bytes.'}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/effect-residual-reduction.impact.json"
Write-Output "Impact verified: $($packages.Count) packages; consumer evidence reused from $($consumers.Source)"
