$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/effect-residual-reduction.publication.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/effect-residual-reduction.quality.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/effect-residual-reduction.owner-summary.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/effect-residual-reduction.structure.json"|ConvertFrom-Json
if((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $pub.Source -or @(git diff --name-only HEAD).Count -or $quality.Source -ne $pub.Source -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $owner.NewTests.Count -ne 8 -or $structure.ExitCode){throw 'Publication validation differs'}
git fetch origin main > "$root/effect-residual-reduction.source-fetch.log" 2>&1
if($LASTEXITCODE -or (git rev-parse origin/main) -ne $pub.Parent){throw 'Remote moved before source publication'}
git push origin main > "$root/effect-residual-reduction.source-push.log" 2>&1
if($LASTEXITCODE){throw 'Source push failed'}
$remote=(git ls-remote origin refs/heads/main).Split()[0]
if($LASTEXITCODE -or $remote -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source){throw 'Remote head differs'}
foreach($path in $pub.Paths){if((git rev-parse "origin/main:$($path.Path)") -ne $path.Blob -or (git hash-object -- $path.Path) -ne $path.Blob -or (Get-FileHash -LiteralPath $path.Path -Algorithm SHA256).Hash -cne $path.SHA256){throw 'Published source blob differs'}}
$pub.Pushed=$true
$pub|Add-Member -NotePropertyName Remote -NotePropertyValue $remote
$pub|Add-Member -NotePropertyName AllSourceBlobsVerified -NotePropertyValue $true
$pub|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/effect-residual-reduction.publication.json"
Write-Output "PUBLISHED $remote; six source blobs verified"
