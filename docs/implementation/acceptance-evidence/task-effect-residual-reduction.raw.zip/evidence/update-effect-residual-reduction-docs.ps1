$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/effect-residual-reduction.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/effect-residual-reduction.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/effect-residual-reduction.impact.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/effect-residual-reduction.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/effect-residual-reduction.structure.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/effect-residual-reduction.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean'}
if($owner.Passed -ne 1718 -or $owner.Failed -ne 6 -or $impact.ReverseConsumersRerun -or !$archive.AllEntriesVerified -or $structure.ExitCode){throw 'Evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'History prefix changed'}
$rows=@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。nullary残余条件の正確な簡約を検証・公開。本体内推論は継続** | 最新Source `SOURCE`。Native／AWBCの42・各step公開保存復元、実Source Γ・import lease・frame移送の既受入を維持する。元の量化R、guard付きimport、条件付きsupport、親の最小化からderived値を除く境界、borrowed inspectionとFutureの部分代入を保持。引数なし・choiceなしの点ごとに独立な条件は局所関数を同時消去し、未固定Future上のsatisfiable／principalと下限行を計算する。Kの外側は実Futureが含むlabelだけを局所解に許す。FutureだけのCoverageは全行条件として保持し、局所関数を含む他条件へは点ごとのモデルが一意と証明できた場合だけ下限を代入する。非一意なcross-label条件・全体共通choice・有効な局所∀・非nullary関数・importは元の量化式を保持し、未対応をfalseとしない。出力行はprincipal条件と元ownerに結び付いたままでcanonical行を発行しない。新8件はPASS、64入力の元solver／独立replayとの照合を含む。一般の量化消去・MGU／rank・Fn型ownerの局所∀、reify入力の元operand導出、checked primitive effect ownerと行seal、全portのΓ統合、frontend prepared value／effect・body一回準備・一括sealは継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[Γとowner](convergence-evidence-history.md#inference-references-and-application-leases)・[今回の簡約](convergence-evidence-history.md#nullary-effect-residual-reduction)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,718 PASS／6 FAIL。後続21 packageは以前の公開Sourceの実測を再利用** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,724件をSECONDS秒で実行。直前1,716 IDを維持し新8件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。新しい簡約はFuture入力未定での等式解、joint minimumの条件、symbolic Coverage、非一意なcross-label条件・choice・∀・全行implicationの保持、予算0・foreign issuer拒否、2 Future×全subsetsの64入力で元solverとの条件／行一致を確認した。全feature Cargo graphは22 packageで不変。crate-privateの残余簡約を追加し、既存prepared producer・有限基底solver・cross-crate API・codec・fixture・Cargo入力は不変のため、後続21 package／107 targetはSource `0691efa11175cadc7c0850278cd1a7ef4be45f62` の2,507 PASS／2 FAIL／1 SKIPを再利用する。Compiler既知2失敗のExpressionCycle slot 17／19を今回の再実行とは扱わない。[今回のowner・graph・再利用根拠](acceptance-evidence/task-effect-residual-reduction.raw.zip)・[consumer実測](acceptance-evidence/task-conditional-component.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **以前の公開Sourceの規定226件PASSを維持。全 check は未再実行** | 実行Source `0691efa11175cadc7c0850278cd1a7ef4be45f62`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS。binはcompile済み・runnable test 0件。今回のprivate準備効果ownerの変更ではこの結果を再利用し、新Sourceの再実行へ読み替えない。以前の入力・件数・失敗も履歴と原本に保持する。[CLI実行原本](acceptance-evidence/task-conditional-component.raw.zip)・[今回の再利用根拠](acceptance-evidence/task-effect-residual-reduction.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新owner Clippy・fmt・doctest・構造gateは終了0。workspace記録は以前のSourceを再利用** | Source `SOURCE` と同一のRust bytesでlocked owner全target／全feature Clippy、workspace fmt、Sema doctest 2件を実行。checkはClippyに包含。構造gateはPACKAGES package・FILES files・RUSTFILES Rust files・RUSTLOC Rust LOC・REVIEWS review・blocking 0。6 Rust path・GROWTH物理LOC増を対象に、残余owner内の制御付き反復lowering、全行scalar条件、同時Boolean消去と一意性証明、guardを保持する検査APIの責務を確認した。元graph／量化Rをauthorityとして保持し、既存の有限基底solverと独立replayを変更しない。Cargo graphは22 package、fan-in／outは12／19で不変。private cutとしてworkspace全target／全feature check／ClippyはSource `0691efa11175cadc7c0850278cd1a7ef4be45f62` の終了0を再利用し、今回の実行へ付け替えない。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告は原本へ保持。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を維持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・graph](acceptance-evidence/task-effect-residual-reduction.raw.zip)・[workspace実測](acceptance-evidence/task-conditional-component.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$status=[IO.File]::ReadAllText($statusPath)
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'}
    $replacement=$rows[$key].Replace('SOURCE',$pub.Source).Replace('SECONDS',[string]$owner.ExecutionSeconds).Replace('PACKAGES',[string]$structure.Packages).Replace('RUSTFILES',[string]$structure.RustFiles).Replace('FILES',[string]$structure.Files).Replace('RUSTLOC',[string]$structure.RustPhysicalLOC).Replace('REVIEWS',[string]$structure.ReviewTriggers).Replace('GROWTH',[string]$owner.PhysicalGrowth)
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$status=[regex]::Replace($status,'この更新の基点の `main` と `origin/main` は `[a-f0-9]{40}`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Nullary effect residual reduction

2026-11-13。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの6 Rust pathを通常commit／非force pushし、検証入力の全bytesと公開blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- 残余ownerへnullary・choiceなしの正確な部分簡約を実装した。元の量化Rを反復loweringし、点ごとに独立な条件から局所関数を同時消去して、未固定Future上のsatisfiable／principalと各下限行を保持する。Kの外のmembershipは実Future入力の和集合をsupportとし、架空のlabelやGeneric参照を作らない。全行のAnd／Or／Not／domain⇒consequenceはscalar DAGで保持し、pointwiseな論理へ誤変換しない。
- FutureだけのCoverageは元の能力包含として保持する。局所関数を含む他のscalar条件へは、点ごとの関係の全モデルが下限と等しいことをcountermodel消去で証明した場合だけ代入する。単に最小解が存在するだけではこの代入を許さない。非一意なcross-label条件・choice・有効な局所∀・非nullary関数・importは元の正確な量化表現を保持する。未対応をUnsatisfiable／NonPrincipalへ変換しない。簡約行はprincipal条件・実Future参照・元issuerと結び付き、canonical EffectRowやSource Γを発行しない。
- 新8件がPASS。x=F、x∪y=Fの条件付きjoint minimum、x=FとCoverage(x,G)の一意代入、部分固定と親能力grant、非一意cross-label・global choice・∀・全行implicationの保持、制御予算0とforeign issuer拒否を確認した。4つの関係×2 Futureの各4部分集合の64入力で、symbolic条件・下限行・全入力固定の簡約を元の有限基底solver／独立replayと照合し、K外の実入力labelも含めた。
- 最終locked・全feature Sema lib／testsは1,724件／1,718 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,716 ID保持・新8件PASS・選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。先行dev checkのprivate field参照とEffectId constructorのcompile拒否、先行対象runの不正な単一成分labelによる5失敗を原本に保持し、実装の参照accessorとテスト入力を既存契約へ訂正した。
- 今回のowner全target／全feature Clippy、workspace fmt、Sema doctest 2件と構造gateは終了0。full metadata／全target reverse treeは22 package、fan-in 12／fan-out 19で不変。6 Rust pathで$($owner.PhysicalGrowth)物理LOC増。制御付き反復lowering、scalar DAGとpointwise消去、一意性証明、元ownerに結び付いたborrowed検査を残余ownerが所有する。既存producer・有限基底solver・公開cross-crate API・codec・syntax・fixture・Cargo入力と生成物は不変で、このAPIをowner外のproducerへまだ接続していない。後続21 package／107 targetの2,507 PASS／2 FAIL／1 SKIPとworkspace check／ClippyはSource ``0691efa11175cadc7c0850278cd1a7ef4be45f62`` の実測を元SHAのまま再利用する。
- Supersedes: 現状一覧で論理簡約全体を未実装とした記述と、nullaryの消去・Future Coverage保持・uniqueな局所解の代入を残作業とした列挙を、今回の具体的な実装・検証を根拠に置換した。一般量化消去やfrontend接続の完了とはしない。以前の全SHA・実測・失敗・原本とGeneric Match・caller-bound recursion・共有prefixの受入を保持し、現在の項目別一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-effect-residual-reduction.raw.zip](acceptance-evidence/task-effect-residual-reduction.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`r`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended actual reduction evidence.'
