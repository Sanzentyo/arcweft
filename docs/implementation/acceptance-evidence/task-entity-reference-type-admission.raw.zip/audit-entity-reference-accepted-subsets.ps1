param([Parameter(Mandatory)][string]$Run,[Parameter(Mandatory)][string]$Source)
$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$receipt=Get-Content -LiteralPath "$taskTemp/$Run.runtime.json" -Raw|ConvertFrom-Json
$audit=Get-Content -LiteralPath "$taskTemp/$Run.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$lines=[IO.File]::ReadAllLines($receipt.log)
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0){throw 'Missing terminal summary'}
$cases=@{}
foreach($line in $lines[($summary+1)..($lines.Length-1)]){
    if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
        $key=$Matches[2]+"`t"+$Matches[3]
        if($cases.ContainsKey($key)){throw 'Duplicate final case'}
        $cases[$key]=[ordered]@{status=$Matches[1];binary=$Matches[2];test=$Matches[3]}
    }
}
if($cases.Count -ne $audit.executed){throw 'Final case count differs'}
$sets=@{}
foreach($boundary in @('genericMatch','view40')){
    $previous=Get-Content -LiteralPath "$taskTemp/action-qualified-reverse-$boundary.json" -Raw|ConvertFrom-Json
    $sets[$boundary]=@($previous.cases)
}
$focused=Get-Content -LiteralPath "$taskTemp/action-qualified-path.focused-cases.json" -Raw|ConvertFrom-Json
if($focused.cases){$sets['qualifiedAction11']=@($focused.cases)}else{$sets['qualifiedAction11']=@($focused)}
$wanted=@('entity_reference_ownership_rejects_other_families','action_channel_ownership_rejects_other_declarations','reference_admission_keeps_family_and_original_declaration','reference_payload_is_a_type_edge_instead_of_an_owned_value','character_look_references_keep_their_character_owner','entity_reference_type_wire_preserves_and_validates_all_metadata','presentation_cancellation_fixtures_match_the_original_program')
$newCases=@(foreach($name in $wanted){$found=@($cases.Values|Where-Object {$_.test.EndsWith('::'+$name)});if($found.Count -ne 1){throw "New regression selection differs: $name"};$found[0]})
$sets['referenceRegressions7']=$newCases
foreach($boundary in $sets.Keys|Sort-Object){
    $observed=@(foreach($case in $sets[$boundary]){ $key=$case.binary+"`t"+$case.test;if(-not $cases.ContainsKey($key)){throw "Required case absent: $key"};$cases[$key] })
    $failed=@($observed|Where-Object {$_.status -notin @('PASS','SLOW')})
    [ordered]@{version=1;productionSource=$Source;run=$Run;scope=$boundary;passed=$observed.Count-$failed.Count;failed=$failed.Count;caseDrift=0;sourceInputs=$receipt.sourceInputs;sourceDrift=$receipt.sourceDrift;cases=$observed}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$taskTemp/entity-reference-types-$boundary.json" -Encoding utf8
    [pscustomobject]@{boundary=$boundary;cases=$observed.Count;passed=$observed.Count-$failed.Count;failed=$failed.Count;caseDrift=0}|ConvertTo-Json -Compress
}
