param([Parameter(Mandatory)][string]$FinalSource)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$record=Get-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-entity-reference-type-admission.json' -Raw|ConvertFrom-Json -Depth 100
if($record.source -ne $FinalSource){throw 'Status source differs'}
$path='docs/implementation/current-status.md'
$text=[IO.File]::ReadAllText([IO.Path]::GetFullPath($path))
$newline=if($text.Contains("`r`n")){"`r`n"}else{"`n"}
$lines=[Collections.Generic.List[string]]::new()
$lines.AddRange([string[]]($text -split '\r?\n'))
function Replace-One([string]$Prefix,[string]$Replacement){$indices=@(for($i=0;$i -lt $lines.Count;$i++){if($lines[$i].StartsWith($Prefix,[StringComparison]::Ordinal)){$i}});if($indices.Count -ne 1){throw "Status row count differs: $Prefix"};$lines[$indices[0]]=$Replacement}
$native=$record.acceptance.nativeRepair
$normal=$record.acceptance.normalInitial
$cli=$record.acceptance.cli
Replace-One '確認日:' "確認日: 2026-11-03。最新公開Sourceは$FinalSource。Entity参照の型metadata・元Source証明を共有化し、影響71 packageのcompile／実行とNative fixture修復を区別して照合した。初回全件runの成功と、同じ失敗IDを含むNative owner再検証を再利用範囲付きで記録する。既存12 tracked／6 actual untracked WIPを保持している。"
$newRow="| Entity参照のfamily／元宣言／payload型metadata・元Source証明 | **当該inert型・値admissionは検証・公開済み** | Source $FinalSource、共有契約f54050124603e4ace5fa59c87a17f79f9d07f3e5、Source証明2dbd62719e44c02d794aef4ee484f7715c3150dc。Coreの一つの型ownerが36 project family・元宣言・CharacterLook owner・payload型edgeを保持し、Sema／RuntimePlan／Native／AWBC／schema／codecへ接続した。異family・別Action宣言・同じ型IDで偽造したmetadataを拒否する。payload型edgeから値所有権や実行権限は作らない。新7件と旧受入subsetはPASS。古いAWBC fixtureとStyle型をCharacter factoryへ流用していたNative fixtureを最終契約へ修復し、後者は全$($native.executed)件PASS。全件run・再検証・CLIの範囲は下表へ集約する。emit／receive・実行channelの元program admission・停止保存は別境界。[実測・失敗・訂正理由・raw](acceptance-evidence/task-entity-reference-type-admission.json)。 |"
if(@($lines|Where-Object {$_.StartsWith('| Entity参照のfamily／')}).Count){throw 'New status row already exists'}
$tableIndex=$lines.IndexOf('|---|---|---|')
if($tableIndex -lt 0){throw 'Status table absent'}
$lines.Insert($tableIndex+1,$newRow)
Replace-One '| Generic Match `.1.2` C3/C5 |' '| Generic Match `.1.2` C3/C5 | **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。Source 2dbd62719e44c02d794aef4ee484f7715c3150dc・4083入力でも同じ151 IDが151／151 PASS、除外0。完全transcript、uninhabited-domain、Never／let-else、exhaustive-only atomic publicationの既受入を維持する。[受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)、[公開記録](acceptance-evidence/accepted-generic-phase-note-publication.json)、[最新151件照合](acceptance-evidence/task-entity-reference-type-admission.json)。 |'
Replace-One '| 共有契約／推移的逆依存matrix |' "| 共有契約／推移的逆依存matrix | **影響71 packageを照合。通常側の初回は9187件中9164 PASS／23 FAIL、Native修復後は元の23失敗を含む全$($native.executed)件PASS** | 初回Source 2dbd62719e44c02d794aef4ee484f7715c3150dc、all-target／all-feature／locked、4083入力。通常70 package中66に実行対象があり、25 ignored。残る4 packageはcompileのみ。初回の23失敗は共通fixtureのStyle／Character型流用で、修復差分は1 pathのみ。初回の成功9164件は関連入力が不変な範囲で再利用し、単一の9187件再実行とは扱わない。既受入Generic Match151／View40／修飾Action11と新7件は初回で全PASS。Source／case／test EXE差分0。[実graph・失敗原本・再実行と再利用範囲](acceptance-evidence/task-entity-reference-type-admission.json)。 |"
Replace-One '| CLI全target照合 |' "| CLI全target照合 | **$($cli.executed)件を全実行し$($cli.passed) PASS／$($cli.failed) FAIL** | all-target／all-feature／locked、4083入力、$($cli.skipped) ignored。Native修復と同じ実入力でSource／case／test EXE差分0。旧693件・660 PASS／33 FAILとの実際の失敗ID差分と現在stderrは[原本](acceptance-evidence/task-entity-reference-type-admission.json)へ保持する。ID一致だけから原因の同一性を推定しない。CLI統合の未完了を、受入済みの別境界へ転記しない。 |"
Replace-One '| workspace check／Clippy・fmt・構造gate |' '| workspace check／Clippy・fmt・構造gate | **workspace全98のcheck／Clippy・構造gateは終了0。Native fixture修復もowner Clippy終了0。警告は残存** | Entity参照の共有契約・Source証明の4083入力でall-target／all-feature／lockedの全98 gateが終了0。以後の差分はNative test fixtureの1 pathで、全owner testとClippyを追加実行した。9 crateのdoctestは88／88 PASS（残る5 crateは0件）、Web wasm32-unknown-unknown checkも終了0。全workspace gateを最終SHAで再実行したとはしない。[全実測・exact入力・凝集性レビュー](acceptance-evidence/task-entity-reference-type-admission.json)。 |'
[IO.File]::WriteAllText([IO.Path]::GetFullPath($path),($lines -join $newline),[Text.UTF8Encoding]::new($false))
$history='docs/implementation/convergence-evidence-history.md'
$prefix=Get-Content -LiteralPath "$e/entity-reference-types.history-prefix-before.json" -Raw|ConvertFrom-Json
$before=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history))
if($before.Length -ne $prefix.bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant() -ne $prefix.sha256){throw 'Historical byte prefix differs before append'}
$entry=@"


## Entity参照の型metadata・元Source証明 — 2026-11-03

公開Source: f54050124603e4ace5fa59c87a17f79f9d07f3e5 → 2dbd62719e44c02d794aef4ee484f7715c3150dc → $FinalSource。main、既存12 tracked／6 actual untracked WIP保持。各通常pushのparent／tree／patch／blob照合は原本へ記録した。実入力は4083 pathであり、公開SHAだけから既存CLI WIPの内容を推定しない。

最初のSema回帰2件は2 FAIL。無条件EntityRef投影が異familyと別Action宣言を受理することを再現した。Coreの型ownerへfamily・元宣言・Look owner・payload型edgeを統合し、全producer／consumerをversion 1の最終shapeへ移行した。元Sema証明とのmetadata一致もvalue／pattern／constructorで検査する。inert参照metadataはchannelの実行権限ではない。

owner1／2／3のcatalogは各compile101・runtime未実行。owner4は4623実行／4620 PASS／3 FAILで、旧static AWBC fixtureのdecode失敗だった。現行の元program builderによる明示generatorを1件実行して2 fixtureを再生成し、通常の決定的fixture比較も追加した。generatorのignoredは自動生成時の書込みを避ける指定であり、受入caseの除外ではない。owner5は3908実行／3907 PASS／1 FAIL／generator 1 ignoredで、正例fixtureのCharacterにAsset型を流用していたため修復し、owner6 RuntimePlan library134／134 PASS。Dialogue初回69件中1 FAILは共通admissionで既に拒否された値に古い後段RoleTypeを期待したためで、重複guardを削除し厳密なProgramType拒否へ移行後69／69 PASS。Driver表示filter6／6 PASS。quality1／2は古いunit variant残存でcheck101、後続Clippy／structure未実行。修復後quality3は全98 check／Clippy／structure終了0（警告残存）。

Source 2dbd62719e44c02d794aef4ee484f7715c3150dcの通常逆依存run: $($normal.summary)。71 packageの解決済みclosureからCLIを除く70を選択し、66で実行、4はcompileのみ。新7件・Generic Match151・View40・修飾Action11はすべてPASS。23 FAILはNative共通fixtureがStyle型IDをCharacter factory receiverへ流用していた。1 pathのfixture修復後、Native全owner再検証: $($native.summary)。元23失敗IDがすべて再選択されPASSしたことをcatalogと終端で照合した。初回成功9164件は関連入力の不変を確認して再利用し、修復後の単一9187件runとは表現しない。

Native初回の63 PASSは古いwrapper入力templateにより4031 pathだけを監視していたため、その結果を隠さず保持し、完全な4083 pathを渡して同じ63件を再実行した。後者が今回のNative受入証拠であり、二回の件数を合算しない。

CLI: $($cli.summary)。旧Source6daa0f58c1088c844af85fb7c5c5103d5d8e92b1の693件／660 PASS／33 FAILとのID差分と現在診断を原本へ保持する。ID一致だけで原因同一とはしない。doctest9 crate、Web wasm check、Native owner Clippyも終了0。ユーザーの追加指定による全体cargo cleanは201827 files／227.5 GiBを削除し終了0、4083入力hash／Git状態差分0、ログはtarget外に保持した。

訂正理由: 現状一覧の旧横断件数を今回の実測へ置換し、初回失敗と後続再検証を分離した。旧結果・full SHA・失敗原本は削除せず履歴へ保持する。Generic Matchの既受入を維持し、全体goalやCLIの未達から未完了へ戻さない。Action emit／receive、元program実行channel admission、停止保存はこのinert型cutでは未達の別境界である。

[実測・入力・生成物・全失敗・凝集性レビュー・raw](acceptance-evidence/task-entity-reference-type-admission.json)。現状はcurrent-status.md一か所へ集約する。
"@
[IO.File]::AppendAllText([IO.Path]::GetFullPath($history),$entry,[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));$kept=[byte[]]::new($before.Length);[Array]::Copy($after,$kept,$before.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($kept)).ToLowerInvariant() -ne $prefix.sha256){throw 'Historical prefix changed'}
[ordered]@{version=1;source=$FinalSource;historyPrefixBytes=$before.Length;historyPrefixSha256=$prefix.sha256;historyPrefixDrift=0;currentStatusAuthority=$path}|ConvertTo-Json|Set-Content -LiteralPath "$e/entity-reference-status-update.json" -Encoding utf8
