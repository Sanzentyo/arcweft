$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$epoch='entity-reference-types-native2-20261103'
$native=Get-Content -LiteralPath "$taskTemp/$epoch.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if(-not $native.isPassingRun -or $native.sourceDrift){throw 'Native repair is not validated'}
& "$taskTemp/run-action-qualified-reverse.ps1" -Slice cli -Stem 'entity-reference-types-reverse-cli1-20261103' -Epoch $epoch
if($LASTEXITCODE -notin @(0,100)){throw 'CLI run has no valid terminal'}
& "$taskTemp/audit-entity-reference-cli-delta.ps1" -Run 'entity-reference-types-reverse-cli1-20261103' -Source '2dbd62719e44c02d794aef4ee484f7715c3150dc'
if($LASTEXITCODE){throw 'CLI delta audit failed'}
& "$taskTemp/run-entity-reference-docs-wasm.ps1" -Stem 'entity-reference-types-docs-wasm1-20261103' -Epoch $epoch
if($LASTEXITCODE){throw 'Docs or wasm failed'}
$freeze=Get-Content -LiteralPath "$taskTemp/$epoch.source-freeze.json" -Raw|ConvertFrom-Json
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}}
Assert-Inputs
$started=[DateTime]::UtcNow.ToString('o')
$arguments=@('clippy','-p','arcweft-player-native','--all-targets','--all-features','--locked')
& cargo @arguments *> "$taskTemp/entity-reference-types-native-quality1-20261103.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/entity-reference-types-native-quality1-20261103.json" -Encoding utf8
if($code){throw 'Native Clippy failed'}
Write-Output 'Final gate sequence closed; inspect all actual receipts before acceptance.'
