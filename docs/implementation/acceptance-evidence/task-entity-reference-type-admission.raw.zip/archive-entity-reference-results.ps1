$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$zipPath='docs/implementation/acceptance-evidence/task-entity-reference-type-admission.raw.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Preserve the existing archive'}
$files=@(rg --files $e -g '*.json' -g '*.log' -g '*.patch' -g '*.ps1' -g '*.txt' | Where-Object {
    (([IO.Path]::GetDirectoryName($_)) -replace '\\','/') -eq $e -and
    [IO.Path]::GetFileName($_) -match '^(entity-reference-|checkpoint-entity-reference-|action-channel-admission-repro1-|user-requested-cargo-clean-20261103|run-entity-reference-|audit-entity-reference-|archive-entity-reference-|record-entity-reference-|update-entity-reference-)'
})
$extra=@('presentation-frame-driver.metadata.json','action-qualified-path.reverse-graph.json','action-qualified-path.focused-cases.json','action-qualified-reverse-genericMatch.json','action-qualified-reverse-view40.json','action-qualified-reverse-cli1-20261103.runtime.terminal-audit.json','run-action-qualified-reverse.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','run-action-payload-quality.ps1','assert-no-arcweft-build.ps1','read-live-log-tail.ps1')
foreach($name in $extra){$files+=Join-Path $e $name}
$files+=@(rg --files "$e/entity-reference-types-quality3-20261103.structure-report")
$files=@($files|ForEach-Object {[IO.Path]::GetFullPath($_)}|Sort-Object -Unique)
$manifest=@()
$names=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($path in $files){
        $file=Get-Item -LiteralPath $path
        $entry=[IO.Path]::GetRelativePath($e,$file.FullName) -replace '\\','/'
        if(-not $names.Add($entry)){throw "Duplicate archive entry: $entry"}
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)
        $manifest += [ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
    }
} finally {$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {
    if($zip.Entries.Count -ne $manifest.Count){throw 'Archive entry count differs'}
    foreach($row in $manifest){
        $stream=$zip.GetEntry($row.entry).Open()
        try {$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}
        finally {$stream.Dispose()}
        if($hash -ne $row.sha256){throw "Archive entry drift: $($row.entry)"}
    }
} finally {$zip.Dispose()}
[ordered]@{version=1;path=$zipPath;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entryDrift=0;entries=$manifest}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$e/entity-reference-raw-manifest.json" -Encoding utf8
[ordered]@{entries=$manifest.Count;bytes=(Get-Item -LiteralPath $zipPath).Length;entryDrift=0}|ConvertTo-Json
