param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
if(Test-Path -LiteralPath "$taskTemp/$Stem.json"){throw 'Existing generation receipt'}
$outputs=@('crates/arcweft-core/src/awbc/product_step/tests/presentation/fanout-cancellation.awbc','crates/arcweft-core/src/awbc/product_step/tests/presentation/fanout-need-cancellation.awbc')
$template=Get-Content -LiteralPath "$taskTemp/entity-reference-types-owner4-20261103.source-freeze.json" -Raw|ConvertFrom-Json
$inputs=@(foreach($path in $template.paths.path){if($path.Replace('\','/').Replace('D:/git/arcweft/','') -in $outputs){continue};[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
if($inputs.Count -ne $template.paths.Count - 2){throw 'Generation output separation differs'}
function Assert-Inputs {foreach($row in $inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Generator source changed: $($row.path)"}}}
$before=@(foreach($path in $outputs){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $path).Length}})
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();purpose='explicit artifact generation, not an acceptance run';inputs=$inputs;outputs=$before}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$Stem.inputs.json" -Encoding utf8
$selection=@('-p','arcweft-runtime-plan','--lib','--all-features','--locked','-E','test(=awbc_lower::tests::program_fanout::regenerate_presentation_cancellation_fixtures)','--run-ignored','only')
$started=[DateTime]::UtcNow.ToString('o')
& cargo nextest list @selection --message-format json *> "$taskTemp/$Stem.catalog.log"
$catalogCode=$LASTEXITCODE
Assert-Inputs
if($catalogCode){throw 'Generator catalog failed'}
$line=[IO.File]::ReadLines("$taskTemp/$Stem.catalog.log")|Where-Object {$_.StartsWith('{"rust-build-meta"')}|Select-Object -Last 1
$catalog=$line|ConvertFrom-Json -Depth 100
$matched=@(foreach($suite in $catalog.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){[ordered]@{binary=$suite.Value.'binary-id';test=$case.Name;ignored=$case.Value.ignored;path=$suite.Value.'binary-path';sha256=(Get-FileHash -LiteralPath $suite.Value.'binary-path').Hash.ToLowerInvariant()}}}})
if($matched.Count -ne 1 -or -not $matched[0].ignored){throw 'Generator selection differs'}
& cargo nextest run @selection --no-tests fail --no-fail-fast --status-level all --final-status-level all *> "$taskTemp/$Stem.log"
$code=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $matched[0].path).Hash.ToLowerInvariant() -ne $matched[0].sha256){throw 'Generator executable changed'}
$after=@(foreach($path in $outputs){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $path).Length}})
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();purpose='explicit artifact generation, not an acceptance run';catalogExitCode=$catalogCode;exitCode=$code;selection=$selection;matched=$matched;sourceInputs=$inputs.Count;sourceDrift=0;executableDrift=0;before=$before;after=$after;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$taskTemp/$Stem.json" -Encoding utf8
Get-Content -LiteralPath "$taskTemp/$Stem.json" -Raw
exit $code
