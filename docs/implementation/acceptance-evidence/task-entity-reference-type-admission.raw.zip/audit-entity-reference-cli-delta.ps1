param([Parameter(Mandatory)][string]$Run,[Parameter(Mandatory)][string]$Source)
$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prior=Get-Content -LiteralPath "$taskTemp/action-qualified-reverse-cli1-20261103.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$current=Get-Content -LiteralPath "$taskTemp/$Run.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($prior.executed -ne 693 -or $prior.failed -ne 33){throw 'Prior complete CLI baseline differs'}
$oldKeys=@($prior.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$newKeys=@($current.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$result=[ordered]@{version=1;productionSource=$Source;current=$current;comparisonSource='6daa0f58c1088c844af85fb7c5c5103d5d8e92b1';prior=$prior;retainedFailureIds=@($current.failureSet|Where-Object {($_.binary+"`t"+$_.test) -in $oldKeys});newlyFailingIds=@($current.failureSet|Where-Object {($_.binary+"`t"+$_.test) -notin $oldKeys});resolvedFailureIds=@($prior.failureSet|Where-Object {($_.binary+"`t"+$_.test) -notin $newKeys});causeCaution='Equal case IDs do not prove equal causes. Preserve complete diagnostics and compare concrete failures.'}
$result|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$taskTemp/entity-reference-types-cli-delta.json" -Encoding utf8
[ordered]@{executed=$current.executed;passed=$current.passed;failed=$current.failed;retained=$result.retainedFailureIds.Count;added=$result.newlyFailingIds.Count;resolved=$result.resolvedFailureIds.Count;sourceDrift=$current.sourceDrift;caseDrift=$current.catalogCaseDrift}|ConvertTo-Json -Compress
