param([Parameter(Mandatory)][string]$FinalSource)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
if((git rev-parse HEAD).Trim() -ne $FinalSource){throw 'Final source differs'}
$normal=Read-Record 'entity-reference-types-reverse-normal1-20261103.runtime.terminal-audit'
$native=Read-Record 'entity-reference-types-native2-20261103.runtime.terminal-audit'
$cli=Read-Record 'entity-reference-types-reverse-cli1-20261103.runtime.terminal-audit'
$nativeFreeze=Read-Record 'entity-reference-types-native2-20261103.source-freeze'
$normalFreeze=Read-Record 'entity-reference-types-reverse-normal1-20261103.source-freeze'
$cliFreeze=Read-Record 'entity-reference-types-reverse-cli1-20261103.source-freeze'
if($normal.executed -ne 9187 -or $normal.failed -ne 23 -or $normal.sourceDrift){throw 'Initial normal result differs'}
if(-not $native.isPassingRun -or $native.sourceDrift){throw 'Native repair has not passed'}
$originalRows=@{};foreach($row in $normalFreeze.paths){$originalRows[$row.path]=$row.sha256}
$delta=@($nativeFreeze.paths|Where-Object {$originalRows[$_.path] -ne $_.sha256})
if($delta.Count -ne 1 -or ($delta[0].path -replace '\\','/') -notlike '*/arcweft-player-native/tests/support/character_dialogue_generation.rs'){throw 'Repair delta exceeds the Native fixture'}
$a=@($nativeFreeze.paths|ForEach-Object {$_.path+"`t"+$_.sha256})
$b=@($cliFreeze.paths|ForEach-Object {$_.path+"`t"+$_.sha256})
if(@(Compare-Object $a $b).Count){throw 'Native and CLI frozen inputs differ'}
foreach($row in $nativeFreeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Post-validation source drift: $($row.path)"}}
$catalog=Read-Record 'entity-reference-types-native2-20261103.catalog.inventory'
foreach($failure in $normal.failureSet){
    $matched=@($catalog.rows|Where-Object {$_.binary -eq $failure.binary -and $_.test -eq $failure.test -and $_.status -eq 'matches'})
    if($matched.Count -ne 1){throw "Failed case absent from repair run: $($failure.test)"}
}
$required=[ordered]@{}
foreach($name in @('genericMatch','view40','qualifiedAction11','referenceRegressions7')){
    $r=Read-Record "entity-reference-types-$name"
    if($r.failed -or $r.caseDrift -or $r.sourceDrift){throw "Required subset did not pass: $name"}
    $required[$name]=$r
}
$quality=@(foreach($suffix in @('check','clippy','structure')){$name="entity-reference-types-quality3-20261103-$suffix";$r=Read-Record $name;if($r.exitCode -or $r.sourceDrift){throw "Quality failed: $name"};[ordered]@{run=$name;receipt=$r}})
$supplemental=[ordered]@{}
foreach($name in @('entity-reference-types-docs-wasm1-20261103-docs','entity-reference-types-docs-wasm1-20261103-wasm','entity-reference-types-native-quality1-20261103')){$r=Read-Record $name;if($r.exitCode -or $r.sourceDrift){throw "Supplemental gate failed: $name"};$supplemental[$name]=$r}
$untracked=Read-Record 'task-documentation-final-untracked-before'
foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Original untracked file drift: $($row.path)"}}
$cohesion=@(Read-Record 'entity-reference-types.cohesion')
$fileMetrics=Import-Csv -LiteralPath "$e/entity-reference-types-quality3-20261103.structure-report/file_metrics.csv"
$packageMetrics=Import-Csv -LiteralPath "$e/entity-reference-types-quality3-20261103.structure-report/package_metrics.csv"
$dispositions=@{
    'crates/arcweft-runtime-plan/src/semantic_facts.rs'='The accepted RuntimeNormalizedType algebra and source fact admission own the original Sema entity proof. This change compares retained family/declaration/payload metadata at the existing value and pattern boundaries. It adds no registry, secondary source traversal or unrelated mutable state; global and closed consumers borrow their existing source authority.'
    'crates/arcweft-lang-sema/src/types.rs'='EntityKind and EntityType own the language reference algebra. EntityKind now exhaustively projects the public family, and EntityType projects exact accepted Action declaration and payload metadata. There is no executable capability, runtime queue, host dependency or parallel family table in this owner.'
    'crates/arcweft-core/src/pattern.rs'='RuntimeCheckedType is the finite checked-type algebra used by pattern and value admission. Its EntityReference case delegates family/declaration/Look admission to the shared Core selector instead of duplicating a predicate. Format I/O and source analysis remain outside this owner; its embedded behavioral tests exercise the same type boundary.'
}
foreach($path in @('crates/arcweft-runtime-plan/src/semantic_facts.rs','crates/arcweft-lang-sema/src/types.rs','crates/arcweft-core/src/pattern.rs')){
    $metric=@($fileMetrics|Where-Object path -eq $path)
    if($metric.Count -ne 1 -or (Get-Item -LiteralPath $path).Length -ne [long]$metric[0].bytes){throw 'Structural measurement differs'}
    $cohesion += [ordered]@{source=$FinalSource;workingTree='12 tracked / 6 actual untracked original WIP; published owner bytes';path=$path;crate=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLoc=[int]$metric[0].physical_lines;embeddedTestLoc=[int]$metric[0].embedded_test_lines;classification=$metric[0].classification;dependencyMetrics=@($packageMetrics|Where-Object package -eq $metric[0].owner)[0];disposition=$dispositions[$path];apiReview='No public API widening solely for file splitting; no new dependency direction, I/O or unrelated state. Tests stay with their production boundary.'}
}
$recordPath='docs/implementation/acceptance-evidence/task-entity-reference-type-admission.json'
if(Test-Path -LiteralPath $recordPath){throw 'Preserve the existing acceptance record'}
& "$e/archive-entity-reference-results.ps1"
$record=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$FinalSource
    publications=@((Read-Record 'checkpoint-entity-reference-types.verified'),(Read-Record 'checkpoint-entity-reference-owner.verified'),(Read-Record 'checkpoint-entity-reference-native.verified'))
    authority='Core RuntimeEntityReferenceType owns inert reference family, exact original declaration, CharacterLook owner and payload type edge. Sema projects accepted declaration metadata; RuntimePlan compares it with the accepted source proof; Core and AWBC share logical value admission. Payload metadata is not an owned runtime value or an executable channel capability. All contract version markers remain 1.'
    acceptance=[ordered]@{normalInitial=$normal;nativeRepair=$native;requiredAcceptedSubsets=$required;cli=$cli;cliDelta=(Read-Record 'entity-reference-types-cli-delta');cliDiagnostics=(Read-Record 'entity-reference-types-cli-diagnostic-excerpts');quality=$quality;supplemental=$supplemental;doctestCases=(Read-Record 'entity-reference-types-doctest-cases');resolvedGraph=(Read-Record 'entity-reference-types.reverse-graph-reuse')}
    provenance=[ordered]@{sourceInputs=$nativeFreeze.paths.Count;heldTracked=12;originalUntracked=6;originalUntrackedDrift=0;normalToRepairDelta=$delta;normalCliInputDrift='The Native repair and CLI inputs match exactly. The initial full normal run precedes the one-file fixture repair.';reusedNormalPassingCases=$normal.passed;repairedOriginalFailures=$normal.failureSet;meaning='Frozen inputs include preserved original WIP. Production SHAs alone do not describe all CLI fixtures. Initial 9164 passing cases are reused for unchanged relevant inputs; the complete Native owner, including all original 23 failures, is rerun. This is not presented as a new single 9187-case passing run.'}
    artifactGeneration=(Read-Record 'entity-reference-fixtures-generation1-20261103')
    ownershipReview=$cohesion
    corrections=@('The former universal EntityRef projection admitted Character/Asset and distinct Action declarations interchangeably; typed family and declaration metadata now survive the complete pipeline.','Old static AWBC cancellation fixtures were regenerated through the current original program builder, without a legacy reader. Initial failures remain in the archive.','Source value/pattern metadata is checked against the accepted original Sema proof, including equal type-ID but wrong-family rejection.','Dialogue wrong-family values now fail at shared program admission; the redundant later Style guard was deleted while exact rejection assertions remain.','Native CharacterDialogue test fixtures had reused the Style type for the Character factory receiver. They now use distinct type rows; execution admission is not weakened.','Generic Match remains accepted/published. Separate CLI failures and unimplemented Action emit/receive do not reopen it.')
    scopeExclusion='This accepts inert typed reference admission and original-source metadata proof, with recorded consumer coverage. Actual Action emit/receive, executable channel admission, suspension and save remain separate unfinished boundaries in current-status.md. The overall goal remains active.'
    raw=(Read-Record 'entity-reference-raw-manifest')
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
[ordered]@{source=$FinalSource;initialNormal=$normal.summary;nativeRepair=$native.summary;cli=$cli.summary;rawEntries=$record.raw.entries.Count}|ConvertTo-Json
