$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$epoch='entity-reference-types-native2-20261103'
& "$taskTemp/run-entity-reference-docs-wasm.ps1" -Stem 'entity-reference-types-docs-wasm1-20261103' -Epoch $epoch
if($LASTEXITCODE){throw 'Docs or wasm failed'}
$freeze=Get-Content -LiteralPath "$taskTemp/$epoch.source-freeze.json" -Raw|ConvertFrom-Json
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}}
Assert-Inputs
$started=[DateTime]::UtcNow.ToString('o')
$arguments=@('clippy','-p','arcweft-player-native','--all-targets','--all-features','--locked')
& cargo @arguments *> "$taskTemp/entity-reference-types-native-quality1-20261103.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/entity-reference-types-native-quality1-20261103.json" -Encoding utf8
if($code){throw 'Native Clippy failed'}
Write-Output 'Supplemental gates closed.'
