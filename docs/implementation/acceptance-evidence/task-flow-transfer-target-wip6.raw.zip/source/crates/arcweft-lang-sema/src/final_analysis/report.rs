//! Immutable accepted semantic report and publication transaction.

mod project_functions;
mod variants;

use super::declaration_defaults::{
    checked_declaration_default_captures, checked_view_parameter_defaults,
};

use std::{
    collections::{BTreeMap, BTreeSet},
    sync::Arc,
};

use arcweft_lang_hir::{
    identity::HirValueTypeOwner,
    item::{HirItemKind, HirVisibility},
    project::{
        HirProjectEvaluationTopology, HirRuntimeExecutableOwner,
        HirRuntimeExecutableSemanticOwners, HirRuntimeReachabilityIdentity,
        HirRuntimeSelectedMethodOwners, HirRuntimeSemanticReachability,
        HirSelectedCallExpressionInventory,
    },
    scope::HirScopeKind,
    source_index::{
        HirDeclarationSourceRole, HirExprSourceRole, HirItemSourceRole, HirSourcePresence,
        HirSourceQuery, HirSourceSite,
    },
};
use arcweft_source::{Diagnostic, DiagnosticLabel, DiagnosticSeverity, SourceSpan};
use thiserror::Error;

#[cfg(test)]
use std::sync::atomic::AtomicBool;

use super::PhysicalCandidateArgumentEvaluation;
use super::match_edges;
use super::{
    CallTargetFacts, CaptureId, CheckedBinding, CheckedCallableCatalog, CheckedExpression,
    CheckedExpressionCallCallee, CheckedExpressionExecutionPlan, CheckedExpressionResolution,
    CheckedImplicitCallable, CheckedImplicitCallableBody, CheckedImplicitCallableIdentity,
    CheckedImplicitCapture, CheckedImplicitParameterOccurrence, CheckedItem, CheckedPattern,
    CheckedPipe, CheckedPipeBindingIdentity, CheckedPipeLeftOccurrence,
    CheckedRuntimeValueDisposition, CheckedStatement, CheckedTry, CheckedTryBoundary,
    CheckedTryCarrier, ExprId, FinalSemanticAnalysisControl, FinalSemanticAnalysisError,
    FinalSemanticAnalysisInput, FinalSemanticAnalysisWork, FinalSemanticProjectError,
    HirAnalysisProjectView, HirModule, HirModuleId, ItemId, LocalId, PatternId, ProjectSymbolTable,
    SemanticFactFamily, StmtId, TypeId, TypeKind, TypeResolutionReport,
    validation::{
        SemanticFactInventory, accepted_type_owners, collect_unique, collect_work,
        validate_bindings, validate_calls, validate_complete_inventory, validate_expressions,
        validate_items, validate_patterns, validate_physical_candidate_argument_evaluations,
        validate_statements, validate_types,
    },
};
use crate::callable::CheckedCallSite;
use crate::entry::CheckedEntryCatalog;
use crate::semantic_coordinate::AcceptedSemanticRootCatalog;

use super::nominal_schema::RuntimeNominalProjectionCatalog;
use super::nominal_semantic::{ProjectNominalSemanticCatalog, ProjectNominalSemanticDefinition};
use super::semantic_shapes::AcceptedSemanticShapeCatalog;

/// Immutable semantic analysis bound to one exact accepted HIR generation.
#[derive(Clone, Debug)]
pub struct FinalSemanticAnalysis {
    authority: FinalSemanticAnalysisAuthority,
    checked_callables: Arc<CheckedCallableCatalog>,
    accepted_roots: Arc<AcceptedSemanticRootCatalog>,
    checked_entries: CheckedEntryCatalog,
    project_nominals: ProjectNominalSemanticCatalog,
    checked_text_proxies: crate::checked_text_proxy::CheckedTextProxyCatalog,
    checked_fx_definitions: super::CheckedFxDefinitionCatalog,
    display_conformances: super::analyzer::display::DisplayConformanceCatalog,
    local_uses: Arc<super::CheckedLocalUseCatalog>,
    semantic_shapes: AcceptedSemanticShapeCatalog,
    runtime_nominals: RuntimeNominalProjectionCatalog,
    dialogue_lines: arcweft_lang_hir::project::AcceptedDialogueLineInventory,
    types: BTreeMap<TypeId, TypeKind>,
    type_resolutions: BTreeMap<TypeId, TypeResolutionReport>,
    type_resolution_nodes: BTreeMap<TypeId, ResolvedTypeNodeLocation>,
    locals: BTreeMap<LocalId, CheckedBinding>,
    captures: BTreeMap<CaptureId, CheckedBinding>,
    expressions: BTreeMap<ExprId, CheckedExpression>,
    patterns: BTreeMap<PatternId, CheckedPattern>,
    statements: BTreeMap<StmtId, CheckedStatement>,
    items: BTreeMap<ItemId, CheckedItem>,
    calls: BTreeMap<ExprId, CallTargetFacts>,
    selected_call_inventories: BTreeMap<ExprId, HirSelectedCallExpressionInventory>,
    expression_execution_regions: super::execution_regions::CheckedExecutionCatalog,
    pub(super) edge_facts: BTreeMap<
        ExprId,
        Result<super::CheckedExpressionEdgeFact, super::CheckedExpressionEdgeError>,
    >,
    diagnostics: Arc<[Diagnostic]>,
    #[cfg(test)]
    physical_candidate_argument_evaluations:
        BTreeMap<ExprId, Arc<[PhysicalCandidateArgumentEvaluation]>>,
    work: FinalSemanticAnalysisWork,
}

/// Exact address of a source-owned node in the immutable resolution reports.
/// No nominal facts are copied into this lookup index.
#[derive(Clone, Copy, Debug)]
struct ResolvedTypeNodeLocation {
    root: TypeId,
    node: usize,
}

/// Retains the actual registration allocations, rather than reconstructing
/// authority from matching digests. Hand-assembled unit fixtures cannot issue
/// accepted Rust runtime projections.
#[derive(Clone, Debug)]
pub(super) enum FinalSemanticAnalysisAuthority {
    Registered(crate::registration::RegisteredSemanticWorld),
    #[cfg(test)]
    Fixture,
}

/// Final execution projection for one checked expression.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedExpressionExecution {
    Structural {
        value: CheckedRuntimeValueDisposition,
    },
    Call {
        result: CheckedRuntimeValueDisposition,
        callee: CheckedCallExecutionCallee,
    },
    /// A checked call result is materialized as a runtime constant; the
    /// application digest retains the exact compile-time producer authority.
    ResidualValue {
        application: crate::callable::CheckedCallApplicationDigest,
    },
}

/// Callee handling selected by one sealed ordinary call application.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedCallExecutionCallee {
    Static,
    SemanticValue { expression: ExprId },
    RuntimeReceiver,
    RuntimeValue { expression: ExprId },
}

/// Exact checked execution row for one explicit closure producer.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FinalAnalysisClosureExecution {
    owner: ExprId,
    definition_identity: super::CheckedExecutionDefinitionIdentity,
    captures: Box<[CheckedClosureCaptureOrigin]>,
    id: crate::callable::CheckedClosureId,
    effects: crate::effect_row::EffectRow,
    suspension: super::CheckedSuspensionRole,
    control: super::CheckedExecutableControlRole,
}

/// Accepted lexical definition of an implicit callable, independent of a
/// closed generic instance's types and capture transfer modes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FinalAnalysisImplicitCallableDefinition {
    owner: ExprId,
    identity: CheckedImplicitCallableIdentity,
    definition_identity: super::CheckedExecutionDefinitionIdentity,
    control: super::CheckedExecutableControlRole,
    captures: Box<[CheckedImplicitCallableCaptureOrigin]>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckedImplicitCallableCaptureOrigin {
    position: u32,
    local: LocalId,
    origin: crate::semantic_coordinate::StableCheckedBindingCoordinate,
}

impl CheckedImplicitCallableCaptureOrigin {
    pub const fn position(&self) -> u32 {
        self.position
    }
    pub const fn local(&self) -> LocalId {
        self.local
    }
    pub const fn origin(&self) -> &crate::semantic_coordinate::StableCheckedBindingCoordinate {
        &self.origin
    }
}

impl FinalAnalysisImplicitCallableDefinition {
    pub const fn owner(&self) -> ExprId {
        self.owner
    }
    pub const fn identity(&self) -> CheckedImplicitCallableIdentity {
        self.identity
    }
    pub const fn definition_identity(&self) -> super::CheckedExecutionDefinitionIdentity {
        self.definition_identity
    }
    pub const fn control(&self) -> super::CheckedExecutableControlRole {
        self.control
    }
    pub const fn captures(&self) -> &[CheckedImplicitCallableCaptureOrigin] {
        &self.captures
    }
}

/// Accepted stable origin and exact generation-local join of one closure
/// capture. Only the final closure execution projection issues these rows.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckedClosureCaptureOrigin {
    position: u32,
    capture: CaptureId,
    source: LocalId,
    origin: crate::semantic_coordinate::CheckedLocalBindingOrigin,
}

impl CheckedClosureCaptureOrigin {
    pub const fn position(&self) -> u32 {
        self.position
    }
    pub const fn capture(&self) -> CaptureId {
        self.capture
    }
    pub const fn source(&self) -> LocalId {
        self.source
    }
    pub const fn checked_origin(&self) -> &crate::semantic_coordinate::CheckedLocalBindingOrigin {
        &self.origin
    }
    pub const fn origin(&self) -> &crate::semantic_coordinate::StableCheckedBindingCoordinate {
        self.origin.coordinate()
    }
}

impl FinalAnalysisClosureExecution {
    pub const fn owner(&self) -> ExprId {
        self.owner
    }

    pub const fn definition_identity(&self) -> super::CheckedExecutionDefinitionIdentity {
        self.definition_identity
    }

    pub const fn captures(&self) -> &[CheckedClosureCaptureOrigin] {
        &self.captures
    }

    pub const fn id(&self) -> &crate::callable::CheckedClosureId {
        &self.id
    }

    pub const fn effects(&self) -> &crate::effect_row::EffectRow {
        &self.effects
    }

    pub const fn suspension(&self) -> super::CheckedSuspensionRole {
        self.suspension
    }

    pub const fn control(&self) -> super::CheckedExecutableControlRole {
        self.control
    }
}

/// Failure to project one checked expression into execution.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum FinalAnalysisExecutionProjectionError {
    #[error("checked expression {owner:?} has no accepted structural coordinate")]
    InvalidExpressionCoordinate { owner: ExprId },
    #[error("checked statement {owner:?} has no accepted structural coordinate")]
    InvalidStatementCoordinate { owner: StmtId },
    #[error("program source {owner:?} belongs to another callable authority")]
    ForeignProgramCallableAuthority {
        owner: super::CheckedExecutionSource,
    },
    #[error("program source {owner:?} belongs to another HIR authority")]
    ForeignProgramHirAuthority {
        owner: super::CheckedExecutionSource,
    },
    #[error("checked expression {owner:?} is absent from the final analysis")]
    MissingExpression { owner: ExprId },
    #[error("checked source type {owner:?} has no accepted nominal-resolution purpose")]
    MissingTypeResolution { owner: TypeId },
    #[error("checked pattern {owner:?} is absent from the final analysis")]
    MissingPattern { owner: PatternId },
    #[error("checked statement {owner:?} is absent from the final analysis")]
    MissingStatement { owner: StmtId },
    #[error("checked HirCall expression {owner:?} has no call fact")]
    MissingCallFacts { owner: ExprId },
    #[error("checked HirCall expression {owner:?} has no selected call application")]
    UnselectedCall { owner: ExprId },
    #[error(
        "checked HirCall expression {owner:?} has a mismatched call fact site: expected {expected:?}, actual {actual:?}"
    )]
    CallSiteMismatch {
        owner: ExprId,
        expected: CheckedCallSite,
        actual: CheckedCallSite,
    },
    #[error("checked expression {owner:?} does not have the requested execution view")]
    WrongExpressionKind { owner: ExprId },
    #[error("runtime reachability has no executable-owner partition for {executable:?}")]
    MissingExecutablePartition {
        executable: HirRuntimeExecutableOwner,
    },
    #[error("checked closure expression {owner:?} has no exact source/execution authority")]
    MissingClosureExecution { owner: ExprId },
    #[error(
        "checked callable expression {owner:?} has invalid accepted definition/capture coordinates"
    )]
    InvalidCallableCoordinates { owner: ExprId },
    #[error("checked constructor call {owner:?} has no exact instantiated variant authority")]
    InvalidVariantConstructor { owner: ExprId },
}

/// Borrowed final-analysis authority for execution.
///
/// This is the only cross-layer source for expression execution decisions and
/// the typed implicit-callable/pipe views. It borrows the immutable report so
/// consumers cannot rebuild execution facts by rescanning HIR.
pub struct FinalAnalysisExecutionProjection<'analysis> {
    analysis: &'analysis FinalSemanticAnalysis,
}

/// Runtime semantic-payload family selected for one expression in an exact
/// executable-owner partition.
///
/// This is a family tag rather than a second semantic payload. The final
/// checked expression remains the payload authority; the tag seals which
/// runtime-fact algebra member a downstream projection must publish.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedExecutableRuntimeExpressionFactFamily {
    Structural,
    Scope,
    Consumed,
    Literal,
    Value,
    Select,
    NominalRecord,
    Variant,
    Call,
    ResidualValue,
    EvaluatedEffect,
    PostfixCandidate,
    Await,
    Thread,
    Choice,
    Try,
    ImplicitCallable,
    Pipe,
    DialogueApplication,
    ContentApplication,
    Closure,
}

/// One final-sema-sealed expression row in an executable partition.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckedExecutableRuntimeExpressionFactOwner {
    owner: ExprId,
    coordinate: crate::semantic_coordinate::CheckedSemanticPath,
    producer_kind: Option<crate::CheckedExpressionProducerKind>,
    family: CheckedExecutableRuntimeExpressionFactFamily,
    has_runtime_type: bool,
    children: Box<[ExprId]>,
}

/// An immutable classification issued by final sema for one selected source
/// owner. This is type evidence, not an executable frame or capability grant.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckedSemanticValueProjection {
    reachability: HirRuntimeReachabilityIdentity,
    owner: HirValueTypeOwner,
    ty: crate::types::CompileTimeCallableType,
}

impl CheckedSemanticValueProjection {
    pub const fn owner(&self) -> HirValueTypeOwner {
        self.owner
    }
    pub const fn ty(&self) -> &crate::types::CompileTimeCallableType {
        &self.ty
    }
    pub fn belongs_to(&self, reachability: &HirRuntimeReachabilityIdentity) -> bool {
        &self.reachability == reachability
    }
}

impl CheckedExecutableRuntimeExpressionFactOwner {
    pub const fn coordinate(&self) -> &crate::semantic_coordinate::CheckedSemanticPath {
        &self.coordinate
    }
    pub const fn producer_kind(&self) -> Option<crate::CheckedExpressionProducerKind> {
        self.producer_kind
    }

    pub const fn owner(&self) -> ExprId {
        self.owner
    }

    pub const fn family(&self) -> CheckedExecutableRuntimeExpressionFactFamily {
        self.family
    }

    pub const fn has_runtime_type(&self) -> bool {
        self.has_runtime_type
    }

    pub const fn children(&self) -> &[ExprId] {
        &self.children
    }
}

/// Runtime semantic-payload family selected for one pattern.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedExecutableRuntimePatternFactFamily {
    Structural,
    Literal,
    Entity,
    NominalRecord,
    Variant,
    TypedBinding,
}

/// One final-sema-sealed pattern row in an executable partition.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CheckedExecutableRuntimePatternFactOwner {
    owner: PatternId,
    family: CheckedExecutableRuntimePatternFactFamily,
}

impl CheckedExecutableRuntimePatternFactOwner {
    pub const fn owner(self) -> PatternId {
        self.owner
    }

    pub const fn family(self) -> CheckedExecutableRuntimePatternFactFamily {
        self.family
    }
}

/// Runtime semantic-payload family selected for one statement.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedExecutableRuntimeStatementFactFamily {
    Structural,
    Assignment,
    RegistryWrite,
    Assertion,
    Defer,
    EvaluatedEffect,
    Iteration,
    ControlTransfer,
    Trigger,
    UnsafeAudit,
    Select,
    SourceLocale,
    Scope,
    Include,
    Suspension,
    Yield,
}

/// One final-sema-sealed statement row in an executable partition.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CheckedExecutableRuntimeStatementFactOwner {
    owner: StmtId,
    coordinate: crate::semantic_coordinate::StableCheckedStatementCoordinate,
    family: CheckedExecutableRuntimeStatementFactFamily,
}

impl CheckedExecutableRuntimeStatementFactOwner {
    pub const fn coordinate(
        &self,
    ) -> &crate::semantic_coordinate::StableCheckedStatementCoordinate {
        &self.coordinate
    }

    pub const fn owner(&self) -> StmtId {
        self.owner
    }

    pub const fn family(&self) -> CheckedExecutableRuntimeStatementFactFamily {
        self.family
    }
}

/// One final-sema-sealed source type row in an executable partition.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckedExecutableRuntimeTypeFactOwner {
    owner: TypeId,
    purpose: crate::nominal::ResolvedTypeNodePurpose,
}

impl CheckedExecutableRuntimeTypeFactOwner {
    pub const fn owner(&self) -> TypeId {
        self.owner
    }

    pub const fn purpose(&self) -> &crate::nominal::ResolvedTypeNodePurpose {
        &self.purpose
    }

    pub const fn has_runtime_type(&self) -> bool {
        self.purpose.has_runtime_type()
    }
}

/// Sealed final-sema inventory of every semantic owner belonging to one exact
/// HIR executable partition.
///
/// Nested closure bodies belong to independent rows. Private fields prevent a
/// downstream compiler or runtime-fact producer from substituting an
/// arbitrary same-module owner row or silently omitting a semantic family.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckedExecutableRuntimeFactPartition {
    reachability: HirRuntimeReachabilityIdentity,
    executable: HirRuntimeExecutableOwner,
    expressions: Box<[CheckedExecutableRuntimeExpressionFactOwner]>,
    patterns: Box<[CheckedExecutableRuntimePatternFactOwner]>,
    statements: Box<[CheckedExecutableRuntimeStatementFactOwner]>,
    locals: Box<[LocalId]>,
    input_locals: Box<[LocalId]>,
    types: Box<[CheckedExecutableRuntimeTypeFactOwner]>,
    captures: Box<[CaptureId]>,
    semantic_values: BTreeMap<HirValueTypeOwner, crate::types::CompileTimeCallableType>,
}

impl CheckedExecutableRuntimeFactPartition {
    pub fn semantic_value_projection(
        &self,
        owner: HirValueTypeOwner,
    ) -> Option<CheckedSemanticValueProjection> {
        Some(CheckedSemanticValueProjection {
            reachability: self.reachability.clone(),
            owner,
            ty: self.semantic_values.get(&owner)?.clone(),
        })
    }
    pub fn semantic_value_projections(
        &self,
    ) -> impl Iterator<Item = CheckedSemanticValueProjection> + '_ {
        self.semantic_values
            .iter()
            .map(|(owner, ty)| CheckedSemanticValueProjection {
                reachability: self.reachability.clone(),
                owner: *owner,
                ty: ty.clone(),
            })
    }
    /// The accepted semantic classification is distinct from an omitted
    /// effect result. It proves which values may be erased from runtime data.
    pub fn semantic_value_type(
        &self,
        owner: HirValueTypeOwner,
    ) -> Option<&crate::types::CompileTimeCallableType> {
        self.semantic_values.get(&owner)
    }
    pub const fn reachability(&self) -> &HirRuntimeReachabilityIdentity {
        &self.reachability
    }

    pub const fn executable(&self) -> &HirRuntimeExecutableOwner {
        &self.executable
    }

    pub const fn expressions(&self) -> &[CheckedExecutableRuntimeExpressionFactOwner] {
        &self.expressions
    }

    pub const fn patterns(&self) -> &[CheckedExecutableRuntimePatternFactOwner] {
        &self.patterns
    }

    pub const fn statements(&self) -> &[CheckedExecutableRuntimeStatementFactOwner] {
        &self.statements
    }

    pub const fn locals(&self) -> &[LocalId] {
        &self.locals
    }

    /// Ingress bindings belong to this frame without redeclaring their source local.
    pub const fn input_locals(&self) -> &[LocalId] {
        &self.input_locals
    }

    pub const fn types(&self) -> &[CheckedExecutableRuntimeTypeFactOwner] {
        &self.types
    }

    pub const fn captures(&self) -> &[CaptureId] {
        &self.captures
    }
}

impl FinalAnalysisExecutionProjection<'_> {
    pub fn runtime_program_fact_partition(
        &self,
        reachability: &HirRuntimeSemanticReachability<'_>,
        program: &super::CheckedDeterministicProgram,
    ) -> Result<CheckedExecutableRuntimeFactPartition, FinalAnalysisExecutionProjectionError> {
        let abi = program.input_abi();
        abi.validate_analysis(self.analysis).map_err(|_| {
            FinalAnalysisExecutionProjectionError::ForeignProgramCallableAuthority {
                owner: abi.source().clone(),
            }
        })?;
        abi.validate_project(reachability.project()).map_err(|_| {
            FinalAnalysisExecutionProjectionError::ForeignProgramHirAuthority {
                owner: abi.source().clone(),
            }
        })?;
        let mut partition =
            self.runtime_fact_partition(reachability, &program.reachability_owner())?;
        partition.input_locals = abi
            .inputs()
            .iter()
            .filter(|input| matches!(input.role(), super::CheckedExecutionInputRole::Free))
            .map(|input| input.binding().local())
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect();
        Ok(partition)
    }

    /// Projects one closure through its typed source-bound callable identity
    /// and completed effect/suspension/control row.
    pub fn closure_execution(
        &self,
        reachability: &HirRuntimeSemanticReachability<'_>,
        owner: ExprId,
    ) -> Result<FinalAnalysisClosureExecution, FinalAnalysisExecutionProjectionError> {
        let expression = self
            .analysis
            .expression(owner)
            .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?;
        let CheckedExpressionResolution::Closure(closure) = expression.resolution() else {
            return Err(FinalAnalysisExecutionProjectionError::WrongExpressionKind { owner });
        };
        let module = reachability
            .project()
            .modules()
            .find_map(|(_, module)| (module.module_id() == owner.module()).then_some(module))
            .ok_or(FinalAnalysisExecutionProjectionError::MissingClosureExecution { owner })?;
        let source = module
            .source_site(
                module.provenance().source_identity(),
                HirSourceQuery::Expr {
                    owner,
                    role: HirExprSourceRole::Whole,
                },
            )
            .ok()
            .and_then(|lookup| match lookup.presence() {
                HirSourcePresence::Present(HirSourceSite::Span(span)) => Some(span),
                HirSourcePresence::Present(HirSourceSite::Insertion(_))
                | HirSourcePresence::AbsentOptional => None,
            })
            .ok_or(FinalAnalysisExecutionProjectionError::MissingClosureExecution { owner })?;
        let (id, execution) = self
            .analysis
            .checked_callables()
            .closure_identity_and_execution_at_source(source)
            .map_err(
                |_| FinalAnalysisExecutionProjectionError::MissingClosureExecution { owner },
            )?;
        let coordinates = crate::semantic_coordinate::SemanticCoordinateIndex::new(
            self.analysis.accepted_root_catalog(),
            self.analysis,
        );
        let invalid =
            || FinalAnalysisExecutionProjectionError::InvalidCallableCoordinates { owner };
        let path = coordinates.expression(owner).map_err(|_| invalid())?;
        let definition_identity = super::CheckedExecutionDefinitionIdentity::from_coordinate(
            &super::CheckedExecutionCoordinate::CallableBody(path),
        )
        .map_err(|_| invalid())?;
        let runtime_captures = closure
            .captures()
            .iter()
            .map(|capture| {
                let checked = self
                    .analysis
                    .capture(capture.capture())
                    .ok_or_else(invalid)?;
                Ok((
                    capture,
                    !matches!(checked.ty(), TypeKind::CompileTimeCallable(_)),
                ))
            })
            .collect::<Result<Vec<_>, FinalAnalysisExecutionProjectionError>>()?;
        let captures = runtime_captures
            .into_iter()
            .filter_map(|(capture, runtime)| runtime.then_some(capture))
            .enumerate()
            .map(|(position, capture)| {
                Ok(CheckedClosureCaptureOrigin {
                    position: u32::try_from(position).map_err(|_| invalid())?,
                    capture: capture.capture(),
                    source: capture.local(),
                    origin: self
                        .analysis
                        .local_binding_origin(capture.local())
                        .map_err(|_| invalid())?,
                })
            })
            .collect::<Result<Box<[_]>, FinalAnalysisExecutionProjectionError>>()?;
        Ok(FinalAnalysisClosureExecution {
            owner,
            definition_identity,
            captures,
            id: id.clone(),
            effects: execution.effects().clone(),
            suspension: execution.suspension(),
            control: execution.control(),
        })
    }

    /// Seals every checked semantic owner for one exact executable owner.
    /// Calls suppressed by their checked execution plan are tagged Consumed;
    /// nested closures retain only their value expression here while their
    /// bodies belong to the closure's independent HIR partition.
    pub fn runtime_fact_partition(
        &self,
        reachability: &HirRuntimeSemanticReachability<'_>,
        executable: &HirRuntimeExecutableOwner,
    ) -> Result<CheckedExecutableRuntimeFactPartition, FinalAnalysisExecutionProjectionError> {
        let owners = reachability.executable_owners(executable).ok_or_else(|| {
            FinalAnalysisExecutionProjectionError::MissingExecutablePartition {
                executable: executable.clone(),
            }
        })?;
        self.classify_runtime_fact_partition(
            reachability.project(),
            reachability.identity(),
            executable,
            owners,
        )
    }

    /// Classifies an exact selected trait-method body under the original
    /// reachability generation without adding it to the global owner graph.
    pub fn selected_method_fact_partition(
        &self,
        selected: &HirRuntimeSelectedMethodOwners<'_>,
    ) -> Result<CheckedExecutableRuntimeFactPartition, FinalAnalysisExecutionProjectionError> {
        self.classify_runtime_fact_partition(
            selected.project(),
            selected.reachability(),
            selected.executable(),
            selected.owners(),
        )
    }

    /// Classifies a nested closure selected under one closed method owner.
    /// The closure retains its own executable partition and the method's
    /// original reachability generation without entering the global graph.
    pub fn selected_method_closure_fact_partition(
        &self,
        selected: &HirRuntimeSelectedMethodOwners<'_>,
        owner: ExprId,
    ) -> Result<CheckedExecutableRuntimeFactPartition, FinalAnalysisExecutionProjectionError> {
        let executable = HirRuntimeExecutableOwner::CallableBody(owner);
        let owners = selected.closure_owners(owner).ok_or_else(|| {
            FinalAnalysisExecutionProjectionError::MissingExecutablePartition {
                executable: executable.clone(),
            }
        })?;
        self.classify_runtime_fact_partition(
            selected.project(),
            selected.reachability(),
            &executable,
            owners,
        )
    }

    fn classify_runtime_fact_partition(
        &self,
        project: HirAnalysisProjectView<'_>,
        reachability: &HirRuntimeReachabilityIdentity,
        executable: &HirRuntimeExecutableOwner,
        owners: &HirRuntimeExecutableSemanticOwners,
    ) -> Result<CheckedExecutableRuntimeFactPartition, FinalAnalysisExecutionProjectionError> {
        let coordinates = crate::semantic_coordinate::SemanticCoordinateIndex::new(
            self.analysis.accepted_root_catalog(),
            self.analysis,
        );
        let module = |owner: ExprId| {
            project
                .modules()
                .find_map(|(_, module)| (module.module_id() == owner.module()).then_some(module))
        };
        let mut expressions = Vec::new();
        let mut semantic_values = BTreeMap::new();
        for owner in owners.expressions() {
            if let Some(TypeKind::CompileTimeCallable(ty)) = self
                .analysis
                .expression(owner)
                .and_then(|expression| expression.value_type())
            {
                semantic_values.insert(HirValueTypeOwner::Expression(owner), ty.clone());
            }
        }
        for owner in owners.patterns() {
            if let Some(pattern) = self.analysis.pattern(owner)
                && let TypeKind::CompileTimeCallable(ty) = pattern.ty()
            {
                semantic_values.insert(HirValueTypeOwner::Pattern(owner), ty.clone());
            }
        }
        for owner in owners.locals() {
            if let Some(local) = self.analysis.local(owner)
                && let TypeKind::CompileTimeCallable(ty) = local.ty()
            {
                semantic_values.insert(HirValueTypeOwner::Local(owner), ty.clone());
            }
        }
        for owner in owners.types() {
            if let Some(TypeKind::CompileTimeCallable(ty)) = self.analysis.ty(owner) {
                semantic_values.insert(HirValueTypeOwner::Type(owner), ty.clone());
            }
        }
        for owner in owners.captures() {
            if let Some(capture) = self.analysis.capture(owner)
                && let TypeKind::CompileTimeCallable(ty) = capture.ty()
            {
                semantic_values.insert(HirValueTypeOwner::Capture(owner), ty.clone());
            }
        }
        let runtime_type_owners = owners.expression_type_owners().collect::<BTreeSet<_>>();
        for owner in owners.expressions() {
            let expression = self
                .analysis
                .expression(owner)
                .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?;
            let hir = module(owner)
                .and_then(|module| module.resolve_expr(owner).ok())
                .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?;
            let plan = self.plan(owner)?;
            let semantic_value =
                semantic_values.contains_key(&HirValueTypeOwner::Expression(owner));
            let family = if semantic_value || plan.is_registry_drop_address() {
                CheckedExecutableRuntimeExpressionFactFamily::Consumed
            } else if expression.evaluated_effect().is_some() {
                if !plan.is_evaluated_effect_carrier() {
                    return Err(FinalAnalysisExecutionProjectionError::WrongExpressionKind {
                        owner,
                    });
                }
                CheckedExecutableRuntimeExpressionFactFamily::EvaluatedEffect
            } else if plan.executes_as_runtime_call() {
                if !self.analysis.calls.contains_key(&owner) {
                    return Err(FinalAnalysisExecutionProjectionError::MissingCallFacts { owner });
                }
                CheckedExecutableRuntimeExpressionFactFamily::Call
            } else if plan.residual_value_application().is_some() {
                if !self.analysis.calls.contains_key(&owner) {
                    return Err(FinalAnalysisExecutionProjectionError::MissingCallFacts { owner });
                }
                CheckedExecutableRuntimeExpressionFactFamily::ResidualValue
            } else {
                match expression.resolution() {
                    CheckedExpressionResolution::Structural
                        if matches!(
                            hir.kind(),
                            arcweft_lang_hir::expr::HirExprKind::NumericBracketSequence(_)
                        ) =>
                    {
                        CheckedExecutableRuntimeExpressionFactFamily::Literal
                    }
                    CheckedExpressionResolution::Structural => {
                        CheckedExecutableRuntimeExpressionFactFamily::Structural
                    }
                    CheckedExpressionResolution::Scope(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Scope
                    }
                    CheckedExpressionResolution::Literal(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Literal
                    }
                    CheckedExpressionResolution::CompileTimeScalar(scalar)
                        if scalar.value().runtime_quantity().is_some() =>
                    {
                        CheckedExecutableRuntimeExpressionFactFamily::Literal
                    }
                    CheckedExpressionResolution::Value(value)
                        if matches!(
                            value,
                            super::CheckedValueResolution::Local(_)
                                | super::CheckedValueResolution::RegistryRead(_)
                                | super::CheckedValueResolution::EnvironmentCallable(_)
                                | super::CheckedValueResolution::CatalogAsset(_)
                                | super::CheckedValueResolution::Registered(_)
                                | super::CheckedValueResolution::Constant(_)
                        ) || (matches!(
                            value,
                            super::CheckedValueResolution::ProjectItem(_)
                                | super::CheckedValueResolution::ImportedProjectEntity(_)
                                | super::CheckedValueResolution::PresentationAddress(_)
                        ) && matches!(
                            expression.value_type(),
                            Some(TypeKind::Ref(_))
                        )) =>
                    {
                        CheckedExecutableRuntimeExpressionFactFamily::Value
                    }
                    CheckedExpressionResolution::DialogueLineReference(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Value
                    }
                    CheckedExpressionResolution::Value(
                        super::CheckedValueResolution::ProjectCallable(callable),
                    ) if runtime_type_owners.contains(&owner)
                        && callable.declaration().owner()
                            == arcweft_lang_hir::symbol::CallableDeclarationOwner::Function =>
                    {
                        CheckedExecutableRuntimeExpressionFactFamily::Value
                    }
                    CheckedExpressionResolution::Value(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Consumed
                    }
                    CheckedExpressionResolution::Select(super::CheckedSelectResolution::Field(
                        _,
                    )) if matches!(hir.kind(), arcweft_lang_hir::expr::HirExprKind::Path(_))
                        && expression
                            .mutable_place()
                            .is_some_and(|place| !place.fields().is_empty()) =>
                    {
                        CheckedExecutableRuntimeExpressionFactFamily::Value
                    }
                    CheckedExpressionResolution::Select(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Select
                    }
                    CheckedExpressionResolution::Nominal(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::NominalRecord
                    }
                    CheckedExpressionResolution::Variant(_)
                    | CheckedExpressionResolution::StageLook(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Variant
                    }
                    CheckedExpressionResolution::Await(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Await
                    }
                    CheckedExpressionResolution::Thread(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Thread
                    }
                    CheckedExpressionResolution::Choice(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Choice
                    }
                    CheckedExpressionResolution::Try(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Try
                    }
                    CheckedExpressionResolution::ImplicitCallable(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::ImplicitCallable
                    }
                    CheckedExpressionResolution::Closure(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Closure
                    }
                    CheckedExpressionResolution::Pipe(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Pipe
                    }
                    CheckedExpressionResolution::DialogueApplication { .. } => {
                        CheckedExecutableRuntimeExpressionFactFamily::DialogueApplication
                    }
                    CheckedExpressionResolution::ContentApplication(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::ContentApplication
                    }
                    CheckedExpressionResolution::PostfixBracket(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::PostfixCandidate
                    }
                    CheckedExpressionResolution::RegistryAddress(_)
                    | CheckedExpressionResolution::CompileTimeEnum(_)
                    | CheckedExpressionResolution::Effect(_)
                    | CheckedExpressionResolution::Call
                    | CheckedExpressionResolution::ImplicitParameter(_)
                    | CheckedExpressionResolution::PipeLeft(_)
                    | CheckedExpressionResolution::ViewCall(_)
                    | CheckedExpressionResolution::ViewFxApplication(_)
                    | CheckedExpressionResolution::StyleValue(_)
                    | CheckedExpressionResolution::StyleOperand(_)
                    | CheckedExpressionResolution::ViewPartName(_)
                    | CheckedExpressionResolution::CompileTimeCallee(_)
                    | CheckedExpressionResolution::TypeValue(_)
                    | CheckedExpressionResolution::CompileTimeScalar(_)
                    | CheckedExpressionResolution::DialogueLineCoordinate(_)
                    | CheckedExpressionResolution::DialogueTextKeyCoordinate(_)
                    | CheckedExpressionResolution::CharacterDialogueFactory(_)
                    | CheckedExpressionResolution::CharacterDialogueReconfigure(_) => {
                        CheckedExecutableRuntimeExpressionFactFamily::Consumed
                    }
                }
            };
            expressions.push(CheckedExecutableRuntimeExpressionFactOwner {
                owner,
                coordinate: coordinates.expression(owner).map_err(|_| {
                    FinalAnalysisExecutionProjectionError::InvalidExpressionCoordinate { owner }
                })?,
                producer_kind: matches!(
                    expression.resolution(),
                    CheckedExpressionResolution::Thread(_)
                )
                .then_some(crate::CheckedExpressionProducerKind::Thread),
                family,
                has_runtime_type: runtime_type_owners.contains(&owner) && !semantic_value,
                children: owners.expression_children(owner).into(),
            });
        }

        let patterns = owners
            .patterns()
            .map(|owner| {
                let pattern = self
                    .analysis
                    .pattern(owner)
                    .ok_or(FinalAnalysisExecutionProjectionError::MissingPattern { owner })?;
                let family = match pattern.resolution() {
                    super::CheckedPatternResolution::Structural => {
                        CheckedExecutableRuntimePatternFactFamily::Structural
                    }
                    super::CheckedPatternResolution::Literal(_) => {
                        CheckedExecutableRuntimePatternFactFamily::Literal
                    }
                    super::CheckedPatternResolution::Entity(_)
                    | super::CheckedPatternResolution::ImportedProjectEntity(_)
                    | super::CheckedPatternResolution::PresentationAddress(_) => {
                        CheckedExecutableRuntimePatternFactFamily::Entity
                    }
                    super::CheckedPatternResolution::Record(_) => {
                        CheckedExecutableRuntimePatternFactFamily::NominalRecord
                    }
                    super::CheckedPatternResolution::Variant(_) => {
                        CheckedExecutableRuntimePatternFactFamily::Variant
                    }
                    super::CheckedPatternResolution::TypedBinding(_) => {
                        CheckedExecutableRuntimePatternFactFamily::TypedBinding
                    }
                };
                Ok(CheckedExecutableRuntimePatternFactOwner { owner, family })
            })
            .collect::<Result<Vec<_>, _>>()?;

        let statements = owners
            .statements()
            .map(|owner| {
                let statement = self
                    .analysis
                    .statement(owner)
                    .ok_or(FinalAnalysisExecutionProjectionError::MissingStatement { owner })?;
                let family = match statement.payload() {
                    super::CheckedStatementPayload::RegistryWrite(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::RegistryWrite
                    }
                    super::CheckedStatementPayload::Structural => {
                        CheckedExecutableRuntimeStatementFactFamily::Structural
                    }
                    super::CheckedStatementPayload::Assignment(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Assignment
                    }
                    super::CheckedStatementPayload::Assertion(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Assertion
                    }
                    super::CheckedStatementPayload::Defer(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Defer
                    }
                    super::CheckedStatementPayload::EvaluatedEffect(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::EvaluatedEffect
                    }
                    super::CheckedStatementPayload::Iteration(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Iteration
                    }
                    super::CheckedStatementPayload::ControlTransfer(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::ControlTransfer
                    }
                    super::CheckedStatementPayload::Trigger(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Trigger
                    }
                    super::CheckedStatementPayload::UnsafeAudit(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::UnsafeAudit
                    }
                    super::CheckedStatementPayload::Select(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Select
                    }
                    super::CheckedStatementPayload::SourceLocale(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::SourceLocale
                    }
                    super::CheckedStatementPayload::Scope(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Scope
                    }
                    super::CheckedStatementPayload::Include(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Include
                    }
                    super::CheckedStatementPayload::Suspension(_) => {
                        CheckedExecutableRuntimeStatementFactFamily::Suspension
                    }
                    super::CheckedStatementPayload::Yield => {
                        CheckedExecutableRuntimeStatementFactFamily::Yield
                    }
                };
                Ok(CheckedExecutableRuntimeStatementFactOwner {
                    owner,
                    family,
                    coordinate: coordinates.statement(owner).map_err(|_| {
                        FinalAnalysisExecutionProjectionError::InvalidStatementCoordinate { owner }
                    })?,
                })
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(CheckedExecutableRuntimeFactPartition {
            semantic_values,
            reachability: reachability.clone(),
            executable: executable.clone(),
            expressions: expressions.into_boxed_slice(),
            patterns: patterns.into_boxed_slice(),
            statements: statements.into_boxed_slice(),
            locals: owners.locals().collect(),
            input_locals: Box::new([]),
            types: owners
                .types()
                .map(|owner| {
                    let node = self.analysis.type_resolution_node(owner).ok_or(
                        FinalAnalysisExecutionProjectionError::MissingTypeResolution { owner },
                    )?;
                    Ok(CheckedExecutableRuntimeTypeFactOwner {
                        owner,
                        purpose: node.purpose(),
                    })
                })
                .collect::<Result<_, FinalAnalysisExecutionProjectionError>>()?,
            captures: owners.captures().collect(),
        })
    }

    /// Borrows an executable plan. A tooling-only call has no plan and cannot
    /// be reinterpreted as a structural expression that omits its value.
    pub fn plan(
        &self,
        owner: ExprId,
    ) -> Result<&CheckedExpressionExecutionPlan, FinalAnalysisExecutionProjectionError> {
        self.analysis
            .expression(owner)
            .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?
            .execution_plan()
            .ok_or(FinalAnalysisExecutionProjectionError::UnselectedCall { owner })
    }

    /// Returns the exact execution projection of one checked expression.
    pub fn expression(
        &self,
        owner: ExprId,
    ) -> Result<CheckedExpressionExecution, FinalAnalysisExecutionProjectionError> {
        Ok(match self.plan(owner)? {
            CheckedExpressionExecutionPlan::Structural { value, .. } => {
                CheckedExpressionExecution::Structural { value: *value }
            }
            CheckedExpressionExecutionPlan::Call { result, callee, .. } => {
                CheckedExpressionExecution::Call {
                    result: *result,
                    callee: match callee {
                        CheckedExpressionCallCallee::Static => CheckedCallExecutionCallee::Static,
                        CheckedExpressionCallCallee::SemanticValue { expression } => {
                            CheckedCallExecutionCallee::SemanticValue {
                                expression: *expression,
                            }
                        }
                        CheckedExpressionCallCallee::RuntimeReceiver => {
                            CheckedCallExecutionCallee::RuntimeReceiver
                        }
                        CheckedExpressionCallCallee::RuntimeValue { expression } => {
                            CheckedCallExecutionCallee::RuntimeValue {
                                expression: *expression,
                            }
                        }
                    },
                }
            }
            CheckedExpressionExecutionPlan::ResidualValue { application, .. } => {
                CheckedExpressionExecution::ResidualValue {
                    application: *application,
                }
            }
        })
    }

    /// Borrows the accepted implicit-callable execution view for `owner`.
    pub fn implicit_callable(
        &self,
        owner: ExprId,
    ) -> Result<FinalAnalysisImplicitCallableView<'_>, FinalAnalysisExecutionProjectionError> {
        let expression = self
            .analysis
            .expression(owner)
            .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?;
        let CheckedExpressionResolution::ImplicitCallable(callable) = expression.resolution()
        else {
            return Err(FinalAnalysisExecutionProjectionError::WrongExpressionKind { owner });
        };
        let coordinates = crate::semantic_coordinate::SemanticCoordinateIndex::new(
            self.analysis.accepted_root_catalog(),
            self.analysis,
        );
        let invalid =
            || FinalAnalysisExecutionProjectionError::InvalidCallableCoordinates { owner };
        let definition_identity = super::CheckedExecutionDefinitionIdentity::from_coordinate(
            &super::CheckedExecutionCoordinate::CallableBody(
                coordinates.expression(owner).map_err(|_| invalid())?,
            ),
        )
        .map_err(|_| invalid())?;
        let control = self
            .analysis
            .callable_body_control(owner)
            .ok_or_else(invalid)?;
        let mut captured_locals = BTreeSet::new();
        let captures = callable
            .captures()
            .iter()
            .enumerate()
            .map(|(position, capture)| {
                let local = capture.lookup_local();
                if !captured_locals.insert(local) {
                    return Err(invalid());
                }
                Ok(CheckedImplicitCallableCaptureOrigin {
                    position: u32::try_from(position).map_err(|_| invalid())?,
                    local,
                    origin: capture.origin().clone(),
                })
            })
            .collect::<Result<Box<[_]>, FinalAnalysisExecutionProjectionError>>()?;
        Ok(FinalAnalysisImplicitCallableView {
            callable,
            definition: FinalAnalysisImplicitCallableDefinition {
                owner,
                identity: callable.identity(),
                definition_identity,
                control,
                captures,
            },
        })
    }

    /// Borrows the accepted once-only pipe execution view for `owner`.
    pub fn pipe(
        &self,
        owner: ExprId,
    ) -> Result<FinalAnalysisPipeView<'_>, FinalAnalysisExecutionProjectionError> {
        let expression = self
            .analysis
            .expression(owner)
            .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?;
        let CheckedExpressionResolution::Pipe(pipe) = expression.resolution() else {
            return Err(FinalAnalysisExecutionProjectionError::WrongExpressionKind { owner });
        };
        Ok(FinalAnalysisPipeView { pipe })
    }

    /// Borrows the exact checked Try execution view for `owner`.
    pub fn try_expression(
        &self,
        owner: ExprId,
    ) -> Result<FinalAnalysisTryView<'_>, FinalAnalysisExecutionProjectionError> {
        let expression = self
            .analysis
            .expression(owner)
            .ok_or(FinalAnalysisExecutionProjectionError::MissingExpression { owner })?;
        let CheckedExpressionResolution::Try(tried) = expression.resolution() else {
            return Err(FinalAnalysisExecutionProjectionError::WrongExpressionKind { owner });
        };
        Ok(FinalAnalysisTryView { tried })
    }
}

/// Typed execution view of one checked implicit callable.
pub struct FinalAnalysisImplicitCallableView<'analysis> {
    callable: &'analysis CheckedImplicitCallable,
    definition: FinalAnalysisImplicitCallableDefinition,
}

impl FinalAnalysisImplicitCallableView<'_> {
    pub const fn definition(&self) -> &FinalAnalysisImplicitCallableDefinition {
        &self.definition
    }
    pub const fn identity(&self) -> CheckedImplicitCallableIdentity {
        self.callable.identity()
    }

    pub fn parameter(&self) -> &TypeKind {
        self.callable.parameter()
    }

    pub fn result(&self) -> &TypeKind {
        self.callable.result()
    }

    pub fn placeholders(&self) -> impl ExactSizeIterator<Item = ExprId> + '_ {
        self.callable
            .parameter_occurrences()
            .iter()
            .map(CheckedImplicitParameterOccurrence::lookup_expression)
    }

    pub fn captures(&self) -> impl ExactSizeIterator<Item = LocalId> + '_ {
        self.callable
            .captures()
            .iter()
            .map(CheckedImplicitCapture::lookup_local)
    }

    pub fn body(&self) -> FinalAnalysisImplicitCallableBody<'_> {
        match self.callable.body() {
            CheckedImplicitCallableBody::Plain(resolution) => {
                FinalAnalysisImplicitCallableBody::Plain(resolution)
            }
            CheckedImplicitCallableBody::Try(tried) => {
                FinalAnalysisImplicitCallableBody::Try(FinalAnalysisTryView { tried })
            }
            CheckedImplicitCallableBody::Pipe(pipe) => {
                FinalAnalysisImplicitCallableBody::Pipe(FinalAnalysisPipeView { pipe })
            }
        }
    }
}

/// Exhaustive execution projection of an implicit callable body.
#[derive(Clone, Copy)]
pub enum FinalAnalysisImplicitCallableBody<'analysis> {
    Plain(&'analysis CheckedExpressionResolution),
    Try(FinalAnalysisTryView<'analysis>),
    Pipe(FinalAnalysisPipeView<'analysis>),
}

/// Typed execution view of one checked Try expression.
#[derive(Clone, Copy)]
pub struct FinalAnalysisTryView<'analysis> {
    tried: &'analysis CheckedTry,
}

impl FinalAnalysisTryView<'_> {
    pub const fn operand(&self) -> ExprId {
        self.tried.operand().lookup_owner()
    }

    pub const fn operand_type(&self) -> &TypeKind {
        self.tried.operand().value_type()
    }

    pub const fn carrier(&self) -> &CheckedTryCarrier {
        self.tried.carrier()
    }

    pub const fn boundary(&self) -> &CheckedTryBoundary {
        self.tried.boundary()
    }
}

/// Typed execution view of one checked once-only pipe.
#[derive(Clone, Copy)]
pub struct FinalAnalysisPipeView<'analysis> {
    pipe: &'analysis CheckedPipe,
}

impl FinalAnalysisPipeView<'_> {
    pub const fn binding_identity(&self) -> CheckedPipeBindingIdentity {
        self.pipe.binding_identity()
    }

    pub const fn left(&self) -> ExprId {
        self.pipe.lookup_left()
    }

    pub const fn right(&self) -> ExprId {
        self.pipe.lookup_right()
    }

    pub fn placeholders(&self) -> impl ExactSizeIterator<Item = ExprId> + '_ {
        self.pipe
            .occurrences()
            .iter()
            .map(CheckedPipeLeftOccurrence::lookup_expression)
    }
}

/// Complete, unpublished semantic generation awaiting the consuming Entry and
/// runtime-nominal seal. This owner is deliberately non-Clone.
pub(crate) struct FinalSemanticAnalysisDraft {
    pub(super) checked_callables: Arc<CheckedCallableCatalog>,
    pub(super) accepted_roots: Arc<AcceptedSemanticRootCatalog>,
    pub(super) types: BTreeMap<TypeId, TypeKind>,
    pub(super) type_resolutions: BTreeMap<TypeId, TypeResolutionReport>,
    pub(super) locals: BTreeMap<LocalId, CheckedBinding>,
    pub(super) captures: BTreeMap<CaptureId, CheckedBinding>,
    pub(super) expressions: BTreeMap<ExprId, super::PreparedExpressionFact>,
    pub(super) patterns: BTreeMap<PatternId, super::PreparedPatternFact>,
    pub(super) statements: BTreeMap<StmtId, super::PreparedStatementPayload>,
    pub(super) items: BTreeMap<ItemId, CheckedItem>,
    pub(super) calls: BTreeMap<ExprId, CallTargetFacts>,
    pub(super) callable_joins: super::match_edges::PreparedCallableJoins,
    pub(super) selected_expressions: super::match_edges::CheckedSelectedExpressionGraph,
    pub(super) structural_edges: super::match_edges::CheckedStructuralEdgeDraft,
    pub(super) ingress: super::PreparedExecutableIngressSeal,
    pub(super) text_proxies: crate::checked_text_proxy::PreparedCheckedTextProxyCatalog,
    pub(super) fx_definitions: super::CheckedFxDefinitionCatalog,
    pub(super) physical_candidate_argument_evaluations:
        BTreeMap<ExprId, Arc<[PhysicalCandidateArgumentEvaluation]>>,
    pub(super) executable_suspensions:
        super::execution_regions::PreparedExecutableSuspensionCatalog,
}

/// Disjoint moved draft state used while the nominal context borrows only the
/// accepted type map.
pub(crate) struct FinalSemanticAnalysisDraftParts {
    pub(super) checked_callables: Arc<CheckedCallableCatalog>,
    pub(super) accepted_roots: Arc<AcceptedSemanticRootCatalog>,
    pub(super) types: BTreeMap<TypeId, TypeKind>,
    pub(super) type_resolutions: BTreeMap<TypeId, TypeResolutionReport>,
    pub(super) locals: BTreeMap<LocalId, CheckedBinding>,
    pub(super) captures: BTreeMap<CaptureId, CheckedBinding>,
    pub(super) expressions: BTreeMap<ExprId, super::PreparedExpressionFact>,
    pub(super) patterns: BTreeMap<PatternId, super::PreparedPatternFact>,
    pub(super) statements: BTreeMap<StmtId, super::PreparedStatementPayload>,
    pub(super) items: BTreeMap<ItemId, CheckedItem>,
    pub(super) calls: BTreeMap<ExprId, CallTargetFacts>,
    pub(super) callable_joins: super::match_edges::PreparedCallableJoins,
    pub(super) selected_expressions: super::match_edges::CheckedSelectedExpressionGraph,
    pub(super) structural_edges: super::match_edges::CheckedStructuralEdgeDraft,
    pub(super) ingress: super::PreparedExecutableIngressSeal,
    pub(super) text_proxies: crate::checked_text_proxy::PreparedCheckedTextProxyCatalog,
    pub(super) fx_definitions: super::CheckedFxDefinitionCatalog,
    pub(super) physical_candidate_argument_evaluations:
        BTreeMap<ExprId, Arc<[PhysicalCandidateArgumentEvaluation]>>,
    pub(super) executable_suspensions:
        super::execution_regions::PreparedExecutableSuspensionCatalog,
}

impl FinalSemanticAnalysisDraft {
    pub(crate) fn into_parts(self) -> FinalSemanticAnalysisDraftParts {
        let Self {
            checked_callables,
            accepted_roots,
            types,
            type_resolutions,
            locals,
            captures,
            expressions,
            patterns,
            statements,
            items,
            calls,
            callable_joins,
            selected_expressions,
            structural_edges,
            ingress,
            text_proxies,
            fx_definitions,
            physical_candidate_argument_evaluations,
            executable_suspensions,
        } = self;
        FinalSemanticAnalysisDraftParts {
            checked_callables,
            accepted_roots,
            types,
            type_resolutions,
            locals,
            captures,
            expressions,
            patterns,
            statements,
            items,
            calls,
            callable_joins,
            selected_expressions,
            structural_edges,
            ingress,
            text_proxies,
            fx_definitions,
            physical_candidate_argument_evaluations,
            executable_suspensions,
        }
    }
}

/// Post-Entry unpublished state. The full executable ingress worklist has
/// already been split and consumed; only the affine statement half remains.
pub(crate) struct FinalSemanticAnalysisPostEntryDraft {
    pub(super) checked_callables: Arc<CheckedCallableCatalog>,
    pub(super) accepted_roots: Arc<AcceptedSemanticRootCatalog>,
    pub(super) types: BTreeMap<TypeId, TypeKind>,
    pub(super) type_resolutions: BTreeMap<TypeId, TypeResolutionReport>,
    pub(super) locals: BTreeMap<LocalId, CheckedBinding>,
    pub(super) captures: BTreeMap<CaptureId, CheckedBinding>,
    pub(super) expressions: BTreeMap<ExprId, super::PreparedExpressionFact>,
    pub(super) patterns: BTreeMap<PatternId, super::PreparedPatternFact>,
    pub(super) statements: BTreeMap<StmtId, super::PreparedStatementPayload>,
    pub(super) items: BTreeMap<ItemId, CheckedItem>,
    pub(super) calls: BTreeMap<ExprId, CallTargetFacts>,
    pub(super) callable_joins: super::match_edges::PreparedCallableJoins,
    pub(super) selected_expressions: super::match_edges::CheckedSelectedExpressionGraph,
    pub(super) structural_edges: super::match_edges::CheckedStructuralEdgeDraft,
    pub(super) statement_ingress: super::PreparedStatementIngressSeal,
    pub(super) text_proxies: crate::checked_text_proxy::PreparedCheckedTextProxyCatalog,
    pub(super) fx_definitions: super::CheckedFxDefinitionCatalog,
    pub(super) physical_candidate_argument_evaluations:
        BTreeMap<ExprId, Arc<[PhysicalCandidateArgumentEvaluation]>>,
    pub(super) executable_suspensions:
        super::execution_regions::PreparedExecutableSuspensionCatalog,
}

impl FinalSemanticAnalysisDraftParts {
    pub(crate) fn into_post_entry(
        self,
    ) -> (
        super::PreparedEntryIngressSeal,
        FinalSemanticAnalysisPostEntryDraft,
    ) {
        let FinalSemanticAnalysisDraftParts {
            checked_callables,
            accepted_roots,
            types,
            type_resolutions,
            locals,
            captures,
            expressions,
            patterns,
            statements,
            items,
            calls,
            callable_joins,
            selected_expressions,
            structural_edges,
            ingress,
            text_proxies,
            fx_definitions,
            physical_candidate_argument_evaluations,
            executable_suspensions,
        } = self;
        let (entry_ingress, statement_ingress) = ingress.into_phase_seals();
        (
            entry_ingress,
            FinalSemanticAnalysisPostEntryDraft {
                checked_callables,
                accepted_roots,
                types,
                type_resolutions,
                locals,
                captures,
                expressions,
                patterns,
                statements,
                items,
                calls,
                callable_joins,
                selected_expressions,
                structural_edges,
                statement_ingress,
                text_proxies,
                fx_definitions,
                physical_candidate_argument_evaluations,
                executable_suspensions,
            },
        )
    }
}

impl FinalSemanticAnalysisPostEntryDraft {
    pub(super) fn seal(
        self,
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
        checked_entries: CheckedEntryCatalog,
        project_nominals: ProjectNominalSemanticCatalog,
        semantic_shapes: AcceptedSemanticShapeCatalog,
        runtime_nominals: RuntimeNominalProjectionCatalog,
        authority: FinalSemanticAnalysisAuthority,
        control: FinalSemanticAnalysisControl<'_>,
    ) -> Result<FinalSemanticAnalysis, FinalSemanticAnalysisError> {
        let Self {
            checked_callables,
            accepted_roots,
            types,
            type_resolutions,
            locals,
            captures,
            expressions: prepared_expressions,
            patterns: prepared_patterns,
            statements: prepared_statements,
            items,
            calls,
            callable_joins,
            selected_expressions,
            structural_edges,
            statement_ingress,
            text_proxies,
            fx_definitions,
            physical_candidate_argument_evaluations,
            executable_suspensions,
        } = self;
        control.check()?;
        let expressions = collect_sealed_expressions(prepared_expressions)?;
        fx_definitions
            .validate_applications(&expressions)
            .map_err(|_| FinalSemanticAnalysisError::WrongPayloadFamily)?;
        let checked_fx_definitions = fx_definitions;
        let patterns = collect_sealed_patterns(prepared_patterns)?;
        let evaluation_topology = Arc::clone(accepted_roots.topology());
        let modules = project_generation_modules(project);
        let dialogue_lines = selected_expressions.dialogue_lines().clone();
        let completed = {
            let coordinates = crate::semantic_coordinate::SemanticCoordinateIndex::new(
                accepted_roots.as_ref(),
                &structural_edges,
            );
            let payloads = super::statement_seal::CheckedStatementSeal::new(
                prepared_statements,
                statement_ingress,
                &locals,
                checked_callables.as_ref(),
                &calls,
                &coordinates,
                &structural_edges,
                project,
                &expressions,
                &modules,
            )?;
            super::statement_effects::seal_statement_effects(
                super::statement_effects::StatementEffectSealInput {
                    modules: &modules,
                    topology: evaluation_topology.as_ref(),
                    selected: &selected_expressions,
                    calls: &calls,
                    callables: checked_callables.as_ref(),
                    expressions,
                    payloads,
                    control,
                },
            )?
        };
        let (expressions, statements) = completed.into_parts();
        for expression in expressions.values() {
            if let super::CheckedExpressionResolution::ImplicitCallable(callable) =
                expression.resolution()
            {
                callable
                    .validate_execution_uses(
                        &expressions,
                        &crate::semantic_coordinate::SemanticCoordinateIndex::new(
                            &accepted_roots,
                            &structural_edges,
                        ),
                        |owner| structural_edges.record_fields(owner).ok(),
                        |local| locals.get(&local).map(|binding| binding.ty().clone()),
                    )
                    .map_err(|violation| FinalSemanticAnalysisError::CaptureAuthority {
                        violation,
                    })?;
            }
        }
        validate_checked_entry_references(&expressions, &checked_entries)?;

        let type_owners =
            accepted_type_owners(&modules, &expressions, &calls, &selected_expressions)?;
        let type_resolution_nodes =
            validate_type_resolution_reports(&type_owners, &types, &type_resolutions)?;
        control.check()?;

        let inventory = SemanticFactInventory {
            types: &types,
            locals: &locals,
            captures: &captures,
            expressions: &expressions,
            patterns: &patterns,
            statements: &statements,
            items: &items,
            calls: &calls,
        };
        validate_complete_inventory(
            evaluation_topology.as_ref(),
            &modules,
            &selected_expressions,
            &type_owners,
            inventory,
            &type_resolutions,
        )?;
        for expression in expressions.values() {
            if let super::CheckedExpressionResolution::Closure(closure) = expression.resolution() {
                closure.validate_selection(&selected_expressions)?;
            }
        }
        control.check()?;
        validate_types(&modules, &types)?;
        control.check()?;
        validate_bindings(&modules, &locals, &captures)?;
        control.check()?;
        let coordinates = crate::semantic_coordinate::SemanticCoordinateIndex::new(
            accepted_roots.as_ref(),
            &structural_edges,
        );
        validate_expressions(
            symbols,
            &checked_callables,
            &semantic_shapes,
            &evaluation_topology,
            &modules,
            &dialogue_lines,
            &locals,
            &expressions,
            &calls,
            &structural_edges,
            &coordinates,
        )?;
        control.check()?;
        validate_patterns(
            symbols,
            evaluation_topology.generation(),
            &modules,
            &types,
            &patterns,
        )?;
        control.check()?;
        validate_statements(&modules, &locals, &expressions, &statements)?;
        for module in modules.values() {
            for (owner, statement) in module.statements() {
                if let arcweft_lang_hir::stmt::HirStmtKind::Let {
                    storage: arcweft_lang_hir::stmt::HirBindingStorage::RetainedState,
                    locals,
                    ..
                } = statement.kind()
                {
                    if locals.is_empty() {
                        return Err(FinalSemanticAnalysisError::EmptyRetainedState { owner });
                    }
                    for local in locals {
                        coordinates
                            .retained_state_field_identity(module, *local)
                            .map_err(|_| FinalSemanticAnalysisError::InvalidRetainedState {
                                owner: *local,
                            })?;
                    }
                }
            }
        }
        control.check()?;
        validate_items(&modules, &items)?;
        control.check()?;
        validate_calls(symbols, &modules, &expressions, &calls)?;
        validate_physical_candidate_argument_evaluations(
            &modules,
            &physical_candidate_argument_evaluations,
        )?;
        let work = collect_work(inventory)?;
        let (checked_text_proxies, text_proxy_diagnostics) = text_proxies
            .seal(crate::checked_text_proxy::TextProxyFinalSealAuthority {
                project,
                symbols,
                project_nominals: &project_nominals,
                types: &types,
                type_resolutions: &type_resolutions,
                expressions: &expressions,
                control,
            })?
            .into_parts();
        let mut diagnostics = collect_final_diagnostics(&modules, &types, &expressions, &items)?;
        diagnostics.extend(text_proxy_diagnostics);
        let (edge_facts, unconsumed_callable_joins) =
            structural_edges.into_final_facts(&modules, &calls, callable_joins);
        if !unconsumed_callable_joins.is_empty() {
            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
        }
        control.check()?;
        let expression_execution_regions = executable_suspensions.publish(
            &expressions,
            &statements,
            &evaluation_topology,
            &selected_expressions,
        )?;
        let selected_call_inventories = selected_expressions.into_selected_call_inventories();
        let mut analysis = FinalSemanticAnalysis {
            authority,
            checked_callables,
            accepted_roots,
            checked_entries,
            project_nominals,
            checked_text_proxies,
            checked_fx_definitions,
            display_conformances: Default::default(),
            local_uses: Arc::new(super::CheckedLocalUseCatalog::empty(Arc::clone(
                evaluation_topology.generation(),
            ))),
            semantic_shapes,
            runtime_nominals,
            dialogue_lines,
            types,
            type_resolutions,
            type_resolution_nodes,
            locals,
            captures,
            expressions,
            patterns,
            statements,
            items,
            calls,
            selected_call_inventories,
            expression_execution_regions,
            edge_facts,
            diagnostics: diagnostics.into(),
            #[cfg(test)]
            physical_candidate_argument_evaluations,
            work,
        };
        seal_checked_callable_interfaces(&mut analysis, project, symbols, control)?;
        analysis.local_uses = Arc::new(super::CheckedLocalUseCatalog::seal(&analysis, project)?);
        Ok(analysis)
    }
}

fn seal_checked_callable_interfaces(
    analysis: &mut FinalSemanticAnalysis,
    project: HirAnalysisProjectView<'_>,
    symbols: &ProjectSymbolTable,
    control: FinalSemanticAnalysisControl<'_>,
) -> Result<(), FinalSemanticAnalysisError> {
    use crate::{
        callable::{
            CallableAttachedContentExecution, CallableAttachedContentPolicy, CallableCandidateId,
            CallableParameterPresence, CheckedCallableAttachedContentParameter,
            CheckedDeclarationDefault,
        },
        effect_row::EffectRow,
        semantic_coordinate::{SemanticCoordinateIndex, StableCheckedValueCoordinate},
    };
    use arcweft_lang_hir::item::{HirAttachedContentPresence, HirAttachedContentRole};

    let coordinates = SemanticCoordinateIndex::new(analysis.accepted_root_catalog(), analysis);
    let mut rows = BTreeMap::new();
    let mut parameter_defaults = BTreeMap::new();
    for facts in analysis.checked_callables().records() {
        control.check()?;
        let id = facts.id().clone();
        let defaults = checked_view_parameter_defaults(
            analysis,
            project,
            symbols,
            facts,
            &coordinates,
            control,
        )?;
        if parameter_defaults.insert(id.clone(), defaults).is_some() {
            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
        }
        let row = match (facts.record().id(), facts.signature().attached_content()) {
            (CallableCandidateId::Project(declaration), Some(parameter))
                if parameter.execution() == CallableAttachedContentExecution::RuntimeContent =>
            {
                let symbol = symbols
                    .callable(declaration)
                    .ok_or(FinalSemanticAnalysisError::InvalidCallableOwner)?;
                let module = project
                    .modules()
                    .find_map(|(_, module)| {
                        (module.module_id() == symbol.source_item().module())
                            .then_some(module.as_ref())
                    })
                    .ok_or(FinalSemanticAnalysisError::InvalidOwner)?;
                let hir = crate::callable::project_callable_attached_content(module, symbol)
                    .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)?
                    .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?;
                let CallableAttachedContentPolicy::Declared(admission) = parameter.policy() else {
                    return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
                };
                let hir_admission = match hir.role() {
                    HirAttachedContentRole::Inline => crate::callable::CheckedContentRole::Inline,
                    HirAttachedContentRole::Rich => crate::callable::CheckedContentRole::Rich,
                    HirAttachedContentRole::Dialogue => {
                        crate::callable::CheckedContentRole::Dialogue
                    }
                };
                let hir_presence = match hir.presence() {
                    HirAttachedContentPresence::Required => CallableParameterPresence::Required,
                    HirAttachedContentPresence::Optional => CallableParameterPresence::Optional,
                    HirAttachedContentPresence::Defaulted { .. } => {
                        CallableParameterPresence::Defaulted
                    }
                };
                if hir_admission != admission || hir_presence != parameter.presence() {
                    return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
                }
                let result = facts
                    .signature()
                    .value_type()
                    .cloned()
                    .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?;
                let binding_type = match parameter.presence() {
                    CallableParameterPresence::Optional => {
                        TypeKind::Option(Box::new(result.clone()))
                    }
                    CallableParameterPresence::Required | CallableParameterPresence::Defaulted => {
                        result.clone()
                    }
                };
                let abi_type = match parameter.presence() {
                    CallableParameterPresence::Required => result.clone(),
                    CallableParameterPresence::Optional | CallableParameterPresence::Defaulted => {
                        TypeKind::Option(Box::new(result.clone()))
                    }
                };
                let binding = analysis.local(hir.binding()).ok_or(
                    FinalSemanticAnalysisError::LocalTypeUnavailable {
                        owner: hir.binding(),
                    },
                )?;
                if binding.ty() != &binding_type {
                    return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
                }
                let binding_coordinate = coordinates
                    .binding(hir.binding())
                    .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)?;
                let abi_position = u32::try_from(
                    facts
                        .signature()
                        .group(parameter.group())
                        .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?
                        .parameters()
                        .len(),
                )
                .map_err(|_| FinalSemanticAnalysisError::AccountingOverflow)?;
                let default = match hir.presence() {
                    HirAttachedContentPresence::Defaulted { value } => {
                        let checked = analysis.expression(value).ok_or(
                            FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: value },
                        )?;
                        if checked.value_type() != Some(&result) {
                            return Err(FinalSemanticAnalysisError::ExpressionTypeUnavailable {
                                owner: value,
                            });
                        }
                        let coordinate = StableCheckedValueCoordinate::Expression(
                            coordinates
                                .expression(value)
                                .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)?,
                        );
                        let expression = super::semantic_transcript::checked_declaration_default_expression_digest(
                            analysis,
                            project,
                            value,
                            control,
                        )
                        .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)?;
                        let execution = analysis
                            .expression_execution_region(value)
                            .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?;
                        let captures = checked_declaration_default_captures(
                            analysis,
                            module,
                            symbol,
                            value,
                            &execution,
                            &coordinates,
                            control,
                        )?;
                        Some(CheckedDeclarationDefault::new(
                            value,
                            coordinate,
                            (
                                result.semantic_identity_digest()?,
                                result.semantic_identity_digest()?,
                                result.clone(),
                            ),
                            EffectRow::closed(checked.effects().clone()),
                            execution.suspension(),
                            execution.control(),
                            expression,
                            captures,
                        ))
                    }
                    HirAttachedContentPresence::Required | HirAttachedContentPresence::Optional => {
                        None
                    }
                };
                Some(CheckedCallableAttachedContentParameter::new(
                    parameter.group(),
                    hir.binding(),
                    binding_coordinate,
                    admission,
                    parameter.presence(),
                    abi_position,
                    binding_type,
                    abi_type,
                    default,
                ))
            }
            (_, Some(parameter))
                if parameter.execution() == CallableAttachedContentExecution::RuntimeContent =>
            {
                return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
            }
            _ => None,
        };
        if rows.insert(id, row).is_some() {
            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
        }
    }
    let catalog = Arc::get_mut(&mut analysis.checked_callables)
        .ok_or(FinalSemanticAnalysisError::CheckedCallableCatalog)?;
    catalog
        .seal_interfaces(rows, parameter_defaults)
        .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)
}

fn validate_checked_entry_references(
    expressions: &BTreeMap<ExprId, CheckedExpression>,
    entries: &CheckedEntryCatalog,
) -> Result<(), FinalSemanticAnalysisError> {
    for (owner, expression) in expressions {
        let super::CheckedExpressionResolution::Value(super::CheckedValueResolution::Entry(
            reference,
        )) = expression.resolution()
        else {
            continue;
        };
        let binding = entries
            .get_public(reference.diagnostic_public_id())
            .ok_or(FinalSemanticAnalysisError::InvalidOwner)?;
        let checked_type = expression
            .value_type()
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: *owner })?;
        if binding.source_item() != reference.lookup_owner()
            || binding.binding_digest() != reference.binding()
            || checked_type.semantic_identity_digest()? != reference.value_type()
            || checked_type != &TypeKind::entity_ref(crate::types::EntityKind::Entry)
        {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
    }
    Ok(())
}

impl FinalSemanticAnalysis {
    /// Emission role of the invoked callable body, distinct from evaluating
    /// the expression that creates its value. Issued by the shared execution DAG.
    pub fn callable_body_control(
        &self,
        owner: ExprId,
    ) -> Option<super::CheckedExecutableControlRole> {
        self.expression_execution_regions
            .body_row(owner)
            .map(|row| row.control())
    }
    /// Selected expression membership from this report's accepted execution DAG.
    pub fn expression_execution_region(
        &self,
        owner: ExprId,
    ) -> Option<super::execution_regions::CheckedExecutionRegion> {
        self.expression_execution_regions
            .region(super::CheckedExecutionOperation::Value(owner))
    }

    pub(super) fn match_selection_execution_region(
        &self,
        matched: arcweft_lang_hir::project::HirMatchView<'_>,
    ) -> Option<super::execution_regions::CheckedExecutionRegion> {
        self.expression_execution_regions.region_roots(
            std::iter::once(matched.scrutinee())
                .chain(matched.arms().filter_map(|arm| arm.guard()))
                .map(super::CheckedExecutionOperation::Value),
        )
    }

    /// Selected statement membership from this report's accepted execution DAG.
    pub fn statement_execution_region(
        &self,
        owner: StmtId,
    ) -> Option<super::execution_regions::CheckedExecutionRegion> {
        self.expression_execution_regions
            .region(super::CheckedExecutionOperation::Statement(owner))
    }

    pub(super) fn iteration_execution_region(
        &self,
        owner: StmtId,
    ) -> Option<super::execution_regions::CheckedExecutionRegion> {
        self.expression_execution_regions
            .region(super::CheckedExecutionOperation::Iteration(owner))
    }

    pub(super) fn body_execution_region(
        &self,
        owner: &super::CheckedExecutionBodyOwner,
    ) -> Option<super::execution_regions::CheckedExecutionRegion> {
        self.expression_execution_regions
            .region(super::CheckedExecutionOperation::Body(Arc::new(
                owner.clone(),
            )))
    }

    pub(super) fn has_execution_body(&self, owner: &super::CheckedExecutionBodyOwner) -> bool {
        self.expression_execution_regions.contains_body(owner)
    }

    pub(super) fn body_execution_effects(
        &self,
        owner: &super::CheckedExecutionBodyOwner,
    ) -> Option<crate::effects::EffectSet> {
        if let super::CheckedExecutionBodyOwner::CallableValue(owner) = owner
            && matches!(
                self.expression(*owner)?.resolution(),
                CheckedExpressionResolution::ImplicitCallable(_)
            )
        {
            let TypeKind::Function { effects, .. } = self.expression(*owner)?.value_type()? else {
                return None;
            };
            return effects.constant_effects().ok();
        }
        self.expression_execution_regions
            .body_effects(owner, &self.expressions, &self.statements)
    }

    /// A plain accepted opaque carrier may be copied only after the exact
    /// supplied runtime binding passes the function-ingress ownership check.
    pub(super) fn accepted_plain_opaque_nominal(
        &self,
        nominal: &crate::types::AcceptedNominalType,
    ) -> bool {
        matches!(self.accepted_nominal_semantics(nominal),
            Some(crate::env::nominal::AcceptedNominalSemantics::Opaque(carrier))
                if carrier.value_class() == arcweft_core::value::RuntimeOpaqueValueClass::Plain)
    }

    /// Exact accepted declaration metadata; consumers do not resolve a type
    /// spelling or manufacture a separate nominal ownership table.
    pub(super) fn accepted_nominal_semantics(
        &self,
        nominal: &crate::types::AcceptedNominalType,
    ) -> Option<&crate::env::nominal::AcceptedNominalSemantics> {
        match &self.authority {
            FinalSemanticAnalysisAuthority::Registered(world) => world
                .environment
                .nominal_catalog()
                .exact(nominal.declaration().canonical_path())
                .filter(|record| {
                    record.id() == nominal.declaration()
                        && usize::from(record.arity()) == nominal.arguments().len()
                })
                .map(crate::env::nominal::AcceptedNominalRecord::semantics),
            #[cfg(test)]
            FinalSemanticAnalysisAuthority::Fixture => None,
        }
    }

    /// Substitutes the original joined Rust declaration under the consumer's
    /// shared allowance. No nominal metadata is reconstructed or copied aside.
    pub(super) fn instantiate_accepted_rust_nominal<C: crate::types::TypeProjectionControl>(
        &self,
        nominal: &crate::types::AcceptedNominalType,
        control: &mut C,
    ) -> Result<
        Option<crate::env::rust_metadata::InstantiatedRustTypeMetadata>,
        crate::env::rust_metadata::RustMetadataInstantiationError<C::Error>,
    > {
        match &self.authority {
            FinalSemanticAnalysisAuthority::Registered(world) => world
                .environment
                .rust_metadata()
                .instantiate_with_control(nominal, control)
                .map(Some),
            #[cfg(test)]
            FinalSemanticAnalysisAuthority::Fixture => Ok(None),
        }
    }

    pub(super) fn character_dialogue_policy_types(
        &self,
    ) -> Option<&arcweft_dialogue::CharacterDialoguePolicyTypeGraph> {
        match &self.authority {
            FinalSemanticAnalysisAuthority::Registered(world) => {
                Some(world.environment.character_dialogue_roles().policy_types())
            }
            #[cfg(test)]
            FinalSemanticAnalysisAuthority::Fixture => None,
        }
    }

    /// Source-site local read and capture-transfer modes sealed for this exact
    /// accepted HIR generation.
    pub const fn checked_local_uses(&self) -> &Arc<super::CheckedLocalUseCatalog> {
        &self.local_uses
    }

    /// Closes one generic function, DisplayText method, and all its nested
    /// executable closure uses under the selected frozen type environment.
    /// The supplied project lease must be the report's exact HIR generation.
    pub fn checked_local_uses_for_instance(
        &self,
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
        instance: super::CheckedLocalUseInstantiation<'_>,
    ) -> Result<super::CheckedLocalUseInstanceCatalog, super::CheckedLocalUseError> {
        super::CheckedLocalUseCatalog::seal_closed_instance(self, project, symbols, instance)
    }

    pub(super) fn with_display_conformances(
        mut self,
        catalog: super::analyzer::display::DisplayConformanceCatalog,
    ) -> Self {
        self.display_conformances = catalog;
        self
    }

    /// Selects one closed formatter witness for an instantiated value type.
    /// Generic source functions call this after their type arguments close;
    /// deferred generic witnesses must never be published to a runtime plan.
    pub fn display_witness_for_fmt_type(
        &self,
        ty: &TypeKind,
    ) -> Result<Option<crate::checked_rich_text::CheckedDisplayWitness>, FinalSemanticAnalysisError>
    {
        self.display_conformances
            .for_fmt_primary(ty, &crate::env::nominal::standard_dialogue_content_type())
    }

    /// Selects one closed direct-interpolation witness for an instantiated type.
    pub fn display_witness_for_interpolation_type(
        &self,
        ty: &TypeKind,
    ) -> Result<Option<crate::checked_rich_text::CheckedDisplayWitness>, FinalSemanticAnalysisError>
    {
        self.display_conformances
            .for_interpolation(ty, &crate::env::nominal::standard_dialogue_content_type())
    }
    pub(super) const fn accepted_types(&self) -> &BTreeMap<TypeId, TypeKind> {
        &self.types
    }

    pub(crate) fn matches_symbol_lease(&self, symbols: &ProjectSymbolTable) -> bool {
        symbols.world() == self.hir_generation().symbol_world()
            && *symbols.revision() == self.hir_generation().symbol_revision()
    }

    pub(crate) fn matches_registered_world(
        &self,
        world: &crate::registration::RegisteredSemanticWorld,
    ) -> bool {
        match &self.authority {
            FinalSemanticAnalysisAuthority::Registered(retained) => {
                std::ptr::eq(retained.symbols(), world.symbols())
                    && std::ptr::eq(retained.environment(), world.environment())
                    && self.matches_symbol_lease(world.symbols())
                    && world.environment().world() == world.symbols().world()
                    && world.environment().symbol_revision() == world.symbols().revision()
            }
            #[cfg(test)]
            FinalSemanticAnalysisAuthority::Fixture => false,
        }
    }

    /// Validates and publishes a complete semantic generation.
    #[cfg(test)]
    pub(crate) fn try_new(
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
        topology: Arc<HirProjectEvaluationTopology>,
        checked_callables: Arc<CheckedCallableCatalog>,
        input: FinalSemanticAnalysisInput,
    ) -> Result<Self, FinalSemanticAnalysisError> {
        let cancellation = AtomicBool::new(false);
        Self::try_new_with_control(
            project,
            symbols,
            topology,
            checked_callables,
            input,
            FinalSemanticAnalysisControl::new(&cancellation),
        )
    }

    /// Validates and publishes a complete semantic generation while observing
    /// caller-owned cancellation at every publication phase boundary.
    #[cfg(test)]
    pub(crate) fn try_new_with_control(
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
        topology: Arc<HirProjectEvaluationTopology>,
        checked_callables: Arc<CheckedCallableCatalog>,
        input: FinalSemanticAnalysisInput,
        control: FinalSemanticAnalysisControl<'_>,
    ) -> Result<Self, FinalSemanticAnalysisError> {
        Self::try_new_with_control_and_type_resolutions(
            project,
            symbols,
            topology,
            checked_callables,
            input,
            BTreeMap::new(),
            control,
        )
    }

    /// Test-only publication keeps a single topology lease without exposing a
    /// constructor that can mint accepted roots in production.
    #[cfg(test)]
    pub(crate) fn try_new_with_control_and_type_resolutions(
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
        topology: Arc<HirProjectEvaluationTopology>,
        checked_callables: Arc<CheckedCallableCatalog>,
        mut input: FinalSemanticAnalysisInput,
        type_resolutions: BTreeMap<TypeId, TypeResolutionReport>,
        control: FinalSemanticAnalysisControl<'_>,
    ) -> Result<Self, FinalSemanticAnalysisError> {
        control.check()?;
        let mut item_facts = BTreeMap::new();
        for (item, fact) in &input.items {
            if item_facts.insert(*item, fact).is_some() {
                return Err(FinalSemanticAnalysisError::DuplicateFact {
                    family: SemanticFactFamily::Item,
                });
            }
        }
        let accepted_roots = Arc::new(AcceptedSemanticRootCatalog::seal(
            Arc::clone(&topology),
            &checked_callables,
            &item_facts,
        )?);
        let modules = project_generation_modules(project);
        let prepared_expressions = collect_unique(
            input.expressions.iter().cloned(),
            SemanticFactFamily::Expression,
        )?;
        let expressions = prepared_expressions;
        let selected_expressions =
            match_edges::CheckedSelectedExpressionGraph::seal_call_free_fixture(
                project,
                Arc::clone(&topology),
                &expressions,
            )?;
        input.set_structural_edges(match_edges::CheckedStructuralEdgeDraft::seal(
            &selected_expressions,
            &modules,
            &expressions,
        ))?;
        input.set_selected_expressions(selected_expressions)?;
        Self::try_new_with_control_and_type_resolutions_and_catalog(
            project,
            symbols,
            checked_callables,
            input,
            type_resolutions,
            accepted_roots,
            AcceptedSemanticShapeCatalog::default(),
            crate::checked_text_proxy::PreparedCheckedTextProxyCatalog::default(),
            super::CheckedFxDefinitionCatalog::default(),
            FinalSemanticAnalysisAuthority::Fixture,
            control,
        )
        .map_err(FinalSemanticProjectError::into_semantic_fixture_error)
    }

    /// Publishes the semantic type products created by the sole production
    /// nominal resolver with the same accepted generation as their flattened
    /// type facts. Manual fact fixtures deliberately use the constructor above
    /// and therefore cannot fabricate nominal-reference evidence.
    pub(super) fn try_new_with_control_and_type_resolutions_and_catalog(
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
        checked_callables: Arc<CheckedCallableCatalog>,
        mut input: FinalSemanticAnalysisInput,
        type_resolutions: BTreeMap<TypeId, TypeResolutionReport>,
        accepted_roots: Arc<AcceptedSemanticRootCatalog>,
        semantic_shapes: AcceptedSemanticShapeCatalog,
        text_proxies: crate::checked_text_proxy::PreparedCheckedTextProxyCatalog,
        fx_definitions: super::CheckedFxDefinitionCatalog,
        authority: FinalSemanticAnalysisAuthority,
        control: FinalSemanticAnalysisControl<'_>,
    ) -> Result<Self, FinalSemanticProjectError> {
        control.check()?;
        let observed = project
            .accept_symbol_generation(symbols)
            .map_err(|_| FinalSemanticAnalysisError::SymbolGenerationMismatch)?;
        if !accepted_roots
            .topology()
            .generation()
            .same_generation(observed.generation().as_ref())
        {
            return Err(FinalSemanticAnalysisError::GenerationMismatch.into());
        }
        let callable_generation = checked_callables
            .hir_generation()
            .ok_or(FinalSemanticAnalysisError::CatalogGenerationMismatch)?;
        if !Arc::ptr_eq(accepted_roots.topology().generation(), callable_generation) {
            return Err(FinalSemanticAnalysisError::CatalogGenerationMismatch.into());
        }
        let evaluation_topology = Arc::clone(accepted_roots.topology());
        let types = collect_unique(input.types, SemanticFactFamily::Type)?;
        let locals = collect_unique(input.locals, SemanticFactFamily::Local)?;
        control.check()?;
        let captures = collect_unique(input.captures, SemanticFactFamily::Capture)?;
        control.check()?;
        let prepared_expressions =
            collect_unique(input.expressions, SemanticFactFamily::Expression)?;
        let selected_expressions = input
            .selected_expressions
            .take()
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        if !Arc::ptr_eq(selected_expressions.topology(), &evaluation_topology) {
            return Err(FinalSemanticAnalysisError::GenerationMismatch.into());
        }
        let structural_edges = input
            .structural_edges
            .take()
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        let ingress = input
            .ingress_seal
            .take()
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        control.check()?;
        let prepared_patterns = collect_unique(input.patterns, SemanticFactFamily::Pattern)?;
        control.check()?;
        let statements = collect_unique(input.statements, SemanticFactFamily::Statement)?;
        control.check()?;
        let items = collect_unique(input.items, SemanticFactFamily::Item)?;
        control.check()?;
        let calls = collect_unique(
            input
                .calls
                .into_iter()
                .map(|call| (call.expression(), call)),
            SemanticFactFamily::Call,
        )?;
        let callable_joins = input.callable_joins;
        match_edges::validate_callable_join_inventory(&calls, &callable_joins)
            .map_err(|error| FinalSemanticAnalysisError::CheckedCallableJoin(Box::new(error)))?;
        let physical_candidate_argument_evaluations = input.physical_candidate_argument_evaluations;
        control.check()?;
        let draft = FinalSemanticAnalysisDraft {
            checked_callables,
            accepted_roots,
            types,
            type_resolutions,
            locals,
            captures,
            expressions: prepared_expressions,
            patterns: prepared_patterns,
            statements,
            items,
            calls,
            callable_joins,
            selected_expressions,
            structural_edges,
            ingress,
            text_proxies,
            fx_definitions,
            physical_candidate_argument_evaluations,
            executable_suspensions: input.executable_suspensions,
        };
        super::nominal_schema::seal_nominal_draft(
            draft,
            project,
            symbols,
            semantic_shapes,
            authority,
            control,
        )
    }

    /// Rejects reuse with any missing, foreign, or stale module generation.
    pub fn validate_generation(
        &self,
        project: HirAnalysisProjectView<'_>,
        symbols: &ProjectSymbolTable,
    ) -> Result<(), FinalSemanticAnalysisError> {
        let observed = project
            .accept_symbol_generation(symbols)
            .map_err(|_| FinalSemanticAnalysisError::SymbolGenerationMismatch)?;
        self.hir_generation()
            .same_generation(observed.generation().as_ref())
            .then_some(())
            .ok_or(FinalSemanticAnalysisError::GenerationMismatch)
    }

    /// Validates one module-scoped query against this report's exact accepted
    /// snapshot and symbol generation. This does not publish or reconstruct a
    /// partial analysis; it is only a lease check for consumers that already
    /// hold the immutable project report.
    pub fn validate_module_generation(
        &self,
        module: &HirModule,
        symbols: &ProjectSymbolTable,
    ) -> Result<(), FinalSemanticAnalysisError> {
        self.hir_generation()
            .validate_module_lease(module, symbols)
            .map_err(|_| FinalSemanticAnalysisError::GenerationMismatch)
    }

    pub fn hir_generation(&self) -> &Arc<arcweft_lang_hir::project::AcceptedHirProjectGeneration> {
        self.accepted_roots.topology().generation()
    }

    pub fn validate_registered_callable_authority(
        &self,
        registered: &crate::callable::RegisteredCallableCatalog,
    ) -> Result<(), crate::callable::CheckedCallableLookupError> {
        self.checked_callables
            .validate_registered_authority(registered, self.hir_generation().as_ref())
    }

    pub fn hir_topology(&self) -> &Arc<HirProjectEvaluationTopology> {
        self.accepted_roots.topology()
    }

    /// Stable named field identity within the accepted retained lexical scope.
    /// Initializer, field type, and declaration instruction position are excluded.
    pub fn retained_state_field_identity(
        &self,
        module: &HirModule,
        local: arcweft_lang_hir::identity::LocalId,
    ) -> Result<[u8; 32], FinalSemanticAnalysisError> {
        crate::semantic_coordinate::SemanticCoordinateIndex::new(self.accepted_root_catalog(), self)
            .retained_state_field_identity(module, local)
            .map_err(|_| FinalSemanticAnalysisError::InvalidRetainedState { owner: local })
    }

    /// Dialogue-line identities accepted from this generation's selected HIR
    /// expression graph. The HIR project itself retains only provisional
    /// source-site evidence.
    pub const fn dialogue_lines(
        &self,
    ) -> &arcweft_lang_hir::project::AcceptedDialogueLineInventory {
        &self.dialogue_lines
    }

    /// Sole checked Entry catalog accepted by this semantic generation.
    pub const fn checked_entries(&self) -> &CheckedEntryCatalog {
        &self.checked_entries
    }

    /// Sole typed text-proxy catalog accepted by this semantic generation.
    pub const fn checked_text_proxies(
        &self,
    ) -> &crate::checked_text_proxy::CheckedTextProxyCatalog {
        &self.checked_text_proxies
    }

    /// Sole checked Fx definition catalog accepted by this semantic generation.
    pub const fn checked_fx_definitions(&self) -> &super::CheckedFxDefinitionCatalog {
        &self.checked_fx_definitions
    }

    pub(crate) const fn runtime_nominals(&self) -> &RuntimeNominalProjectionCatalog {
        &self.runtime_nominals
    }

    pub(crate) const fn project_nominals(&self) -> &ProjectNominalSemanticCatalog {
        &self.project_nominals
    }

    /// Layout-free accepted semantics for one exact project nominal type.
    pub(crate) fn project_nominal_semantic(
        &self,
        semantic_type: crate::types::SemanticTypeDigest,
    ) -> Option<&ProjectNominalSemanticDefinition> {
        self.project_nominals.get(semantic_type)
    }

    /// Complete layout-free checked variant owner for one project semantic type.
    pub fn project_variant_owner(
        &self,
        semantic_type: crate::types::SemanticTypeDigest,
    ) -> Result<Option<super::CheckedVariantOwner>, super::CheckedVariantOwnerError> {
        let Some(definition) = self.project_nominals.get(semantic_type) else {
            return Ok(None);
        };
        let Some(cases) = definition.cases() else {
            return Ok(None);
        };
        super::CheckedVariantOwner::try_project_shapes(
            definition.nominal().clone(),
            cases.iter().map(|case| {
                (
                    case.payload().clone(),
                    Some(case.diagnostic_name().to_owned()),
                )
            }),
        )
        .map(Some)
    }

    /// Exact checked closed-enum owner retained by this accepted generation.
    ///
    /// Runtime projection uses this for source-owned environment enums whose
    /// ordered case inventory is part of their nominal ABI. The returned owner
    /// is borrowed from the accepted semantic-shape catalog; callers cannot
    /// reconstruct or extend its cases.
    pub fn accepted_closed_variant_owner(
        &self,
        semantic_type: crate::types::SemanticTypeDigest,
    ) -> Option<&super::CheckedVariantOwner> {
        self.semantic_shapes().closed_variant(semantic_type)
    }

    pub(crate) const fn semantic_shapes(&self) -> &AcceptedSemanticShapeCatalog {
        &self.semantic_shapes
    }

    pub fn ty(&self, owner: TypeId) -> Option<&TypeKind> {
        self.types.get(&owner)
    }

    /// Complete nominal-resolution product for one exact final-HIR type root.
    ///
    /// Production reports contain one row for every structural type root.
    /// Hand-built test fixtures intentionally return `None` instead of
    /// inventing source or alias evidence.
    pub fn type_resolution(&self, owner: TypeId) -> Option<&TypeResolutionReport> {
        self.type_resolutions.get(&owner)
    }

    /// Borrows the exact source-owned node, excluding alias-use substitutions.
    /// The index is issued once while sealing the complete resolution inventory.
    pub fn type_resolution_node(&self, owner: TypeId) -> Option<&crate::nominal::ResolvedTypeNode> {
        let location = self.type_resolution_nodes.get(&owner)?;
        self.type_resolutions
            .get(&location.root)?
            .outcome()
            .product()
            .nodes()
            .get(location.node)
    }

    pub fn type_resolutions(
        &self,
    ) -> impl ExactSizeIterator<Item = (TypeId, &TypeResolutionReport)> {
        self.type_resolutions
            .iter()
            .map(|(owner, report)| (*owner, report))
    }

    pub fn local(&self, owner: LocalId) -> Option<&CheckedBinding> {
        self.locals.get(&owner)
    }

    /// Issues the accepted lexical binding origin without exposing the private index.
    pub fn local_binding_origin(
        &self,
        owner: LocalId,
    ) -> Result<
        crate::semantic_coordinate::CheckedLocalBindingOrigin,
        crate::semantic_coordinate::CheckedLocalBindingOriginError,
    > {
        crate::semantic_coordinate::SemanticCoordinateIndex::new(self.accepted_root_catalog(), self)
            .binding(owner)
            .map_err(
                |_| crate::semantic_coordinate::CheckedLocalBindingOriginError { local: owner },
            )
            .and_then(|coordinate| {
                crate::semantic_coordinate::CheckedLocalBindingOrigin::try_new(
                    owner,
                    Arc::clone(self.hir_topology()),
                    coordinate,
                )
            })
    }

    pub fn capture(&self, owner: CaptureId) -> Option<&CheckedBinding> {
        self.captures.get(&owner)
    }

    /// Selected capture identity, source local, and access from its closed
    /// producer. Type facts and this projection belong to the same generation.
    pub fn selected_capture(
        &self,
        owner: CaptureId,
    ) -> Option<&arcweft_lang_hir::project::HirSelectedCapture> {
        self.capture(owner)?;
        let row = self
            .accepted_root_catalog()
            .topology()
            .module(owner.module())?
            .captures()
            .capture(owner)?;
        let super::CheckedExpressionResolution::Closure(closure) =
            self.expression(row.closure())?.resolution()
        else {
            return None;
        };
        closure
            .captures()
            .iter()
            .find(|capture| capture.capture() == owner)
    }

    pub fn expression(&self, owner: ExprId) -> Option<&CheckedExpression> {
        self.expressions.get(&owner)
    }

    /// Local receiver observed by an admitted, synchronous field projection.
    /// This follows checked fields, including environment records, without
    /// granting Copy or a mutable runtime place to the receiver.
    pub fn local_inspection_root(&self, owner: ExprId) -> Option<LocalId> {
        self.expression(owner)?.inspection_root(|child| {
            self.expression(child)
                .and_then(CheckedExpression::local_place_source)
        })
    }

    pub fn expression_origin(
        &self,
        owner: ExprId,
    ) -> Result<
        crate::semantic_coordinate::CheckedExpressionOrigin,
        crate::semantic_coordinate::CheckedExpressionOriginError,
    > {
        crate::semantic_coordinate::SemanticCoordinateIndex::new(self.accepted_root_catalog(), self)
            .expression(owner)
            .map(|coordinate| {
                crate::semantic_coordinate::CheckedExpressionOrigin::new(
                    owner,
                    Arc::clone(self.hir_topology()),
                    coordinate,
                )
            })
            .map_err(
                |_| crate::semantic_coordinate::CheckedExpressionOriginError { expression: owner },
            )
    }

    pub fn statement_origin(
        &self,
        owner: StmtId,
    ) -> Result<
        crate::semantic_coordinate::CheckedStatementOrigin,
        crate::semantic_coordinate::CheckedStatementOriginError,
    > {
        crate::semantic_coordinate::SemanticCoordinateIndex::new(self.accepted_root_catalog(), self)
            .statement_origin(owner)
            .map_err(
                |_| crate::semantic_coordinate::CheckedStatementOriginError { statement: owner },
            )
    }

    /// Borrows fallible execution projections from this semantic generation.
    /// Tooling-only outcomes remain queryable in the report but cannot yield
    /// an executable plan through this view.
    pub const fn execution_projection(&self) -> FinalAnalysisExecutionProjection<'_> {
        FinalAnalysisExecutionProjection { analysis: self }
    }

    pub fn pattern(&self, owner: PatternId) -> Option<&CheckedPattern> {
        self.patterns.get(&owner)
    }

    pub fn statement(&self, owner: StmtId) -> Option<&CheckedStatement> {
        self.statements.get(&owner)
    }

    pub fn item(&self, owner: ItemId) -> Option<&CheckedItem> {
        self.items.get(&owner)
    }

    pub fn call(&self, owner: ExprId) -> Option<&CallTargetFacts> {
        self.calls.get(&owner)
    }

    /// Returns the exact mapper-sealed HIR child inventory accepted for one
    /// ordinary Call. Runtime reachability consumes this authority so it can
    /// preserve reference-only semantic metadata arguments without guessing
    /// ownership from source or raw HIR shape.
    pub fn selected_call_expression_inventory(
        &self,
        owner: ExprId,
    ) -> Option<&HirSelectedCallExpressionInventory> {
        self.selected_call_inventories.get(&owner)
    }

    /// Sole immutable checked callable/effect authority accepted with this
    /// semantic generation.
    pub const fn checked_callables(&self) -> &Arc<CheckedCallableCatalog> {
        &self.checked_callables
    }

    /// Source-independent identity from this report's sealed declaration-root
    /// catalog. This is definition metadata, not a body or task-seal proof.
    pub fn accepted_declaration_identity(
        &self,
        declaration: &arcweft_lang_hir::symbol::CallableDeclarationKey,
    ) -> Result<
        crate::semantic_coordinate::AcceptedDeclarationSemanticId,
        crate::semantic_coordinate::AcceptedSemanticRootCatalogError,
    > {
        self.accepted_roots.declaration_for_hir(declaration)
    }

    /// Sole accepted-root authority retained by this immutable report.
    pub(crate) const fn accepted_root_catalog(&self) -> &Arc<AcceptedSemanticRootCatalog> {
        &self.accepted_roots
    }

    pub fn types(&self) -> impl ExactSizeIterator<Item = (TypeId, &TypeKind)> {
        self.types.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn locals(&self) -> impl ExactSizeIterator<Item = (LocalId, &CheckedBinding)> {
        self.locals.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn captures(&self) -> impl ExactSizeIterator<Item = (CaptureId, &CheckedBinding)> {
        self.captures.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn expressions(&self) -> impl ExactSizeIterator<Item = (ExprId, &CheckedExpression)> {
        self.expressions.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn patterns(&self) -> impl ExactSizeIterator<Item = (PatternId, &CheckedPattern)> {
        self.patterns.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn statements(&self) -> impl ExactSizeIterator<Item = (StmtId, &CheckedStatement)> {
        self.statements.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn items(&self) -> impl ExactSizeIterator<Item = (ItemId, &CheckedItem)> {
        self.items.iter().map(|(id, fact)| (*id, fact))
    }

    pub fn calls(&self) -> impl ExactSizeIterator<Item = (ExprId, &CallTargetFacts)> {
        self.calls.iter().map(|(id, fact)| (*id, fact))
    }

    /// Ordered per-root operational trace used by the sema acceptance matrix.
    /// This remains crate-owned and is not projected into language tooling.
    #[cfg(test)]
    pub(crate) fn physical_candidate_argument_evaluations(
        &self,
    ) -> impl Iterator<Item = &PhysicalCandidateArgumentEvaluation> {
        self.physical_candidate_argument_evaluations
            .values()
            .flat_map(|evaluations| evaluations.iter())
    }

    pub const fn work(&self) -> FinalSemanticAnalysisWork {
        self.work
    }

    /// Diagnostics remain owned by their exact call facts; this projection
    /// does not copy them into a positional side table.
    pub fn call_diagnostics(&self) -> impl Iterator<Item = &crate::callable::CallableDiagnostic> {
        self.calls
            .values()
            .flat_map(|call| call.diagnostics().iter())
    }

    /// Source-backed warnings accepted with this exact semantic generation.
    pub fn diagnostics(&self) -> &[Diagnostic] {
        &self.diagnostics
    }
}

fn collect_sealed_expressions(
    prepared: BTreeMap<ExprId, super::PreparedExpressionFact>,
) -> Result<BTreeMap<ExprId, CheckedExpression>, FinalSemanticAnalysisError> {
    prepared
        .into_iter()
        .map(|(owner, fact)| {
            let super::PreparedExpressionFact::Complete(fact) = fact else {
                return Err(FinalSemanticAnalysisError::UnsealedPreparedC2Owner);
            };
            Ok((owner, fact))
        })
        .collect()
}

fn collect_sealed_patterns(
    prepared: BTreeMap<PatternId, super::PreparedPatternFact>,
) -> Result<BTreeMap<PatternId, CheckedPattern>, FinalSemanticAnalysisError> {
    prepared
        .into_iter()
        .map(|(owner, fact)| {
            fact.into_complete()
                .map(|fact| (owner, fact))
                .map_err(|_| FinalSemanticAnalysisError::UnsealedPreparedC2Owner)
        })
        .collect()
}

fn project_generation_modules(
    project: HirAnalysisProjectView<'_>,
) -> BTreeMap<HirModuleId, &HirModule> {
    project
        .modules()
        .map(|(_, module)| (module.module_id(), module.as_ref()))
        .collect()
}

fn collect_final_diagnostics(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    types: &BTreeMap<TypeId, TypeKind>,
    expressions: &BTreeMap<ExprId, CheckedExpression>,
    items: &BTreeMap<ItemId, CheckedItem>,
) -> Result<Vec<Diagnostic>, FinalSemanticAnalysisError> {
    let mut diagnostics = Vec::new();
    for (owner, checked) in expressions {
        if checked.type_selection() != Some(super::CheckedTypeSelection::DefaultNumericFallback) {
            continue;
        }
        let module = resolve_module(modules, owner.module())?;
        let expression = module
            .resolve_expr(*owner)
            .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?;
        if !scope_is_nested_in_closure(module, expression.scope())? {
            continue;
        }
        let span = source_span(
            module,
            HirSourceQuery::Expr {
                owner: *owner,
                role: HirExprSourceRole::Whole,
            },
        )?;
        let checked_type = checked
            .value_type()
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: *owner })?;
        diagnostics.push(
            Diagnostic::new(
                DiagnosticSeverity::Warning,
                format!(
                    "unsuffixed numeric literal inside inferred closure body defaults to {}; add a suffix or closure return type to make the contract explicit",
                    checked_type.source_label()
                ),
            )
            .with_code("sema.numeric.fallback_in_inferred_closure")
            .with_label(DiagnosticLabel::primary(
                span,
                Some("default numeric type selected here".to_owned()),
            )),
        );
    }
    for (owner, checked) in items {
        if !matches!(checked.role(), super::CheckedItemRole::TypeAlias) {
            continue;
        }
        let module = resolve_module(modules, owner.module())?;
        let item = module
            .resolve_item(*owner)
            .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?;
        let HirItemKind::TypeAlias(alias) = item.kind() else {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        };
        if item.prefix().visibility() != Some(HirVisibility::Public)
            || !matches!(types.get(&alias.target()), Some(TypeKind::Choice(_)))
        {
            continue;
        }
        let name = alias
            .name()
            .resolved()
            .ok_or(FinalSemanticAnalysisError::RecoveredOwner)?;
        let span = source_span(
            module,
            HirSourceQuery::Item {
                owner: *owner,
                role: HirItemSourceRole::Declaration(HirDeclarationSourceRole::Name),
            },
        )?;
        let ty = types
            .get(&alias.target())
            .ok_or(FinalSemanticAnalysisError::InvalidOwner)?;
        diagnostics.push(
            Diagnostic::new(
                DiagnosticSeverity::Warning,
                format!(
                    "public type alias `{}` exposes anonymous sum `{}`; public ABI and save data are more stable with a nominal enum",
                    name.as_str(),
                    ty.source_label()
                ),
            )
            .with_code("sema.public_abi.anonymous_sum")
            .with_label(DiagnosticLabel::primary(
                span,
                Some("public anonymous sum type".to_owned()),
            )),
        );
    }
    Ok(diagnostics)
}

fn scope_is_nested_in_closure(
    module: &HirModule,
    mut scope: arcweft_lang_hir::identity::ScopeId,
) -> Result<bool, FinalSemanticAnalysisError> {
    loop {
        let current = module
            .resolve_scope(scope)
            .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?;
        if current.kind() == HirScopeKind::Closure {
            return Ok(true);
        }
        let Some(parent) = current.parent() else {
            return Ok(false);
        };
        scope = parent;
    }
}

fn resolve_module<'a>(
    modules: &BTreeMap<HirModuleId, &'a HirModule>,
    owner: HirModuleId,
) -> Result<&'a HirModule, FinalSemanticAnalysisError> {
    modules
        .get(&owner)
        .copied()
        .ok_or(FinalSemanticAnalysisError::InvalidOwner)
}

fn source_span(
    module: &HirModule,
    query: HirSourceQuery,
) -> Result<SourceSpan, FinalSemanticAnalysisError> {
    module
        .source_anchor(query)
        .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?
        .ok_or(FinalSemanticAnalysisError::RecoveredOwner)
}

fn validate_type_resolution_reports(
    accepted_owners: &BTreeSet<TypeId>,
    types: &BTreeMap<TypeId, TypeKind>,
    reports: &BTreeMap<TypeId, TypeResolutionReport>,
) -> Result<BTreeMap<TypeId, ResolvedTypeNodeLocation>, FinalSemanticAnalysisError> {
    if reports.is_empty() {
        return Ok(BTreeMap::new());
    }
    let all_nodes = accepted_owners;
    let mut node_facts = BTreeMap::new();
    let mut locations = BTreeMap::new();
    for (owner, report) in reports {
        let product = report.outcome().product();
        if product.root() != *owner {
            return Err(FinalSemanticAnalysisError::TypeResolutionReportMismatch { owner: *owner });
        }
        for (index, node) in product.nodes().iter().enumerate() {
            if node.is_contextual_alias_target() {
                continue;
            }
            if !all_nodes.contains(&node.node()) {
                return Err(FinalSemanticAnalysisError::TypeResolutionReportMismatch {
                    owner: node.node(),
                });
            }
            let fact = (node.recovered().cloned(), node.purpose());
            merge_type_resolution_fact(&mut node_facts, node.node(), &fact)?;
            locations
                .entry(node.node())
                .or_insert(ResolvedTypeNodeLocation {
                    root: *owner,
                    node: index,
                });
        }
    }
    let covered = node_facts.keys().copied().collect::<BTreeSet<_>>();
    let recovered = node_facts
        .into_iter()
        .filter_map(|(owner, (ty, purpose))| {
            purpose
                .has_runtime_type()
                .then_some(ty)
                .flatten()
                .map(|ty| (owner, ty))
        })
        .collect::<BTreeMap<_, _>>();
    if &covered != all_nodes || recovered != *types {
        let owner = all_nodes
            .iter()
            .find(|owner| !covered.contains(owner) || recovered.get(owner) != types.get(owner))
            .copied()
            .or_else(|| {
                types
                    .keys()
                    .find(|owner| !recovered.contains_key(owner))
                    .copied()
            })
            .unwrap_or_else(|| *reports.keys().next().expect("non-empty report inventory"));
        return Err(FinalSemanticAnalysisError::TypeResolutionReportMismatch { owner });
    }
    Ok(locations)
}

pub(super) fn merge_type_resolution_fact<T: Clone + Eq>(
    facts: &mut BTreeMap<TypeId, T>,
    owner: TypeId,
    fact: &T,
) -> Result<(), FinalSemanticAnalysisError> {
    match facts.entry(owner) {
        std::collections::btree_map::Entry::Vacant(entry) => {
            entry.insert(fact.clone());
            Ok(())
        }
        std::collections::btree_map::Entry::Occupied(entry) if entry.get() == fact => Ok(()),
        std::collections::btree_map::Entry::Occupied(_) => {
            Err(FinalSemanticAnalysisError::TypeResolutionReportMismatch { owner })
        }
    }
}
