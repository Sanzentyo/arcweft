//! Exhaustive late construction of the final-HIR statement families.
//!
//! Specialized early checks retain only private preparation. This module is
//! the one producer that consumes those rows, the statement ingress proofs,
//! and affine coordinate evidence after every checked child is complete.

use std::collections::BTreeMap;

use arcweft_lang_hir::{
    expr::{
        HirExprKind, HirExpressionOwnedBodyRole, HirLinePlanStatementRole,
        HirNestedExpressionPathSegment,
    },
    identity::{ExprId, LocalId, StmtId},
    leaf::{HirLiteral, HirStringLiteral},
    module::HirModule,
    project::{HirAnalysisProjectView, HirControlTransferKind},
    source_index::{HirExprSourceRole, HirSourceQuery},
    stmt::{
        HirCancelTrigger, HirSelectBranchHead, HirSelectStmt, HirSourceLocaleValue, HirStmtKind,
        HirTrigger, HirUnsafeAuditIdentity, HirUnsafeLifetimeBody,
    },
};

use crate::{
    callable::{CheckedCallableCatalog, CheckedCallableDeclaration},
    semantic_coordinate::{CheckedSemanticPathStep, SemanticCoordinateIndex},
    types::TypeKind,
};

use super::{
    CheckedAssignment, CheckedBinding, CheckedDefer, CheckedExpression, CheckedIncludeFlowTarget,
    CheckedScopeIdentity, CheckedSelectBranchHead, CheckedSelectStatement, CheckedStatement,
    CheckedStatementPayload, CheckedTrigger, CheckedUnsafeAudit, FinalSemanticAnalysisError,
    PreparedSelectBranchHeadProof, PreparedSelectScrutineeProof, PreparedStatementIngressSeal,
    PreparedStatementPayload, PreparedStatementScrutineeProof, PreparedTriggerScrutineeProof,
    statement_effects::CheckedStatementPayloadSealer,
};

/// Move-only all-statement producer used by the final effect transaction.
pub(crate) struct CheckedStatementSeal<'a, 'project, 'coordinate> {
    prepared: BTreeMap<StmtId, PreparedStatementPayload>,
    includes: BTreeMap<StmtId, super::PreparedIncludeFlowProof>,
    scrutinees: BTreeMap<StmtId, PreparedStatementScrutineeProof>,
    locals: &'a BTreeMap<LocalId, CheckedBinding>,
    callables: &'a CheckedCallableCatalog,
    calls: &'a BTreeMap<ExprId, crate::callable::CallTargetFacts>,
    coordinates: &'coordinate SemanticCoordinateIndex<'coordinate, 'coordinate>,
    structural_edges: &'coordinate super::match_edges::CheckedStructuralEdgeDraft,
    project: HirAnalysisProjectView<'project>,
}

impl<'a, 'project, 'coordinate> CheckedStatementSeal<'a, 'project, 'coordinate> {
    #[allow(
        clippy::too_many_arguments,
        reason = "the affine statement producer joins complete generation-bound inventories before folding latent bodies"
    )]
    pub(crate) fn new(
        prepared: BTreeMap<StmtId, PreparedStatementPayload>,
        ingress: PreparedStatementIngressSeal,
        locals: &'a BTreeMap<LocalId, CheckedBinding>,
        callables: &'a CheckedCallableCatalog,
        calls: &'a BTreeMap<ExprId, crate::callable::CallTargetFacts>,
        coordinates: &'coordinate SemanticCoordinateIndex<'coordinate, 'coordinate>,
        structural_edges: &'coordinate super::match_edges::CheckedStructuralEdgeDraft,
        project: HirAnalysisProjectView<'project>,
        expressions: &BTreeMap<ExprId, CheckedExpression>,
        modules: &BTreeMap<arcweft_lang_hir::identity::HirModuleId, &HirModule>,
    ) -> Result<Self, FinalSemanticAnalysisError> {
        let (includes, scrutinees) = ingress.into_parts();
        let mut seal = Self {
            prepared,
            includes,
            scrutinees,
            locals,
            callables,
            calls,
            coordinates,
            structural_edges,
            project,
        };
        let owners = seal.prepared.keys().copied().collect::<Vec<_>>();
        for owner in owners {
            let module = modules
                .get(&owner.module())
                .ok_or(FinalSemanticAnalysisError::InvalidOwner)?;
            let statement = module
                .resolve_stmt(owner)
                .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?;
            if let HirStmtKind::Return { value } = statement.kind() {
                let CheckedStatementPayload::ControlTransfer(
                    crate::semantic_coordinate::CheckedControlTransferTarget::Return(boundary),
                ) = seal.return_statement(module, owner, *value, expressions)?
                else {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                };
                seal.prepared
                    .insert(owner, PreparedStatementPayload::Return(boundary));
            }
        }
        Ok(seal)
    }

    fn take_prepared(
        &mut self,
        owner: StmtId,
    ) -> Result<PreparedStatementPayload, FinalSemanticAnalysisError> {
        self.prepared
            .remove(&owner)
            .ok_or(FinalSemanticAnalysisError::MissingFact {
                family: super::SemanticFactFamily::Statement,
            })
    }

    fn structural(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match self.take_prepared(owner)? {
            PreparedStatementPayload::HirOwned => Ok(CheckedStatementPayload::Structural),
            PreparedStatementPayload::Return(_)
            | PreparedStatementPayload::Assignment(_)
            | PreparedStatementPayload::RegistryWrite(_)
            | PreparedStatementPayload::Assertion(_)
            | PreparedStatementPayload::Iteration(_)
            | PreparedStatementPayload::Suspension(_)
            | PreparedStatementPayload::Yield
            | PreparedStatementPayload::EvaluatedEffect(_)
            | PreparedStatementPayload::SealedEvaluatedEffectReference(_) => {
                Err(FinalSemanticAnalysisError::WrongPayloadFamily)
            }
        }
    }

    fn assertion(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match self.take_prepared(owner)? {
            PreparedStatementPayload::Assertion(assertion) => {
                Ok(CheckedStatementPayload::Assertion(assertion))
            }
            PreparedStatementPayload::HirOwned
            | PreparedStatementPayload::Return(_)
            | PreparedStatementPayload::Assignment(_)
            | PreparedStatementPayload::RegistryWrite(_)
            | PreparedStatementPayload::Iteration(_)
            | PreparedStatementPayload::Suspension(_)
            | PreparedStatementPayload::Yield
            | PreparedStatementPayload::EvaluatedEffect(_)
            | PreparedStatementPayload::SealedEvaluatedEffectReference(_) => {
                Err(FinalSemanticAnalysisError::WrongPayloadFamily)
            }
        }
    }

    fn iteration(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match self.take_prepared(owner)? {
            PreparedStatementPayload::Iteration(iteration) => {
                Ok(CheckedStatementPayload::Iteration(iteration))
            }
            PreparedStatementPayload::HirOwned
            | PreparedStatementPayload::Return(_)
            | PreparedStatementPayload::Assignment(_)
            | PreparedStatementPayload::RegistryWrite(_)
            | PreparedStatementPayload::Assertion(_)
            | PreparedStatementPayload::Suspension(_)
            | PreparedStatementPayload::Yield
            | PreparedStatementPayload::EvaluatedEffect(_)
            | PreparedStatementPayload::SealedEvaluatedEffectReference(_) => {
                Err(FinalSemanticAnalysisError::WrongPayloadFamily)
            }
        }
    }

    fn suspension(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match self.take_prepared(owner)? {
            PreparedStatementPayload::Suspension(suspension) => {
                Ok(CheckedStatementPayload::Suspension(suspension))
            }
            PreparedStatementPayload::HirOwned
            | PreparedStatementPayload::Return(_)
            | PreparedStatementPayload::Assignment(_)
            | PreparedStatementPayload::RegistryWrite(_)
            | PreparedStatementPayload::Assertion(_)
            | PreparedStatementPayload::Iteration(_)
            | PreparedStatementPayload::Yield
            | PreparedStatementPayload::EvaluatedEffect(_)
            | PreparedStatementPayload::SealedEvaluatedEffectReference(_) => {
                Err(FinalSemanticAnalysisError::WrongPayloadFamily)
            }
        }
    }

    fn yield_statement(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match self.take_prepared(owner)? {
            PreparedStatementPayload::Yield => Ok(CheckedStatementPayload::Yield),
            PreparedStatementPayload::HirOwned
            | PreparedStatementPayload::Return(_)
            | PreparedStatementPayload::Assignment(_)
            | PreparedStatementPayload::RegistryWrite(_)
            | PreparedStatementPayload::Assertion(_)
            | PreparedStatementPayload::Iteration(_)
            | PreparedStatementPayload::Suspension(_)
            | PreparedStatementPayload::EvaluatedEffect(_)
            | PreparedStatementPayload::SealedEvaluatedEffectReference(_) => {
                Err(FinalSemanticAnalysisError::WrongPayloadFamily)
            }
        }
    }

    fn assignment(
        &mut self,
        owner: StmtId,
        expressions: &BTreeMap<ExprId, CheckedExpression>,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        let PreparedStatementPayload::Assignment(prepared) = self.take_prepared(owner)? else {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        };
        let (target, value, target_type) = prepared.into_parts();
        let target_id = target;
        let value_id = value;
        let target = expressions
            .get(&target)
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: target })?;
        let checked_target_type = target
            .value_type()
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: target_id })?;
        let value = expressions
            .get(&value_id)
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: value_id })?;
        let value_type = value
            .value_type()
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: value_id })?;
        if checked_target_type != &target_type || value_type != &target_type {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let place = target
            .mutable_place()
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        Ok(CheckedStatementPayload::Assignment(Box::new(
            CheckedAssignment::new(place, value_type.clone()),
        )))
    }

    fn control_transfer(
        &mut self,
        owner: StmtId,
        expected: HirControlTransferKind,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        let prepared = self.take_prepared(owner)?;
        if !matches!(prepared, PreparedStatementPayload::HirOwned) {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let evidence = self
            .coordinates
            .control_transfer_evidence(owner)
            .map_err(|_| FinalSemanticAnalysisError::WrongPayloadFamily)?;
        if evidence.owner() != owner || evidence.kind() != expected {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        Ok(CheckedStatementPayload::ControlTransfer(
            evidence.into_target(),
        ))
    }

    fn return_statement(
        &mut self,
        module: &HirModule,
        owner: StmtId,
        value: ExprId,
        expressions: &BTreeMap<ExprId, CheckedExpression>,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        if !matches!(
            self.take_prepared(owner)?,
            PreparedStatementPayload::HirOwned
        ) {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let (boundary, expected) = super::CheckedCallableBoundary::for_return(
            module,
            owner,
            value,
            expressions,
            self.callables,
            self.coordinates,
        )?;
        let expression = expressions
            .get(&value)
            .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: value })?;
        // Unavailable is a retained rejection, not fabricated value evidence.
        // Its call diagnostic remains authoritative; closed roots reject it.
        let actual = match expression.result() {
            super::CheckedExpressionResult::Value(result) => Some(result.ty()),
            super::CheckedExpressionResult::Unavailable => None,
            super::CheckedExpressionResult::NonValue(_) => {
                return Err(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: value });
            }
        };
        if let (Some(expected), Some(actual)) = (expected, actual)
            && !expected.accepts(actual)
        {
            return Err(FinalSemanticAnalysisError::ReturnValueTypeMismatch {
                owner,
                expected: Box::new(expected),
                actual: Box::new(actual.clone()),
            });
        }
        Ok(CheckedStatementPayload::ControlTransfer(
            crate::semantic_coordinate::CheckedControlTransferTarget::Return(boundary),
        ))
    }

    fn trigger(
        &mut self,
        owner: StmtId,
        hir: &HirTrigger,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        if !matches!(
            self.take_prepared(owner)?,
            PreparedStatementPayload::HirOwned
        ) {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let proof = self
            .scrutinees
            .remove(&owner)
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        let PreparedStatementScrutineeProof::Trigger(proof) = proof else {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        };
        let checked = match (hir, proof) {
            (HirTrigger::Input(_), PreparedTriggerScrutineeProof::Input) => CheckedTrigger::input(),
            (HirTrigger::Input(_), PreparedTriggerScrutineeProof::InputAction(action)) => {
                CheckedTrigger::input_action(action)
            }
            (HirTrigger::Event(_), PreparedTriggerScrutineeProof::Event) => CheckedTrigger::event(),
            (HirTrigger::Signal { .. }, PreparedTriggerScrutineeProof::Signal) => {
                CheckedTrigger::signal()
            }
            (HirTrigger::Timeout(_), PreparedTriggerScrutineeProof::Timeout) => {
                CheckedTrigger::timeout()
            }
            (HirTrigger::Mark(hir), PreparedTriggerScrutineeProof::Mark(proof))
                if *hir == proof =>
            {
                CheckedTrigger::mark(
                    self.coordinates
                        .dialogue_mark(self.project, proof)
                        .map_err(|_| FinalSemanticAnalysisError::WrongPayloadFamily)?,
                )
            }
            (HirTrigger::Select(_), PreparedTriggerScrutineeProof::Select) => {
                CheckedTrigger::select()
            }
            (HirTrigger::Task(_), PreparedTriggerScrutineeProof::Task) => CheckedTrigger::task(),
            (HirTrigger::Scope(_), PreparedTriggerScrutineeProof::Scope) => CheckedTrigger::scope(),
            (HirTrigger::Expression(_), PreparedTriggerScrutineeProof::Expression) => {
                CheckedTrigger::expression()
            }
            (HirTrigger::Recovered(_), _)
            | (HirTrigger::Input(_), _)
            | (HirTrigger::Event(_), _)
            | (HirTrigger::Signal { .. }, _)
            | (HirTrigger::Timeout(_), _)
            | (HirTrigger::Mark(_), _)
            | (HirTrigger::Select(_), _)
            | (HirTrigger::Task(_), _)
            | (HirTrigger::Scope(_), _)
            | (HirTrigger::Expression(_), _) => {
                return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
            }
        };
        Ok(CheckedStatementPayload::Trigger(checked))
    }

    fn cancel_trigger(
        &mut self,
        owner: StmtId,
        hir: &HirCancelTrigger,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match hir {
            HirCancelTrigger::Other(trigger) => self.trigger(owner, trigger),
            HirCancelTrigger::Recovered(_) => Err(FinalSemanticAnalysisError::RecoveredOwner),
            HirCancelTrigger::InputAction(name) => {
                if !matches!(
                    self.take_prepared(owner)?,
                    PreparedStatementPayload::HirOwned
                ) {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                }
                let Some(PreparedStatementScrutineeProof::Trigger(
                    PreparedTriggerScrutineeProof::InputAction(action),
                )) = self.scrutinees.remove(&owner)
                else {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                };
                if action.as_str() != name.as_str() {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                }
                Ok(CheckedStatementPayload::Trigger(
                    CheckedTrigger::input_action(action),
                ))
            }
        }
    }

    fn select(
        &mut self,
        owner: StmtId,
        hir: &HirSelectStmt,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        if !matches!(
            self.take_prepared(owner)?,
            PreparedStatementPayload::HirOwned
        ) {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let proof = self
            .scrutinees
            .remove(&owner)
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        let PreparedStatementScrutineeProof::Select(proof) = proof else {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        };
        let checked = match (hir, proof) {
            (HirSelectStmt::Operand(_), PreparedSelectScrutineeProof::Operand) => {
                CheckedSelectStatement::operand()
            }
            (
                HirSelectStmt::Branches { branches, .. },
                PreparedSelectScrutineeProof::Branches(proofs),
            ) if branches.len() == proofs.len() => {
                let heads = branches
                    .iter()
                    .zip(proofs.into_vec())
                    .map(|(branch, proof)| match (branch.head(), proof) {
                        (HirSelectBranchHead::Bind { .. }, PreparedSelectBranchHeadProof::Bind) => {
                            Ok(CheckedSelectBranchHead::Bind)
                        }
                        (
                            HirSelectBranchHead::Frame { .. },
                            PreparedSelectBranchHeadProof::Frame,
                        ) => Ok(CheckedSelectBranchHead::Frame),
                        (
                            HirSelectBranchHead::Event { .. },
                            PreparedSelectBranchHeadProof::Event,
                        ) => Ok(CheckedSelectBranchHead::Event),
                        (HirSelectBranchHead::Recovered, _)
                        | (HirSelectBranchHead::Bind { .. }, _)
                        | (HirSelectBranchHead::Frame { .. }, _)
                        | (HirSelectBranchHead::Event { .. }, _) => {
                            Err(FinalSemanticAnalysisError::WrongPayloadFamily)
                        }
                    })
                    .collect::<Result<Vec<_>, _>>()?
                    .into_boxed_slice();
                CheckedSelectStatement::branches(heads)
            }
            (HirSelectStmt::Operand(_), PreparedSelectScrutineeProof::Branches(_))
            | (HirSelectStmt::Branches { .. }, PreparedSelectScrutineeProof::Operand)
            | (HirSelectStmt::Branches { .. }, PreparedSelectScrutineeProof::Branches(_)) => {
                return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
            }
        };
        Ok(CheckedStatementPayload::Select(checked))
    }

    fn unsafe_audit(
        &mut self,
        module: &HirModule,
        owner: StmtId,
        audit: &arcweft_lang_hir::stmt::HirUnsafeAudit,
        body: &HirUnsafeLifetimeBody,
        expressions: &BTreeMap<ExprId, CheckedExpression>,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        if !matches!(
            self.take_prepared(owner)?,
            PreparedStatementPayload::HirOwned
        ) || !matches!(body, HirUnsafeLifetimeBody::Block { .. })
        {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let HirUnsafeAuditIdentity::Accepted(id) = audit.identity() else {
            return Err(FinalSemanticAnalysisError::RecoveredOwner);
        };
        if let Some(reason) = audit.reason() {
            let checked = expressions
                .get(&reason)
                .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: reason })?;
            let expression = module
                .resolve_expr(reason)
                .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?;
            let literal = matches!(
                (expression.kind(), checked.resolution()),
                (
                    HirExprKind::Literal(HirLiteral::String(HirStringLiteral::Value(source))),
                    super::CheckedExpressionResolution::Literal(HirLiteral::String(
                        HirStringLiteral::Value(value),
                    )),
                ) if source == value && !value.trim().is_empty()
            );
            if !literal
                || checked.value_type() != Some(&TypeKind::String)
                || !checked.effects().is_empty()
            {
                let source_span = module
                    .source_anchor(HirSourceQuery::Expr {
                        owner: reason,
                        role: HirExprSourceRole::Whole,
                    })
                    .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?
                    .ok_or(FinalSemanticAnalysisError::RecoveredOwner)?;
                return Err(FinalSemanticAnalysisError::InvalidUnsafeAuditReason {
                    owner,
                    reason,
                    source_span,
                });
            }
        }
        Ok(CheckedStatementPayload::UnsafeAudit(
            CheckedUnsafeAudit::new(id.clone(), audit.reason(), audit.has_safety_doc()),
        ))
    }

    fn include(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        if !matches!(
            self.take_prepared(owner)?,
            PreparedStatementPayload::HirOwned
        ) {
            return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
        }
        let proof = self
            .includes
            .remove(&owner)
            .filter(|proof| proof.statement() == owner)
            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
        self.callables
            .project_callable(proof.source())
            .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)?;
        let target = proof.into_target();
        let declaration = arcweft_lang_hir::symbol::CallableDeclarationKey::Flow(target.clone());
        let checked = self
            .callables
            .project_callable(&declaration)
            .map_err(|_| FinalSemanticAnalysisError::CheckedCallableCatalog)?;
        if !matches!(
            checked.id().declaration(),
            CheckedCallableDeclaration::Project(retained) if retained == &declaration
        ) {
            return Err(FinalSemanticAnalysisError::CheckedCallableCatalog);
        }
        Ok(CheckedStatementPayload::Include(
            CheckedIncludeFlowTarget::new(
                self.coordinates
                    .statement_origin(owner)
                    .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?,
                target.semantic_digest(),
            ),
        ))
    }

    fn expression_statement(
        &mut self,
        owner: StmtId,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match self.take_prepared(owner)? {
            PreparedStatementPayload::HirOwned => Ok(CheckedStatementPayload::Structural),
            PreparedStatementPayload::SealedEvaluatedEffectReference(reference) => {
                Ok(CheckedStatementPayload::EvaluatedEffect(reference))
            }
            PreparedStatementPayload::Return(_)
            | PreparedStatementPayload::Assignment(_)
            | PreparedStatementPayload::RegistryWrite(_)
            | PreparedStatementPayload::Assertion(_)
            | PreparedStatementPayload::Iteration(_)
            | PreparedStatementPayload::Suspension(_)
            | PreparedStatementPayload::Yield
            | PreparedStatementPayload::EvaluatedEffect(_) => {
                Err(FinalSemanticAnalysisError::WrongPayloadFamily)
            }
        }
    }
}

impl CheckedStatementPayloadSealer for CheckedStatementSeal<'_, '_, '_> {
    #[allow(
        clippy::too_many_lines,
        reason = "the accepted contract requires one explicit producer arm for every HIR family"
    )]
    fn seal_payload(
        &mut self,
        module: &HirModule,
        owner: StmtId,
        statement: &HirStmtKind,
        expressions: &BTreeMap<ExprId, CheckedExpression>,
        _statements: &BTreeMap<StmtId, CheckedStatement>,
    ) -> Result<CheckedStatementPayload, FinalSemanticAnalysisError> {
        match statement {
            HirStmtKind::Assertion { .. } => self.assertion(owner),
            HirStmtKind::Let { .. } => self.structural(owner),
            HirStmtKind::Assign { .. } => self.assignment(owner, expressions),
            HirStmtKind::LetElse { .. } => self.structural(owner),
            HirStmtKind::Return { .. } => {
                let PreparedStatementPayload::Return(boundary) = self.take_prepared(owner)? else {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                };
                Ok(CheckedStatementPayload::ControlTransfer(
                    crate::semantic_coordinate::CheckedControlTransferTarget::Return(boundary),
                ))
            }
            HirStmtKind::Out { .. } => self.control_transfer(owner, HirControlTransferKind::Out),
            HirStmtKind::Goto { target } => {
                let checked = expressions.get(target).ok_or(
                    FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: *target },
                )?;
                if let Some(call) = self.calls.get(target) {
                    // A selected Flow application owns its parameter binding.
                    // A failed call keeps its original tooling diagnostic.
                    if call.selected_application().is_some_and(|application| {
                        application
                            .core()
                            .candidates()
                            .selected()
                            .id()
                            .is_flow_transfer()
                    }) || call.selected_application().is_none() && !call.diagnostics().is_empty()
                    {
                        return self.structural(owner);
                    }
                }
                if let super::CheckedExpressionResolution::Value(
                    super::CheckedValueResolution::ProjectItem(flow),
                ) = checked.resolution()
                    && flow.flow_owner().is_some()
                {
                    let source_span = module
                        .source_anchor(HirSourceQuery::Expr {
                            owner: *target,
                            role: HirExprSourceRole::Whole,
                        })
                        .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?
                        .ok_or(FinalSemanticAnalysisError::RecoveredOwner)?;
                    self.callables
                        .validate_empty_flow_transfer(flow, *target, source_span)?;
                }
                let actual = checked.value_type().ok_or(
                    FinalSemanticAnalysisError::ExpressionTypeUnavailable { owner: *target },
                )?;
                if !matches!(actual, TypeKind::Never)
                    && !matches!(actual, TypeKind::Ref(entity) if entity.kind() == &crate::types::EntityKind::Flow)
                {
                    return Err(FinalSemanticAnalysisError::StatementOperandTypeMismatch {
                        statement: owner,
                        owner: *target,
                        expected: Box::new(TypeKind::entity_ref(crate::types::EntityKind::Flow)),
                        actual: Box::new(actual.clone()),
                    });
                }
                self.structural(owner)
            }
            HirStmtKind::Defer {
                outcome,
                expression,
            } => {
                if !matches!(
                    self.take_prepared(owner)?,
                    PreparedStatementPayload::HirOwned
                ) {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                }
                let actual = expressions
                    .get(expression)
                    .and_then(CheckedExpression::value_type)
                    .ok_or(FinalSemanticAnalysisError::ExpressionTypeUnavailable {
                        owner: *expression,
                    })?;
                if actual != &TypeKind::Unit {
                    return Err(FinalSemanticAnalysisError::StatementOperandTypeMismatch {
                        statement: owner,
                        owner: *expression,
                        expected: Box::new(TypeKind::Unit),
                        actual: Box::new(actual.clone()),
                    });
                }
                let captures = super::free_capture::collect_checked_free_locals(
                    *expression,
                    self.coordinates,
                    self.structural_edges,
                    |child| {
                        let checked = expressions
                            .get(&child)
                            .ok_or(FinalSemanticAnalysisError::WrongPayloadFamily)?;
                        let fields = self
                            .structural_edges
                            .record_fields(child)
                            .map_err(|_| FinalSemanticAnalysisError::WrongPayloadFamily)?;
                        super::free_capture::CheckedCaptureExpression::from_checked(
                            child,
                            checked,
                            fields,
                            |local| self.locals.get(&local).map(|binding| binding.ty().clone()),
                            |owner| {
                                expressions
                                    .get(&owner)
                                    .and_then(super::CheckedExpression::local_place_source)
                            },
                            arcweft_lang_hir::scope::CaptureAccess::Read,
                        )
                    },
                    |local| self.locals.get(&local).map(|binding| binding.ty().clone()),
                )?;
                let coordinate = self
                    .coordinates
                    .statement(owner)
                    .map_err(|_| FinalSemanticAnalysisError::InvalidOwner)?;
                let runtime_owner = match coordinate.path().steps().last() {
                    Some(CheckedSemanticPathStep::ExpressionOwned(
                        HirExpressionOwnedBodyRole::DialogueLinePlanStatement {
                            path,
                            role: HirLinePlanStatementRole::Statement,
                        },
                    )) if matches!(
                        path.segments(),
                        [HirNestedExpressionPathSegment::LinePlanItem { .. }]
                    ) =>
                    {
                        arcweft_core::plan::RuntimeDeferOwner::LineRoot
                    }
                    _ => arcweft_core::plan::RuntimeDeferOwner::CurrentScope,
                };
                Ok(CheckedStatementPayload::Defer(Box::new(CheckedDefer::new(
                    owner,
                    *outcome,
                    runtime_owner,
                    *expression,
                    super::CheckedExecutionDefinitionIdentity::from_coordinate(
                        &super::CheckedExecutionCoordinate::CallableBody(
                            self.coordinates
                                .expression(*expression)
                                .map_err(|_| FinalSemanticAnalysisError::WrongPayloadFamily)?,
                        ),
                    )
                    .map_err(|_| FinalSemanticAnalysisError::WrongPayloadFamily)?,
                    captures,
                ))))
            }
            HirStmtKind::Yield { .. } => self.yield_statement(owner),
            HirStmtKind::Signal { .. } => self.structural(owner),
            HirStmtKind::LifetimeSet { target, value } => {
                let PreparedStatementPayload::RegistryWrite(prepared) =
                    self.take_prepared(owner)?
                else {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                };
                let expected = super::CheckedRegistryAddress::from_statement(module, owner)?;
                if prepared.address.as_ref() != &expected
                    || prepared.value != *value
                    || expressions
                        .get(value)
                        .and_then(super::CheckedExpression::value_type)
                        != Some(&prepared.value_type)
                    || !matches!(expressions.get(target).map(super::CheckedExpression::resolution), Some(super::CheckedExpressionResolution::RegistryAddress(address)) if address == &prepared.address)
                {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                }
                Ok(CheckedStatementPayload::RegistryWrite(Box::new(
                    super::CheckedRegistryWrite::new(
                        prepared.address,
                        prepared.value,
                        prepared.value_type,
                    ),
                )))
            }
            HirStmtKind::Wait { .. } => self.suspension(owner),
            HirStmtKind::On { trigger, .. } => self.trigger(owner, trigger),
            HirStmtKind::CancelRule { trigger, .. } => self.cancel_trigger(owner, trigger),
            HirStmtKind::UnsafeLifetime { audit, body } => {
                self.unsafe_audit(module, owner, audit, body, expressions)
            }
            HirStmtKind::Choice { .. } => self.structural(owner),
            HirStmtKind::If(_) => self.structural(owner),
            HirStmtKind::IfLet(_) => self.structural(owner),
            HirStmtKind::Match(_) => self.structural(owner),
            HirStmtKind::While(_) => self.structural(owner),
            HirStmtKind::WhileLet(_) => self.structural(owner),
            HirStmtKind::For(_) => self.iteration(owner),
            HirStmtKind::Close { .. } => self.structural(owner),
            HirStmtKind::Select(select) => self.select(owner, select),
            HirStmtKind::SourceLocale(locale) => {
                if !matches!(
                    self.take_prepared(owner)?,
                    PreparedStatementPayload::HirOwned
                ) {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                }
                let HirSourceLocaleValue::Resolved(locale) = locale.locale() else {
                    return Err(FinalSemanticAnalysisError::RecoveredOwner);
                };
                Ok(CheckedStatementPayload::SourceLocale(locale.clone()))
            }
            HirStmtKind::Scope(scope) => {
                if !matches!(
                    self.take_prepared(owner)?,
                    PreparedStatementPayload::HirOwned
                ) {
                    return Err(FinalSemanticAnalysisError::WrongPayloadFamily);
                }
                Ok(CheckedStatementPayload::Scope(match scope.name() {
                    Some(name) => CheckedScopeIdentity::Named(
                        arcweft_id::DeclarationName::try_new(name.as_str())
                            .map_err(|_| FinalSemanticAnalysisError::RecoveredOwner)?,
                    ),
                    None => CheckedScopeIdentity::Anonymous,
                }))
            }
            HirStmtKind::Include(_) => self.include(owner),
            HirStmtKind::Break { .. } => {
                self.control_transfer(owner, HirControlTransferKind::Break)
            }
            HirStmtKind::Continue { .. } => {
                self.control_transfer(owner, HirControlTransferKind::Continue)
            }
            HirStmtKind::Expression { .. } => self.expression_statement(owner),
            HirStmtKind::ProofCall { .. } => self.structural(owner),
            HirStmtKind::Error => Err(FinalSemanticAnalysisError::RecoveredOwner),
        }
    }

    fn finish(self) -> Result<(), FinalSemanticAnalysisError> {
        if self.prepared.is_empty() && self.includes.is_empty() && self.scrutinees.is_empty() {
            Ok(())
        } else {
            Err(FinalSemanticAnalysisError::WrongPayloadFamily)
        }
    }
}
