$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$first=Join-Path $r 'modern-feedback-migration-dev-r1'
$next=Join-Path $r 'modern-feedback-migration-dev-r5'
if(Test-Path -LiteralPath $next){throw 'Fixture exists'}
$source=[IO.File]::ReadAllText("$first/src/main.arcw")
$pattern='(?ms)\n[ \t]+\.style \{\n.*?\n[ \t]+\}'
$patches=[regex]::Matches($source,$pattern)
if($patches.Count -ne 4){throw 'Four original node patches required'}
$index=0
$source=[regex]::Replace($source,$pattern,[Text.RegularExpressions.MatchEvaluator]{
    param($match)
    $style=if(($script:index++ % 2) -eq 0){'modern_feedback_heading'}else{'modern_feedback_caption'}
    [string][char]10+'        .style(@style:.'+$style+')'
})
$styles=@'
style modern_feedback_heading {
  Text {
    color = rgba(244, 247, 251, 255)
    font-size = 36px
    font-weight = 720
  }
}

style modern_feedback_caption {
  Text {
    color = rgba(164, 176, 194, 255)
    font-size = 16px
  }
}

'@
$anchor='pub style modern_feedback_panel {'
if($source.Split($anchor,[StringSplitOptions]::None).Count -ne 2){throw 'Style anchor changed'}
$source=$source.Replace($anchor,$styles+[char]10+$anchor)
New-Item -ItemType Directory -Path "$next/src","$next/assets/bg"|Out-Null
[IO.File]::WriteAllText("$next/src/main.arcw",$source,[Text.UTF8Encoding]::new($false))
Copy-Item -LiteralPath "$first/arcw.toml" -Destination "$next/arcw.toml"
Copy-Item -LiteralPath "$first/assets/bg/glass_lights.png" -Destination "$next/assets/bg/glass_lights.png"
$main='D:/git/arcweft/target/debug/arcw.exe'
$expected='82f0783982d58d2e694f0444d4f07230040acc43cd3337262e7605382fb587c4'
if((Get-FileHash $main).Hash.ToLowerInvariant() -ne $expected){throw 'Preceding CLI changed'}
& $main check --manifest-path "$next/arcw.toml" --json *> "$r/modern-feedback-migration-dev-20261109.check-r5.log"
$code=$LASTEXITCODE
if((Get-FileHash $main).Hash.ToLowerInvariant() -ne $expected){throw 'Preceding CLI changed'}
[ordered]@{version=1;fixture=$next;sourceSha256=(Get-FileHash "$next/src/main.arcw").Hash.ToLowerInvariant();change='Preserve complete original Flow and every title/description property. Replace four unsupported closure-style applications with current typed Ref<Style> applications at the same authored Text nodes. Two shared named sheets retain exact original literal properties and Text selector; retained panel sheet, application positions, fonts, image, controls, Actions and branches remain.';contract='docs/03-presentation/view-reactive.md and ViewModifierId::Style signature accept Ref<Style>. This is migration to the current contract, not resurrection of a removed untyped closure API.';cliSource='f8c17506c05ee9df614581d8df12e46a2c178464';cliSha256=$expected;exitCode=$code;scope='Preliminary fixture check only, not current Source acceptance. Repository inputs remain unchanged.'}|ConvertTo-Json -Depth 8|Set-Content "$r/modern-feedback-migration-dev-20261109.check-r5.json"
Get-Content "$r/modern-feedback-migration-dev-20261109.check-r5.log" -TotalCount 25
exit $code
