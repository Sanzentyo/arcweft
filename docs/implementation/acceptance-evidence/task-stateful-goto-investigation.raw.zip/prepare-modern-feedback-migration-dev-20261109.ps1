$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$fixture=Join-Path $r 'modern-feedback-migration-dev-r1'
if(Test-Path -LiteralPath $fixture){throw 'Fixture epoch exists'}
$sourcePath='samples/modern-feedback-view/src/main.arcw'
$crlf=[string][char]13+[char]10
$lf=[string][char]10
$original=[IO.File]::ReadAllText((Join-Path (Get-Location) $sourcePath)).Replace($crlf,$lf)
$source=$original
function Replace-Once([string]$before,[string]$after) {
    if(($script:source.Split($before,[StringSplitOptions]::None)).Count -ne 2){throw ('Expected unique migration input: '+$before)}
    $script:source=$script:source.Replace($before,$after)
}
Replace-Once @'
pub image glass_bg {
  asset = @asset:.bg.glass_lights
  target = @target.modern.glass_bg
  layer = @layer.background
  x = 0px
  y = 0px
  width = 1280px
  height = 720px
  fit = cover
  opacity = 1
  depth = -1000
  visible = true
}
'@ @'
pub fn glass_bg() -> Handle<ImageSurface> {
  image(
    asset = @asset:.bg.glass_lights,
    id = "image.glass_bg",
    target = @target.modern.glass_bg,
    layer = @layer.background,
    x = 0px,
    y = 0px,
    width = 1280px,
    height = 720px,
    fit = "cover",
    opacity = 1,
    depth = -1000,
    visible = true
  )
}
'@
Replace-Once '  let visitor_name = input.text(@input:.visitor_name, initial = "")' '  local state mut visitor_name: String = ""'
Replace-Once '  let product_brief = input.text(@input:.product_brief, initial = "")' '  local state mut product_brief: String = ""'
Replace-Once @'
        TextField(visitor_name)
          .label("Name")
          .placeholder("Your name")
          .purpose(.name)
          .enter_key(.send)
          .on_submit {
            action.invoke(@action:.feedback.submit_name, value = visitor_name.text)
          }
'@ @'
        TextField(visitor_name, target = @input:.visitor_name, label = "Name",
                  placeholder = "Your name", purpose = .name, enter_key = .send)
          .on_submit(|| feedback.submit_name(value = visitor_name))
'@
Replace-Once @'
        Button(@button:.submit_name, label = "Continue")
          .enabled(true)
          .focusable(true)
          .on_click {
            action.invoke(@action:.feedback.submit_name, value = visitor_name.text)
          }
'@ @'
        Button("Continue", target = @button:.submit_name, enabled = true)
          .on_click(|| feedback.submit_name(value = visitor_name))
'@
Replace-Once @'
      TextArea(product_brief)
        .label("Product brief")
        .placeholder("Write one sharp product idea")
        .purpose(.text)
        .on_submit {
          action.invoke(@action:.feedback.submit_brief, value = product_brief.text)
        }
'@ @'
      TextArea(product_brief, target = @input:.product_brief, label = "Product brief",
               placeholder = "Write one sharp product idea", purpose = .text)
        .on_submit(|| feedback.submit_brief(value = product_brief))
'@
Replace-Once @'
        Button(@button:.send_brief, label = "Send brief")
          .enabled(true)
          .focusable(true)
          .on_click {
            action.invoke(@action:.feedback.submit_brief, value = product_brief.text)
          }
'@ @'
        Button("Send brief", target = @button:.send_brief, enabled = true)
          .on_click(|| feedback.submit_brief(value = product_brief))
'@
Replace-Once @'
        Button(@button:.draft_status, label = "Draft saved")
          .enabled(false)
          .focusable(false)
'@ @'
        Button("Draft saved", target = @button:.draft_status, enabled = false)
'@
Replace-Once '    image(@image.glass_bg)' '    let background = glass_bg()'
Replace-Once '        let name_panel = view(@view:.ModernFeedbackNamePanel)' '        let name_panel = mount(ModernFeedbackNamePanel())'
Replace-Once '        let brief_panel = view(@view:.ModernFeedbackBriefPanel)' '        let brief_panel = mount(ModernFeedbackBriefPanel())'
Replace-Once '        let name_event = receive action(@action:.feedback.submit_name)' '        let name_event = await receive(feedback.submit_name)'
Replace-Once '        let brief_event = receive action(@action:.feedback.submit_brief)' '        let brief_event = await receive(feedback.submit_brief)'
New-Item -ItemType Directory -Path "$fixture/src","$fixture/assets/bg" -Force|Out-Null
[IO.File]::WriteAllText("$fixture/src/main.arcw",$source,[Text.UTF8Encoding]::new($false))
Copy-Item -LiteralPath 'samples/modern-feedback-view/arcw.toml' -Destination "$fixture/arcw.toml"
Copy-Item -LiteralPath 'samples/modern-feedback-view/assets/bg/glass_lights.png' -Destination "$fixture/assets/bg/glass_lights.png"
$main='D:/git/arcweft/target/debug/arcw.exe'
$expected='82f0783982d58d2e694f0444d4f07230040acc43cd3337262e7605382fb587c4'
if((Get-FileHash $main).Hash.ToLowerInvariant() -ne $expected){throw 'Previously accepted CLI changed'}
& $main check --manifest-path "$fixture/arcw.toml" --json *> "$r/modern-feedback-migration-dev-20261109.check-r1.log"
$code=$LASTEXITCODE
if((Get-FileHash $main).Hash.ToLowerInvariant() -ne $expected){throw 'Previously accepted CLI changed'}
if([IO.File]::ReadAllText((Join-Path (Get-Location) $sourcePath)).Replace($crlf,$lf) -cne $original){throw 'Frozen sample input changed'}
[ordered]@{version=1;sourceBase=(git rev-parse HEAD).Trim();originalPath=$sourcePath;originalSha256=(Get-FileHash $sourcePath).Hash.ToLowerInvariant();fixture=$fixture;fixtureSourceSha256=(Get-FileHash "$fixture/src/main.arcw").Hash.ToLowerInvariant();cliSource='f8c17506c05ee9df614581d8df12e46a2c178464';cliPath=$main;cliSha256=$expected;exitCode=$code;scope='Preliminary migration check with the preceding accepted CLI, not current Environment consumer acceptance. Repository Source input remains unchanged; fixture copies only authored source/manifest/image asset, never build artifacts.'}|ConvertTo-Json -Depth 7|Set-Content "$r/modern-feedback-migration-dev-20261109.check-r1.json"
Get-Content "$r/modern-feedback-migration-dev-20261109.check-r1.json"
exit $code
