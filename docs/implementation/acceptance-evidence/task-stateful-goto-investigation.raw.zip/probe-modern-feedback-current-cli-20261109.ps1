$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$pin=Get-Content "$r/style-environment-integrated-20261109.cli-r1.main-before.json" -Raw|ConvertFrom-Json
$freeze=Get-Content "$r/style-environment-integrated-20261109.noncli-r1.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20
function Assert-Inputs {
    if((Get-FileHash $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw 'Pinned main changed'}
    foreach($row in $freeze.paths){if((Get-FileHash $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Frozen Source changed: '+$row.path)}}
}
Assert-Inputs
$rows=@(foreach($epoch in @(5,6,7)){
    $fixture=Join-Path $r "modern-feedback-migration-dev-r$epoch"
    $stem=Join-Path $r "modern-feedback-migration-current-20261109.r$epoch"
    if(Test-Path ($stem+'.json')){throw 'Current probe epoch exists'}
    & $pin.path check --manifest-path "$fixture/arcw.toml" --json *> ($stem+'.check.log')
    $check=$LASTEXITCODE
    Assert-Inputs
    $bundle=$null
    $artifact=$null
    if($epoch -eq 5 -and $check -eq 0){
        $artifact='D:/git/arcweft/target/arcweft/modern-feedback-view-migration-current.awfb'
        if(Test-Path $artifact){throw 'Artifact epoch exists'}
        & $pin.path bundle --manifest-path "$fixture/arcw.toml" --profile main --output $artifact --json *> ($stem+'.bundle.log')
        $bundle=$LASTEXITCODE
        Assert-Inputs
    }
    $record=[ordered]@{
        version=1;base=$freeze.base;productionSource='ef2679347c14dccee649e5fb716d3a37510cac1f'
        fixture=$fixture;fixtureSourceSha256=(Get-FileHash "$fixture/src/main.arcw").Hash.ToLowerInvariant()
        main=$pin;binaryDrift=0;sourceInputs=$freeze.paths.Count;sourceDrift=0
        checkExitCode=$check;bundleExitCode=$bundle
        scope='Current pinned CLI probe while the independent complete CLI matrix remains live. Preserve complete original sample behavior in r5; r6/r7 are explicit transfer-syntax counterexamples. No repository Source mutation or extra Cargo build.'
    }
    if($bundle -eq 0){$record.artifact=[ordered]@{path=$artifact;bytes=(Get-Item $artifact).Length;sha256=(Get-FileHash $artifact).Hash.ToLowerInvariant()}}
    $record|ConvertTo-Json -Depth 10|Set-Content ($stem+'.json')
    [ordered]@{epoch=$epoch;checkExitCode=$check;bundleExitCode=$bundle;log=$stem}
})
$rows|ConvertTo-Json -Depth 6
