$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
if((git rev-parse HEAD).Trim() -ne 'c5a4c901473354a3cc87d122b85ac47096fb1b6e'){throw 'Investigation base changed'}
$minimal=@(Read-Record 'stateful-goto-current-20261109.results.json')
$current=Read-Record 'modern-feedback-migration-current-20261109.r5.json'
$main=Read-Record 'style-environment-integrated-20261109.cli-r1.main-audit.json'
if($minimal.Count -ne 2 -or $minimal[0].checkExitCode -ne 0 -or $minimal[0].bundleExitCode -ne 0 -or $minimal[1].checkExitCode -ne 0 -or $minimal[1].bundleExitCode -ne 1 -or $current.checkExitCode -ne 0 -or $current.bundleExitCode -ne 1){throw 'Investigation outcomes changed'}
foreach($row in @($minimal)+@($current)){if($row.main.sha256 -ne $main.sha256 -or $row.binaryDrift -ne 0){throw 'Current probe pin mismatch'}}
$archive='docs/implementation/acceptance-evidence/task-stateful-goto-investigation.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
$files=@(foreach($filter in @('modern-feedback-migration-*','stateful-goto-*')){Get-ChildItem -LiteralPath $r -File -Filter $filter|Where-Object {$_.Extension -in @('.json','.log','.txt')}})
$files+=@('prepare-modern-feedback-migration-dev-20261109.ps1','probe-modern-feedback-style-references-20261109.ps1','probe-modern-feedback-current-cli-20261109.ps1','probe-stateful-goto-current-20261109.ps1','record-stateful-goto-investigation-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
foreach($directory in @((Get-ChildItem $r -Directory -Filter 'modern-feedback-migration-dev-r*')+(Get-ChildItem $r -Directory -Filter 'stateful-goto-current-20261109.*'))){
    foreach($relative in @('src/main.arcw','arcw.toml')){$p=Join-Path $directory.FullName $relative;if(Test-Path $p){$files+=Get-Item $p}}
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,[IO.Path]::GetRelativePath($r,$f.FullName).Replace('\','/'),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';observingBase=(git rev-parse HEAD).Trim();productionSource='ef2679347c14dccee649e5fb716d3a37510cac1f'
 status='Newly reproduced unresolved boundary: a stateful Flow self-goto passes Source check but loses its required formal argument before AWBC verification. Existing zero-argument transfer/cleanup acceptance remains accepted.'
 currentMinimal=$minimal;currentCompleteMigrationCandidate=$current;currentMain=$main
 transferSyntaxCounterexamples=@((Read-Record 'modern-feedback-migration-current-20261109.r6.json'),(Read-Record 'modern-feedback-migration-current-20261109.r7.json'))
 source='Empty control and self-goto use the same actual GameState formal and typed game startup. Empty control produces a13-instruction AWFB. Adding only goto @flow.main fails at block0, expected1/found0. Complete modern-feedback migration candidate similarly fails at block25. This is independent of View, image or Style producers. Reference-call target is non-callable; bare Flow name invocation is unknown. Do not remove the state formal, retain recursive caller lifetimes, or drop original sample behavior to avoid the defect.'
 owners='Sema currently groups Goto as HirOwned and seals it structurally. RuntimePlan final_flow lowers a static Flow reference to Goto(target) with no argument carrier. AWBC lower creates GotoStatic with args Vec::new(). Inspect original complete formal/invocation authority and stateful transition contract, then repair admission, argument evaluation/ownership, cleanup and both backends together.'
 modernMigration='Prepared in temporary fixtures only, not published repository Source. Replace obsolete image declaration with an ordinary Handle<ImageSurface> factory retaining original metadata and asset. Keep retained String state, targets, labels/placeholders, IME roles, original Action declarations/payloads, two scoped mounts, dialogue/branches and tail transfer. Current Style modifier accepts Ref<Style>; replace four obsolete closure-style patches with two shared named sheets applied at the same Text nodes, retaining every property. Full candidate passes current check. Real Native/Web operation/capture acceptance is not claimed.'
 diagnosticFidelity='Reduction r3 omits only Flow and still fails Expr525; r4 also omits four inline patches and passes. These are diagnostic reductions, never final acceptance fixtures. R5 restores all body/Style behavior through the current API. Preliminary unpinned r6/r7 Source attributions were explicitly corrected after the main rebuild; raw results and correction reasons are retained. Current r5/r6/r7 and both minimal cases were rerun under the actual verified main pin.'
 originalSource=[ordered]@{path='samples/modern-feedback-view/src/main.arcw';sha256=(Get-FileHash 'samples/modern-feedback-view/src/main.arcw').Hash.ToLowerInvariant();image='samples/modern-feedback-view/assets/bg/glass_lights.png';imageSha256=(Get-FileHash 'samples/modern-feedback-view/assets/bg/glass_lights.png').Hash.ToLowerInvariant()}
 separation='These source probes are separate from the complete Environment5397-case runtime matrix and are not added to those totals. Reopen only this newly evidenced parameterized-transfer boundary; preserve Generic Match, zero-argument goto, scoped defer, Style and all unrelated accepted cuts.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$registryPath=Join-Path (Get-Location) $registry
$original=[IO.File]::ReadAllText($registryPath).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 150 -or $prior.PSObject.Properties.Name -contains 'statefulGotoArgumentInvestigation'){throw 'Environment record must be present exactly once'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "statefulGotoArgumentInvestigation": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText($registryPath,$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
if($status.Contains('| 引数を持つFlowへのgoto |')){throw 'Current row already exists'}
$anchor='| Line の初期所有入力 |'
$position=$status.IndexOf($anchor)
if($position -lt 0){throw 'Current table anchor changed'}
$row='| 引数を持つFlowへのgoto | **formal／引数のadmissionと転送が未達** | Source ef2679347c14dccee649e5fb716d3a37510cac1fの実CLIを前後pinし、同じGameState formalを持つ最小2入力で再現した。空Flowはcheck／13命令AWFB生成が成功し、自己goto追加だけでcheckは通るがAWBC block0で要求1引数／実際0引数となる。Semaの構造扱いからRuntimePlanの引数なしGoto、AWBCの空argsへ至る接続を調査・修復する。modern-feedbackの全動作を保持した一時移行案もcheck成功後に同じ問題で停止する。実repo sample移行・実操作は未公開／未受入。既存の引数なしgoto・scope cleanup・Style等の受入は維持し、この新しい具体的境界だけを未達として追跡する。[最小対照・失敗原本・CLI pin・訂正理由](acceptance-evidence/task-flow-registry-execution.json)。 |'+$lf
$status=$status.Insert($position,$row)
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — 引数を持つFlowへのgotoの新しい未達

観察base c5a4c901473354a3cc87d122b85ac47096fb1b6e、production Source ef2679347c14dccee649e5fb716d3a37510cac1f の固定CLI SHA256 $($main.sha256) を使った独立Source probeで、stateful Flowの自己gotoがSource checkを通り、AWBCでformal引数を失う問題を確認した。同じGameState formal／typed startupの空Flowはcheckと13命令のAWFB生成が終了0だが、自己gotoだけを追加するとblock0で要求1／実際0引数となる。元pathの対照AWFB hashは原本へ保持する。全modern-feedback移行案もcheckを通るが同じ問題でblock25に停止した。Refへのcallはnon-callable、bare Flow名のcallはunknown targetで拒否され、値渡しを接続できていない。

SemaはGotoをHirOwned／structuralとして扱い、RuntimePlan final_flowのstatic Gotoはtargetのみ、AWBC lowerは空argsを構築する。元のcomplete formal／invocation、stateful entryとの契約を確認し、引数評価・所有とcleanup・Native／AWBCへ接続する必要がある。state formalの削除、callerを蓄積する自己再帰、元のlifecycleの置換を解決としない。引数なしgotoと既受入cleanup、Generic Match等は戻さず、この具体的なparameterized transfer境界だけを現状一覧に追加した。別入力のprobeをEnvironment5397件へ加算していない。

modern-feedbackの準備は一時fixtureに留め、実repo Sourceは変更していない。旧image宣言を現行Handle factoryへ、入力／Action／mount／receiveを現行APIへ移す案を作り、画像・metadata・全Style property・元font stack・target／label／placeholder／IME・Action identity／payload・2 scope・対話／分岐／自己gotoを保持する。Flow削減だけではExpr525が残り、4つの旧closure-style patchを診断用に省くと通過した。最終候補r5では全表現を戻し、現行Ref<Style>契約の2共有sheetを同じText nodeへ適用して現CLI checkを通した。削減fixtureを受入としない。

CLI main rebuildの間に行ったpreliminary r6／r7は前後pinを持たなかったため、推測Source帰属を未検証へ訂正し、元の推測値と理由・rawを保持した。固定した現CLIでr5／r6／r7と最小2入力を再実行し、前後hash一致を確認した。以前のSource／失敗／full SHAと既存150 registry propertyの値を保持し、statefulGotoArgumentInvestigationを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。zipにはfixture Source／manifestと実測だけを含め、EXE／AWFB等をコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$entry.archive}|ConvertTo-Json -Depth 7|Set-Content "$r/stateful-goto-current-20261109.acceptance-record.json"
Get-Content "$r/stateful-goto-current-20261109.acceptance-record.json"
