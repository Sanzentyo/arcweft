$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$pin=Get-Content "$r/style-environment-integrated-20261109.cli-r1.main-before.json" -Raw|ConvertFrom-Json
$prefix=@'
struct GameState { started: bool }
enum GameEvent { Start }
fn initialize() -> GameState effects {} { GameState { started = false } }
fn reduce(state: &GameState, event: GameEvent) -> Result<Reduction<GameState>, ReducerError>
effects {} { Ok(Reduction.unchanged(state)) }
entry game @entry.main {
  state = GameState
  initializer = initialize
  event = GameEvent
  reducer = reduce
  goto @flow.main
}
'@
$manifest=@'
schema = 1
default-profile = "main"
[package]
id = "org.arcweft.samples.goto-stateful-probe"
version = "0.1.0"
[profiles.main]
kind = "game"
entry = "@entry.main"
source = "src/main.arcw"
'@
$rows=@(foreach($case in @(
    [pscustomobject]@{name='empty-control';body=''},
    [pscustomobject]@{name='self-goto';body='goto @flow.main'}
)){
    $fixture=Join-Path $r ('stateful-goto-current-20261109.'+$case.name)
    if(Test-Path $fixture){throw 'Probe epoch exists'}
    New-Item -ItemType Directory -Path "$fixture/src","$fixture/assets"|Out-Null
    [IO.File]::WriteAllText("$fixture/arcw.toml",$manifest,[Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText("$fixture/src/main.arcw",$prefix+[char]10+'flow main(state: GameState) { '+$case.body+' }'+[char]10,[Text.UTF8Encoding]::new($false))
    $artifact='D:/git/arcweft/target/arcweft/stateful-goto-current-'+$case.name+'.awfb'
    if(Test-Path $artifact){throw 'Original artifact epoch exists'}
    if((Get-FileHash $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw 'Pinned main changed'}
    & $pin.path check --manifest-path "$fixture/arcw.toml" --json *> ($fixture+'.check.log')
    $check=$LASTEXITCODE
    $bundle=$null
    if($check -eq 0){
        & $pin.path bundle --manifest-path "$fixture/arcw.toml" --profile main --output $artifact --json *> ($fixture+'.bundle.log')
        $bundle=$LASTEXITCODE
    }
    if((Get-FileHash $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw 'Pinned main changed'}
    $row=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();productionSource='ef2679347c14dccee649e5fb716d3a37510cac1f';name=$case.name;fixture=$fixture;sourceSha256=(Get-FileHash "$fixture/src/main.arcw").Hash.ToLowerInvariant();main=$pin;binaryDrift=0;checkExitCode=$check;bundleExitCode=$bundle;scope='Minimal same-signature stateful startup control vs self-transfer. No View/image/Style/sample-specific producer. Repository Source remains fixed.'}
    if($bundle -eq 0){$row.artifact=[ordered]@{path=$artifact;bytes=(Get-Item $artifact).Length;sha256=(Get-FileHash $artifact).Hash.ToLowerInvariant()}}
    $row|ConvertTo-Json -Depth 8|Set-Content ($fixture+'.json')
    $row
})
$rows|ConvertTo-Json -Depth 10|Set-Content "$r/stateful-goto-current-20261109.results.json"
$rows|ForEach-Object {[ordered]@{name=$_.name;checkExitCode=$_.checkExitCode;bundleExitCode=$_.bundleExitCode}}|ConvertTo-Json
