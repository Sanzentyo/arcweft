$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$publication=Get-Content -Raw "$root/scheme-instantiation.publication.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/scheme-instantiation.owner-validation.json"|ConvertFrom-Json
$baseline=Get-Content -Raw "$root/scheme-instantiation.owner-baseline.json"|ConvertFrom-Json
$original=Get-Content -Raw "$root/scoped-effect-consumers.owner-baseline.json"|ConvertFrom-Json
if($quality.Source -ne $publication.Source -or $quality.Tree -ne $publication.Tree -or $quality.Steps.Count -ne 4 -or @($quality.Steps|Where-Object {!$_.SourcePinsVerified -or ($_.Name -eq 'owner-run' -and $_.ExitCode -ne 100) -or ($_.Name -ne 'owner-run' -and $_.ExitCode -ne 0)}).Count){throw 'Owner step outcomes differ'}
foreach($step in $quality.Steps){
    if((Get-FileHash "$root/$($step.Output)" -Algorithm SHA256).Hash -ne $step.OutputSHA256 -or (Get-FileHash "$root/$($step.Log)" -Algorithm SHA256).Hash -ne $step.LogSHA256){throw 'Owner output changed'}
}
if((Get-FileHash "$root/$($baseline.TerminalPath)" -Algorithm SHA256).Hash -ne $baseline.TerminalSHA256 -or (Get-FileHash "$root/$($baseline.SummaryPath)" -Algorithm SHA256).Hash -ne $baseline.SummarySHA256){throw 'Intermediate baseline changed'}
$log=[IO.File]::ReadAllText("$root/scheme-instantiation.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1648 tests run: 1642 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Owner terminal summary differs'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1648\) (\S+) (.+)\r?$')|ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/scheme-instantiation.owner-list.json"|ConvertFrom-Json
$ids=@(foreach($suite in $listing.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Name+'$'+$case.Name}}})
if($ids.Count -ne 1648 -or $terminal.Count -ne 1648 -or @($terminal|Group-Object Id|Where-Object Count -GT 1).Count -or @(Compare-Object -CaseSensitive @($ids|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Owner selected and terminal IDs differ'}
$delta=@(Compare-Object -CaseSensitive @($baseline.Ids|Sort-Object) @($ids|Sort-Object))
if($delta.Count -ne 3 -or @($delta|Where-Object SideIndicator -CNE '=>').Count){throw 'Intermediate test IDs changed'}
$new=@($terminal|Where-Object {$delta.InputObject -ccontains $_.Id})
if($new.Count -ne 3 -or @($new|Where-Object Result -CNE 'PASS').Count){throw 'New scheme regressions did not pass'}
$overall=@(Compare-Object -CaseSensitive @($original.Ids|Sort-Object) @($ids|Sort-Object))
$removed=@($overall|Where-Object SideIndicator -CEQ '<='|ForEach-Object InputObject)
$added=@($overall|Where-Object SideIndicator -CEQ '=>'|ForEach-Object InputObject)
if($removed.Count -ne 1 -or $removed[0] -cne $original.RetiredId -or $added.Count -ne 7 -or @($terminal|Where-Object {$added -ccontains $_.Id -and $_.Result -cne 'PASS'}).Count){throw 'Combined test migration differs'}
$failed=@($terminal|Where-Object Result -CEQ 'FAIL'|ForEach-Object Name|Sort-Object)
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Actual owner failures changed'}
$structure=Get-Content -Raw "$root/scheme-instantiation.structure.json"|ConvertFrom-Json
if($structure.Source -ne $publication.Source -or $structure.ExitCode -ne 0 -or (Get-Content -Raw "$root/scheme-instantiation.structure.stdout") -notmatch '(?m)^blocking violations: 0\r?$'){throw 'Canonical structural gate differs'}
$metrics=Import-Csv "$root/scheme-instantiation.structure/file_metrics.csv"
$measurements=@(foreach($p in $publication.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($publication.Source):$($p.Path)") -ne $p.Blob){throw 'Published input changed'}
    $row=@($metrics|Where-Object path -CEQ $p.Path)
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    if($row.Count -ne 1 -or [int]$row[0].physical_lines -ne $lines -or [long]$row[0].bytes -ne (Get-Item -LiteralPath $p.Path).Length){throw 'Canonical source measurement differs'}
    $old=@(git show "$($publication.ChangeBase):$($p.Path)" 2>$null);$baseLines=if($LASTEXITCODE -eq 0){$old.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=[long]$row[0].bytes;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '(^|/)tests(/|\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=[int]$row[0].embedded_test_lines;SHA256=$p.SHA256;Blob=$p.Blob}
})
if($measurements.Count -ne 20 -or (git rev-parse HEAD) -ne $publication.Source -or (git rev-parse 'HEAD^{tree}') -ne $publication.Tree -or @(git diff --name-only HEAD).Count){throw 'Final published source identity differs'}
$reverse=Get-Content -Raw "$root/scheme-instantiation.reverse-reuse.json"|ConvertFrom-Json
if($reverse.CurrentSource -ne $publication.Source -or $reverse.Packages.Count -ne 22 -or !$reverse.CargoInputDiffEmpty -or $reverse.NewExecution){throw 'Reverse graph reuse differs'}
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/scheme-instantiation.owner-terminal.json"
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Parent=$publication.Parent;ChangeBase=$publication.ChangeBase;Selected=1648;Passed=1642;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;IdsEqual=$true;Duplicates=0;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);SlowTests=if($summary.Groups['slow'].Success){[int]$summary.Groups['slow'].Value}else{0};Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewSchemeTests=$new.Name;OverallAdded=$added;OverallRetired=$removed;IntermediateBaseline=$baseline.Source;ClippyExit=0;FmtExit=0;StructureExit=0;BlockingViolations=0;SourcePinsVerified=$true;FullOwnerOnly=$true;Measurements=$measurements;DependencyMetrics=(Import-Csv "$root/scheme-instantiation.structure/package_metrics.csv"|Where-Object package -CEQ 'arcweft-lang-sema');ReverseReuse=$reverse}|ConvertTo-Json -Depth 10|Set-Content -Encoding utf8 "$root/scheme-instantiation.owner-summary.json"
Get-Content -LiteralPath "$root/scheme-instantiation.owner-summary.json" -TotalCount 18
