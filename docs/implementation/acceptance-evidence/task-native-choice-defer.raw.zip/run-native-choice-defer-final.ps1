$ErrorActionPreference='Stop'
$t=$PSScriptRoot
$stem="$t/native-choice-defer-20261107.final"
$freeze=Get-Content -Raw -LiteralPath "$stem.source-freeze.json" | ConvertFrom-Json
$runs=@(
    @{name='reverse-list';args=@('nextest','list','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli','-E','rdeps(=arcweft-core)','--message-format','json')},
    @{name='reverse';args=@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli','-E','rdeps(=arcweft-core)','--no-tests','fail','--no-fail-fast')},
    @{name='reverse-list-repeat';args=@('nextest','list','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli','-E','rdeps(=arcweft-core)','--message-format','json')},
    @{name='reverse-repeat';args=@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli','-E','rdeps(=arcweft-core)','--no-tests','fail','--no-fail-fast')},
    @{name='reverse-list-final';args=@('nextest','list','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli','-E','rdeps(=arcweft-core)','--message-format','json')},
    @{name='cli-unit-list';args=@('nextest','list','--locked','-p','arcweft-cli','--lib','--bins','--message-format','json')},
    @{name='cli-unit';args=@('nextest','run','--locked','-p','arcweft-cli','--lib','--bins','--no-tests','fail','--no-fail-fast')},
    @{name='cli-integration-list';args=@('nextest','list','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens','--message-format','json')},
    @{name='cli-integration';args=@('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens','--no-tests','fail','--no-fail-fast')},
    @{name='workspace-check';args=@('check','--locked','--workspace','--all-targets','--all-features')},
    @{name='workspace-clippy';args=@('clippy','--locked','--workspace','--all-targets','--all-features')}
)
$failures=0
foreach($run in $runs){
    if ($env:ARCWEFT_CHOICE_RUNS -and $run.name -notin ($env:ARCWEFT_CHOICE_RUNS -split ',')) {continue}
    $drift=@($freeze.paths | Where-Object {(Get-FileHash -LiteralPath $_.path).Hash -ine $_.sha256})
    if($drift.Count){throw 'Source drift before validation'}
    $log="$stem.$($run.name).log"
    $started=[DateTime]::UtcNow.ToString('o')
    $argsForCargo=$run.args
    cargo @argsForCargo *> $log
    $code=$LASTEXITCODE
    $drift=@($freeze.paths | Where-Object {(Get-FileHash -LiteralPath $_.path).Hash -ine $_.sha256})
    $summary=@(Select-String -LiteralPath $log -Pattern '^\s*(Summary\s+\[|Finished .+ profile)' | ForEach-Object {$_.Line.Trim()})
    [ordered]@{version=1;head=$freeze.head;exitCode=$code;inputs=$freeze.paths.Count;sourceDrift=$drift.path;
        summary=$summary;command=@('cargo')+$argsForCargo;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$stem.$($run.name).receipt.json"
    Write-Output "$($run.name) exit=$code $summary"
    if($drift.Count){throw 'Source drift during validation'}
    if($code){
        $failures++
        rg -n -A 5 '^error|panicked at|Summary' $log | Select-Object -Last 25
    }
}
if($failures){exit 1}
