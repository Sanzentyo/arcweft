param([Parameter(Mandatory)][string]$Commit)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSCommandPath
$exe=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
if ((git rev-parse HEAD) -ne $Commit) { throw 'CLI validation revision differs.' }
$binary=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
$prior=Get-Content -LiteralPath (Join-Path $root 'nested-header-effects.dev03-prior-cli.json') -Raw | ConvertFrom-Json
if ($binary -eq $prior.sha256) { throw 'The CLI executable still matches the pre-fix build.' }
$ordinary=Get-Content -LiteralPath (Join-Path $root 'shared-effect-tables.dev03-cli-default.json') -Raw | ConvertFrom-Json
$aot=Get-Content -LiteralPath (Join-Path $root 'shared-effect-tables.dev03-aot-three-callbacks.json') -Raw | ConvertFrom-Json
$rows=@(@($ordinary.runs)+@($aot.cases))
if ($rows.Count -ne 14) { throw 'Expected 14 historical executor runs.' }
$outcomes=@(
    foreach ($row in $rows) {
        $arguments=[string[]]$row.args
        $execIndex=[array]::IndexOf($arguments,'--executor')
        if ($execIndex -lt 0) { throw 'Missing executor.' }
        $executor=$arguments[$execIndex+1]
        $expectedHash=$row.input_sha256 ?? $row.fixture_sha256
        $inputHash=(Get-FileHash -LiteralPath $arguments[1] -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($inputHash -ne $expectedHash) { throw ('Source fixture changed: '+$row.name) }
        $stepsIndex=[array]::IndexOf($arguments,'--steps')
        if ($stepsIndex -lt 0) { throw 'Missing observation limit.' }
        $arguments[$stepsIndex+1]='256'
        $priorStdout=$row.stdout
        if ($row.name -eq 'third-three-callback' -and $executor -eq 'awbc-product') {
            $priorStdout='shared-effect-tables.dev03-third-three-callback-awbc-terminal.stdout.log'
        }
        $priorOutput=Get-Content -LiteralPath (Join-Path $root $priorStdout) -Raw | ConvertFrom-Json
        $prefix='nested-header-effects.dev03-cli-'+$row.name+'-'+$executor
        $stdout=Join-Path $root ($prefix+'.stdout.log')
        $stderr=Join-Path $root ($prefix+'.stderr.log')
        & $exe @arguments 1> $stdout 2> $stderr
        $exit=$LASTEXITCODE
        if ($exit -ne 0) { throw ('CLI failed: '+$row.name+' '+$executor+' '+$exit) }
        $actual=Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json
        $maxOps=($actual.steps.stats.executed_ops | Measure-Object -Maximum).Maximum
        $diagnosticSteps=@($actual.steps | Where-Object { $_.stats.diagnostics -gt 0 -or $_.diagnostics.Count -gt 0 -or $_.assertion_failures.Count -gt 0 -or $_.assertion_diagnostics.Count -gt 0 }).Count
        $expectedLogs=@($priorOutput.steps[-1].observations.logs | ForEach-Object message)
        $actualLogs=@($actual.steps[-1].observations.logs | ForEach-Object message)
        $sameLogs=(ConvertTo-Json -InputObject $expectedLogs -Compress) -ceq (ConvertTo-Json -InputObject $actualLogs -Compress)
        $expectedStatus='done Return("42")'
        if ($priorOutput.final_status -cne $expectedStatus -or $actual.final_status -cne $expectedStatus -or $actual.steps.Count -ne $priorOutput.steps.Count -or $maxOps -ne 1 -or $diagnosticSteps -ne 0 -or -not $sameLogs) {
            throw ('CLI output or work limit changed: '+$row.name+' '+$executor)
        }
        @{name=$row.name; executor=$executor; input_sha256=$inputHash; args=$arguments; exit=$exit; steps=$actual.steps.Count; final_status=$actual.final_status; max_ops=$maxOps; diagnostic_steps=$diagnosticSteps; logs=$actualLogs; prior_stdout=$priorStdout; stdout=[IO.Path]::GetFileName($stdout); stderr=[IO.Path]::GetFileName($stderr)}
    }
)
@{version=1; source=$Commit; binary_sha256=$binary; runs=$outcomes; finished=(Get-Date -Format o)} | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $root 'nested-header-effects.dev03-cli-callbacks.json') -Encoding utf8NoBOM
$outcomes | ForEach-Object { '{0} {1}: {2}, {3} steps' -f $_.name,$_.executor,$_.final_status,$_.steps }



