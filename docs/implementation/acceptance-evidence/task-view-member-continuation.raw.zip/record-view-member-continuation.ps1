$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$source=Read-Record 'checkpoint-view-member-continuation-20261105.verified'
$sample=Read-Record 'checkpoint-showcase-typed-policies-20261105.verified'
$runtime=Read-Record 'view-member-continuation-syntax2-20261105.runtime.terminal-audit'
$check=Read-Record 'view-member-continuation-syntax-quality2-20261105-check'
$clippy=Read-Record 'view-member-continuation-syntax-quality2-20261105-clippy'
if((git rev-parse HEAD).Trim() -ne $source.commit -or $runtime.passed -ne 743 -or $runtime.failed -ne 0 -or $check.exitCode -ne 0 -or $clippy.exitCode -ne 0){throw 'Unexpected published source/results'}
$attempts=@(foreach($stem in @('rich-text-showcase-compiler1-20261105','rich-text-showcase-origin-trace1-20261105','rich-text-showcase-origin-trace2-20261105','rich-text-showcase-origin-trace3-20261105','rich-text-showcase-rejection-trace1-20261105','rich-text-showcase-variant-trace1-20261105','rich-text-showcase-expectation-trace1-20261105','rich-text-showcase-compiler2-20261105','rich-text-showcase-compiler3-20261105','view-node-modifiers-showcase1-20261105','view-node-modifiers-showcase2-20261105','view-node-modifiers-showcase3-20261105','view-node-modifiers-showcase4-20261105','view-node-modifiers-call-origin1-20261105','view-node-modifiers-call-origin2-20261105','view-node-modifiers-showcase5-20261105','view-node-modifiers-showcase6-20261105','view-member-continuation-syntax1-20261105','view-member-continuation-syntax2-20261105')){
 $terminal="$taskTemp/$stem.runtime.terminal-audit.json"
 if(Test-Path -LiteralPath $terminal){[ordered]@{run=$stem;runtime=Read-Record "$stem.runtime.terminal-audit"}}
 elseif(Test-Path -LiteralPath "$taskTemp/$stem.catalog.json"){[ordered]@{run=$stem;catalog=Read-Record "$stem.catalog";runtime='not run: catalog failed'}}
 else{throw "Missing attempted run $stem"}
})
. "$taskTemp/convergence-image-git-bytes.ps1"
$pending=@(Get-Content -LiteralPath "$taskTemp/checkpoint-view-member-continuation-20261105.other.txt")
$patch=Read-GitBytes (@('diff','--binary','--full-index','--')+$pending)
[IO.File]::WriteAllBytes("$taskTemp/view-node-properties-pending-20261105.patch",$patch)
$files=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
 $_.Name -match '^(rich-text-showcase-|view-node-modifiers-|view-member-continuation-|view-node-properties-pending-|cli-rag-multiple-source-probe|checkpoint-showcase-typed-policies-|checkpoint-view-member-continuation-|view-modifier-sema-check1-)' -and $_.Extension -in @('.json','.log','.arcw','.patch','.txt','.pathspec')
})
$files+=@(Get-Item -LiteralPath "$taskTemp/record-view-member-continuation.ps1","$taskTemp/run-cli-presentation-quality.ps1","$taskTemp/run-presentation-projection-owner.ps1","$taskTemp/audit-nextest-final-result.ps1")
. "$taskTemp/write-verified-evidence-archive.ps1"
$rawPath='docs/implementation/acceptance-evidence/task-view-member-continuation.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$before=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('viewNodeProperties')){throw 'Preserve existing evidence'}
$record.viewNodeProperties=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');state='Syntax continuation owner validated and published; remaining static View properties and Source Style identity integration are active, unaccepted implementation work.'
 sampleCheckpoint=$sample
 sampleCorrection='Use dialogue.character.display_name and compose text/ruby through rich_text_style(text=text_style(...),ruby=ruby_style(...)); remove two look requests with no registered Character manifest. Preserve all6 dialogue bodies, IDs, fonts, Fx and numerical parameters. This checkpoint explicitly retained the failing View compile condition.'
 correctionOfIntermediateAssumption='The temporary flat text_style(ruby_size=...,ruby_gap=...) rewrite was incorrect: the current Source API retains rich_text_style(text,ruby) composition. Flat property storage does not imply flat Source factory arguments. Preserve the failed original, probe and compiler attempts; do not describe rich_text_style/ruby_style as removed.'
 syntaxSource=$source;runtime=$runtime;command=(Read-Record 'view-member-continuation-syntax2-20261105.runtime').command
 quality=[ordered]@{check=$check;clippy=$clippy};scope='743/743 Syntax library cases, no skips, 29.867s;4110 source inputs/case/EXE drift0. LF/CRLF, comments and empty lines, root/nested View chains, explicit semicolon termination, missing-member diagnostic/recovery and following declaration retention. All-target/all-feature/locked Syntax check/Clippy exit0; warnings remain.'
 syntaxDecision='The shared statement boundary owns leading-dot newline continuation. Remove the root-only View terminator, which also incorrectly joined across semicolons. Advance over continued trivia once so a long run of empty/comment lines does not cause quadratic rescanning.'
 attempts=$attempts
 diagnosticBuild='view-modifier-sema-check1-20261105 exited101 for a non-exhaustive new consumer match. Source was edited during this diagnostic build; it is not frozen validation evidence. Subsequent catalog/runtime attempts have their own frozen receipts.'
 concreteRemainingEvidence=@('Before the new typed property implementation, Panel(part=dialogue_panel) was rejected at Source572..586.','After adding property schemas, nested newline .x was still a ShortVariant; the published parser cut repairs that root.','The x method was rejected with a declared Named(Length) because standard method schemas were created before scalar registration. The pending registry change completes all View modifier signatures after the full standard environment is populated.','Latest showcase6 rejects EntityReference Absolute(style.rich_text_panel), Source897..919, ValueResolutionFailed owner82. HIR symbol/table/retained.rs explicitly excludes HirItemKind::Style, while Compiler style lowering independently publishes the Style product. Style must join the shared declaration identity authority, not a fallback lookup or Source parser.','showcase6:4 executed,2PASS2FAIL919skip; missing-member recovery test first exposed the absent diagnostic, subsequently repaired in the separate743-case Syntax runs. The sample compile failure remains outstanding.')
 pending=[ordered]@{paths=$pending;patchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant();state='Uncommitted, not accepted production implementation. Frozen historical patch retained for continuation; final design and consumer migration are still being completed.'}
 notClaimed='No passing RAG multi-source case, sample main-profile check, full reverse-dependency run, fresh workspace quality/structure, Native/AWBC product or image parity is claimed for the pending View changes. Earlier full7140/14FAIL, CLI700/14FAIL and the later z-index3PASS remain independent actual results. Generic Match and all other accepted feature boundaries remain accepted.'
 workingTree='Original12 tracked WIP patch SHA25646402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac preserved by publication checks; original6 untracked files retained.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$needle='| DialogueViewの複数投影／pure program／handler |'
$newRow='| member chainの改行継続・不正memberの診断 | **Syntax ownerを検証・公開済み。新しい共有Sourceのconsumer検証は継続中** | Source '+$source.commit+'。共通のstatement境界で改行後の`.`を前の式へ接続し、nested View子blockでも同じSelectを保持する。root専用の重複scannerを除去し、明示`;`は必ず終了する。LF／CRLF・コメント／空行・回復／後続宣言を含むSyntax全743／743 PASS、0 skipped、29.867秒。Syntax check／Clippy終了0、4110 source／case／EXE drift0。Style参照と静的View propertyの実装は別に未受入であり、sample／RAG成功や全consumer完了とは扱わない。[実測・失敗・公開SHA・raw](acceptance-evidence/task-rich-text-property-identity.json)。 |'
if(-not $status.Contains($needle)){throw 'Current owner row not found'}
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith($needle)){$newRow;$line}
 elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){$line.Replace('後続のCLI owner修復を継続','後続のCLI owner修復と、新しいSyntax／静的View変更のconsumer検証を継続')}
 else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$append=@"

## 2026-11-05 — Shared member-chain boundaries and ongoing typed View properties

- Sample checkpoint $($sample.commit) corrects the nested DialogueView character projection and composed text/ruby policies. Remove only unregistered look requests; all6 bodies, IDs, fonts, Fx and numerical values remain. The intermediate flat Source factory rewrite was mistaken and was corrected; failed probes and compiler attempts are retained.
- Syntax Source $($source.commit) moves leading-dot continuation to the shared statement boundary, removes the root-only duplicate scanner and retains explicit semicolon termination. Missing member access receives a precise insertion diagnostic and typed recovery. Continued trivia is consumed once, avoiding quadratic rescanning. Final743/743PASS0skip29.867s;4110 source/case/EXE drift0; all-target/all-feature/locked Syntax check/Clippy exit0 with warnings. Earlier Syntax run743PASS28.372s is a separate input, not a combined run.
- The new regression exposed independent missing View contracts. Before the parser fix, nested .x parsed as ShortVariant. New method schemas initially retained Named(Length); the pending registry completes all modifier signatures after standard type population. Latest showcase6 is4executed/2PASS2FAIL/919skip: its sample still fails ValueResolutionFailed on the exact Style entity reference at Source897..919. HIR retained symbol publication excludes Style, despite its generated Style product. Finish that shared identity integration and property consumers; do not add a fallback Style resolver or remove presentation to make RAG pass.
- All catalog/runtime failures, diagnostics, source pins, published full SHAs and the explicitly unaccepted pending patch are retained in [the existing task record](acceptance-evidence/task-rich-text-property-identity.json). No full reverse run, fresh workspace quality/structure or sample/RAG/runtime/parity success is claimed for the pending changes. Preserve the actual earlier full7140/14FAIL, CLI700/14FAIL, separate z-index3PASS, and accepted Generic Match status. [Current state has one list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous evidence changed'}}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history))){throw 'History changed'}
[ordered]@{source=$source.commit;runtime=$runtime.summary;priorFieldDrift=0;historyPrefixDrift=0;raw=$record.viewNodeProperties.raw}|ConvertTo-Json -Depth 5
