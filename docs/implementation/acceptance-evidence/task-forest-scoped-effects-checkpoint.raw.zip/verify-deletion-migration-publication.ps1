param([string] $ManifestPath, [string] $ReceiptPath)
$ErrorActionPreference = 'Stop'
$manifest = Get-Content -Raw -LiteralPath $ManifestPath | ConvertFrom-Json
$source = (& git rev-parse HEAD).Trim()
$remote = ((& git ls-remote origin refs/heads/main) -split '\s+')[0]
if ($remote -ne $source) { throw 'Published source mismatch' }
$verified = @($manifest.paths | ForEach-Object {
    $file = $_
    if($file.deleted){
        if(Test-Path -LiteralPath $file.path){throw 'Deleted working file exists'}
        if(@(git ls-tree $source -- $file.path).Count){throw 'Deleted published blob exists'}
        $baseBlob=(git rev-parse ($manifest.base+':'+$file.path)).Trim()
        if($baseBlob -ne $file.baseBlob){throw 'Deletion base blob mismatch'}
        return @{path=$file.path; deleted=$true; publishedAbsent=$true; workingAbsent=$true; baseBlob=$baseBlob}
    }
    $blob = (& git rev-parse ($source + ':' + $file.path)).Trim()
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = 'git'
    $start.Arguments = 'cat-file blob ' + $blob
    $start.WorkingDirectory = 'D:\git\arcweft'
    $start.UseShellExecute = $false
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = [Diagnostics.Process]::Start($start)
    $hash = [Security.Cryptography.SHA256]::Create()
    try {
        $published = ([BitConverter]::ToString($hash.ComputeHash($process.StandardOutput.BaseStream))).Replace('-', '').ToLowerInvariant()
        $process.WaitForExit()
        if ($process.ExitCode -ne 0) { throw $process.StandardError.ReadToEnd() }
    } finally { $hash.Dispose(); $process.Dispose() }
    $working = (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($working -ne $file.sha256 -or $published -ne $file.sha256) { throw "Input mismatch: $($file.path)" }
    @{ path = $file.path; sha256 = $file.sha256; publishedSha256 = $published; blob = $blob }
})
$receipt = @{ base = $manifest.base; source = $source; remote = $remote; verifiedAt = (Get-Date).ToString('o'); command = $manifest.command; manifestSha256 = (Get-FileHash -LiteralPath $ManifestPath -Algorithm SHA256).Hash.ToLowerInvariant(); paths = $verified; evidenceReuse = 'Precommit validation input and published bytes verified; no postcommit test rerun.' }
if (Test-Path -LiteralPath $ReceiptPath) { throw 'Receipt already exists' }
[IO.File]::WriteAllText($ReceiptPath, ($receipt | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
@{ source = $source; remote = $remote; verified = $verified.Count } | ConvertTo-Json
