$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-recursion-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$old=ArcJson (Join-Path $d 'baseline.receipt.json')
$typed=ArcJson (Join-Path $d 'typed-growth.receipt.json')
$q=ArcJson (Join-Path $d 'quality.receipt.json')
if($old.cliSha256 -ne $typed.cliSha256 -or $old.source -ne $typed.source){throw 'Baseline CLI differs'}
git diff --quiet $old.source $q.base -- 'crates/**' Cargo.toml Cargo.lock
if($LASTEXITCODE){throw 'Baseline code differs from the reviewed parent'}
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($sha -ne $q.cliSha256 -or $sha -eq $old.cliSha256){throw 'Expected the revised exact CLI'}
foreach($row in $q.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
$inputs=@($old.cases|Where-Object {$_.name -match '^recursion-(?:type|value)-'})+@($typed.cases)
function ReadArcCase($row,$command){
    $name=$row.name
    $src=Join-Path $d "$name.arcw"
    if((ArcSha $src) -ne $row.inputSha256 -or $row.stage -ne 'type-check'){throw "Baseline source differs $name"}
    $out=Join-Path $d "$name.$command.after.json"
    $err=Join-Path $d "$name.$command.after.stderr.log"
    if($command -eq 'verify'){
        & $cli verify $src --mode test --backend emit --json > $out 2> $err
    }else{
        & $cli check $src --json > $out 2> $err
    }
    $exit=$LASTEXITCODE
    $report=ArcJson $out
    $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
    $code,$span=if($name -match '-owned(?:-typed)?$'){'sema.lifetime.promotion_execution',"callback.promote('flow)"}else{'sema.lifetime.promotion_receiver','callback'}
    if($exit -ne 1 -or $report.stage -ne 'type-check' -or $report.status -ne 'denied' -or $diagnostics.Count -ne 1 -or $diagnostics[0].code -ne $code -or $report.obligations -or $report.solver_checks){throw "Unexpected $name $command result $($diagnostics.code -join ',')"}
    $range=$diagnostics[0].span
    $sourceSpan=(Get-Content -Raw -LiteralPath $src).Substring($range.start,$range.end-$range.start)
    if($sourceSpan -cne $span){throw "Unexpected $name span $sourceSpan"}
    [ordered]@{name=$name;command=$command;stage=$report.stage;exit=$exit;code=$code;span=$sourceSpan;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
}
$rows=@(foreach($row in $inputs){
    ReadArcCase $row 'check'
    if($row.name -in 'recursion-type-third','recursion-value-third','recursion-growing-owned-typed'){ReadArcCase $row 'verify'}
})
if($rows.Count -ne 13 -or (ArcSha $cli) -ne $sha){throw 'Revised CLI result differs'}
[ordered]@{version=1;base=$q.base;cliSha256=$sha;cases=$rows}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
$rows|ForEach-Object {[pscustomobject]$_}|Format-Table name,command,code,span
exit 0
