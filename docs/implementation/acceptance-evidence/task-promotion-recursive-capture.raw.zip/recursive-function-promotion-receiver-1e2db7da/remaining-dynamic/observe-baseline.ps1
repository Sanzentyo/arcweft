$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-dynamic-20261110'
$prior=Join-Path $env:TEMP 'arcweft-promotion-recursion-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$deadline=[DateTime]::UtcNow.AddMinutes(12)
do {
    $q=ArcJson (Join-Path $prior 'quality.receipt.json')
    $stage=@($q.results|Where-Object name -eq 'cli-build')
    if($stage.Count){break}
    if([DateTime]::UtcNow -ge $deadline -or (!$q.active -and !$q.remaining)){throw 'Validated CLI build did not become available'}
    Start-Sleep -Seconds 4
} while($true)
if($stage.Count -ne 1 -or $stage[0].exitCode){throw 'CLI build failed'}
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($sha -ne $q.cliSha256){throw 'Baseline CLI bytes differ'}
foreach($row in $q.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
$rows=@(foreach($src in Get-ChildItem -LiteralPath $d -Filter 'dynamic-*.arcw'|Sort-Object Name){
    $out=Join-Path $d ($src.BaseName+'.before.json')
    $err=Join-Path $d ($src.BaseName+'.before.stderr.log')
    & $cli check $src.FullName --json > $out 2> $err
    $code=$LASTEXITCODE
    $r=ArcJson $out
    [ordered]@{name=$src.BaseName;stage=$r.stage;exit=$code;codes=@($r.diagnostics|ForEach-Object {$_.diagnostic.code});messages=@($r.diagnostics|ForEach-Object {$_.diagnostic.message});inputSha256=ArcSha $src.FullName;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
if((ArcSha $cli) -ne $sha -or $rows.Count -ne 6){throw 'Baseline changed'}
[ordered]@{version=1;base=$q.base;validatedInputs=$q.inputs;cliSha256=$sha;cases=$rows}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'baseline.receipt.json') -Encoding utf8
$rows|ForEach-Object {[pscustomobject]$_}|Format-Table name,stage,exit,codes
exit 0
