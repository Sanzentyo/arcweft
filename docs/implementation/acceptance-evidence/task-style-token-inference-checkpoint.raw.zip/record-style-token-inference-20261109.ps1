$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-token-inference-20261109.source-checkpoint.verified.json'
$owner=Read-Record 'style-token-inference-20261109.owner-r1.runtime.terminal-audit.json'
$quality=@(foreach($gate in @('check','clippy','structure','fmt')){Read-Record "style-token-inference-20261109.quality.$gate.receipt.json"})
$finalLint=Read-Record 'style-token-inference-20261109.final-lint.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit -or $owner.actualExitCode -ne 0 -or $owner.executed -ne 50 -or @($quality|Where-Object exitCode -ne 0).Count -or $finalLint.exitCode -ne 0){throw 'Source or checks changed'}
$review=Read-Record 'style-token-inference-20261109.owner-review.json'
foreach($p in $review.paths){$p.bytes=(Get-Item -LiteralPath $p.path).Length;$p.physicalLoc=@(Get-Content -LiteralPath $p.path).Count}
$review|ConvertTo-Json -Depth 8|Set-Content "$r/style-token-inference-20261109.owner-review.json"
$archive='docs/implementation/acceptance-evidence/task-style-token-inference-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(Get-ChildItem -LiteralPath $r -File -Filter 'style-token-inference-20261109*'|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')})
$files+=@('run-style-token-inference-owner-20261109.ps1','run-style-token-inference-quality-20261109.ps1','run-style-token-inference-consumers-20261109.ps1','run-style-token-inference-cli-consumers-20261109.ps1','record-style-token-inference-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';publication=$pub;status='Sheet-local unannotated Style token inference implemented, owner-verified and published; complete consumer runtime execution remains pending.'
 model='One shared Source grammar owns all fifteen factory signatures, argument-slot binding, exact numeric parsing, native enum construction and sequence element roles. Checking and inference use that authority; remove former private composite signatures and duplicated primitive parsing. Plain numeric and enum forms retain finite native-kind candidates; explicit annotations and actual property/factory-operand uses constrain them. Unannotated aliases propagate equality through original sheet-local declaration identities. Use a monotone work queue, not recursive/quadratic rescans or name-prefix guesses. Publish inferred expectations only when every domain is unique; ordinary checking validates every original initializer and final native payload. Do not fabricate HIR annotations, expression IDs or runtime values.'
 invariants='Principal Length kinds remain Length under contextual uniform-radii conversion. Reject ambiguous unused values, incompatible uses, unresolved cycles, wrong sheet names and invalid ranges/precision/suffixes. Compact domains are statically checked against the native tag inventory; bind preflights arity before allocating. Native value/cascade/codec ownership, Cargo edges, I/O, unsafe and all contract markers remain unchanged.'
 owner=$owner;ownerToQualityScope=(Read-Record 'style-token-inference-20261109.owner-to-quality-scope.json')
 quality=$quality;finalLint=$finalLint;finalFmt=(Read-Record 'style-token-inference-20261109.final-fmt.json')
 graph=(Read-Record 'style-token-inference-20261109.graph.json');reverseDependencyTree=(Read-Record 'style-token-inference-20261109.tree-invert.json');ownerReview=$review
 scope='Owner snapshot: 50/50 pass, 2559 filter skips, 3917 inputs/catalog/EXE drift0. Then add one grammar arity-before-allocation guard; all 98 workspace packages pass locked/all-target/all-feature check and Clippy, structure and fmt. Final inference-only lint correction widens a constant comparison and uses is_power_of_two without changing behavior; Sema all-target/all-feature Clippy and explicit fmt pass. Final complete Sema consumer execution (22 packages, nonCLI all-features 21 and CLI defaults 1) is pending; do not claim owner50 is that matrix.'
 pending='Complete final Sema consumer execution, Environment Source publication, remaining sample migration and actual Native/Web operation/capture parity. Prior explicit construction acceptance, Generic Match and other completed functions remain accepted.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 146 -or $prior.PSObject.Properties.Name -contains 'styleTokenInferenceCheckpoint'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "styleTokenInferenceCheckpoint": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$styleRow='| Style 指定値・token・構築処理 | **明示型付き構築の統合受入を維持。未annotation推論をowner検証・公開** | 推論Source '+$pub.commit+'。既存の構築・引数・数値・enum文法を共有し、元sheetの注釈／実利用からnative kindを絞る。forward aliasは単調queueで伝播し、名前prefixから推測しない。全domainが一意になってから期待型を公開し、元initializerの値を通常checkerで検証する。全25 kind・最大64段alias・曖昧／矛盾／別sheet拒否・元HIRにannotationを作らない条件をowner50件で確認した。以後の引数数preflightと集合判定整理、workspace品質は下行と原本に分離。最終SourceのSema逆依存22 package実行は継続する。明示型付き構築／token合成の既受入と前回View consumer結果は保持する。残る実装範囲はEnvironment、残るsampleと実Native／Web操作／表示。[全SHA・実測・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$qualityRow='| workspace check／Clippy・fmt・構造gate | **Style推論のworkspace gateは終了0** | Source '+$pub.commit+'。owner後のgrammar引数数preflightを含む全98 package・全target・全feature・locked check／Clippy、構造gate、fmtが終了0（3917入力drift0、警告あり）。後続のinference.rsだけの集合判定整理は、意味を変えずSema全target／feature Clippyと明示11 Rust pathのfmtで確認した。前回の構築Sourceの品質・全View consumer実測も履歴に保持する。[gate・差分範囲・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status=(@($status -split $lf|ForEach-Object {
 if($_.StartsWith('| Style 指定値・token・構築処理 ')){$styleRow}
 elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate ')){$qualityRow}
 elseif($_.StartsWith('| 共有契約／推移的逆依存matrix ')){$_.Replace('**新規5388実行：','**前回View範囲5388実行：')}
 elseif($_.StartsWith('確認日 ')){$_.Replace('eb4b9a820e7e74a106e4ca17405e50b642cb579b',$pub.commit)}
 else{$_}
})) -join $lf
if(($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — 未annotation Style tokenの型推論

Source $($pub.commit) をmainへ通常公開し、parent／tree／12 pathのblobとpatchを照合した。構築signature・引数slot binding・数値／enum判定・sequence roleを一つのSource文法へ移し、旧composite schemaと重複parserを削除した。注釈なしtokenは文法由来のnative kind候補と元sheetの実利用を照合し、unannotated aliasの等式制約を単調queueで伝播する。Source名prefixや普通のruntime型にfallbackせず、曖昧／矛盾／未解決cycleを拒否する。principal LengthはRadii文脈の変換で再分類しない。全domainが一意になるまで期待型を公開せず、通常checkerが元initializerを検証する。HIR annotationやExprId、runtime値を作っていない。

最初のdev checkはpath属性経由の子module探索先が異なり3 compile errorで停止し、明示child pathへ修正した。次のSema／Compiler tests checkは終了0。owner50件が全PASS・2559 filter SKIP・5.080秒で、3917入力／catalog／実EXE差分0。全25種類、typed useと別sheet同名、64段forward alias、曖昧値と衝突の拒否、元HIRが無annotationのままという条件を確認した。その後の変更はgrammarの引数数preflight（割当前に拒否）1 pathで、workspace gateに含めた。さらにinference.rsのconstant比較とsingleton判定だけをlint整理し、意味を変えていない。これらの差分scopeを分離し、owner50件を最終全consumer実行と記さない。

全98 workspaceのlocked／all-target／all-feature check・Clippy、構造gate、fmtが終了0。最終Sema all-target／all-feature Clippyと明示11 Rust pathのfmtも終了0。今回のproduction ownerはprivate Source文法／SemaとCompiler testsなので、metadata／target-all tree一致のSema逆依存22 package（非CLI全feature21＋CLI既定1）を次に実行する。前回のnative componentを含むView逆依存41 packageの実測と受入は保ち、今回実行済みとは記さない。Environment、sample移行、実Native／Webと既知CLI4条件は別の未達として保持する。Generic Match等の完了を戻さない。

現状一覧の未annotation推論を実装未達からowner検証・公開へ更新した根拠は今回のSourceと実測である。全consumerはpendingとして明記し、過去のSource／失敗／full SHAを保持した。既存146 registry propertyの値を全件照合して保持し、styleTokenInferenceCheckpointを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。build artifactをZIPへコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;owner=$owner.summary;archive=$entry.archive}|ConvertTo-Json -Depth 6|Set-Content "$r/style-token-inference-20261109.acceptance-record.json"
Get-Content "$r/style-token-inference-20261109.acceptance-record.json"

