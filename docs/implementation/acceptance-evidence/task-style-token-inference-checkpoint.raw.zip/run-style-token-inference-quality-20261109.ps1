$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$stem="$r/style-token-inference-20261109.quality"
if(Test-Path ($stem+'.source.json')){throw 'Quality epoch exists'}
$new=@('crates/arcweft-lang-sema/src/final_analysis/analyzer/style/grammar.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/style/inference.rs','crates/arcweft-compiler/tests/view_product/style_inference.rs')
$paths=@((git ls-files -- '*.rs' '*.toml' '*.lock' '*.json' '*.stderr' '*.arcw' '*.awfagent' 'rust-toolchain*' '.cargo/*')|Where-Object {$_ -notlike 'docs/*'})
$paths=@($paths+$new|Sort-Object -Unique)
$source=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();inputs=@(foreach($p in $paths){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})}
$source|ConvertTo-Json -Depth 8|Set-Content ($stem+'.source.json') -Encoding utf8
function Assert-Inputs {foreach($row in $source.inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
function Invoke-Quality([string]$name,[string[]]$arguments){
    Assert-Inputs
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> ($stem+".$name.log")
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$source.base;command=$arguments;exitCode=$code;sourceInputs=$source.inputs.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content ($stem+".$name.receipt.json") -Encoding utf8
    if($code -ne 0){throw ('Quality failed: '+$name)}
}
Invoke-Quality 'metadata' @('metadata','--locked','--all-features','--format-version','1')
$m=Get-Content ($stem+'.metadata.log') -Raw|ConvertFrom-Json -Depth 100
$root=@($m.packages|Where-Object name -eq 'arcweft-lang-sema')
if($root.Count -ne 1){throw 'Missing exact Style value owner'}
$closure=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
[void]$closure.Add($root[0].id)
do {
    $changed=$false
    foreach($node in $m.resolve.nodes){
        if(!$closure.Contains($node.id) -and @($node.dependencies|Where-Object {$closure.Contains($_)}).Count){$changed=$closure.Add($node.id) -or $changed}
    }
}while($changed)
$packages=@($m.packages|Where-Object {$_.id -in $m.workspace_members -and $closure.Contains($_.id)}|Sort-Object name|Select-Object name,id)
$owners=@('arcweft-lang-sema','arcweft-compiler')
if(@($owners|Where-Object {$_ -notin $packages.name}).Count){throw 'Changed production owner outside closure'}
[ordered]@{version=1;base=$source.base;metadataSha256=(Get-FileHash ($stem+'.metadata.log')).Hash.ToLowerInvariant();workspacePackages=$m.workspace_members.Count;owners=$owners;selection='rdeps(=arcweft-lang-sema)';packages=$packages;packageCount=$packages.Count;nonCliFeaturePoint='workspace except CLI, all features, lib/tests';cliFeaturePoint='CLI defaults, lib/tests; actual main executable pinned in place'}|ConvertTo-Json -Depth 8|Set-Content "$r/style-token-inference-20261109.graph.json" -Encoding utf8
Invoke-Quality 'check' @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Quality 'clippy' @('clippy','--locked','--workspace','--all-targets','--all-features')
Invoke-Quality 'structure' @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking','--write',"$r/style-token-inference-20261109.structure-report")
$fmt=@((git diff --name-only 21303d45deecde6c93a3bc52ef1479d3c73707f0 -- '*.rs')+$new|Sort-Object -Unique)
Assert-Inputs
& rustfmt --check --edition 2024 --config skip_children=true $fmt *> ($stem+'.fmt.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{base=$source.base;paths=$fmt;exitCode=$code;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.fmt.receipt.json') -Encoding utf8
exit $code
