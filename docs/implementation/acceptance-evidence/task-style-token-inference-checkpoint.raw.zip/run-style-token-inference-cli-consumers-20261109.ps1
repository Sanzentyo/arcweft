$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$new=@(Get-Content "$r/style-token-inference-20261109.additional-paths.json" -Raw|ConvertFrom-Json)
& "$r/run-retained-input-cli-main-20261108.ps1" -Stem 'style-token-inference-integrated-20261109.cli-r1' -Selection @('--locked','-p','arcweft-cli','--lib','--tests') -ExpectedMatches 711 -AdditionalPaths $new
exit $LASTEXITCODE
