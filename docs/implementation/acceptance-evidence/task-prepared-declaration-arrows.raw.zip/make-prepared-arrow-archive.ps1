$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$publication = Get-Content -Raw -LiteralPath (Join-Path $root 'prepared-arrow.publication.json') | ConvertFrom-Json
$summary = Get-Content -Raw -LiteralPath (Join-Path $root 'prepared-arrow.owner-summary.json') | ConvertFrom-Json
if ($summary.Selected -ne 1543 -or -not $summary.SelectedIdsEqualTerminalIds -or -not $summary.FailureIdsUnchanged -or $summary.Tree -ne $publication.Tree) { throw 'Owner evidence is incomplete.' }
$files = [Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File | Where-Object {
    ($_.Name.StartsWith('prepared-arrow.') -or $_.Name -in @('audit-prepared-arrow.ps1','make-prepared-arrow-archive.ps1')) -and
    $_.Name -notin @('prepared-arrow.manifest.json','prepared-arrow.archive.json','prepared-arrow.docs-publication.json')
} | Sort-Object Name | ForEach-Object { $files.Add([ordered]@{name=$_.Name; path=$_.FullName}) }
$manifest = [ordered]@{
    version=1; source=$publication.Source; tree=$publication.Tree; base=$publication.Base
    phases=@(
        [ordered]@{name='initial-unpinned-check'; note='Test fixture Array syntax errors; exit 101, no tests executed; source snapshot was not captured.'},
        [ordered]@{name='initial-unpinned-selection'; selected=6; passed=5; failed=1; note='The bare time effect label is invalid. The selected-list JSON is extracted from the original mixed-stream log; this is not the final pinned input.'},
        [ordered]@{name='final-owner'; tree=$publication.Tree; selected=1543; passed=1537; failed=6; skipped=0; note='All six new tests passed. The six recursive-body failure IDs are unchanged.'}
    )
    files=@($files | ForEach-Object { $item=Get-Item -LiteralPath $_.path; [ordered]@{name=$_.name; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant()} })
}
$manifestPath = Join-Path $root 'prepared-arrow.manifest.json'
$manifest | ConvertTo-Json -Depth 10 | Set-Content -Encoding utf8 -LiteralPath $manifestPath
$files.Add([ordered]@{name='manifest.json'; path=$manifestPath})
$archivePath = 'D:\git\arcweft\docs\implementation\acceptance-evidence\task-prepared-declaration-arrows.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Refusing to overwrite a frozen archive.' }
$zip = [IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try { foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.path,$file.name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null} }
finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $files.Count) { throw 'Archive entry count mismatch.' }
    foreach ($file in $files) {
        $entry=$zip.GetEntry($file.name); $original=Get-Item -LiteralPath $file.path
        if ($null -eq $entry -or $entry.Length -ne $original.Length) { throw ('Archive length mismatch: '+$file.name) }
        $stream=$entry.Open()
        try { $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() }
        finally { $stream.Dispose() }
        if ($hash -ne (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()) { throw ('Archive hash mismatch: '+$file.name) }
    }
    $rawBytes=($zip.Entries | Measure-Object Length -Sum).Sum
} finally { $zip.Dispose() }
$archive=Get-Item -LiteralPath $archivePath
[ordered]@{version=1; source=$publication.Source; tree=$publication.Tree; entries=$files.Count; rawBytes=$rawBytes; bytes=$archive.Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); verifiedEveryEntryIncludingManifest=$true} | ConvertTo-Json | Set-Content -Encoding utf8 -LiteralPath (Join-Path $root 'prepared-arrow.archive.json')
Get-Content -LiteralPath (Join-Path $root 'prepared-arrow.archive.json')
