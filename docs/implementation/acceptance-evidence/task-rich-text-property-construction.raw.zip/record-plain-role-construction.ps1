$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Receipt([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 100}
$source=Read-Receipt 'plain-role-construction-source.verified'
if((git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected published source'}
$terminal=Read-Receipt 'plain-role-construction-owner5-20261104.runtime.terminal-audit'
if($terminal.executed -ne 24 -or $terminal.passed -ne 24 -or $terminal.failed -ne 0 -or $terminal.sourceDrift -ne 0){throw 'Final constructor bundle differs'}
$freeze=Read-Receipt 'plain-role-construction-owner5-20261104.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift $($row.path)"}}
$quality=@(foreach($gate in @('check','clippy','structure')){$name="plain-role-construction-quality2-$gate";$result=Read-Receipt $name;if($result.exitCode -ne 0){throw "Required check failed $name"};[ordered]@{receipt=$name;result=$result}})
$before=@([IO.File]::ReadAllLines((Join-Path $PWD 'docs/implementation/current-status.md'))|Where-Object {$_.StartsWith('| RichTextの部分layout指定／source factory |') -or $_.StartsWith('| workspace check／Clippy・fmt・構造gate |')})
if($before.Count -ne 2){throw 'Missing/duplicate canonical status rows'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD 'docs/implementation/convergence-evidence-history.md'))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
[ordered]@{version=1;source=$source.commit;supersededCurrentRows=$before;historyPrefix=$historyPrefix;reason='New program-bound construction implementation and 24 final passing cases complete this API boundary. Source registration and calling-context integration remain separate; prior accepted features stay accepted.'}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$taskTemp/plain-role-construction-status-before.json" -Encoding utf8
foreach($row in (Read-Receipt 'task-documentation-final-untracked-before').files){if(-not(Test-Path -LiteralPath $row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
. "$taskTemp/write-verified-evidence-archive.ps1"
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like 'plain-construction-owner1-20261104.*' -or $_.Name -like 'rich-text-construction-owner[1-4]-20261104.*' -or $_.Name -like 'plain-role-construction-*'})
foreach($name in @('plain-role-construction-quality1.structure-report','plain-role-construction-quality2.structure-report')){$files+=@(Get-ChildItem -LiteralPath "$taskTemp/$name" -File -Recurse)}
foreach($name in @('record-plain-role-construction.ps1','run-presentation-projection-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')){$files+=Get-Item -LiteralPath "$taskTemp/$name"}
$archivePath='docs/implementation/acceptance-evidence/task-rich-text-property-construction.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $archivePath))) $files
$raw.path=$archivePath
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('construction')){throw 'Preserve existing construction evidence'}
$record['construction']=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$source.commit;source=$source
 state='Program-bound borrowed construction API validated and published. Source factory registration/execution and whole reverse-dependency runtime acceptance are not claimed.'
 implementation=@('Core owns a prospective borrowed scalar/tuple/Option recipe with no opaque or affine grant. One original retained bank checks the complete opaque envelope and payload before owned allocation.','Dialogue admits borrowed semantic properties through its existing value grammar, including closed enum owner domains and allowed units, then merges source-ordered duplicate settings.','The producer binds the exact executable lease and accepted RichText role. Dynamic display tests consume this API instead of assembling opaque payloads by hand.','Version-one unit tags are owned by RichTextUnit and reused by Presentation and Dialogue; existing bytes are unchanged. New API failures preserve typed boxed errors.')
 validation=[ordered]@{terminal=$terminal;quality=$quality;sourceCaseExecutableDrift=0;fmt='All 13 owned Rust files formatted; explicit staged whitespace gate passed.'}
 attempts=@(
  [ordered]@{receipt='plain-construction-owner1-20261104.runtime.terminal-audit';result=(Read-Receipt 'plain-construction-owner1-20261104.runtime.terminal-audit')},
  [ordered]@{receipt='rich-text-construction-owner1-20261104.catalog';result=(Read-Receipt 'rich-text-construction-owner1-20261104.catalog');correction='Unbox the existing owned collection error at its unchanged public boundary.'},
  [ordered]@{receipt='rich-text-construction-owner2-20261104.catalog';result=(Read-Receipt 'rich-text-construction-owner2-20261104.catalog');correction='Use the public RuntimeBorrowedValue conversion in tests.'},
  [ordered]@{receipt='rich-text-construction-owner3-20261104.runtime.terminal-audit';result=(Read-Receipt 'rich-text-construction-owner3-20261104.runtime.terminal-audit');correction='The test incorrectly rejected Pt. The canonical RubySize contract permits both Px and Pt; use Deg as the negative case and assert both allowed units.'},
  [ordered]@{receipt='rich-text-construction-owner4-20261104.runtime.terminal-audit';result=(Read-Receipt 'rich-text-construction-owner4-20261104.runtime.terminal-audit')}
 )
 scope='Final 24 cases include 5 Core construction cases, unit tags, borrowed property admission, original Native/AWBC type owners and JSON cold restore, existing role codec/schema tests and 5 dynamic display cases. Fixtures with both type tables do not claim source execution. Full 98-package check/Clippy/all-targets/all-features and structure pass on final hashes; existing warnings remain. Prior 47-package execution and its 14 CLI failures are preserved as earlier-input evidence, not a fresh run of the new Core API.'
 ownership='Core owns borrowed recipe inspection and resource/type admission; Dialogue owns property grammar and role production; Presentation consumes the schema-owned unit codec. No dependency direction changes or version bump.'
 correctionReason='Remove construction API implementation from the current remaining range based on actual code and execution. Keep external source registration, original call-context connection, alias argument-order and static provenance within the continuing factory boundary.'
 supersededCurrentRows=$before;historyPrefix=$historyPrefix;raw=$raw
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
[ordered]@{version=1;head=$source.commit;raw=$raw.path;entries=$raw.entries.Count;sha256=$raw.sha256}|ConvertTo-Json|Set-Content -LiteralPath "$taskTemp/plain-role-construction-evidence-record.json" -Encoding utf8
Write-Output "Constructor evidence entries=$($raw.entries.Count), hash=$($raw.sha256)"