$ErrorActionPreference='Stop'
$r=$PSScriptRoot
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$graph=Read-Record 'string-read-operations-20261108.graph.json'
$previous=Read-Record 'ime-purpose-enter-key-integrated-20261108.noncli.catalog.inventory.json'
$current=Read-Record 'string-read-operations-integrated-20261108.noncli-r2.catalog.inventory.json'
$packages=@($graph.packages.name|Where-Object {$_ -ne 'arcweft-cli'})
$before=@($previous.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $packages})
$after=@($current.rows|Where-Object {$_.status -eq 'matches'})
$oldName='final_analysis::tests::production_analyzer_routes_string_preserving_value_methods_through_capacity_family'
$newName='final_analysis::tests::production_analyzer_routes_string_preserving_value_methods_through_string_family'
if(@($before|Where-Object {$_.package -eq 'arcweft-lang-sema' -and $_.test -eq $oldName}).Count -ne 1 -or @($after|Where-Object {$_.package -eq 'arcweft-lang-sema' -and $_.test -eq $newName}).Count -ne 1){throw 'Expected one-to-one String family test rename is absent'}
function Key($row){$name=if($row.package -eq 'arcweft-lang-sema' -and $row.test -eq $oldName){$newName}else{$row.test};$row.package+'|'+$row.binary+'|'+$name}
$oldKeys=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$newKeys=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $before){if(!$oldKeys.Add((Key $row))){throw 'Duplicate prior case'}}
foreach($row in $after){if(!$newKeys.Add((Key $row))){throw 'Duplicate current case'}}
$missing=@($before|Where-Object {!$newKeys.Contains((Key $_))})
$added=@($after|Where-Object {!$oldKeys.Contains((Key $_))})
if($missing.Count){throw 'A previously selected case is missing'}
if(@($after|Where-Object {$_.package -notin $packages}).Count){throw 'Selected non-CLI case outside Cargo closure'}
$terminal=Read-Record 'string-read-operations-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
if($after.Count -ne $terminal.executed){throw 'Catalog and terminal case count differ'}
$record=[ordered]@{version=1;base=$terminal.base;baseline='ime-purpose-enter-key-integrated-20261108.noncli.catalog.inventory.json';baselineProjection='Prior ID closure projected onto the current Core reverse-dependency package set; all-features non-CLI lib/tests in both runs.';selection=$graph.selection;closurePackages=$graph.packageCount;baselineProjectedCases=$before.Count;selectedCases=$after.Count;missing=$missing;added=$added;duplicateCases=0;renamedCases=@([ordered]@{package='arcweft-lang-sema';old=$oldName;new=$newName;reason='The same String-preserving test now asserts the final Core-owned String family instead of obsolete Capacity membership. Two calls, candidate uniqueness, String results and unresolved-dot nominal-coordinate checks remain, with exact Trim/ToString identities added.'});note='Only the final integrated run counts as new execution; the first 3-failure matrix, focused owner repetitions and older consumer runs are not added.'}
$record|ConvertTo-Json -Depth 12|Set-Content "$r/string-read-operations-integrated-20261108.coverage-audit.json" -Encoding utf8
[ordered]@{base=$record.base;baselineProjectedCases=$before.Count;selectedCases=$after.Count;missing=$missing.Count;added=$added.Count;duplicateCases=0}|ConvertTo-Json
