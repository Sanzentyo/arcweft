$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$extra=@('crates/arcweft-core/src/awbc/product_step/action.rs','crates/arcweft-presentation/src/text_input/policy.rs','crates/arcweft-compiler/tests/view_product/text_input/placeholder.rs','crates/arcweft-core/src/value/string.rs','crates/arcweft-core/src/awbc/verify/code/string_tests.rs','crates/arcweft-compiler/tests/callable_execution/string_operations.rs')
& "$r/run-retained-input-frozen-matrix-20261108.ps1" -Stem string-read-operations-integrated-20261108.noncli-r2 -Selection @('--locked','--workspace','--exclude','arcweft-cli','--all-features','--lib','--tests','-E','rdeps(=arcweft-core)') -ExpectedMatches 7378 -AdditionalPaths $extra
$noncli=$LASTEXITCODE
if($noncli -ne 0){throw ('Non-CLI consumers failed: '+$noncli)}
& "$r/run-retained-input-cli-main-20261108.ps1" -Stem string-read-operations-integrated-20261108.cli -Selection @('--locked','-p','arcweft-cli','--lib','--tests') -ExpectedMatches 711 -AdditionalPaths $extra
exit $LASTEXITCODE
