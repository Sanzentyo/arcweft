$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$stem="$r/string-read-operations-integrated-20261108.final-source-probe"
if(Test-Path ($stem+'.json')){throw 'Final Source probe receipt exists'}
$mainAudit=Get-Content "$r/string-read-operations-integrated-20261108.cli.main-audit.json" -Raw|ConvertFrom-Json
$main=$mainAudit.path
$paths=@($main,'samples/text-submit-flow/src/main.arcw','samples/text-submit-flow/arcw.toml')
$inputs=@(foreach($p in $paths){[ordered]@{path=$p;sha256=(Get-FileHash $p).Hash.ToLowerInvariant()}})
if($inputs[0].sha256 -ne $mainAudit.sha256){throw 'Actual CLI differs from the tested binary'}
function Assert-Inputs {foreach($row in $inputs){if((Get-FileHash $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Final Source probe input drift'}}}
$start=[DateTime]::UtcNow.ToString('o')
& $main check --manifest-path samples/text-submit-flow/arcw.toml --json *> ($stem+'.check.log')
$check=$LASTEXITCODE
Assert-Inputs
if($check -ne 0){throw 'Final CLI Source check failed'}
$report=Get-Content ($stem+'.check.log') -Raw|ConvertFrom-Json -Depth 40
if($report.status -ne 'ok'){throw 'Final CLI check has no successful status'}
$artifact='D:/git/arcweft/target/arcweft/text-submit-flow-final.awfb'
& $main bundle --manifest-path samples/text-submit-flow/arcw.toml --profile main --output $artifact --json *> ($stem+'.bundle.log')
$bundle=$LASTEXITCODE
Assert-Inputs
if($bundle -ne 0){throw 'Final CLI Source bundle failed'}
$hash=(Get-FileHash $artifact).Hash.ToLowerInvariant()
$original=Get-Content "$r/string-read-operations-20261108.sample-bundle-r2.json" -Raw|ConvertFrom-Json -Depth 15
if($hash -ne $original.artifact.sha256){throw 'Canonical bundle changed between equivalent production CLI builds'}
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();inputs=$inputs;checkCommand=@($main,'check','--manifest-path','samples/text-submit-flow/arcw.toml','--json');checkExitCode=$check;status=$report.status;bundleCommand=@($main,'bundle','--manifest-path','samples/text-submit-flow/arcw.toml','--profile','main','--output',$artifact,'--json');bundleExitCode=$bundle;artifact=[ordered]@{path=$artifact;bytes=(Get-Item $artifact).Length;sha256=$hash};matchesPriorCanonicalBundle=$true;inputDrift=0;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Actual final tested CLI Source check and main-profile bundle generation. Not another nextest test or interactive Native/Web acceptance. Both generated bundles remain at their original build paths.'}|ConvertTo-Json -Depth 12|Set-Content ($stem+'.json') -Encoding utf8
Get-Content ($stem+'.json') -Raw
