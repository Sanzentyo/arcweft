$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$owner=Get-Content "$r/string-read-operations-20261108.test-oracles-owner.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if(!$owner.isPassingRun -or $owner.passed -ne 3){throw 'Corrected tests have not passed'}
$freeze=Get-Content "$r/string-read-operations-20261108.test-oracles-owner.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
Assert-Inputs
$start=[DateTime]::UtcNow.ToString('o')
& cargo clippy --locked -p arcweft-core -p arcweft-lang-sema --all-targets --all-features *> "$r/string-read-operations-20261108.test-oracles-clippy.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=@('cargo','clippy','--locked','-p','arcweft-core','-p','arcweft-lang-sema','--all-targets','--all-features');exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;scope='Two existing test files only; production bytes are unchanged from the full workspace gates.';startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 6|Set-Content "$r/string-read-operations-20261108.test-oracles-clippy.json" -Encoding utf8
if($code -ne 0){throw 'Corrected-test Clippy failed'}
$paths=@('crates/arcweft-core/src/plan/construction/source/expression/tests.rs','crates/arcweft-lang-sema/src/final_analysis/tests.rs')
& rustfmt --check --edition 2024 --config skip_children=true $paths *> "$r/string-read-operations-20261108.test-oracles-fmt.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();paths=$paths;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0}|ConvertTo-Json -Depth 6|Set-Content "$r/string-read-operations-20261108.test-oracles-fmt.json" -Encoding utf8
if($code -ne 0){throw 'Corrected-test format failed'}
$prefix='string-read-operations-20261108.test-oracles'
[IO.File]::WriteAllText("$r/$prefix.owned.txt",($paths -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText("$r/$prefix.other.txt",'',[Text.UTF8Encoding]::new($false))
$message=@'
test(string): migrate semantic family and closed intrinsic tag expectations

The first full Core closure ran 7378 tests: 7375 passed and three stale assertions
failed. Preserve all-tag round trips and exact legacy coordinates, extend the
closed intrinsic count to 95 and assert String tags 18/19/94 explicitly.

Migrate the two String semantic tests from obsolete Capacity membership to the
Core-owned String operation, keeping result/candidate/nominal checks and adding
exact Trim/ToString identities. Rename one test to reflect its final family.

All three corrected cases, affected all-target/all-feature Clippy and fmt pass.
The full non-CLI matrix and default CLI matrix continue after this checkpoint.
'@
[IO.File]::WriteAllText("$r/$prefix.message.txt",$message,[Text.UTF8Encoding]::new($false))
& "$r/checkpoint-explicit-wide-prepare.ps1" -Prefix $prefix
& "$r/checkpoint-explicit-publish.ps1" -Prefix $prefix
if($LASTEXITCODE -ne 0){throw 'Corrected-test publication failed'}
& "$r/run-string-consumers-r2-20261108.ps1"
exit $LASTEXITCODE
