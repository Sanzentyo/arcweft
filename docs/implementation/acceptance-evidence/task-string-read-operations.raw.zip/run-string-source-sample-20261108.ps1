param([Parameter(Mandatory)][string]$Epoch)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$stem="$r/string-read-operations-20261108.$Epoch"
if(Test-Path ($stem+'.build.json')){throw 'Build epoch already exists'}
$paths=@((git ls-files -- '*.rs' '*.toml' '*.lock' '*.json' '*.stderr' '*.arcw' '*.awfagent' 'rust-toolchain*' '.cargo/*')|Where-Object {$_ -notlike 'docs/*'})
$paths=@($paths+@('crates/arcweft-core/src/value/string.rs','crates/arcweft-core/src/awbc/verify/code/string_tests.rs','crates/arcweft-compiler/tests/callable_execution/string_operations.rs')|Sort-Object -Unique)
$source=@(foreach($p in $paths){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$source|ConvertTo-Json -Depth 8|Set-Content ($stem+'.inputs.json') -Encoding utf8
function Assert-Inputs {foreach($row in $source){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
$start=[DateTime]::UtcNow.ToString('o')
& cargo build --locked -p arcweft-cli --bin arcw *> ($stem+'.build.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=@('cargo','build','--locked','-p','arcweft-cli','--bin','arcw');exitCode=$code;sourceInputs=$source.Count;sourceDrift=0;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.build.json') -Encoding utf8
if($code -ne 0){throw 'CLI build failed'}
$main='D:/git/arcweft/target/debug/arcw.exe'
$mainBefore=(Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant()
$manifest='samples/text-submit-flow/arcw.toml'
$start=[DateTime]::UtcNow.ToString('o')
& $main check --manifest-path $manifest --json *> ($stem+'.check.log')
$code=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant() -ne $mainBefore){throw 'CLI binary drift'}
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=@($main,'check','--manifest-path',$manifest,'--json');exitCode=$code;sourceSha256=(Get-FileHash samples/text-submit-flow/src/main.arcw).Hash.ToLowerInvariant();manifestSha256=(Get-FileHash $manifest).Hash.ToLowerInvariant();mainSha256=$mainBefore;sourceDrift=0;binaryDrift=0;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.check.json') -Encoding utf8
Get-Content ($stem+'.check.log') -TotalCount 30
exit $code
