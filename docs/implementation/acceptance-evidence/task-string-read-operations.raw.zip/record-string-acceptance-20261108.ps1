$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$publication=Read-Record 'string-read-operations-20261108.source.verified.json'
$sample=Read-Record 'string-read-operations-20261108.sample-source.verified.json'
$cleanup=Read-Record 'string-read-operations-20261108.test-cleanup.verified.json'
$tests=Read-Record 'string-read-operations-20261108.test-oracles.verified.json'
if((git rev-parse HEAD).Trim() -ne $tests.commit){throw 'Observed Source changed'}
$firstNoncli=Read-Record 'string-read-operations-integrated-20261108.noncli.runtime.terminal-audit.json'
$noncli=Read-Record 'string-read-operations-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
$cli=Read-Record 'string-read-operations-integrated-20261108.cli.runtime.terminal-audit.json'
$priorCli=Read-Record 'view-placeholder-integrated-20261108.cli.runtime.terminal-audit.json'
if(!$noncli.isPassingRun -or $cli.failed -ne 4 -or $cli.executed -ne 711){throw 'Consumer acceptance differs'}
if(@(Compare-Object @($priorCli.failureSet|ForEach-Object {$_.binary+'|'+$_.test}) @($cli.failureSet|ForEach-Object {$_.binary+'|'+$_.test})).Count){throw 'CLI failure IDs changed'}
$quality=@(foreach($name in @('check','clippy','structure','fmt')){$receipt=Read-Record "string-read-operations-20261108.quality.$name.receipt.json";if($receipt.exitCode -ne 0){throw 'Quality failure'};[ordered]@{check=$name;receipt=$receipt}})
$cleanupClippy=Read-Record 'string-read-operations-20261108.test-cleanup-clippy.json'
$cleanupFmt=Read-Record 'string-read-operations-20261108.test-cleanup-fmt.json'
if($cleanupClippy.exitCode -ne 0 -or $cleanupFmt.exitCode -ne 0){throw 'Test cleanup quality failed'}
$oracleClippy=Read-Record 'string-read-operations-20261108.test-oracles-clippy.json'
$oracleFmt=Read-Record 'string-read-operations-20261108.test-oracles-fmt.json'
if($oracleClippy.exitCode -ne 0 -or $oracleFmt.exitCode -ne 0){throw 'Oracle correction quality failed'}
$coverage=Read-Record 'string-read-operations-integrated-20261108.coverage-audit.json'
$diagnostics=Read-Record 'string-read-operations-integrated-20261108.failure-diagnostics.json'
$archive='docs/implementation/acceptance-evidence/task-string-read-operations.raw.zip'
if(Test-Path $archive){throw 'Archive already exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$raw=@(Get-ChildItem -LiteralPath $r -File -Filter 'string-read-operations*'|Where-Object {$_.Extension -in @('.json','.log','.txt','.patch')})
$raw+=@(Get-ChildItem -LiteralPath $r -File -Filter '*string*-20261108.ps1')
$raw+=Get-Item "$r/inspect-string-sample-hir.rs"
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($file in ($raw|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    foreach($file in (Get-ChildItem -LiteralPath "$r/string-read-operations-20261108.structure-report" -File)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('structure-report/'+$file.Name),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$entry=[ordered]@{
    version=1;date='2026-11-08';sourcePublication=$publication;samplePublication=$sample;testCleanupPublication=$cleanup;testPublication=$tests
    acceptance='Read-only String trim/to_string/scalar_count, exact typed ABI admission, Native/decoded compact AWBC execution and per-op public AWBC cold restore with captured String are accepted. Complete sample interactive Native/Web acceptance remains open.'
    ownership='Core RuntimeStringOperation is the final authority for source vocabulary, result contract, intrinsic identity/tags and evaluation. Sema seals this operation directly, outside Capacity; Compiler projects the checked identity. Native construction and AWBC verification reject wrong receiver/arity/result (including u64 versus usize). The VM evaluates deterministic String intrinsics without an application host resolver. Obsolete flat String intrinsic and Capacity cases are deleted.'
    semanticScope='scalar_count counts Unicode scalar values, including decomposed marks and emoji-sequence scalars; empty text is zero. It does not allocate a character sequence or count bytes/grapheme/TextCluster units. trim/to_string return owned String values and retain the receiver.'
    focused=(Read-Record 'string-read-operations-20261108.owner-r4.runtime.terminal-audit.json')
    nonCli=$noncli;cli=$cli;mainExecutable=(Read-Record 'string-read-operations-integrated-20261108.cli.main-audit.json')
    freshUniqueExecuted=($noncli.executed+$cli.executed);passed=($noncli.passed+$cli.passed);failed=($noncli.failed+$cli.failed);skipped=($noncli.skipped+$cli.skipped);featurePoints=2
    coverage=$coverage;graph=(Read-Record 'string-read-operations-20261108.graph.json');cliFailureIdChanges=0;observedDiagnostics=$diagnostics.failureDiagnostics
    quality=$quality;testCleanupClippy=$cleanupClippy;testCleanupFmt=$cleanupFmt;testOracleClippy=$oracleClippy;testOracleFmt=$oracleFmt
    qualityReuse='Workspace production gates are for Source 208b3b5315ab00272fe3a9524a67b9c1642d8c50. Only test files then changed: immutable local builders, explicit unchanged default budget types, a documented intentional non-NFC fixture expectation, and three stale semantic assertions. Those final files pass affected all-target/all-feature Clippy and fmt; the final full consumer matrix executes their bytes. No production contract changed after the full gates.'
    firstNonCli=$firstNoncli;oracleFocused=(Read-Record 'string-read-operations-20261108.test-oracles-owner.runtime.terminal-audit.json')
    oracleCorrection='First full Core closure: 7378 run/7375 pass/3 fail/18 skip. Two Sema tests still expected obsolete Capacity membership; one Core codec test expected 94 intrinsic tags instead of 95. The final tests retain receiver/result/unique-candidate/nominal-coordinate and all-tag round-trip checks, and add exact Trim/ToString identities and tags 18/19/94. One test name is updated one-to-one from capacity_family to string_family, explicitly mapped in the coverage audit. The failing full run remains historical and is not added to final execution totals.'
    sampleCheck=(Read-Record 'string-read-operations-20261108.sample-r3.check.json');sampleBundle=(Read-Record 'string-read-operations-20261108.sample-bundle-r2.json');finalSourceProbe=(Read-Record 'string-read-operations-integrated-20261108.final-source-probe.json')
    sampleCorrection='The genuine HIR source API mapped refused expression 173 to the returned submitted String. Declaring -> String exposed a separate local feedback variable hiding the Action namespace. Naming the internal state feedback_text preserves original input/Action IDs and payloads. Actual CLI check and main-profile AWFB generation now pass; every response branch and counting threshold remains. Old README input factories, handlers, receive syntax and unsupported trace assumptions were replaced with current Source and verified commands; the reason is retained here.'
    preservedFailures=@(
        [ordered]@{phase='dev-check-r1';receipt=(Read-Record 'string-read-operations-20261108.dev-check-r1.json');reason='Missing new Core enum import in a test and u8 versus u16 digest tag; fixed before dev-check-r2.'},
        [ordered]@{phase='dev-check-r2';receipt=(Read-Record 'string-read-operations-20261108.dev-check-r2.json');reason='Earlier development workspace check passed; not counted as the final frozen gates.'},
        [ordered]@{phase='owner-r1';receipt=(Read-Record 'string-read-operations-20261108.owner-r1.runtime.terminal-audit.json');reason='3 pass/1 fail: decoded compact AWBC delegated String operations to an unresolved application host. Production Core VM dispatch was fixed, preserving the failing host behavior in the test.'},
        [ordered]@{phase='owner-r2';receipt=(Read-Record 'string-read-operations-20261108.owner-r2.runtime.terminal-audit.json');reason='4 pass before adding capture and per-op public cold restore; not added to final execution totals.'},
        [ordered]@{phase='owner-r3';receipt=(Read-Record 'string-read-operations-20261108.owner-r3.catalog.json');reason='Test preparation failed: seal_flow_invocation consumes the plan. Each fresh cold executor now receives its own cloned plan.'},
        [ordered]@{phase='sample-r1';receipt=(Read-Record 'string-read-operations-20261108.sample-r1.check.json');reason='Final expression 173 had no admissible type; original returned String now explicit.'},
        [ordered]@{phase='sample-r2';receipt=(Read-Record 'string-read-operations-20261108.sample-r2.check.json');reason='Local feedback state hid Action namespace; internal variable renamed.'},
        [ordered]@{phase='sample-bundle';receipt=(Read-Record 'string-read-operations-20261108.sample-bundle.json');reason='Invocation omitted required profile/source selection; corrected to --profile main.'}
    )
    ownerMeasurements=(Read-Record 'string-read-operations-20261108.owner-measurements-final.json')
    structureDisposition='The new small Core String module owns the complete closed operation algebra. Existing large value/VM/plan construction/verification owners retain their existing value, instruction, construction and dataflow responsibilities; the added String ABI/dispatch belongs to those algorithms, with no new unrelated state, I/O or duplicated resolver. Sema identity/schema/sealing/canonical transcript and Compiler lowering retain their existing respective boundaries. Child tests follow admission and Source execution ownership. The existing large final semantic test owner retains its HIR/generation/production-analyzer acceptance responsibility; only its two existing String cases changed, with no new unrelated state or widened helper API. Exact size/growth and dependency fan-in/out are in the raw measurements and canonical report; no file grew by 300 LOC. No dependency/feature/unsafe/version changes were introduced.'
    tier2='No protocol, capture, rendering, device or production-limit boundary changed. Stateless read-only String operations are exercised through real Native/AWBC and one-op public cold restore; unrelated ignored Tier2 families were not rerun.'
    scope='Only final integrated non-CLI and CLI runs count as fresh unique execution. All earlier failed preparation, owner repetitions and previous feature matrices remain historical evidence. Generic Match and every other accepted bounded cut remain accepted; known Scroll/voice/promotion failures and Style/sample/display work remain distinct.'
    archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();containsExecutables=$false;containsGeneratedBundles=$false}
}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'stringReadOperations'){throw 'String record exists'}
$wrapper=[ordered]@{stringReadOperations=$entry}|ConvertTo-Json -Depth 100
$inner=$wrapper.Substring($wrapper.IndexOf('{')+1).TrimEnd();$inner=$inner.Substring(0,$inner.LastIndexOf('}')).TrimEnd()
$new=$base.TrimEnd();$new=$new.Substring(0,$new.LastIndexOf('}')).TrimEnd()+','+"`n"+$inner+"`n}`n"
$after=$new|ConvertFrom-Json -Depth 100 -DateKind String
foreach($p in $prior.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($p.Name)|ConvertTo-Json -Depth 100 -Compress)){throw 'Historical record drift'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$new,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$tests.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;raw=$entry.archive;freshUniqueExecuted=$entry.freshUniqueExecuted;passed=$entry.passed;failed=$entry.failed;skipped=$entry.skipped}|ConvertTo-Json -Depth 8|Set-Content "$r/string-read-operations-20261108.acceptance-record.json" -Encoding utf8
Get-Content "$r/string-read-operations-20261108.acceptance-record.json" -Raw
