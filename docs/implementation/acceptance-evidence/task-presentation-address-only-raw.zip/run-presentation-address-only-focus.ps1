$ErrorActionPreference='Stop'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$previous=Get-Content -LiteralPath "$taskTemp/presentation-slot-call-tag-repair1-20261101.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
& "$taskTemp/run-shared-identity-owner.ps1" -Stem 'presentation-address-only-focus1-20261101' -Selection @('-p','arcweft-core','-p','arcweft-interaction-model','-p','arcweft-lang-sema','-p','arcweft-compiler','--lib','--tests','--all-features','--locked','-E','test(slot_reference) | test(slot_references) | test(presentation_scope_selection) | test(presentation_schemas_retain)') -ExpectedMatches -1 -AdditionalPaths @($previous.paths.path)
exit $LASTEXITCODE
