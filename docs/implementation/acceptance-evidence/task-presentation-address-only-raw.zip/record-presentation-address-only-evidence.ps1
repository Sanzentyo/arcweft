$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$quality=[IO.File]::ReadAllText("$taskTemp/product-execution-quality.active.txt")
$stem='presentation-address-only-reverse-20261101'
function Read-Receipt([string]$name) { Get-Content -LiteralPath "$taskTemp/$name" -Raw|ConvertFrom-Json -Depth 100 }
$focus=Read-Receipt 'presentation-address-only-focus1-20261101.runtime.terminal-audit.json'
$matrix=Read-Receipt "$stem.matrix.json"
$graph=Read-Receipt "$stem.graph.json"
$freeze=Read-Receipt "$stem.source-freeze.json"
$generic=Read-Receipt "$stem.generic-coverage.json"
$cli=Read-Receipt 'presentation-address-only-full-cli-20261101.matrix.json'
$cliComparison=Read-Receipt 'presentation-address-only-full-cli-20261101.cli-comparison.json'
$allCli=Read-Receipt 'presentation-address-only-full-cli-20261101.all-cli-scope.json'
$commit=Read-Receipt 'checkpoint-presentation-address-only.verified.json'
if($matrix.status -ne 'terminal' -or $matrix.rows.Count -ne 3){throw 'Reverse run is not closed'}
if($cli.status -ne 'terminal' -or $cli.rows.Count -ne 2 -or $allCli.caseDrift -ne 0 -or $allCli.sourceDrift -ne 0){throw 'CLI run is not closed and audited'}
if($focus.passed -ne 15 -or $focus.failed -ne 0 -or $focus.sourceDrift -ne 0){throw 'Focused evidence differs'}
if($commit.commit -ne (git rev-parse HEAD).Trim()){throw 'Published source differs'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Evidence source drift: '+$row.path)}}
$gates=@(foreach($gate in @('workspace-check','clippy','core-default','core-wasm','structure','fmt')){
    $receipt=Read-Receipt "$quality.$gate.json"
    if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw ('Quality gate failed: '+$gate)}
    [ordered]@{gate=$gate;receipt=$receipt}
})
$archivePath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-presentation-address-only-raw.zip'
$manifestPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-presentation-address-only-validation.json'
if((Test-Path -LiteralPath $archivePath) -or (Test-Path -LiteralPath $manifestPath)){throw 'Final evidence already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    $_.Name -like 'presentation-address-only-*' -or $_.Name -like 'presentation-address-only.*' -or $_.Name -like 'checkpoint-presentation-address-only.*' -or
    $_.Name -like '*presentation-address-only*.ps1'
})+@(Get-ChildItem -LiteralPath "$taskTemp/$quality.structure-report" -File)
$files=@($files|Sort-Object FullName -Unique)
$archive=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($file in $files){
        $entry=$file.FullName.Substring($taskTemp.Length+1).Replace('\','/')
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $archive.Dispose() }
$terminals=@($matrix.rows|ForEach-Object {$_.terminal})
if(@($terminals|Where-Object {$null -eq $_ -or $_.sourceDrift -ne 0 -or $_.catalogCaseDrift -ne 0}).Count){throw 'Unverified reverse terminal'}
$passed=($terminals|Measure-Object -Property passed -Sum).Sum
$failed=($terminals|Measure-Object -Property failed -Sum).Sum
$skipped=($terminals|Measure-Object -Property skipped -Sum).Sum
$result=[ordered]@{
    version=1
    date=[DateTime]::UtcNow.ToString('yyyy-MM-dd')
    source=$commit.commit
    inspectedWorkingTree='main; only the original 14 tracked and 6 actual untracked WIP plus this task documentation/evidence; original WIP retained'
    correction=[ordered]@{
        supersedes='The current-status enumeration of explicit Scope as unfinished for readonly SlotRef constructors only; original validation receipts remain historical evidence.'
        cause='The old Sema schemas exposed scope while RuntimePresentationSlotRefCall::construct rejected every Scope input. PresentationSlotAddress owns only target, slot and resource, and SlotRef issues no occupant lifetime grant.'
        decision='Remove scope and open occupant configuration from readonly ref.bg/ref.show. Keep scope selection on staging/removal operations. Delete the old Core input role and its readers in place at version 1; no compatibility consumer is known or required.'
    }
    publication=$commit
    focus=$focus
    focusedCases='Fifteen tests across three matching owners; interaction-model was selected with no matching focused case and is exercised by the complete reverse matrix. The Source test executes ten returned addresses spanning default/target-only/slot-only/both, generic Copy, entity patterns, authored evaluation order, Native and decoded AWBC, bad signature rejection, and public AWBC JSON save/restore after every step.'
    quality=$gates
    structure=[ordered]@{files=3281;rustFiles=3151;physicalRustLoc=1780629;workspacePackages=97;reviewTriggers=384;blocking=0;ownerReview='presentation-address-only.owner-review.json';changedRustPaths=9;owners=4}
    reverse=[ordered]@{graph=$graph;matrix=$matrix;passed=$passed;failed=$failed;skipped=$skipped;inputs=$freeze.paths.Count;sourceDrift=0;catalogCaseDrift=0;allPassed=($failed -eq 0 -and @($matrix.rows|Where-Object runtimeExit -ne 0).Count -eq 0)}
    genericCoverage=$generic
    additionalCli=[ordered]@{matrix=$cli;comparison=$cliComparison;allCliTargets=$allCli}
    limits=@(
        'No aggregate admission of already-live Engine/PureEvaluator/Product state is established by this change.'
        'Source ViewValue/Handle/Removed construction, staging commands/methods/driver, execution-owned explicit staging scope, and public Native save remain separate unfinished boundaries.'
        'All twelve current CLI lib/bin/integration targets are covered by four commands on the same 4045 source inputs; feature unions and runtime commands remain distinct. Original source 5f6cfabe3e18edbfd4c08fb7b15f02e1354a4695 receipts remain immutable, and exact failed binary/test IDs are compared separately; matching IDs alone do not establish identical causes.'
        'No executable documentation example was added; doctests and Tier 2 were not run for this readonly argument/codec correction. No host/device/render/capture path changed.'
        'Clippy exit zero does not mean warning-free. No test assertion, operation count, budget, concurrency, default filter, or fixture condition was weakened.'
        'The requested full cargo clean was completed once before these cuts; no build artifacts were moved, copied or retreated.'
    )
    raw=[ordered]@{path='task-presentation-address-only-raw.zip';entries=$files.Count;bytes=(Get-Item -LiteralPath $archivePath).Length;sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant()}
}
$result|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $manifestPath -Encoding utf8
[ordered]@{source=$commit.commit;focusPassed=$focus.passed;reversePassed=$passed;reverseFailed=$failed;reverseSkipped=$skipped;genericPassed=$generic.passed;archiveEntries=$files.Count;archiveBytes=$result.raw.bytes;archiveSha256=$result.raw.sha256}|ConvertTo-Json -Compress
