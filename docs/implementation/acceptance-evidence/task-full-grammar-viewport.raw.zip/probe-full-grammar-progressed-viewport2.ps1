$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='full-grammar-progressed-viewport-probe2'
if(Test-Path -LiteralPath (Join-Path $t ($stem+'.receipt.json'))){throw 'Keep existing probe'}
$source=(Resolve-Path -LiteralPath 'samples/rich-text-full-grammar.arcw').Path
$binary=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$controller=Join-Path $t ($stem+'.awfagent')
$pins=@(foreach($p in @($source,$binary,$controller)){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$arguments=@('agent','script','run',$controller,'--native-source',$source,'--entry','entry.rich_text_full_grammar','--native-steps','4','--native-max-ops','64','--json','--trace-out',(Join-Path $t ($stem+'.arcwx')),'--blob-dir',(Join-Path $t ($stem+'.blobs')))
$started=[DateTime]::UtcNow.ToString('o')
& $binary @arguments > (Join-Path $t ($stem+'.stdout.json')) 2> (Join-Path $t ($stem+'.stderr.log'))
$code=$LASTEXITCODE
foreach($pin in $pins){if((Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw 'Probe inputs changed'}}
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=@($binary)+$arguments;exitCode=$code;pins=$pins;inputDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Actual local public CLI AgentScript persistent native session; original4steps/64max_ops for viewport fixture. One observe and13explicit semantic advances, final observation resource and viewport capture. No renderer substitute or opaque URI/object reconstruction.'} | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $t ($stem+'.receipt.json')) -Encoding utf8
Get-Content -LiteralPath (Join-Path $t ($stem+'.receipt.json')) -Raw
exit $code

