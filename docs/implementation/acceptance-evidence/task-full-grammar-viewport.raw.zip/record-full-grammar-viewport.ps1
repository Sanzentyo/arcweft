$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$owner=Read-Record 'full-grammar-viewport-owner1-20261106.runtime.terminal-audit'
$quality=[ordered]@{check=Read-Record 'full-grammar-viewport-quality1-20261106-check';clippy=Read-Record 'full-grammar-viewport-quality1-20261106-clippy';format=Read-Record 'full-grammar-viewport-format1-20261106'}
if($owner.executed -ne 1 -or $owner.passed -ne 1 -or $owner.failed -or $quality.check.exitCode -or $quality.clippy.exitCode -or $quality.format.exitCode){throw 'Owner/quality did not pass'}
$source=Read-Record 'checkpoint-full-grammar-viewport-20261106.verified'
$prepared=Read-Record 'checkpoint-full-grammar-viewport-20261106.prepared'
. (Join-Path $t 'convergence-image-git-bytes.ps1')
$measurements=@(foreach($row in $source.paths){
 [byte[]]$old=[byte[]]::new(0)
 if(@(git ls-tree --name-only $source.parent -- $row.path).Count){$old=Read-GitBytes @('show',($source.parent+':'+$row.path))}
 $text=[IO.File]::ReadAllText((Join-Path $PWD $row.path))
 [ordered]@{path=$row.path;owner='arcweft-cli';classification='integration test';bytes=(Get-Item -LiteralPath $row.path).Length;loc=([regex]::Matches($text,"`n")).Count;baseBytes=$old.Length;baseLoc=([regex]::Matches([Text.Encoding]::UTF8.GetString($old),"`n")).Count;sha256=(Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant();stagedBlob=$row.blob;embeddedTestLoc=0}
})
$graph=Read-Record 'native-session-frame-request.graph'
foreach($p in $graph.cargoInputPins){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw 'Cargo graph inputs changed'}}
$probe1=Read-Record 'full-grammar-progressed-viewport-probe1.receipt'
$probe2=Read-Record 'full-grammar-progressed-viewport-probe2.receipt'
$probe3=Read-Record 'full-grammar-progressed-viewport-probe3.receipt'
if($probe1.exitCode -or $probe2.exitCode -eq 0 -or $probe3.exitCode){throw 'Unexpected probe history'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('fullGrammarViewport')){throw 'Preserve existing result'}
$before=$record | ConvertTo-Json -Depth 100 -Compress
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 $_.Name.StartsWith('full-grammar-viewport-') -or $_.Name.StartsWith('full-grammar-progressed-viewport-probe') -or $_.Name.StartsWith('probe-full-grammar-progressed-viewport') -or $_.Name.StartsWith('checkpoint-full-grammar-viewport-20261106.')
} | Where-Object {$_.Name -notlike '*original-held*'})
$files+=@(Get-Item -LiteralPath (Join-Path $t 'full-grammar-viewport.preservation-proof.json'),(Join-Path $t 'record-full-grammar-viewport.ps1'),(Join-Path $t 'run-full-grammar-viewport-quality.ps1'),(Join-Path $t 'run-native-coverage-owner.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'prepare-full-grammar-viewport-preservation.ps1'))
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'full-grammar-progressed-viewport-probe3.blobs') -Recurse -File)
if(@($files | Where-Object {$_.Name -like '*head-after.rs' -or $_.Name -like '*original-held*' -or $_.Name -like '*original-user*'}).Count){throw 'Private full user source must not be archived'}
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-full-grammar-viewport.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record.fullGrammarViewport=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;owner=$owner;quality=$quality;measurements=$measurements;preservation=Read-Record 'full-grammar-viewport.preservation-proof'
 graph=[ordered]@{selection=@('arcweft-cli');cargoInputPins=$graph.cargoInputPins;inputDrift=0;scope='Reuse the actual retained all-feature normal/build/dev graph: CLI is a leaf, closure1. This is a test-only fixture/helper/include change with no production/API/Cargo/feature/runtime changes. No new metadata invocation or workspace98/Tier2/wasm claim.'}
 ownership='NativeCliFixture owns its exact launch and public AgentScript CLI capture. NativeStoredViewportCapture retains the actual final-frame report, canonical image metadata and persisted bytes. The helper owns disposable controller/blob IO, response admission, exact action/tick checks, same-issued-URI readback, blob byte/content-hash checks and native frame decode; no cloned production model or synthetic report.images list. Existing large integration owner changes one fixture; new155LOC child separates its real process/blob IO responsibility without public API widening.'
 probes=[ordered]@{initial=$probe1;rejected=$probe2;final=$probe3;correction='Probe2 omitted try on Result<CaptureResult,AgentError> before shot.uri and is rejected before runtime with sema.call.no_viable_signature. Probe3 unwraps that existing typed result, succeeds, captures one1280x720PNG/44442bytes at tick55, then reads exactly the URI issued by that capture. Keep the failed source/receipt and both successful probes; do not classify the malformed controller as an engine regression.'}
 behavior='Preserve Windows-font one-shot --out PNG, geometry,width<=500 and nonempty content. Full grammar uses one observe plus13actual semantic advances at4steps/64max_ops, preserving the original per-call configuration. Admit the real current report, check each action accepted/tick+4 and finaltick55/steps56, exactline005/source28..64/152x101geometry, native Color/Viewport/Framebuffer1280x720metadata, nonempty content and actualPNGdecode. The CLI blob writer persists the capture; its bytes equal the same-frame URI read, byte length and BLAKE3 content hash. Discover the one saved file without parsing an opaque object/URI or asserting private file layout.'
 correctionReason='A one-shot observation exposes its active first line, so the old full-grammar viewport fixture could not select005. Replace that stale lifecycle expectation with real explicit inputs and an actual CLI-owned write/read sequence. Keep both sample conditions and original4step/64op budget; use the already established standard25px/34px geometry instead of old30px/min120 expectations. Existing latest all705CLI/696PASS9FAIL remains a historical full run; this focused1PASS proves this PNG owner condition only. Eight other owner conditions remain, including the full-grammar constructs case; do not invent a705/8FAIL rerun or reopen accepted Generic Match/style/coverage.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| Native prepared-textのcoverage負荷／同一frame readback |')){
  $line.Replace('geometry／PNGと','geometry／dialogue-layer PNGと')
  '| full-grammarの進行後viewport PNG保存 | **現行fixtureへ同期・当該CLI保存を検証・公開済み** | Source 590587b009e74ee0e850f80b74a1932df5e0d933。公開Agent Script CLIで1回観測＋13回の実semantic入力を返し、元の4-step／64-opのまま005／tick55へ進行する。Windows-fontの従来保存も保持し、既存1 case内の両sampleがPASS。native1280×720 PNGの実保存・同じ発行URIとのバイト一致・BLAKE3・decoded pixels・元Source／厳密geometryを検証した。CLI check／Clippy・formatも終了0、4120入力drift0。別のrich-text constructs条件は残る。[旧期待の訂正理由・全入力・失敗probe・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| CLI全target照合 |')){
  '| CLI全target照合 | **最新の全705実測は696 PASS／9 FAIL。後続PNG保存owner 1 PASS** | 全件Source cf674f51c2dd5169f2e5ee350e615b9b84ed14e6の終端・新規ID差分0は履歴へ保持する。Source 590587b009e74ee0e850f80b74a1932df5e0d933ではその9 ID中のPNG保存caseが、両sampleを保ってPASS。残る8 owner条件はfull-grammar constructs1、Scroll1、unsafe1、run-edge1、負例診断1、verifier3で、全705の新たな終端値へ再計算しない。[各入力・全ID・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Real progressed viewport PNG saved by the public CLI

- Source590587b009e74ee0e850f80b74a1932df5e0d933, parent791945ea6ec3a97ffbd6420d6f3f2ab8b3b689b8, tree11f976ce2a7008ad8e9c621f6060b80fb8dd59dd,3test paths/217add51delete, patcha7f40b85f71b6cbddcf29faa9251f74b38c81c5ac60b37491d00177b18e601a5. Keep Windows-font one-shot output/geometry and replace only the stale simultaneous005 viewport expectation with one actual observe plus13semantic advances through Agent Script. Original4steps/64max_ops and1280x720 remain unchanged. Every action is accepted/tick+4; finalreport55/steps56 and line005/source/152x101 geometry are exact. CLI saves actualPNG bytes, reads the same issued captureURI and checks persisted-byte equality, length, BLAKE3, metadata and decoded content. No fake images/written fields or cross-frame object reconstruction.
- Existing two-sample case:1PASS/727skipped/17.691s. CLI all-target/all-feature/locked check/Clippy and explicit3Rust format check exit0,warnings remain,4120Source/case/executable drift0. Leaf CLI closure1 reuses the actual graph with101Cargo/toolchain pins0; no new workspace98/Tier2/wasm runtime claim. Existing full705/696PASS9FAIL fromSourcecf674... remains unchanged; this later owner pass removes only the PNG condition, leaving8other owner conditions rather than inventing a705/8FAIL full run. Generic Match/style/coverage acceptance is preserved.
- Probe1 demonstrates actual localCLI viewport persistence. Probe2's unwrapped Result before shot.uri is rejected before runtime withsema.call.no_viable_signature; Probe3 correctly usestry capture(viewport()), succeeds and reads its own issued image. Final probe captures1280x720PNG/44442bytes at tick55 with the same4/64 configuration. Retain failed source/receipts/trace and actualfinalPNG as evidence, not an engine defect. Original Scroll WIP is replayed onto the clean partial candidate and reconstructs normalized working source exactly; other11held hashes remain unchanged. Residual patch1a1d975747c193cc89af68ded0a5ca746b56d7b0796d7c0647b71e7b9609b843; original snapshot69a470ec090c3e561f4b6ce3dd8b91a91d247928e0566bb9bc568e373cbe2bb6 stays private.
- [Source/owner/probes/preservation/verified raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md). The full-grammar constructs/effect/proxy condition remains separate work.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$after.Remove('fullGrammarViewport')
if(($after | ConvertTo-Json -Depth 100 -Compress) -ne $before){throw 'Prior evidence changed'}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{source=$source.commit;raw=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'full-grammar-viewport-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'full-grammar-viewport-documentation-audit.json')
