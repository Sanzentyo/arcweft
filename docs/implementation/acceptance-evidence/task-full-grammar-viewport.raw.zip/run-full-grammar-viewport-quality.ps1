$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& (Join-Path $t 'assert-no-arcweft-build.ps1')
$freeze=Get-Content -LiteralPath (Join-Path $t 'full-grammar-viewport-owner1-20261106.source-freeze.json') -Raw | ConvertFrom-Json
function Assert-Inputs {foreach($p in $freeze.paths){if((Get-FileHash -LiteralPath $p.path).Hash.ToLowerInvariant() -ne $p.sha256){throw ('Source drift: '+$p.path)}}}
foreach($check in @('check','clippy')){
 $stem='full-grammar-viewport-quality1-20261106-'+$check
 if(Test-Path -LiteralPath (Join-Path $t ($stem+'.json'))){throw 'Keep existing quality receipt'}
 Assert-Inputs
 $started=[DateTime]::UtcNow.ToString('o')
 $arguments=@($check,'-p','arcweft-cli','--all-targets','--all-features','--locked')
 & cargo @arguments *> (Join-Path $t ($stem+'.log'))
 $code=$LASTEXITCODE
 Assert-Inputs
 [ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $t ($stem+'.json')) -Encoding utf8
 Write-Output ($stem+' exit='+$code)
 if($code){throw 'CLI quality failed'}
}
$files=@('crates/arcweft-cli/tests/check/agent_observe_native.rs','crates/arcweft-cli/tests/check/agent_observe_native/native_samples_effects.rs','crates/arcweft-cli/tests/check/agent_observe_native/native_script_capture.rs')
Assert-Inputs
& rustfmt --edition 2024 --check @files *> (Join-Path $t 'full-grammar-viewport-format1-20261106.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$freeze.base;command=@('rustfmt','--edition','2024','--check')+$files;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $t 'full-grammar-viewport-format1-20261106.json') -Encoding utf8
if($code){throw 'Format failed'}
