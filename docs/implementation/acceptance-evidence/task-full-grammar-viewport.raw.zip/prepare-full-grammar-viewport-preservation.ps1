$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. (Join-Path $t 'convergence-image-git-bytes.ps1')
$path='crates/arcweft-cli/tests/check/agent_observe_native/native_samples_effects.rs'
$baseline=Get-Content -LiteralPath (Join-Path $t 'checkpoint-task-view.source-freeze.json') -Raw | ConvertFrom-Json -Depth 30
$base=(git rev-parse HEAD).Trim()
if($base -ne $baseline.base -or @(git diff --cached --name-only).Count){throw 'Unexpected base/index'}
$original=Join-Path $t 'full-grammar-viewport-native-samples.original-held.rs'
if((Get-FileHash -LiteralPath $original).Hash.ToLowerInvariant() -ne '69a470ec090c3e561f4b6ce3dd8b91a91d247928e0566bb9bc568e373cbe2bb6'){throw 'Original held snapshot changed'}
$baselineIndex=@{};foreach($row in $baseline.paths){$baselineIndex[$row.path]=$row.sha256}
foreach($held in $baseline.held){
 if($held -eq $path){continue}
 if((Get-FileHash -LiteralPath $held).Hash.ToLowerInvariant() -ne $baselineIndex[$held]){throw ('Other original WIP changed: '+$held)}
}
$review=Join-Path $t 'full-grammar-viewport-partial-review1'
if(Test-Path -LiteralPath $review){throw 'Preserve existing partial proof'}
$null=New-Item -ItemType Directory -Path $review
$encoding=[Text.UTF8Encoding]::new($false)
function Normalize([byte[]]$bytes){[Text.Encoding]::UTF8.GetString($bytes).Replace("`r`n","`n")}
$head=Normalize (Read-GitBytes @('show',($base+':'+$path)))
$before=Normalize ([IO.File]::ReadAllBytes($original))
$after=Normalize ([IO.File]::ReadAllBytes((Join-Path $PWD $path)))
foreach($entry in @(@('head.rs',$head),@('before.rs',$before),@('after.rs',$after))){[IO.File]::WriteAllText((Join-Path $review $entry[0]),$entry[1],$encoding)}
function Git-At([string]$directory,[string[]]$arguments,[bool]$allowDiff=$false){
 $info=[Diagnostics.ProcessStartInfo]::new('git');$info.WorkingDirectory=$directory;$info.UseShellExecute=$false;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 foreach($arg in $arguments){$info.ArgumentList.Add($arg)}
 $proc=[Diagnostics.Process]::Start($info);$out=$proc.StandardOutput.ReadToEnd();$err=$proc.StandardError.ReadToEnd();$proc.WaitForExit()
 if($proc.ExitCode -ne 0 -and -not($allowDiff -and $proc.ExitCode -eq 1)){throw $err}
 return $out
}
function Write-Patch([string]$a,[string]$b,[string]$name){
 $diff=Git-At $review @('diff','--no-index','--full-index','--no-ext-diff','--', $a,$b) $true
 $diff=[regex]::Replace($diff,'(?m)^diff --git .*$', 'diff --git a/native_samples_effects.rs b/native_samples_effects.rs')
 $diff=[regex]::Replace($diff,'(?m)^--- .*$', '--- a/native_samples_effects.rs')
 $diff=[regex]::Replace($diff,'(?m)^\+\+\+ .*$', '+++ b/native_samples_effects.rs')
 [IO.File]::WriteAllText((Join-Path $review $name),$diff.Replace("`r`n","`n"),$encoding)
}
Write-Patch 'before.rs' 'after.rs' 'owned.patch'
Write-Patch 'head.rs' 'before.rs' 'original-user.patch'
$target=Join-Path $review 'native_samples_effects.rs'
[IO.File]::WriteAllText($target,$head,$encoding)
$null=Git-At $review @('apply','--no-index','--check','--', (Join-Path $review 'owned.patch'))
$null=Git-At $review @('apply','--no-index','--', (Join-Path $review 'owned.patch'))
$clean=$encoding.GetBytes((Normalize ([IO.File]::ReadAllBytes($target))))
$candidate=Join-Path $t 'full-grammar-viewport.head-after.rs'
[IO.File]::WriteAllBytes($candidate,$clean)
Write-Patch 'head.rs' 'native_samples_effects.rs' 'owned-from-head.patch'
$null=Git-At $review @('apply','--no-index','--check','--', (Join-Path $review 'original-user.patch'))
$null=Git-At $review @('apply','--no-index','--', (Join-Path $review 'original-user.patch'))
if((Normalize ([IO.File]::ReadAllBytes($target))) -cne $after){throw 'Original WIP replay does not reconstruct the complete current source'}
$blob=(& git hash-object -w ('--path='+$path) -- $candidate).Trim()
if($LASTEXITCODE){throw 'Candidate blob write failed'}
$tempIndex=Join-Path $review 'proof.index'
$oldIndex=$env:GIT_INDEX_FILE
try {
 $env:GIT_INDEX_FILE=$tempIndex
 & git read-tree HEAD
 if($LASTEXITCODE){throw 'Private index load failed'}
 & git update-index --cacheinfo ('100644,'+$blob+','+$path)
 if($LASTEXITCODE){throw 'Private candidate staging failed'}
 $residual=Read-GitBytes (@('diff','--binary','--full-index','--')+$baseline.held)
} finally {
 if($null -eq $oldIndex){Remove-Item -LiteralPath Env:GIT_INDEX_FILE -ErrorAction SilentlyContinue}else{$env:GIT_INDEX_FILE=$oldIndex}
}
$expectedBlobs=[ordered]@{};foreach($held in $baseline.held){$expectedBlobs[$held]=(& git hash-object -- $held).Trim()}
$proof=[ordered]@{
 version=1;base=$base;path=$path;originalWipPatchSha256=$baseline.heldPatchSha256;originalHeldSnapshotSha256='69a470ec090c3e561f4b6ce3dd8b91a91d247928e0566bb9bc568e373cbe2bb6'
 expectedResidualWipPatchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($residual)).ToLowerInvariant()
 stagedCodeBlob=$blob;originalUserPatchPreserved=$true;heldCanonicalBlobDrift=0;expectedHeldBlobs=$expectedBlobs
 reason='Apply only the owned geometry/progress patch to the clean HEAD blob, replay the original Scroll WIP onto that candidate, and byte-compare normalized complete working source. Other11 held file hashes match the prior baseline. Compute residual patch through a private index; no real index/worktree/source or branch changes.'
}
$proof | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $t 'full-grammar-viewport.preservation-proof.json') -Encoding utf8
$template=Get-Content -LiteralPath (Join-Path $t 'checkpoint-cli-proof-hunks-prepare.ps1') -Raw
$template=$template.Replace('task-cli-proof.preservation-proof.json','full-grammar-viewport.preservation-proof.json').Replace('crates/arcweft-cli/tests/check/cli_runtime_bench.rs',$path).Replace('task-cli-proof.head-after.rs','full-grammar-viewport.head-after.rs')
$template | Set-Content -LiteralPath (Join-Path $t 'checkpoint-full-grammar-viewport-hunks-prepare.ps1') -Encoding utf8
[ordered]@{base=$base;stagedCodeBlob=$blob;originalWipPreserved=$true;otherHeldUnchanged=11;residualPatchSha256=$proof.expectedResidualWipPatchSha256;realIndexEmpty=(@(git diff --cached --name-only).Count -eq 0)} | ConvertTo-Json

