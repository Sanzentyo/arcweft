$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$publication=Read-Record 'callable-input-order-checkpoint.verified'
$runtime=Read-Record 'callable-input-order-owner2-20261105.runtime.terminal-audit'
$structure=Read-Record 'callable-input-order.structure'
$graph=Read-Record 'callable-input-order.graph'
if((git rev-parse HEAD).Trim() -ne $publication.commit -or $runtime.executed -ne 2272 -or $runtime.passed -ne 2272 -or $structure.exitCode -ne 0 -or $graph.selectedPackages -ne 58 -or $graph.metadataTreeDrift -ne 0){throw 'Unexpected source/results'}
foreach($row in (Read-Record 'callable-input-order-owner2-20261105.source-freeze').paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$before=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('callableInputOrder')){throw 'Preserve existing evidence'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$oldRows=@($status -split "`n"|Where-Object {$_ -match '^\| (RichTextの部分layout指定／source factory|共有契約／推移的逆依存matrix|CLI全target照合|workspace check／Clippy・fmt・構造gate) \|'})
$metrics=@(Import-Csv -LiteralPath "$taskTemp/callable-input-order-structure-report/file_metrics.csv"|Where-Object path -in $publication.paths.path)
if($metrics.Count -ne 28){throw 'Missing owner measurements'}
$metrics|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/callable-input-order.owner-metrics.json" -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like 'callable-input-order*'})
$files+=@(Get-ChildItem -LiteralPath "$taskTemp/callable-input-order-structure-report" -File -Recurse)
foreach($name in @('record-callable-input-order.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')){$files+=Get-Item -LiteralPath "$taskTemp/$name"}
$root=[IO.Path]::GetFullPath($taskTemp)
$index=@(foreach($file in @($files|Sort-Object FullName -Unique)){[ordered]@{entry=$file.FullName.Substring($root.Length+1).Replace([IO.Path]::DirectorySeparatorChar,[char]'/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$index|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/callable-input-order.archive-inputs.json" -Encoding utf8
$files+=Get-Item -LiteralPath "$taskTemp/callable-input-order.archive-inputs.json"
. "$taskTemp/write-verified-evidence-archive.ps1"
$archive='docs/implementation/acceptance-evidence/task-callable-input-order.raw.zip'
$raw=Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record.callableInputOrder=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$publication
    state='Intermediate ownership checkpoint. Application/snapshot provenance is implemented and owner-tested; executable-frame/provider forwarding and full acceptance remain pending.'
    implementation=@('One typed complete RuntimeInputOrder permutation is independent of formal ABI value storage and belongs to the live retained callable, pending default packet and invocation. No source/name reconstruction or global side table. All contract versions remain1; snapshots require new fields without legacy readers.','Native/AWBC ProjectCall derives logical order from actual physical operand coordinates. Declared projection includes omitted Optional/empty Rest slots. Retain/partial/default/Invoke transitions project the same order using RuntimeCallableInputSource, and specialization preserves it.','Live/inert views, unrestricted deep copy, strict callable/pending snapshots and canonical retained encoding preserve order. Original program and cumulative shape/metadata work/byte admission precede retained graph copying.')
    validation=[ordered]@{ownerLibrary=$runtime;command=(Read-Record 'callable-input-order-owner2-20261105.runtime').command;sourceRelation='4105 pinned actual inputs on base092c356c0a50d4748d1b8fca02cb4626fc17baa6 plus28 paths published as466c2d7bf8245d1f7dd0c3560db27d0d2f53f893. Source/case/executable drift0. Actual inputs include original12tracked+6untracked WIP, which is excluded from the publication.';positive='All2272 Core library cases PASS with0 skipped. Noncanonical retained copy/JSON restore/default terminal projection, moved slots, malformed order/arity/missing field, original-owner, affine and exact resource boundaries are exercised.';firstAttempt=(Read-Record 'callable-input-order-owner1-20261105.catalog');firstAttemptReason='Catalog compile101: one direct pending-packet fixture omitted input_order; repaired before owner2. No owner1 runtime ran.';fmt='Changed28 Rust paths: rustfmt edition2024/skip_children check0; staged whitespace0.';structure=$structure;graph=$graph;pending='Core library is not the full58-package closure. Complete reverse runtime, Compiler/public snapshot integration, final alias regression, full98 check/Clippy and Tier2/display/CLI acceptance remain pending.'}
    resourceContract=[ordered]@{unchanged='No engine defaults, jobs/profile, OneOp assertions, node counts, copy rules or capture conditions weakened.';callable='The one-retained-i64 exact encoded boundary changes21→23 bytes for the new order length/slot;23 succeeds and22 rejects. The existing test name now includes order, with its original retained value and one-short assertion preserved.';pending='Four original slots add5 bytes and5 work. The two-value boundary keeps max_nodes2 and becomes9 bytes/18 work; each one-short limit rejects in live/inert form. Empty moved slots still use0 value nodes but charge5 bytes/13 work, with12 work rejected.'}
    ownershipReview=[ordered]@{measurement='Archive contains exact28-path owner/bytes/physical/code/embedded-test LOC and complete package/dependency metrics. Scanner:98 packages,3336 files,3205 Rust files,385 review triggers,0 blocking violations.';disposition='RuntimeInputOrder owns permutation invariants, projection and strict serde. Callable application retains its cohesive state/affine/default algorithm; declared-group proof owns omission mapping. Existing Engine/VM dispatchers and borrowed value traversal gain only order transport/encoding; responsibility, I/O ownership and dependency direction are unchanged. Large owners touched only in malformed fixtures retain their existing disposition. Public exports are required by the same public snapshot contract, not physical splitting.';scope='No manifest/dependency change. New reverse closure58; full runtime/quality acceptance remains pending.'}
    remaining='Native synchronous/suspended function calls, PureEvaluator and AWBC frames still discard RuntimeCallableInvocation.input_order. Connect it to original scope/frame admission, rollback and public save, then explicitly forward it at external-declaration wrappers. Ordinary body-authored calls retain their own operand order. Source187 pt alias failure remains the last actual end-to-end evidence.'
    correctionReason='Replace prior current row with observed owner implementation/results. Keep Generic Match and earlier accepted boundaries accepted. Owner-only tests do not establish alias/px acceptance.'
    supersededCurrentRows=$oldRows;historyPrefix=$historyPrefix
    raw=[ordered]@{path=$archive;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0;indexEntry='callable-input-order.archive-inputs.json'}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$sha=$publication.commit
$rows=@(foreach($line in ($status -split "`n")){
    if($line.StartsWith('| RichTextの部分layout指定／source factory |')){"| RichTextの部分layout指定／source factory | **既受入を維持。callableの順序保持を中間公開、frame・単位は継続** | Source ${sha}で実引数順をformal格納順と独立したtyped permutationとしてcallable・継続packet・保存形式へ接続し、Core library2272／2272 PASS。最終frame／providerへの転送は未接続で、aliasの受入とはしない。直近のfactory実測Source187fb586261ac6ba381546532143fa20854dba8bはgeneric関数／closure quantityとAWBC各OneOp公開保存がPASS、一方pt合成は直接24pt／alias11pt、px2条件もpt限定schemaでFAIL。単位consumer・typed bare serif・static inline_stylesと全体受入を継続する。部分layout・共通property等の既受入は維持する。[順序ownerの実測・旧失敗・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){"| 共有契約／推移的逆依存matrix | **直近の全53実測を保持。今回の全58逆依存は未実行** | Source2aaa0480b171d15274737d7bd49a3c391ce19096の全53実runは7808件中7793 PASS／15 CLI FAIL、40 skipped。50 packageに実テストがあり、3 packageはbuildのみ。source／case／EXE drift0。中間Source${sha}はCoreを含む5 ownerの実graphで58 package、normal／build／dev・all target／all featureのmetadata／tree差分0。Core library2272件のPASSを全58の実行とは扱わない。[全実測・新graph・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| CLI全target照合 |')){$line.Replace('中間Source 187fb586261ac6ba381546532143fa20854dba8b',"中間Source $sha")}
    elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){"| workspace check／Clippy・fmt・構造gate | **中間cutはfmt・構造gateが終了0。全体check／Clippyは未再実行** | Source${sha}は変更Rust28件のfmt・staged whitespaceと全98 packageの構造gateが終了0（blocking0、review trigger385）。全98 check／Clippy（all-target／all-feature／locked）の直近の終了0はSource2aaa0480b171d15274737d7bd49a3c391ce19096で、警告は残存する。ユーザー指定の全体cargo cleanはSource187fb586261ac6ba381546532143fa20854dba8bで終了0、ソース・記録・Git差分0。doctest／wasm専用検証は未再実行。[測定・owner review・cleanを含む履歴とraw](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-05 — Callable input-order ownership checkpoint

- Source $sha (parent $($publication.parent)) publishes28 Rust paths. One typed permutation belongs to retained callable/default packet/invocation, independently of formal ABI storage. Actual Native/AWBC operand coordinates establish its group order. Specialization, deep copy, strict snapshots and canonical retained encoding preserve it; no legacy reader/version increase.
- Core all-feature/locked library:2272/2272 PASS,0 skipped;4105 inputs and case/executable inventories have zero drift. Initial catalog101 from one missed fixture field remains separate. New noncanonical copy/JSON restore/default continuation and malformed/one-short conditions pass. Exact thresholds include metadata; engine defaults, node counts and assertions remain unchanged.
- Actual5-owner reverse closure58 packages, all targets and normal/build/dev; metadata/tree difference0. The98-package structural gate exits0 with385 review triggers/0 blocking; owner measurements and cohesion rationale are retained. Changed28 Rust fmt/whitespace exit0. Full58 runtime/full98 check/Clippy remain pending.
- This is not final alias-order acceptance: Native/PureEvaluator/AWBC scope/frame and external-forwarding consumers still need the invocation's order. Keep Source187's pt alias11pt/direct24pt and px2 failures. Accepted Generic Match and other completed boundaries remain accepted. [Existing evidence and raw](acceptance-evidence/task-rich-text-property-identity.json) retain all earlier fields/results/SHAs; [current-status.md](current-status.md) remains the only current list.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw "Prior field changed: $key"}}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $historyPrefix.sha256){throw 'History prefix changed'}
[ordered]@{source=$sha;priorFieldDrift=0;historyPrefixDrift=0;rawEntries=$raw.entries.Count;rawBytes=$raw.bytes;rawSha256=$raw.sha256;sourceMetrics=$metrics.Count}|ConvertTo-Json -Compress
