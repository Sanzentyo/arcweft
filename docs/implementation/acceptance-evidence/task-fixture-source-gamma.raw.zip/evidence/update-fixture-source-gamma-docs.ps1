$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/fixture-source-gamma.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/fixture-source-gamma.owner-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/fixture-source-gamma.archive.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/fixture-source-gamma.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -cne $pub.Source -or @(git diff --name-only HEAD).Count -or $owner.Passed -ne 1681 -or $owner.Failed -ne 6){throw 'Owner evidence differs'}
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
if((Get-FileHash $statusPath).Hash -cne $before.StatusSHA256){throw 'Status changed'}
$status=[IO.File]::ReadAllText($statusPath)
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `72df8edc204aec4009fd04884f8b46dd4dbc5a15`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
$rows=[ordered]@{}
$name='再帰関数値の終端効果'
$row=[regex]::Match($status,'(?m)^\| '+$name+' \|[^\r\n]*').Value
$row=$row.Replace('最新Source `72df8edc204aec4009fd04884f8b46dd4dbc5a15` の数学層は','数学層の実装Source `72df8edc204aec4009fd04884f8b46dd4dbc5a15` は')
$row=$row.Replace('新6件を含む数学層56件が全owner runでPASS。','新6件を含む数学層56件が全owner runでPASS。Γ移行用fixtureはSource `'+$pub.Source+'` で独立した宣言Γを明示し、元frameを保持して既存のproduction admissionへ通す。値や候補から参照権限を集めず、移行した2件と新3件を含む対象8件は最新の全ownerでもPASS。')
$row=$row.Replace('[将来値の保持](convergence-evidence-history.md#future-effect-function-specialization)。','[将来値の保持](convergence-evidence-history.md#future-effect-function-specialization)・[fixtureのΓ](convergence-evidence-history.md#explicit-fixture-source-gamma)。')
$rows[$name]=$row
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,681 PASS／6 FAIL。逆依存は直前Sourceの2,507 PASS／2 FAIL／1 SKIPを再利用** | 最新Source `'+$pub.Source+'` の全feature Sema lib／testsは1,687件、73.649秒、選択と終端の全ID一致・重複0。直前1,684 IDをすべて維持し、新3件はPASS。既知6失敗のIDと実診断は同じ5 ExpressionCycle／1 PendingCallableEffectProjection。今回の変更はcfg(test)の元Source宣言・Γ admission fixtureとその検証だけで、productionと他ownerは変更しない。他21 package・規定107 targetの2,510 IDはSource `1914f17ba506ea591ed49cd5690bc31c27b332d3` の実行を再利用し、最新Sourceの再実行とはしない。Compiler既知2失敗とslot 17／19もその入力の実測。owner全featureとconsumer既定featureは別sliceである。[最新owner原本](acceptance-evidence/task-fixture-source-gamma.raw.zip)・[直前の逆依存原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新owner check／Clippy・fmtは終了0。workspace品質と構造gateは既存実測を再利用** | Source `'+$pub.Source+'` のlocked Sema全target／全feature check／Clippy、owner fmt checkを今回実行。変更3 pathのbyte pin・公開blobと各step前後のSource／tree／tracked差分0を照合した。cfg(test)内の変更だけでproduction・他owner・Cargo入力・公開doc実行例・toolchain・featuresは不変。workspace全target／全feature check／Clippy・workspace fmt・Sema doctest 2件はSource `1914f17ba506ea591ed49cd5690bc31c27b332d3`、構造gateはSource `72df8edc204aec4009fd04884f8b46dd4dbc5a15` の終了0（review trigger396・blocking0）を再利用する。新しいsize／growth triggerはない。警告を原本に保持。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持する。Tier 2・新しい再帰本体のNative／AWBC・Native／Web受入へ拡張しない。[最新owner原本](acceptance-evidence/task-fixture-source-gamma.raw.zip)・[構造gate原本](acceptance-evidence/task-future-effect-functions.raw.zip)・[workspace品質原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
foreach($name in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($name)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row is not unique'}
    $replacement=$rows[$name]
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
if((Get-Item $historyPath).Length -ne $before.HistoryBytes -or (Get-FileHash $historyPath).Hash -cne $before.HistorySHA256){throw 'History prefix changed'}
$addition=@'

## Explicit fixture source gamma

2026-11-13。Source `647403f016195194eb252876ec5e57ecfa3095c6`、tree `2cade5aa75c8bf23f17b8b57e7d43facf66f819e`、親・変更基点 `6abaf2aa93211b96f2e8322f8551fa34b774c03c`。既存mainで通常commit／non-forced pushし変更3 blobを照合。未追跡 `%SystemDrive%/` を保持した。

cfg(test)のFixtureOriginalSourceはgroundと明示宣言を区別し、宣言type／const／effectと任意の既存import leaseを独立したfixture入力として保持する。値や受け手のinventoryからΓを作らない。fixture_operand_inは元Γの実frameを保持し、productionのOriginalOperandValue admissionへ入る。frame共有前の取消し・作業量を検査する。旧ground helperの空Γを広げず、無条件に参照を許すoriginも追加しない。既存のtype／const／effect・Fn predicateの2件をこの入口へ移した。production source-ownerを直接使う別のnegativeとbudget testも維持する。

対象8件と、最終Sourceの全feature Sema lib／testsを実行。全1,687件中1,681 PASS／6 FAIL／0 SKIP、73.649秒、slow0。5 binaryで選択・終端ID一致、重複0、直前1,684 IDをすべて保持、新3件はPASS。元Γに参照がない場合と下位環境に変数がない場合を区別し、候補側の許可で前者を通さない。同形の別frameを現在contextから採用せず、元frameを保持すること、共有前の予算拒否、source identityと重複／不正rigid入力の拒否も確認した。既知6失敗は同じID・実診断の5 ExpressionCycle／1 PendingCallableEffectProjection。数学層56件を含む既存のassertion・budget・probe／replayを弱めていない。

locked owner全target／全feature check／Clippyとowner fmt checkは終了0。各step前後のSource／tree／tracked差分0と3 pathのbyte pin・公開blob・出力hashを照合した。警告は原本へ保持。合計成長186 physical LOCで新しいsize／growth triggerなし。全変更はcfg(test)宣言・実装か既存のtest owner内であり、production・他owner・依存edge・公開API・codec・versionを変えない。CARGO_INCREMENTAL=0、jobs／profile上書きなし。

このため、調査済み22 package graphと他21 package・規定107 targetのSource `1914f17ba506ea591ed49cd5690bc31c27b332d3` の2,510 ID（2,507 PASS／2 FAIL／1 SKIP）、同Sourceのworkspace check／Clippy・workspace fmt・Sema doctest2件を再利用する。構造gateはSource `72df8edc204aec4009fd04884f8b46dd4dbc5a15` のreview trigger396・blocking0を再利用。元SHAを保持し、新規実行へ読み替えない。Γの全producerへの適用、checked primitive effect owner、条件付きcompletionとfrontend接続は継続し、このfixture準備をその受入とはしない。Generic Match、caller-bound recursion、共有prefix、完了値capture、header portの既受入を戻さず、過去の実測・full SHAを保持する。全体cargo cleanは9:08の履行を維持した。

[最新owner原本](acceptance-evidence/task-fixture-source-gamma.raw.zip)は@@ENTRIES@@ entry、展開時@@RAW_BYTES@@ bytes、ZIP @@ZIP_BYTES@@ bytes、SHA-256 `@@ZIP_SHA@@`。manifestと全entryの長さ・hash・portable pathを読み戻して照合した。再利用のSourceと理由も原本へ区別して保持する。
'@
$addition=$addition.Replace('@@ENTRIES@@',[string]$archive.Entries).Replace('@@RAW_BYTES@@',[string]$archive.RawBytes).Replace('@@ZIP_BYTES@@',[string]$archive.ZIPBytes).Replace('@@ZIP_SHA@@',$archive.SHA256.ToLowerInvariant()).Replace("`r`n","`n")+"`n"
[IO.File]::AppendAllText($historyPath,$addition,[Text.UTF8Encoding]::new($false))
git diff --check
if($LASTEXITCODE -ne 0){throw 'Whitespace validation failed'}
