$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-defer-custody-20261108'
$source=Get-Content -LiteralPath "$taskTemp/$prefix.source.verified.json" -Raw | ConvertFrom-Json
if((& git rev-parse HEAD).Trim() -ne $source.commit){throw 'Published source differs'}
$quality=[ordered]@{}
foreach($name in @('core','compiler','scoped','fanout','docs','clippy','structure','fmt')){
 $receipt=Get-Content -LiteralPath "$taskTemp/$prefix.quality.$name.receipt.json" -Raw | ConvertFrom-Json
 if($receipt.exitCode -ne $(if($name -eq 'compiler'){100}else{0})){throw "Unexpected quality result: $name"}
 $quality[$name]=$receipt
}
$cleanup=Get-Content -LiteralPath "$taskTemp/$prefix.cleanup.receipt.json" -Raw | ConvertFrom-Json
$cleanupSource=Get-Content -LiteralPath "$taskTemp/$prefix.cleanup.source.json" -Raw | ConvertFrom-Json
if($cleanup.exitCode -ne 0 -or -not $cleanupSource.exactDeletionVerified){throw 'Final cleanup is not verified'}
foreach($row in $cleanup.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Published source differs from final lint'} }
$ledgerPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($ledgerPath)
if($before.Contains('"awbcOrdinaryDeferCustody"')){throw 'Custody evidence already exists'}
$archivePath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-awbc-ordinary-defer-custody.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Raw archive exists'}
$names=@(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*" | ForEach-Object Name)+@('run-awbc-defer-custody-quality-20261108.ps1','record-awbc-defer-custody-20261108.ps1') | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object {Join-Path $taskTemp $_}) -DestinationPath $archivePath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
 if($zip.Entries.Count -ne $entries.Count){throw 'Archive count differs'}
 foreach($entry in $zip.Entries){
  $expected=$entries | Where-Object entry -eq $entry.FullName
  $stream=$entry.Open()
  try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
  if($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256){throw 'Archive entry differs'}
 }
}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';source=$source
 behavior=@('A prepared function fiber owns its actual allocated root frame and exact positional input destinations before captures leave their packet.', 'Ordinary deferred registration, unwind, filtered skip and child instructions reconcile the complete ordinary-fiber custody graph with the published issuers. Filtered skips authorize only removed capture tokens.', 'One physical collector includes root and lexical deferred packets. Live reconciliation and inert restore use the same slot projection; saved admission checks every published receiver lease against actual ordinary and foreign receiving storage.', 'Line callbacks, Program task and fanout share the prepared function-frame owner. The duplicate owned-task wrapper, old tuple allocator, unused identity getter and partial AWBC-fiber classifier are removed. Public save and slot grammar remain version 1.')
 actual=[ordered]@{
  core=[ordered]@{run=2323;passed=2323;failed=0;skipped=0;receipt=$quality.core}
  compiler=[ordered]@{run=108;passed=105;failed=3;skipped=0;receipt=$quality.compiler}
  scopedDefer=[ordered]@{run=30;passed=30;failed=0;skipped=0;receipt=$quality.scoped}
  fanout=[ordered]@{run=4;passed=4;failed=0;skipped=162;receipt=$quality.fanout;note='Exact program_fanout filter across the RuntimePlan catalog; 162 excludes unselected cases and the existing ignored generator. Not a fresh complete RuntimePlan run.'}
  coreDocs=[ordered]@{passed=80;failed=0;receipt=$quality.docs}
  captureCases=[ordered]@{run=5;passed=5;failed=0;skipped=103;receipt=(Get-Content -LiteralPath "$taskTemp/$prefix.r3.receipt.json" -Raw | ConvertFrom-Json);operationBound=1;tickBound=512;stageAcquireAndRelease=1;conditions=@('direct returned Actor','Actor inside a tuple','outcome filter skips cleanup and releases the Actor','nested ordinary registration transfers the same Actor','public restore rejects packet/child coordinate forgeries and a missing capture packet, then the original execution still completes')}
  quality=$quality
  finalCleanup=[ordered]@{source=$cleanupSource;receipt=$cleanup;fmt=(Get-Content -LiteralPath "$taskTemp/$prefix.cleanup.fmt.receipt.json" -Raw | ConvertFrom-Json);reuse='The runtime tests, doctests and full Core/Compiler lint ran before deleting the now-unused private identity getter. The exact four-line deletion was verified, all other frozen behavior inputs stayed unchanged, and final Core all-target/all-feature Clippy plus 10-path fmt passed. These runtime results are reused for their unchanged behavior, not reported as new runs of the final bytes.'}
 }
 developmentFailures=@(
  [ordered]@{receipt="$prefix.first.receipt.json";failure='E0599 at two Program task consumers of the removed tuple allocator';resolution='Migrate both consumers and fanout onto the same prepared function-frame owner; remove the duplicate task wrapper.'},
  [ordered]@{receipt="$prefix.r2.receipt.json";failure='E0599: active_frame was only defined for live FiberState';resolution='Generalize the existing owning accessor to live and inert fiber parameters, rather than reconstructing a frame at the consumer.'}
 )
 remainingFailures=@('ordinary_defer::native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line: AffineGroupCapture; initial owned Line inputs and post-reveal shared inputs are not separated','ordinary_defer::saved_awbc_nested_deferred_line_uses_the_innermost_capture_frame: ordinary deferred child has no product dialogue dispatch','ordinary_defer::saved_awbc_generic_deferred_line_uses_each_closed_capture_frame: same product dialogue dispatch boundary')
 corrections=@('Delete the current AWBC ordinary-defer handle-registration rejection clause because its original input and four additional capture/rejection cases now pass through each-step public save/cold restore.', 'Retain the original 104-case 100 PASS/4 FAIL run and the initial invalid-transition reproduction as history. The new 108-case run is 105 PASS/3 FAIL; do not rewrite or combine the earlier counts.', 'Previously accepted Generic Match, Line/init and bounded Native features remain accepted. Remaining work is limited to concrete failing boundaries and the still-unmet wider acceptance conditions.')
 ownershipReview=(Get-Content -LiteralPath "$taskTemp/$prefix.ownership-review.json" -Raw | ConvertFrom-Json -Depth 15)
 limits=@('No fresh complete Core53 reverse-closure or workspace-wide check/Clippy matrix is claimed. The resolved Cargo graph and manifests remain unchanged.', 'Native initial owned Line inputs and ordinary AWBC deferred-dialogue dispatch remain open; the 5 capture cases do not establish these separate capabilities.', 'AWBC cancellation and aggregate registration/child preconstruction limits, final Native public save and Native/Web visual acceptance remain wider convergence conditions.', 'Warnings, including the prepared transition enum size review, remain in the raw lint evidence. No performance improvement is claimed.')
 raw=[ordered]@{path='task-awbc-ordinary-defer-custody.raw.zip';sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$fragment=([ordered]@{awbcOrdinaryDeferCustody=$record} | ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($ledgerPath,$after,[Text.UTF8Encoding]::new($false))
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — AWBC 通常 defer の所有捕捉と実フレームへの移譲

Source **$($source.commit)** を既存 main へ通常 commit/push し、親・tree・全 blob・完全差分を照合した。登録packetのroot／lexical捕捉を同じ物理slot収集へ入れ、捕捉を抜く前に実際の子frameと入力registerを確定する。通常fiber全体の前後グラフと発行元leaseを照合してから移譲し、条件不一致のcleanupはその捕捉tokenだけを正規に破棄する。公開復元は一部fiberだけの選択検査を置換し、普通のfiberと他Lineが受け取った値を含む実slotと全published receiver leaseを照合する。Program task／fanoutも同じ準備済みframeを使用し、旧tuple allocator、重複wrapper、未使用getter、部分的なfiber分類を除いた。wire／save／slot versionは1のまま。
対象5件はPASS。直接・tuple・入れ子のActor捕捉と条件不一致時の解放を、元の1-op／512-stepと取得・解放各1回、毎stepの公開JSON保存／cold restoreで確認した。packetのexecution／fiber／frame／registration／ordinal／scope、実行中の子のexecution／fiber／frameを改変し、packetそのものを除いた保存も拒否し、拒否後の元executorで完走した。Core2323 PASS、evaluated_effectsは108件中105 PASS／3 FAIL、通常defer30 PASS、選択したfanout4 PASS／162 SKIP、Core doctest80 PASS。fanoutのSKIPは選択外と既存ignored generatorを含み、前の完全165件runに合成しない。Core・Compiler全target／全feature Clippy、10 path fmt、構造gateは終了0。
これらruntime検証の後、未使用private getterだけを4行削除した。ほかの固定入力は不変で、その差分を照合し、最終Core全target／全feature Clippyと10 path fmtを再確認した。runtime結果は挙動不変の再利用で、最終bytesの新規runとは呼ばない。警告と開発時のE0599も原本へ保持する。元入力が通ったため、AWBCの捕捉登録拒否を現状から削除した。旧104件中100 PASS／4 FAILと全SHAはそのまま履歴に保持する。残る3失敗はNativeの初期Line所有入力1件と、AWBC defer子の対話開始2件の2境界。既受入を全体goal未達で戻さない。[全実測・訂正・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。Core53／全workspaceの最終matrixは未実施。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=$status -split "`n"
$match=@(0..($lines.Length-1) | Where-Object {$lines[$_].StartsWith('| 通常 Flow の scoped defer |')})
if($match.Count -ne 1){throw 'Current ordinary Flow row differs'}
$lines[$match[0]]='| 通常 Flow の scoped defer | **Native の既受入を保持。通常 cleanup・goto／Choice・待機・Flow registry、所有するLine handleのdefer捕捉は対象を検証・公開済み。全体受入は継続中** | 関数本体・明示scopeのLIFO、generic捕捉／戻り値、registryの読書き・drop／置換、cleanup後のgoto／Choice移譲、失敗時のcaller drain、待機と毎step version 1公開保存／cold restoreを検証済み。raw Return／Completeはopen scopeを拒否する。直接outするActor取得・効果付き関数の値継続を両実行器で、cleanup内Lineの入れ子・2型genericをNativeで確認した。Source '+$source.commit+' はAWBCの捕捉packetと実際の子frameをlease照合へ接続し、直接・tuple・入れ子のActor捕捉、条件不一致時の解放、改変保存の拒否の5件がPASS。元入力が通ったため旧登録拒否を削除した。evaluated_effectsは108件中105 PASS／3 FAIL。残る実測は、Line開始時の所有入力と開始後の共有入力の未分離（Native 1件）と、AWBC defer子からの対話開始拒否（2ケース）の2境界。AWBC取消し・登録／子構築前の集約検査も継続中。必須registry読取りには静的存在証明が必要。[全実測・訂正理由・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$match=@(0..($lines.Length-1) | Where-Object {$lines[$_].StartsWith('| workspace check／Clippy・fmt・構造gate |')})
if($match.Count -ne 1){throw 'Current quality row differs'}
$lines[$match[0]]='| workspace check／Clippy・fmt・構造gate | **直近の全workspace gateはSource b6dfで終了0。追加Sourceのowner gateも終了0** | 全workspaceの直近入力はSource `b6df0c825805b9ac77cad6a9760761a861007679`。最新runtime差分はCore2323 PASS／doctest80 PASS、Compiler通常defer30 PASS、RuntimePlanの選択fanout4 PASS／162 SKIP。Core・Compiler全target／全feature Clippy、10 path fmt、構造gateが終了0。最後の未使用private getter削除後はCore全target／全feature Clippyとfmtを再確認した。前段のruntime結果は挙動不変の再利用として原本に区別する。Compiler evaluated_effectsの3失敗は通常Flow行で追跡する。旧件数・初回失敗・警告・全SHAは履歴に保持する。新Sourceの全workspace／Core53最終再検証は未実施。他platform／Tier2の受入へ拡張しない。[全実測・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;entries=$entries.Count;rawSha256=$record.raw.sha256;corePassed=2323;compilerPassed=105;compilerFailed=3;captureCases=5;fanoutPassed=4;docsPassed=80} | ConvertTo-Json
