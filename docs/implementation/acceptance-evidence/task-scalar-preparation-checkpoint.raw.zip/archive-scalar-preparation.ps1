$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '7da8e84b631fcce67ed30b7bdef3023a432b604d'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'scalar-preparation.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='TypeLeaf owns one effect-independent scalar compatibility algebra used by both canonical SelectedCall/Recovery/structural checking and prepared binding planning. Identical scalar kinds use their typed equality; established actor erasure, character identity, compile-time enum/Fx acceptance, ActionName and AgentValue rules remain explicit. The copied canonical leaf arms and scalar AgentValue list are deleted; no prepared tree is reconstructed as canonical and no function row is solved. The canonical scalar header factory preserves Recovery handling of placeholder names only after existing strict forbidden checks; it cannot admit a placeholder as a prepared operand. Direct scalar relations now prune mismatches and retain provisional compatible paths without invoking final effect closure on unrelated Named bodies. Original equality remains exact rather than directional widening. Context reference/header validation is parameterized by the existing effect domain because it reads type/const ports only. The occurs grammar is aligned with its real prepared binding values and follows aliases/actual nested scopes without effect solving; the existing nested binder/cycle assertions retain the same budget and now receive the real graph and prepared authored headers. Four new fixtures cover mismatches and matches with an unavailable unrelated body, directional ActionName acceptance versus original equality, actor-handle identity direction, and Recovery versus strict placeholder policy. Their execution remains unrun because the library/test targets fail. Old composite eager acceptance, final transaction/solution callers, fixture graph loans, full frontend switch and acceptance remain pending; this cut does not claim to have removed all eager completion. New internal TypeLeaf visibility serves actual canonical/prepared consumers, not a physical file split; private responsibilities remain in compatibility, with context and normalization retaining their existing scoped admission/occurs owners. No second type grammar, resolver/catalog, public facade, Cargo dependency/feature, layer direction, I/O, unsafe, codec/version, production budget, jobs or profile change. Exact base/current size, growth, test classification and inline test LOC are recorded. The existing resolved dependency graph and reverse-dependency evidence are reused; no workspace structural scanner run.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'scalar-preparation.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'scalar-preparation.'+$iteration+$suffix}})
$names+=@('scalar-preparation.source-publication.json','scalar-preparation.ownership-review.json','scalar-preparation.staged-review.json','scalar-preparation.dev03-diagnostic-review.json')
$names+=@('run-scalar-preparation-check.ps1','archive-scalar-preparation.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-scalar-preparation-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-scalar-preparation-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'scalar-preparation.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
