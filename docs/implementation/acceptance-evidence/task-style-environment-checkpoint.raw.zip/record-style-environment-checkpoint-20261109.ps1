$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-environment-20261109.source-checkpoint.verified.json'
$owner=Read-Record 'style-environment-20261109.owner-r2.runtime.terminal-audit.json'
$first=Read-Record 'style-environment-20261109.owner-r1.catalog.json'
$quality=@(foreach($gate in @('check','clippy','structure','fmt')){Read-Record "style-environment-20261109.quality.$gate.receipt.json"})
$lint=Read-Record 'style-environment-20261109.final-test-lint.json'
$fmt=Read-Record 'style-environment-20261109.final-test-fmt.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit -or $owner.actualExitCode -ne 0 -or $owner.executed -ne 55 -or @($quality|Where-Object exitCode -ne 0).Count -or $lint.exitCode -ne 0 -or $fmt.exitCode -ne 0){throw 'Source or checks changed'}
$archive='docs/implementation/acceptance-evidence/task-style-environment-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(Get-ChildItem -LiteralPath $r -File -Filter 'style-environment-20261109*'|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')})
$files+=@('run-style-environment-owner-20261109.ps1','run-style-environment-owner-r2-20261109.ps1','run-style-environment-quality-20261109.ps1','run-style-environment-consumers-20261109.ps1','run-style-environment-cli-consumers-20261109.ps1','record-style-environment-checkpoint-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';publication=$pub
 status='Source-bound Style environment conditions implemented, owner-verified and published. Complete View consumer execution is pending.'
 model='Use the existing native ViewEnvironmentTest and canonical sourced conjunction. Sema issues a private-field proof bound to the original Style item, body path, wrapper/clause ordinals and value ExprId, recomputes it from HIR before final publication, and records the native test semantic digest. CompileTimeStyle Environment role12 is semantic-only. No fake HIR annotations/expressions, product Source IDs or runtime values. Compiler StyleBodyLowerer owns the one source table and global authored rule order across nested and unconditional bodies; preserve exact clause and wrapper predicate/body/scope sources. Remove former root-only lowering and blanket environment rejection.'
 grammar='Closed enum/bool fields admit equality only: color-scheme light/dark, contrast standard/more, reduced-motion true/false. The native predicates represent exact values; Source parsing of a generic comparison operator does not admit every operator for every field. Text-scale supports all six native comparisons and exact unsuffixed integer/decimal or percent literals in 500..4000 milli. Reuse scalar literal and HIR exact decimal conversion; do not use the Ratio carrier with a 1000 ceiling. Reject rounding, clamping, runtime/token expressions, suffixes and other units.'
 bounds='Preflight native MAX_WRAPPERS4/MAX_CLAUSES4 before descent/frame clones; no repeated field across an ancestor path, siblings remain independent. Native sourced conjunction remains final canonical, field and wrapper-use validator. No Cargo edge, I/O, unsafe, wire shape or non-1 version marker change.'
 development=(Read-Record 'style-environment-20261109.dev-check-r1.json')
 initialCatalog=$first
 initialFailure='Initial owner catalog exited101 before running tests: Windows paging-file exhaustion, OS1455 while mmap-ing the original arcweft_bundle rlib, followed by invalid-metadata/ICE cascades. Preserve the actual log. Wait for terminal completion, then retry unchanged Source/selection/Cargo settings. No extra clean, artifact movement or jobs reduction.'
 owner=$owner;quality=$quality;finalTestLint=$lint;finalTestFmt=$fmt
 qualityToFinalScope=(Read-Record 'style-environment-20261109.quality-to-final-scope.json')
 graph=(Read-Record 'style-environment-20261109.graph.json');reverseDependencyTree=(Read-Record 'style-environment-20261109.tree-invert.json')
 ownerReview=(Read-Record 'style-environment-20261109.owner-review.json')
 scope='Owner55/55 pass, 2559 filter skips, 4.902s, 3920 Source/catalog/EXE drift0. All98 locked/all-target/all-feature workspace check/Clippy, structure and explicit18-path fmt pass. Then correct two equivalent spellings in the new Compiler integration test only; production drift0, final target Clippy/fmt pass. The subsequent View41 matrix must validate final bytes; owner55 is not that matrix.'
 pending='Full View consumer runtime execution; remaining sample migration and actual Native/Web operation/capture parity; the separately diagnosed four CLI failures. Accepted token inference, explicit Style construction, Generic Match and other completed functions remain accepted.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 148 -or $prior.PSObject.Properties.Name -contains 'styleEnvironmentSourceCheckpoint'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "styleEnvironmentSourceCheckpoint": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$styleRow='| Style 指定値・token・構築処理 | **構築・推論の受入を維持。EnvironmentのSource接続をowner検証・公開** | Environment Source '+$pub.commit+'。元sheet・body path・clause・ExprIdに結び付けた検査結果を既存native条件型へ渡し、入れ子のpredicate／body／scope／clauseの正確なSourceと全ルールの記述順を保持する。閉じた値の等値条件、text-scaleの6比較・0.5〜4.0の正確なmilli値、最大4 wrapper／4非重複fieldを扱う。owner55件が全PASS。全98 workspace品質と、その後のtest表記だけの整理は下表／原本へ分離する。最終SourceのView逆依存41 package実行は継続する。推論Source f8c17506c05ee9df614581d8df12e46a2c178464の全Sema consumer受入と、明示構築の既受入を保持する。残るsampleと実Native／Web操作／表示は継続。[全SHA・実測・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$qualityRow='| workspace check／Clippy・fmt・構造gate | **Environment接続のworkspace gateは終了0** | Source '+$pub.commit+'。全98 package・全target・全feature・locked check／Clippy、構造gate、明示18 Rust pathのfmtが終了0（3920入力drift0、警告あり）。後続変更はCompilerの新test1 pathの等価な表記2件だけで、本番Source／assertion／予算の差分0。最終test対象Clippyとfmtも終了0。owner55件と全consumer実行は区別する。[gate・差分範囲・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status=(@($status -split $lf|ForEach-Object {
 if($_.StartsWith('| Style 指定値・token・構築処理 ')){$styleRow}
 elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate ')){$qualityRow}
 elseif($_.StartsWith('| 共有契約／推移的逆依存matrix ')){$_.Replace('**今回Sema範囲4333実行：','**前回Sema範囲4333実行：')}
 elseif($_.StartsWith('確認日 ')){$_.Replace('f8c17506c05ee9df614581d8df12e46a2c178464',$pub.commit)}
 else{$_}
})) -join $lf
if(($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — Style Environmentの元Source接続

Source $($pub.commit) をmainへ通常公開し、parent／tree／19 pathのblobとpatchを照合した。Semaは元Style／body path／wrapper・clause ordinal／value ExprIdからnative testを検査・発行し、final validationで元HIRから再検証する。Environmentはsemantic-only Style operand role12で、native component digestをtranscriptへ含める。製品Source IDやruntime値、HIRを捏造していない。CompilerのStyleBodyLowererが一つのSource表と全体のrule記述順を所有し、nested wrapperとclauseの元Sourceをcanonical native条件へ渡す。従来のroot-only body lowering／Environment一律拒否を削除した。

閉じたnative predicateは等値を表すため、color-scheme light／dark、contrast standard／more、reduced-motion boolは等値文法にした。text-scaleはnative6比較と500..4000 milliの正確な値を使い、unsuffixed整数／小数・percentを受理する。Ratioの1000上限を流用せず、共通scalar literal／HIR decimal変換を再利用し、丸め・clamp・runtime式・token・suffix・他unitを拒否する。4 wrapper／4非重複fieldをdescent／frame clone前にpreflightし、final native constructorがcanonical順・wrapper使用・重複を検証する。Siblingは独立する。Cargo依存方向、I/O、unsafe、wire shape、version 1は維持した。

開発checkは終了0。初回owner catalogはWindowsのpaging-file不足OS1455で元rlibのmmapに失敗し、invalid metadataとICEが続いて終了101。テスト実行前の失敗として原本へ保持した。全handle終了後、Source・selection・Cargo設定を変えずに再試行し、55／55 PASS・2559 filter SKIP・4.902秒、3920入力／catalog／実EXE差分0。canonical codec往復、四段nestedの正確なSource・rule順、4field、text-scale全比較／両表記／境界、誤値／operator／重複拒否、元clauseのsemantic-only証明、native test payload digestを確認した。

全98 workspaceのlocked／all-target／all-feature check・Clippy、構造gate、明示18 Rust pathのfmtが終了0。後からCompiler新test1 pathだけのraw文字列delimiter／等価method closureを整理し、最終対象Clippy／fmtが終了0。本番Source／assertion／fixture／budget差分0で、このscopeを分離した。metadataとtarget-all invert treeはView逆依存41 packageで一致する。全consumer runtimeは次に実行し、owner55件を最終matrixに転用しない。既知CLI4件、残るsampleと実Native／Webは具体的な別境界として継続する。

現状一覧のEnvironmentを実装未達からowner検証・公開へ更新した。全consumerはpendingと明記し、構築・推論やGeneric Match等の既受入を維持する。以前のSource／失敗／full SHA／実測は保持し、旧現状の重複は履歴へ集約した。既存148 registry propertyの値を全件照合して保持し、styleEnvironmentSourceCheckpointを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。EXE／AWFB等のbuild artifactをZIPへコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;owner=$owner.summary;archive=$entry.archive}|ConvertTo-Json -Depth 6|Set-Content "$r/style-environment-20261109.acceptance-record.json"
Get-Content "$r/style-environment-20261109.acceptance-record.json"
