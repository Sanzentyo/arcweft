$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$new=@(Get-Content "$r/style-environment-20261109.additional-paths.json" -Raw|ConvertFrom-Json)
$selection=@('--locked','--all-features','--lib','--tests','-p','arcweft-lang-sema','-p','arcweft-view','-p','arcweft-compiler','-E','test(style_) | test(component_semantic_identity) | test(specified_style_values_and_operands)')
& "$r/run-retained-input-frozen-matrix-20261108.ps1" -Stem 'style-environment-20261109.owner-r1' -Selection $selection -AdditionalPaths $new
exit $LASTEXITCODE