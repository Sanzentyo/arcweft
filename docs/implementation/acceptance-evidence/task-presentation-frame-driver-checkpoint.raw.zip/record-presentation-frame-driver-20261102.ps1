$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$source='9bd9fe195ec3da493bce853ad644ca0e03e85052'
$nl=[string][char]10
$cr=[string][char]13
$utf8=[Text.UTF8Encoding]::new($false)
if((git rev-parse HEAD).Trim() -ne $source){throw 'Unexpected documentation base'}
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Json([string]$name){Get-Content -LiteralPath "$taskTemp/$name" -Raw|ConvertFrom-Json -Depth 100}
function Hash-Bytes([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $nl|Where-Object {$_.StartsWith('| Generic Match ')}) -join $nl
if(-not $generic){throw 'Accepted Generic row missing'}
$genericHash=Hash-Bytes ($utf8.GetBytes($generic))
$historyPath='docs/implementation/convergence-evidence-history.md'
$historyBefore=[IO.File]::ReadAllBytes($historyPath)
$historyHash=Hash-Bytes $historyBefore
$freeze=Read-Json 'presentation-frame-driver-quality2.source-freeze.json'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Published source differs: '+$row.path)}}
$rawFiles=@(
    Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
        $_.Name -match '^(presentation-frame-(api|source|driver)|run-presentation-(frame-driver|projection-owner)|record-presentation-frame-driver)' -and
        $_.Extension -in @('.json','.log','.patch','.ps1','.txt','.rs')
    }
    Get-ChildItem -LiteralPath "$taskTemp/presentation-frame-driver-quality2-20261102.structure-report" -File
)|Sort-Object FullName -Unique
$rows=@($rawFiles|ForEach-Object {[ordered]@{path=[IO.Path]::GetRelativePath($taskTemp,$_.FullName).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})
$destination='docs/implementation/acceptance-evidence/task-presentation-frame-driver-checkpoint.raw.zip'
if(Test-Path -LiteralPath $destination){throw 'Evidence archive already exists'}
$zipStream=[IO.File]::Open($destination,[IO.FileMode]::CreateNew)
$zip=[IO.Compression.ZipArchive]::new($zipStream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($row in $rows){
        $entry=$zip.CreateEntry($row.path,[IO.Compression.CompressionLevel]::Optimal)
        $entry.LastWriteTime=[DateTimeOffset]::new(2026,11,2,0,0,0,[TimeSpan]::Zero)
        $writer=$entry.Open()
        try {$reader=[IO.File]::OpenRead("$taskTemp/$($row.path)");try{$reader.CopyTo($writer)}finally{$reader.Dispose()}}
        finally{$writer.Dispose()}
    }
    $writer=$zip.CreateEntry('manifest.json').Open()
    try {$bytes=$utf8.GetBytes((@{version=1;source=$source;files=$rows}|ConvertTo-Json -Depth 10));$writer.Write($bytes)}finally{$writer.Dispose()}
} finally {$zip.Dispose();$zipStream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $destination))
try {
    if($zip.Entries.Count -ne $rows.Count+1){throw 'Archive count differs'}
    foreach($row in $rows){
        $stream=$zip.GetEntry($row.path).Open()
        try {$memory=[IO.MemoryStream]::new();try{$stream.CopyTo($memory);if((Hash-Bytes $memory.ToArray()) -ne $row.sha256){throw ('Archive entry differs: '+$row.path)}}finally{$memory.Dispose()}}
        finally{$stream.Dispose()}
    }
}finally{$zip.Dispose()}
$archive=@{path=$destination;payloadEntries=$rows.Count;bytes=(Get-Item $destination).Length;sha256=(Get-FileHash $destination).Hash.ToLowerInvariant();entryHashDrift=0;buildArtifactsIncluded=$false}
$record=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source
    publication=(Read-Json 'presentation-frame-driver.verified.json')
    initialApiPublication=(Read-Json 'presentation-frame-api.verified.json')
    workingTree=@{heldTracked=12;actualUntracked=6;heldPatchSha256='57ed4bca2a9e68d4ae2c9c17d5ed4f6e6f051299129cf490e6e333bbb95c44b8';indexEmpty=$true}
    status='Published owner checkpoint; full 62-consumer runtime and actual CLI/native-web capture acceptance pending'
    ownerCases=(Read-Json 'presentation-frame-driver-owners2-20261102.runtime.terminal-audit.json')
    sourceCases=(Read-Json 'presentation-frame-driver-source6-20261102.runtime.terminal-audit.json')
    quality=@{
        check=(Read-Json 'presentation-frame-driver-quality2-check-20261102.json')
        clippy=(Read-Json 'presentation-frame-driver-quality2-clippy-20261102.json')
        structure=(Read-Json 'presentation-frame-driver-quality2-structure-20261102.json')
        format=(Read-Json 'presentation-frame-driver-format.json')
        inputDelta=(Read-Json 'presentation-frame-driver-quality2-input-delta.json')
        reuse='Owner 42 and Source 6 precede the single missing CLI import repair. That path is outside their package/consumer slice; final workspace gates validate the repaired import. No runtime rerun is claimed for the import repair.'
        warnings='Warnings remain; outputs retained. The private Source type returned by the first API getter was a newly introduced warning, corrected in this Source.'
        structureCounts=@{files=3311;rust=3180;physicalLOC=1792283;reviewTriggers=384;blocking=0}
    }
    reverseGraph=(Read-Json 'presentation-frame-driver.reverse-graph.json')
    ownerMetrics=(Read-Json 'presentation-frame-driver.owner-metrics.json')
    ownerDispositions=@{
        core='Existing Engine/Product/facade orchestration keeps custody in original banks. The small borrowed frame and original-Source body admission add no I/O, alternate registry or grant constructor.'
        driver='One disposable typed projection replaces effect replay and mutable lifecycle epochs. View root admission/evaluation and atomic session restore remain in their owning contexts. The exhaustive View evaluator is cohesive.'
        compiler='Construction identity comes from the same checked callable as the parameter ABI. CompiledSource retains the original CompiledProject to borrow its complete product, without rebuilding a text catalog.'
        bundle='The existing complete-product cross-join owns construction identity/count checks. Declaration metadata alone does not force standalone host descriptions to load an executable.'
        sourceIntegration='The new 359-line test owner covers four public Source/product/driver projection boundaries, with exact values, per-step owned restore and forged-projection rejection.'
    }
    preservedDialogueTests=(Read-Json 'presentation-frame-driver-dialogue-test-preservation.json')
    historicalAttempts=@(
        @{stem='presentation-frame-source-owner1-20261102';result='catalog compile failure; no runtime';reason='Fixture used nonexistent LogicalDuration::from_millis; exact nanoseconds replace it.'},
        @{stem='presentation-frame-driver-source1-20261102';result='freeze setup failure; no Cargo/runtime';reason='Deleted viewport input remained in the old template. A deletion-aware wrapper guards absence and freezes remaining inputs.'},
        @{stem='presentation-frame-driver-source2-20261102';result='3 PASS / 1 FAIL';reason='The fixture mixed String addition into its input/default/capture probe. RuntimePlan rejected String arithmetic. The corrected probe observes two exact Text values and the capture directly; this is not String addition acceptance.'},
        @{stem='presentation-frame-driver-source3-20261102';result='3 PASS / 1 FAIL';reason='The Source facade did not expose its complete text catalog. It now retains the original compiler transaction and borrows that product.'},
        @{stem='presentation-frame-driver-source4-20261102';result='3 PASS / 1 FAIL';reason='View ingress mistakenly admitted the affine resource carrier as Copy. It now checks the original immutable body under a shared allowance.'},
        @{stem='presentation-frame-driver-source5-20261102';result='4 PASS';reason='Intermediate success before final decoder/metadata cleanup; not added to final six-case counts.'},
        @{stem='presentation-frame-driver-owners1-20261102';result='catalog completed; input guard rejected; no runtime';reason='Crate map changed during the pinned epoch. Owner2 freezes final inputs and runs all 42 cases.'},
        @{stem='presentation-frame-driver-quality';result='workspace check 101; Clippy/structure not run';reason='Missing AgentObservedObjectContent import in capture. Quality2 repairs it and passes all three gates.'}
    )
    deletionReason='Final projection reads original custody. String readers, shadow lifecycle epochs and tests accepting fabricated saved resources are obsolete. The five-test dynamic CharacterDialogue module is preserved byte-for-byte. Real Source lifecycle and forged-projection rejection replace the old success path.'
    scope=@(
        'Native/AWBC borrowed frame lifecycle and original-Source body Copy; per-step public AWBC restore',
        'Source Product/AWFB/driver image metadata and distinct occurrences; hide/show/individual release; forged image projection rejection',
        'Source View supplied inputs, omitted constant default and stored callback capture; host names cannot override constructor inputs',
        'Source background replacement/old-handle release and viewport selection/release; every driver step public snapshot/owned restore'
    )
    notClaimed=@('Arbitrary reactive defaults','Execution of unproven View callbacks','All length-unit layout resolution','Full staging failure atomicity','All 62 consumer runtime tests','Actual CLI/native-web capture parity')
    acceptedGeneric=@{rowSha256=$genericHash;unchanged=$true;accepted='850534b9e9bc8c8872f6528dd00050a5e6e7699e';publication='f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2'}
    historyPrefix=@{bytes=$historyBefore.Length;sha256=$historyHash}
    raw=$archive
}
$record|ConvertTo-Json -Depth 30|Set-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-presentation-frame-driver-checkpoint.json' -Encoding utf8
function Replace-Row([string]$label,[string]$replacement){
    $start=$script:status.IndexOf('| '+$label+' |');if($start -lt 0){throw ('Missing row: '+$label)}
    $end=$script:status.IndexOf($nl,$start);$old=$script:status.Substring($start,$end-$start)
    $suffix=if($old.EndsWith($cr)){$cr}else{''}
    $script:status=$script:status.Remove($start,$end-$start).Insert($start,$replacement+$suffix)
}
$start=$status.IndexOf('確認日:');$end=$status.IndexOf($nl,$start)
$status=$status.Remove($start,$end-$start).Insert($start,"確認日: 2026-11-02。最新の公開Sourceは $source（Coreの借用frameからdriverへの投影、実行occurrenceと著者IDの区別、View入力・保存復元の照合）。当該cutは既存12 tracked／6 actual untracked WIPを保持した入力で検証した。最新の全件runtime runは下表の5dfcd9caa087a6d8978829c750ac0fcbd8365877を基準とし、新Sourceのowner検証と区別する。")
Replace-Row 'Source Presentation staging全体' '| Source Presentation staging全体 | **Core→driverの接続cutはowner検証・公開済み。全体の最終受入は未確認** | Source 9bd9fe195ec3da493bce853ad644ca0e03e85052。元bank・body・可視性から画像／viewport／View rootを投影し、文字列effect readerと独立したHandle lifecycle・epochを削除した。Sourceの画像metadata・同一著者IDの別occurrence・hide／show／個別release、background置換と旧Handle release、viewport選択／release、View明示引数・省略default・callback captureを4条件で確認。各1-op step後の公開save／owned restoreと、捏造した保存投影の拒否もPASS。元Sourceによるbody admission、宣言identityのbundle照合、完全なView/text productの保持を同じownerへ接続した。owner42件とNative／AWBC frame APIを含むSource6件はPASS。全62逆依存runtime、実CLI画像観測・Native/Web parity、全体の構築前資源検査・式全体の失敗原子性・明示scope/lifetimeはこのcutの受入へ拡張しない。旧Sourceの画像0は履歴へ移し、現Sourceの実観測と混同しない。[公開・原本・訂正理由](acceptance-evidence/task-presentation-frame-driver-checkpoint.json)。 |'
Replace-Row '共有契約／推移的逆依存matrix' '| 共有契約／推移的逆依存matrix | **最新全件runは旧Sourceの55逆依存・7987 PASS。新Sourceの62 runtimeは未実行** | 基準Source 5dfcd9caa087a6d8978829c750ac0fcbd8365877・4074入力の7987 PASS／0 FAIL・24 skippedとGeneric Match151／View値40 exact IDのPASSを元の履歴として保持する。新Source 9bd9fe195ec3da493bce853ad644ca0e03e85052は846 resolved／98 workspaceの実metadataから変更11 ownerの推移的62 packageを確認した。owner42件とSource6件を、この62 package全件の再実行とはしない。[旧全件原本](acceptance-evidence/task-source-scalar-acceptance.json)、[新graph・owner原本](acceptance-evidence/task-presentation-frame-driver-checkpoint.json)。 |'
Replace-Row 'CLI全target照合' '| CLI全target照合 | **最新全target runは旧Sourceの652 PASS／40 FAIL。新Sourceは未実行** | Source 5dfcd9caa087a6d8978829c750ac0fcbd8365877・4074入力の692 unique／652 PASS／40 FAIL・23 skipped、宣言12 target／実case11 binary、Source／case／EXE差分0を履歴として保持する。当時の40失敗原因と、前Sourceから新規失敗0／PASSへ進んだ2件も原本に残す。9bd9fe195ec3da493bce853ad644ca0e03e85052のdriver接続後に全件または実画像captureを再実行したとはしない。旧release欠落probeだけでpositive画像やlifecycleの受入を判断しない。[旧全件・失敗原本](acceptance-evidence/task-source-scalar-acceptance.json)、[新Sourceの範囲](acceptance-evidence/task-presentation-frame-driver-checkpoint.json)。 |'
Replace-Row 'workspace check／Clippy・fmt・構造gate' '| workspace check／Clippy・fmt・構造gate | **新Sourceの全98 package gate・対象fmtは終了0。警告は残存** | Source 9bd9fe195ec3da493bce853ad644ca0e03e85052・4078入力で全target／全feature／locked check・Clippyと構造gateを確認。構造3311 file／3180 Rust／1,792,283 physical LOC、review trigger384／blocking0。Source6／owner42からの差分はCLI captureの不足import 1 pathで、final gateは修復後を検証した。元Core custody、Viewのadmission・評価、sessionのatomic restore、既存compiler／bundleのchecked cross-joinへ責務を保持し、53 pathの公開blobを照合した。初回check失敗、APIのprivate型warning、入力固定の中断も原本に保持する。[原本・入力差分・所有レビュー](acceptance-evidence/task-presentation-frame-driver-checkpoint.json)。 |'
$afterGeneric=($status -split $nl|Where-Object {$_.StartsWith('| Generic Match ')}) -join $nl
if((Hash-Bytes ($utf8.GetBytes($afterGeneric))) -ne $genericHash){throw 'Accepted Generic row changed'}
[IO.File]::WriteAllText($statusPath,$status,$utf8)
$append=@"


## 2026-11-02 Core frameとdriver投影の公開cut

公開 d4658f9af936188ad2a0ccbdcd8a8b688bae1071（parent a382531e581068fff030c5b381009471563db474）、
後続 9bd9fe195ec3da493bce853ad644ca0e03e85052（parent d4658f9af936188ad2a0ccbdcd8a8b688bae1071）。
後続tree 576f45bef6d5a445bb72732a6267d6c419ab1bff、53 path、patch SHA256
db4cb16273c1f9dc0bbb6a325fb93c547e04ffab8980096f073825308e91d81e。main/originと公開blobを照合した。

元Core bank・body・slot・可視性からdriverへ投影し、著者IDと実行occurrenceを区別した。
Viewのchecked宣言identity・供給引数・省略default、元SourceとinstantiationによるCopy前admission、
保存投影と実executorの照合を保持する。文字列effect reader・別Handle lifecycle epochは置換済みのため削除した。
保存記述だけでHandleを捏造する旧成功テストはCore custodyに矛盾するので拒否・元状態保持の検査へ変更した。
削除に巻き込まれた動的CharacterDialogue 5テストは公開前に元moduleをbyte単位で復元・照合し、owner runでPASSした。
旧実測結果は以前のSourceに対する履歴として有効なまま保持する。

最終ownerは42／42 PASS（5 package、2470 skipped）。Source runは6／6 PASS（296 skipped）で、
Native／canonical-AWBC frame API 2条件とProduct/AWFB/driver 4条件を含む。
画像metadata・別occurrence・hide/show/release、background置換と旧Handle release、viewport選択/release、
View明示入力・省略constant default・保存callback captureを確認する。各1-op step・256 tick上限、
公開save／owned restore、捏造された画像投影の拒否を維持する。View callbackの描画式実行や任意reactive defaultの全受入へは拡張しない。

初期APIの6 Core／2 Source／2 compile-failは当時の原本として保持する。
public getterがprivate Source型を返す新しいwarningを見落としていたため、後続Sourceで公開program ownerへ訂正した。
Source consumerからgetterとCopyを利用する2条件も最終6件に含む。
driver Source2の3 PASS／1 FAILはfixtureのString加算をruntime-planが拒否したもの。
引数/defaultの別Text値とclosure captureを直接観測する形へ訂正し、String加算の実装・受入は主張しない。
Source3のtext catalog欠落、Source4のaffine carrierの誤ったCopy admissionも各3 PASS／1 FAILとして保持し、Source5で4 PASSした。
owner1は検証中のcrate map変更をinput guardが検知したためruntime未実行。owner2は最終入力を固定して42 PASSした。
初回workspace checkはCLI不足importで101。修復後の全98 package／all-target／all-feature check・Clippy、
構造gate、対象fmtは終了0。final gateとowner/Source runの差分は当該CLI import 1 pathだけで、再実行と再利用を原本で区別する。

構造は3311 file／3180 Rust／1,792,283 physical LOC、review trigger384／blocking0。
Core Engine5908 LOC・Product6185 LOCは元orchestrationとcustodyを保ち、Frame157 LOCを借用境界へ分離した。
Driver投影689 LOC／root入力145 LOCは一時的な投影・admissionを所有する。既存View evaluator2802 LOCはexhaustive評価・mount commit、
compiler View2959 LOCは同じchecked callable／parameter ABIのloweringを所有するため、そのownerへ追加した。
session1912 LOC／persistence1087 LOCは実sessionとatomic restore、bundle codec2476 LOCは既存complete-product cross-joinを保つ。
Source integration359 LOCは同じ公開projection境界の4条件を所有する。実測・Cargo fan-in/outは原本に保持する。

新Sourceの実graphは846 resolved／98 workspace、変更11 ownerの推移的62 package。この62 runtime全件、実CLI画像観測、
Native/Web capture parityはこのcutでは未実行。旧Source5dfcd9caa087a6d8978829c750ac0fcbd8365877の7987 PASS／CLI652 PASS・40 FAILと
2／8／32 stepの画像0は元入力の履歴へ移し、新Sourceの現状と同一視しない。
Generic Matchの受入850534b9e9bc8c8872f6528dd00050a5e6e7699e／公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2、
View値40条件等の既受入は維持し、現状一覧のGeneric行はbyte単位で変更していない。
原本は[frame/driver checkpoint](acceptance-evidence/task-presentation-frame-driver-checkpoint.json)。
"@
$stream=[IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write)
try{$stream.Write($utf8.GetBytes($append))}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($historyPath)
if((Hash-Bytes $after[0..($historyBefore.Length-1)]) -ne $historyHash){throw 'History prefix changed'}
@{version=1;source=$source;genericRowUnchanged=$true;historyPrefixBytes=$historyBefore.Length;historyPrefixSha256=$historyHash;raw=$archive}|ConvertTo-Json -Depth 7|Set-Content "$taskTemp/presentation-frame-driver-doc-record.json"
$archive|ConvertTo-Json -Compress
