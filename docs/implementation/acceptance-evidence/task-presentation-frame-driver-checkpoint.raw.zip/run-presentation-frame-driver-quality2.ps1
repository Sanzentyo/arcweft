$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze = Get-Content -LiteralPath "$taskTemp/presentation-frame-driver-quality2.source-freeze.json" -Raw | ConvertFrom-Json
function Assert-Inputs {
    foreach ($row in $freeze.paths) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
function Invoke-Recorded([string]$name, [string[]]$arguments) {
    Assert-Inputs
    $started = [DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> "$taskTemp/$name.log"
    $code = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ version=1; base=(git rev-parse HEAD).Trim(); command=$arguments; exitCode=$code; sourceInputs=$freeze.paths.Count; sourceDrift=0; startedAt=$started; finishedAt=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/$name.json" -Encoding utf8
    if ($code) { throw "$name failed with $code" }
}
Invoke-Recorded 'presentation-frame-driver-quality2-check-20261102' @('check','--workspace','--all-targets','--all-features','--locked')
Invoke-Recorded 'presentation-frame-driver-quality2-clippy-20261102' @('clippy','--workspace','--all-targets','--all-features','--locked')
Invoke-Recorded 'presentation-frame-driver-quality2-structure-20261102' @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking','--write',"$taskTemp/presentation-frame-driver-quality2-20261102.structure-report")
