mod match_source;
mod presentation;
mod presentation_slot;
mod retained_inputs;
pub(crate) use retained_inputs::admit_retained_pattern_inputs;
mod matching;
use matching::{pattern_matches_view, pattern_matches_view_with_work};

pub use presentation_slot::RuntimePresentationSlotRefDecodeError;

pub use match_source::{
    CanonicalMatchSource, MatchSourceArm, MatchSourceArmCoordinate, MatchSourceArmCoordinateOwner,
    MatchSourceArmResult, MatchSourceBinding, MatchSourceCoverage, MatchSourceCoverageOwner,
    MatchSourceData, MatchSourceDataArm, MatchSourceDataBinding, MatchSourceDataCoordinate,
    MatchSourceDataCoverage, MatchSourceDataIdentity, MatchSourceDataUnreachable,
    MatchSourceDefinition, MatchSourceEncodingError, MatchSourceGuard, MatchSourceGuardClass,
    MatchSourceMaterializationBudget, MatchSourceMaterializationError, MatchSourceSink,
    MatchSourceUnreachable, MatchSourceUnreachableOwner, MatchSourceUnreachableReason,
    MatchSourceWriter,
};

use crate::entry::{RuntimeIdentityError, RuntimeMapKind, RuntimeNominalTypeId, TypeLayoutHash};
use crate::plan::{
    RuntimeNominalRecordDomain, RuntimePlan, RuntimePlanRecordField, RuntimePlanTypeProjection,
    RuntimePlanValueTypeError,
};
use crate::runtime_id::{RuntimeLocalDeclarationId, RuntimePlanTypeId};
use crate::value::runtime_value_views_equal;
use crate::value::{
    LiveRuntimeValueView, RuntimeEntityReference, RuntimeEvalError, RuntimeExpr,
    RuntimeLocalBinding, RuntimeLocalReadMode, RuntimeOpaquePersistence, RuntimeOpaqueValue,
    RuntimeOpaqueValueClass, RuntimeOpaqueValueError, RuntimePayload, RuntimeRecordFieldId,
    RuntimeScalarView, RuntimeSignedIntWidth, RuntimeUnsignedIntWidth, RuntimeValue,
    RuntimeValueView,
};
pub use arcweft_id::RuntimeSemanticTypeId;
use serde::{Deserialize, Deserializer, Serialize};
use std::collections::BTreeSet;
use thiserror::Error;

mod binding;
mod declarations;

pub use binding::{
    MAX_RUNTIME_PATTERN_BINDING_DEPTH, RuntimePatternBindingCoordinate,
    RuntimePatternBindingCoordinateError, RuntimePatternBindingPath,
    RuntimePatternBindingPathError, RuntimePatternBindingStep, RuntimePatternBindingWireError,
};
pub use declarations::{RuntimePatternBindingDeclaration, RuntimePatternBindingDeclarations};

/// Canonical semantic-type identity encoder shared by semantic producers.
///
/// The domain is fixed at version 1. Producers own their typed fragments while
/// this lower-layer encoder owns the common byte grammar and digest algorithm.
pub struct RuntimeSemanticTypeIdentityEncoder(blake3::Hasher);

impl RuntimeSemanticTypeIdentityEncoder {
    #[must_use]
    pub fn new() -> Self {
        let mut hasher = blake3::Hasher::new();
        hasher.update(b"arcweft.semantic-type.identity.v1\0");
        Self(hasher)
    }

    pub fn write_tag(&mut self, value: u16) {
        self.write_u16(value);
    }

    pub fn write_u8(&mut self, value: u8) {
        self.0.update(&[value]);
    }

    pub fn write_u16(&mut self, value: u16) {
        self.0.update(&value.to_le_bytes());
    }

    pub fn write_u32(&mut self, value: u32) {
        self.0.update(&value.to_le_bytes());
    }

    pub fn write_u64(&mut self, value: u64) {
        self.0.update(&value.to_le_bytes());
    }

    /// Writes a sequence length in the canonical `u32` representation.
    ///
    /// # Panics
    ///
    /// Panics when `value` exceeds the semantic identity grammar's `u32`
    /// sequence-length bound.
    pub fn write_len(&mut self, value: usize) {
        self.write_u32(
            u32::try_from(value).expect("accepted semantic sequences fit the u32 contract"),
        );
    }

    pub fn write_str(&mut self, value: &str) {
        self.write_len(value.len());
        self.write_bytes(value.as_bytes());
    }

    pub fn write_bytes(&mut self, value: &[u8]) {
        self.0.update(value);
    }

    #[must_use]
    pub fn finish(self) -> RuntimeSemanticTypeId {
        RuntimeSemanticTypeId::from_bytes(*self.0.finalize().as_bytes())
    }
}

impl Default for RuntimeSemanticTypeIdentityEncoder {
    fn default() -> Self {
        Self::new()
    }
}

/// Stable identity of a producer that validates opaque runtime payloads.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
#[repr(transparent)]
pub struct RuntimeOpaqueTypeProducerId(RuntimeNominalTypeId);

impl RuntimeOpaqueTypeProducerId {
    pub fn try_new(value: impl Into<String>) -> Result<Self, RuntimeIdentityError> {
        RuntimeNominalTypeId::try_new(value).map(Self)
    }

    #[must_use]
    pub const fn from_nominal(value: RuntimeNominalTypeId) -> Self {
        Self(value)
    }

    #[must_use]
    pub const fn nominal(&self) -> &RuntimeNominalTypeId {
        &self.0
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        self.0.as_str()
    }
}

impl<'de> Deserialize<'de> for RuntimeOpaqueTypeProducerId {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let value = String::deserialize(deserializer)?;
        Self::try_new(value).map_err(serde::de::Error::custom)
    }
}

/// One language-standard opaque runtime carrier shared by semantic checking
/// and host-manifest projection.
///
/// The source-visible path and runtime producer are one closed relation. A
/// consumer must not reconstruct the producer from a display name.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RuntimeStandardOpaqueTypeSpec {
    path: &'static [&'static str],
    arity: u16,
    producer: &'static str,
    persistence: RuntimeOpaquePersistence,
}

impl RuntimeStandardOpaqueTypeSpec {
    const fn new(path: &'static [&'static str], arity: u16, producer: &'static str) -> Self {
        Self {
            path,
            arity,
            producer,
            persistence: RuntimeOpaquePersistence::ConstantAndSnapshot,
        }
    }

    pub(crate) const fn snapshot_only(
        path: &'static [&'static str],
        producer: &'static str,
    ) -> Self {
        Self {
            path,
            arity: 0,
            producer,
            persistence: RuntimeOpaquePersistence::SnapshotOnly,
        }
    }

    #[must_use]
    pub const fn path(&self) -> &'static [&'static str] {
        self.path
    }

    #[must_use]
    pub const fn arity(&self) -> u16 {
        self.arity
    }

    #[must_use]
    pub const fn producer(&self) -> &'static str {
        self.producer
    }

    #[must_use]
    pub const fn value_class(&self) -> RuntimeOpaqueValueClass {
        RuntimeOpaqueValueClass::Plain
    }

    #[must_use]
    pub const fn persistence(&self) -> RuntimeOpaquePersistence {
        self.persistence
    }

    /// Returns the exact owner of a standard opaque type with no arguments.
    /// Generic standard types require their selected argument identities.
    #[must_use]
    pub fn monomorphic_owner(self) -> Option<RuntimeOpaqueTypeOwner> {
        if self.arity != 0 {
            return None;
        }
        let mut encoder = RuntimeSemanticTypeIdentityEncoder::new();
        encoder.write_tag(65);
        encoder.write_u8(0);
        encoder.write_u8(0);
        encoder.write_len(self.path.len());
        for segment in self.path {
            encoder.write_str(segment);
        }
        encoder.write_len(0);
        Some(RuntimeOpaqueTypeOwner::exact_with(
            RuntimeOpaqueTypeProducerId::try_new(self.producer)
                .expect("standard opaque producer identities are valid"),
            encoder.finish(),
            self.value_class(),
            self.persistence(),
        ))
    }
}

pub const RUNTIME_STANDARD_REDUCTION: RuntimeStandardOpaqueTypeSpec =
    RuntimeStandardOpaqueTypeSpec::new(&["Reduction"], 1, "std.reduction");
pub const RUNTIME_STANDARD_AGENT_ERROR: RuntimeStandardOpaqueTypeSpec =
    RuntimeStandardOpaqueTypeSpec::new(&["AgentError"], 0, "std.agent_error");
pub const RUNTIME_STANDARD_VIRTUAL_PATH: RuntimeStandardOpaqueTypeSpec =
    RuntimeStandardOpaqueTypeSpec::new(&["VirtualPath"], 0, "std.virtual_path");

/// Closed standard opaque inventory. Both semantic catalogs and external
/// adapter references consume this inventory, so producer identity cannot
/// diverge between those boundaries.
pub const RUNTIME_STANDARD_OPAQUE_TYPES: [RuntimeStandardOpaqueTypeSpec; 13] = [
    RUNTIME_STANDARD_REDUCTION,
    RuntimeStandardOpaqueTypeSpec::new(&["Watch"], 1, "std.watch"),
    RuntimeStandardOpaqueTypeSpec::new(&["Sample"], 1, "std.sample"),
    RUNTIME_STANDARD_VIRTUAL_PATH,
    RuntimeStandardOpaqueTypeSpec::new(&["ArcError"], 0, "std.arc_error"),
    RuntimeStandardOpaqueTypeSpec::new(&["ReducerError"], 0, "std.reducer_error"),
    RUNTIME_STANDARD_AGENT_ERROR,
    RuntimeStandardOpaqueTypeSpec::snapshot_only(&["AssetError"], "std.asset_error"),
    RuntimeStandardOpaqueTypeSpec::new(&["ContentLoadError"], 0, "std.content_load_error"),
    RuntimeStandardOpaqueTypeSpec::new(&["DialogueText"], 0, "std.dialogue_text"),
    RuntimeStandardOpaqueTypeSpec::snapshot_only(&["ImageHandle"], "std.image_handle"),
    RuntimeStandardOpaqueTypeSpec::snapshot_only(&["AudioHandle"], "std.audio_handle"),
    RuntimeStandardOpaqueTypeSpec::snapshot_only(&["VoiceError"], "std.voice_error"),
];

/// Resolves one exact standard opaque source path.
#[must_use]
pub fn runtime_standard_opaque_type(
    path: &[&str],
) -> Option<&'static RuntimeStandardOpaqueTypeSpec> {
    RUNTIME_STANDARD_OPAQUE_TYPES
        .iter()
        .find(|spec| spec.path() == path)
}

/// Whether an opaque checked owner names one exact type or a producer-defined top.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
#[repr(u8)]
pub enum RuntimeOpaqueTypeAdmission {
    ExactIdentity = 0,
    ProducerWide = 1,
}

impl RuntimeOpaqueTypeAdmission {
    #[must_use]
    pub const fn encoded(self) -> u8 {
        self as u8
    }

    #[must_use]
    pub const fn from_encoded(value: u8) -> Option<Self> {
        Some(match value {
            0 => Self::ExactIdentity,
            1 => Self::ProducerWide,
            _ => return None,
        })
    }
}

/// Closed checked owner for one producer-validated opaque type.
#[derive(Clone, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub struct RuntimeOpaqueTypeOwner {
    producer: RuntimeOpaqueTypeProducerId,
    semantic_identity: RuntimeSemanticTypeId,
    admission: RuntimeOpaqueTypeAdmission,
    value_class: RuntimeOpaqueValueClass,
    persistence: RuntimeOpaquePersistence,
}

impl RuntimeOpaqueTypeOwner {
    #[must_use]
    pub const fn with_admission(
        producer: RuntimeOpaqueTypeProducerId,
        semantic_identity: RuntimeSemanticTypeId,
        admission: RuntimeOpaqueTypeAdmission,
        value_class: RuntimeOpaqueValueClass,
        persistence: RuntimeOpaquePersistence,
    ) -> Self {
        Self {
            producer,
            semantic_identity,
            admission,
            value_class,
            persistence,
        }
    }

    #[must_use]
    pub const fn exact(
        producer: RuntimeOpaqueTypeProducerId,
        semantic_identity: RuntimeSemanticTypeId,
    ) -> Self {
        Self::exact_with(
            producer,
            semantic_identity,
            RuntimeOpaqueValueClass::Plain,
            RuntimeOpaquePersistence::ConstantAndSnapshot,
        )
    }

    #[must_use]
    pub const fn exact_with(
        producer: RuntimeOpaqueTypeProducerId,
        semantic_identity: RuntimeSemanticTypeId,
        value_class: RuntimeOpaqueValueClass,
        persistence: RuntimeOpaquePersistence,
    ) -> Self {
        Self::with_admission(
            producer,
            semantic_identity,
            RuntimeOpaqueTypeAdmission::ExactIdentity,
            value_class,
            persistence,
        )
    }

    #[must_use]
    pub const fn producer_wide(
        producer: RuntimeOpaqueTypeProducerId,
        semantic_identity: RuntimeSemanticTypeId,
    ) -> Self {
        Self::producer_wide_with(
            producer,
            semantic_identity,
            RuntimeOpaqueValueClass::Plain,
            RuntimeOpaquePersistence::ConstantAndSnapshot,
        )
    }

    #[must_use]
    pub const fn producer_wide_with(
        producer: RuntimeOpaqueTypeProducerId,
        semantic_identity: RuntimeSemanticTypeId,
        value_class: RuntimeOpaqueValueClass,
        persistence: RuntimeOpaquePersistence,
    ) -> Self {
        Self::with_admission(
            producer,
            semantic_identity,
            RuntimeOpaqueTypeAdmission::ProducerWide,
            value_class,
            persistence,
        )
    }

    #[must_use]
    pub const fn producer(&self) -> &RuntimeOpaqueTypeProducerId {
        &self.producer
    }

    #[must_use]
    pub const fn semantic_identity(&self) -> RuntimeSemanticTypeId {
        self.semantic_identity
    }

    #[must_use]
    pub const fn admission(&self) -> RuntimeOpaqueTypeAdmission {
        self.admission
    }

    #[must_use]
    pub const fn value_class(&self) -> RuntimeOpaqueValueClass {
        self.value_class
    }

    #[must_use]
    pub const fn persistence(&self) -> RuntimeOpaquePersistence {
        self.persistence
    }

    #[must_use]
    pub fn accepts_owner(&self, actual: &Self) -> bool {
        self == actual
            || (self.admission == RuntimeOpaqueTypeAdmission::ProducerWide
                && actual.admission == RuntimeOpaqueTypeAdmission::ExactIdentity
                && self.producer == actual.producer
                && self.value_class == actual.value_class
                && self.persistence == actual.persistence)
    }

    #[must_use]
    pub fn accepts_opaque_value(&self, actual: &RuntimeOpaqueValue) -> bool {
        self.accepts_opaque_view(crate::value::RuntimeOpaqueView::Live(actual))
    }

    pub(crate) fn accepts_opaque_view(&self, actual: crate::value::RuntimeOpaqueView<'_>) -> bool {
        &self.producer == actual.producer()
            && self.value_class == actual.value_class()
            && self.persistence == actual.persistence()
            && (self.admission == RuntimeOpaqueTypeAdmission::ProducerWide
                || self.semantic_identity == actual.semantic_identity())
            && crate::value::standard_asset_opaque_payload_is_valid(self, actual.payload())
            && crate::value::quantity_payload_is_valid(self, actual.payload())
            && self
                .validate_presentation_handle_payload(actual.payload())
                .is_ok()
            && self
                .validate_presentation_slot_ref_payload(actual.payload())
                .is_ok()
    }

    pub fn try_wrap(&self, payload: RuntimeValue) -> Result<RuntimeValue, RuntimeOpaqueValueError> {
        if self.admission == RuntimeOpaqueTypeAdmission::ProducerWide {
            return Err(RuntimeOpaqueValueError::NonConcreteOwner {
                producer: self.producer.clone(),
                semantic_identity: self.semantic_identity,
            });
        }
        if !crate::value::standard_asset_opaque_payload_is_valid(self, payload.view())
            || !crate::value::quantity_payload_is_valid(self, payload.view())
        {
            return Err(RuntimeOpaqueValueError::InvalidStandardPayload {
                producer: self.producer.clone(),
            });
        }
        self.validate_presentation_handle_payload(payload.view())?;
        self.validate_presentation_slot_ref_payload(payload.view())?;
        Ok(RuntimeValue::Opaque(RuntimeOpaqueValue::new_exact(
            self, payload,
        )))
    }
}

/// Closed identity of a runtime variant value after semantic checking.
///
/// Generic payload types remain on [`RuntimeCheckedType`]. Values retain only
/// the owner family and source-ordered case ordinal, so Option/Result
/// intrinsics never invent erased generic arguments and nominal values never
/// fall back to source-path strings.
#[derive(Clone, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub enum RuntimeVariantIdentity {
    Nominal {
        nominal: RuntimeNominalTypeId,
        semantic_identity: RuntimeSemanticTypeId,
        layout: TypeLayoutHash,
    },
    Builtin(RuntimeBuiltinVariantIdentity),
}

/// Core-owned identity and canonical case schema for standard runtime
/// variants. Every builtin variant boundary uses this same owner; codecs and
/// host adapters must not reconstruct it from case strings.
#[repr(u8)]
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub enum RuntimeBuiltinVariantIdentity {
    Option = 0,
    Result = 1,
    AgentResourceBody = 2,
    AgentBinaryEncoding = 3,
    CaptureFormat = 4,
    CaptureKind = 5,
    PointerButton = 6,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeBuiltinVariantCaseSchema {
    identity: RuntimeBuiltinVariantCaseIdentity,
    name: &'static str,
    has_payload: bool,
}

impl RuntimeBuiltinVariantCaseSchema {
    const fn new(
        identity: RuntimeBuiltinVariantCaseIdentity,
        name: &'static str,
        has_payload: bool,
    ) -> Self {
        Self {
            identity,
            name,
            has_payload,
        }
    }

    pub const fn identity(self) -> RuntimeBuiltinVariantCaseIdentity {
        self.identity
    }

    pub const fn name(self) -> &'static str {
        self.name
    }

    pub const fn has_payload(self) -> bool {
        self.has_payload
    }

    /// Payload-bearing builtin cases use a one-item Tuple at the value and
    /// checked-type boundaries. Unit cases have no payload or Tuple wrapper.
    #[must_use]
    pub(crate) const fn payload_arity(self) -> Option<usize> {
        if self.has_payload { Some(1) } else { None }
    }
}

/// Semantic identity of one case in a core-owned builtin variant.
///
/// Callers use this coordinate instead of copying case ordinals or names.
/// The source-ordered schema slice owned by [`RuntimeBuiltinVariantIdentity`]
/// remains the sole ordinal authority.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeBuiltinVariantCaseIdentity {
    OptionSome,
    OptionNone,
    ResultOk,
    ResultErr,
    AgentResourceBodyJson,
    AgentResourceBodyText,
    AgentResourceBodyBytesBase64,
    AgentBinaryEncodingBase64,
    CaptureFormatPng,
    CaptureFormatRawRgba,
    CaptureKindColor,
    CaptureKindMask,
    PointerButtonPrimary,
    PointerButtonSecondary,
    PointerButtonMiddle,
}

impl RuntimeBuiltinVariantCaseIdentity {
    #[must_use]
    pub const fn owner(self) -> RuntimeBuiltinVariantIdentity {
        match self {
            Self::OptionSome | Self::OptionNone => RuntimeBuiltinVariantIdentity::Option,
            Self::ResultOk | Self::ResultErr => RuntimeBuiltinVariantIdentity::Result,
            Self::AgentResourceBodyJson
            | Self::AgentResourceBodyText
            | Self::AgentResourceBodyBytesBase64 => {
                RuntimeBuiltinVariantIdentity::AgentResourceBody
            }
            Self::AgentBinaryEncodingBase64 => RuntimeBuiltinVariantIdentity::AgentBinaryEncoding,
            Self::CaptureFormatPng | Self::CaptureFormatRawRgba => {
                RuntimeBuiltinVariantIdentity::CaptureFormat
            }
            Self::CaptureKindColor | Self::CaptureKindMask => {
                RuntimeBuiltinVariantIdentity::CaptureKind
            }
            Self::PointerButtonPrimary
            | Self::PointerButtonSecondary
            | Self::PointerButtonMiddle => RuntimeBuiltinVariantIdentity::PointerButton,
        }
    }
}

const OPTION_CASES: [RuntimeBuiltinVariantCaseSchema; 2] = [
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::OptionSome,
        "Some",
        true,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::OptionNone,
        "None",
        false,
    ),
];
const RESULT_CASES: [RuntimeBuiltinVariantCaseSchema; 2] = [
    RuntimeBuiltinVariantCaseSchema::new(RuntimeBuiltinVariantCaseIdentity::ResultOk, "Ok", true),
    RuntimeBuiltinVariantCaseSchema::new(RuntimeBuiltinVariantCaseIdentity::ResultErr, "Err", true),
];
const AGENT_RESOURCE_BODY_CASES: [RuntimeBuiltinVariantCaseSchema; 3] = [
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyJson,
        "Json",
        true,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyText,
        "Text",
        true,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyBytesBase64,
        "BytesBase64",
        true,
    ),
];
const AGENT_BINARY_ENCODING_CASES: [RuntimeBuiltinVariantCaseSchema; 1] =
    [RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::AgentBinaryEncodingBase64,
        "Base64",
        false,
    )];
const CAPTURE_FORMAT_CASES: [RuntimeBuiltinVariantCaseSchema; 2] = [
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::CaptureFormatPng,
        "png",
        false,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::CaptureFormatRawRgba,
        "raw_rgba",
        false,
    ),
];
const CAPTURE_KIND_CASES: [RuntimeBuiltinVariantCaseSchema; 2] = [
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::CaptureKindColor,
        "color",
        false,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::CaptureKindMask,
        "mask",
        false,
    ),
];
const POINTER_BUTTON_CASES: [RuntimeBuiltinVariantCaseSchema; 3] = [
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::PointerButtonPrimary,
        "primary",
        false,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::PointerButtonSecondary,
        "secondary",
        false,
    ),
    RuntimeBuiltinVariantCaseSchema::new(
        RuntimeBuiltinVariantCaseIdentity::PointerButtonMiddle,
        "middle",
        false,
    ),
];

impl RuntimeBuiltinVariantIdentity {
    /// Core-owned name for the builtin's fixed external-tag data descriptor.
    #[must_use]
    pub const fn codec_name(self) -> &'static str {
        match self {
            Self::Option => "Option",
            Self::Result => "Result",
            Self::AgentResourceBody => "AgentResourceBody",
            Self::AgentBinaryEncoding => "AgentBinaryEncoding",
            Self::CaptureFormat => "CaptureFormat",
            Self::CaptureKind => "CaptureKind",
            Self::PointerButton => "PointerButton",
        }
    }

    const COUNT: usize = Self::PointerButton as usize + 1;
    const DECODE: [Option<Self>; RuntimeBuiltinVariantIdentity::COUNT] = {
        let mut decode = [None; RuntimeBuiltinVariantIdentity::COUNT];
        decode[Self::Option as usize] = Some(Self::Option);
        decode[Self::Result as usize] = Some(Self::Result);
        decode[Self::AgentResourceBody as usize] = Some(Self::AgentResourceBody);
        decode[Self::AgentBinaryEncoding as usize] = Some(Self::AgentBinaryEncoding);
        decode[Self::CaptureFormat as usize] = Some(Self::CaptureFormat);
        decode[Self::CaptureKind as usize] = Some(Self::CaptureKind);
        decode[Self::PointerButton as usize] = Some(Self::PointerButton);
        decode
    };

    #[must_use]
    pub const fn semantic_tag(self) -> u8 {
        self as u8
    }

    #[must_use]
    pub fn from_wire_tag(tag: u8) -> Option<Self> {
        Self::DECODE.get(tag as usize).copied().flatten()
    }

    #[must_use]
    pub const fn cases(self) -> &'static [RuntimeBuiltinVariantCaseSchema] {
        match self {
            Self::Option => &OPTION_CASES,
            Self::Result => &RESULT_CASES,
            Self::AgentResourceBody => &AGENT_RESOURCE_BODY_CASES,
            Self::AgentBinaryEncoding => &AGENT_BINARY_ENCODING_CASES,
            Self::CaptureFormat => &CAPTURE_FORMAT_CASES,
            Self::CaptureKind => &CAPTURE_KIND_CASES,
            Self::PointerButton => &POINTER_BUTTON_CASES,
        }
    }

    /// Number of unary payload item types in canonical case order.
    #[must_use]
    pub fn payload_count(self) -> usize {
        self.cases()
            .iter()
            .filter(|case| case.has_payload())
            .count()
    }

    /// Resolves a semantic case coordinate to its canonical source ordinal
    /// and schema row.
    #[must_use]
    pub fn resolve_case(
        self,
        identity: RuntimeBuiltinVariantCaseIdentity,
    ) -> Option<(u32, RuntimeBuiltinVariantCaseSchema)> {
        if identity.owner() != self {
            return None;
        }
        self.cases()
            .iter()
            .copied()
            .enumerate()
            .find(|(_, schema)| schema.identity() == identity)
            .and_then(|(ordinal, schema)| {
                u32::try_from(ordinal).ok().map(|ordinal| (ordinal, schema))
            })
    }

    /// Resolves one runtime ordinal through the canonical schema table.
    #[must_use]
    pub fn case_at(self, ordinal: u32) -> Option<RuntimeBuiltinVariantCaseSchema> {
        usize::try_from(ordinal)
            .ok()
            .and_then(|ordinal| self.cases().get(ordinal))
            .copied()
    }
}

/// Rejection produced while sealing a checked type for one core-owned
/// builtin variant family.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeBuiltinVariantTypeError {
    #[error(
        "builtin variant {owner:?} requires {expected} cases, but {actual} payload rows were supplied"
    )]
    CaseCount {
        owner: RuntimeBuiltinVariantIdentity,
        expected: usize,
        actual: usize,
    },
    #[error("builtin variant case {case:?} has the wrong payload presence")]
    InvalidPayloadPresence {
        case: RuntimeBuiltinVariantCaseIdentity,
    },
    #[error("builtin variant case {case:?} requires a one-item Tuple payload type")]
    InvalidPayloadTuple {
        case: RuntimeBuiltinVariantCaseIdentity,
    },
}

/// One source-ordered case in a checked nominal enum.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeCheckedVariantCase {
    pub name: String,
    pub payload: Option<Box<RuntimeCheckedType>>,
}

/// One declaration-ordered field in a checked structural record.
///
/// The accepted coordinate, source-order name, and recursive type all
/// participate in equality, checked-type identity, and value admission.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeCheckedRecordField {
    field: RuntimeRecordFieldId,
    diagnostic_name: String,
    ty: RuntimeCheckedType,
}

impl RuntimeCheckedRecordField {
    #[must_use]
    pub const fn field(&self) -> RuntimeRecordFieldId {
        self.field
    }

    #[must_use]
    pub fn diagnostic_name(&self) -> &str {
        &self.diagnostic_name
    }

    #[must_use]
    pub const fn ty(&self) -> &RuntimeCheckedType {
        &self.ty
    }
}

#[derive(Clone, Copy, Debug, Eq, Error, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeCheckedRecordTypeError {
    #[error("checked record field ordinal exceeds the runtime field-ID space")]
    FieldOrdinalOverflow,
    #[error("checked record field {actual} does not match declaration coordinate {expected}")]
    InvalidFieldCoordinate {
        expected: RuntimeRecordFieldId,
        actual: RuntimeRecordFieldId,
    },
    #[error("checked record contains a duplicate diagnostic field name")]
    DuplicateDiagnosticName,
}

/// One recursively typed pattern admitted into a runtime plan.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimePattern {
    ty: RuntimePlanTypeId,
    kind: RuntimePatternKind,
}

impl RuntimePattern {
    pub(crate) const fn from_admitted_parts(
        ty: RuntimePlanTypeId,
        kind: RuntimePatternKind,
    ) -> Self {
        Self { ty, kind }
    }

    #[must_use]
    pub const fn ty(&self) -> RuntimePlanTypeId {
        self.ty
    }

    #[must_use]
    pub const fn kind(&self) -> &RuntimePatternKind {
        &self.kind
    }
}

/// Closed executable pattern algebra. Local destinations are plan-local IDs
/// paired with coordinates derived by the aggregate plan builder.
#[derive(Clone, Debug, PartialEq)]
pub enum RuntimePatternKind {
    Bind {
        mutable: bool,
        binding: RuntimePatternBindingCoordinate,
    },
    Discard,
    Literal(RuntimeValue),
    Entity(RuntimeEntityReference),
    Tuple(Box<[RuntimePattern]>),
    Or(Box<[RuntimePattern]>),
    Record {
        fields: Box<[RuntimeRecordPatternField]>,
        rest: RuntimePatternRest,
    },
    Sequence {
        items: Box<[RuntimePattern]>,
        rest: RuntimePatternRest,
    },
    Variant {
        ordinal: u32,
        payload: Option<Box<RuntimePattern>>,
    },
    Whole {
        binding: RuntimePatternBindingCoordinate,
        pattern: Box<RuntimePattern>,
    },
    Typed {
        binding: RuntimePatternBindingCoordinate,
    },
}

/// Exact, open, or binding remainder semantics shared by structural patterns.
///
/// A record rest binding receives the original complete record. A bracket-
/// sequence rest binding receives only the unmatched tail.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimePatternRest {
    Exact,
    Ignore,
    Bind(RuntimePatternBindingCoordinate),
}

impl RuntimePatternRest {
    /// Returns whether `actual` elements/fields satisfy this remainder mode.
    #[must_use]
    pub const fn accepts_len(&self, required: usize, actual: usize) -> bool {
        match self {
            Self::Exact => required == actual,
            Self::Ignore | Self::Bind(_) => required <= actual,
        }
    }

    /// Returns the admitted local coordinate written by a binding rest.
    #[must_use]
    pub const fn binding(&self) -> Option<&RuntimePatternBindingCoordinate> {
        match self {
            Self::Bind(binding) => Some(binding),
            Self::Exact | Self::Ignore => None,
        }
    }
}

/// Closed structural type predicate for a runtime typed-binding pattern.
///
/// The compiler projects this value once from checked semantic type facts.
/// Native execution and AWBC lowering consume the same typed vocabulary; no
/// source/display label is reparsed at either boundary.
mod descriptor;

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeCheckedType {
    /// Program storage admission additionally checks the retained Source and captures.
    PresentationResource(arcweft_interaction_model::presentation::PresentationResourceKind),
    /// Diagnostic reference to the selected program's complete type row.
    /// It is not a standalone value-admission predicate.
    ExecutableRef(RuntimeSemanticTypeId),
    Never,
    Unit,
    Bool,
    Signed(RuntimeSignedIntWidth),
    Unsigned(RuntimeUnsignedIntWidth),
    F32,
    F64,
    String,
    Color,
    Char,
    Duration,
    Progress,
    DenseNumeric(crate::math::RuntimeDenseNumericType),
    EntityReference(crate::value::RuntimeEntityReferenceType<RuntimeSemanticTypeId>),
    AgentValue,
    Bytes,
    Sequence(Box<RuntimeCheckedType>),
    /// Ordered entry carrier with the exact semantic map family retained.
    /// Each runtime entry is a two-item tuple `(key, value)`.
    Map {
        kind: RuntimeMapKind,
        key: Box<RuntimeCheckedType>,
        value: Box<RuntimeCheckedType>,
    },
    /// A fixed-length sequence whose item predicate applies to every element.
    Array {
        item: Box<RuntimeCheckedType>,
        length: u64,
    },
    Tuple(Vec<RuntimeCheckedType>),
    Record(Box<[RuntimeCheckedRecordField]>),
    Choice(Vec<RuntimeCheckedType>),
    Nominal {
        nominal: RuntimeNominalTypeId,
        semantic_identity: RuntimeSemanticTypeId,
        layout: TypeLayoutHash,
        arguments: Vec<RuntimeCheckedType>,
    },
    Opaque {
        owner: RuntimeOpaqueTypeOwner,
    },
    Variant {
        owner: RuntimeVariantIdentity,
        arguments: Vec<RuntimeCheckedType>,
        cases: Vec<RuntimeCheckedVariantCase>,
    },
    Result {
        ok: Box<RuntimeCheckedType>,
        error: Box<RuntimeCheckedType>,
    },
    Option(Box<RuntimeCheckedType>),
    Agent(crate::plan::RuntimeAgentTypeProjection<Box<Self>>),
}

impl RuntimeCheckedType {
    /// Admits a complete value against this exact checked payload contract.
    pub fn try_payload(&self, value: RuntimeValue) -> Result<RuntimePayload, String> {
        if self.accepts_value(&value) {
            Ok(RuntimePayload::new(value))
        } else {
            Err("runtime payload does not satisfy its checked type".to_owned())
        }
    }

    /// Constructs and admits a domain result. Transport failures do not pass
    /// through this value boundary; the caller owns their control outcome.
    pub fn try_result_payload(
        &self,
        value: Result<RuntimeValue, RuntimeValue>,
    ) -> Result<RuntimePayload, String> {
        if !matches!(self, Self::Result { .. }) {
            return Err("checked payload contract is not a Result type".to_owned());
        }
        self.try_payload(match value {
            Ok(value) => RuntimeValue::result_ok(value),
            Err(value) => RuntimeValue::result_err(value),
        })
    }

    pub fn try_record(
        fields: impl IntoIterator<Item = (RuntimeRecordFieldId, String, RuntimeCheckedType)>,
    ) -> Result<Self, RuntimeCheckedRecordTypeError> {
        let mut diagnostic_names = BTreeSet::new();
        let mut checked = Vec::new();
        for (ordinal, (field, diagnostic_name, ty)) in fields.into_iter().enumerate() {
            let expected = RuntimeRecordFieldId::try_from_zero_based_ordinal(ordinal)
                .map_err(|_| RuntimeCheckedRecordTypeError::FieldOrdinalOverflow)?;
            if field != expected {
                return Err(RuntimeCheckedRecordTypeError::InvalidFieldCoordinate {
                    expected,
                    actual: field,
                });
            }
            if !diagnostic_names.insert(diagnostic_name.clone()) {
                return Err(RuntimeCheckedRecordTypeError::DuplicateDiagnosticName);
            }
            checked.push(RuntimeCheckedRecordField {
                field,
                diagnostic_name,
                ty,
            });
        }
        Ok(Self::Record(checked.into_boxed_slice()))
    }

    /// Seals one core-owned builtin variant type through its canonical case
    /// schema. Callers provide payload types only; names and ordinals remain
    /// owned by [`RuntimeBuiltinVariantIdentity`].
    pub fn try_builtin_variant(
        owner: RuntimeBuiltinVariantIdentity,
        payloads: impl IntoIterator<Item = Option<RuntimeCheckedType>>,
    ) -> Result<Self, RuntimeBuiltinVariantTypeError> {
        let payloads = payloads.into_iter().collect::<Vec<_>>();
        let schemas = owner.cases();
        if payloads.len() != schemas.len() {
            return Err(RuntimeBuiltinVariantTypeError::CaseCount {
                owner,
                expected: schemas.len(),
                actual: payloads.len(),
            });
        }
        let cases = schemas
            .iter()
            .copied()
            .zip(payloads)
            .map(|(schema, payload)| {
                if schema.has_payload() != payload.is_some() {
                    return Err(RuntimeBuiltinVariantTypeError::InvalidPayloadPresence {
                        case: schema.identity(),
                    });
                }
                if let Some(payload) = &payload
                    && !matches!(payload, Self::Tuple(items)
                        if Some(items.len()) == schema.payload_arity())
                {
                    return Err(RuntimeBuiltinVariantTypeError::InvalidPayloadTuple {
                        case: schema.identity(),
                    });
                }
                Ok(RuntimeCheckedVariantCase {
                    name: schema.name().to_owned(),
                    payload: payload.map(Box::new),
                })
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Self::Variant {
            owner: RuntimeVariantIdentity::Builtin(owner),
            arguments: Vec::new(),
            cases,
        })
    }

    /// Appends this checked type's canonical structural transcript to an
    /// enclosing semantic-type identity.
    ///
    /// This is the single transcript authority for checked runtime types.
    /// Higher-layer semantic owners use it when a checked type is either the
    /// complete identity or one structural child; they must not duplicate the
    /// checked-type tag grammar.
    pub fn encode_semantic_identity(&self, encoder: &mut RuntimeSemanticTypeIdentityEncoder) {
        write_checked_type_identity(encoder, self);
    }

    /// Returns the canonical, source-independent digest of this checked type.
    /// The encoder is structural and deliberately ignores debug/display
    /// formatting so producers can share one semantic identity boundary.
    #[must_use]
    pub fn semantic_identity_digest(&self) -> RuntimeSemanticTypeId {
        if let Self::ExecutableRef(identity) = self {
            return *identity;
        }
        let mut encoder = RuntimeSemanticTypeIdentityEncoder::new();
        self.encode_semantic_identity(&mut encoder);
        encoder.finish()
    }

    #[must_use]
    pub fn variant_identity(&self) -> Option<RuntimeVariantIdentity> {
        match self {
            Self::Variant { owner, .. } => Some(owner.clone()),
            Self::Result { .. } => Some(RuntimeVariantIdentity::Builtin(
                RuntimeBuiltinVariantIdentity::Result,
            )),
            Self::Option(_) => Some(RuntimeVariantIdentity::Builtin(
                RuntimeBuiltinVariantIdentity::Option,
            )),
            _ => None,
        }
    }

    #[must_use]
    pub fn variant_case(&self, ordinal: u32) -> Option<RuntimeCheckedVariantCase> {
        match self {
            Self::Variant { cases, .. } => usize::try_from(ordinal)
                .ok()
                .and_then(|ordinal| cases.get(ordinal))
                .cloned(),
            Self::Result { ok, error } => {
                let schema = RuntimeBuiltinVariantIdentity::Result.case_at(ordinal)?;
                let payload = match schema.identity() {
                    RuntimeBuiltinVariantCaseIdentity::ResultOk => {
                        Some(Box::new(Self::Tuple(vec![ok.as_ref().clone()])))
                    }
                    RuntimeBuiltinVariantCaseIdentity::ResultErr => {
                        Some(Box::new(Self::Tuple(vec![error.as_ref().clone()])))
                    }
                    _ => return None,
                };
                Some(RuntimeCheckedVariantCase {
                    name: schema.name().to_owned(),
                    payload,
                })
            }
            Self::Option(item) => {
                let schema = RuntimeBuiltinVariantIdentity::Option.case_at(ordinal)?;
                let payload = match schema.identity() {
                    RuntimeBuiltinVariantCaseIdentity::OptionSome => {
                        Some(Box::new(Self::Tuple(vec![item.as_ref().clone()])))
                    }
                    RuntimeBuiltinVariantCaseIdentity::OptionNone => None,
                    _ => return None,
                };
                Some(RuntimeCheckedVariantCase {
                    name: schema.name().to_owned(),
                    payload,
                })
            }
            _ => None,
        }
    }

    /// Returns whether a runtime value satisfies this exact closed predicate.
    #[must_use]
    pub fn accepts_value(&self, value: &RuntimeValue) -> bool {
        self.accepts_value_at_depth(value, 0)
    }

    fn accepts_value_at_depth(&self, value: &RuntimeValue, depth: usize) -> bool {
        self.accepts_value_view(value.view(), depth, None)
    }

    /// Matches borrowed admitted storage through the same closed predicate,
    /// retaining the enclosing allowance's first hard relation failure.
    pub(crate) fn accepts_admitted_value_view(
        &self,
        value: RuntimeValueView<'_>,
        work: &crate::entry::schema::value_budget::ValidationWork,
    ) -> Result<bool, crate::entry::RuntimeSchemaError> {
        let accepted = self.accepts_value_view(value, 0, Some(work));
        work.failure().map_or(Ok(accepted), Err)
    }

    fn accepts_value_view(
        &self,
        value: RuntimeValueView<'_>,
        depth: usize,
        work: Option<&crate::entry::schema::value_budget::ValidationWork>,
    ) -> bool {
        if work.is_some_and(|work| work.clone().charge(depth).is_err()) {
            return false;
        }
        if depth > crate::value::MAX_RUNTIME_VALUE_NESTING_DEPTH {
            return false;
        }
        match (value, self) {
            (RuntimeValueView::PresentationResource(value), Self::PresentationResource(kind)) => value.layout().resource() == *kind,
            (RuntimeValueView::DenseNumeric(value), Self::DenseNumeric(expected)) => value.ty() == *expected,
            (RuntimeValueView::Scalar(RuntimeScalarView::Unit), Self::Unit)
            | (RuntimeValueView::Scalar(RuntimeScalarView::Bool(_)), Self::Bool)
            | (RuntimeValueView::Scalar(RuntimeScalarView::F32(_)), Self::F32)
            | (RuntimeValueView::Scalar(RuntimeScalarView::F64(_)), Self::F64)
            | (RuntimeValueView::Scalar(RuntimeScalarView::String(_)), Self::String)
            | (RuntimeValueView::Scalar(RuntimeScalarView::Color(_)), Self::Color)
            | (RuntimeValueView::Scalar(RuntimeScalarView::Char(_)), Self::Char)
            | (RuntimeValueView::Scalar(RuntimeScalarView::Duration(_)), Self::Duration)
            | (RuntimeValueView::Scalar(RuntimeScalarView::Progress { .. }), Self::Progress) => true,
            (RuntimeValueView::Scalar(RuntimeScalarView::EntityRef(value)), Self::EntityReference(expected)) => expected.accepts(value),
            (value, Self::AgentValue) => runtime_value_view_is_agent_value(value, depth, work),
            (RuntimeValueView::Scalar(RuntimeScalarView::Int(value)), Self::Signed(width)) => value.width() == *width,
            (RuntimeValueView::Scalar(RuntimeScalarView::UInt(value)), Self::Unsigned(width)) => value.width() == *width,
            (RuntimeValueView::Sequence(sequence), Self::Bytes) => sequence.all(|value| {
                work.is_none_or(|work| work.clone().charge(depth + 1).is_ok())
                    && matches!(value, RuntimeValueView::Scalar(RuntimeScalarView::UInt(value)) if value.width() == RuntimeUnsignedIntWidth::U8)
            }),
            (RuntimeValueView::Sequence(sequence), Self::Sequence(item)) => sequence.all(|value| item.accepts_value_view(value, depth + 1, work)),
            (RuntimeValueView::Sequence(sequence), Self::Map { key, value, .. }) => sequence.all(|actual| {
                let RuntimeValueView::Tuple(pair) = actual else { return false; };
                work.is_none_or(|work| work.clone().charge(depth + 1).is_ok())
                    && pair.len() == 2
                    && pair.get(0).is_some_and(|actual| key.accepts_value_view(actual, depth + 1, work))
                    && pair.get(1).is_some_and(|actual| value.accepts_value_view(actual, depth + 1, work))
            }),
            (RuntimeValueView::Sequence(sequence), Self::Array { item, length }) => {
                sequence.len().ok().and_then(|length| u64::try_from(length).ok()) == Some(*length)
                    && sequence.all(|value| item.accepts_value_view(value, depth + 1, work))
            }
            (RuntimeValueView::Tuple(values), Self::Tuple(items)) => {
                values.len() == items.len()
                    && items.iter().enumerate().all(|(index, item)| values.get(index).is_some_and(|value| item.accepts_value_view(value, depth + 1, work)))
            }
            (RuntimeValueView::Record(values), Self::Record(fields)) => {
                values.len() == fields.len()
                    && fields.iter().enumerate().all(|(index, field)| values.get(index).is_some_and(|(id, name, value)| {
                        id == field.field && name == field.diagnostic_name && field.ty.accepts_value_view(value, depth + 1, work)
                    }))
            }
            (value, Self::Choice(alternatives)) => alternatives
                .iter()
                .any(|alternative| alternative.accepts_value_view(value, depth + 1, work)),
            (RuntimeValueView::Opaque(value), Self::Opaque { owner }) => {
                owner.accepts_opaque_view(value)
            }
            (RuntimeValueView::Reduction(value), Self::Opaque { owner }) => {
                owner.accepts_owner(value.owner())
            }
            (
                RuntimeValueView::NominalRecord(record),
                Self::Nominal {
                    nominal, semantic_identity, layout, ..
                },
            ) => record.type_id() == nominal
                && record.semantic_identity() == *semantic_identity
                && record.layout() == *layout,
            (
                RuntimeValueView::Variant(variant),
                Self::Variant { .. },
            ) => self.accepts_nominal_variant_at_depth(
                variant.owner(),
                variant.ordinal(),
                variant.name(),
                variant.payload(),
                depth,
                work,
            ),
            (
                RuntimeValueView::Variant(variant),
                Self::Result { .. } | Self::Option(_),
            ) => self.accepts_builtin_variant_parts_at_depth(variant.owner(), variant.ordinal(), variant.name(), variant.payload(), depth, work),
            (RuntimeValueView::Agent(value), Self::Agent(expected)) => {
                !matches!(expected, crate::plan::RuntimeAgentTypeProjection::DataShape(_))
                    && value.operational_type() == expected.operational_type()
            }
            (RuntimeValueView::Record(_), Self::Agent(expected)) => {
                expected.operational_type().accepts_protocol_record()
            }
            _ => false,
        }
    }

    fn accepts_builtin_variant_parts_at_depth(
        &self,
        owner: &RuntimeVariantIdentity,
        ordinal: u32,
        name: &str,
        payload: Option<RuntimeValueView<'_>>,
        depth: usize,
        work: Option<&crate::entry::schema::value_budget::ValidationWork>,
    ) -> bool {
        let Some(expected_owner) = self.variant_identity() else {
            return false;
        };
        if owner != &expected_owner {
            return false;
        }
        self.variant_case(ordinal).is_some_and(|case| {
            case.name == name
                && match (case.payload.as_deref(), payload) {
                    (Some(expected), Some(actual)) => {
                        expected.accepts_value_view(actual, depth + 1, work)
                    }
                    (None, None) => true,
                    _ => false,
                }
        })
    }

    fn accepts_nominal_variant_at_depth(
        &self,
        owner: &RuntimeVariantIdentity,
        ordinal: u32,
        name: &str,
        payload: Option<RuntimeValueView<'_>>,
        depth: usize,
        work: Option<&crate::entry::schema::value_budget::ValidationWork>,
    ) -> bool {
        let Self::Variant {
            owner: expected_owner,
            cases,
            ..
        } = self
        else {
            return false;
        };
        if owner != expected_owner {
            return false;
        }
        usize::try_from(ordinal)
            .ok()
            .and_then(|ordinal| cases.get(ordinal))
            .is_some_and(|case| {
                case.name == name
                    && match (case.payload.as_deref(), payload) {
                        (None, None) => true,
                        (Some(expected), Some(actual)) => {
                            expected.accepts_value_view(actual, depth + 1, work)
                        }
                        (None, Some(_)) | (Some(_), None) => false,
                    }
            })
    }
}

#[allow(
    clippy::too_many_lines,
    reason = "the closed checked-type algebra has one canonical transcript owner"
)]
fn write_checked_type_identity(
    encoder: &mut RuntimeSemanticTypeIdentityEncoder,
    ty: &RuntimeCheckedType,
) {
    match ty {
        RuntimeCheckedType::PresentationResource(kind) => {
            encoder.write_tag(28);
            encoder.write_u8(kind.semantic_tag());
        }
        RuntimeCheckedType::ExecutableRef(identity) => {
            encoder.write_tag(27);
            encoder.write_bytes(identity.as_bytes());
        }
        RuntimeCheckedType::Never => encoder.write_tag(0),
        RuntimeCheckedType::Unit => encoder.write_tag(1),
        RuntimeCheckedType::Bool => encoder.write_tag(2),
        RuntimeCheckedType::Signed(width) => {
            encoder.write_tag(3);
            encoder.write_u8(match width {
                RuntimeSignedIntWidth::I8 => 0,
                RuntimeSignedIntWidth::I16 => 1,
                RuntimeSignedIntWidth::I32 => 2,
                RuntimeSignedIntWidth::I64 => 3,
                RuntimeSignedIntWidth::I128 => 4,
                RuntimeSignedIntWidth::ISize => 5,
            });
        }
        RuntimeCheckedType::Unsigned(width) => {
            encoder.write_tag(4);
            encoder.write_u8(match width {
                RuntimeUnsignedIntWidth::U8 => 0,
                RuntimeUnsignedIntWidth::U16 => 1,
                RuntimeUnsignedIntWidth::U32 => 2,
                RuntimeUnsignedIntWidth::U64 => 3,
                RuntimeUnsignedIntWidth::U128 => 4,
                RuntimeUnsignedIntWidth::USize => 5,
            });
        }
        RuntimeCheckedType::F32 => encoder.write_tag(5),
        RuntimeCheckedType::F64 => encoder.write_tag(6),
        RuntimeCheckedType::String => encoder.write_tag(7),
        RuntimeCheckedType::Color => encoder.write_tag(26),
        RuntimeCheckedType::Char => encoder.write_tag(8),
        RuntimeCheckedType::Duration => encoder.write_tag(9),
        RuntimeCheckedType::Progress => encoder.write_tag(10),
        RuntimeCheckedType::DenseNumeric(dense) => {
            encoder.write_tag(27);
            for role in dense.semantic_parts() {
                encoder.write_u8(role);
            }
        }
        RuntimeCheckedType::EntityReference(reference) => {
            encoder.write_tag(11);
            encoder.write_u8(reference.kind_tag());
            if let Some(character) = reference.look_owner() {
                encoder.write_str(character.as_str());
            }
            encoder.write_u8(u8::from(reference.declaration().is_some()));
            if let Some(id) = reference.declaration() {
                encoder.write_str(id.as_str());
            }
            encoder.write_u8(u8::from(reference.payload().is_some()));
            if let Some(payload) = reference.payload() {
                encoder.write_bytes(payload.as_bytes());
            }
        }
        RuntimeCheckedType::Bytes => encoder.write_tag(12),
        RuntimeCheckedType::Sequence(inner) => {
            encoder.write_tag(13);
            write_checked_type_identity(encoder, inner);
        }
        RuntimeCheckedType::Map { kind, key, value } => {
            encoder.write_tag(25);
            encoder.write_u8(kind.semantic_tag());
            write_checked_type_identity(encoder, key);
            write_checked_type_identity(encoder, value);
        }
        RuntimeCheckedType::Array { item, length } => {
            encoder.write_tag(24);
            encoder.write_u64(*length);
            write_checked_type_identity(encoder, item);
        }
        RuntimeCheckedType::Tuple(items) => {
            encoder.write_tag(14);
            encoder.write_len(items.len());
            for item in items {
                write_checked_type_identity(encoder, item);
            }
        }
        RuntimeCheckedType::Record(fields) => {
            encoder.write_tag(23);
            encoder.write_len(fields.len());
            for field in fields {
                encoder.write_u32(field.field.zero_based());
                encoder.write_str(&field.diagnostic_name);
                write_checked_type_identity(encoder, &field.ty);
            }
        }
        RuntimeCheckedType::Choice(items) => {
            encoder.write_tag(15);
            encoder.write_len(items.len());
            for item in items {
                write_checked_type_identity(encoder, item);
            }
        }
        RuntimeCheckedType::Nominal {
            semantic_identity,
            layout,
            arguments,
            ..
        } => {
            encoder.write_tag(16);
            encoder.write_bytes(semantic_identity.as_bytes());
            encoder.write_bytes(layout.as_bytes());
            encoder.write_len(arguments.len());
            for argument in arguments {
                write_checked_type_identity(encoder, argument);
            }
        }
        RuntimeCheckedType::Opaque { owner } => {
            encoder.write_tag(17);
            encoder.write_str(owner.producer().as_str());
            encoder.write_bytes(owner.semantic_identity().as_bytes());
            encoder.write_u8(owner.admission().encoded());
            encoder.write_u8(owner.value_class().semantic_tag());
            encoder.write_u8(owner.persistence().semantic_tag());
        }
        RuntimeCheckedType::Variant {
            owner,
            arguments,
            cases,
        } => {
            encoder.write_tag(18);
            write_variant_identity(encoder, owner);
            encoder.write_len(arguments.len());
            for argument in arguments {
                write_checked_type_identity(encoder, argument);
            }
            encoder.write_len(cases.len());
            for case in cases {
                encoder.write_str(&case.name);
                match &case.payload {
                    Some(payload) => {
                        encoder.write_u8(1);
                        write_checked_type_identity(encoder, payload);
                    }
                    None => encoder.write_u8(0),
                }
            }
        }
        RuntimeCheckedType::Result { ok, error } => {
            encoder.write_tag(19);
            write_checked_type_identity(encoder, ok);
            write_checked_type_identity(encoder, error);
        }
        RuntimeCheckedType::Option(inner) => {
            encoder.write_tag(20);
            write_checked_type_identity(encoder, inner);
        }
        RuntimeCheckedType::Agent(agent) => {
            encoder.write_tag(21);
            encoder.write_u8(agent.operational_type().semantic_tag());
            if let crate::plan::RuntimeAgentTypeProjection::Probe(result)
            | crate::plan::RuntimeAgentTypeProjection::DataShape(result) = agent
            {
                write_checked_type_identity(encoder, result);
            }
        }
        RuntimeCheckedType::AgentValue => encoder.write_tag(22),
    }
}

fn runtime_value_view_is_agent_value(
    value: RuntimeValueView<'_>,
    depth: usize,
    work: Option<&crate::entry::schema::value_budget::ValidationWork>,
) -> bool {
    if work.is_some_and(|work| work.clone().charge(depth).is_err()) {
        return false;
    }
    if depth > crate::value::MAX_RUNTIME_VALUE_NESTING_DEPTH || !value.is_agent_value_node() {
        return false;
    }
    match value {
        RuntimeValueView::Sequence(values) => {
            values.all(|value| runtime_value_view_is_agent_value(value, depth + 1, work))
        }
        RuntimeValueView::Record(fields) => (0..fields.len()).all(|index| {
            fields.get(index).is_some_and(|(_, _, value)| {
                runtime_value_view_is_agent_value(value, depth + 1, work)
            })
        }),
        _ => true,
    }
}

fn write_variant_identity(
    encoder: &mut RuntimeSemanticTypeIdentityEncoder,
    owner: &RuntimeVariantIdentity,
) {
    match owner {
        RuntimeVariantIdentity::Nominal {
            semantic_identity, ..
        } => {
            encoder.write_u8(0);
            encoder.write_bytes(semantic_identity.as_bytes());
        }
        RuntimeVariantIdentity::Builtin(owner) => {
            encoder.write_u8(1);
            encoder.write_u8(owner.semantic_tag());
        }
    }
}

/// One field inside a runtime record pattern.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeRecordPatternField {
    field: RuntimeRecordFieldId,
    pattern: RuntimePattern,
}

impl RuntimeRecordPatternField {
    pub(crate) const fn from_admitted_parts(
        field: RuntimeRecordFieldId,
        pattern: RuntimePattern,
    ) -> Self {
        Self { field, pattern }
    }

    #[must_use]
    pub const fn field(&self) -> RuntimeRecordFieldId {
        self.field
    }

    #[must_use]
    pub const fn pattern(&self) -> &RuntimePattern {
        &self.pattern
    }
}

pub(crate) fn match_runtime_pattern(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    value: &RuntimeValue,
) -> Result<Option<Vec<RuntimeLocalBinding>>, RuntimePatternMatchError> {
    validate_runtime_pattern(plan, pattern)?;
    if !plan.value_matches_type(pattern.ty(), value)? {
        return Ok(None);
    }
    let mut bindings = Vec::with_capacity(pattern_binding_capacity(pattern));
    if collect_pattern_bindings(plan, pattern, value, &mut bindings)? {
        Ok(Some(bindings))
    } else {
        Ok(None)
    }
}

/// Borrows a matched pattern for guard evaluation while the original value
/// remains available to later arms. Only recursively unrestricted binding
/// leaves enter the temporary guard scope; an affine sibling stays in the
/// original scrutinee until the selected arm performs one owned bind.
pub(crate) fn project_runtime_pattern_guard_bindings(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    value: &RuntimeValue,
    required: &[RuntimeLocalDeclarationId],
    instantiation: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
) -> Result<Option<Vec<RuntimeLocalBinding>>, RuntimePatternMatchError> {
    if !inspect_runtime_pattern_owned(plan, pattern, value, instantiation)? {
        return Ok(None);
    }
    let required = required.iter().copied().collect::<BTreeSet<_>>();
    for &local in &required {
        let Some(ownership) = runtime_pattern_binding_ownership(pattern, value, local) else {
            return Err(RuntimePatternMatchError::UnknownLocal { local });
        };
        if !ownership.permits_copy() {
            return Err(RuntimePatternMatchError::AffineGuardBinding { local });
        }
    }
    let mut bindings = Vec::new();
    collect_copy_guard_bindings(pattern, value.live_view(), &required, &mut bindings);
    Ok(Some(bindings))
}

/// Checks the guard's exact admitted local-read inventory before any guard
/// expression runs, then projects only its selected Copy binding leaves.
pub(crate) fn prepare_runtime_pattern_guard_bindings(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    value: &RuntimeValue,
    guard: &RuntimeExpr,
    instantiation: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
) -> Result<Vec<RuntimeLocalBinding>, RuntimeEvalError> {
    let selected = guard.guard_copy_locals();
    for (local, mode) in guard.evaluation_free_local_reads(plan)?.iter().copied() {
        if !runtime_pattern_contains_binding(pattern, local) {
            continue;
        }
        if mode != RuntimeLocalReadMode::Copy {
            return Err(RuntimeEvalError::GuardMovedPatternBinding { local });
        }
        if !selected.contains(&local) {
            return Err(RuntimeEvalError::MissingGuardCopyRequirement { local });
        }
    }
    project_runtime_pattern_guard_bindings(plan, pattern, value, selected, instantiation)?
        .ok_or_else(|| RuntimeEvalError::PatternMismatch(crate::value::runtime_value_label(value)))
}

fn collect_copy_guard_bindings(
    pattern: &RuntimePattern,
    value: LiveRuntimeValueView<'_>,
    required: &BTreeSet<RuntimeLocalDeclarationId>,
    bindings: &mut Vec<RuntimeLocalBinding>,
) {
    let add = |binding: &RuntimePatternBindingCoordinate,
               value: LiveRuntimeValueView<'_>,
               bindings: &mut Vec<RuntimeLocalBinding>| {
        if required.contains(&binding.local()) {
            let value = value
                .copy_unrestricted()
                .expect("guard binding Copy was proven before projection");
            bindings.push(RuntimeLocalBinding {
                local: binding.local(),
                value,
            });
        }
    };
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => {
            if let Some(selected) = alternatives
                .iter()
                .find(|pattern| pattern_matches_view(pattern, value.inspect()))
            {
                collect_copy_guard_bindings(selected, value, required, bindings);
            }
        }
        RuntimePatternKind::Bind { binding, .. } | RuntimePatternKind::Typed { binding } => {
            add(binding, value, bindings);
        }
        RuntimePatternKind::Whole { binding, pattern } => {
            add(binding, value, bindings);
            collect_copy_guard_bindings(pattern, value, required, bindings);
        }
        RuntimePatternKind::Tuple(items) => {
            let RuntimeValueView::Tuple(_) = value.inspect() else {
                unreachable!("checked tuple pattern retains a tuple view")
            };
            for (index, pattern) in items.iter().enumerate() {
                let nested = value
                    .child_at(index)
                    .expect("checked tuple field remains present");
                collect_copy_guard_bindings(pattern, nested, required, bindings);
            }
        }
        RuntimePatternKind::Record { fields, rest } => {
            if let Some(binding) = rest.binding() {
                add(binding, value, bindings);
            }
            for field in fields {
                let index = field.field().zero_based() as usize;
                let nested = match value.inspect() {
                    RuntimeValueView::Record(values) => values
                        .get(index)
                        .filter(|(id, _, _)| *id == field.field())
                        .and_then(|_| value.child_at(index)),
                    RuntimeValueView::NominalRecord(_) => value.child_at(index),
                    _ => None,
                }
                .expect("checked record field remains present");
                collect_copy_guard_bindings(field.pattern(), nested, required, bindings);
            }
        }
        RuntimePatternKind::Sequence { items, rest } => {
            let Some(sequence) = value.sequence() else {
                unreachable!("checked sequence pattern retains a sequence view")
            };
            for (index, pattern) in items.iter().enumerate() {
                let nested = sequence
                    .live_value_view(index)
                    .expect("checked sequence item remains present");
                collect_copy_guard_bindings(pattern, nested, required, bindings);
            }
            if let Some(binding) = rest.binding()
                && required.contains(&binding.local())
            {
                bindings.push(RuntimeLocalBinding {
                    local: binding.local(),
                    value: RuntimeValue::Seq(sequence.tail_from(items.len())),
                });
            }
        }
        RuntimePatternKind::Variant { payload, .. } => {
            if let Some(pattern) = payload
                && let RuntimeValueView::Variant(variant) = value.inspect()
                && variant.payload().is_some()
            {
                collect_copy_guard_bindings(
                    pattern,
                    value
                        .child_at(0)
                        .expect("checked variant retains its child"),
                    required,
                    bindings,
                );
            }
        }
        RuntimePatternKind::Discard
        | RuntimePatternKind::Literal(_)
        | RuntimePatternKind::Entity(_) => {}
    }
}

/// Reads the ownership of exactly one admitted pattern binding without
/// creating a second runtime owner. Function input ABI checks use this before
/// any frame mutation.
pub(crate) fn runtime_pattern_binding_ownership(
    pattern: &RuntimePattern,
    value: &RuntimeValue,
    local: RuntimeLocalDeclarationId,
) -> Option<crate::value::ownership::RuntimeValueOwnership> {
    runtime_pattern_binding_ownership_view(pattern, value.live_view(), local)
}

fn runtime_pattern_binding_ownership_view(
    pattern: &RuntimePattern,
    value: LiveRuntimeValueView<'_>,
    local: RuntimeLocalDeclarationId,
) -> Option<crate::value::ownership::RuntimeValueOwnership> {
    use crate::value::ownership::RuntimeValueOwnership;
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => alternatives
            .iter()
            .find(|pattern| pattern_matches_view(pattern, value.inspect()))
            .and_then(|selected| runtime_pattern_binding_ownership_view(selected, value, local)),
        RuntimePatternKind::Bind { binding, .. } | RuntimePatternKind::Typed { binding } => {
            (binding.local() == local).then(|| value.ownership())
        }
        RuntimePatternKind::Whole {
            binding,
            pattern: inner,
        } => {
            if binding.local() == local {
                Some(value.ownership())
            } else {
                runtime_pattern_binding_ownership_view(inner, value, local)
            }
        }
        RuntimePatternKind::Tuple(items) => {
            let RuntimeValueView::Tuple(_) = value.inspect() else {
                return None;
            };
            items.iter().enumerate().find_map(|(index, item)| {
                value
                    .child_at(index)
                    .and_then(|value| runtime_pattern_binding_ownership_view(item, value, local))
            })
        }
        RuntimePatternKind::Record { fields, rest } => {
            if rest
                .binding()
                .is_some_and(|binding| binding.local() == local)
            {
                return Some(value.ownership());
            }
            fields.iter().find_map(|field| {
                let index = field.field().zero_based() as usize;
                let nested = match value.inspect() {
                    RuntimeValueView::Record(values) => values
                        .get(index)
                        .filter(|(id, _, _)| *id == field.field())
                        .and_then(|_| value.child_at(index)),
                    RuntimeValueView::NominalRecord(_) => value.child_at(index),
                    _ => None,
                };
                nested.and_then(|value| {
                    runtime_pattern_binding_ownership_view(field.pattern(), value, local)
                })
            })
        }
        RuntimePatternKind::Sequence { items, rest } => {
            let Some(sequence) = value.sequence() else {
                return None;
            };
            if rest
                .binding()
                .is_some_and(|binding| binding.local() == local)
            {
                return Some(
                    (items.len()..sequence.len())
                        .filter_map(|index| sequence.live_value_view(index))
                        .fold(RuntimeValueOwnership::Unrestricted, |ownership, value| {
                            ownership.join(value.ownership())
                        }),
                );
            }
            items.iter().enumerate().find_map(|(index, item)| {
                sequence
                    .live_value_view(index)
                    .and_then(|value| runtime_pattern_binding_ownership_view(item, value, local))
            })
        }
        RuntimePatternKind::Variant { payload, .. } => {
            let RuntimeValueView::Variant(_) = value.inspect() else {
                return None;
            };
            payload
                .as_deref()
                .zip(value.child_at(0))
                .and_then(|(pattern, nested)| {
                    runtime_pattern_binding_ownership_view(pattern, nested, local)
                })
        }
        RuntimePatternKind::Discard
        | RuntimePatternKind::Literal(_)
        | RuntimePatternKind::Entity(_) => None,
    }
}

pub(crate) fn runtime_pattern_contains_binding(
    pattern: &RuntimePattern,
    local: RuntimeLocalDeclarationId,
) -> bool {
    pattern
        .binding_declarations()
        .any(|binding| binding.local() == local)
}

/// Borrowed handle destination preview for dialogue result publication. The
/// actual result value remains in line custody until all host commands clear.
pub(crate) fn runtime_pattern_handle_destinations(
    pattern: &RuntimePattern,
    value: &RuntimeValue,
    token: &crate::runtime_id::RuntimeLineHandleToken,
) -> Result<Vec<RuntimeLocalDeclarationId>, crate::value::ownership::RuntimeAffineHandleError> {
    runtime_pattern_handle_destinations_view(pattern, value.view(), token)
}

pub(crate) fn runtime_pattern_handle_destinations_view(
    pattern: &RuntimePattern,
    value: RuntimeValueView<'_>,
    token: &crate::runtime_id::RuntimeLineHandleToken,
) -> Result<Vec<RuntimeLocalDeclarationId>, crate::value::ownership::RuntimeAffineHandleError> {
    let mut destinations = Vec::new();
    collect_pattern_handle_destinations(pattern, value, token, &mut destinations)?;
    Ok(destinations)
}

fn collect_pattern_handle_destinations(
    pattern: &RuntimePattern,
    value: RuntimeValueView<'_>,
    token: &crate::runtime_id::RuntimeLineHandleToken,
    destinations: &mut Vec<RuntimeLocalDeclarationId>,
) -> Result<(), crate::value::ownership::RuntimeAffineHandleError> {
    let contains = |view: RuntimeValueView<'_>| {
        view.line_handle_projection()
            .map(|handles| handles.iter().any(|handle| handle.token() == token))
    };
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => {
            if let Some(selected) = alternatives
                .iter()
                .find(|pattern| pattern_matches_view(pattern, value))
            {
                collect_pattern_handle_destinations(selected, value, token, destinations)?;
            }
        }
        RuntimePatternKind::Bind { binding, .. } | RuntimePatternKind::Typed { binding } => {
            if contains(value)? {
                destinations.push(binding.local());
            }
        }
        RuntimePatternKind::Whole { binding, pattern } => {
            if contains(value)? {
                destinations.push(binding.local());
            }
            collect_pattern_handle_destinations(pattern, value, token, destinations)?;
        }
        RuntimePatternKind::Tuple(items) => {
            if let RuntimeValueView::Tuple(_) = value {
                for (index, item) in items.iter().enumerate() {
                    if let Some(value) = value.child_at(index) {
                        collect_pattern_handle_destinations(item, value, token, destinations)?;
                    }
                }
            }
        }
        RuntimePatternKind::Record { fields, rest } => {
            if let Some(binding) = rest.binding()
                && contains(value)?
            {
                destinations.push(binding.local());
            }
            for field in fields {
                let index = field.field().zero_based() as usize;
                let nested = match value {
                    RuntimeValueView::Record(_) => value.child_at(index),
                    RuntimeValueView::NominalRecord(_) => value.child_at(index),
                    _ => None,
                };
                if let Some(value) = nested {
                    collect_pattern_handle_destinations(
                        field.pattern(),
                        value,
                        token,
                        destinations,
                    )?;
                }
            }
        }
        RuntimePatternKind::Sequence { items, rest } => {
            if let RuntimeValueView::Sequence(values) = value {
                for (index, item) in items.iter().enumerate() {
                    if let Some(value) = values.value_view(index) {
                        collect_pattern_handle_destinations(item, value, token, destinations)?;
                    }
                }
                if let Some(binding) = rest.binding() {
                    let len = values.len().map_err(|_| {
                        crate::value::ownership::RuntimeAffineHandleError::StructuralOrdinalOverflow
                    })?;
                    for index in items.len()..len {
                        if let Some(value) = values.value_view(index) {
                            if contains(value)? {
                                destinations.push(binding.local());
                                break;
                            }
                        }
                    }
                }
            }
        }
        RuntimePatternKind::Variant {
            payload: Some(pattern),
            ..
        } => {
            if let RuntimeValueView::Variant(variant) = value
                && variant.payload().is_some()
            {
                collect_pattern_handle_destinations(
                    pattern,
                    value
                        .child_at(0)
                        .expect("checked variant retains its child"),
                    token,
                    destinations,
                )?;
            }
        }
        RuntimePatternKind::Discard
        | RuntimePatternKind::Literal(_)
        | RuntimePatternKind::Entity(_)
        | RuntimePatternKind::Variant { payload: None, .. } => {}
    }
    Ok(())
}

/// Consuming binder for function-frame inputs. Matching and overlap admission
/// finish against borrowed values before any field owner is transferred.
pub(crate) fn match_runtime_pattern_owned(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    value: RuntimeValue,
    instantiation: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
) -> Result<Option<Vec<RuntimeLocalBinding>>, RuntimePatternMatchError> {
    let prepared = prepare_runtime_pattern_owned_view(
        plan,
        pattern,
        value.live_view(),
        instantiation,
        &crate::entry::schema::value_budget::ValidationWork::new(
            crate::entry::RuntimeSchemaLimits::engine_default(),
        ),
    )?;
    Ok(prepared.map(|prepared| prepared.commit(value)))
}

/// Consumed proof that an exact, immutable pattern accepted an owning value's
/// live projection, including all affine overlap checks, before its move.
pub(crate) struct RuntimePreparedPatternBinding<'a> {
    pattern: &'a RuntimePattern,
}

impl RuntimePreparedPatternBinding<'_> {
    pub(crate) fn commit(self, value: RuntimeValue) -> Vec<RuntimeLocalBinding> {
        let mut bindings = Vec::with_capacity(pattern_binding_capacity(self.pattern));
        collect_pattern_bindings_owned(self.pattern, value, &mut bindings);
        bindings
    }
}

/// Exact borrowed preflight for a later owning bind. Success seals all
/// refutable tests and affine overlap checks before an owner is taken.
pub(crate) fn inspect_runtime_pattern_owned(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    value: &RuntimeValue,
    instantiation: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
) -> Result<bool, RuntimePatternMatchError> {
    Ok(prepare_runtime_pattern_owned_view(
        plan,
        pattern,
        value.live_view(),
        instantiation,
        &crate::entry::schema::value_budget::ValidationWork::new(
            crate::entry::RuntimeSchemaLimits::engine_default(),
        ),
    )?
    .is_some())
}

pub(crate) fn prepare_runtime_pattern_owned_view<'a>(
    plan: &RuntimePlan,
    pattern: &'a RuntimePattern,
    value: LiveRuntimeValueView<'_>,
    instantiation: Option<&crate::program_types::RuntimeFunctionEffectInstantiation>,
    work: &crate::entry::schema::value_budget::ValidationWork,
) -> Result<Option<RuntimePreparedPatternBinding<'a>>, RuntimePatternMatchError> {
    validate_runtime_pattern(plan, pattern)?;
    let type_matches = match instantiation {
        Some(binding) => {
            binding.value_view_matches_with_work(plan, pattern.ty(), value.inspect(), work)
        }
        None => plan.value_view_matches_type_with_work(pattern.ty(), value.inspect(), work)?,
    };
    if !type_matches || !pattern_matches_view(pattern, value.inspect()) {
        return Ok(None);
    }
    check_owned_pattern_overlap_view(pattern, value)?;
    Ok(Some(RuntimePreparedPatternBinding { pattern }))
}

fn pattern_matches_borrowed(pattern: &RuntimePattern, value: &RuntimeValue) -> bool {
    pattern_matches_view(pattern, value.view())
}

fn check_owned_pattern_overlap_view(
    pattern: &RuntimePattern,
    value: LiveRuntimeValueView<'_>,
) -> Result<(), RuntimePatternMatchError> {
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => alternatives
            .iter()
            .find(|pattern| pattern_matches_view(pattern, value.inspect()))
            .map_or(Ok(()), |pattern| {
                check_owned_pattern_overlap_view(pattern, value)
            }),
        RuntimePatternKind::Whole { pattern: inner, .. } => {
            if pattern_binding_capacity(inner) != 0 && !value.ownership().permits_copy() {
                return Err(RuntimePatternMatchError::AffineBindingOverlap);
            }
            check_owned_pattern_overlap_view(inner, value)
        }
        RuntimePatternKind::Record { fields, rest } => {
            if rest.binding().is_some()
                && fields
                    .iter()
                    .any(|field| pattern_binding_capacity(field.pattern()) != 0)
                && !value.ownership().permits_copy()
            {
                return Err(RuntimePatternMatchError::AffineBindingOverlap);
            }
            for field in fields {
                let index = field.field().zero_based() as usize;
                let nested = match value.inspect() {
                    RuntimeValueView::Record(_) => value.child_at(index),
                    RuntimeValueView::NominalRecord(_) => value.child_at(index),
                    _ => None,
                };
                if let Some(value) = nested {
                    check_owned_pattern_overlap_view(field.pattern(), value)?;
                }
            }
            Ok(())
        }
        RuntimePatternKind::Tuple(items) => {
            let RuntimeValueView::Tuple(_) = value.inspect() else {
                return Ok(());
            };
            for (index, pattern) in items.iter().enumerate() {
                if let Some(value) = value.child_at(index) {
                    check_owned_pattern_overlap_view(pattern, value)?;
                }
            }
            Ok(())
        }
        RuntimePatternKind::Sequence { items, .. } => {
            let RuntimeValueView::Sequence(_) = value.inspect() else {
                return Ok(());
            };
            for (index, pattern) in items.iter().enumerate() {
                if let Some(value) = value.child_at(index) {
                    check_owned_pattern_overlap_view(pattern, value)?;
                }
            }
            Ok(())
        }
        RuntimePatternKind::Variant {
            payload: Some(pattern),
            ..
        } => {
            let RuntimeValueView::Variant(_) = value.inspect() else {
                return Ok(());
            };
            let Some(nested) = value.child_at(0) else {
                return Ok(());
            };
            check_owned_pattern_overlap_view(pattern, nested)
        }
        RuntimePatternKind::Bind { .. }
        | RuntimePatternKind::Typed { .. }
        | RuntimePatternKind::Discard
        | RuntimePatternKind::Literal(_)
        | RuntimePatternKind::Entity(_)
        | RuntimePatternKind::Variant { payload: None, .. } => Ok(()),
    }
}

fn collect_pattern_bindings_owned(
    pattern: &RuntimePattern,
    value: RuntimeValue,
    bindings: &mut Vec<RuntimeLocalBinding>,
) {
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => {
            let selected = alternatives
                .iter()
                .find(|pattern| pattern_matches_borrowed(pattern, &value))
                .expect("preflight selected an Or alternative");
            collect_pattern_bindings_owned(selected, value, bindings);
        }
        RuntimePatternKind::Bind { binding, .. } | RuntimePatternKind::Typed { binding } => {
            bindings.push(RuntimeLocalBinding {
                local: binding.local(),
                value,
            })
        }
        RuntimePatternKind::Whole {
            binding,
            pattern: inner,
        } => {
            if pattern_binding_capacity(inner) == 0 {
                bindings.push(RuntimeLocalBinding {
                    local: binding.local(),
                    value,
                });
            } else {
                let whole = value.clone(); // overlap preflight proved unrestricted
                collect_pattern_bindings_owned(inner, value, bindings);
                bindings.push(RuntimeLocalBinding {
                    local: binding.local(),
                    value: whole,
                });
            }
        }
        RuntimePatternKind::Tuple(patterns) => {
            let RuntimeValue::Tuple(values) = value else {
                unreachable!("preflight matched tuple");
            };
            for (pattern, value) in patterns.iter().zip(values) {
                collect_pattern_bindings_owned(pattern, value, bindings);
            }
        }
        RuntimePatternKind::Record { fields, rest } => {
            let whole = rest.binding().and_then(|binding| {
                fields
                    .iter()
                    .any(|field| pattern_binding_capacity(field.pattern()) != 0)
                    .then(|| RuntimeLocalBinding {
                        local: binding.local(),
                        value: value.clone(), // overlap preflight proved unrestricted
                    })
            });
            if rest.binding().is_some() && whole.is_none() {
                bindings.push(RuntimeLocalBinding {
                    local: rest.binding().expect("checked record rest").local(),
                    value,
                });
                return;
            }
            let mut values = match value {
                RuntimeValue::Record(record) => record
                    .into_iter()
                    .map(|field| Some(field.into_value()))
                    .collect::<Vec<_>>(),
                RuntimeValue::NominalRecord(record) => record
                    .into_fields()
                    .into_iter()
                    .map(Some)
                    .collect::<Vec<_>>(),
                _ => unreachable!("preflight matched record"),
            };
            for field in fields {
                let index = field.field().zero_based() as usize;
                let value = values[index]
                    .take()
                    .expect("preflight matched record field");
                collect_pattern_bindings_owned(field.pattern(), value, bindings);
            }
            if let Some(whole) = whole {
                bindings.push(whole);
            }
        }
        RuntimePatternKind::Sequence { items, rest } => {
            let RuntimeValue::Seq(sequence) = value else {
                unreachable!("preflight matched sequence");
            };
            let mut values = sequence.into_values().into_iter();
            for pattern in items {
                collect_pattern_bindings_owned(
                    pattern,
                    values.next().expect("preflight matched sequence item"),
                    bindings,
                );
            }
            if let Some(binding) = rest.binding() {
                bindings.push(RuntimeLocalBinding {
                    local: binding.local(),
                    value: RuntimeValue::Seq(crate::value::RuntimeSeq::Values(values.collect())),
                });
            }
        }
        RuntimePatternKind::Variant {
            payload: Some(pattern),
            ..
        } => {
            let RuntimeValue::Variant(variant) = value else {
                unreachable!("preflight matched variant");
            };
            collect_pattern_bindings_owned(
                pattern,
                variant.into_payload().expect("preflight matched payload"),
                bindings,
            );
        }
        RuntimePatternKind::Variant { payload: None, .. }
        | RuntimePatternKind::Discard
        | RuntimePatternKind::Literal(_)
        | RuntimePatternKind::Entity(_) => {}
    }
}

pub(crate) fn pattern_binding_capacity(pattern: &RuntimePattern) -> usize {
    let direct = match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => {
            alternatives.first().map_or(0, pattern_binding_capacity)
        }
        RuntimePatternKind::Bind { .. } | RuntimePatternKind::Typed { .. } => 1,
        RuntimePatternKind::Discard
        | RuntimePatternKind::Literal(_)
        | RuntimePatternKind::Entity(_) => 0,
        RuntimePatternKind::Tuple(patterns)
        | RuntimePatternKind::Sequence {
            items: patterns, ..
        } => patterns.iter().map(pattern_binding_capacity).sum(),
        RuntimePatternKind::Record { fields, .. } => fields
            .iter()
            .map(|field| pattern_binding_capacity(field.pattern()))
            .sum(),
        RuntimePatternKind::Variant { payload, .. } => {
            payload.as_deref().map_or(0, pattern_binding_capacity)
        }
        RuntimePatternKind::Whole { pattern, .. } => pattern_binding_capacity(pattern) + 1,
    };
    direct
        + usize::from(matches!(
            pattern.kind(),
            RuntimePatternKind::Record {
                rest: RuntimePatternRest::Bind(_),
                ..
            } | RuntimePatternKind::Sequence {
                rest: RuntimePatternRest::Bind(_),
                ..
            }
        ))
}

#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimePatternMatchError {
    #[error(transparent)]
    ValueType(#[from] RuntimePlanValueTypeError),
    #[error("an affine pattern input would be bound both whole and through a nested field")]
    AffineBindingOverlap,
    #[error("a borrowed pattern cannot duplicate an affine binding input")]
    AffineBorrowedPatternBinding,
    #[error("guard local {local} requires Copy but its selected pattern leaf is affine")]
    AffineGuardBinding { local: RuntimeLocalDeclarationId },
    #[error("runtime pattern references unknown plan type {ty}")]
    UnknownType { ty: RuntimePlanTypeId },
    #[error("runtime pattern kind is incompatible with plan type {ty}")]
    InvalidKind { ty: RuntimePlanTypeId },
    #[error("runtime pattern child has type {actual}, expected {expected}")]
    ChildType {
        expected: RuntimePlanTypeId,
        actual: RuntimePlanTypeId,
    },
    #[error("runtime pattern references unknown local declaration {local}")]
    UnknownLocal { local: RuntimeLocalDeclarationId },
    #[error("runtime pattern local {local} has type {actual}, expected {expected}")]
    LocalType {
        local: RuntimeLocalDeclarationId,
        expected: RuntimePlanTypeId,
        actual: RuntimePlanTypeId,
    },
    #[error("runtime pattern local {local} has a coordinate inconsistent with its node")]
    InvalidCoordinate { local: RuntimeLocalDeclarationId },
    #[error("runtime pattern binds local {local} more than once")]
    DuplicateLocal { local: RuntimeLocalDeclarationId },
    #[error("runtime record pattern type {ty} has no nominal-record domain")]
    MissingRecordDomain { ty: RuntimePlanTypeId },
    #[error("runtime record pattern type {ty} references unknown field {field}")]
    UnknownRecordField {
        ty: RuntimePlanTypeId,
        field: RuntimeRecordFieldId,
    },
    #[error("runtime record pattern type {ty} repeats field {field}")]
    DuplicateRecordField {
        ty: RuntimePlanTypeId,
        field: RuntimeRecordFieldId,
    },
    #[error(transparent)]
    VariantCase(#[from] crate::plan::RuntimePlanVariantCaseError),
    #[error("runtime variant pattern type {ty} has an invalid payload shape for case {ordinal}")]
    VariantPayload { ty: RuntimePlanTypeId, ordinal: u32 },
}

fn validate_runtime_pattern(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
) -> Result<(), RuntimePatternMatchError> {
    let mut locals = BTreeSet::new();
    validate_pattern_node(plan, pattern, &[], &mut locals)
}

fn validate_pattern_node(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    path: &[RuntimePatternBindingStep],
    locals: &mut BTreeSet<RuntimeLocalDeclarationId>,
) -> Result<(), RuntimePatternMatchError> {
    let declaration = plan
        .type_table()
        .get(pattern.ty())
        .ok_or(RuntimePatternMatchError::UnknownType { ty: pattern.ty() })?;
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => {
            if alternatives.len() < 2 {
                return Err(RuntimePatternMatchError::InvalidKind { ty: pattern.ty() });
            }
            let initial = locals.clone();
            let mut shared = None;
            for alternative in alternatives {
                validate_child_type(pattern.ty(), alternative.ty())?;
                let mut current = initial.clone();
                validate_pattern_node(plan, alternative, path, &mut current)?;
                if let Some(expected) = &shared {
                    if expected != &current {
                        return Err(RuntimePatternMatchError::InvalidKind { ty: pattern.ty() });
                    }
                } else {
                    shared = Some(current);
                }
            }
            *locals = shared.expect("at least two alternatives");
            Ok(())
        }
        RuntimePatternKind::Bind { binding, .. } | RuntimePatternKind::Typed { binding } => {
            validate_binding(plan, pattern.ty(), path, binding, locals)
        }
        RuntimePatternKind::Discard => Ok(()),
        RuntimePatternKind::Literal(value) => {
            if plan.value_matches_type(pattern.ty(), value)? {
                Ok(())
            } else {
                Err(RuntimePatternMatchError::InvalidKind { ty: pattern.ty() })
            }
        }
        RuntimePatternKind::Entity(value) => match declaration.projection() {
            RuntimePlanTypeProjection::EntityReference(expected) if expected.accepts(value) => {
                Ok(())
            }
            _ => Err(RuntimePatternMatchError::InvalidKind { ty: pattern.ty() }),
        },
        RuntimePatternKind::Tuple(patterns) => {
            validate_tuple_pattern(plan, pattern.ty(), patterns, path, locals)
        }
        RuntimePatternKind::Record { fields, rest } => {
            validate_record_pattern(plan, pattern.ty(), fields, rest, path, locals)
        }
        RuntimePatternKind::Sequence { items, rest } => {
            validate_sequence_pattern(plan, pattern.ty(), items, rest, path, locals)
        }
        RuntimePatternKind::Variant { ordinal, payload } => validate_variant_pattern(
            plan,
            pattern.ty(),
            *ordinal,
            payload.as_deref(),
            path,
            locals,
        ),
        RuntimePatternKind::Whole {
            binding,
            pattern: inner,
        } => {
            validate_child_type(pattern.ty(), inner.ty())?;
            validate_binding(plan, pattern.ty(), path, binding, locals)?;
            validate_pattern_node(plan, inner, path, locals)
        }
    }
}

fn validate_tuple_pattern(
    plan: &RuntimePlan,
    ty: RuntimePlanTypeId,
    patterns: &[RuntimePattern],
    path: &[RuntimePatternBindingStep],
    locals: &mut BTreeSet<RuntimeLocalDeclarationId>,
) -> Result<(), RuntimePatternMatchError> {
    let Some(projection) = plan
        .type_table()
        .get(ty)
        .map(crate::plan::RuntimePlanTypeDeclaration::projection)
    else {
        return Err(RuntimePatternMatchError::InvalidKind { ty });
    };
    if projection.tuple_arity() != Some(patterns.len()) {
        return Err(RuntimePatternMatchError::InvalidKind { ty });
    }
    for (ordinal, pattern) in patterns.iter().enumerate() {
        let expected = projection
            .tuple_element(ordinal)
            .ok_or(RuntimePatternMatchError::InvalidKind { ty })?;
        validate_child_type(*expected, pattern.ty())?;
        let ordinal =
            u32::try_from(ordinal).map_err(|_| RuntimePatternMatchError::InvalidKind { ty })?;
        let mut child_path = path.to_vec();
        child_path.push(RuntimePatternBindingStep::TupleElement(ordinal));
        validate_pattern_node(plan, pattern, &child_path, locals)?;
    }
    Ok(())
}

/// The two exact runtime record families admitted by a record pattern.
///
/// Keeping the projection join here makes validation and matching consume the
/// same declaration-owned field coordinates. Structural records never fall
/// back to nominal domains or diagnostic-name lookup.
enum RuntimeRecordPatternDomain<'a> {
    ProjectNominal(&'a RuntimeNominalRecordDomain),
    Record(&'a [RuntimePlanRecordField<RuntimePlanTypeId>]),
}

impl RuntimeRecordPatternDomain<'_> {
    fn field_type(&self, field: RuntimeRecordFieldId) -> Option<RuntimePlanTypeId> {
        let ordinal = usize::try_from(field.zero_based()).ok()?;
        match self {
            Self::ProjectNominal(domain) => domain
                .fields()
                .get(ordinal)
                .map(crate::plan::RuntimeNominalRecordDomainField::ty),
            Self::Record(fields) => fields.get(ordinal).map(|field| *field.ty()),
        }
    }

    fn value_field_count(&self, value: &RuntimeValue) -> Option<usize> {
        match (self, value) {
            (Self::ProjectNominal(_), RuntimeValue::NominalRecord(record)) => {
                Some(record.fields().len())
            }
            (Self::Record(_), RuntimeValue::Record(fields)) => Some(fields.len()),
            (Self::ProjectNominal(_) | Self::Record(_), _) => None,
        }
    }

    fn value_field<'value>(
        &self,
        value: &'value RuntimeValue,
        field: RuntimeRecordFieldId,
    ) -> Option<&'value RuntimeValue> {
        match (self, value) {
            (Self::ProjectNominal(_), RuntimeValue::NominalRecord(record)) => record.field(field),
            (Self::Record(_), RuntimeValue::Record(fields)) => {
                let ordinal = usize::try_from(field.zero_based()).ok()?;
                fields
                    .get(ordinal)
                    .filter(|value| value.field() == field)
                    .map(crate::value::RuntimeFieldValue::value)
            }
            (Self::ProjectNominal(_) | Self::Record(_), _) => None,
        }
    }
}

fn runtime_record_pattern_domain(
    plan: &RuntimePlan,
    ty: RuntimePlanTypeId,
) -> Result<RuntimeRecordPatternDomain<'_>, RuntimePatternMatchError> {
    let declaration = plan
        .type_table()
        .get(ty)
        .ok_or(RuntimePatternMatchError::UnknownType { ty })?;
    match declaration.projection() {
        RuntimePlanTypeProjection::Nominal { .. } => plan
            .nominal_record_domains()
            .get(ty)
            .map(RuntimeRecordPatternDomain::ProjectNominal)
            .ok_or(RuntimePatternMatchError::MissingRecordDomain { ty }),
        RuntimePlanTypeProjection::Record(fields) => Ok(RuntimeRecordPatternDomain::Record(fields)),
        RuntimePlanTypeProjection::BoundType(_)
        | RuntimePlanTypeProjection::PresentationResource(_)
        | RuntimePlanTypeProjection::Never
        | RuntimePlanTypeProjection::Unit
        | RuntimePlanTypeProjection::Bool
        | RuntimePlanTypeProjection::Signed(_)
        | RuntimePlanTypeProjection::Unsigned(_)
        | RuntimePlanTypeProjection::F32
        | RuntimePlanTypeProjection::F64
        | RuntimePlanTypeProjection::String
        | RuntimePlanTypeProjection::Color
        | RuntimePlanTypeProjection::Char
        | RuntimePlanTypeProjection::Bytes
        | RuntimePlanTypeProjection::Duration
        | RuntimePlanTypeProjection::Progress
        | RuntimePlanTypeProjection::DenseNumeric(_)
        | RuntimePlanTypeProjection::EntityReference(_)
        | RuntimePlanTypeProjection::AgentValue
        | RuntimePlanTypeProjection::Range(_)
        | RuntimePlanTypeProjection::Iterator(_)
        | RuntimePlanTypeProjection::Sequence { .. }
        | RuntimePlanTypeProjection::Array { .. }
        | RuntimePlanTypeProjection::Map { .. }
        | RuntimePlanTypeProjection::Need(_)
        | RuntimePlanTypeProjection::Traversal { .. }
        | RuntimePlanTypeProjection::Stream { .. }
        | RuntimePlanTypeProjection::Result { .. }
        | RuntimePlanTypeProjection::Option { .. }
        | RuntimePlanTypeProjection::BuiltinVariant { .. }
        | RuntimePlanTypeProjection::ThreadHandle(_)
        | RuntimePlanTypeProjection::Shared(_)
        | RuntimePlanTypeProjection::Reference(_)
        | RuntimePlanTypeProjection::Function { .. }
        | RuntimePlanTypeProjection::Tuple(_)
        | RuntimePlanTypeProjection::Choice(_)
        | RuntimePlanTypeProjection::Opaque { .. }
        | RuntimePlanTypeProjection::Agent(_) => Err(RuntimePatternMatchError::InvalidKind { ty }),
    }
}

fn validate_record_pattern(
    plan: &RuntimePlan,
    ty: RuntimePlanTypeId,
    fields: &[RuntimeRecordPatternField],
    rest: &RuntimePatternRest,
    path: &[RuntimePatternBindingStep],
    locals: &mut BTreeSet<RuntimeLocalDeclarationId>,
) -> Result<(), RuntimePatternMatchError> {
    let domain = runtime_record_pattern_domain(plan, ty)?;
    let mut seen_fields = BTreeSet::new();
    for (ordinal, field) in fields.iter().enumerate() {
        if !seen_fields.insert(field.field()) {
            return Err(RuntimePatternMatchError::DuplicateRecordField {
                ty,
                field: field.field(),
            });
        }
        let expected = domain.field_type(field.field()).ok_or(
            RuntimePatternMatchError::UnknownRecordField {
                ty,
                field: field.field(),
            },
        )?;
        validate_child_type(expected, field.pattern().ty())?;
        let ordinal =
            u32::try_from(ordinal).map_err(|_| RuntimePatternMatchError::InvalidKind { ty })?;
        let mut child_path = path.to_vec();
        child_path.push(RuntimePatternBindingStep::RecordField(ordinal));
        validate_pattern_node(plan, field.pattern(), &child_path, locals)?;
    }
    if let Some(binding) = rest.binding() {
        let mut rest_path = path.to_vec();
        rest_path.push(RuntimePatternBindingStep::RecordRest);
        validate_binding(plan, ty, &rest_path, binding, locals)?;
    }
    Ok(())
}

fn validate_sequence_pattern(
    plan: &RuntimePlan,
    ty: RuntimePlanTypeId,
    items: &[RuntimePattern],
    rest: &RuntimePatternRest,
    path: &[RuntimePatternBindingStep],
    locals: &mut BTreeSet<RuntimeLocalDeclarationId>,
) -> Result<(), RuntimePatternMatchError> {
    let declaration = plan
        .type_table()
        .get(ty)
        .ok_or(RuntimePatternMatchError::UnknownType { ty })?;
    let item_ty = match declaration.projection() {
        RuntimePlanTypeProjection::Sequence { item, .. } => *item,
        RuntimePlanTypeProjection::Array { item, .. }
            if !matches!(rest, RuntimePatternRest::Bind(_)) =>
        {
            *item
        }
        _ => return Err(RuntimePatternMatchError::InvalidKind { ty }),
    };
    for (ordinal, item) in items.iter().enumerate() {
        validate_child_type(item_ty, item.ty())?;
        let ordinal =
            u32::try_from(ordinal).map_err(|_| RuntimePatternMatchError::InvalidKind { ty })?;
        let mut child_path = path.to_vec();
        child_path.push(RuntimePatternBindingStep::SequenceElement(ordinal));
        validate_pattern_node(plan, item, &child_path, locals)?;
    }
    if let Some(binding) = rest.binding() {
        let mut rest_path = path.to_vec();
        rest_path.push(RuntimePatternBindingStep::SequenceRest);
        validate_binding(plan, ty, &rest_path, binding, locals)?;
    }
    Ok(())
}

fn validate_variant_pattern(
    plan: &RuntimePlan,
    ty: RuntimePlanTypeId,
    ordinal: u32,
    payload: Option<&RuntimePattern>,
    path: &[RuntimePatternBindingStep],
    locals: &mut BTreeSet<RuntimeLocalDeclarationId>,
) -> Result<(), RuntimePatternMatchError> {
    match (plan.variant_case(ty, ordinal)?.payload(), payload) {
        (Some(expected), Some(payload)) => {
            validate_child_type(expected, payload.ty())?;
            let mut child_path = path.to_vec();
            child_path.push(RuntimePatternBindingStep::VariantPayload);
            validate_pattern_node(plan, payload, &child_path, locals)
        }
        (None, None) => Ok(()),
        (Some(_), None) | (None, Some(_)) => {
            Err(RuntimePatternMatchError::VariantPayload { ty, ordinal })
        }
    }
}

fn validate_binding(
    plan: &RuntimePlan,
    expected_ty: RuntimePlanTypeId,
    path: &[RuntimePatternBindingStep],
    binding: &RuntimePatternBindingCoordinate,
    locals: &mut BTreeSet<RuntimeLocalDeclarationId>,
) -> Result<(), RuntimePatternMatchError> {
    let local = plan.local_declarations().get(binding.local()).ok_or(
        RuntimePatternMatchError::UnknownLocal {
            local: binding.local(),
        },
    )?;
    if local.ty() != expected_ty {
        return Err(RuntimePatternMatchError::LocalType {
            local: binding.local(),
            expected: expected_ty,
            actual: local.ty(),
        });
    }
    let expected_path = if path.is_empty() {
        &[RuntimePatternBindingStep::Whole][..]
    } else {
        path
    };
    if binding.path().steps() != expected_path {
        return Err(RuntimePatternMatchError::InvalidCoordinate {
            local: binding.local(),
        });
    }
    if !locals.insert(binding.local()) {
        return Err(RuntimePatternMatchError::DuplicateLocal {
            local: binding.local(),
        });
    }
    Ok(())
}

fn validate_child_type(
    expected: RuntimePlanTypeId,
    actual: RuntimePlanTypeId,
) -> Result<(), RuntimePatternMatchError> {
    if expected == actual {
        Ok(())
    } else {
        Err(RuntimePatternMatchError::ChildType { expected, actual })
    }
}

fn collect_pattern_bindings(
    plan: &RuntimePlan,
    pattern: &RuntimePattern,
    value: &RuntimeValue,
    bindings: &mut Vec<RuntimeLocalBinding>,
) -> Result<bool, RuntimePatternMatchError> {
    match pattern.kind() {
        RuntimePatternKind::Or(alternatives) => {
            for alternative in alternatives {
                if pattern_matches_borrowed(alternative, value) {
                    return collect_pattern_bindings(plan, alternative, value, bindings);
                }
            }
            Ok(false)
        }
        RuntimePatternKind::Bind { binding, .. } | RuntimePatternKind::Typed { binding } => {
            bindings.push(RuntimeLocalBinding {
                local: binding.local(),
                value: value.clone(),
            });
            Ok(true)
        }
        RuntimePatternKind::Discard => Ok(true),
        RuntimePatternKind::Literal(expected) => Ok(expected == value),
        RuntimePatternKind::Entity(expected) => Ok(matches!(
            value,
            RuntimeValue::EntityRef(actual) if actual == expected
        )),
        RuntimePatternKind::Tuple(patterns) => {
            let RuntimeValue::Tuple(values) = value else {
                return Ok(false);
            };
            collect_pattern_list(plan, patterns, values, bindings)
        }
        RuntimePatternKind::Record { fields, rest } => {
            collect_record_pattern_bindings(plan, pattern.ty(), fields, rest, value, bindings)
        }
        RuntimePatternKind::Sequence { items, rest } => {
            collect_sequence_pattern_bindings(plan, items, rest, value, bindings)
        }
        RuntimePatternKind::Variant {
            ordinal, payload, ..
        } => {
            let RuntimeValue::Variant(variant) = value else {
                return Ok(false);
            };
            if *ordinal != variant.ordinal() {
                return Ok(false);
            }
            match (payload.as_deref(), variant.payload()) {
                (Some(pattern), Some(value)) => {
                    collect_pattern_bindings(plan, pattern, value, bindings)
                }
                (None, None) => Ok(true),
                (Some(_), None) | (None, Some(_)) => Ok(false),
            }
        }
        RuntimePatternKind::Whole {
            binding,
            pattern: inner,
        } => {
            if !collect_pattern_bindings(plan, inner, value, bindings)? {
                return Ok(false);
            }
            bindings.push(RuntimeLocalBinding {
                local: binding.local(),
                value: value.clone(),
            });
            Ok(true)
        }
    }
}

fn collect_record_pattern_bindings(
    plan: &RuntimePlan,
    ty: RuntimePlanTypeId,
    fields: &[RuntimeRecordPatternField],
    rest: &RuntimePatternRest,
    value: &RuntimeValue,
    bindings: &mut Vec<RuntimeLocalBinding>,
) -> Result<bool, RuntimePatternMatchError> {
    let domain = runtime_record_pattern_domain(plan, ty)?;
    let Some(field_count) = domain.value_field_count(value) else {
        return Ok(false);
    };
    if !rest.accepts_len(fields.len(), field_count) {
        return Ok(false);
    }
    for field in fields {
        let Some(value) = domain.value_field(value, field.field()) else {
            return Ok(false);
        };
        if !collect_pattern_bindings(plan, field.pattern(), value, bindings)? {
            return Ok(false);
        }
    }
    if let Some(binding) = rest.binding() {
        bindings.push(RuntimeLocalBinding {
            local: binding.local(),
            value: value.clone(),
        });
    }
    Ok(true)
}

fn collect_sequence_pattern_bindings(
    plan: &RuntimePlan,
    items: &[RuntimePattern],
    rest: &RuntimePatternRest,
    value: &RuntimeValue,
    bindings: &mut Vec<RuntimeLocalBinding>,
) -> Result<bool, RuntimePatternMatchError> {
    let RuntimeValue::Seq(sequence) = value else {
        return Ok(false);
    };
    if !rest.accepts_len(items.len(), sequence.len()) {
        return Ok(false);
    }
    for (index, pattern) in items.iter().enumerate() {
        if !collect_pattern_bindings(plan, pattern, &sequence.value_at(index), bindings)? {
            return Ok(false);
        }
    }
    if let Some(binding) = rest.binding() {
        bindings.push(RuntimeLocalBinding {
            local: binding.local(),
            value: RuntimeValue::Seq(sequence.tail_from(items.len())),
        });
    }
    Ok(true)
}

fn collect_pattern_list(
    plan: &RuntimePlan,
    patterns: &[RuntimePattern],
    values: &[RuntimeValue],
    bindings: &mut Vec<RuntimeLocalBinding>,
) -> Result<bool, RuntimePatternMatchError> {
    for (pattern, value) in patterns.iter().zip(values) {
        if !collect_pattern_bindings(plan, pattern, value, bindings)? {
            return Ok(false);
        }
    }
    Ok(true)
}

impl RuntimePlan {
    /// Checks one value against the sole admitted plan type graph.
    ///
    /// Pattern matching and structured closure capture/application share this
    /// context-owned operation instead of maintaining parallel predicates.
    pub(crate) fn value_matches_type(
        &self,
        ty: RuntimePlanTypeId,
        value: &RuntimeValue,
    ) -> Result<bool, RuntimePlanValueTypeError> {
        self.value_matches_type_with_work(
            ty,
            value,
            &crate::entry::schema::value_budget::ValidationWork::new(
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ),
        )
    }

    pub(crate) fn value_matches_type_with_work(
        &self,
        ty: RuntimePlanTypeId,
        value: &RuntimeValue,
        work: &crate::entry::schema::value_budget::ValidationWork,
    ) -> Result<bool, RuntimePlanValueTypeError> {
        self.value_view_matches_type_with_work(ty, value.view(), work)
    }

    pub(crate) fn value_view_matches_type_with_work(
        &self,
        ty: RuntimePlanTypeId,
        value: RuntimeValueView<'_>,
        work: &crate::entry::schema::value_budget::ValidationWork,
    ) -> Result<bool, RuntimePlanValueTypeError> {
        if self.type_table().get(ty).is_none() {
            return Err(RuntimePlanValueTypeError::UnknownType { ty });
        }
        Ok(self
            .validate_live_value_view_with_work(ty, value, work)
            .is_ok())
    }
}

impl RuntimePatternKind {
    pub(crate) const fn semantic_tag(&self) -> u8 {
        match self {
            Self::Bind { .. } => 0,
            Self::Discard => 1,
            Self::Literal(_) => 2,
            Self::Entity(_) => 3,
            Self::Tuple(_) => 4,
            Self::Or(_) => 5,
            Self::Record { .. } => 6,
            Self::Sequence { .. } => 7,
            Self::Variant { .. } => 8,
            Self::Whole { .. } => 9,
            Self::Typed { .. } => 10,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::plan::{
        RuntimeLocalDeclarationSeed, RuntimeNominalRecordDomainFieldSeed,
        RuntimeNominalRecordDomainSeed, RuntimePatternRestSeed, RuntimePatternSeed,
        RuntimePatternSeedKind, RuntimePlanBuildError, RuntimePlanBuilder, RuntimePlanRecordField,
        RuntimePlanTypeProjection, RuntimePlanTypeSeed, RuntimeRecordFieldSeedId,
        RuntimeRecordPatternFieldSeed,
    };
    use crate::value::{
        RuntimeBuiltinVariantValueError, RuntimeNominalRecordValue, runtime_sequence_values,
    };

    fn identity(marker: u8) -> RuntimeSemanticTypeId {
        RuntimeSemanticTypeId::from_bytes([marker; 32])
    }

    #[test]
    fn standard_audio_handle_has_a_distinct_plain_opaque_owner() {
        let spec = runtime_standard_opaque_type(&["AudioHandle"])
            .expect("AudioHandle is in the standard opaque inventory");
        assert_eq!(spec.arity(), 0);
        assert_eq!(spec.producer(), "std.audio_handle");
        assert_eq!(spec.value_class(), RuntimeOpaqueValueClass::Plain);
        assert_eq!(spec.persistence(), RuntimeOpaquePersistence::SnapshotOnly);

        let owner = spec
            .monomorphic_owner()
            .expect("AudioHandle is monomorphic");
        assert_eq!(owner.admission(), RuntimeOpaqueTypeAdmission::ExactIdentity);
        let binding = crate::value::RuntimeBundleAssetBinding::try_new(
            crate::value::RuntimeBundleAssetContext::new(
                crate::task::GenerationId::new(1),
                crate::value::RuntimeBundleAssetArtifactDigest::try_from_bytes([1; 32])
                    .expect("artifact digest"),
            ),
            crate::value::RuntimeBundleAssetResourceId::try_new("asset.voice.opening")
                .expect("asset id"),
            crate::value::RuntimeAssetContentDigest::try_for_bytes(b"audio")
                .expect("content digest"),
        )
        .expect("bundle binding");
        let value = crate::value::RuntimeAudioHandleValue::from_binding(binding)
            .into_runtime_value()
            .expect("typed audio handle");
        let checked = RuntimeCheckedType::Opaque {
            owner: owner.clone(),
        };
        assert!(checked.accepts_value(&value));

        let image_owner = runtime_standard_opaque_type(&["ImageHandle"])
            .and_then(|spec| spec.monomorphic_owner())
            .expect("ImageHandle is a distinct standard opaque owner");
        assert!(!(RuntimeCheckedType::Opaque { owner: image_owner }).accepts_value(&value));
    }

    #[test]
    fn checked_structural_record_requires_field_coordinates_names_and_types() {
        let first = RuntimeRecordFieldId::try_from_zero_based_ordinal(0).expect("first field");
        let second = RuntimeRecordFieldId::try_from_zero_based_ordinal(1).expect("second field");
        let original = RuntimeCheckedType::try_record([
            (
                first,
                "z".to_owned(),
                RuntimeCheckedType::Signed(RuntimeSignedIntWidth::I64),
            ),
            (second, "a".to_owned(), RuntimeCheckedType::Bool),
        ])
        .expect("ordered checked record");
        let renamed = RuntimeCheckedType::try_record([
            (
                first,
                "left".to_owned(),
                RuntimeCheckedType::Signed(RuntimeSignedIntWidth::I64),
            ),
            (second, "right".to_owned(), RuntimeCheckedType::Bool),
        ])
        .expect("renamed checked record");
        assert_ne!(original, renamed);
        assert_ne!(
            original.semantic_identity_digest(),
            renamed.semantic_identity_digest()
        );

        let value = RuntimeValue::try_record(vec![
            ("z".to_owned(), RuntimeValue::i64(7)),
            ("a".to_owned(), RuntimeValue::Bool(true)),
        ])
        .expect("runtime record uses the same declaration coordinates");
        assert!(original.accepts_value(&value));
        assert!(!renamed.accepts_value(&value));
        let wrong_type = RuntimeValue::try_record(vec![
            ("z".to_owned(), RuntimeValue::u64(7)),
            ("a".to_owned(), RuntimeValue::Bool(true)),
        ])
        .expect("structurally valid record with the wrong first type");
        assert!(!original.accepts_value(&wrong_type));

        assert_eq!(
            RuntimeCheckedType::try_record([
                (first, "same".to_owned(), RuntimeCheckedType::Unit),
                (second, "same".to_owned(), RuntimeCheckedType::Bool),
            ]),
            Err(RuntimeCheckedRecordTypeError::DuplicateDiagnosticName)
        );
        assert_eq!(
            RuntimeCheckedType::try_record([(
                second,
                "misordered".to_owned(),
                RuntimeCheckedType::Unit,
            )]),
            Err(RuntimeCheckedRecordTypeError::InvalidFieldCoordinate {
                expected: first,
                actual: second,
            })
        );
    }

    #[test]
    fn checked_map_preserves_kind_and_admits_typed_entry_rows() {
        let ordered = RuntimeCheckedType::Map {
            kind: RuntimeMapKind::Ordered,
            key: Box::new(RuntimeCheckedType::String),
            value: Box::new(RuntimeCheckedType::Bool),
        };
        let sorted = RuntimeCheckedType::Map {
            kind: RuntimeMapKind::Sorted,
            key: Box::new(RuntimeCheckedType::String),
            value: Box::new(RuntimeCheckedType::Bool),
        };
        assert_ne!(
            ordered.semantic_identity_digest(),
            sorted.semantic_identity_digest()
        );

        let valid = runtime_sequence_values(vec![RuntimeValue::Tuple(vec![
            RuntimeValue::String("key".to_owned()),
            RuntimeValue::Bool(true),
        ])]);
        assert!(ordered.accepts_value(&valid));

        let wrong_value = runtime_sequence_values(vec![RuntimeValue::Tuple(vec![
            RuntimeValue::String("key".to_owned()),
            RuntimeValue::String("wrong type".to_owned()),
        ])]);
        assert!(!ordered.accepts_value(&wrong_value));

        let wrong_arity =
            runtime_sequence_values(vec![RuntimeValue::Tuple(vec![RuntimeValue::String(
                "key".to_owned(),
            )])]);
        assert!(!ordered.accepts_value(&wrong_arity));
    }

    #[test]
    fn opaque_type_admission_tags_are_stable_and_closed() {
        let cases = [
            (RuntimeOpaqueTypeAdmission::ExactIdentity, 0),
            (RuntimeOpaqueTypeAdmission::ProducerWide, 1),
        ];

        for (admission, tag) in cases {
            assert_eq!(admission.encoded(), tag);
            assert_eq!(
                RuntimeOpaqueTypeAdmission::from_encoded(tag),
                Some(admission)
            );
        }
        assert_eq!(RuntimeOpaqueTypeAdmission::from_encoded(2), None);
        assert_eq!(RuntimeOpaqueTypeAdmission::from_encoded(u8::MAX), None);
    }

    #[test]
    fn builtin_variant_owner_is_the_sole_tag_case_and_payload_authority() {
        let owners = [
            RuntimeBuiltinVariantIdentity::Option,
            RuntimeBuiltinVariantIdentity::Result,
            RuntimeBuiltinVariantIdentity::AgentResourceBody,
            RuntimeBuiltinVariantIdentity::AgentBinaryEncoding,
            RuntimeBuiltinVariantIdentity::CaptureFormat,
            RuntimeBuiltinVariantIdentity::CaptureKind,
            RuntimeBuiltinVariantIdentity::PointerButton,
        ];
        for owner in owners {
            assert_eq!(
                RuntimeBuiltinVariantIdentity::from_wire_tag(owner.semantic_tag()),
                Some(owner)
            );
            for (expected_ordinal, schema) in owner.cases().iter().copied().enumerate() {
                let (ordinal, resolved) = owner
                    .resolve_case(schema.identity())
                    .expect("schema identity resolves through its owner");
                assert_eq!(usize::try_from(ordinal).ok(), Some(expected_ordinal));
                assert_eq!(resolved, schema);
                assert_eq!(owner.case_at(ordinal), Some(schema));

                let payload = schema.has_payload().then_some(RuntimeValue::Unit);
                let value = RuntimeValue::try_builtin_variant(schema.identity(), payload)
                    .expect("schema-derived payload cardinality is accepted");
                assert_eq!(
                    value.builtin_variant_case().map(|(case, _)| case),
                    Some(schema.identity())
                );
            }
        }
        assert_eq!(RuntimeBuiltinVariantIdentity::from_wire_tag(u8::MAX), None);
        assert_eq!(
            RuntimeValue::try_builtin_variant(
                RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyJson,
                None,
            ),
            Err(RuntimeBuiltinVariantValueError::InvalidPayloadPresence)
        );
        assert_eq!(
            RuntimeValue::try_builtin_variant(
                RuntimeBuiltinVariantCaseIdentity::AgentBinaryEncodingBase64,
                Some(RuntimeValue::Unit),
            ),
            Err(RuntimeBuiltinVariantValueError::InvalidPayloadPresence)
        );
    }

    #[test]
    fn builtin_checked_types_require_the_same_tuple_abi_as_runtime_values() {
        for owner in [
            RuntimeBuiltinVariantIdentity::Option,
            RuntimeBuiltinVariantIdentity::Result,
            RuntimeBuiltinVariantIdentity::AgentResourceBody,
            RuntimeBuiltinVariantIdentity::AgentBinaryEncoding,
            RuntimeBuiltinVariantIdentity::CaptureFormat,
            RuntimeBuiltinVariantIdentity::CaptureKind,
            RuntimeBuiltinVariantIdentity::PointerButton,
        ] {
            let payloads: Vec<_> = owner
                .cases()
                .iter()
                .map(|case| {
                    case.has_payload()
                        .then(|| RuntimeCheckedType::Tuple(vec![RuntimeCheckedType::Unit]))
                })
                .collect();
            let checked = RuntimeCheckedType::try_builtin_variant(owner, payloads.clone()).unwrap();
            for (index, case) in owner.cases().iter().enumerate() {
                let value = RuntimeValue::try_builtin_variant(
                    case.identity(),
                    case.has_payload().then_some(RuntimeValue::Unit),
                )
                .unwrap();
                assert!(checked.accepts_value(&value));
                if case.has_payload() {
                    for malformed in [
                        RuntimeCheckedType::Unit,
                        RuntimeCheckedType::Tuple(vec![]),
                        RuntimeCheckedType::Tuple(vec![RuntimeCheckedType::Unit; 2]),
                    ] {
                        let mut candidate = payloads.clone();
                        candidate[index] = Some(malformed);
                        assert_eq!(
                            RuntimeCheckedType::try_builtin_variant(owner, candidate),
                            Err(RuntimeBuiltinVariantTypeError::InvalidPayloadTuple {
                                case: case.identity(),
                            })
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn resource_body_builtin_rejects_unknown_wrong_and_flat_legacy_shapes() {
        let owner = RuntimeBuiltinVariantIdentity::AgentResourceBody;
        let cases = owner
            .cases()
            .iter()
            .copied()
            .map(|schema| RuntimeCheckedVariantCase {
                name: schema.name().to_owned(),
                payload: Some(Box::new(RuntimeCheckedType::Tuple(vec![
                    match schema.identity() {
                        RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyJson => {
                            RuntimeCheckedType::AgentValue
                        }
                        RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyText => {
                            RuntimeCheckedType::String
                        }
                        RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyBytesBase64 => {
                            RuntimeCheckedType::Agent(
                                crate::plan::RuntimeAgentTypeProjection::BinaryResourceBody,
                            )
                        }
                        _ => {
                            unreachable!("resource body schema only contains resource body cases")
                        }
                    },
                ]))),
            })
            .collect();
        let expected = RuntimeCheckedType::Variant {
            owner: RuntimeVariantIdentity::Builtin(owner),
            arguments: Vec::new(),
            cases,
        };
        let json = RuntimeValue::try_builtin_variant(
            RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyJson,
            Some(
                RuntimeValue::try_record(vec![("enabled".to_owned(), RuntimeValue::Bool(true))])
                    .expect("fixture JSON object"),
            ),
        )
        .expect("typed Json resource body");
        assert!(expected.accepts_value(&json));

        let (_, json_schema) = owner
            .resolve_case(RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyJson)
            .expect("Json case");
        let mut wrong_name = serde_json::to_value(&json).unwrap();
        wrong_name["Variant"]["name"] = serde_json::json!("not-a-resource-case");
        assert!(serde_json::from_value::<RuntimeValue>(wrong_name.clone()).is_err());
        wrong_name["Variant"]["payload"] = serde_json::to_value(RuntimeValue::Unit).unwrap();
        assert!(serde_json::from_value::<RuntimeValue>(wrong_name).is_err());
        assert!(owner.case_at(u32::MAX).is_none());
        assert_eq!(
            json_schema.identity(),
            RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyJson
        );

        let flat_legacy = RuntimeValue::try_record(vec![
            ("kind".to_owned(), RuntimeValue::String("json".to_owned())),
            ("json".to_owned(), RuntimeValue::String("{}".to_owned())),
            ("text".to_owned(), RuntimeValue::String(String::new())),
            ("base64".to_owned(), RuntimeValue::String(String::new())),
        ])
        .expect("legacy flat record is structurally a record");
        assert!(!expected.accepts_value(&flat_legacy));

        let wrong_payload = RuntimeValue::try_builtin_variant(
            RuntimeBuiltinVariantCaseIdentity::AgentResourceBodyText,
            Some(RuntimeValue::Bool(false)),
        )
        .expect("case cardinality is valid before type checking");
        assert!(!expected.accepts_value(&wrong_payload));
    }

    #[test]
    fn checked_runtime_type_recursively_validates_host_payload_shape() {
        let owner = RuntimeOpaqueTypeOwner::exact(
            RuntimeOpaqueTypeProducerId::try_new("fixture.host-result")
                .expect("fixture producer identity"),
            identity(90),
        );
        let expected = RuntimeCheckedType::Result {
            ok: Box::new(RuntimeCheckedType::Tuple(vec![
                RuntimeCheckedType::Sequence(Box::new(RuntimeCheckedType::Option(Box::new(
                    RuntimeCheckedType::Unsigned(RuntimeUnsignedIntWidth::U16),
                )))),
                RuntimeCheckedType::Opaque {
                    owner: owner.clone(),
                },
            ])),
            error: Box::new(RuntimeCheckedType::String),
        };
        let opaque = owner
            .try_wrap(RuntimeValue::String("opaque".to_owned()))
            .expect("exact owner wraps its payload");
        let valid = RuntimeValue::result_ok(RuntimeValue::Tuple(vec![
            runtime_sequence_values(vec![
                RuntimeValue::option_some(RuntimeValue::u16(7)),
                RuntimeValue::option_none(),
            ]),
            opaque,
        ]));

        assert!(expected.accepts_value(&valid));
        assert!(
            expected.accepts_value(&RuntimeValue::result_err(RuntimeValue::String(
                "domain error".to_owned(),
            )))
        );

        let wrong_nested_width = RuntimeValue::result_ok(RuntimeValue::Tuple(vec![
            runtime_sequence_values(vec![RuntimeValue::option_some(RuntimeValue::u32(7))]),
            owner
                .try_wrap(RuntimeValue::String("opaque".to_owned()))
                .expect("exact owner wraps its payload"),
        ]));
        assert!(!expected.accepts_value(&wrong_nested_width));

        let foreign_owner = RuntimeOpaqueTypeOwner::exact(
            RuntimeOpaqueTypeProducerId::try_new("fixture.foreign-result")
                .expect("foreign fixture producer identity"),
            identity(90),
        );
        let wrong_opaque_owner = RuntimeValue::result_ok(RuntimeValue::Tuple(vec![
            runtime_sequence_values(vec![RuntimeValue::option_none()]),
            foreign_owner
                .try_wrap(RuntimeValue::String("opaque".to_owned()))
                .expect("foreign owner wraps its own payload"),
        ]));
        assert!(!expected.accepts_value(&wrong_opaque_owner));
        assert!(!expected.accepts_value(&RuntimeValue::result_err(RuntimeValue::Bool(false))));
    }

    #[test]
    fn tuple_pattern_binds_plan_local_ids() {
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(identity(1), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(identity(2), RuntimePlanTypeProjection::String),
                    RuntimePlanTypeSeed::new(
                        identity(3),
                        RuntimePlanTypeProjection::Tuple(
                            vec![identity(1), identity(2)].into_boxed_slice(),
                        ),
                    ),
                ],
                [
                    RuntimeLocalDeclarationSeed::new(
                        manual_local_source(
                            "arcweft-core.fixture.pattern.tuple_pattern_binds_plan_local_ids.binding_a",
                        ),
                        identity(1),
                    ),
                    RuntimeLocalDeclarationSeed::new(
                        manual_local_source(
                            "arcweft-core.fixture.pattern.tuple_pattern_binds_plan_local_ids.binding_b",
                        ),
                        identity(2),
                    ),
                ],
            )
            .expect("typed tuple admission");
        let pattern = builder
            .lower_pattern_seed_for_test(RuntimePatternSeed::new(
                identity(3),
                RuntimePatternSeedKind::Tuple(
                    vec![
                        RuntimePatternSeed::new(
                            identity(1),
                            RuntimePatternSeedKind::Bind {
                                mutable: false,
                                local: admitted.local_ids()[0].clone(),
                            },
                        ),
                        RuntimePatternSeed::new(
                            identity(2),
                            RuntimePatternSeedKind::Typed {
                                local: admitted.local_ids()[1].clone(),
                            },
                        ),
                    ]
                    .into_boxed_slice(),
                ),
            ))
            .expect("admitted tuple pattern");
        let RuntimePatternKind::Tuple(items) = pattern.kind() else {
            panic!("tuple pattern kind");
        };
        let RuntimePatternKind::Bind {
            binding: bool_binding,
            ..
        } = items[0].kind()
        else {
            panic!("bool binding kind");
        };
        let RuntimePatternKind::Typed {
            binding: string_binding,
        } = items[1].kind()
        else {
            panic!("string binding kind");
        };
        let bool_local = bool_binding.local();
        let string_local = string_binding.local();
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let plan = builder.finish().expect("plan");
        let value = RuntimeValue::Tuple(vec![
            RuntimeValue::Bool(true),
            RuntimeValue::String("ready".to_owned()),
        ]);

        assert_eq!(
            match_runtime_pattern(&plan, &pattern, &value),
            Ok(Some(vec![
                RuntimeLocalBinding {
                    local: bool_local,
                    value: RuntimeValue::Bool(true),
                },
                RuntimeLocalBinding {
                    local: string_local,
                    value: RuntimeValue::String("ready".to_owned()),
                },
            ]))
        );
    }

    #[test]
    fn guard_copies_only_selected_scalar_sibling_before_moving_affine_tuple() {
        let integer = RuntimeCheckedType::Signed(crate::value::RuntimeSignedIntWidth::I64)
            .semantic_identity_digest();
        let affine_need = || {
            crate::tests::reusable_need_with_outcome(
                "need.guard.affine",
                crate::task::TaskOutcomeContract::new(RuntimeCheckedType::Signed(
                    crate::value::RuntimeSignedIntWidth::I64,
                )),
            )
        };
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(identity(101), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(
                        integer,
                        RuntimePlanTypeProjection::Signed(crate::value::RuntimeSignedIntWidth::I64),
                    ),
                    RuntimePlanTypeSeed::new(
                        identity(103),
                        RuntimePlanTypeProjection::Need(integer),
                    ),
                    RuntimePlanTypeSeed::new(
                        identity(104),
                        RuntimePlanTypeProjection::Tuple(
                            vec![integer, identity(103)].into_boxed_slice(),
                        ),
                    ),
                ],
                [
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.guard_copies_only_selected_scalar_sibling_before_moving_affine_tuple.binding_a"), integer),
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.guard_copies_only_selected_scalar_sibling_before_moving_affine_tuple.binding_b"), identity(103)),
                ],
            )
            .expect("typed affine tuple admission");
        let pattern = builder
            .lower_pattern_seed_for_test(RuntimePatternSeed::new(
                identity(104),
                RuntimePatternSeedKind::Tuple(
                    vec![
                        RuntimePatternSeed::new(
                            integer,
                            RuntimePatternSeedKind::Bind {
                                mutable: false,
                                local: admitted.local_ids()[0].clone(),
                            },
                        ),
                        RuntimePatternSeed::new(
                            identity(103),
                            RuntimePatternSeedKind::Bind {
                                mutable: false,
                                local: admitted.local_ids()[1].clone(),
                            },
                        ),
                    ]
                    .into_boxed_slice(),
                ),
            ))
            .expect("affine tuple pattern");
        let RuntimePatternKind::Tuple(items) = pattern.kind() else {
            panic!("tuple pattern kind")
        };
        let RuntimePatternKind::Bind {
            binding: scalar, ..
        } = items[0].kind()
        else {
            panic!("scalar binding")
        };
        let RuntimePatternKind::Bind {
            binding: affine, ..
        } = items[1].kind()
        else {
            panic!("affine binding")
        };
        let scalar = scalar.local();
        let affine = affine.local();
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let plan = builder.finish().expect("plan");
        let value = RuntimeValue::Tuple(vec![
            RuntimeValue::i64(7),
            RuntimeValue::NeedHandle(affine_need()),
        ]);
        let guard = crate::value::RuntimeExpr::from_admitted_parts_with_guard_copy_locals(
            admitted.type_ids()[0],
            crate::value::RuntimeExprKind::Local(
                crate::value::RuntimeLocalRead::from_admitted_parts(
                    scalar,
                    RuntimeLocalReadMode::Copy,
                ),
            ),
            vec![scalar],
        );
        let projected =
            prepare_runtime_pattern_guard_bindings(&plan, &pattern, &value, &guard, None)
                .expect("Copy scalar guard projection");
        assert_eq!(
            projected,
            vec![RuntimeLocalBinding {
                local: scalar,
                value: RuntimeValue::i64(7),
            }]
        );
        let bindings = match_runtime_pattern_owned(&plan, &pattern, value, None)
            .expect("owned tuple bind")
            .expect("matched tuple");
        assert!(bindings.iter().any(|binding| {
            binding.local == affine && binding.value == RuntimeValue::NeedHandle(affine_need())
        }));

        let affine_guard = crate::value::RuntimeExpr::from_admitted_parts_with_guard_copy_locals(
            admitted.type_ids()[0],
            crate::value::RuntimeExprKind::Local(
                crate::value::RuntimeLocalRead::from_admitted_parts(
                    affine,
                    RuntimeLocalReadMode::Copy,
                ),
            ),
            vec![affine],
        );
        let value = RuntimeValue::Tuple(vec![
            RuntimeValue::i64(7),
            RuntimeValue::NeedHandle(affine_need()),
        ]);
        assert!(matches!(
            prepare_runtime_pattern_guard_bindings(&plan, &pattern, &value, &affine_guard, None),
            Err(RuntimeEvalError::Pattern(
                RuntimePatternMatchError::AffineGuardBinding { local }
            )) if local == affine
        ));
    }

    #[test]
    fn structural_record_pattern_binds_selected_field_and_complete_rest_record() {
        let mut builder = RuntimePlanBuilder::new();
        let admission = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(
                        identity(1),
                        RuntimePlanTypeProjection::Record(
                            vec![
                                RuntimePlanRecordField::new("first", identity(2)),
                                RuntimePlanRecordField::new("second", identity(3)),
                            ]
                            .into_boxed_slice(),
                        ),
                    ),
                    RuntimePlanTypeSeed::new(identity(2), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(identity(3), RuntimePlanTypeProjection::String),
                ],
                [
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.structural_record_pattern_binds_selected_field_and_complete_rest_record.binding_a"), identity(2)),
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.structural_record_pattern_binds_selected_field_and_complete_rest_record.binding_b"), identity(1)),
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.structural_record_pattern_binds_selected_field_and_complete_rest_record.binding_c"), identity(3)),
                ],
            )
            .expect("structural record type graph");
        let selected_seed = admission.local_ids()[0].clone();
        let rest_seed = admission.local_ids()[1].clone();
        let pattern = builder
            .lower_pattern_seed_for_test(RuntimePatternSeed::new(
                identity(1),
                RuntimePatternSeedKind::Record {
                    fields: Box::new([RuntimeRecordPatternFieldSeed::new(
                        RuntimeRecordFieldSeedId::from_zero_based(0),
                        RuntimePatternSeed::new(
                            identity(2),
                            RuntimePatternSeedKind::Bind {
                                mutable: false,
                                local: selected_seed,
                            },
                        ),
                    )]),
                    rest: RuntimePatternRestSeed::Bind(rest_seed),
                },
            ))
            .expect("structural record pattern admission");
        let RuntimePatternKind::Record { fields, rest } = pattern.kind() else {
            panic!("structural record pattern kind");
        };
        let RuntimePatternKind::Bind { binding, .. } = fields[0].pattern().kind() else {
            panic!("structural record selected-field binding");
        };
        let selected_local = binding.local();
        let rest_local = rest
            .binding()
            .expect("structural record rest binding")
            .local();
        builder
            .declare_test_input_locals(admission.local_ids())
            .unwrap();
        let plan = builder.finish().expect("structural record plan");
        let value = RuntimeValue::try_record(vec![
            ("first".to_owned(), RuntimeValue::Bool(true)),
            ("second".to_owned(), RuntimeValue::String("tail".to_owned())),
        ])
        .expect("structural record value");

        assert_eq!(
            match_runtime_pattern(&plan, &pattern, &value),
            Ok(Some(vec![
                RuntimeLocalBinding {
                    local: selected_local,
                    value: RuntimeValue::Bool(true),
                },
                RuntimeLocalBinding {
                    local: rest_local,
                    value,
                },
            ]))
        );
    }

    #[test]
    fn structural_record_pattern_rejects_unknown_field_and_wrong_field_type() {
        let mut builder = RuntimePlanBuilder::new();
        let admission = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(
                        identity(1),
                        RuntimePlanTypeProjection::Record(
                            vec![RuntimePlanRecordField::new("value", identity(2))]
                                .into_boxed_slice(),
                        ),
                    ),
                    RuntimePlanTypeSeed::new(identity(2), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(identity(3), RuntimePlanTypeProjection::String),
                ],
                [
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.structural_record_pattern_rejects_unknown_field_and_wrong_field_type.binding_a"), identity(2)),
                    RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.structural_record_pattern_rejects_unknown_field_and_wrong_field_type.binding_b"), identity(3)),
                ],
            )
            .expect("structural record type graph");

        let unknown_field = builder.lower_pattern_seed_for_test(RuntimePatternSeed::new(
            identity(1),
            RuntimePatternSeedKind::Record {
                fields: Box::new([RuntimeRecordPatternFieldSeed::new(
                    RuntimeRecordFieldSeedId::from_zero_based(1),
                    RuntimePatternSeed::new(identity(2), RuntimePatternSeedKind::Discard),
                )]),
                rest: RuntimePatternRestSeed::Ignore,
            },
        ));
        assert!(matches!(
            unknown_field,
            Err(RuntimePlanBuildError::UnknownRecordField { .. })
        ));

        let wrong_type = builder.lower_pattern_seed_for_test(RuntimePatternSeed::new(
            identity(1),
            RuntimePatternSeedKind::Record {
                fields: Box::new([RuntimeRecordPatternFieldSeed::new(
                    RuntimeRecordFieldSeedId::from_zero_based(0),
                    RuntimePatternSeed::new(
                        identity(3),
                        RuntimePatternSeedKind::Bind {
                            mutable: false,
                            local: admission.local_ids()[1].clone(),
                        },
                    ),
                )]),
                rest: RuntimePatternRestSeed::Ignore,
            },
        ));
        assert!(matches!(
            wrong_type,
            Err(RuntimePlanBuildError::TypeMismatch {
                context: "record pattern field",
                ..
            })
        ));
    }

    #[test]
    fn nominal_record_pattern_uses_owner_domain_and_field_id() {
        use crate::entry::{
            RuntimeNominalSchemaBody, RuntimeNominalSchemaDefinition, RuntimeNominalSchemaField,
            RuntimeNominalSchemaGraph, RuntimeNominalSchemaIdentity, RuntimeSchemaLimits,
            RuntimeTypeSchema,
        };
        let nominal = RuntimeNominalTypeId::try_new("game.Pair").unwrap();
        let schema = RuntimeNominalSchemaGraph::try_new(
            vec![RuntimeNominalSchemaDefinition::new(
                crate::entry::RuntimeNominalDeclarationId::from_bytes(
                    *(RuntimeNominalSchemaIdentity::new(nominal.clone(), identity(1)))
                        .semantic_identity()
                        .as_bytes(),
                ),
                RuntimeNominalSchemaIdentity::new(nominal.clone(), identity(1)),
                vec![],
                RuntimeNominalSchemaBody::Record {
                    shape: crate::entry::RuntimeNominalRecordShape::Record,
                    fields: [
                        ("alpha", RuntimeTypeSchema::Bool),
                        ("zeta", RuntimeTypeSchema::String),
                    ]
                    .into_iter()
                    .enumerate()
                    .map(|(ordinal, (name, schema))| {
                        RuntimeNominalSchemaField::new(
                            RuntimeRecordFieldId::try_from_zero_based_ordinal(ordinal).unwrap(),
                            Some(name.to_owned()),
                            schema,
                        )
                    })
                    .collect(),
                },
            )],
            RuntimeSchemaLimits::engine_default(),
        )
        .unwrap();
        let layout = schema.try_layout_hash(identity(1)).unwrap();
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_semantic_batch(
                [
                    RuntimePlanTypeSeed::new(
                        identity(1),
                        RuntimePlanTypeProjection::Nominal {
                            nominal: nominal.clone(),
                            layout,
                            arguments: Box::new([]),
                        },
                    ),
                    RuntimePlanTypeSeed::new(identity(2), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(identity(3), RuntimePlanTypeProjection::String),
                ],
                [RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.nominal_record_pattern_uses_owner_domain_and_field_id.binding_a"), identity(2))],
                [RuntimeNominalRecordDomainSeed::new(
                    identity(1),
                    crate::entry::RuntimeNominalRecordShape::Record,
                    [
                        RuntimeNominalRecordDomainFieldSeed::new(
                            crate::value::RuntimeRecordFieldId::try_from_zero_based_ordinal(0)
                                .unwrap(),
                            Some("alpha".to_owned()),
                            identity(2),
                        ),
                        RuntimeNominalRecordDomainFieldSeed::new(
                            crate::value::RuntimeRecordFieldId::try_from_zero_based_ordinal(1)
                                .unwrap(),
                            Some("zeta".to_owned()),
                            identity(3),
                        ),
                    ],
                )],
                [],
                &schema,
            )
            .expect("record admission");
        let pattern = builder
            .lower_pattern_seed_for_test(RuntimePatternSeed::new(
                identity(1),
                RuntimePatternSeedKind::Record {
                    fields: Box::new([RuntimeRecordPatternFieldSeed::new(
                        RuntimeRecordFieldSeedId::from_zero_based(0),
                        RuntimePatternSeed::new(
                            identity(2),
                            RuntimePatternSeedKind::Bind {
                                mutable: false,
                                local: admitted.local_ids()[0].clone(),
                            },
                        ),
                    )]),
                    rest: crate::plan::RuntimePatternRestSeed::Ignore,
                },
            ))
            .expect("admitted record pattern");
        let RuntimePatternKind::Record { fields, .. } = pattern.kind() else {
            panic!("record pattern kind");
        };
        let RuntimePatternKind::Bind { binding, .. } = fields[0].pattern().kind() else {
            panic!("record binding kind");
        };
        let local = binding.local();
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let plan = builder.finish().expect("plan");
        let value = RuntimeValue::NominalRecord(RuntimeNominalRecordValue::new(
            nominal,
            identity(1),
            layout,
            vec![
                RuntimeValue::Bool(true),
                RuntimeValue::String("tail".to_owned()),
            ],
        ));

        assert_eq!(
            match_runtime_pattern(&plan, &pattern, &value),
            Ok(Some(vec![RuntimeLocalBinding {
                local,
                value: RuntimeValue::Bool(true),
            }]))
        );
    }

    #[test]
    fn binding_local_type_must_equal_the_pattern_node_type() {
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(identity(1), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(identity(2), RuntimePlanTypeProjection::String),
                ],
                [RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.pattern.binding_local_type_must_equal_the_pattern_node_type.binding_a"), identity(2))],
            )
            .expect("local admission");
        let result = builder.lower_pattern_seed_for_test(RuntimePatternSeed::new(
            identity(1),
            RuntimePatternSeedKind::Bind {
                mutable: false,
                local: admitted.local_ids()[0].clone(),
            },
        ));
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let plan = builder.finish().expect("plan");
        let bool_ty = plan
            .type_table()
            .id_for_semantic(identity(1))
            .expect("bool type");
        let string_ty = plan
            .type_table()
            .id_for_semantic(identity(2))
            .expect("string type");

        assert_eq!(
            result,
            Err(RuntimePlanBuildError::TypeMismatch {
                context: "pattern binding local",
                expected: bool_ty,
                actual: string_ty,
            })
        );
    }
}

#[cfg(test)]
fn manual_local_source(declaration: &str) -> crate::plan::RuntimeLocalDeclarationSource {
    // This fixture declares a semantic binding name independent of its value,
    // type, source offset, and builder-issued local ordinal.
    let mut identity = blake3::Hasher::new();
    identity.update(b"arcweft.manual-fixture-binding.v1\0");
    identity.update(declaration.as_bytes());
    crate::plan::RuntimeLocalDeclarationSource::Binding {
        identity: *identity.finalize().as_bytes(),
        declaration: crate::plan::RuntimeLocalBindingDeclaration::new(
            crate::plan::RuntimeLocalBindingKind::PatternBinding,
            false,
            crate::plan::RuntimeLocalBindingStorage::Derived,
        ),
    }
}
