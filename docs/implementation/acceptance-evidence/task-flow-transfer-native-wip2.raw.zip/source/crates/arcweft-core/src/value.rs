use crate::entry::{
    FlowParameterCoordinate, RuntimeCallableId, RuntimeIdentityError, RuntimeSchemaError,
    RuntimeValueDigest,
};
use crate::math::{DenseMatrixF32, DenseMatrixF64, DenseTensorF32, DenseTensorF64};
use crate::pattern::{RuntimeBuiltinVariantCaseIdentity, RuntimePattern, RuntimeVariantIdentity};
use crate::plan::{
    RuntimeLineId, RuntimePlanValueTypeError, RuntimePureHelperId, RuntimePureInputType,
    RuntimePureOutputType, RuntimeReceiverMode, RuntimeTraitMethodId,
};
use crate::runtime_id::{RuntimeFunctionSiteId, RuntimeLocalDeclarationId, RuntimePlanTypeId};
use crate::scope::RuntimeScopeIdentity;
use crate::time::LogicalDuration;
use arcweft_id::{DeclarationIdentityFamily, PublicId, PublicIdFamilyError};
pub use arcweft_need::Progress;
use serde::{Deserialize, Serialize};
use std::fmt;
use std::sync::Arc;
use thiserror::Error;

mod agent;
pub(crate) use agent::{
    RuntimeAgentSignatureError, RuntimeAgentTypeContext, RuntimeAgentTypeOperand,
};
mod asset_handle;
pub(crate) use asset_handle::standard_asset_opaque_payload_is_valid;
mod arc_error;
pub use arc_error::{
    RUNTIME_ARC_ERROR_VALUE_VERSION, RuntimeArcError, RuntimeArcErrorContextPending,
    RuntimeArcErrorDataEntry, RuntimeArcErrorFrame, RuntimeArcErrorKind,
    RuntimeArcErrorNativeBacktrace, RuntimeArcErrorSource, RuntimeArcErrorStateHash,
    RuntimeArcErrorTrace, RuntimeArcErrorValueError,
};
pub(crate) use arc_error::{RuntimeArcErrorContextKind, RuntimeArcErrorContextStart};
mod awbc_save;
pub use awbc_save::RuntimeRetainedValueAdmission;
pub(crate) use awbc_save::RuntimeRetainedValueAdmissionState;
pub(crate) use awbc_save::RuntimeValueRestoreContext;
mod callable;
mod canonical_transform;
pub use canonical_transform::{RuntimeValueMergeError, RuntimeValueNormalizationError};
mod character_dialogue;
mod collection;
mod string;
pub use string::{RuntimeStringOperation, RuntimeStringResultKind};
mod color;
mod quantity;
pub(crate) use collection::evaluate_collection_intrinsic;
pub(crate) use ownership::evaluate_ownership_intrinsic;
pub(crate) use quantity::quantity_payload_is_valid;
pub use quantity::{RuntimeQuantity, RuntimeQuantityKind};
mod data_shape;
mod dense_numeric;
mod entity_identity;
mod entity_type;
pub(crate) use entity_identity::RuntimeEntityIdentityVisitor;
pub use entity_type::{RuntimeEntityReferenceType, RuntimeProjectEntityReferenceType};
mod env;
mod expression_literals;
mod expression_locals;
mod expression_semantic;
mod external_callable;
pub use external_callable::{
    RuntimeExternalCallOperand, RuntimeExternalCallOperandError, RuntimeExternalCallOperandOrder,
    RuntimeExternalCallOperandProjection, RuntimeExternalCallable,
    RuntimeExternalCallableDeclaration, RuntimeExternalCallableExport,
    RuntimeExternalCallableProvider, StandardEnvironmentId,
};
pub(crate) mod expression_tree;
mod float_storage_serde;
mod format_content;
mod imported_entity;
pub(crate) use imported_entity::ImportedProjectTarget;
mod integer;
pub use imported_entity::{
    RuntimeImportedProjectEntityError, RuntimeImportedProjectEntityReference,
};
mod borrowed;
mod literal_semantic;
mod nesting;
mod nominal_record;
mod nominal_record_expr;
mod opaque;
mod option_value;
mod plain_construction;
pub use plain_construction::RuntimePlainValueRecipe;
pub mod ownership;
mod place_displacement;
mod place_storage;
mod range;
mod record;
mod record_id;
mod reduction;
mod runtime_value_visit;
mod sequence_constructors;
mod sequence_impls;
mod shape;
mod storage;
pub(crate) use storage::{InertRuntimeValueStorage, RuntimeStoredValue};
mod view;
pub use borrowed::{
    RuntimeBorrowedOpaque, RuntimeBorrowedSequence, RuntimeBorrowedTuple, RuntimeBorrowedValue,
    RuntimeBorrowedValueVisitError,
};
pub use view::RuntimeScalarView;
pub(crate) use view::runtime_value_views_equal;
mod virtual_path;

pub(crate) use view::{
    LiveRuntimeValueView, RuntimeAgentKind, RuntimeAgentView, RuntimeCallableView,
    RuntimeCommandListView, RuntimeCommandView, RuntimeDenseNumericView, RuntimeIteratorKind,
    RuntimeIteratorView, RuntimeNeedView, RuntimeNominalRecordView, RuntimeOpaqueView,
    RuntimePredicateKind, RuntimePredicateListView, RuntimePredicateView, RuntimeRecordView,
    RuntimeReductionView, RuntimeSequenceView, RuntimeTupleView, RuntimeValueSource,
    RuntimeValueView, RuntimeVariantView,
};

pub(crate) mod runtime_public_id {
    use arcweft_id::PublicId;
    use serde::{Deserialize, Deserializer, Serializer};

    pub(crate) fn serialize<S>(value: &PublicId, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.serialize_str(value.as_str())
    }

    pub(crate) fn deserialize<'de, D>(deserializer: D) -> Result<PublicId, D::Error>
    where
        D: Deserializer<'de>,
    {
        PublicId::try_new_engine_owned(String::deserialize(deserializer)?)
            .map_err(serde::de::Error::custom)
    }
}

pub use agent::{
    AgentPredicateOperands, AgentPredicateOperandsError, RuntimeAgentAction,
    RuntimeAgentActionDispatch, RuntimeAgentActionTarget, RuntimeAgentCaptureTarget,
    RuntimeAgentCompareOp, RuntimeAgentConstructionError, RuntimeAgentConstructor,
    RuntimeAgentExpr, RuntimeAgentField, RuntimeAgentFieldOwner, RuntimeAgentFieldResult,
    RuntimeAgentFieldValue, RuntimeAgentPath, RuntimeAgentPathExpr, RuntimeAgentPredicate,
    RuntimeAgentPredicateExpr, RuntimeAgentProbe, RuntimeAgentProbeExpr, RuntimeAgentTargetExpr,
    RuntimeAgentValue,
};
pub(crate) use arc_error::RuntimeArcErrorContextValueError;
pub use asset_handle::{
    RUNTIME_BUNDLE_ASSET_VALUE_VERSION, RuntimeAssetContentDigest, RuntimeAssetErrorValue,
    RuntimeAudioHandleValue, RuntimeBundleAssetArtifactDigest, RuntimeBundleAssetBinding,
    RuntimeBundleAssetContext, RuntimeBundleAssetFailure, RuntimeBundleAssetFailureReason,
    RuntimeBundleAssetOpaqueRole, RuntimeBundleAssetResourceId, RuntimeBundleAssetValueError,
    RuntimeImageHandleValue, RuntimeVoiceErrorValue, runtime_bundle_asset_opaque_role,
};
pub(crate) use awbc_save::source_codec::{
    PreparedRuntimeLiteralEncoding, RuntimeLiteralSourceError, RuntimeLiteralSourceLimits,
};
pub use awbc_save::{
    AwbcRuntimeCallableSnapshot, AwbcRuntimeValueSnapshot, AwbcRuntimeValueSnapshotError,
};
pub(crate) use callable::{
    RuntimeCallableApplication, RuntimeCallableBodyReference, RuntimeCallableInvocation,
    RuntimeCallableMaterializedArgument, RuntimeCallableZeroArgInvocationProof,
};
pub use callable::{
    RuntimeCallablePendingGroup, RuntimeCallablePendingSnapshot, RuntimeCallableValue,
    RuntimeCallableValueError, RuntimeInputOrder, RuntimeInputOrderError,
};
pub use character_dialogue::RuntimeCharacterDialogueProducerId;
pub use color::RuntimeColor;
pub use data_shape::{RuntimeDataShape, RuntimeDataShapeError};
pub use expression_locals::RuntimeExprFreeLocalError;
pub use expression_tree::{
    RuntimeExpressionChildRole, RuntimeExpressionChildren, RuntimeExpressionNode,
};
pub(crate) use format_content::project_display_layout;
pub use format_content::{
    RuntimeFormatAttemptError, RuntimeFormatContext, RuntimeFormatDataIdentity,
    RuntimeFormatPrimaryKind, finish_format_content_attempt, project_display_context,
    project_display_result,
};
pub use integer::{RuntimeInt, RuntimeSignedIntWidth, RuntimeUInt, RuntimeUnsignedIntWidth};
pub use nesting::{MAX_RUNTIME_VALUE_NESTING_DEPTH, RuntimeValueNestingError};
pub use nominal_record::{
    RuntimeNominalRecordError, RuntimeNominalRecordLayout, RuntimeNominalRecordLayoutError,
    RuntimeNominalRecordLayoutField, RuntimeNominalRecordValue,
};
pub use nominal_record_expr::{RuntimeNominalRecordExpr, RuntimeNominalRecordFieldExpr};
pub use opaque::{
    RUNTIME_DIALOGUE_CONTENT_VALUE_VERSION, RuntimeDialogueActionValue,
    RuntimeDialogueAdvanceAction, RuntimeDialogueContentBinding,
    RuntimeDialogueContentEffectBinding, RuntimeDialogueContentValue,
    RuntimeDialogueContentValueError, RuntimeDialogueFormattedFailureSelection,
    RuntimeDialogueFormattedOutcome, RuntimeDialogueFormattedSuccess,
    RuntimeDialogueFormattedValue, RuntimeDialogueFormattedValueError, RuntimeDialogueOpaqueRole,
    RuntimeDialoguePlainTextContextTemplateProof, RuntimeDialoguePlainTextContextTemplateRef,
    RuntimeDialogueValueError, RuntimeDialogueViewField, RuntimeDialogueViewValue,
    RuntimeHandleKind, RuntimeInlineTextValue, RuntimeInlineTextValueError,
    RuntimeOpaquePersistence, RuntimeOpaqueValue, RuntimeOpaqueValueClass, RuntimeOpaqueValueError,
};
pub use option_value::{
    evaluate_core_option_is_some_intrinsic, evaluate_core_option_unwrap_intrinsic,
};
pub use place_displacement::{
    RuntimeAssignment, RuntimeDisplacedField, RuntimePlaceDisplacement, RuntimePlaceInitialization,
};
pub(crate) use place_storage::RecordHeader as RuntimePlaceRecordHeader;
pub use place_storage::RuntimePlaceStorage;
pub use range::{
    RuntimeIterator, RuntimeIteratorWitness, RuntimeIteratorWitnessError, RuntimeRange,
    RuntimeRangeIterator,
};
pub use record::{RuntimeFieldValue, RuntimeRecordAdmissionError, RuntimeRecordValue};
pub use record_id::{RuntimeRecordFieldId, RuntimeRecordFieldIdError};
pub use reduction::{
    RuntimeCommand, RuntimeReductionProducer, RuntimeReductionValue, RuntimeReductionValueError,
};
pub use runtime_value_visit::visit_runtime_value_graph;
pub use sequence_constructors::{
    runtime_sequence_dense_bool, runtime_sequence_dense_bytes, runtime_sequence_dense_chars,
    runtime_sequence_dense_durations, runtime_sequence_dense_entity_refs,
    runtime_sequence_dense_f32, runtime_sequence_dense_f64, runtime_sequence_dense_i8,
    runtime_sequence_dense_i16, runtime_sequence_dense_i32, runtime_sequence_dense_i64,
    runtime_sequence_dense_i128, runtime_sequence_dense_isize, runtime_sequence_dense_strings,
    runtime_sequence_dense_u8, runtime_sequence_dense_u16, runtime_sequence_dense_u32,
    runtime_sequence_dense_u64, runtime_sequence_dense_u128, runtime_sequence_dense_units,
    runtime_sequence_dense_usize, runtime_sequence_repeat_value,
};
pub use sequence_impls::{RecordSeq, RecordSeqField, TupleSeq};
pub use shape::RuntimeValueShape;
pub use virtual_path::{RuntimeVirtualPath, RuntimeVirtualPathError, RuntimeVirtualPathSpace};

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RuntimeBinding {
    pub name: String,
    pub value: RuntimeValue,
}

/// One value or operand addressed by the checked Flow parameter ABI.
///
/// Route adapters use this carrier after a checked route binding has resolved
/// the external request source to an exact target parameter coordinate. The
/// diagnostic parameter name is deliberately absent and cannot become a
/// second execution authority.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RuntimeFlowParameterBinding<V = RuntimeValue> {
    pub parameter: FlowParameterCoordinate,
    pub value: V,
}

/// One binding in the plan-local structured execution domain.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(
    deny_unknown_fields,
    bound(
        serialize = "V: InertRuntimeValueStorage",
        deserialize = "V: InertRuntimeValueStorage"
    )
)]
pub struct RuntimeLocalBinding<V = RuntimeValue> {
    pub local: RuntimeLocalDeclarationId,
    pub value: V,
}

/// Validation failures at a native FunctionSite input boundary.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeFunctionApplyError {
    #[error("function site {site} input instantiation failed: {source}")]
    InputInstantiation {
        site: crate::runtime_id::RuntimeFunctionSiteId,
        #[source]
        source: crate::program_types::RuntimeFunctionEffectInstantiationError,
    },
    #[error("function site {site} inputs have no joint declaration effect instantiation")]
    InvalidEffectInstantiation {
        site: crate::runtime_id::RuntimeFunctionSiteId,
    },
    #[error("structured function site {site} does not belong to its owning plan")]
    UnknownStructuredSite { site: RuntimeFunctionSiteId },
    #[error("structured function site {site} requires {expected} captures, received {actual}")]
    CaptureCountMismatch {
        site: RuntimeFunctionSiteId,
        expected: usize,
        actual: usize,
    },
    #[error("structured function site {site} references unknown local declaration {local}")]
    UnknownStructuredLocal {
        site: RuntimeFunctionSiteId,
        local: RuntimeLocalDeclarationId,
    },
    #[error(
        "structured function site {site} capture {index} for local {local} does not match plan type {expected}"
    )]
    CaptureTypeMismatch {
        site: RuntimeFunctionSiteId,
        index: usize,
        local: RuntimeLocalDeclarationId,
        expected: RuntimePlanTypeId,
    },
    #[error(
        "structured function site {site} argument {index} for local {local} does not match plan type {expected}"
    )]
    ArgumentTypeMismatch {
        site: RuntimeFunctionSiteId,
        index: usize,
        local: RuntimeLocalDeclarationId,
        expected: RuntimePlanTypeId,
    },
    #[error("structured function site {site} input {input:?} requires an unrestricted value")]
    UnrestrictedInputRequired {
        site: RuntimeFunctionSiteId,
        input: crate::plan::RuntimeFunctionInputSource,
    },
    #[error("structured function site {site} local {local} requires an unrestricted bound value")]
    UnrestrictedBindingRequired {
        site: RuntimeFunctionSiteId,
        local: RuntimeLocalDeclarationId,
    },
    #[error("function has {remaining} remaining parameters, received {provided} arguments")]
    TooManyArguments { remaining: usize, provided: usize },
    #[error("structured function site {site} has an invalid bound-argument prefix")]
    InvalidBoundArgumentPrefix { site: RuntimeFunctionSiteId },
    #[error(transparent)]
    ValueType(#[from] RuntimePlanValueTypeError),
}

/// Structured payload exchanged at the host/runtime boundary.
///
/// Payloads intentionally retain `RuntimeValue` shape instead of collapsing
/// source and stream items to debug strings. Hosts may still display `label()`
/// for logs, but replay and downstream runtime consumers keep typed data.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct RuntimePayload(pub RuntimeValue);

/// Deterministic value domain used by the Sans I/O flow runtime.
///
/// Typed floats use Rust's native `f32`/`f64` values. Exact bit identity is an
/// explicit operation rather than language equality.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub enum RuntimeValue {
    Unit,
    Bool(bool),
    Int(RuntimeInt),
    UInt(RuntimeUInt),
    F32(f32),
    F64(f64),
    MatrixF32(DenseMatrixF32),
    MatrixF64(DenseMatrixF64),
    TensorF32(DenseTensorF32),
    TensorF64(DenseTensorF64),
    String(String),
    Color(RuntimeColor),
    /// Opaque identity of a one-shot temporal value. The payload type is owned
    /// by the enclosing runtime type, never inferred from this identity.
    NeedHandle(crate::task::RuntimeNeedHandle),
    Char(char),
    Duration(LogicalDuration),
    Progress(Progress),
    Range(RuntimeRange),
    Iterator(RuntimeIterator),
    EntityRef(RuntimeEntityReference),
    Tuple(Vec<RuntimeValue>),
    Seq(RuntimeSeq),
    Record(RuntimeRecordValue),
    NominalRecord(RuntimeNominalRecordValue),
    Opaque(RuntimeOpaqueValue),
    PresentationResource(Box<crate::presentation::RuntimePresentationResourceValue>),
    Reduction(RuntimeReductionValue),
    Agent(RuntimeAgentValue),
    Callable(RuntimeCallableValue),
    Variant(RuntimeVariantValue),
}

/// Immutable variant header and its source-shaped owned payload.
/// Owning schema/program constructors admit candidates before publication.
///
/// External callers cannot forge a live header:
/// ```compile_fail
/// use arcweft_core::value::{RuntimeValue, RuntimeVariantValue};
/// use arcweft_core::pattern::{RuntimeVariantIdentity, RuntimeBuiltinVariantIdentity};
/// let value = RuntimeValue::Variant(RuntimeVariantValue {
///     owner: RuntimeVariantIdentity::Builtin(RuntimeBuiltinVariantIdentity::Option),
///     ordinal: 0,
///     name: "Forged".to_owned(),
///     payload: None,
///     type_instantiation: None,
/// });
/// ```
/// Payload mutation also remains inside the value owner's type-preserving operations:
/// ```compile_fail
/// use arcweft_core::value::RuntimeValue;
/// let RuntimeValue::Variant(value) = RuntimeValue::option_some(RuntimeValue::Bool(true)) else {
///     unreachable!()
/// };
/// let forged = value.try_map_payload(|_| Ok::<_, ()>(RuntimeValue::String("wrong type".into())));
/// ```
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeVariantValue {
    owner: RuntimeVariantIdentity,
    ordinal: u32,
    name: String,
    type_instantiation:
        Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
    payload: Option<Box<RuntimeValue>>,
}

impl RuntimeVariantValue {
    pub(crate) fn try_from_plan_case<E>(
        case: &crate::plan::RuntimePlanVariantCase<'_>,
        payload: Option<RuntimeValue>,
        binding: Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
        validate: impl FnOnce(&RuntimeValue) -> Result<(), E>,
    ) -> Result<RuntimeValue, E> {
        Self::admit(
            case.owner().clone(),
            case.ordinal(),
            case.name().to_owned(),
            payload,
            binding,
            validate,
        )
    }

    pub(crate) fn try_from_nominal_case<E>(
        identity: &crate::entry::RuntimeNominalSchemaIdentity,
        layout: crate::entry::TypeLayoutHash,
        case: &crate::entry::RuntimeNominalSchemaCase,
        payload: Option<RuntimeValue>,
        validate: impl FnOnce(&RuntimeValue) -> Result<(), E>,
    ) -> Result<RuntimeValue, E> {
        Self::admit(
            RuntimeVariantIdentity::Nominal {
                nominal: identity.nominal().clone(),
                semantic_identity: identity.semantic_identity(),
                layout,
            },
            case.ordinal(),
            case.name().to_owned(),
            payload,
            None,
            validate,
        )
    }

    pub(crate) fn try_from_program_case<E>(
        case: crate::program_types::ProgramVariantCase,
        payload: Option<RuntimeValue>,
        binding: Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
        validate: impl FnOnce(&RuntimeValue) -> Result<(), E>,
    ) -> Result<RuntimeValue, E> {
        let (owner, ordinal, name) = case.into_header();
        Self::admit(owner, ordinal, name, payload, binding, validate)
    }

    fn admit<E>(
        owner: RuntimeVariantIdentity,
        ordinal: u32,
        name: String,
        payload: Option<RuntimeValue>,
        binding: Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
        validate: impl FnOnce(&RuntimeValue) -> Result<(), E>,
    ) -> Result<RuntimeValue, E> {
        let value = RuntimeValue::Variant(Self {
            owner,
            ordinal,
            name,
            payload: payload.map(Box::new),
            type_instantiation: binding,
        });
        validate(&value)?;
        Ok(value)
    }
    #[must_use]
    pub fn into_payload(self) -> Option<RuntimeValue> {
        self.payload.map(|payload| *payload)
    }
    #[must_use]
    pub const fn owner(&self) -> &RuntimeVariantIdentity {
        &self.owner
    }
    #[must_use]
    pub const fn ordinal(&self) -> u32 {
        self.ordinal
    }
    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }
    #[must_use]
    pub fn payload(&self) -> Option<&RuntimeValue> {
        self.payload.as_deref()
    }
    #[must_use]
    pub fn type_instantiation(
        &self,
    ) -> Option<&crate::program_types::RuntimeFunctionEffectInstantiation> {
        self.type_instantiation.as_deref()
    }

    #[must_use]
    pub fn type_instantiation_lease(
        &self,
    ) -> Option<&std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>> {
        self.type_instantiation.as_ref()
    }

    /// Maps a retained child without copying or reconstructing the header.
    fn try_map_payload<E>(
        mut self,
        map: impl FnOnce(RuntimeValue) -> Result<RuntimeValue, E>,
    ) -> Result<Self, E> {
        self.payload = self
            .payload
            .map(|value| map(*value).map(Box::new))
            .transpose()?;
        Ok(self)
    }
}

impl Serialize for RuntimeVariantValue {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        if matches!(self.owner, RuntimeVariantIdentity::Nominal { .. }) {
            return Err(serde::ser::Error::custom(
                "nominal variant values require a program-bound snapshot",
            ));
        }
        use serde::ser::SerializeStruct;
        let mut row = serializer.serialize_struct("RuntimeVariantValue", 5)?;
        row.serialize_field("owner", &self.owner)?;
        row.serialize_field("ordinal", &self.ordinal)?;
        row.serialize_field("name", &self.name)?;
        row.serialize_field("type_instantiation", &self.type_instantiation)?;
        row.serialize_field("payload", &self.payload)?;
        row.end()
    }
}

impl<'de> Deserialize<'de> for RuntimeVariantValue {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Input {
            owner: RuntimeVariantIdentity,
            ordinal: u32,
            name: String,
            type_instantiation:
                Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
            payload: Option<Box<RuntimeValue>>,
        }
        let input = Input::deserialize(deserializer)?;
        let RuntimeVariantIdentity::Builtin(owner) = input.owner else {
            return Err(serde::de::Error::custom(
                "nominal variant values require program-bound restore",
            ));
        };
        let case = owner
            .case_at(input.ordinal)
            .ok_or_else(|| serde::de::Error::custom("unknown builtin variant case"))?;
        if input.name != case.name()
            || input.type_instantiation.is_some()
            || match (case.payload_arity(), input.payload.as_deref()) {
                (None, None) => false,
                (Some(arity), Some(RuntimeValue::Tuple(fields))) if fields.len() == arity => false,
                _ => true,
            }
        {
            return Err(serde::de::Error::custom(
                "invalid builtin variant header or payload",
            ));
        }
        Ok(Self {
            owner: RuntimeVariantIdentity::Builtin(owner),
            ordinal: input.ordinal,
            name: input.name,
            type_instantiation: None,
            payload: input.payload,
        })
    }
}

/// Rejection produced when a caller attempts to construct a builtin variant
/// without following the case schema owned by
/// [`crate::pattern::RuntimeBuiltinVariantIdentity`].
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum RuntimeBuiltinVariantValueError {
    #[error("builtin variant case belongs to a different owner")]
    WrongOwner,
    #[error("builtin variant case payload presence does not match its schema")]
    InvalidPayloadPresence,
}

impl RuntimeValue {
    /// Reads a field from either physical record representation by admitted
    /// ordinal. The executable type schema remains the field's owner.
    pub(crate) fn record_field(&self, field: RuntimeRecordFieldId) -> Option<&RuntimeValue> {
        let ordinal = field.zero_based() as usize;
        match self {
            Self::NominalRecord(record) => record.fields().get(ordinal),
            Self::Record(fields) => fields.get(ordinal).map(RuntimeFieldValue::value),
            _ => None,
        }
    }

    /// Returns whether this value graph contains a snapshot-only opaque leaf.
    #[must_use]
    pub fn contains_nonconstant_opaque(&self) -> bool {
        match self {
            Self::PresentationResource(_) => true,
            Self::Opaque(value) => {
                value.persistence() == RuntimeOpaquePersistence::SnapshotOnly
                    || matches!(
                        value.value_class(),
                        RuntimeOpaqueValueClass::AffineHandle(_)
                    )
                    || value.payload().contains_nonconstant_opaque()
            }
            Self::Tuple(values) => values.iter().any(Self::contains_nonconstant_opaque),
            Self::Record(fields) => fields
                .iter()
                .any(|field| field.value().contains_nonconstant_opaque()),
            Self::Seq(sequence) => sequence
                .clone()
                .into_values()
                .iter()
                .any(Self::contains_nonconstant_opaque),
            Self::NominalRecord(record) => record
                .fields()
                .iter()
                .any(Self::contains_nonconstant_opaque),
            Self::Reduction(value) => {
                value.state().contains_nonconstant_opaque()
                    || value
                        .commands()
                        .iter()
                        .any(|command| command.payload().0.contains_nonconstant_opaque())
            }
            Self::Agent(value) => value
                .nested_runtime_values_with_depth()
                .into_iter()
                .any(|(_, value)| value.contains_nonconstant_opaque()),
            Self::Iterator(RuntimeIterator::Values { items, .. }) => {
                items.iter().any(Self::contains_nonconstant_opaque)
            }
            Self::Iterator(RuntimeIterator::Witness(witness)) => {
                witness.state().contains_nonconstant_opaque()
            }
            Self::Variant(crate::value::RuntimeVariantValue { payload, .. }) => payload
                .as_deref()
                .is_some_and(Self::contains_nonconstant_opaque),
            Self::Unit
            | Self::Bool(_)
            | Self::Int(_)
            | Self::UInt(_)
            | Self::F32(_)
            | Self::F64(_)
            | Self::MatrixF32(_)
            | Self::MatrixF64(_)
            | Self::TensorF32(_)
            | Self::TensorF64(_)
            | Self::String(_)
            | Self::Color(_)
            | Self::Char(_)
            | Self::Duration(_)
            | Self::Progress(_)
            | Self::Range(_)
            | Self::Iterator(RuntimeIterator::Range(_))
            | Self::EntityRef(_) => false,
            Self::Callable(callable) => callable
                .retained()
                .iter()
                .any(Self::contains_nonconstant_opaque),
            Self::NeedHandle(handle) => handle
                .request_values()
                .any(Self::contains_nonconstant_opaque),
        }
    }

    /// Returns whether this value graph contains executable function state.
    ///
    /// Runtime-plan constants and pattern literals use this exhaustive owner
    /// predicate to prevent a live closure from retaining its owning plan.
    #[must_use]
    pub fn contains_function(&self) -> bool {
        match self {
            Self::PresentationResource(value) => value.body().contains_function(),
            Self::Callable(_) => true,
            Self::NeedHandle(handle) => handle.request_values().any(Self::contains_function),
            Self::Tuple(values) => values.iter().any(Self::contains_function),
            Self::Record(fields) => fields.iter().any(|field| field.value().contains_function()),
            Self::Seq(sequence) => sequence_contains_function(sequence),
            Self::NominalRecord(record) => record.fields().iter().any(Self::contains_function),
            Self::Opaque(value) => value.payload().contains_function(),
            Self::Reduction(value) => {
                value.state().contains_function()
                    || value
                        .commands()
                        .iter()
                        .any(|command| command.payload().0.contains_function())
            }
            Self::Agent(value) => value
                .nested_runtime_values_with_depth()
                .into_iter()
                .any(|(_, value)| value.contains_function()),
            Self::Iterator(RuntimeIterator::Values { items, .. }) => {
                items.iter().any(Self::contains_function)
            }
            Self::Iterator(RuntimeIterator::Witness(witness)) => {
                witness.state().contains_function()
            }
            Self::Variant(crate::value::RuntimeVariantValue {
                payload: Some(payload),
                ..
            }) => payload.contains_function(),
            Self::Unit
            | Self::Bool(_)
            | Self::Int(_)
            | Self::UInt(_)
            | Self::F32(_)
            | Self::F64(_)
            | Self::MatrixF32(_)
            | Self::MatrixF64(_)
            | Self::TensorF32(_)
            | Self::TensorF64(_)
            | Self::String(_)
            | Self::Color(_)
            | Self::Char(_)
            | Self::Duration(_)
            | Self::Progress(_)
            | Self::Range(_)
            | Self::Iterator(RuntimeIterator::Range(_))
            | Self::EntityRef(_)
            | Self::Variant(crate::value::RuntimeVariantValue { payload: None, .. }) => false,
        }
    }
}

fn sequence_contains_function(sequence: &RuntimeSeq) -> bool {
    match sequence {
        RuntimeSeq::Values(values) => values.iter().any(RuntimeValue::contains_function),
        RuntimeSeq::TupleColumns(columns) => {
            columns.columns().iter().any(sequence_contains_function)
        }
        RuntimeSeq::RecordColumns(records) => records
            .fields()
            .iter()
            .any(|field| sequence_contains_function(field.values())),
        RuntimeSeq::Dense(_) => false,
    }
}

/// Runtime call target after syntax lowering.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeCallTarget {
    Intrinsic(RuntimeIntrinsic),
    Callable(RuntimeCallableId),
    External(RuntimeExternalCallable),
    /// A Core-owned slot operation with its exact compact selector ABI.
    PresentationSlot(crate::presentation::RuntimePresentationSlotCall),
    /// Stateful construction owned by the execution's presentation bank.
    PresentationFactory(Arc<crate::presentation::RuntimePresentationFactoryCall>),
    /// Retains a View declaration and its supplied values without mounting it.
    PresentationView(Arc<crate::presentation::RuntimePresentationViewCall>),
}

impl RuntimeCallTarget {
    pub fn try_from_label(label: impl Into<String>) -> Result<Self, RuntimeIdentityError> {
        let label = label.into();
        RuntimeIntrinsic::from_label(&label)
            .map(Self::Intrinsic)
            .map_or_else(|| RuntimeCallableId::try_new(label).map(Self::Callable), Ok)
    }

    pub const fn intrinsic(intrinsic: RuntimeIntrinsic) -> Self {
        Self::Intrinsic(intrinsic)
    }

    pub const fn callable(callable: RuntimeCallableId) -> Self {
        Self::Callable(callable)
    }

    pub const fn as_intrinsic(&self) -> Option<RuntimeIntrinsic> {
        match self {
            Self::Intrinsic(intrinsic) => Some(*intrinsic),
            Self::Callable(_)
            | Self::External(_)
            | Self::PresentationSlot(_)
            | Self::PresentationFactory(_)
            | Self::PresentationView(_) => None,
        }
    }

    /// Whether execution must borrow the actual presentation custody owner.
    /// Inert slot addresses do not acquire this execution requirement.
    pub const fn requires_presentation_owner(&self) -> bool {
        match self {
            Self::PresentationFactory(_) | Self::PresentationView(_) => true,
            Self::PresentationSlot(call) => !call.is_reference(),
            Self::Intrinsic(_) | Self::Callable(_) | Self::External(_) => false,
        }
    }

    pub fn as_label(&self) -> &str {
        match self {
            Self::Intrinsic(intrinsic) => intrinsic.as_label(),
            Self::Callable(callable) => callable.as_str(),
            Self::External(callable) => callable.identity().as_str(),
            Self::PresentationSlot(call) => match call.operation() {
                crate::presentation::RuntimePresentationSlotOperation::Reference => {
                    "core.presentation.slot_ref"
                }
                crate::presentation::RuntimePresentationSlotOperation::Remove => {
                    "core.presentation.remove"
                }
            },
            Self::PresentationFactory(_) => "core.presentation.factory",
            Self::PresentationView(_) => "core.presentation.view_value",
        }
    }

    /// The selected semantic identity, including calls with declaration linkage.
    pub const fn callable_identity(&self) -> Option<&RuntimeCallableId> {
        match self {
            Self::Callable(identity) => Some(identity),
            Self::External(callable) => Some(callable.identity()),
            Self::Intrinsic(_)
            | Self::PresentationSlot(_)
            | Self::PresentationFactory(_)
            | Self::PresentationView(_) => None,
        }
    }
}

impl fmt::Display for RuntimeCallTarget {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_label())
    }
}

/// Built-in runtime calls that use typed dispatch instead of string matching.
#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeIntrinsic {
    Add,
    CoreRange,
    CoreIterCollect,
    CoreSeqLen,
    CoreSeqSum,
    /// Checks the actual retained graph and returns the same owned value.
    CoreRequireUnrestricted,
    /// Owns a finite collection plus its validated positive fanout limit.
    CoreFanoutInputs,
    CoreRangeIntoIter,
    CoreSeqIntoIter,
    CoreStreamIntoIter,
    CoreVecIntoIter,
    CoreArrayIntoIter,
    CoreSliceIntoIter,
    CoreTupleIntoIter,
    CoreIterNext,
    CoreOptionIsSome,
    CoreOptionUnwrap,
    StdOptionContext,
    StdOptionWithContext,
    StdResultContext,
    StdResultWithContext,
    CoreIndex,
    String(RuntimeStringOperation),
    VecWithCapacity,
    StringWithCapacity,
    BytesWithCapacity,
    VecReserve,
    StringReserve,
    BytesReserve,
    VecShrinkTo,
    StringShrinkTo,
    BytesShrinkTo,
    VecShrink,
    StringShrink,
    BytesShrink,
    StdF32Abs,
    StdF32Floor,
    StdF32Ceil,
    StdF32Round,
    StdF32Trunc,
    StdF32Fract,
    StdF32Sqrt,
    StdF32Sin,
    StdF32Cos,
    StdF32Tan,
    StdF32Exp,
    StdF32Exp2,
    StdF32Ln,
    StdF32Log2,
    StdF32Log10,
    StdF32Powf,
    StdF32Atan2,
    StdF32MulAdd,
    StdF32IsNan,
    StdF32IsInfinite,
    StdF32IsFinite,
    StdF32IsSignPositive,
    StdF32IsSignNegative,
    StdF32ToBits,
    StdF32FromBits,
    StdF32ToF64,
    StdF64Abs,
    StdF64Floor,
    StdF64Ceil,
    StdF64Round,
    StdF64Trunc,
    StdF64Fract,
    StdF64Sqrt,
    StdF64Sin,
    StdF64Cos,
    StdF64Tan,
    StdF64Exp,
    StdF64Exp2,
    StdF64Ln,
    StdF64Log2,
    StdF64Log10,
    StdF64Powf,
    StdF64Atan2,
    StdF64MulAdd,
    StdF64IsNan,
    StdF64IsInfinite,
    StdF64IsFinite,
    StdF64IsSignPositive,
    StdF64IsSignNegative,
    StdF64ToBits,
    StdF64FromBits,
    StdF64ToF32,
    MathMatmulF32,
    MathMatrixAddF32,
    MathTensorAddF32,
    MathMatmulF64,
    MathMatrixAddF64,
    MathTensorAddF64,
}

/// Closed capacity intrinsic family shared by execution and bytecode verification.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RuntimeCapacityFamily {
    Vec,
    String,
    Bytes,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RuntimeCapacityOperation {
    Construct,
    Hint,
    Shrink,
}

impl RuntimeIntrinsic {
    pub(crate) const fn capacity_contract(
        self,
    ) -> Option<(RuntimeCapacityFamily, RuntimeCapacityOperation)> {
        use RuntimeCapacityFamily::{Bytes, String, Vec};
        use RuntimeCapacityOperation::{Construct, Hint, Shrink};
        Some(match self {
            Self::VecWithCapacity => (Vec, Construct),
            Self::StringWithCapacity => (String, Construct),
            Self::BytesWithCapacity => (Bytes, Construct),
            Self::VecReserve | Self::VecShrinkTo => (Vec, Hint),
            Self::StringReserve | Self::StringShrinkTo => (String, Hint),
            Self::BytesReserve | Self::BytesShrinkTo => (Bytes, Hint),
            Self::VecShrink => (Vec, Shrink),
            Self::StringShrink => (String, Shrink),
            Self::BytesShrink => (Bytes, Shrink),
            _ => return None,
        })
    }
    pub fn from_label(label: &str) -> Option<Self> {
        if let Some(operation) = label
            .strip_prefix("string.")
            .and_then(RuntimeStringOperation::from_source_name)
        {
            return Some(Self::String(operation));
        }
        match label {
            "add" => Some(Self::Add),
            "core.range" => Some(Self::CoreRange),
            "core.iter.collect" => Some(Self::CoreIterCollect),
            "core.seq.len" => Some(Self::CoreSeqLen),
            "core.value.require_unrestricted" => Some(Self::CoreRequireUnrestricted),
            "core.fanout.inputs" => Some(Self::CoreFanoutInputs),
            "core.seq.sum" => Some(Self::CoreSeqSum),
            "core.iter.into_iter.range" => Some(Self::CoreRangeIntoIter),
            "core.iter.into_iter.seq" => Some(Self::CoreSeqIntoIter),
            "core.iter.into_iter.stream" => Some(Self::CoreStreamIntoIter),
            "core.iter.into_iter.vec" => Some(Self::CoreVecIntoIter),
            "core.iter.into_iter.array" => Some(Self::CoreArrayIntoIter),
            "core.iter.into_iter.slice" => Some(Self::CoreSliceIntoIter),
            "core.iter.into_iter.tuple" => Some(Self::CoreTupleIntoIter),
            "core.iter.next" => Some(Self::CoreIterNext),
            "core.option.is_some" => Some(Self::CoreOptionIsSome),
            "core.option.unwrap" => Some(Self::CoreOptionUnwrap),
            "std.option.context" => Some(Self::StdOptionContext),
            "std.option.with_context" => Some(Self::StdOptionWithContext),
            "std.result.context" => Some(Self::StdResultContext),
            "std.result.with_context" => Some(Self::StdResultWithContext),
            "core.index" => Some(Self::CoreIndex),
            "vec.with_capacity" => Some(Self::VecWithCapacity),
            "string.with_capacity" => Some(Self::StringWithCapacity),
            "bytes.with_capacity" => Some(Self::BytesWithCapacity),
            "vec.reserve" => Some(Self::VecReserve),
            "string.reserve" => Some(Self::StringReserve),
            "bytes.reserve" => Some(Self::BytesReserve),
            "vec.shrink_to" => Some(Self::VecShrinkTo),
            "string.shrink_to" => Some(Self::StringShrinkTo),
            "bytes.shrink_to" => Some(Self::BytesShrinkTo),
            "vec.shrink" => Some(Self::VecShrink),
            "string.shrink" => Some(Self::StringShrink),
            "bytes.shrink" => Some(Self::BytesShrink),
            "std.f32.abs" => Some(Self::StdF32Abs),
            "std.f32.floor" => Some(Self::StdF32Floor),
            "std.f32.ceil" => Some(Self::StdF32Ceil),
            "std.f32.round" => Some(Self::StdF32Round),
            "std.f32.trunc" => Some(Self::StdF32Trunc),
            "std.f32.fract" => Some(Self::StdF32Fract),
            "std.f32.sqrt" => Some(Self::StdF32Sqrt),
            "std.f32.sin" => Some(Self::StdF32Sin),
            "std.f32.cos" => Some(Self::StdF32Cos),
            "std.f32.tan" => Some(Self::StdF32Tan),
            "std.f32.exp" => Some(Self::StdF32Exp),
            "std.f32.exp2" => Some(Self::StdF32Exp2),
            "std.f32.ln" => Some(Self::StdF32Ln),
            "std.f32.log2" => Some(Self::StdF32Log2),
            "std.f32.log10" => Some(Self::StdF32Log10),
            "std.f32.powf" => Some(Self::StdF32Powf),
            "std.f32.atan2" => Some(Self::StdF32Atan2),
            "std.f32.mul_add" => Some(Self::StdF32MulAdd),
            "std.f32.is_nan" => Some(Self::StdF32IsNan),
            "std.f32.is_infinite" => Some(Self::StdF32IsInfinite),
            "std.f32.is_finite" => Some(Self::StdF32IsFinite),
            "std.f32.is_sign_positive" => Some(Self::StdF32IsSignPositive),
            "std.f32.is_sign_negative" => Some(Self::StdF32IsSignNegative),
            "std.f32.to_bits" => Some(Self::StdF32ToBits),
            "std.f32.from_bits" => Some(Self::StdF32FromBits),
            "std.f32.to_f64" => Some(Self::StdF32ToF64),
            "std.f64.abs" => Some(Self::StdF64Abs),
            "std.f64.floor" => Some(Self::StdF64Floor),
            "std.f64.ceil" => Some(Self::StdF64Ceil),
            "std.f64.round" => Some(Self::StdF64Round),
            "std.f64.trunc" => Some(Self::StdF64Trunc),
            "std.f64.fract" => Some(Self::StdF64Fract),
            "std.f64.sqrt" => Some(Self::StdF64Sqrt),
            "std.f64.sin" => Some(Self::StdF64Sin),
            "std.f64.cos" => Some(Self::StdF64Cos),
            "std.f64.tan" => Some(Self::StdF64Tan),
            "std.f64.exp" => Some(Self::StdF64Exp),
            "std.f64.exp2" => Some(Self::StdF64Exp2),
            "std.f64.ln" => Some(Self::StdF64Ln),
            "std.f64.log2" => Some(Self::StdF64Log2),
            "std.f64.log10" => Some(Self::StdF64Log10),
            "std.f64.powf" => Some(Self::StdF64Powf),
            "std.f64.atan2" => Some(Self::StdF64Atan2),
            "std.f64.mul_add" => Some(Self::StdF64MulAdd),
            "std.f64.is_nan" => Some(Self::StdF64IsNan),
            "std.f64.is_infinite" => Some(Self::StdF64IsInfinite),
            "std.f64.is_finite" => Some(Self::StdF64IsFinite),
            "std.f64.is_sign_positive" => Some(Self::StdF64IsSignPositive),
            "std.f64.is_sign_negative" => Some(Self::StdF64IsSignNegative),
            "std.f64.to_bits" => Some(Self::StdF64ToBits),
            "std.f64.from_bits" => Some(Self::StdF64FromBits),
            "std.f64.to_f32" => Some(Self::StdF64ToF32),
            "math.matmul_f32" => Some(Self::MathMatmulF32),
            "math.matrix_add_f32" => Some(Self::MathMatrixAddF32),
            "math.tensor_add_f32" => Some(Self::MathTensorAddF32),
            "math.matmul_f64" => Some(Self::MathMatmulF64),
            "math.matrix_add_f64" => Some(Self::MathMatrixAddF64),
            "math.tensor_add_f64" => Some(Self::MathTensorAddF64),
            _ => None,
        }
    }

    pub const fn as_label(self) -> &'static str {
        match self {
            Self::Add => "add",
            Self::CoreRange => "core.range",
            Self::CoreIterCollect => "core.iter.collect",
            Self::CoreSeqLen => "core.seq.len",
            Self::CoreRequireUnrestricted => "core.value.require_unrestricted",
            Self::CoreFanoutInputs => "core.fanout.inputs",
            Self::CoreSeqSum => "core.seq.sum",
            Self::CoreRangeIntoIter => "core.iter.into_iter.range",
            Self::CoreSeqIntoIter => "core.iter.into_iter.seq",
            Self::CoreStreamIntoIter => "core.iter.into_iter.stream",
            Self::CoreVecIntoIter => "core.iter.into_iter.vec",
            Self::CoreArrayIntoIter => "core.iter.into_iter.array",
            Self::CoreSliceIntoIter => "core.iter.into_iter.slice",
            Self::CoreTupleIntoIter => "core.iter.into_iter.tuple",
            Self::CoreIterNext => "core.iter.next",
            Self::CoreOptionIsSome => "core.option.is_some",
            Self::CoreOptionUnwrap => "core.option.unwrap",
            Self::StdOptionContext => "std.option.context",
            Self::StdOptionWithContext => "std.option.with_context",
            Self::StdResultContext => "std.result.context",
            Self::StdResultWithContext => "std.result.with_context",
            Self::CoreIndex => "core.index",
            Self::String(operation) => operation.intrinsic_label(),
            Self::VecWithCapacity => "vec.with_capacity",
            Self::StringWithCapacity => "string.with_capacity",
            Self::BytesWithCapacity => "bytes.with_capacity",
            Self::VecReserve => "vec.reserve",
            Self::StringReserve => "string.reserve",
            Self::BytesReserve => "bytes.reserve",
            Self::VecShrinkTo => "vec.shrink_to",
            Self::StringShrinkTo => "string.shrink_to",
            Self::BytesShrinkTo => "bytes.shrink_to",
            Self::VecShrink => "vec.shrink",
            Self::StringShrink => "string.shrink",
            Self::BytesShrink => "bytes.shrink",
            Self::StdF32Abs => "std.f32.abs",
            Self::StdF32Floor => "std.f32.floor",
            Self::StdF32Ceil => "std.f32.ceil",
            Self::StdF32Round => "std.f32.round",
            Self::StdF32Trunc => "std.f32.trunc",
            Self::StdF32Fract => "std.f32.fract",
            Self::StdF32Sqrt => "std.f32.sqrt",
            Self::StdF32Sin => "std.f32.sin",
            Self::StdF32Cos => "std.f32.cos",
            Self::StdF32Tan => "std.f32.tan",
            Self::StdF32Exp => "std.f32.exp",
            Self::StdF32Exp2 => "std.f32.exp2",
            Self::StdF32Ln => "std.f32.ln",
            Self::StdF32Log2 => "std.f32.log2",
            Self::StdF32Log10 => "std.f32.log10",
            Self::StdF32Powf => "std.f32.powf",
            Self::StdF32Atan2 => "std.f32.atan2",
            Self::StdF32MulAdd => "std.f32.mul_add",
            Self::StdF32IsNan => "std.f32.is_nan",
            Self::StdF32IsInfinite => "std.f32.is_infinite",
            Self::StdF32IsFinite => "std.f32.is_finite",
            Self::StdF32IsSignPositive => "std.f32.is_sign_positive",
            Self::StdF32IsSignNegative => "std.f32.is_sign_negative",
            Self::StdF32ToBits => "std.f32.to_bits",
            Self::StdF32FromBits => "std.f32.from_bits",
            Self::StdF32ToF64 => "std.f32.to_f64",
            Self::StdF64Abs => "std.f64.abs",
            Self::StdF64Floor => "std.f64.floor",
            Self::StdF64Ceil => "std.f64.ceil",
            Self::StdF64Round => "std.f64.round",
            Self::StdF64Trunc => "std.f64.trunc",
            Self::StdF64Fract => "std.f64.fract",
            Self::StdF64Sqrt => "std.f64.sqrt",
            Self::StdF64Sin => "std.f64.sin",
            Self::StdF64Cos => "std.f64.cos",
            Self::StdF64Tan => "std.f64.tan",
            Self::StdF64Exp => "std.f64.exp",
            Self::StdF64Exp2 => "std.f64.exp2",
            Self::StdF64Ln => "std.f64.ln",
            Self::StdF64Log2 => "std.f64.log2",
            Self::StdF64Log10 => "std.f64.log10",
            Self::StdF64Powf => "std.f64.powf",
            Self::StdF64Atan2 => "std.f64.atan2",
            Self::StdF64MulAdd => "std.f64.mul_add",
            Self::StdF64IsNan => "std.f64.is_nan",
            Self::StdF64IsInfinite => "std.f64.is_infinite",
            Self::StdF64IsFinite => "std.f64.is_finite",
            Self::StdF64IsSignPositive => "std.f64.is_sign_positive",
            Self::StdF64IsSignNegative => "std.f64.is_sign_negative",
            Self::StdF64ToBits => "std.f64.to_bits",
            Self::StdF64FromBits => "std.f64.from_bits",
            Self::StdF64ToF32 => "std.f64.to_f32",
            Self::MathMatmulF32 => "math.matmul_f32",
            Self::MathMatrixAddF32 => "math.matrix_add_f32",
            Self::MathTensorAddF32 => "math.tensor_add_f32",
            Self::MathMatmulF64 => "math.matmul_f64",
            Self::MathMatrixAddF64 => "math.matrix_add_f64",
            Self::MathTensorAddF64 => "math.tensor_add_f64",
        }
    }

    #[must_use]
    pub const fn builtin_iterator_into_iter(
        family: crate::plan::RuntimeBuiltinIteratorFamily,
    ) -> Self {
        match family {
            crate::plan::RuntimeBuiltinIteratorFamily::Range => Self::CoreRangeIntoIter,
            crate::plan::RuntimeBuiltinIteratorFamily::Seq => Self::CoreSeqIntoIter,
            crate::plan::RuntimeBuiltinIteratorFamily::Stream => Self::CoreStreamIntoIter,
            crate::plan::RuntimeBuiltinIteratorFamily::Vec => Self::CoreVecIntoIter,
            crate::plan::RuntimeBuiltinIteratorFamily::Array => Self::CoreArrayIntoIter,
            crate::plan::RuntimeBuiltinIteratorFamily::Slice => Self::CoreSliceIntoIter,
            crate::plan::RuntimeBuiltinIteratorFamily::TupleHomogeneous => Self::CoreTupleIntoIter,
        }
    }

    #[must_use]
    pub const fn builtin_iterator_family(
        self,
    ) -> Option<crate::plan::RuntimeBuiltinIteratorFamily> {
        match self {
            Self::CoreRangeIntoIter => Some(crate::plan::RuntimeBuiltinIteratorFamily::Range),
            Self::CoreSeqIntoIter => Some(crate::plan::RuntimeBuiltinIteratorFamily::Seq),
            Self::CoreStreamIntoIter => Some(crate::plan::RuntimeBuiltinIteratorFamily::Stream),
            Self::CoreVecIntoIter => Some(crate::plan::RuntimeBuiltinIteratorFamily::Vec),
            Self::CoreArrayIntoIter => Some(crate::plan::RuntimeBuiltinIteratorFamily::Array),
            Self::CoreSliceIntoIter => Some(crate::plan::RuntimeBuiltinIteratorFamily::Slice),
            Self::CoreTupleIntoIter => {
                Some(crate::plan::RuntimeBuiltinIteratorFamily::TupleHomogeneous)
            }
            _ => None,
        }
    }
}

impl RuntimeValue {
    /// Constructs one core-owned builtin variant through its canonical case
    /// schema. Callers provide a semantic case coordinate, never a copied
    /// ordinal or case label.
    pub fn try_builtin_variant(
        case: RuntimeBuiltinVariantCaseIdentity,
        payload: Option<RuntimeValue>,
    ) -> Result<Self, RuntimeBuiltinVariantValueError> {
        let owner = case.owner();
        let Some((ordinal, schema)) = owner.resolve_case(case) else {
            return Err(RuntimeBuiltinVariantValueError::WrongOwner);
        };
        if schema.has_payload() != payload.is_some() {
            return Err(RuntimeBuiltinVariantValueError::InvalidPayloadPresence);
        }
        Ok(Self::Variant(crate::value::RuntimeVariantValue {
            owner: RuntimeVariantIdentity::Builtin(owner),
            ordinal,
            name: schema.name().to_owned(),
            payload: payload.map(|payload| Box::new(Self::Tuple(vec![payload]))),
            type_instantiation: None,
        }))
    }

    /// Returns the admitted semantic case coordinate and payload for one
    /// canonical builtin variant value. Malformed owner/ordinal/name/payload
    /// combinations are rejected instead of being partially interpreted.
    #[must_use]
    pub fn builtin_variant_case(
        &self,
    ) -> Option<(RuntimeBuiltinVariantCaseIdentity, Option<&RuntimeValue>)> {
        let Self::Variant(crate::value::RuntimeVariantValue {
            owner: RuntimeVariantIdentity::Builtin(owner),
            ordinal,
            name,
            payload,
            type_instantiation: _,
        }) = self
        else {
            return None;
        };
        let schema = owner.case_at(*ordinal)?;
        let payload = match (schema.payload_arity(), payload.as_deref()) {
            (None, None) => None,
            (Some(arity), Some(Self::Tuple(fields))) if fields.len() == arity => fields.first(),
            _ => return None,
        };
        (name == schema.name()).then_some((schema.identity(), payload))
    }

    /// Consumes one canonical builtin variant without cloning its payload.
    /// Malformed owner/ordinal/name/payload combinations are returned intact.
    pub fn try_into_builtin_variant_case(
        self,
    ) -> Result<(RuntimeBuiltinVariantCaseIdentity, Option<RuntimeValue>), Self> {
        let Self::Variant(crate::value::RuntimeVariantValue {
            owner: RuntimeVariantIdentity::Builtin(owner),
            ordinal,
            name,
            payload,
            type_instantiation,
        }) = self
        else {
            return Err(self);
        };
        let Some(schema) = owner.case_at(ordinal) else {
            return Err(Self::Variant(crate::value::RuntimeVariantValue {
                owner: RuntimeVariantIdentity::Builtin(owner),
                ordinal,
                name,
                payload,
                type_instantiation,
            }));
        };
        let payload = match (schema.payload_arity(), payload) {
            (None, None) => None,
            (Some(arity), Some(payload)) => match *payload {
                Self::Tuple(mut fields) if fields.len() == arity => fields.pop(),
                payload => {
                    return Err(Self::Variant(crate::value::RuntimeVariantValue {
                        owner: RuntimeVariantIdentity::Builtin(owner),
                        ordinal,
                        name,
                        payload: Some(Box::new(payload)),
                        type_instantiation,
                    }));
                }
            },
            (_, payload) => {
                return Err(Self::Variant(crate::value::RuntimeVariantValue {
                    owner: RuntimeVariantIdentity::Builtin(owner),
                    ordinal,
                    name,
                    payload,
                    type_instantiation,
                }));
            }
        };
        if name != schema.name() {
            return Err(Self::Variant(crate::value::RuntimeVariantValue {
                owner: RuntimeVariantIdentity::Builtin(owner),
                ordinal,
                name,
                payload: payload.map(|payload| Box::new(Self::Tuple(vec![payload]))),
                type_instantiation,
            }));
        }
        Ok((schema.identity(), payload))
    }

    /// Materializes the canonical runtime representation of `Result::Ok`.
    ///
    /// # Panics
    ///
    /// Panics only if the core-owned Result case schema is inconsistent with
    /// its statically defined payload cardinality.
    pub fn result_ok(value: RuntimeValue) -> Self {
        Self::try_builtin_variant(RuntimeBuiltinVariantCaseIdentity::ResultOk, Some(value))
            .expect("Result::Ok builtin schema requires exactly one payload")
    }

    /// Materializes the canonical runtime representation of `Result::Err`.
    ///
    /// # Panics
    ///
    /// Panics only if the core-owned Result case schema is inconsistent with
    /// its statically defined payload cardinality.
    pub fn result_err(error: RuntimeValue) -> Self {
        Self::try_builtin_variant(RuntimeBuiltinVariantCaseIdentity::ResultErr, Some(error))
            .expect("Result::Err builtin schema requires exactly one payload")
    }

    /// Returns this value as a nominal record without accepting anonymous
    /// structural records.
    #[must_use]
    pub const fn as_nominal_record(&self) -> Option<&RuntimeNominalRecordValue> {
        match self {
            Self::NominalRecord(record) => Some(record),
            _ => None,
        }
    }

    /// Encodes the deterministic replay/save identity of this value.
    pub fn try_canonical_bytes(
        &self,
        max_encoded_bytes: usize,
    ) -> Result<Vec<u8>, RuntimeSchemaError> {
        crate::entry::canonical_runtime_value_bytes(self, max_encoded_bytes)
    }

    /// Hashes the deterministic replay/save identity of this value.
    pub fn try_digest(
        &self,
        max_encoded_bytes: usize,
    ) -> Result<RuntimeValueDigest, RuntimeSchemaError> {
        crate::entry::canonical_runtime_value_digest(self, max_encoded_bytes)
    }

    /// Hashes persistent data with one shared logical-value budget, including
    /// opaque payloads. This does not establish nominal or producer type facts.
    pub fn try_digest_with_limits(
        &self,
        limits: crate::entry::RuntimeSchemaLimits,
    ) -> Result<RuntimeValueDigest, RuntimeSchemaError> {
        crate::entry::schema::value_encoding::validate_and_hash(
            self,
            limits,
            &mut crate::entry::schema::value_encoding::NoSchemaValidation::default(),
            (),
        )
    }

    pub const fn i8(value: i8) -> Self {
        Self::Int(RuntimeInt::i8(value))
    }

    pub const fn i16(value: i16) -> Self {
        Self::Int(RuntimeInt::i16(value))
    }

    pub const fn i32(value: i32) -> Self {
        Self::Int(RuntimeInt::i32(value))
    }

    pub const fn i64(value: i64) -> Self {
        Self::Int(RuntimeInt::i64(value))
    }

    pub const fn i128(value: i128) -> Self {
        Self::Int(RuntimeInt::i128(value))
    }

    pub const fn isize(value: i64) -> Self {
        Self::Int(RuntimeInt::isize(value))
    }

    pub const fn u8(value: u8) -> Self {
        Self::UInt(RuntimeUInt::u8(value))
    }

    pub const fn u16(value: u16) -> Self {
        Self::UInt(RuntimeUInt::u16(value))
    }

    pub const fn u32(value: u32) -> Self {
        Self::UInt(RuntimeUInt::u32(value))
    }

    pub const fn u64(value: u64) -> Self {
        Self::UInt(RuntimeUInt::u64(value))
    }

    pub const fn u128(value: u128) -> Self {
        Self::UInt(RuntimeUInt::u128(value))
    }

    pub const fn usize(value: u64) -> Self {
        Self::UInt(RuntimeUInt::usize(value))
    }

    pub const fn f32(value: f32) -> Self {
        Self::F32(value)
    }

    pub const fn f64(value: f64) -> Self {
        Self::F64(value)
    }

    pub fn matrix_f32(value: DenseMatrixF32) -> Self {
        Self::MatrixF32(value)
    }

    pub fn matrix_f64(value: DenseMatrixF64) -> Self {
        Self::MatrixF64(value)
    }

    pub fn tensor_f32(value: DenseTensorF32) -> Self {
        Self::TensorF32(value)
    }

    pub fn tensor_f64(value: DenseTensorF64) -> Self {
        Self::TensorF64(value)
    }

    pub fn as_identifier(&self) -> Option<String> {
        match self {
            Self::EntityRef(value) => Some(value.runtime_label()),
            Self::String(value) => Some(value.clone()),
            _ => None,
        }
    }

    pub const fn as_bool(&self) -> Option<bool> {
        match self {
            Self::Bool(value) => Some(*value),
            _ => None,
        }
    }

    pub fn try_i64(&self) -> Option<i64> {
        match self {
            Self::Int(value) => value.try_into_i64(),
            Self::UInt(value) => value.try_into_i64(),
            _ => None,
        }
    }

    pub fn try_u64(&self) -> Option<u64> {
        match self {
            Self::UInt(value) => value.try_into_u64(),
            Self::Int(value) => value
                .try_into_i64()
                .and_then(|value| u64::try_from(value).ok()),
            _ => None,
        }
    }
}

/// Storage strategy for runtime sequence values.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub enum RuntimeSeq {
    Values(Vec<RuntimeValue>),
    Dense(DenseSeq),
    TupleColumns(TupleSeq),
    RecordColumns(RecordSeq),
}

#[derive(Clone, Debug, Error, PartialEq)]
pub enum RuntimeSeqError {
    #[error("sequence column {ordinal} length {actual} does not match expected length {expected}")]
    ColumnLength {
        ordinal: usize,
        expected: usize,
        actual: usize,
    },
    #[error("invalid record sequence field inventory: {0}")]
    RecordFields(#[from] RuntimeRecordAdmissionError),
}

/// Storage value for `isize`-semantic runtime integers.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[repr(transparent)]
pub struct RuntimeISizeValue(i64);

impl RuntimeISizeValue {
    pub const fn new(value: i64) -> Self {
        Self(value)
    }

    pub const fn get(self) -> i64 {
        self.0
    }

    #[must_use]
    pub fn wrapping_neg(self) -> Self {
        Self(self.0.wrapping_neg())
    }
}

impl std::fmt::Display for RuntimeISizeValue {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.0.fmt(f)
    }
}

/// Storage value for `usize`-semantic runtime integers.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[repr(transparent)]
pub struct RuntimeUSizeValue(u64);

impl RuntimeUSizeValue {
    pub const fn new(value: u64) -> Self {
        Self(value)
    }

    pub const fn get(self) -> u64 {
        self.0
    }
}

impl std::fmt::Display for RuntimeUSizeValue {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.0.fmt(f)
    }
}

/// Exact integer storage that can cross runtime pure-helper fast paths without widening.
pub trait RuntimeExactInteger: Copy + 'static {
    const INPUT_TYPE: RuntimePureInputType;
    const OUTPUT_TYPE: RuntimePureOutputType;

    fn into_runtime_value(self) -> RuntimeValue;
    fn try_from_runtime_value(helper: &str, value: RuntimeValue) -> Result<Self, RuntimeEvalError>;
    fn try_sum_as_i64(self, helper: &str) -> Result<i64, RuntimeEvalError>;
    fn exact_slice(values: &[Self]) -> RuntimeExactIntegerSlice<'_>;
    fn exact_slice_mut(values: &mut [Self]) -> RuntimeExactIntegerSliceMut<'_>;
    fn seq_slice(seq: &RuntimeSeq) -> Option<&[Self]>;
    fn dense_sequence(values: Vec<Self>) -> RuntimeValue;
}

/// Borrowed exact-width integer slice used at runtime fast-path boundaries.
#[derive(Clone, Copy, Debug)]
pub enum RuntimeExactIntegerSlice<'a> {
    I8(&'a [i8]),
    I16(&'a [i16]),
    I32(&'a [i32]),
    I128(&'a [i128]),
    ISize(&'a [RuntimeISizeValue]),
    U8(&'a [u8]),
    U16(&'a [u16]),
    U32(&'a [u32]),
    U64(&'a [u64]),
    U128(&'a [u128]),
    USize(&'a [RuntimeUSizeValue]),
}

/// Mutable exact-width integer slice used at runtime fast-path output boundaries.
#[derive(Debug)]
pub enum RuntimeExactIntegerSliceMut<'a> {
    I8(&'a mut [i8]),
    I16(&'a mut [i16]),
    I32(&'a mut [i32]),
    I128(&'a mut [i128]),
    ISize(&'a mut [RuntimeISizeValue]),
    U8(&'a mut [u8]),
    U16(&'a mut [u16]),
    U32(&'a mut [u32]),
    U64(&'a mut [u64]),
    U128(&'a mut [u128]),
    USize(&'a mut [RuntimeUSizeValue]),
}

/// Homogeneous storage kind used by a dense runtime sequence.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Serialize)]
pub enum DenseSeqKind {
    Units,
    I8,
    I16,
    I32,
    I64,
    I128,
    ISize,
    U8,
    U16,
    U32,
    U64,
    U128,
    USize,
    F32,
    F64,
    Bool,
    Bytes,
    Chars,
    Durations,
    Strings,
    EntityRefs,
}

/// Dense sequence storage for homogeneous scalar data.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub enum DenseSeq {
    Units(usize),
    I8(DenseSeqStorage<i8>),
    I16(DenseSeqStorage<i16>),
    I32(DenseSeqStorage<i32>),
    I64(DenseSeqStorage<i64>),
    I128(DenseSeqStorage<i128>),
    ISize(DenseSeqStorage<RuntimeISizeValue>),
    U8(DenseSeqStorage<u8>),
    U16(DenseSeqStorage<u16>),
    U32(DenseSeqStorage<u32>),
    U64(DenseSeqStorage<u64>),
    U128(DenseSeqStorage<u128>),
    USize(DenseSeqStorage<RuntimeUSizeValue>),
    F32(#[serde(with = "float_storage_serde::width32")] DenseSeqStorage<f32>),
    F64(#[serde(with = "float_storage_serde::width64")] DenseSeqStorage<f64>),
    Bool(DenseSeqStorage<bool>),
    Bytes(DenseSeqStorage<u8>),
    Chars(DenseSeqStorage<char>),
    Durations(DenseSeqStorage<LogicalDuration>),
    Strings(DenseSeqStorage<String>),
    EntityRefs(DenseSeqStorage<RuntimeEntityReference>),
}

/// Generic backing store for one dense homogeneous sequence.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct DenseSeqStorage<T> {
    values: Vec<T>,
}

/// One recursively typed expression admitted into a runtime plan.
///
/// Construction is owned by `RuntimePlanBuilder`; the private type identity
/// and kind cannot be assembled independently or deserialized as a second
/// plan authority.
#[derive(Clone, PartialEq)]
pub struct RuntimeExpr {
    node: Arc<RuntimeExprData>,
}

/// One immutable admitted expression. Cloning a source reference retains this
/// complete owner, including guard obligations, without copying its value tree.
#[derive(Debug, PartialEq)]
struct RuntimeExprData {
    ty: RuntimePlanTypeId,
    kind: RuntimeExprKind,
    guard_copy_locals: Vec<RuntimeLocalDeclarationId>,
}

impl fmt::Debug for RuntimeExpr {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("RuntimeExpr")
            .field("ty", &self.ty())
            .field("kind", self.kind())
            .field("guard_copy_locals", &self.guard_copy_locals())
            .finish()
    }
}

/// How one checked local use transfers the value from its owning binding.
#[derive(
    Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd, serde::Deserialize, serde::Serialize,
)]
pub enum RuntimeLocalReadMode {
    Copy,
    Move,
}

/// One plan-owned local read. The semantic producer selects its transfer mode;
/// runtime execution never infers a move from the current value alone.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct RuntimeLocalRead {
    local: RuntimeLocalDeclarationId,
    mode: RuntimeLocalReadMode,
    fields: Box<[RuntimeRecordFieldId]>,
}

impl RuntimeLocalRead {
    pub(crate) fn from_admitted_parts(
        local: RuntimeLocalDeclarationId,
        mode: RuntimeLocalReadMode,
    ) -> Self {
        Self {
            local,
            mode,
            fields: Box::new([]),
        }
    }

    pub(crate) const fn from_admitted_place(
        local: RuntimeLocalDeclarationId,
        mode: RuntimeLocalReadMode,
        fields: Box<[RuntimeRecordFieldId]>,
    ) -> Self {
        Self {
            local,
            mode,
            fields,
        }
    }

    #[must_use]
    pub const fn local(&self) -> RuntimeLocalDeclarationId {
        self.local
    }

    #[must_use]
    pub const fn mode(&self) -> RuntimeLocalReadMode {
        self.mode
    }
    pub fn fields(&self) -> &[RuntimeRecordFieldId] {
        &self.fields
    }
}

/// Parameter identity retained by a checked standard `fmt` expression.
///
/// Core cannot depend on the language semantic crate, so this closed runtime
/// coordinate is the owner-neutral representation of the selected schema
/// parameter. Its index mapping matches the standard `fmt` schema order.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeFmtParameterId {
    Value,
    Style,
    Locale,
    Currency,
    NoneValue,
    Color,
    OnError,
    Fallback,
    DiscardError,
}

impl RuntimeFmtParameterId {
    /// Resolves the stable parameter coordinate used by the selected `fmt` schema.
    #[must_use]
    pub const fn from_index(index: usize) -> Option<Self> {
        match index {
            0 => Some(Self::Value),
            1 => Some(Self::Style),
            2 => Some(Self::Locale),
            3 => Some(Self::Currency),
            4 => Some(Self::NoneValue),
            5 => Some(Self::Color),
            6 => Some(Self::OnError),
            7 => Some(Self::Fallback),
            8 => Some(Self::DiscardError),
            _ => None,
        }
    }

    /// Returns the stable parameter coordinate used by the selected `fmt` schema.
    #[must_use]
    pub const fn index(self) -> usize {
        match self {
            Self::Value => 0,
            Self::Style => 1,
            Self::Locale => 2,
            Self::Currency => 3,
            Self::NoneValue => 4,
            Self::Color => 5,
            Self::OnError => 6,
            Self::Fallback => 7,
            Self::DiscardError => 8,
        }
    }
}

/// One selected `fmt` operand retained in authored source order.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeFormatContentOperand {
    definition: crate::plan::RuntimeFunctionDefinitionIdentity,
    parameter: RuntimeFmtParameterId,
    expression: RuntimeExpr,
}

impl RuntimeFormatContentOperand {
    pub(crate) const fn from_admitted_parts(
        definition: crate::plan::RuntimeFunctionDefinitionIdentity,
        parameter: RuntimeFmtParameterId,
        expression: RuntimeExpr,
    ) -> Self {
        Self {
            definition,
            parameter,
            expression,
        }
    }

    #[must_use]
    pub const fn parameter(&self) -> RuntimeFmtParameterId {
        self.parameter
    }

    #[must_use]
    pub const fn definition(&self) -> crate::plan::RuntimeFunctionDefinitionIdentity {
        self.definition
    }

    #[must_use]
    pub const fn expression(&self) -> &RuntimeExpr {
        &self.expression
    }
}

/// Writable place admitted as a local or a complete stored record field path.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeMutablePlace {
    Local(RuntimeLocalDeclarationId),
    Fields {
        base: RuntimeLocalDeclarationId,
        fields: Box<[RuntimeRecordFieldId]>,
    },
}

impl RuntimeMutablePlace {
    pub fn fields(&self) -> &[RuntimeRecordFieldId] {
        match self {
            Self::Local(_) => &[],
            Self::Fields { fields, .. } => fields,
        }
    }
    pub const fn local(&self) -> RuntimeLocalDeclarationId {
        match self {
            Self::Local(local) | Self::Fields { base: local, .. } => *local,
        }
    }
}

/// Checked runtime identity retained by an entity-reference expression or
/// pattern. Project identities preserve their accepted declaration family;
/// structural dialogue lines retain their typed runtime ID.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub enum RuntimeEntityReference {
    /// Inert target or typed slot identity; no declaration or lease authority.
    PresentationAddress(arcweft_interaction_model::presentation::PresentationAddressIdentity),
    StructuralFlow(crate::plan::FlowRuntimeId),
    ImportedProject(RuntimeImportedProjectEntityReference),
    Project {
        family: DeclarationIdentityFamily,
        #[serde(with = "runtime_public_id")]
        public_id: PublicId,
    },
    DialogueLine(RuntimeLineId),
    CharacterLook {
        character: arcweft_character::id::CharacterId,
        look: arcweft_character::id::CharacterLookId,
    },
}

/// Closed projection coordinate exposed by entity-reference values.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeEntityReferenceField {
    Id,
    Family,
    Name,
}

impl RuntimeEntityReferenceField {
    pub const ALL: [Self; 3] = [Self::Id, Self::Family, Self::Name];

    /// Resolves an exact source/wire field label through the closed vocabulary.
    #[must_use]
    pub fn from_label(label: &str) -> Option<Self> {
        Self::ALL
            .into_iter()
            .find(|field| field.as_label() == label)
    }

    #[must_use]
    pub const fn as_label(self) -> &'static str {
        match self {
            Self::Id => "id",
            Self::Family => "family",
            Self::Name => "name",
        }
    }
}

/// Closed field coordinates of the standard runtime Progress value.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeProgressField {
    Ratio,
    Label,
}

impl RuntimeProgressField {
    #[must_use]
    pub const fn as_label(self) -> &'static str {
        match self {
            Self::Ratio => "ratio",
            Self::Label => "label",
        }
    }
}

/// An operation evaluates an owned value or inspects an initialized stored
/// owner. Inspection is synchronous and may return only an unrestricted value;
/// the stored owner is never cloned or reconstructed for the operation.
#[derive(Clone, Debug, PartialEq)]
pub enum RuntimeValueTarget {
    Value(Box<RuntimeExpr>),
    /// Move this initialized owner only after the operation's preflight.
    Take {
        place: RuntimeMutablePlace,
        ty: RuntimePlanTypeId,
    },
    Inspect {
        place: RuntimeMutablePlace,
        ty: RuntimePlanTypeId,
    },
}

impl From<Box<RuntimeExpr>> for RuntimeValueTarget {
    fn from(value: Box<RuntimeExpr>) -> Self {
        Self::Value(value)
    }
}

impl RuntimeValueTarget {
    pub fn value(&self) -> Option<&RuntimeExpr> {
        match self {
            Self::Value(value) => Some(value),
            Self::Inspect { .. } | Self::Take { .. } => None,
        }
    }
    pub fn ty(&self) -> RuntimePlanTypeId {
        match self {
            Self::Value(value) => value.ty(),
            Self::Inspect { ty, .. } | Self::Take { ty, .. } => *ty,
        }
    }
}

/// Checked field projection retained by a runtime expression.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeFieldProjection {
    Nominal(RuntimeRecordFieldId),
    OpaqueRecord {
        owner: crate::pattern::RuntimeOpaqueTypeOwner,
        field: RuntimeRecordFieldId,
    },
    Agent(RuntimeAgentField),
    EntityReference(RuntimeEntityReferenceField),
    Progress(RuntimeProgressField),
}

impl RuntimeFieldProjection {
    /// Copies only the selected unrestricted child, never the complete owner.
    pub(crate) fn inspect(&self, value: &RuntimeValue) -> Result<RuntimeValue, RuntimeEvalError> {
        let selected = match (self, value) {
            (Self::Nominal(field), value) => value.record_field(*field),
            (Self::OpaqueRecord { owner, field }, RuntimeValue::Opaque(value))
                if owner.accepts_opaque_value(value) =>
            {
                match value.payload() {
                    RuntimeValue::Tuple(fields) => fields.get(field.zero_based() as usize),
                    _ => None,
                }
            }
            (Self::Agent(field), RuntimeValue::Record(fields))
                if field.permits_protocol_record() =>
            {
                fields
                    .iter()
                    .find(|entry| entry.name() == field.as_label())
                    .map(RuntimeFieldValue::value)
            }
            _ => None,
        };
        if let Some(selected) = selected {
            if !selected.ownership().permits_copy() {
                return Err(RuntimeEvalError::AffineFieldCopy);
            }
            return Ok(selected.clone());
        }
        let projected = match (self, value) {
            (Self::EntityReference(field), RuntimeValue::EntityRef(id)) => {
                Some(RuntimeValue::String(id.field_value(*field)))
            }
            (Self::Agent(field), RuntimeValue::Agent(value)) => value.project_typed_field(*field),
            (Self::Progress(field), RuntimeValue::Progress(progress)) => Some(match field {
                RuntimeProgressField::Ratio => RuntimeValue::F32(progress.ratio()),
                RuntimeProgressField::Label => progress
                    .label()
                    .map_or_else(RuntimeValue::option_none, |label| {
                        RuntimeValue::option_some(RuntimeValue::String(label.to_owned()))
                    }),
            }),
            _ => None,
        }
        .ok_or_else(|| RuntimeEvalError::MissingField {
            field: self.label(),
            value: runtime_value_label(value),
        })?;
        if !projected.ownership().permits_copy() {
            return Err(RuntimeEvalError::AffineFieldCopy);
        }
        Ok(projected)
    }

    #[must_use]
    pub fn label(&self) -> String {
        match self {
            Self::Nominal(field) => format!("field#{}", field.zero_based()),
            Self::OpaqueRecord { owner, field } => {
                format!("opaque:{owner:?}.field#{}", field.zero_based())
            }
            Self::Agent(field) => field.as_label().to_owned(),
            Self::EntityReference(field) => field.as_label().to_owned(),
            Self::Progress(field) => field.as_label().to_owned(),
        }
    }
}

impl RuntimeEntityReference {
    pub fn try_project(
        family: DeclarationIdentityFamily,
        public_id: PublicId,
    ) -> Result<Self, PublicIdFamilyError> {
        family.validate_public_id(&public_id)?;
        Ok(Self::Project { family, public_id })
    }

    #[must_use]
    pub const fn project_family(&self) -> Option<DeclarationIdentityFamily> {
        match self {
            Self::Project { family, .. } => Some(*family),
            Self::PresentationAddress(_) => None,
            Self::ImportedProject(value) => value.family().declaration_family(),
            Self::StructuralFlow(_) => Some(DeclarationIdentityFamily::Flow),
            Self::DialogueLine(_) | Self::CharacterLook { .. } => None,
        }
    }

    #[must_use]
    pub const fn character_look(
        &self,
    ) -> Option<(
        &arcweft_character::id::CharacterId,
        &arcweft_character::id::CharacterLookId,
    )> {
        match self {
            Self::CharacterLook { character, look } => Some((character, look)),
            Self::PresentationAddress(_) => None,
            Self::Project { .. }
            | Self::ImportedProject(_)
            | Self::StructuralFlow(_)
            | Self::DialogueLine(_) => None,
        }
    }

    #[must_use]
    pub fn runtime_label(&self) -> String {
        match self {
            Self::PresentationAddress(identity) => identity.public_id().as_str().to_owned(),
            Self::Project { public_id, .. } => public_id.as_str().to_owned(),
            Self::ImportedProject(value) => value.line().map_or_else(
                || value.public_id().as_str().to_owned(),
                RuntimeLineId::canonical_label,
            ),
            Self::StructuralFlow(flow) => flow.public_label().as_str().to_owned(),
            Self::DialogueLine(line) => line.canonical_label(),
            Self::CharacterLook { character, look } => {
                format!("{character}.look.{}", look.as_str())
            }
        }
    }

    /// Projects the typed reference into one of its explicit string fields.
    ///
    /// This is the only string projection used by field consumers; the
    /// resulting label is never interpreted as a new runtime identity.
    #[must_use]
    pub fn field_value(&self, field: RuntimeEntityReferenceField) -> String {
        let label = self.runtime_label();
        match field {
            RuntimeEntityReferenceField::Id => label,
            RuntimeEntityReferenceField::Family => label
                .split_once('.')
                .map_or_else(|| label.clone(), |(family, _)| family.to_owned()),
            RuntimeEntityReferenceField::Name => label
                .split_once('.')
                .map_or_else(String::new, |(_, name)| name.to_owned()),
        }
    }
}

impl RuntimeExpr {
    pub(crate) const fn source_node_storage_bytes() -> usize {
        size_of::<RuntimeExprData>() + 2 * size_of::<usize>() + size_of::<Self>()
    }

    pub(crate) fn from_admitted_parts(ty: RuntimePlanTypeId, kind: RuntimeExprKind) -> Self {
        Self::from_admitted_parts_with_guard_copy_locals(ty, kind, Vec::new())
    }

    pub(crate) fn from_admitted_parts_with_guard_copy_locals(
        ty: RuntimePlanTypeId,
        kind: RuntimeExprKind,
        guard_copy_locals: Vec<RuntimeLocalDeclarationId>,
    ) -> Self {
        Self {
            node: Arc::new(RuntimeExprData {
                ty,
                kind,
                guard_copy_locals,
            }),
        }
    }

    #[must_use]
    /// Pattern-local Copy leaves issued for this guard transaction.
    pub fn guard_copy_locals(&self) -> &[RuntimeLocalDeclarationId] {
        &self.node.guard_copy_locals
    }

    /// Constructs an admitted `DialogueContent` expression with effect-site
    /// callback captures.  The plan builder has already sealed the template,
    /// callback sites, and expression types before this constructor is used.
    pub(crate) fn dialogue_content_with_effects(
        ty: RuntimePlanTypeId,
        template: crate::runtime_id::RuntimeDialogueContentTemplateId,
        values: Vec<Self>,
        effects: Vec<RuntimeDialogueContentEffectBindingExpr>,
    ) -> Self {
        Self::from_admitted_parts(
            ty,
            RuntimeExprKind::DialogueContent {
                template,
                values,
                effects,
            },
        )
    }

    #[must_use]
    pub fn ty(&self) -> RuntimePlanTypeId {
        self.node.ty
    }

    #[must_use]
    pub fn kind(&self) -> &RuntimeExprKind {
        &self.node.kind
    }
}

/// Closed expression algebra. Every recursive value child is another typed
/// [`RuntimeExpr`]; spread is call-argument metadata rather than a fake node.
#[derive(Clone, Debug, PartialEq)]
pub enum RuntimeExprKind {
    Value(RuntimeValue),
    Agent(RuntimeAgentExpr),
    Local(RuntimeLocalRead),
    /// Reads an unrestricted value from the reached registry. The enclosing
    /// expression owns the checked result type, including `Option` for an optional read.
    RegistryRead {
        key: arcweft_id::LifetimeRegistryKey,
        kind: crate::effect::RuntimeRegistryReadKind,
    },
    /// Removes the first item from an admitted Vec place and returns `Option<T>`.
    SequencePopFront {
        place: RuntimeMutablePlace,
    },
    /// Appends one item to an admitted mutable Vec/Seq place and returns `Unit`.
    SequencePush {
        place: RuntimeMutablePlace,
        value: Box<RuntimeExpr>,
    },
    /// Removes the last item from an admitted Vec place and returns `Option<T>`.
    SequencePopBack {
        place: RuntimeMutablePlace,
    },
    EntityRef(RuntimeEntityReference),
    Let {
        binding: RuntimeLocalDeclarationId,
        expr: Box<RuntimeExpr>,
        body: Box<RuntimeExpr>,
    },
    Scope {
        identity: RuntimeScopeIdentity,
        body: Box<RuntimeExpr>,
    },
    Tuple(Vec<RuntimeExpr>),
    /// Constructs an exact `DialogueContent` envelope from values evaluated
    /// against the plan-owned immutable template manifest.
    DialogueContent {
        template: crate::runtime_id::RuntimeDialogueContentTemplateId,
        values: Vec<RuntimeExpr>,
        effects: Vec<RuntimeDialogueContentEffectBindingExpr>,
    },
    /// Evaluates selected standard `fmt` operands once in authored order and
    /// constructs one exact Formatted Content binding against its template.
    FormatContent {
        template: crate::runtime_id::RuntimeDialogueContentTemplateId,
        attempt: Option<crate::runtime_id::RuntimeFormatAttemptId>,
        operands: Vec<RuntimeFormatContentOperand>,
        project_method: Option<RuntimeTraitMethodId>,
        project_option: bool,
    },
    /// One checked CharacterDialogue factory or immutable reconfiguration.
    /// Every authored Set contribution remains an executable child.
    CharacterDialogue {
        operation: arcweft_interaction_model::dialogue::CharacterDialogueOperation,
        target: Box<RuntimeExpr>,
        fields: Vec<arcweft_interaction_model::dialogue::CharacterDialoguePatchField<RuntimeExpr>>,
    },
    BracketSeq(Vec<RuntimeExpr>),
    RepeatSeq {
        value: Box<RuntimeExpr>,
        len: usize,
    },
    /// Consumes a homogeneous Vec as the exact Array result type. The active
    /// type context checks its complete value before publication; no element
    /// is copied or replaced during this ownership transfer.
    ArrayFromVec {
        value: Box<RuntimeExpr>,
    },
    Range {
        start: Option<Box<RuntimeExpr>>,
        end: Option<Box<RuntimeExpr>>,
        inclusive: bool,
    },
    NominalRecord(RuntimeNominalRecordExpr),
    Variant {
        ordinal: u32,
        payload: Option<Box<RuntimeExpr>>,
    },
    Field {
        target: RuntimeValueTarget,
        field: RuntimeFieldProjection,
    },
    PresentationHandleMethod {
        method: arcweft_interaction_model::presentation::PresentationHandleMethodId,
        target: RuntimeValueTarget,
    },
    ProjectTuple {
        target: Box<RuntimeExpr>,
        ordinal: usize,
    },
    ProjectRecord {
        target: Box<RuntimeExpr>,
        ordinal: usize,
    },
    Assign {
        place: RuntimeAssignment,
        expr: Box<RuntimeExpr>,
        body: Box<RuntimeExpr>,
    },
    Call {
        callee: RuntimeCallTarget,
        args: Vec<RuntimeCallArgument>,
    },
    /// Constructs a structured function value from the exact outer-scope
    /// capture expressions supplied by the checked caller.  The function
    /// site's `Capture` input rows describe the callee ABI destination; they
    /// are never looked up in the outer environment by input-local id.
    MakeCallable {
        state: crate::runtime_id::RuntimeCallableStateId,
        captures: Vec<RuntimeExpr>,
    },
    SpecializeCallable {
        value: Box<RuntimeExpr>,
        specialization: crate::runtime_id::RuntimeCallableSpecializationId,
    },
    ApplyGroup {
        callee: Box<RuntimeExpr>,
        args: Vec<RuntimeCallArgument>,
    },
    TraitCall {
        callable: RuntimeTraitMethodId,
        receiver: Box<RuntimeExpr>,
        receiver_mode: RuntimeReceiverMode,
        args: Vec<RuntimeCallArgument>,
    },
    PureCall {
        helper: RuntimePureHelperId,
        args: Vec<RuntimeCallArgument>,
    },
    Sum {
        source: Box<RuntimeExpr>,
    },
    Unary {
        op: RuntimeUnaryOp,
        expr: Box<RuntimeExpr>,
    },
    Binary {
        lhs: Box<RuntimeExpr>,
        op: RuntimeBinaryOp,
        rhs: Box<RuntimeExpr>,
    },
    If {
        condition: Box<RuntimeExpr>,
        then_expr: Box<RuntimeExpr>,
        else_expr: Box<RuntimeExpr>,
    },
    IfLet {
        pattern: RuntimePattern,
        expr: Box<RuntimeExpr>,
        guard: Option<Box<RuntimeExpr>>,
        then_expr: Box<RuntimeExpr>,
        else_expr: Box<RuntimeExpr>,
    },
    Match {
        scrutinee: Box<RuntimeExpr>,
        arms: Vec<RuntimeExprMatchArm>,
    },
    /// Core `Reduction.unchanged` construction; no anonymous record or empty
    /// sequence is fabricated below the accepted call-result type.
    ReductionUnchanged {
        state: Box<RuntimeExpr>,
    },
}

/// Final plan-local callback binding for one content effect site.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeDialogueContentEffectBindingExpr {
    pub site: crate::runtime_id::RuntimeDialogueEffectSiteId,
    pub state: crate::runtime_id::RuntimeCallableStateId,
    pub captures: Vec<RuntimeExpr>,
}

/// Closed executable family of the standard `map` callable.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeStandardMapFamily {
    Vec,
    Seq,
    Array,
    Slice,
    Option,
    Result,
}

/// One call operand in resolved runtime order.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeCallArgument {
    value: RuntimeExpr,
    mode: RuntimeCallArgumentMode,
    abi_position: u32,
}

impl RuntimeCallArgument {
    pub(crate) const fn from_admitted_parts(
        value: RuntimeExpr,
        mode: RuntimeCallArgumentMode,
        abi_position: u32,
    ) -> Self {
        Self {
            value,
            mode,
            abi_position,
        }
    }

    #[must_use]
    pub const fn value(&self) -> &RuntimeExpr {
        &self.value
    }

    #[must_use]
    pub const fn mode(&self) -> RuntimeCallArgumentMode {
        self.mode
    }

    /// Returns the first logical ABI position occupied by this source
    /// argument. A spread argument occupies the statically admitted range
    /// beginning at this position; source evaluation remains in vector order.
    #[must_use]
    pub const fn abi_position(&self) -> u32 {
        self.abi_position
    }
}

/// Closed call-edge modifier after argument order has been resolved.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeCallArgumentMode {
    Value,
    Spread,
}

impl RuntimeExpr {
    /// Returns whether this expression can use the allocation-light scalar pure evaluator.
    pub fn supports_scalar_pure_eval(&self) -> bool {
        match self.kind() {
            RuntimeExprKind::Value(
                RuntimeValue::Bool(_)
                | RuntimeValue::Int(_)
                | RuntimeValue::UInt(_)
                | RuntimeValue::F32(_)
                | RuntimeValue::F64(_),
            )
            | RuntimeExprKind::Local(_) => true,
            RuntimeExprKind::Let { expr, body, .. } => {
                expr.supports_scalar_pure_eval() && body.supports_scalar_pure_eval()
            }
            RuntimeExprKind::Scope { body, .. } => body.supports_scalar_pure_eval(),
            RuntimeExprKind::Unary { expr, .. } => expr.supports_scalar_pure_eval(),
            RuntimeExprKind::Binary { lhs, rhs, .. } => {
                lhs.supports_scalar_pure_eval() && rhs.supports_scalar_pure_eval()
            }
            RuntimeExprKind::If {
                condition,
                then_expr,
                else_expr,
            } => {
                condition.supports_scalar_pure_eval()
                    && then_expr.supports_scalar_pure_eval()
                    && else_expr.supports_scalar_pure_eval()
            }
            RuntimeExprKind::Value(_)
            | RuntimeExprKind::Agent(_)
            | RuntimeExprKind::EntityRef(_)
            | RuntimeExprKind::Tuple(_)
            | RuntimeExprKind::DialogueContent { .. }
            | RuntimeExprKind::FormatContent { .. }
            | RuntimeExprKind::CharacterDialogue { .. }
            | RuntimeExprKind::BracketSeq(_)
            | RuntimeExprKind::RepeatSeq { .. }
            | RuntimeExprKind::ArrayFromVec { .. }
            | RuntimeExprKind::RegistryRead { .. }
            | RuntimeExprKind::Range { .. }
            | RuntimeExprKind::NominalRecord(_)
            | RuntimeExprKind::Variant { .. }
            | RuntimeExprKind::Field { .. }
            | RuntimeExprKind::PresentationHandleMethod { .. }
            | RuntimeExprKind::ProjectTuple { .. }
            | RuntimeExprKind::ProjectRecord { .. }
            | RuntimeExprKind::Assign { .. }
            | RuntimeExprKind::Call { .. }
            | RuntimeExprKind::MakeCallable { .. }
            | RuntimeExprKind::SpecializeCallable { .. }
            | RuntimeExprKind::ApplyGroup { .. }
            | RuntimeExprKind::TraitCall { .. }
            | RuntimeExprKind::PureCall { .. }
            | RuntimeExprKind::Sum { .. }
            | RuntimeExprKind::SequencePopFront { .. }
            | RuntimeExprKind::SequencePush { .. }
            | RuntimeExprKind::SequencePopBack { .. }
            | RuntimeExprKind::IfLet { .. }
            | RuntimeExprKind::Match { .. }
            | RuntimeExprKind::ReductionUnchanged { .. } => false,
        }
    }
}

impl fmt::Display for RuntimeExpr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.kind() {
            RuntimeExprKind::Value(value) => f.write_str(&runtime_value_label(value)),
            RuntimeExprKind::Agent(agent) => write!(f, "agent/{:?}", agent.constructor()),
            RuntimeExprKind::Local(read) => write!(f, "local#{}", read.local()),
            RuntimeExprKind::RegistryRead { key, kind } => {
                write!(f, "'{}", key.scope().as_str())?;
                for segment in key.segments() {
                    write!(f, ".{}", segment.as_str())?;
                }
                if *kind == crate::effect::RuntimeRegistryReadKind::Optional {
                    f.write_str("?")?;
                }
                Ok(())
            }
            RuntimeExprKind::SequencePopFront { place } => match place {
                RuntimeMutablePlace::Local(local) => {
                    write!(f, "vec_pop_front/local#{local}")
                }
                RuntimeMutablePlace::Fields { base, fields } => {
                    write!(f, "vec_pop_front/local#{base}")?;
                    for field in fields {
                        write!(f, ".field#{}", field.zero_based())?;
                    }
                    Ok(())
                }
            },
            RuntimeExprKind::SequencePush { place, .. } => match place {
                RuntimeMutablePlace::Local(local) => {
                    write!(f, "vec_push/local#{local}")
                }
                RuntimeMutablePlace::Fields { base, fields } => {
                    write!(f, "vec_push/local#{base}")?;
                    for field in fields {
                        write!(f, ".field#{}", field.zero_based())?;
                    }
                    Ok(())
                }
            },
            RuntimeExprKind::SequencePopBack { place } => match place {
                RuntimeMutablePlace::Local(local) => {
                    write!(f, "vec_pop_back/local#{local}")
                }
                RuntimeMutablePlace::Fields { base, fields } => {
                    write!(f, "vec_pop_back/local#{base}")?;
                    for field in fields {
                        write!(f, ".field#{}", field.zero_based())?;
                    }
                    Ok(())
                }
            },
            RuntimeExprKind::EntityRef(target) => write!(f, "@{}", target.runtime_label()),
            RuntimeExprKind::Let { binding, .. } => write!(f, "let local#{binding}"),
            RuntimeExprKind::Scope { identity, .. } => match identity.name() {
                Some(name) => write!(f, "scope {}", name.as_str()),
                None => f.write_str("scope"),
            },
            RuntimeExprKind::Tuple(items) => write!(f, "tuple/{}", items.len()),
            RuntimeExprKind::DialogueContent {
                template,
                values,
                effects,
            } => {
                write!(
                    f,
                    "dialogue_content/{template}/{}+{}",
                    values.len(),
                    effects.len()
                )
            }
            RuntimeExprKind::FormatContent {
                template,
                attempt,
                operands,
                project_method,
                project_option,
            } => {
                write!(
                    f,
                    "format_content/{template}/attempt={attempt:?}/{}/project={project_method:?}/option={project_option}",
                    operands.len(),
                )
            }
            RuntimeExprKind::CharacterDialogue {
                operation, fields, ..
            } => write!(f, "character_dialogue/{operation:?}/{}", fields.len()),
            RuntimeExprKind::BracketSeq(items) => write!(f, "bracket_seq/{}", items.len()),
            RuntimeExprKind::RepeatSeq { len, .. } => write!(f, "repeat_seq/{len}"),
            RuntimeExprKind::ArrayFromVec { .. } => f.write_str("array_from_vec"),
            RuntimeExprKind::Range { inclusive, .. } => f.write_str(if *inclusive {
                "range/inclusive"
            } else {
                "range"
            }),
            RuntimeExprKind::NominalRecord(record) => {
                write!(f, "nominal_record/{}", record.initializers().len())
            }
            RuntimeExprKind::Variant { ordinal, .. } => write!(f, "variant#{ordinal}"),
            RuntimeExprKind::Field { field, .. } => write!(f, ".{}", field.label()),
            RuntimeExprKind::PresentationHandleMethod { method, .. } => {
                write!(f, "presentation.handle.{method:?}()")
            }
            RuntimeExprKind::ProjectTuple { ordinal, .. } => write!(f, ".{ordinal}"),
            RuntimeExprKind::ProjectRecord { ordinal, .. } => write!(f, ".#{ordinal}"),
            RuntimeExprKind::Assign { place, .. } => {
                write!(f, "assign {place:?}")
            }
            RuntimeExprKind::Call { callee, .. } => write!(f, "{callee}()"),
            RuntimeExprKind::MakeCallable { state, captures } => {
                write!(f, "callable#{state}/retained{}", captures.len())
            }
            RuntimeExprKind::SpecializeCallable { specialization, .. } => {
                write!(f, "specialize#{specialization}")
            }
            RuntimeExprKind::ApplyGroup { .. } => f.write_str("apply"),
            RuntimeExprKind::TraitCall { callable, .. } => write!(f, "trait#{}()", callable.0),
            RuntimeExprKind::PureCall { helper, .. } => write!(f, "pure#{}()", helper.0),
            RuntimeExprKind::Sum { .. } => f.write_str("sum"),
            RuntimeExprKind::Unary { op, .. } => f.write_str(op.as_label()),
            RuntimeExprKind::Binary { op, .. } => f.write_str(op.as_label()),
            RuntimeExprKind::If { .. } => f.write_str("if"),
            RuntimeExprKind::IfLet { .. } => f.write_str("if let"),
            RuntimeExprKind::Match { .. } => f.write_str("match"),
            RuntimeExprKind::ReductionUnchanged { .. } => f.write_str("Reduction.unchanged"),
        }
    }
}

impl fmt::Display for RuntimeUnaryOp {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_label())
    }
}

impl fmt::Display for RuntimeBinaryOp {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_label())
    }
}

/// One value-producing `match` arm in a runtime expression.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeExprMatchArm {
    pattern: RuntimePattern,
    guard: Option<RuntimeExpr>,
    value: RuntimeExpr,
}

impl RuntimeExprMatchArm {
    pub(crate) const fn from_admitted_parts(
        pattern: RuntimePattern,
        guard: Option<RuntimeExpr>,
        value: RuntimeExpr,
    ) -> Self {
        Self {
            pattern,
            guard,
            value,
        }
    }

    pub const fn pattern(&self) -> &RuntimePattern {
        &self.pattern
    }

    pub const fn guard(&self) -> Option<&RuntimeExpr> {
        self.guard.as_ref()
    }

    pub const fn value(&self) -> &RuntimeExpr {
        &self.value
    }
}

/// Unary operator supported by the Sans I/O expression evaluator.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Serialize)]
pub enum RuntimeUnaryOp {
    Not,
    Neg,
}

impl RuntimeUnaryOp {
    pub const fn as_label(self) -> &'static str {
        match self {
            Self::Not => "!",
            Self::Neg => "-",
        }
    }
}

/// Binary operator supported by the Sans I/O expression evaluator.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Serialize)]
pub enum RuntimeBinaryOp {
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
    Add,
    Sub,
    Mul,
    Div,
    And,
    Or,
}

impl RuntimeBinaryOp {
    pub const fn as_label(self) -> &'static str {
        match self {
            Self::Eq => "==",
            Self::Ne => "!=",
            Self::Lt => "<",
            Self::Le => "<=",
            Self::Gt => ">",
            Self::Ge => ">=",
            Self::Add => "+",
            Self::Sub => "-",
            Self::Mul => "*",
            Self::Div => "/",
            Self::And => "&&",
            Self::Or => "||",
        }
    }

    fn unsupported_error(self, lhs: &RuntimeValue, rhs: &RuntimeValue) -> RuntimeEvalError {
        RuntimeEvalError::UnsupportedBinary {
            op: self.as_label(),
            lhs: runtime_value_label(lhs),
            rhs: runtime_value_label(rhs),
        }
    }
}

/// Native lexical storage. Live environments cannot be duplicated without
/// selecting and checking their unrestricted captures.
///
/// ```compile_fail
/// use arcweft_core::value::RuntimeEnv;
/// fn copy(env: &RuntimeEnv) { let _: RuntimeEnv = env.clone(); }
/// ```
#[derive(Debug)]
pub struct RuntimeEnv<V = RuntimeValue> {
    scopes: Vec<RuntimeScope<V>>,
    spare_scopes: Vec<RuntimeScope<V>>,
    assignment_discards: crate::line_task::RuntimeHandleDropAuthorization,
}

#[derive(Clone, Debug, PartialEq)]
struct RuntimeScope<T = RuntimeValue> {
    identity: RuntimeScopeIdentity,
    presentation_scope: Option<crate::presentation::resources::RuntimePresentationScopeBinding>,
    flow_registry: Option<crate::effect::RuntimeScopeRegistry>,
    function_context: RuntimeScopeFunctionContext,
    slots: Vec<RuntimeLocalSlot<T>>,
}

impl<T> Default for RuntimeScope<T> {
    fn default() -> Self {
        Self {
            identity: RuntimeScopeIdentity::default(),
            presentation_scope: None,
            flow_registry: None,
            function_context: RuntimeScopeFunctionContext::default(),
            slots: Vec::new(),
        }
    }
}

/// Lexical inheritance or the authenticated execution context of a function.
/// Suspended operations retain this same context independently of later calls.
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) enum RuntimeScopeFunctionContext {
    #[default]
    Lexical,
    Function {
        site: crate::runtime_id::RuntimeFunctionSiteId,
        input_order: std::sync::Arc<RuntimeInputOrder>,
        instantiation:
            Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
    },
}

/// One declaration identity and its current complete or partial place storage.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
#[serde(bound(
    serialize = "RuntimePlaceStorage<T>: Serialize",
    deserialize = "RuntimePlaceStorage<T>: Deserialize<'de>"
))]
pub struct RuntimeLocalSlot<T = RuntimeValue> {
    local: RuntimeLocalDeclarationId,
    value: RuntimePlaceStorage<T>,
}

impl<T> RuntimeLocalSlot<T> {
    pub(crate) const fn new(
        local: RuntimeLocalDeclarationId,
        value: RuntimePlaceStorage<T>,
    ) -> Self {
        Self { local, value }
    }
    pub const fn local(&self) -> RuntimeLocalDeclarationId {
        self.local
    }
    pub const fn storage(&self) -> &RuntimePlaceStorage<T> {
        &self.value
    }
    pub fn into_values(self) -> Vec<T> {
        self.value.into_values()
    }
}

impl RuntimeLocalSlot<AwbcRuntimeValueSnapshot> {
    pub(crate) fn into_admitted_live_for_program<'a>(
        self,
        owner: impl Into<crate::value::RuntimeValueRestoreContext<'a>>,
    ) -> Result<RuntimeLocalSlot, AwbcRuntimeValueSnapshotError> {
        let owner = owner.into();
        Ok(RuntimeLocalSlot::new(
            self.local,
            self.value.into_admitted_live_for_program(owner)?,
        ))
    }
}

impl From<RuntimeLocalBinding> for RuntimeLocalSlot {
    fn from(binding: RuntimeLocalBinding) -> Self {
        Self::new(binding.local, binding.value.into())
    }
}

/// Pure runtime program consumed by the minimal Sans I/O engine.

#[derive(Clone, Debug, Error, PartialEq)]
pub enum RuntimeEvalError {
    #[error(transparent)]
    FlowInvocation(Box<crate::plan::RuntimeFlowInvocationError>),
    #[error(transparent)]
    ExternalArguments(#[from] Box<crate::pure::RuntimeExternalCallArgumentError>),
    #[error(transparent)]
    Quantity(#[from] RuntimeOpaqueValueError),
    #[error(transparent)]
    ValueOwnership(#[from] ownership::RuntimeValueOwnershipAdmissionError),
    #[error("input capture repeats local {local:?}")]
    DuplicateLocalCapture { local: RuntimeLocalDeclarationId },
    #[error("native task request evaluation failed: {message}")]
    HostTaskRequest { message: String },
    #[error(transparent)]
    Presentation(#[from] crate::presentation::RuntimePresentationError),
    #[error(transparent)]
    Scope(#[from] crate::scope::RuntimeScopeExitError),
    #[error("native work admission failed: {source}")]
    NativeWorkAdmission {
        #[source]
        source: Box<AwbcRuntimeValueSnapshotError>,
    },
    #[error("registry read has no reached execution scope")]
    RegistryReadContextRequired,
    #[error("registry read admission failed: {0}")]
    RegistryReadAdmission(#[source] Box<AwbcRuntimeValueSnapshotError>),
    #[error(transparent)]
    RootRuntime(Box<crate::root::RootRuntimeError>),
    #[error(transparent)]
    IteratorWitness(#[from] RuntimeIteratorWitnessError),
    #[error("program {program} input {position} cannot transfer detached custody: {source}")]
    ProgramInputCustody {
        program: arcweft_id::runtime_program::RuntimePureProgramId,
        position: usize,
        #[source]
        source: ownership::RuntimeDetachedValueError,
    },
    #[error(transparent)]
    DetachedValueCustody(#[from] ownership::RuntimeDetachedValueError),
    #[error(transparent)]
    RecoverableExpression(#[from] RuntimeExpressionFailure),
    #[error("runtime fiber/execution identity space is exhausted")]
    FiberIdentityOverflow,
    #[error("scheduled dialogue callback has an invalid runtime lifecycle state")]
    InvalidScheduledLineTaskState,
    #[error("scheduled callback action has no live typed capture packet")]
    MissingScheduledCapturePacket,
    #[error("scheduled callback action has more than one live typed capture packet")]
    AmbiguousScheduledCapturePacket,
    #[error("scheduled callback action has more than one schedule owner")]
    AmbiguousScheduledCaptureOwner,
    #[error("scheduled callback affine capture graph violates its typed ownership packet")]
    InvalidScheduledCaptureGraph,
    #[error("unknown runtime binding `{0}`")]
    UnknownBinding(String),
    #[error("unknown runtime local declaration {0}")]
    UnknownLocal(RuntimeLocalDeclarationId),
    #[error("runtime local declaration {0} has no initialized value")]
    UninitializedLocal(RuntimeLocalDeclarationId),
    #[error("discarded runtime value has an invalid affine handle graph")]
    InvalidDiscardGraph,
    #[error("runtime local {0} contains an affine value and cannot be copied")]
    AffineLocalCopy(RuntimeLocalDeclarationId),
    #[error(transparent)]
    GuardReadInventory(#[from] RuntimeExprFreeLocalError),
    #[error("guard local {local} moves a pattern binding while later arms retain the scrutinee")]
    GuardMovedPatternBinding { local: RuntimeLocalDeclarationId },
    #[error("guard local {local} has no selected Copy obligation")]
    MissingGuardCopyRequirement { local: RuntimeLocalDeclarationId },
    #[error("a runtime expression literal contains an affine value and cannot be copied")]
    AffineLiteralCopy,
    #[error("an affine field cannot be copied by inspection")]
    AffineFieldCopy,
    #[error("unknown runtime plan type {0}")]
    UnknownPlanType(RuntimePlanTypeId),
    #[error("runtime plan type {0} has no nominal-record domain")]
    MissingNominalRecordDomain(RuntimePlanTypeId),
    #[error(transparent)]
    VariantCase(#[from] crate::plan::RuntimePlanVariantCaseError),
    #[error("runtime DialogueContent construction failed: {0}")]
    DialogueContentConstruction(String),
    #[error("runtime DialogueContent construction requires an artifact-bound plan")]
    DialogueContentUnboundArtifact,
    #[error("runtime CharacterDialogue construction requires an accepted generation producer")]
    CharacterDialogueProducerUnavailable,
    #[error("runtime CharacterDialogue construction failed: {0}")]
    CharacterDialogueConstruction(String),
    #[error(
        "runtime DialogueContent evaluated binding count {actual} does not match template count {expected}"
    )]
    DialogueContentBindingCount { expected: usize, actual: usize },
    #[error("runtime plan has no dialogue content template manifest for {template}")]
    MissingDialogueTemplateManifest {
        template: crate::runtime_id::RuntimeDialogueContentTemplateId,
    },
    #[error("runtime plan type {0} is not valid for this expression kind")]
    InvalidExpressionType(RuntimePlanTypeId),
    #[error(transparent)]
    PlanValueType(#[from] RuntimePlanValueTypeError),
    #[error("cannot construct Array type {ty} from {actual}")]
    ArrayConstruction {
        ty: RuntimePlanTypeId,
        actual: String,
    },
    #[error("nominal record type {ty} has no initializer for field {field}")]
    MissingRecordInitializer {
        ty: RuntimePlanTypeId,
        field: RuntimeRecordFieldId,
    },
    #[error("expected bool expression, found {0}")]
    ExpectedBool(String),
    #[error("expected integer expression, found {0}")]
    ExpectedInt(String),
    #[error("expected entity reference expression, found {0}")]
    ExpectedEntityRef(String),
    #[error("invalid entity target `{target}`: {reason}")]
    InvalidEntityTarget { target: String, reason: String },
    #[error("expected bracket sequence expression, found {0}")]
    ExpectedBracketSeq(String),
    #[error("expected a mutable runtime sequence, found {0}")]
    ExpectedSequence(String),
    #[error("runtime range is invalid: {reason}")]
    InvalidRange { reason: String },
    #[error("field `{field}` does not exist on {value}")]
    MissingField { field: String, value: String },
    #[error("cannot assign field `{field}` on {value}")]
    InvalidFieldAssignment { field: String, value: String },
    #[error("spread argument requires a tuple or bracket sequence, found {0}")]
    InvalidSpread(String),
    #[error("spread argument cannot be evaluated outside a call argument list")]
    SpreadOutsideCall,
    #[error("expected runtime function expression, found {0}")]
    ExpectedFunction(String),
    #[error("runtime function expected {expected} argument(s), found {found}")]
    FunctionArgumentCount { expected: usize, found: usize },
    #[error(transparent)]
    FunctionApply(#[from] RuntimeFunctionApplyError),
    #[error(transparent)]
    Callable(#[from] RuntimeCallableValueError),
    #[error("structured function site {site} belongs to a different admitted runtime plan")]
    ForeignStructuredFunction { site: RuntimeFunctionSiteId },
    #[error("runtime defer site {site} has no executable body in this plan")]
    UnknownDeferredSite {
        site: crate::runtime_id::RuntimeDeferSiteId,
    },
    #[error("structured function site {site} exhausted without a typed return")]
    FunctionFallthrough { site: RuntimeFunctionSiteId },
    #[error("structured function site {site} capture local {local} is not bound")]
    UnboundStructuredCapture {
        site: RuntimeFunctionSiteId,
        local: RuntimeLocalDeclarationId,
    },
    #[error(
        "runtime pure helper `{helper}` expected at most {max} fast-path argument(s), found {found}"
    )]
    TooManyPureArgs {
        helper: String,
        max: usize,
        found: usize,
    },
    #[error("runtime pure helper id {0} does not exist")]
    UnknownPureHelper(usize),
    #[error("runtime trait method id {0} does not exist")]
    UnknownTraitMethod(usize),
    #[error("trait method `{method}` expected {expected} argument(s), found {found}")]
    TraitMethodArgumentCount {
        method: String,
        expected: usize,
        found: usize,
    },
    #[error("trait method `{method}` cannot update receiver `{receiver}`")]
    InvalidTraitReceiverUpdate { method: String, receiver: String },
    #[error("operator `{op}` is not supported for {lhs} and {rhs}")]
    UnsupportedBinary {
        op: &'static str,
        lhs: String,
        rhs: String,
    },
    #[error("operator `{op}` is not supported for {value}")]
    UnsupportedUnary { op: &'static str, value: String },
    #[error("pure helper `{name}` cannot evaluate {reason}")]
    UnsupportedPure { name: String, reason: String },
    #[error("pattern did not match {0}")]
    PatternMismatch(String),
    #[error(transparent)]
    Pattern(#[from] crate::pattern::RuntimePatternMatchError),
    #[error("pattern binds `{0}` more than once")]
    DuplicateBinding(String),
    #[error("break value can only be consumed by a value-producing loop")]
    BreakValueOutsideValueLoop,
    #[error("loop control `{0}` reached a non-loop runtime context")]
    MisplacedLoopControl(&'static str),
    #[error("audio command error: {0}")]
    Audio(String),
    #[error(transparent)]
    StreamYield(#[from] crate::stream::RuntimeStreamYieldError),
    #[error("runtime effect error: {0}")]
    Effect(String),
    #[error("Agent value construction failed: {0}")]
    AgentConstruction(String),
    #[error("audio command expected {expected}, found {actual}")]
    AudioValue {
        expected: &'static str,
        actual: String,
    },
}

impl From<crate::root::RootRuntimeError> for RuntimeEvalError {
    fn from(error: crate::root::RootRuntimeError) -> Self {
        Self::RootRuntime(Box::new(error))
    }
}

/// A checked language-expression failure that a selected formatter may retain
/// as a failed display attempt. Other runtime errors remain fatal.
#[derive(Clone, Debug, Error, PartialEq)]
pub enum RuntimeExpressionFailure {
    #[error("division by zero")]
    DivisionByZero,
    #[error("core.option.unwrap called on None")]
    OptionUnwrapNone,
    #[error("index {index} is outside length {length}")]
    IndexOutOfBounds { index: String, length: usize },
}

impl RuntimeEvalError {
    pub const fn recoverable_expression(&self) -> Option<&RuntimeExpressionFailure> {
        match self {
            Self::RecoverableExpression(failure) => Some(failure),
            _ => None,
        }
    }
}

impl RuntimePayload {
    pub const fn new(value: RuntimeValue) -> Self {
        Self(value)
    }

    pub const fn value(&self) -> &RuntimeValue {
        &self.0
    }

    pub fn into_value(self) -> RuntimeValue {
        self.0
    }

    pub fn label(&self) -> String {
        runtime_value_label(&self.0)
    }
}

impl From<RuntimeValue> for RuntimePayload {
    fn from(value: RuntimeValue) -> Self {
        Self(value)
    }
}

impl From<RuntimePayload> for RuntimeValue {
    fn from(payload: RuntimePayload) -> Self {
        payload.into_value()
    }
}

impl From<String> for RuntimePayload {
    fn from(value: String) -> Self {
        Self(RuntimeValue::String(value))
    }
}

impl From<&str> for RuntimePayload {
    fn from(value: &str) -> Self {
        Self(RuntimeValue::String(value.to_owned()))
    }
}

pub(crate) fn evaluate_unary(
    op: RuntimeUnaryOp,
    value: RuntimeValue,
) -> Result<RuntimeValue, RuntimeEvalError> {
    match (op, value) {
        (RuntimeUnaryOp::Not, RuntimeValue::Bool(value)) => Ok(RuntimeValue::Bool(!value)),
        (RuntimeUnaryOp::Neg, RuntimeValue::Int(value)) => {
            Ok(RuntimeValue::Int(evaluate_signed_integer_neg(value)))
        }
        (RuntimeUnaryOp::Neg, RuntimeValue::F32(value)) => Ok(RuntimeValue::F32(-value)),
        (RuntimeUnaryOp::Neg, RuntimeValue::F64(value)) => Ok(RuntimeValue::F64(-value)),
        (RuntimeUnaryOp::Neg, RuntimeValue::Opaque(value)) => {
            let quantity = RuntimeQuantity::from_value(&value)
                .and_then(RuntimeQuantity::checked_neg)
                .ok_or_else(|| RuntimeEvalError::UnsupportedUnary {
                    op: "-",
                    value: format!("opaque/{}", value.producer().as_str()),
                })?;
            Ok(quantity.into_runtime_value(value.semantic_identity())?)
        }
        (op, value) => Err(RuntimeEvalError::UnsupportedUnary {
            op: op.as_label(),
            value: runtime_value_label(&value),
        }),
    }
}

pub(crate) fn evaluate_binary(
    lhs: RuntimeValue,
    op: RuntimeBinaryOp,
    rhs: RuntimeValue,
) -> Result<RuntimeValue, RuntimeEvalError> {
    match op {
        RuntimeBinaryOp::Eq => Ok(RuntimeValue::Bool(lhs == rhs)),
        RuntimeBinaryOp::Ne => Ok(RuntimeValue::Bool(lhs != rhs)),
        RuntimeBinaryOp::And => match (lhs, rhs) {
            (RuntimeValue::Bool(lhs), RuntimeValue::Bool(rhs)) => {
                Ok(RuntimeValue::Bool(lhs && rhs))
            }
            (lhs, rhs) => Err(op.unsupported_error(&lhs, &rhs)),
        },
        RuntimeBinaryOp::Or => match (lhs, rhs) {
            (RuntimeValue::Bool(lhs), RuntimeValue::Bool(rhs)) => {
                Ok(RuntimeValue::Bool(lhs || rhs))
            }
            (lhs, rhs) => Err(op.unsupported_error(&lhs, &rhs)),
        },
        RuntimeBinaryOp::Lt | RuntimeBinaryOp::Le | RuntimeBinaryOp::Gt | RuntimeBinaryOp::Ge => {
            match (lhs, rhs) {
                (RuntimeValue::Int(lhs), RuntimeValue::Int(rhs)) => {
                    evaluate_signed_integer_compare(lhs, op, rhs).map(RuntimeValue::Bool)
                }
                (RuntimeValue::UInt(lhs), RuntimeValue::UInt(rhs)) => {
                    evaluate_unsigned_integer_compare(lhs, op, rhs).map(RuntimeValue::Bool)
                }
                (RuntimeValue::F32(lhs), RuntimeValue::F32(rhs)) => {
                    Ok(RuntimeValue::Bool(compare_float(&lhs, op, &rhs)))
                }
                (RuntimeValue::F64(lhs), RuntimeValue::F64(rhs)) => {
                    Ok(RuntimeValue::Bool(compare_float(&lhs, op, &rhs)))
                }
                (lhs, rhs) => Err(op.unsupported_error(&lhs, &rhs)),
            }
        }
        RuntimeBinaryOp::Add
        | RuntimeBinaryOp::Sub
        | RuntimeBinaryOp::Mul
        | RuntimeBinaryOp::Div => match (lhs, rhs) {
            (RuntimeValue::Int(lhs), RuntimeValue::Int(rhs)) => {
                evaluate_signed_integer_op(lhs, op, rhs).map(RuntimeValue::Int)
            }
            (RuntimeValue::UInt(lhs), RuntimeValue::UInt(rhs)) => {
                evaluate_unsigned_integer_op(lhs, op, rhs).map(RuntimeValue::UInt)
            }
            (RuntimeValue::F32(lhs), RuntimeValue::F32(rhs)) => {
                evaluate_f32_op(lhs, op, rhs).map(RuntimeValue::F32)
            }
            (RuntimeValue::F64(lhs), RuntimeValue::F64(rhs)) => {
                evaluate_f64_op(lhs, op, rhs).map(RuntimeValue::F64)
            }
            (lhs, rhs) => Err(op.unsupported_error(&lhs, &rhs)),
        },
    }
}

pub fn evaluate_std_float_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
    if let Some(value) = evaluate_std_f32_intrinsic(intrinsic, args)? {
        return Ok(Some(value));
    }
    evaluate_std_f64_intrinsic(intrinsic, args)
}

pub fn evaluate_string_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
    let value = match (intrinsic, args) {
        (RuntimeIntrinsic::String(operation), [RuntimeValue::String(value)]) => {
            operation.evaluate(value)?
        }
        (RuntimeIntrinsic::String(_), _) => {
            return Err(RuntimeEvalError::UnsupportedPure {
                name: intrinsic.as_label().to_owned(),
                reason: "expected one String receiver".to_owned(),
            });
        }
        _ => return Ok(None),
    };
    Ok(Some(value))
}

/// Evaluates the closed capacity surface. Capacity is not observable, but
/// selected operands still have to be evaluated and checked exactly once.
pub fn evaluate_capacity_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
    let Some((family, operation)) = intrinsic.capacity_contract() else {
        return Ok(None);
    };
    let wrong_args = || RuntimeEvalError::UnsupportedPure {
        name: intrinsic.as_label().to_owned(),
        reason: "expected the selected collection receiver and usize capacity argument".to_owned(),
    };
    let receiver_matches = |value: &RuntimeValue| match (family, value) {
        (RuntimeCapacityFamily::Vec, RuntimeValue::Seq(_))
        | (RuntimeCapacityFamily::String, RuntimeValue::String(_)) => true,
        (RuntimeCapacityFamily::Bytes, RuntimeValue::Seq(sequence)) => {
            sequence.dense_kind() == Some(DenseSeqKind::Bytes)
        }
        _ => false,
    };
    let has_usize =
        |value: &RuntimeValue| matches!(value, RuntimeValue::UInt(RuntimeUInt::USize(_)));
    match operation {
        RuntimeCapacityOperation::Construct if matches!(args, [hint] if has_usize(hint)) => {
            Ok(Some(match family {
                RuntimeCapacityFamily::Vec => RuntimeValue::Seq(RuntimeSeq::values(Vec::new())),
                RuntimeCapacityFamily::String => RuntimeValue::String(String::new()),
                RuntimeCapacityFamily::Bytes => {
                    RuntimeValue::Seq(RuntimeSeq::dense_bytes(Vec::new()))
                }
            }))
        }
        RuntimeCapacityOperation::Hint if matches!(args, [receiver, hint] if receiver_matches(receiver) && has_usize(hint)) => {
            Ok(Some(RuntimeValue::Unit))
        }
        RuntimeCapacityOperation::Shrink if matches!(args, [receiver] if receiver_matches(receiver)) => {
            Ok(Some(RuntimeValue::Unit))
        }
        _ => Err(wrong_args()),
    }
}

pub fn evaluate_index_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
    if intrinsic != RuntimeIntrinsic::CoreIndex {
        return Ok(None);
    }
    let [target, index] = args else {
        return Err(index_intrinsic_error(
            "expected a target and an integer index",
        ));
    };
    let length = match target {
        RuntimeValue::Seq(sequence) if sequence.ownership().permits_copy() => sequence.len(),
        RuntimeValue::Seq(_) => {
            return Err(index_intrinsic_error(
                "cannot index a sequence with affine elements",
            ));
        }
        RuntimeValue::String(value) => value.chars().count(),
        _ => {
            return Err(index_intrinsic_error(
                "target is not an indexable runtime value",
            ));
        }
    };
    let numeric_index = match index {
        RuntimeValue::Int(value) => usize::try_from(value.as_i128()).ok(),
        RuntimeValue::UInt(value) => usize::try_from(value.as_u128()).ok(),
        _ => {
            return Err(index_intrinsic_error(
                "index is not an integer runtime value",
            ));
        }
    };
    let Some(numeric_index) = numeric_index.filter(|index| *index < length) else {
        return Err(RuntimeExpressionFailure::IndexOutOfBounds {
            index: runtime_value_label(index),
            length,
        }
        .into());
    };
    match target {
        RuntimeValue::Seq(sequence) => Ok(Some(sequence.value_at(numeric_index))),
        RuntimeValue::String(value) => Ok(Some(
            value
                .chars()
                .nth(numeric_index)
                .map(RuntimeValue::Char)
                .ok_or_else(|| index_intrinsic_error("String index changed during evaluation"))?,
        )),
        _ => Err(index_intrinsic_error(
            "indexable target changed during evaluation",
        )),
    }
}

fn index_intrinsic_error(reason: &str) -> RuntimeEvalError {
    RuntimeEvalError::UnsupportedPure {
        name: RuntimeIntrinsic::CoreIndex.as_label().to_owned(),
        reason: reason.to_owned(),
    }
}

fn evaluate_std_f32_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
    let value = match intrinsic {
        RuntimeIntrinsic::StdF32Abs => RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.abs()),
        RuntimeIntrinsic::StdF32Floor => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.floor())
        }
        RuntimeIntrinsic::StdF32Ceil => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.ceil())
        }
        RuntimeIntrinsic::StdF32Round => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.round())
        }
        RuntimeIntrinsic::StdF32Trunc => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.trunc())
        }
        RuntimeIntrinsic::StdF32Fract => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.fract())
        }
        RuntimeIntrinsic::StdF32Sqrt => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.sqrt())
        }
        RuntimeIntrinsic::StdF32Sin => RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.sin()),
        RuntimeIntrinsic::StdF32Cos => RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.cos()),
        RuntimeIntrinsic::StdF32Tan => RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.tan()),
        RuntimeIntrinsic::StdF32Exp => RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.exp()),
        RuntimeIntrinsic::StdF32Exp2 => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.exp2())
        }
        RuntimeIntrinsic::StdF32Ln => RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.ln()),
        RuntimeIntrinsic::StdF32Log2 => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.log2())
        }
        RuntimeIntrinsic::StdF32Log10 => {
            RuntimeValue::F32(expect_unary_f32(intrinsic, args)?.log10())
        }
        RuntimeIntrinsic::StdF32Powf => {
            let (lhs, rhs) = expect_binary_f32(intrinsic, args)?;
            RuntimeValue::F32(lhs.powf(rhs))
        }
        RuntimeIntrinsic::StdF32Atan2 => {
            let (lhs, rhs) = expect_binary_f32(intrinsic, args)?;
            RuntimeValue::F32(lhs.atan2(rhs))
        }
        RuntimeIntrinsic::StdF32MulAdd => {
            let (a, b, c) = expect_ternary_f32(intrinsic, args)?;
            RuntimeValue::F32(a.mul_add(b, c))
        }
        RuntimeIntrinsic::StdF32IsNan => {
            RuntimeValue::Bool(expect_unary_f32(intrinsic, args)?.is_nan())
        }
        RuntimeIntrinsic::StdF32IsInfinite => {
            RuntimeValue::Bool(expect_unary_f32(intrinsic, args)?.is_infinite())
        }
        RuntimeIntrinsic::StdF32IsFinite => {
            RuntimeValue::Bool(expect_unary_f32(intrinsic, args)?.is_finite())
        }
        RuntimeIntrinsic::StdF32IsSignPositive => {
            RuntimeValue::Bool(expect_unary_f32(intrinsic, args)?.is_sign_positive())
        }
        RuntimeIntrinsic::StdF32IsSignNegative => {
            RuntimeValue::Bool(expect_unary_f32(intrinsic, args)?.is_sign_negative())
        }
        RuntimeIntrinsic::StdF32ToBits => {
            RuntimeValue::u32(expect_unary_f32(intrinsic, args)?.to_bits())
        }
        RuntimeIntrinsic::StdF32FromBits => {
            RuntimeValue::F32(f32::from_bits(expect_unary_u32(intrinsic, args)?))
        }
        RuntimeIntrinsic::StdF32ToF64 => {
            RuntimeValue::F64(f64::from(expect_unary_f32(intrinsic, args)?))
        }
        _ => return Ok(None),
    };
    Ok(Some(value))
}

fn evaluate_std_f64_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
    let value = match intrinsic {
        RuntimeIntrinsic::StdF64Abs => RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.abs()),
        RuntimeIntrinsic::StdF64Floor => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.floor())
        }
        RuntimeIntrinsic::StdF64Ceil => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.ceil())
        }
        RuntimeIntrinsic::StdF64Round => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.round())
        }
        RuntimeIntrinsic::StdF64Trunc => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.trunc())
        }
        RuntimeIntrinsic::StdF64Fract => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.fract())
        }
        RuntimeIntrinsic::StdF64Sqrt => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.sqrt())
        }
        RuntimeIntrinsic::StdF64Sin => RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.sin()),
        RuntimeIntrinsic::StdF64Cos => RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.cos()),
        RuntimeIntrinsic::StdF64Tan => RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.tan()),
        RuntimeIntrinsic::StdF64Exp => RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.exp()),
        RuntimeIntrinsic::StdF64Exp2 => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.exp2())
        }
        RuntimeIntrinsic::StdF64Ln => RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.ln()),
        RuntimeIntrinsic::StdF64Log2 => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.log2())
        }
        RuntimeIntrinsic::StdF64Log10 => {
            RuntimeValue::F64(expect_unary_f64(intrinsic, args)?.log10())
        }
        RuntimeIntrinsic::StdF64Powf => {
            let (lhs, rhs) = expect_binary_f64(intrinsic, args)?;
            RuntimeValue::F64(lhs.powf(rhs))
        }
        RuntimeIntrinsic::StdF64Atan2 => {
            let (lhs, rhs) = expect_binary_f64(intrinsic, args)?;
            RuntimeValue::F64(lhs.atan2(rhs))
        }
        RuntimeIntrinsic::StdF64MulAdd => {
            let (a, b, c) = expect_ternary_f64(intrinsic, args)?;
            RuntimeValue::F64(a.mul_add(b, c))
        }
        RuntimeIntrinsic::StdF64IsNan => {
            RuntimeValue::Bool(expect_unary_f64(intrinsic, args)?.is_nan())
        }
        RuntimeIntrinsic::StdF64IsInfinite => {
            RuntimeValue::Bool(expect_unary_f64(intrinsic, args)?.is_infinite())
        }
        RuntimeIntrinsic::StdF64IsFinite => {
            RuntimeValue::Bool(expect_unary_f64(intrinsic, args)?.is_finite())
        }
        RuntimeIntrinsic::StdF64IsSignPositive => {
            RuntimeValue::Bool(expect_unary_f64(intrinsic, args)?.is_sign_positive())
        }
        RuntimeIntrinsic::StdF64IsSignNegative => {
            RuntimeValue::Bool(expect_unary_f64(intrinsic, args)?.is_sign_negative())
        }
        RuntimeIntrinsic::StdF64ToBits => {
            RuntimeValue::u64(expect_unary_f64(intrinsic, args)?.to_bits())
        }
        RuntimeIntrinsic::StdF64FromBits => {
            RuntimeValue::F64(f64::from_bits(expect_unary_u64(intrinsic, args)?))
        }
        RuntimeIntrinsic::StdF64ToF32 => {
            RuntimeValue::F32(narrow_f64_to_f32(expect_unary_f64(intrinsic, args)?))
        }
        _ => return Ok(None),
    };
    Ok(Some(value))
}

#[expect(
    clippy::cast_possible_truncation,
    reason = "std.f64.to_f32 is the explicit Arcweft narrowing operation"
)]
fn narrow_f64_to_f32(value: f64) -> f32 {
    value as f32
}

fn expect_unary_f32(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<f32, RuntimeEvalError> {
    match args {
        [RuntimeValue::F32(value)] => Ok(*value),
        _ => Err(float_intrinsic_arg_error(intrinsic, "f32", args)),
    }
}

fn expect_binary_f32(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<(f32, f32), RuntimeEvalError> {
    match args {
        [RuntimeValue::F32(lhs), RuntimeValue::F32(rhs)] => Ok((*lhs, *rhs)),
        _ => Err(float_intrinsic_arg_error(intrinsic, "f32, f32", args)),
    }
}

fn expect_ternary_f32(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<(f32, f32, f32), RuntimeEvalError> {
    match args {
        [
            RuntimeValue::F32(a),
            RuntimeValue::F32(b),
            RuntimeValue::F32(c),
        ] => Ok((*a, *b, *c)),
        _ => Err(float_intrinsic_arg_error(intrinsic, "f32, f32, f32", args)),
    }
}

fn expect_unary_f64(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<f64, RuntimeEvalError> {
    match args {
        [RuntimeValue::F64(value)] => Ok(*value),
        _ => Err(float_intrinsic_arg_error(intrinsic, "f64", args)),
    }
}

fn expect_binary_f64(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<(f64, f64), RuntimeEvalError> {
    match args {
        [RuntimeValue::F64(lhs), RuntimeValue::F64(rhs)] => Ok((*lhs, *rhs)),
        _ => Err(float_intrinsic_arg_error(intrinsic, "f64, f64", args)),
    }
}

fn expect_ternary_f64(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<(f64, f64, f64), RuntimeEvalError> {
    match args {
        [
            RuntimeValue::F64(a),
            RuntimeValue::F64(b),
            RuntimeValue::F64(c),
        ] => Ok((*a, *b, *c)),
        _ => Err(float_intrinsic_arg_error(intrinsic, "f64, f64, f64", args)),
    }
}

fn expect_unary_u32(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<u32, RuntimeEvalError> {
    match args {
        [RuntimeValue::UInt(value)] => value
            .try_into_u32()
            .ok_or_else(|| float_intrinsic_arg_error(intrinsic, "u32", args)),
        _ => Err(float_intrinsic_arg_error(intrinsic, "u32", args)),
    }
}

fn expect_unary_u64(
    intrinsic: RuntimeIntrinsic,
    args: &[RuntimeValue],
) -> Result<u64, RuntimeEvalError> {
    match args {
        [RuntimeValue::UInt(value)] => value
            .exact_u64()
            .ok_or_else(|| float_intrinsic_arg_error(intrinsic, "u64", args)),
        _ => Err(float_intrinsic_arg_error(intrinsic, "u64", args)),
    }
}

fn float_intrinsic_arg_error(
    intrinsic: RuntimeIntrinsic,
    expected: &'static str,
    args: &[RuntimeValue],
) -> RuntimeEvalError {
    RuntimeEvalError::UnsupportedPure {
        name: intrinsic.as_label().to_owned(),
        reason: format!(
            "expected ({expected}), got ({})",
            args.iter()
                .map(runtime_value_label)
                .collect::<Vec<_>>()
                .join(", ")
        ),
    }
}

fn compare_ordered<T: Ord>(lhs: &T, op: RuntimeBinaryOp, rhs: &T) -> bool {
    match op {
        RuntimeBinaryOp::Lt => lhs < rhs,
        RuntimeBinaryOp::Le => lhs <= rhs,
        RuntimeBinaryOp::Gt => lhs > rhs,
        RuntimeBinaryOp::Ge => lhs >= rhs,
        _ => unreachable!(),
    }
}

fn compare_float<T: PartialOrd>(lhs: &T, op: RuntimeBinaryOp, rhs: &T) -> bool {
    match op {
        RuntimeBinaryOp::Lt => lhs < rhs,
        RuntimeBinaryOp::Le => lhs <= rhs,
        RuntimeBinaryOp::Gt => lhs > rhs,
        RuntimeBinaryOp::Ge => lhs >= rhs,
        _ => unreachable!(),
    }
}

fn evaluate_signed_integer_compare(
    lhs: RuntimeInt,
    op: RuntimeBinaryOp,
    rhs: RuntimeInt,
) -> Result<bool, RuntimeEvalError> {
    match (lhs, rhs) {
        (RuntimeInt::I8(lhs), RuntimeInt::I8(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeInt::I16(lhs), RuntimeInt::I16(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeInt::I32(lhs), RuntimeInt::I32(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeInt::I64(lhs), RuntimeInt::I64(rhs))
        | (RuntimeInt::ISize(lhs), RuntimeInt::ISize(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeInt::I128(lhs), RuntimeInt::I128(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (lhs, rhs) => Err(op.unsupported_error(&RuntimeValue::Int(lhs), &RuntimeValue::Int(rhs))),
    }
}

fn evaluate_unsigned_integer_compare(
    lhs: RuntimeUInt,
    op: RuntimeBinaryOp,
    rhs: RuntimeUInt,
) -> Result<bool, RuntimeEvalError> {
    match (lhs, rhs) {
        (RuntimeUInt::U8(lhs), RuntimeUInt::U8(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeUInt::U16(lhs), RuntimeUInt::U16(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeUInt::U32(lhs), RuntimeUInt::U32(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeUInt::U64(lhs), RuntimeUInt::U64(rhs))
        | (RuntimeUInt::USize(lhs), RuntimeUInt::USize(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (RuntimeUInt::U128(lhs), RuntimeUInt::U128(rhs)) => Ok(compare_ordered(&lhs, op, &rhs)),
        (lhs, rhs) => Err(op.unsupported_error(&RuntimeValue::UInt(lhs), &RuntimeValue::UInt(rhs))),
    }
}

fn evaluate_signed_integer_neg(value: RuntimeInt) -> RuntimeInt {
    match value {
        RuntimeInt::I8(value) => RuntimeInt::I8(value.wrapping_neg()),
        RuntimeInt::I16(value) => RuntimeInt::I16(value.wrapping_neg()),
        RuntimeInt::I32(value) => RuntimeInt::I32(value.wrapping_neg()),
        RuntimeInt::I64(value) => RuntimeInt::I64(value.wrapping_neg()),
        RuntimeInt::I128(value) => RuntimeInt::I128(value.wrapping_neg()),
        RuntimeInt::ISize(value) => RuntimeInt::ISize(value.wrapping_neg()),
    }
}

fn evaluate_signed_integer_op(
    lhs: RuntimeInt,
    op: RuntimeBinaryOp,
    rhs: RuntimeInt,
) -> Result<RuntimeInt, RuntimeEvalError> {
    match (lhs, rhs) {
        (RuntimeInt::I8(lhs), RuntimeInt::I8(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeInt::I8)
        }
        (RuntimeInt::I16(lhs), RuntimeInt::I16(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeInt::I16)
        }
        (RuntimeInt::I32(lhs), RuntimeInt::I32(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeInt::I32)
        }
        (RuntimeInt::I64(lhs), RuntimeInt::I64(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeInt::I64)
        }
        (RuntimeInt::I128(lhs), RuntimeInt::I128(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeInt::I128)
        }
        (RuntimeInt::ISize(lhs), RuntimeInt::ISize(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeInt::ISize)
        }
        (lhs, rhs) => Err(op.unsupported_error(&RuntimeValue::Int(lhs), &RuntimeValue::Int(rhs))),
    }
}

fn evaluate_unsigned_integer_op(
    lhs: RuntimeUInt,
    op: RuntimeBinaryOp,
    rhs: RuntimeUInt,
) -> Result<RuntimeUInt, RuntimeEvalError> {
    match (lhs, rhs) {
        (RuntimeUInt::U8(lhs), RuntimeUInt::U8(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeUInt::U8)
        }
        (RuntimeUInt::U16(lhs), RuntimeUInt::U16(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeUInt::U16)
        }
        (RuntimeUInt::U32(lhs), RuntimeUInt::U32(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeUInt::U32)
        }
        (RuntimeUInt::U64(lhs), RuntimeUInt::U64(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeUInt::U64)
        }
        (RuntimeUInt::U128(lhs), RuntimeUInt::U128(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeUInt::U128)
        }
        (RuntimeUInt::USize(lhs), RuntimeUInt::USize(rhs)) => {
            evaluate_numeric_op(lhs, op, rhs).map(RuntimeUInt::USize)
        }
        (lhs, rhs) => Err(op.unsupported_error(&RuntimeValue::UInt(lhs), &RuntimeValue::UInt(rhs))),
    }
}

fn evaluate_f32_op(lhs: f32, op: RuntimeBinaryOp, rhs: f32) -> Result<f32, RuntimeEvalError> {
    evaluate_numeric_op(lhs, op, rhs)
}

fn evaluate_f64_op(lhs: f64, op: RuntimeBinaryOp, rhs: f64) -> Result<f64, RuntimeEvalError> {
    evaluate_numeric_op(lhs, op, rhs)
}

pub(crate) trait RuntimeDeterministicNumeric: Copy {
    fn add(lhs: Self, rhs: Self) -> Self;
    fn sub(lhs: Self, rhs: Self) -> Self;
    fn mul(lhs: Self, rhs: Self) -> Self;
    fn div(lhs: Self, rhs: Self) -> Option<Self>;
}

macro_rules! impl_wrapping_numeric {
    ($($ty:ty),* $(,)?) => {
        $(
            impl RuntimeDeterministicNumeric for $ty {
                fn add(lhs: Self, rhs: Self) -> Self {
                    lhs.wrapping_add(rhs)
                }

                fn sub(lhs: Self, rhs: Self) -> Self {
                    lhs.wrapping_sub(rhs)
                }

                fn mul(lhs: Self, rhs: Self) -> Self {
                    lhs.wrapping_mul(rhs)
                }

                fn div(lhs: Self, rhs: Self) -> Option<Self> {
                    (rhs != 0).then(|| lhs.wrapping_div(rhs))
                }
            }
        )*
    };
}

macro_rules! impl_float_numeric {
    ($($ty:ty),* $(,)?) => {
        $(
            impl RuntimeDeterministicNumeric for $ty {
                fn add(lhs: Self, rhs: Self) -> Self {
                    lhs + rhs
                }

                fn sub(lhs: Self, rhs: Self) -> Self {
                    lhs - rhs
                }

                fn mul(lhs: Self, rhs: Self) -> Self {
                    lhs * rhs
                }

                fn div(lhs: Self, rhs: Self) -> Option<Self> {
                    Some(lhs / rhs)
                }
            }
        )*
    };
}

impl_wrapping_numeric!(i8, i16, i32, i64, i128, u8, u16, u32, u64, u128);
impl_float_numeric!(f32, f64);

impl RuntimeDeterministicNumeric for RuntimeISizeValue {
    fn add(lhs: Self, rhs: Self) -> Self {
        Self(lhs.0.wrapping_add(rhs.0))
    }

    fn sub(lhs: Self, rhs: Self) -> Self {
        Self(lhs.0.wrapping_sub(rhs.0))
    }

    fn mul(lhs: Self, rhs: Self) -> Self {
        Self(lhs.0.wrapping_mul(rhs.0))
    }

    fn div(lhs: Self, rhs: Self) -> Option<Self> {
        (rhs.0 != 0).then(|| Self(lhs.0.wrapping_div(rhs.0)))
    }
}

impl RuntimeDeterministicNumeric for RuntimeUSizeValue {
    fn add(lhs: Self, rhs: Self) -> Self {
        Self(lhs.0.wrapping_add(rhs.0))
    }

    fn sub(lhs: Self, rhs: Self) -> Self {
        Self(lhs.0.wrapping_sub(rhs.0))
    }

    fn mul(lhs: Self, rhs: Self) -> Self {
        Self(lhs.0.wrapping_mul(rhs.0))
    }

    fn div(lhs: Self, rhs: Self) -> Option<Self> {
        (rhs.0 != 0).then(|| Self(lhs.0.wrapping_div(rhs.0)))
    }
}

pub(crate) fn evaluate_numeric_op<T: RuntimeDeterministicNumeric>(
    lhs: T,
    op: RuntimeBinaryOp,
    rhs: T,
) -> Result<T, RuntimeEvalError> {
    let value = match op {
        RuntimeBinaryOp::Add => Some(T::add(lhs, rhs)),
        RuntimeBinaryOp::Sub => Some(T::sub(lhs, rhs)),
        RuntimeBinaryOp::Mul => Some(T::mul(lhs, rhs)),
        RuntimeBinaryOp::Div => T::div(lhs, rhs),
        _ => unreachable!(),
    };
    value.ok_or(RuntimeExpressionFailure::DivisionByZero.into())
}

pub(crate) fn sum_i64_sequence_ref(items: &[RuntimeValue]) -> Result<i64, RuntimeEvalError> {
    items.iter().try_fold(0_i64, |acc, item| match item {
        RuntimeValue::Int(value) => value
            .try_sum_as_i64()
            .map(|value| acc.wrapping_add(value))
            .ok_or_else(|| RuntimeEvalError::UnsupportedBinary {
                op: "+",
                lhs: "int".to_owned(),
                rhs: runtime_value_label(item),
            }),
        RuntimeValue::UInt(value) => value
            .try_sum_as_i64()
            .map(|value| acc.wrapping_add(value))
            .ok_or_else(|| RuntimeEvalError::UnsupportedBinary {
                op: "+",
                lhs: "int".to_owned(),
                rhs: runtime_value_label(item),
            }),
        value => Err(RuntimeEvalError::UnsupportedBinary {
            op: "+",
            lhs: "int".to_owned(),
            rhs: runtime_value_label(value),
        }),
    })
}

pub(crate) fn materialize_i64_sequence(items: Vec<i64>) -> Vec<RuntimeValue> {
    items.into_iter().map(RuntimeValue::i64).collect()
}

pub fn evaluate_core_range_intrinsic(
    args: &[RuntimeValue],
) -> Result<RuntimeValue, RuntimeEvalError> {
    let [start, end, RuntimeValue::Bool(inclusive)] = args else {
        return Err(RuntimeEvalError::InvalidRange {
            reason: format!(
                "core.range expected (start|(), end|(), bool), got ({})",
                args.iter()
                    .map(runtime_value_label)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
        });
    };
    let start = range_intrinsic_bound(start);
    let end = range_intrinsic_bound(end);
    RuntimeRange::new(start, end, *inclusive).map(RuntimeValue::Range)
}

fn range_intrinsic_bound(value: &RuntimeValue) -> Option<RuntimeValue> {
    if matches!(value, RuntimeValue::Unit) {
        None
    } else {
        Some(value.clone())
    }
}

pub fn evaluate_core_iter_collect_intrinsic(
    value: RuntimeValue,
) -> Result<RuntimeValue, RuntimeEvalError> {
    RuntimeIterator::from_value(value)
        .map(Iterator::collect)
        .map(runtime_sequence_values)
        .map_err(|value| RuntimeEvalError::ExpectedBracketSeq(runtime_value_label(&value)))
}

pub fn evaluate_core_iter_into_iter_intrinsic(
    value: RuntimeValue,
    family: crate::plan::RuntimeBuiltinIteratorFamily,
) -> Result<RuntimeValue, RuntimeEvalError> {
    RuntimeIterator::from_value_with_builtin_family(value, family)
        .map(RuntimeValue::Iterator)
        .map_err(|value| RuntimeEvalError::ExpectedBracketSeq(runtime_value_label(&value)))
}

pub fn evaluate_core_iter_next_intrinsic(
    value: RuntimeValue,
) -> Result<RuntimeValue, RuntimeEvalError> {
    let RuntimeValue::Iterator(mut iterator) = value else {
        return Err(RuntimeEvalError::ExpectedBracketSeq(format!(
            "core.iter.next expected iterator, found {}",
            runtime_value_label(&value)
        )));
    };
    let item = iterator
        .next()
        .map_or_else(RuntimeValue::option_none, RuntimeValue::option_some);
    Ok(RuntimeValue::Tuple(vec![
        RuntimeValue::Iterator(iterator),
        item,
    ]))
}

pub(crate) fn evaluate_core_iterator_intrinsic(
    intrinsic: RuntimeIntrinsic,
    args: &mut Vec<RuntimeValue>,
) -> Option<Result<RuntimeValue, RuntimeEvalError>> {
    match (intrinsic, args.as_slice()) {
        (RuntimeIntrinsic::CoreIterCollect, [_]) => Some(evaluate_core_iter_collect_intrinsic(
            args.pop().expect("one matched core iterator argument"),
        )),
        (intrinsic, [_]) if intrinsic.builtin_iterator_family().is_some() => {
            Some(evaluate_core_iter_into_iter_intrinsic(
                args.pop().expect("one matched core iterator argument"),
                intrinsic
                    .builtin_iterator_family()
                    .expect("guard retains a built-in iterator family"),
            ))
        }
        (RuntimeIntrinsic::CoreIterNext, [_]) => Some(evaluate_core_iter_next_intrinsic(
            args.pop().expect("one matched core iterator argument"),
        )),
        (RuntimeIntrinsic::CoreOptionIsSome, [value]) => {
            Some(evaluate_core_option_is_some_intrinsic(value))
        }
        (RuntimeIntrinsic::CoreOptionUnwrap, [_]) => Some(evaluate_core_option_unwrap_intrinsic(
            args.pop().expect("one matched core iterator argument"),
        )),
        _ => None,
    }
}

pub fn runtime_sequence_values(values: Vec<RuntimeValue>) -> RuntimeValue {
    RuntimeValue::Seq(RuntimeSeq::values(values))
}

pub fn runtime_sequence_from_literal_values(values: Vec<RuntimeValue>) -> RuntimeValue {
    match values.first().cloned() {
        Some(RuntimeValue::Unit)
            if values
                .iter()
                .all(|value| matches!(value, RuntimeValue::Unit)) =>
        {
            runtime_sequence_dense_units(values.len())
        }
        Some(RuntimeValue::Bool(_)) => collect_dense_or_values(
            values,
            take_bool_value,
            RuntimeValue::Bool,
            runtime_sequence_dense_bool,
        ),
        Some(RuntimeValue::Int(value)) => collect_runtime_int_dense_or_values(values, value),
        Some(RuntimeValue::UInt(value)) => collect_runtime_uint_dense_or_values(values, value),
        Some(RuntimeValue::F32(_)) => collect_dense_or_values(
            values,
            take_f32_value,
            RuntimeValue::F32,
            runtime_sequence_dense_f32,
        ),
        Some(RuntimeValue::F64(_)) => collect_dense_or_values(
            values,
            take_f64_value,
            RuntimeValue::F64,
            runtime_sequence_dense_f64,
        ),
        Some(RuntimeValue::Char(_)) => collect_dense_or_values(
            values,
            take_char_value,
            RuntimeValue::Char,
            runtime_sequence_dense_chars,
        ),
        Some(RuntimeValue::Duration(_)) => collect_dense_or_values(
            values,
            take_duration_value,
            RuntimeValue::Duration,
            runtime_sequence_dense_durations,
        ),
        Some(RuntimeValue::String(_)) => collect_dense_or_values(
            values,
            take_string_value,
            RuntimeValue::String,
            runtime_sequence_dense_strings,
        ),
        Some(RuntimeValue::EntityRef(_)) => collect_dense_or_values(
            values,
            take_entity_ref_value,
            RuntimeValue::EntityRef,
            runtime_sequence_dense_entity_refs,
        ),
        Some(RuntimeValue::Tuple(_)) => collect_tuple_columns_or_values(values),
        Some(RuntimeValue::Record(_)) => collect_record_columns_or_values(values),
        _ => runtime_sequence_values(values),
    }
}

fn collect_dense_or_values<T>(
    values: Vec<RuntimeValue>,
    extract: impl Fn(RuntimeValue) -> Result<T, RuntimeValue>,
    rebuild: impl Fn(T) -> RuntimeValue,
    wrap: impl Fn(Vec<T>) -> RuntimeValue,
) -> RuntimeValue {
    let mut dense = Vec::with_capacity(values.len());
    let mut iter = values.into_iter();
    while let Some(value) = iter.next() {
        match extract(value) {
            Ok(value) => dense.push(value),
            Err(value) => {
                let mut fallback = dense.into_iter().map(rebuild).collect::<Vec<_>>();
                fallback.push(value);
                fallback.extend(iter);
                return runtime_sequence_values(fallback);
            }
        }
    }
    wrap(dense)
}

fn take_bool_value(value: RuntimeValue) -> Result<bool, RuntimeValue> {
    match value {
        RuntimeValue::Bool(value) => Ok(value),
        value => Err(value),
    }
}

fn collect_runtime_int_dense_or_values(
    values: Vec<RuntimeValue>,
    first: RuntimeInt,
) -> RuntimeValue {
    match first {
        RuntimeInt::I8(_) => collect_dense_or_values(
            values,
            take_i8_value,
            RuntimeValue::i8,
            runtime_sequence_dense_i8,
        ),
        RuntimeInt::I16(_) => collect_dense_or_values(
            values,
            take_i16_value,
            RuntimeValue::i16,
            runtime_sequence_dense_i16,
        ),
        RuntimeInt::I32(_) => collect_dense_or_values(
            values,
            take_i32_value,
            RuntimeValue::i32,
            runtime_sequence_dense_i32,
        ),
        RuntimeInt::I64(_) => collect_dense_or_values(
            values,
            take_i64_value,
            RuntimeValue::i64,
            runtime_sequence_dense_i64,
        ),
        RuntimeInt::I128(_) => collect_dense_or_values(
            values,
            take_i128_value,
            RuntimeValue::i128,
            runtime_sequence_dense_i128,
        ),
        RuntimeInt::ISize(_) => collect_dense_or_values(
            values,
            take_isize_value,
            RuntimeValue::isize,
            runtime_sequence_dense_isize,
        ),
    }
}

fn collect_runtime_uint_dense_or_values(
    values: Vec<RuntimeValue>,
    first: RuntimeUInt,
) -> RuntimeValue {
    match first {
        RuntimeUInt::U8(_) => collect_dense_or_values(
            values,
            take_u8_value,
            RuntimeValue::u8,
            runtime_sequence_dense_u8,
        ),
        RuntimeUInt::U16(_) => collect_dense_or_values(
            values,
            take_u16_value,
            RuntimeValue::u16,
            runtime_sequence_dense_u16,
        ),
        RuntimeUInt::U32(_) => collect_dense_or_values(
            values,
            take_u32_value,
            RuntimeValue::u32,
            runtime_sequence_dense_u32,
        ),
        RuntimeUInt::U64(_) => collect_dense_or_values(
            values,
            take_u64_value,
            RuntimeValue::u64,
            runtime_sequence_dense_u64,
        ),
        RuntimeUInt::U128(_) => collect_dense_or_values(
            values,
            take_u128_value,
            RuntimeValue::u128,
            runtime_sequence_dense_u128,
        ),
        RuntimeUInt::USize(_) => collect_dense_or_values(
            values,
            take_usize_value,
            RuntimeValue::usize,
            runtime_sequence_dense_usize,
        ),
    }
}

fn take_i8_value(value: RuntimeValue) -> Result<i8, RuntimeValue> {
    match value {
        RuntimeValue::Int(RuntimeInt::I8(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_i16_value(value: RuntimeValue) -> Result<i16, RuntimeValue> {
    match value {
        RuntimeValue::Int(RuntimeInt::I16(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_i32_value(value: RuntimeValue) -> Result<i32, RuntimeValue> {
    match value {
        RuntimeValue::Int(RuntimeInt::I32(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_i64_value(value: RuntimeValue) -> Result<i64, RuntimeValue> {
    match value {
        RuntimeValue::Int(RuntimeInt::I64(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_i128_value(value: RuntimeValue) -> Result<i128, RuntimeValue> {
    match value {
        RuntimeValue::Int(RuntimeInt::I128(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_isize_value(value: RuntimeValue) -> Result<i64, RuntimeValue> {
    match value {
        RuntimeValue::Int(RuntimeInt::ISize(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_u8_value(value: RuntimeValue) -> Result<u8, RuntimeValue> {
    match value {
        RuntimeValue::UInt(RuntimeUInt::U8(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_u16_value(value: RuntimeValue) -> Result<u16, RuntimeValue> {
    match value {
        RuntimeValue::UInt(RuntimeUInt::U16(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_u32_value(value: RuntimeValue) -> Result<u32, RuntimeValue> {
    match value {
        RuntimeValue::UInt(RuntimeUInt::U32(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_u64_value(value: RuntimeValue) -> Result<u64, RuntimeValue> {
    match value {
        RuntimeValue::UInt(RuntimeUInt::U64(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_u128_value(value: RuntimeValue) -> Result<u128, RuntimeValue> {
    match value {
        RuntimeValue::UInt(RuntimeUInt::U128(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_usize_value(value: RuntimeValue) -> Result<u64, RuntimeValue> {
    match value {
        RuntimeValue::UInt(RuntimeUInt::USize(value)) => Ok(value),
        value => Err(value),
    }
}

fn take_f32_value(value: RuntimeValue) -> Result<f32, RuntimeValue> {
    match value {
        RuntimeValue::F32(value) => Ok(value),
        value => Err(value),
    }
}

fn take_f64_value(value: RuntimeValue) -> Result<f64, RuntimeValue> {
    match value {
        RuntimeValue::F64(value) => Ok(value),
        value => Err(value),
    }
}

fn take_char_value(value: RuntimeValue) -> Result<char, RuntimeValue> {
    match value {
        RuntimeValue::Char(value) => Ok(value),
        value => Err(value),
    }
}

fn take_duration_value(value: RuntimeValue) -> Result<LogicalDuration, RuntimeValue> {
    match value {
        RuntimeValue::Duration(value) => Ok(value),
        value => Err(value),
    }
}

fn take_string_value(value: RuntimeValue) -> Result<String, RuntimeValue> {
    match value {
        RuntimeValue::String(value) => Ok(value),
        value => Err(value),
    }
}

fn take_entity_ref_value(value: RuntimeValue) -> Result<RuntimeEntityReference, RuntimeValue> {
    match value {
        RuntimeValue::EntityRef(value) => Ok(value),
        value => Err(value),
    }
}

fn collect_tuple_columns_or_values(values: Vec<RuntimeValue>) -> RuntimeValue {
    let mut rows = Vec::with_capacity(values.len());
    let mut iter = values.into_iter();
    while let Some(value) = iter.next() {
        let RuntimeValue::Tuple(items) = value else {
            let mut fallback = rows
                .into_iter()
                .map(RuntimeValue::Tuple)
                .collect::<Vec<_>>();
            fallback.push(value);
            fallback.extend(iter);
            return runtime_sequence_values(fallback);
        };
        rows.push(items);
    }
    tuple_rows_to_columnar(rows).map_or_else(runtime_sequence_values, |seq| {
        RuntimeValue::Seq(RuntimeSeq::TupleColumns(seq))
    })
}

fn tuple_rows_to_columnar(mut rows: Vec<Vec<RuntimeValue>>) -> Result<TupleSeq, Vec<RuntimeValue>> {
    let len = rows.len();
    let Some(first) = rows.first() else {
        return TupleSeq::new(0, Vec::new()).map_err(|_| Vec::new());
    };
    let width = first.len();
    if rows.iter().any(|row| row.len() != width) {
        return Err(rows.into_iter().map(RuntimeValue::Tuple).collect());
    }
    let mut columns = (0..width)
        .map(|_| Vec::with_capacity(len))
        .collect::<Vec<_>>();
    for row in &mut rows {
        for (ordinal, value) in row.drain(..).enumerate() {
            columns[ordinal].push(value);
        }
    }
    let columns = columns
        .into_iter()
        .map(runtime_sequence_from_literal_values)
        .map(|value| match value {
            RuntimeValue::Seq(seq) => seq,
            value => RuntimeSeq::Values(vec![value]),
        })
        .collect();
    TupleSeq::new(len, columns).map_err(|_| rows.into_iter().map(RuntimeValue::Tuple).collect())
}

fn collect_record_columns_or_values(values: Vec<RuntimeValue>) -> RuntimeValue {
    let mut rows = Vec::with_capacity(values.len());
    let mut iter = values.into_iter();
    while let Some(value) = iter.next() {
        let RuntimeValue::Record(fields) = value else {
            let mut fallback = rows
                .into_iter()
                .map(RuntimeValue::Record)
                .collect::<Vec<_>>();
            fallback.push(value);
            fallback.extend(iter);
            return runtime_sequence_values(fallback);
        };
        rows.push(fields);
    }
    record_rows_to_columnar(rows).map_or_else(runtime_sequence_values, |seq| {
        RuntimeValue::Seq(RuntimeSeq::RecordColumns(seq))
    })
}

fn record_rows_to_columnar(rows: Vec<RuntimeRecordValue>) -> Result<RecordSeq, Vec<RuntimeValue>> {
    let len = rows.len();
    let Some(first) = rows.first() else {
        return Ok(
            RecordSeq::try_from_accepted_fields(0, Vec::new()).expect("empty record columns")
        );
    };
    if rows.iter().any(|row| !first.same_layout(row)) {
        return Err(rows.into_iter().map(RuntimeValue::Record).collect());
    }
    let mut columns = first
        .iter()
        .map(|field| (field.name().to_owned(), Vec::with_capacity(len)))
        .collect::<Vec<_>>();
    for row in rows {
        for (field, (_, values)) in row.into_iter().zip(&mut columns) {
            values.push(field.into_value());
        }
    }
    let fields = columns
        .into_iter()
        .map(|(name, values)| {
            let RuntimeValue::Seq(values) = runtime_sequence_from_literal_values(values) else {
                unreachable!("sequence literal lowering returns a sequence");
            };
            (name, values)
        })
        .collect();
    Ok(RecordSeq::try_from_accepted_fields(len, fields)
        .expect("admitted rows retain their layout and column lengths"))
}

pub(crate) fn runtime_value_into_sequence_values(
    value: RuntimeValue,
) -> Result<Vec<RuntimeValue>, RuntimeValue> {
    match value {
        RuntimeValue::Seq(seq) => Ok(seq.into_values()),
        RuntimeValue::Tuple(values) => Ok(values),
        value => Err(value),
    }
}

pub(crate) fn runtime_value_label(value: &RuntimeValue) -> String {
    value
        .view()
        .label(None)
        .expect("live storage has representable dimensions")
        .into_owned()
}

impl RuntimeLocalReadMode {
    pub(crate) const fn semantic_tag(self) -> u8 {
        match self {
            Self::Copy => 0,
            Self::Move => 1,
        }
    }

    pub(crate) const fn from_semantic_tag(tag: u8) -> Option<Self> {
        match tag {
            0 => Some(Self::Copy),
            1 => Some(Self::Move),
            _ => None,
        }
    }
}

impl RuntimeCallArgumentMode {
    pub(crate) const fn semantic_tag(self) -> u8 {
        match self {
            Self::Value => 0,
            Self::Spread => 1,
        }
    }
}

impl RuntimeStandardMapFamily {
    pub(crate) const fn from_semantic_tag(tag: u8) -> Option<Self> {
        match tag {
            0 => Some(Self::Vec),
            1 => Some(Self::Seq),
            2 => Some(Self::Array),
            3 => Some(Self::Slice),
            4 => Some(Self::Option),
            5 => Some(Self::Result),
            _ => None,
        }
    }

    pub(crate) const fn semantic_tag(self) -> u8 {
        match self {
            Self::Vec => 0,
            Self::Seq => 1,
            Self::Array => 2,
            Self::Slice => 3,
            Self::Option => 4,
            Self::Result => 5,
        }
    }
}

impl RuntimeUnaryOp {
    pub(crate) const fn semantic_tag(self) -> u8 {
        match self {
            Self::Not => 0,
            Self::Neg => 1,
        }
    }
}

impl RuntimeBinaryOp {
    pub(crate) const fn semantic_tag(self) -> u8 {
        match self {
            Self::Eq => 0,
            Self::Ne => 1,
            Self::Lt => 2,
            Self::Le => 3,
            Self::Gt => 4,
            Self::Ge => 5,
            Self::Add => 6,
            Self::Sub => 7,
            Self::Mul => 8,
            Self::Div => 9,
            Self::And => 10,
            Self::Or => 11,
        }
    }
}

impl RuntimeExprKind {
    pub(crate) const fn semantic_tag(&self) -> u8 {
        match self {
            Self::Value(_) => 0,
            Self::Agent(_) => 1,
            Self::Local(_) => 2,
            Self::SequencePopFront { .. } => 3,
            Self::SequencePush { .. } => 4,
            Self::SequencePopBack { .. } => 5,
            Self::EntityRef(_) => 6,
            Self::Let { .. } => 7,
            Self::Scope { .. } => 8,
            Self::Tuple(_) => 9,
            Self::DialogueContent { .. } => 10,
            Self::FormatContent { .. } => 11,
            Self::CharacterDialogue { .. } => 12,
            Self::BracketSeq(_) => 13,
            Self::RepeatSeq { .. } => 14,
            Self::Range { .. } => 15,
            Self::NominalRecord(_) => 16,
            Self::Variant { .. } => 17,
            Self::Field { .. } => 18,
            Self::ProjectTuple { .. } => 19,
            Self::ProjectRecord { .. } => 20,
            Self::Assign { .. } => 21,
            Self::Call { .. } => 22,
            Self::MakeCallable { .. } => 23,
            Self::SpecializeCallable { .. } => 24,
            Self::ApplyGroup { .. } => 25,
            Self::TraitCall { .. } => 26,
            Self::PureCall { .. } => 27,
            Self::Sum { .. } => 29,
            Self::Unary { .. } => 30,
            Self::Binary { .. } => 31,
            Self::If { .. } => 32,
            Self::IfLet { .. } => 33,
            Self::Match { .. } => 34,
            Self::ReductionUnchanged { .. } => 35,
            Self::ArrayFromVec { .. } => 36,
            Self::RegistryRead { .. } => 38,
            Self::PresentationHandleMethod { .. } => 37,
        }
    }
}

impl RuntimeIntrinsic {
    pub(crate) const fn semantic_tag(self) -> u8 {
        match self {
            Self::Add => 0,
            Self::CoreRange => 1,
            Self::CoreIterCollect => 2,
            Self::CoreRangeIntoIter => 3,
            Self::CoreSeqIntoIter => 4,
            Self::CoreStreamIntoIter => 5,
            Self::CoreVecIntoIter => 6,
            Self::CoreArrayIntoIter => 7,
            Self::CoreSliceIntoIter => 8,
            Self::CoreTupleIntoIter => 9,
            Self::CoreIterNext => 10,
            Self::CoreOptionIsSome => 11,
            Self::CoreOptionUnwrap => 12,
            Self::StdOptionContext => 13,
            Self::StdOptionWithContext => 14,
            Self::StdResultContext => 15,
            Self::StdResultWithContext => 16,
            Self::CoreIndex => 17,
            Self::String(operation) => operation.intrinsic_tag(),
            Self::VecWithCapacity => 20,
            Self::StringWithCapacity => 21,
            Self::BytesWithCapacity => 22,
            Self::VecReserve => 23,
            Self::StringReserve => 24,
            Self::BytesReserve => 25,
            Self::VecShrinkTo => 26,
            Self::StringShrinkTo => 27,
            Self::BytesShrinkTo => 28,
            Self::VecShrink => 29,
            Self::StringShrink => 30,
            Self::BytesShrink => 31,
            Self::StdF32Abs => 32,
            Self::StdF32Floor => 33,
            Self::StdF32Ceil => 34,
            Self::StdF32Round => 35,
            Self::StdF32Trunc => 36,
            Self::StdF32Fract => 37,
            Self::StdF32Sqrt => 38,
            Self::StdF32Sin => 39,
            Self::StdF32Cos => 40,
            Self::StdF32Tan => 41,
            Self::StdF32Exp => 42,
            Self::StdF32Exp2 => 43,
            Self::StdF32Ln => 44,
            Self::StdF32Log2 => 45,
            Self::StdF32Log10 => 46,
            Self::StdF32Powf => 47,
            Self::StdF32Atan2 => 48,
            Self::StdF32MulAdd => 49,
            Self::StdF32IsNan => 50,
            Self::StdF32IsInfinite => 51,
            Self::StdF32IsFinite => 52,
            Self::StdF32IsSignPositive => 53,
            Self::StdF32IsSignNegative => 54,
            Self::StdF32ToBits => 55,
            Self::StdF32FromBits => 56,
            Self::StdF32ToF64 => 57,
            Self::StdF64Abs => 58,
            Self::StdF64Floor => 59,
            Self::StdF64Ceil => 60,
            Self::StdF64Round => 61,
            Self::StdF64Trunc => 62,
            Self::StdF64Fract => 63,
            Self::StdF64Sqrt => 64,
            Self::StdF64Sin => 65,
            Self::StdF64Cos => 66,
            Self::StdF64Tan => 67,
            Self::StdF64Exp => 68,
            Self::StdF64Exp2 => 69,
            Self::StdF64Ln => 70,
            Self::StdF64Log2 => 71,
            Self::StdF64Log10 => 72,
            Self::StdF64Powf => 73,
            Self::StdF64Atan2 => 74,
            Self::StdF64MulAdd => 75,
            Self::StdF64IsNan => 76,
            Self::StdF64IsInfinite => 77,
            Self::StdF64IsFinite => 78,
            Self::StdF64IsSignPositive => 79,
            Self::StdF64IsSignNegative => 80,
            Self::StdF64ToBits => 81,
            Self::StdF64FromBits => 82,
            Self::StdF64ToF32 => 83,
            Self::MathMatmulF32 => 84,
            Self::MathMatrixAddF32 => 85,
            Self::MathTensorAddF32 => 86,
            Self::MathMatmulF64 => 87,
            Self::MathMatrixAddF64 => 88,
            Self::MathTensorAddF64 => 89,
            Self::CoreSeqLen => 90,
            Self::CoreSeqSum => 91,
            Self::CoreRequireUnrestricted => 92,
            Self::CoreFanoutInputs => 93,
        }
    }

    pub(crate) const fn from_source_tag(tag: u8) -> Option<Self> {
        if let Some(operation) = RuntimeStringOperation::from_intrinsic_tag(tag) {
            return Some(Self::String(operation));
        }
        match tag {
            0 => Some(Self::Add),
            1 => Some(Self::CoreRange),
            2 => Some(Self::CoreIterCollect),
            3 => Some(Self::CoreRangeIntoIter),
            4 => Some(Self::CoreSeqIntoIter),
            5 => Some(Self::CoreStreamIntoIter),
            6 => Some(Self::CoreVecIntoIter),
            7 => Some(Self::CoreArrayIntoIter),
            8 => Some(Self::CoreSliceIntoIter),
            9 => Some(Self::CoreTupleIntoIter),
            10 => Some(Self::CoreIterNext),
            11 => Some(Self::CoreOptionIsSome),
            12 => Some(Self::CoreOptionUnwrap),
            13 => Some(Self::StdOptionContext),
            14 => Some(Self::StdOptionWithContext),
            15 => Some(Self::StdResultContext),
            16 => Some(Self::StdResultWithContext),
            17 => Some(Self::CoreIndex),
            20 => Some(Self::VecWithCapacity),
            21 => Some(Self::StringWithCapacity),
            22 => Some(Self::BytesWithCapacity),
            23 => Some(Self::VecReserve),
            24 => Some(Self::StringReserve),
            25 => Some(Self::BytesReserve),
            26 => Some(Self::VecShrinkTo),
            27 => Some(Self::StringShrinkTo),
            28 => Some(Self::BytesShrinkTo),
            29 => Some(Self::VecShrink),
            30 => Some(Self::StringShrink),
            31 => Some(Self::BytesShrink),
            32 => Some(Self::StdF32Abs),
            33 => Some(Self::StdF32Floor),
            34 => Some(Self::StdF32Ceil),
            35 => Some(Self::StdF32Round),
            36 => Some(Self::StdF32Trunc),
            37 => Some(Self::StdF32Fract),
            38 => Some(Self::StdF32Sqrt),
            39 => Some(Self::StdF32Sin),
            40 => Some(Self::StdF32Cos),
            41 => Some(Self::StdF32Tan),
            42 => Some(Self::StdF32Exp),
            43 => Some(Self::StdF32Exp2),
            44 => Some(Self::StdF32Ln),
            45 => Some(Self::StdF32Log2),
            46 => Some(Self::StdF32Log10),
            47 => Some(Self::StdF32Powf),
            48 => Some(Self::StdF32Atan2),
            49 => Some(Self::StdF32MulAdd),
            50 => Some(Self::StdF32IsNan),
            51 => Some(Self::StdF32IsInfinite),
            52 => Some(Self::StdF32IsFinite),
            53 => Some(Self::StdF32IsSignPositive),
            54 => Some(Self::StdF32IsSignNegative),
            55 => Some(Self::StdF32ToBits),
            56 => Some(Self::StdF32FromBits),
            57 => Some(Self::StdF32ToF64),
            58 => Some(Self::StdF64Abs),
            59 => Some(Self::StdF64Floor),
            60 => Some(Self::StdF64Ceil),
            61 => Some(Self::StdF64Round),
            62 => Some(Self::StdF64Trunc),
            63 => Some(Self::StdF64Fract),
            64 => Some(Self::StdF64Sqrt),
            65 => Some(Self::StdF64Sin),
            66 => Some(Self::StdF64Cos),
            67 => Some(Self::StdF64Tan),
            68 => Some(Self::StdF64Exp),
            69 => Some(Self::StdF64Exp2),
            70 => Some(Self::StdF64Ln),
            71 => Some(Self::StdF64Log2),
            72 => Some(Self::StdF64Log10),
            73 => Some(Self::StdF64Powf),
            74 => Some(Self::StdF64Atan2),
            75 => Some(Self::StdF64MulAdd),
            76 => Some(Self::StdF64IsNan),
            77 => Some(Self::StdF64IsInfinite),
            78 => Some(Self::StdF64IsFinite),
            79 => Some(Self::StdF64IsSignPositive),
            80 => Some(Self::StdF64IsSignNegative),
            81 => Some(Self::StdF64ToBits),
            82 => Some(Self::StdF64FromBits),
            83 => Some(Self::StdF64ToF32),
            84 => Some(Self::MathMatmulF32),
            85 => Some(Self::MathMatrixAddF32),
            86 => Some(Self::MathTensorAddF32),
            87 => Some(Self::MathMatmulF64),
            88 => Some(Self::MathMatrixAddF64),
            89 => Some(Self::MathTensorAddF64),
            90 => Some(Self::CoreSeqLen),
            91 => Some(Self::CoreSeqSum),
            92 => Some(Self::CoreRequireUnrestricted),
            93 => Some(Self::CoreFanoutInputs),
            _ => None,
        }
    }
}

#[derive(Eq, Hash, Ord, PartialEq, PartialOrd)]
enum EntityReferenceLogicalIdentity<'a> {
    Project(DeclarationIdentityFamily, &'a PublicId),
    Graph(arcweft_id::ProjectEntityReferenceFamily, &'a PublicId),
    Flow(&'a crate::plan::FlowRuntimeId),
    Line(&'a crate::runtime_id::RuntimeIdPath),
    Look(
        &'a arcweft_character::id::CharacterId,
        &'a arcweft_character::id::CharacterLookId,
    ),
}

impl RuntimeEntityReference {
    /// Borrowed logical identity. Admission provenance is retained in the
    /// value/codec but is not mistaken for a second logical entity identity.
    fn logical_identity(&self) -> EntityReferenceLogicalIdentity<'_> {
        match self {
            Self::PresentationAddress(identity) => EntityReferenceLogicalIdentity::Graph(
                identity.kind().family(),
                identity.public_id(),
            ),
            Self::Project { family, public_id } => {
                EntityReferenceLogicalIdentity::Project(*family, public_id)
            }
            Self::StructuralFlow(flow) => EntityReferenceLogicalIdentity::Flow(flow),
            Self::ImportedProject(entity) => {
                if let Some(flow) = entity.flow() {
                    return EntityReferenceLogicalIdentity::Flow(flow);
                }
                if let Some(line) = entity.line() {
                    return EntityReferenceLogicalIdentity::Line(line.path());
                }
                match entity.family().declaration_family() {
                    Some(family) => {
                        EntityReferenceLogicalIdentity::Project(family, entity.public_id())
                    }
                    None => {
                        EntityReferenceLogicalIdentity::Graph(entity.family(), entity.public_id())
                    }
                }
            }
            Self::DialogueLine(line) => EntityReferenceLogicalIdentity::Line(line.path()),
            Self::CharacterLook { character, look } => {
                EntityReferenceLogicalIdentity::Look(character, look)
            }
        }
    }

    /// Exact identity projection used by dynamic control. Display labels
    /// remain host/UI selectors; they cannot recreate this owner.
    pub fn exact_flow_identity(&self) -> Option<&crate::plan::FlowRuntimeId> {
        match self {
            Self::PresentationAddress(_) => None,
            Self::StructuralFlow(flow) => Some(flow),
            Self::ImportedProject(entity) => entity.flow(),
            Self::Project { .. } | Self::DialogueLine(_) | Self::CharacterLook { .. } => None,
        }
    }

    pub fn line_identity(&self) -> Option<&RuntimeLineId> {
        match self {
            Self::PresentationAddress(_) => None,
            Self::DialogueLine(line) => Some(line),
            Self::ImportedProject(entity) => entity.line(),
            Self::Project { .. } | Self::StructuralFlow(_) | Self::CharacterLook { .. } => None,
        }
    }
}

impl PartialEq for RuntimeEntityReference {
    fn eq(&self, other: &Self) -> bool {
        self.logical_identity() == other.logical_identity()
    }
}
impl Eq for RuntimeEntityReference {}
impl std::hash::Hash for RuntimeEntityReference {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        std::hash::Hash::hash(&self.logical_identity(), state);
    }
}
impl Ord for RuntimeEntityReference {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.logical_identity().cmp(&other.logical_identity())
    }
}
impl PartialOrd for RuntimeEntityReference {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl RuntimeEntityReference {
    /// Borrows the typed declaration identity without projecting or parsing a
    /// display label. Executable authority remains with the selected program.
    pub(crate) fn project_public_id(
        &self,
        expected: DeclarationIdentityFamily,
    ) -> Option<&PublicId> {
        if self.project_family() != Some(expected) {
            return None;
        }
        match self {
            Self::Project { public_id, .. } => Some(public_id),
            Self::ImportedProject(entity) => Some(entity.public_id()),
            Self::StructuralFlow(_)
            | Self::PresentationAddress(_)
            | Self::DialogueLine(_)
            | Self::CharacterLook { .. } => None,
        }
    }

    /// Borrows the admitted public label for an exact declaration family.
    /// Imported provenance and structural Flow identity remain in this value;
    /// a presentation consumer cannot turn this label into execution authority.
    pub fn project_label(&self, expected: DeclarationIdentityFamily) -> Option<&str> {
        if self.project_family() != Some(expected) {
            return None;
        }
        match self {
            Self::PresentationAddress(_) => None,
            Self::Project { public_id, .. } => Some(public_id.as_str()),
            Self::StructuralFlow(flow) => Some(flow.public_label_ref().as_str()),
            Self::ImportedProject(entity) => Some(entity.public_id().as_str()),
            Self::DialogueLine(_) | Self::CharacterLook { .. } => None,
        }
    }
}

impl RuntimeValue {
    /// Exact closed numeric descriptor of this value's actual owning container.
    pub(crate) const fn dense_numeric_type(&self) -> Option<crate::math::RuntimeDenseNumericType> {
        use crate::math::{RuntimeDenseNumericType as Dense, RuntimeFloatWidth as Width};
        match self {
            Self::MatrixF32(_) => Some(Dense::Matrix(Width::F32)),
            Self::MatrixF64(_) => Some(Dense::Matrix(Width::F64)),
            Self::TensorF32(_) => Some(Dense::Tensor(Width::F32)),
            Self::TensorF64(_) => Some(Dense::Tensor(Width::F64)),
            _ => None,
        }
    }
}
