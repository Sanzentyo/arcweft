#[cfg(test)]
use super::RuntimeRecordFieldId;
use super::{
    RuntimeEnv, RuntimeEvalError, RuntimeLocalBinding, RuntimeLocalRead, RuntimeLocalReadMode,
    RuntimeLocalSlot, RuntimeMutablePlace, RuntimeScope, RuntimeValue, runtime_value_label,
};
use crate::runtime_id::RuntimeLocalDeclarationId;
use crate::scope::RuntimeScopeIdentity;
use crate::task::RuntimeProgramOwner;

struct PreparedCaptureEnvironment {
    environment: RuntimeEnv,
    moves: Vec<(usize, RuntimeLocalDeclarationId)>,
}

/// The exclusive parent borrow keeps every deferred Move in place until the
/// complete receiving frame and its publication have been admitted.
pub(crate) struct PreparedRuntimeCaptures<'parent> {
    source: &'parent mut RuntimeEnv,
    prepared: PreparedCaptureEnvironment,
}

impl PreparedRuntimeCaptures<'_> {
    pub(crate) fn function_instantiation(
        &self,
    ) -> Option<&crate::program_types::RuntimeFunctionEffectInstantiation> {
        self.prepared.environment.function_instantiation()
    }

    pub(crate) fn commit(self) -> RuntimeEnv {
        let Self {
            source,
            mut prepared,
        } = self;
        for (index, local) in prepared.moves {
            prepared.environment.scopes[0].slots[index].value = source
                .take(local)
                .expect("the exclusive capture preparation retains its admitted source")
                .into();
        }
        prepared.environment
    }
}

impl super::RuntimeScopeFunctionContext {
    pub(crate) fn instantiation(
        &self,
    ) -> Option<&crate::program_types::RuntimeFunctionEffectInstantiation> {
        match self {
            Self::Lexical => None,
            Self::Function { instantiation, .. } => instantiation.as_deref(),
        }
    }

    fn validate_original(
        &self,
        plan: &crate::plan::RuntimePlan,
        work: &crate::entry::schema::value_budget::ValidationWork,
    ) -> Result<(), super::AwbcRuntimeValueSnapshotError> {
        let Self::Function {
            site,
            instantiation,
            input_order,
        } = self
        else {
            return Ok(());
        };
        plan.validate_function_instantiation(*site, instantiation.as_deref(), work)
            .map_err(|error| {
                work.failure().map_or_else(
                    || super::AwbcRuntimeValueSnapshotError::Message {
                        message: error.to_string(),
                    },
                    super::AwbcRuntimeValueSnapshotError::from,
                )
            })?;
        let declaration = plan
            .function_sites()
            .get(*site)
            .expect("original function instantiation admission checked its site");
        input_order
            .validate_arity(declaration.inputs().len())
            .map_err(|error| super::AwbcRuntimeValueSnapshotError::Message {
                message: error.to_string(),
            })
    }

    pub(crate) fn admit_retained(
        &self,
        admission: &mut super::RuntimeRetainedValueAdmission,
        origin: crate::entry::schema::value_encoding::ValueAdmissionOrigin,
    ) -> Result<(), super::AwbcRuntimeValueSnapshotError> {
        let Self::Function {
            site,
            instantiation,
            input_order,
        } = self
        else {
            return Ok(());
        };
        admission.validate_metadata(&(1_u8, site.get(), instantiation, input_order))?;
        admission.admit_composite(origin, |owner, resources| {
            let Some(RuntimeProgramOwner::Plan(plan)) = owner else {
                return Err(super::AwbcRuntimeValueSnapshotError::Message {
                    message: "suspended native source requires its original plan".into(),
                });
            };
            self.validate_original(plan, &resources.work())
        })
    }
}

/// Non-runnable rollback image of one native lexical environment. Values are
/// encoded under the exact immutable program lease; spare allocation scopes
/// are omitted because they contain no bindings and carry no semantics.
pub(crate) type RuntimeEnvRollbackImage = RuntimeEnv<super::AwbcRuntimeValueSnapshot>;

#[derive(Debug, PartialEq)]
pub(crate) struct RuntimePlaceWriteError {
    cause: RuntimeEvalError,
    value: Box<RuntimeValue>,
}

impl RuntimePlaceWriteError {
    pub(crate) fn into_parts(self) -> (RuntimeEvalError, RuntimeValue) {
        (self.cause, *self.value)
    }
}

impl Default for RuntimeEnv {
    fn default() -> Self {
        Self {
            scopes: vec![RuntimeScope::default()],
            spare_scopes: Vec::new(),
            assignment_discards: crate::line_task::RuntimeHandleDropAuthorization::default(),
        }
    }
}

impl Clone for RuntimeEnvRollbackImage {
    fn clone(&self) -> Self {
        Self {
            scopes: self.scopes.clone(),
            spare_scopes: Vec::new(),
            assignment_discards: self.assignment_discards.clone(),
        }
    }
}

impl<V: PartialEq> PartialEq for RuntimeEnv<V> {
    fn eq(&self, other: &Self) -> bool {
        self.scopes == other.scopes && self.assignment_discards == other.assignment_discards
    }
}

impl RuntimeEnv {
    /// All value, pattern, permutation and source checks precede every Move.
    /// Exclusive access makes the following slot removals infallible; argument
    /// expressions have already run into caller-owned storage in source order.
    pub(crate) fn transfer_flow_inputs(
        &mut self,
        plan: &crate::plan::RuntimePlan,
        flow: &crate::plan::FlowRuntimeId,
        transfer: &crate::plan::RuntimeFlowTransfer<super::RuntimeExpr>,
    ) -> Result<
        (
            crate::plan::RuntimeFlowTransfer<RuntimeValue>,
            Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
        ),
        RuntimeEvalError,
    > {
        let invalid = |error| RuntimeEvalError::FlowInvocation(Box::new(error));
        plan.validate_flow_transfer_shape(flow, transfer)
            .map_err(invalid)?;
        transfer.validate_input_sources().map_err(invalid)?;
        let references = transfer
            .arguments
            .iter()
            .map(|argument| {
                let local =
                    crate::plan::RuntimeFlowTransfer::input_local(argument).map_err(invalid)?;
                let value = self
                    .get(local)
                    .ok_or(RuntimeEvalError::UninitializedLocal(local))?;
                Ok(super::RuntimeFlowParameterBinding {
                    parameter: argument.parameter,
                    value,
                })
            })
            .collect::<Result<Box<[_]>, RuntimeEvalError>>()?;
        let borrowed = crate::plan::RuntimeFlowTransfer {
            target: crate::plan::RuntimeFlowTransferTarget::Static(flow.clone()),
            arguments: references,
        };
        let (declaration, _) = plan
            .validate_flow_transfer_inputs(flow, &borrowed)
            .map_err(invalid)?;
        let instantiation = declaration.type_instantiation.clone();
        drop(borrowed);
        let arguments = transfer
            .arguments
            .iter()
            .map(|argument| {
                let local = crate::plan::RuntimeFlowTransfer::input_local(argument)
                    .expect("the complete input grammar was checked before any Move");
                super::RuntimeFlowParameterBinding {
                    parameter: argument.parameter,
                    value: self
                        .take(local)
                        .expect("exclusive input admission retains every distinct source slot"),
                }
            })
            .collect();
        Ok((
            crate::plan::RuntimeFlowTransfer {
                target: crate::plan::RuntimeFlowTransferTarget::Static(flow.clone()),
                arguments,
            },
            instantiation,
        ))
    }

    #[cfg(test)]
    pub(crate) fn inert_rollback_image(
        &self,
        owner: &RuntimeProgramOwner,
    ) -> Result<RuntimeEnvRollbackImage, String> {
        self.admit_retained(&mut super::RuntimeRetainedValueAdmission::for_program(
            owner.clone(),
            crate::entry::RuntimeSchemaLimits::engine_default(),
        ))
        .map_err(|error| error.to_string())?;
        self.snapshot_admitted(owner)
    }

    pub(crate) fn snapshot_admitted(
        &self,
        owner: &RuntimeProgramOwner,
    ) -> Result<RuntimeEnvRollbackImage, String> {
        Ok(RuntimeEnvRollbackImage {
            assignment_discards: self.assignment_discards.clone(),
            spare_scopes: Vec::new(),
            scopes: self
                .scopes
                .iter()
                .map(|scope| {
                    Ok(RuntimeScope {
                        identity: scope.identity.clone(),
                        presentation_scope: scope.presentation_scope.clone(),
                        flow_registry: scope.flow_registry.clone(),
                        function_context: scope.function_context.clone(),
                        slots: scope
                            .slots
                            .iter()
                            .map(|binding| {
                                binding
                                    .value
                                    .snapshot_admitted_for_program(owner)
                                    .map(|value| RuntimeLocalSlot::new(binding.local, value))
                                    .map_err(|error| error.to_string())
                            })
                            .collect::<Result<_, String>>()?,
                    })
                })
                .collect::<Result<_, String>>()?,
        })
    }

    #[cfg(test)]
    pub(crate) fn from_rollback_image(
        image: RuntimeEnvRollbackImage,
        owner: &RuntimeProgramOwner,
    ) -> Result<Self, String> {
        image
            .admit_retained(&mut super::RuntimeRetainedValueAdmission::for_program(
                owner.clone(),
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ))
            .map_err(|error| error.to_string())?;
        image.into_admitted_live(owner)
    }
}

impl RuntimeEnvRollbackImage {
    pub(crate) fn into_admitted_live(
        self,
        owner: &RuntimeProgramOwner,
    ) -> Result<RuntimeEnv, String> {
        let image = self;
        let env = RuntimeEnv {
            scopes: image
                .scopes
                .into_iter()
                .map(|scope| {
                    Ok(RuntimeScope {
                        identity: scope.identity,
                        presentation_scope: scope.presentation_scope,
                        flow_registry: scope.flow_registry,
                        function_context: scope.function_context,
                        slots: scope
                            .slots
                            .into_iter()
                            .map(|binding| {
                                binding
                                    .into_admitted_live_for_program(owner)
                                    .map_err(|error| error.to_string())
                            })
                            .collect::<Result<_, String>>()?,
                    })
                })
                .collect::<Result<_, String>>()?,
            spare_scopes: Vec::new(),
            assignment_discards: image.assignment_discards,
        };
        Ok(env)
    }
}

impl<V> RuntimeEnv<V> {
    pub(crate) fn scope_depth(&self) -> usize {
        self.scopes.len()
    }

    fn slot(&self, local: RuntimeLocalDeclarationId) -> Option<&RuntimeLocalSlot<V>> {
        self.scopes
            .iter()
            .rev()
            .find_map(|scope| scope.slots.iter().rev().find(|slot| slot.local() == local))
    }

    /// Borrows the nearest physical slot without changing live/inert custody.
    pub(crate) fn get_stored(&self, local: RuntimeLocalDeclarationId) -> Option<&V> {
        self.slot(local)?.value.as_ref()
    }

    pub(crate) fn validate_presentation_context(
        &self,
        program: &RuntimeProgramOwner,
        execution: crate::runtime_id::ExecutionInstanceId,
        fiber: crate::runtime_id::RuntimePersistentFiberId,
    ) -> Result<(), crate::presentation::RuntimePresentationError> {
        if self
            .presentation_scope_bindings()
            .any(|binding| !binding.matches_context(program, execution, fiber))
        {
            return Err(crate::presentation::RuntimePresentationError::Owner);
        }
        Ok(())
    }
    pub(crate) fn presentation_scope_bindings(
        &self,
    ) -> impl Iterator<Item = &crate::presentation::resources::RuntimePresentationScopeBinding>
    {
        self.scopes
            .iter()
            .filter_map(|scope| scope.presentation_scope.as_ref())
    }

    pub(crate) fn presentation_scope_binding(
        &self,
    ) -> Option<&crate::presentation::resources::RuntimePresentationScopeBinding> {
        self.scopes
            .last()
            .and_then(|scope| scope.presentation_scope.as_ref())
    }

    pub(crate) fn presentation_scope_target(
        &mut self,
    ) -> Result<
        crate::presentation::resources::PresentationScopeTarget<'_>,
        crate::presentation::RuntimePresentationError,
    > {
        let scope = self
            .scopes
            .last_mut()
            .ok_or(crate::presentation::RuntimePresentationError::MissingScope)?;
        Ok(
            crate::presentation::resources::PresentationScopeTarget::native(
                &mut scope.presentation_scope,
            ),
        )
    }

    /// Borrows the actual exiting lexical contour and its receiving scope.
    /// The count comes from the interpreter's owning control frames.
    pub(crate) fn presentation_scope_exit_targets(
        &mut self,
        count: usize,
        detached: bool,
    ) -> Result<
        (
            Vec<crate::presentation::resources::PresentationScopeTarget<'_>>,
            Option<crate::presentation::resources::PresentationScopeTarget<'_>>,
        ),
        crate::presentation::RuntimePresentationError,
    > {
        use crate::presentation::{RuntimePresentationError, resources::PresentationScopeTarget};
        let start = self
            .scopes
            .len()
            .checked_sub(count)
            .ok_or(RuntimePresentationError::MissingScope)?;
        let (remaining, exiting) = self.scopes.split_at_mut(start);
        let destination = if detached {
            None
        } else {
            remaining
                .last_mut()
                .map(|scope| PresentationScopeTarget::native(&mut scope.presentation_scope))
        };
        Ok((
            exiting
                .iter_mut()
                .rev()
                .map(|scope| PresentationScopeTarget::native(&mut scope.presentation_scope))
                .collect(),
            destination,
        ))
    }

    pub(crate) fn source_function_context(&self) -> super::RuntimeScopeFunctionContext {
        self.scopes
            .iter()
            .rev()
            .find_map(|scope| match &scope.function_context {
                super::RuntimeScopeFunctionContext::Lexical => None,
                context @ super::RuntimeScopeFunctionContext::Function { .. } => {
                    Some(context.clone())
                }
            })
            .unwrap_or_default()
    }

    pub(crate) fn function_instantiation(
        &self,
    ) -> Option<&crate::program_types::RuntimeFunctionEffectInstantiation> {
        self.function_instantiation_lease()
            .map(std::sync::Arc::as_ref)
    }

    pub(crate) fn function_instantiation_lease(
        &self,
    ) -> Option<&std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>> {
        self.function_contexts()
            .next_back()
            .and_then(|(_, binding)| binding)
    }

    pub(crate) fn function_input_order(&self) -> Option<&std::sync::Arc<super::RuntimeInputOrder>> {
        self.scopes
            .iter()
            .rev()
            .find_map(|scope| match &scope.function_context {
                super::RuntimeScopeFunctionContext::Lexical => None,
                super::RuntimeScopeFunctionContext::Function { input_order, .. } => {
                    Some(input_order)
                }
            })
    }

    pub(crate) fn function_contexts(
        &self,
    ) -> impl DoubleEndedIterator<
        Item = (
            crate::runtime_id::RuntimeFunctionSiteId,
            Option<&std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
        ),
    > {
        self.scopes
            .iter()
            .filter_map(|scope| match &scope.function_context {
                super::RuntimeScopeFunctionContext::Lexical => None,
                super::RuntimeScopeFunctionContext::Function {
                    site,
                    instantiation,
                    ..
                } => Some((*site, instantiation.as_ref())),
            })
    }

    pub(crate) fn admit_retained(
        &self,
        admission: &mut super::RuntimeRetainedValueAdmission,
    ) -> Result<(), super::AwbcRuntimeValueSnapshotError>
    where
        V: super::RuntimeStoredValue,
    {
        admission.validate_metadata_collection(self.scopes.len())?;
        self.assignment_discards.admit_retained(admission)?;
        for scope in &self.scopes {
            admission.validate_metadata(&scope.identity)?;
            if let Some(registry) = &scope.flow_registry {
                registry
                    .admit_retained(crate::effect::RuntimeRegistryOwner::NativeFlow, admission)?;
            }
            if let Some(binding) = &scope.presentation_scope {
                binding.admit_retained(admission)?;
            }
            admission.validate_metadata_collection(scope.slots.len())?;
        }
        admission.admit_composite(V::admission_origin(), |owner, resources| {
            let owner = owner.ok_or_else(|| super::AwbcRuntimeValueSnapshotError::Message {
                message: "native environment requires its original plan".to_owned(),
            })?;
            Self::validate_scope_places(&self.scopes, owner, resources, V::borrowed_view)
        })
    }

    fn validate_scope_places<'value, T>(
        scopes: &'value [RuntimeScope<T>],
        owner: &RuntimeProgramOwner,
        resources: &mut crate::entry::schema::value_encoding::ValueResourceAdmission,
        view: impl Fn(&'value T) -> super::RuntimeValueView<'value>,
    ) -> Result<(), super::AwbcRuntimeValueSnapshotError> {
        let invalid = |message| super::AwbcRuntimeValueSnapshotError::Message { message };
        let RuntimeProgramOwner::Plan(plan) = owner else {
            return Err(invalid(
                "native environment requires its original plan".to_owned(),
            ));
        };
        resources.work().collection(scopes.len())?;
        // All function headers precede the complete declaration/place inventory.
        for scope in scopes {
            scope
                .function_context
                .validate_original(plan, &resources.work())?;
            if scope.flow_registry.is_some()
                && !matches!(&scope.function_context, super::RuntimeScopeFunctionContext::Function { site, .. }
                    if plan.function_sites().get(*site).is_some_and(|site|
                        site.role() == crate::plan::RuntimeFunctionSemanticRole::Flow))
            {
                return Err(invalid(
                    "registry requires a reached native Flow frame".to_owned(),
                ));
            }
        }
        let mut instantiation = None;
        for scope in scopes {
            resources.work().charge(0)?;
            resources.work().collection(scope.slots.len())?;
            if let super::RuntimeScopeFunctionContext::Function {
                instantiation: binding,
                ..
            } = &scope.function_context
            {
                instantiation = binding.as_deref();
            }
            let mut declarations = std::collections::BTreeSet::new();
            for slot in &scope.slots {
                if !declarations.insert(slot.local()) {
                    return Err(invalid(format!(
                        "rollback scope repeats local {}",
                        slot.local()
                    )));
                }
                let ty = plan
                    .local_type_in_context(slot.local(), instantiation)
                    .map_err(|error| invalid(error.to_string()))?;
                slot.storage()
                    .validate_program_type(
                        crate::value::ownership::RuntimeValueOwnershipRequirement::Owned,
                        crate::program_types::RuntimeProgramValueType::Plan { program: plan, ty },
                        instantiation,
                        resources,
                        &view,
                    )
                    .map_err(|error| {
                        if matches!(
                            &error,
                            crate::program_types::RuntimeProgramTypeError::Resource(_)
                        ) {
                            error.into()
                        } else {
                            invalid(format!(
                                "rollback local {} has invalid typed place storage: {error}",
                                slot.local()
                            ))
                        }
                    })?;
            }
        }
        Ok(())
    }
}

impl RuntimeEnv {
    pub(crate) fn try_capture_unrestricted(
        &self,
        locals: &[RuntimeLocalDeclarationId],
    ) -> Result<Self, RuntimeEvalError> {
        Ok(self
            .prepare_capture_environment(
                locals
                    .iter()
                    .map(|local| (*local, RuntimeLocalReadMode::Copy)),
            )?
            .environment)
    }

    pub(crate) fn prepare_local_captures(
        &mut self,
        captures: impl Clone
        + ExactSizeIterator<Item = (RuntimeLocalDeclarationId, RuntimeLocalReadMode)>,
    ) -> Result<PreparedRuntimeCaptures<'_>, RuntimeEvalError> {
        let prepared = self.prepare_capture_environment(captures)?;
        Ok(PreparedRuntimeCaptures {
            source: self,
            prepared,
        })
    }

    fn prepare_capture_environment(
        &self,
        captures: impl Clone
        + ExactSizeIterator<Item = (RuntimeLocalDeclarationId, RuntimeLocalReadMode)>,
    ) -> Result<PreparedCaptureEnvironment, RuntimeEvalError> {
        let mut selected = std::collections::BTreeSet::new();
        for (local, mode) in captures.clone() {
            if !selected.insert(local) {
                return Err(RuntimeEvalError::DuplicateLocalCapture { local });
            }
            let value = self
                .get(local)
                .ok_or(RuntimeEvalError::UninitializedLocal(local))?;
            if mode == super::RuntimeLocalReadMode::Copy && !value.ownership().permits_copy() {
                return Err(RuntimeEvalError::AffineLocalCopy(local));
            }
        }
        // A captured task owns a new lexical root, not the caller's scope or
        // return stack. Only its nearest authenticated type environment is
        // inherited; nested calls above that root retain their own contexts.
        let function_context = self.source_function_context();
        let mut slots = Vec::with_capacity(captures.len());
        let mut moves = Vec::new();
        for (index, (local, mode)) in captures.enumerate() {
            let value = match mode {
                super::RuntimeLocalReadMode::Copy => self
                    .get(local)
                    .expect("all capture reads were inspected before any copy")
                    .clone()
                    .into(),
                super::RuntimeLocalReadMode::Move => {
                    moves.push((index, local));
                    Default::default()
                }
            };
            slots.push(RuntimeLocalSlot::new(local, value));
        }
        Ok(PreparedCaptureEnvironment {
            moves,
            environment: Self {
                scopes: vec![RuntimeScope {
                    identity: RuntimeScopeIdentity::Anonymous,
                    presentation_scope: None,
                    flow_registry: None,
                    function_context,
                    slots,
                }],
                spare_scopes: Vec::new(),
                assignment_discards: crate::line_task::RuntimeHandleDropAuthorization::default(),
            },
        })
    }

    pub fn push_scope(&mut self) {
        self.push_scope_with_capacity(0);
    }

    pub(crate) fn push_scope_with_capacity(&mut self, binding_capacity: usize) {
        self.push_scope_with_identity_and_capacity(
            RuntimeScopeIdentity::Anonymous,
            binding_capacity,
        );
    }

    pub(crate) fn push_function_scope(
        &mut self,
        site: crate::runtime_id::RuntimeFunctionSiteId,
        binding_capacity: usize,
        binding: Option<std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>>,
        input_order: super::RuntimeInputOrder,
    ) {
        self.push_scope_with_capacity(binding_capacity);
        self.scopes
            .last_mut()
            .expect("function scope was pushed")
            .function_context = super::RuntimeScopeFunctionContext::Function {
            site,
            instantiation: binding,
            input_order: std::sync::Arc::new(input_order),
        };
    }

    pub(crate) fn open_flow_registry(&mut self) {
        self.scopes
            .last_mut()
            .expect("Flow has a physical execution scope")
            .flow_registry = Some(crate::effect::RuntimeScopeRegistry::default());
    }

    pub(crate) fn flow_registry(&self) -> Option<&crate::effect::RuntimeScopeRegistry> {
        self.scopes
            .iter()
            .rev()
            .find_map(|scope| scope.flow_registry.as_ref())
    }

    pub(crate) fn flow_registry_mut(&mut self) -> Option<&mut crate::effect::RuntimeScopeRegistry> {
        self.scopes
            .iter_mut()
            .rev()
            .find_map(|scope| scope.flow_registry.as_mut())
    }

    pub(crate) fn close_root_flow_registry(&mut self) {
        if let Some(scope) = self.scopes.first_mut() {
            scope.flow_registry = None;
        }
    }

    /// Installs an admitted Flow function after its previous root has unwound.
    /// Old locals must not inherit the next declaration's type context.
    pub(crate) fn bind_root_function(
        &mut self,
        site: crate::runtime_id::RuntimeFunctionSiteId,
        instantiation: Option<
            std::sync::Arc<crate::program_types::RuntimeFunctionEffectInstantiation>,
        >,
        inputs: (
            impl IntoIterator<Item = RuntimeLocalBinding>,
            super::RuntimeInputOrder,
        ),
    ) {
        let (bindings, input_order) = inputs;
        self.ensure_root_scope();
        let root = self.scopes.first_mut().expect("root scope was ensured");
        root.clear();
        root.flow_registry = Some(crate::effect::RuntimeScopeRegistry::default());
        root.function_context = super::RuntimeScopeFunctionContext::Function {
            site,
            instantiation,
            input_order: std::sync::Arc::new(input_order),
        };
        for binding in bindings {
            root.set(binding.local, binding.value);
        }
    }

    pub(crate) fn value_matches_type(
        &self,
        plan: &crate::plan::RuntimePlan,
        ty: crate::runtime_id::RuntimePlanTypeId,
        value: &RuntimeValue,
    ) -> Result<bool, crate::plan::RuntimePlanValueTypeError> {
        if plan.type_table().get(ty).is_none() {
            return Err(crate::plan::RuntimePlanValueTypeError::UnknownType { ty });
        }
        match self.function_instantiation() {
            Some(binding) => Ok(binding.value_matches(plan, ty, value)),
            None => plan.value_matches_type(ty, value),
        }
    }

    pub(crate) fn construct_array_from_vec(
        &self,
        plan: &crate::plan::RuntimePlan,
        ty: crate::runtime_id::RuntimePlanTypeId,
        value: RuntimeValue,
    ) -> Result<RuntimeValue, crate::value::RuntimeEvalError> {
        if !matches!(
            plan.type_table().get(ty).map(|row| row.projection()),
            Some(crate::plan::RuntimePlanTypeProjection::Array { .. })
        ) {
            return Err(crate::value::RuntimeEvalError::InvalidExpressionType(ty));
        }
        if !self.value_matches_type(plan, ty, &value)? {
            return Err(crate::value::RuntimeEvalError::ArrayConstruction {
                ty,
                actual: crate::value::runtime_value_label(&value),
            });
        }
        // Vec and Array use the same owned sequence storage. The admitted
        // result type establishes exact length without cloning its elements.
        Ok(value)
    }

    pub(crate) fn push_scope_with_identity(&mut self, identity: RuntimeScopeIdentity) {
        self.push_scope_with_identity_and_capacity(identity, 0);
    }

    fn push_scope_with_identity_and_capacity(
        &mut self,
        identity: RuntimeScopeIdentity,
        binding_capacity: usize,
    ) {
        let mut scope = self
            .spare_scopes
            .pop()
            .unwrap_or_else(|| RuntimeScope::with_capacity(binding_capacity));
        scope.clear();
        scope.identity = identity;
        scope.reserve_bindings(binding_capacity);
        self.scopes.push(scope);
    }

    pub fn pop_scope(&mut self) {
        let _ = self.pop_scope_bindings();
    }

    /// Removes one lexical scope while returning its bindings to the owner
    /// that must reconcile affine resources before discarding them.
    pub(crate) fn pop_scope_bindings(&mut self) -> Vec<RuntimeLocalBinding> {
        if self.scopes.len() > 1 {
            if let Some(mut scope) = self.scopes.pop() {
                let bindings = scope.take_bindings();
                scope.clear();
                self.spare_scopes.push(scope);
                return bindings;
            }
        } else if let Some(scope) = self.scopes.last_mut() {
            let bindings = scope.take_bindings();
            scope.clear();
            return bindings;
        }
        Vec::new()
    }

    pub(crate) fn current_scope_bindings(
        &self,
    ) -> impl Iterator<Item = (RuntimeLocalDeclarationId, &RuntimeValue)> {
        self.scopes
            .last()
            .into_iter()
            .flat_map(RuntimeScope::bindings)
    }

    pub fn set(&mut self, local: RuntimeLocalDeclarationId, value: RuntimeValue) {
        if let Some(scope) = self.scopes.last_mut() {
            scope.set(local, value);
        }
    }

    pub(crate) fn set_ref(&mut self, local: RuntimeLocalDeclarationId, value: &RuntimeValue) {
        if let Some(scope) = self.scopes.last_mut() {
            scope.set_ref(local, value);
        }
    }

    pub fn set_root(&mut self, local: RuntimeLocalDeclarationId, value: RuntimeValue) {
        self.ensure_root_scope();
        if let Some(scope) = self.scopes.first_mut() {
            scope.set(local, value);
        }
    }

    pub fn get(&self, local: RuntimeLocalDeclarationId) -> Option<&RuntimeValue> {
        self.get_stored(local)
    }

    /// Removes and returns the nearest binding for one admitted local. This is
    /// the structured runtime's move boundary; affine values are never cloned
    /// before their consuming instruction commits.
    pub(crate) fn take(&mut self, local: RuntimeLocalDeclarationId) -> Option<RuntimeValue> {
        self.slot_mut(local)?.value.take()
    }

    fn slot_mut(&mut self, local: RuntimeLocalDeclarationId) -> Option<&mut RuntimeLocalSlot> {
        self.scopes
            .iter_mut()
            .rev()
            .find_map(|scope| scope.slot_mut(local))
    }

    /// Copies one selected unrestricted field from its complete stored address.
    /// A disjoint moved sibling does not require reconstructing the receiver.
    pub(crate) fn inspect_field(
        &self,
        place: &RuntimeMutablePlace,
        field: &super::RuntimeFieldProjection,
    ) -> Result<RuntimeValue, RuntimeEvalError> {
        let super::RuntimeFieldProjection::Nominal(field) = field else {
            return field.inspect(self.inspect_place(place)?);
        };
        let mut fields = Vec::with_capacity(place.fields().len() + 1);
        fields.extend_from_slice(place.fields());
        fields.push(*field);
        let selected = self
            .slot(place.local())
            .and_then(|slot| slot.value.field(&fields))
            .ok_or(RuntimeEvalError::UninitializedLocal(place.local()))?;
        if !selected.ownership().permits_copy() {
            return Err(RuntimeEvalError::AffineFieldCopy);
        }
        Ok(selected.clone())
    }

    /// Borrows one initialized place for a synchronous inspection. No value or
    /// declaration lifetime is transferred across this boundary.
    pub(crate) fn inspect_place(
        &self,
        place: &RuntimeMutablePlace,
    ) -> Result<&RuntimeValue, RuntimeEvalError> {
        self.slot(place.local())
            .and_then(|slot| slot.value.field(place.fields()))
            .ok_or(RuntimeEvalError::UninitializedLocal(place.local()))
    }

    /// Transfers an initialized owner after its caller has admitted the effect.
    pub(crate) fn take_place(
        &mut self,
        place: &RuntimeMutablePlace,
    ) -> Result<RuntimeValue, RuntimeEvalError> {
        self.slot_mut(place.local())
            .and_then(|slot| slot.value.take_field(place.fields()))
            .ok_or(RuntimeEvalError::UninitializedLocal(place.local()))
    }

    /// Executes the already-selected local-use transfer and checks live value
    /// ownership before any copy. A moved binding is absent for later reads.
    pub(crate) fn read(
        &mut self,
        read: &RuntimeLocalRead,
    ) -> Result<RuntimeValue, RuntimeEvalError> {
        let slot = self
            .slot_mut(read.local())
            .ok_or(RuntimeEvalError::UnknownLocal(read.local()))?;
        match read.mode() {
            RuntimeLocalReadMode::Copy => {
                let value = slot
                    .value
                    .field(read.fields())
                    .ok_or(RuntimeEvalError::UninitializedLocal(read.local()))?;
                if !value.ownership().permits_copy() {
                    return Err(RuntimeEvalError::AffineLocalCopy(read.local()));
                }
                Ok(value.clone())
            }
            RuntimeLocalReadMode::Move => slot
                .value
                .take_field(read.fields())
                .ok_or(RuntimeEvalError::UninitializedLocal(read.local())),
        }
    }

    /// Pops from the nearest binding without moving or cloning the sequence
    /// value itself. Checked expression admission restricts this operation to
    /// Vec locals and parameters.
    pub(crate) fn pop_sequence_front(
        &mut self,
        place: &RuntimeMutablePlace,
    ) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
        Ok(self.sequence_mut(place)?.pop_front())
    }

    pub(crate) fn push_sequence_item(
        &mut self,
        place: &RuntimeMutablePlace,
        value: RuntimeValue,
    ) -> Result<(), RuntimeEvalError> {
        self.sequence_mut(place)?.push_sequence_item(value);
        Ok(())
    }

    pub(crate) fn pop_vector_item(
        &mut self,
        place: &RuntimeMutablePlace,
    ) -> Result<Option<RuntimeValue>, RuntimeEvalError> {
        Ok(self.sequence_mut(place)?.pop_vector_item())
    }

    fn sequence_mut(
        &mut self,
        place: &RuntimeMutablePlace,
    ) -> Result<&mut super::RuntimeSeq, RuntimeEvalError> {
        let local = place.local();
        let binding = self
            .slot_mut(local)
            .ok_or(RuntimeEvalError::UnknownLocal(local))?;
        let path = place.fields();
        let value = binding
            .value
            .field_mut(&path)
            .ok_or(RuntimeEvalError::UninitializedLocal(local))?;
        match value {
            RuntimeValue::Seq(sequence) => Ok(sequence),
            value => Err(RuntimeEvalError::ExpectedSequence(runtime_value_label(
                value,
            ))),
        }
    }

    pub(crate) fn bindings(
        &self,
    ) -> impl Iterator<Item = (RuntimeLocalDeclarationId, &RuntimeValue)> {
        self.scopes.iter().flat_map(RuntimeScope::bindings)
    }

    pub(crate) fn assign_place(
        &mut self,
        assignment: &super::RuntimeAssignment,
        value: RuntimeValue,
    ) -> Result<Vec<RuntimeValue>, RuntimePlaceWriteError> {
        let place = assignment.place();
        let inspected = (|| {
            let slot = self
                .slot(place.local())
                .ok_or(RuntimeEvalError::UnknownLocal(place.local()))?;
            let path = place.fields();
            if !slot
                .value
                .matches_displacement(&path, assignment.displacement())
            {
                return Err(RuntimeEvalError::UninitializedLocal(place.local()));
            }
            slot.value
                .values_at(path)
                .ok_or_else(|| RuntimeEvalError::InvalidFieldAssignment {
                    field: path
                        .iter()
                        .map(|field| field.zero_based().to_string())
                        .collect::<Vec<_>>()
                        .join("."),
                    value: "uninitialized record place".into(),
                })
        })();
        let handles = inspected.and_then(|displaced| {
            displaced
                .into_iter()
                .map(|value| {
                    value
                        .affine_line_handles()
                        .map_err(|_| RuntimeEvalError::InvalidDiscardGraph)
                })
                .collect::<Result<Vec<_>, _>>()
                .map(|handles| handles.into_iter().flatten().collect())
        });
        let handles = match handles {
            Ok(handles) => handles,
            Err(cause) => {
                return Err(RuntimePlaceWriteError {
                    cause,
                    value: Box::new(value),
                });
            }
        };
        if self.assignment_discards.authorize_handles(handles).is_err() {
            return Err(RuntimePlaceWriteError {
                cause: RuntimeEvalError::InvalidDiscardGraph,
                value: Box::new(value),
            });
        }
        let displaced = match place {
            RuntimeMutablePlace::Local(local) => self
                .slot_mut(*local)
                .expect("inspected local remains in the exclusive environment")
                .value
                .replace(value),
            RuntimeMutablePlace::Fields { base, fields } => self
                .slot_mut(*base)
                .expect("inspected field owner remains declared")
                .value
                .assign_field(fields, value)
                .expect("inspected field retains its defining-order coordinate"),
        };
        Ok(displaced)
    }

    /// Runtime-owned destinations have dynamic occupancy, unlike a checked
    /// source assignment with its sealed post-RHS initialization contour.
    pub(crate) fn assign_runtime_place(
        &mut self,
        place: RuntimeMutablePlace,
        value: RuntimeValue,
    ) -> Result<Vec<RuntimeValue>, RuntimePlaceWriteError> {
        self.assign_place(
            &super::RuntimeAssignment::new(place, super::RuntimePlaceDisplacement::conditional()),
            value,
        )
    }

    pub(crate) fn take_assignment_discard_authorization(
        &mut self,
    ) -> crate::line_task::RuntimeHandleDropAuthorization {
        std::mem::take(&mut self.assignment_discards)
    }

    pub(crate) fn set_assignment_discard_boundary(
        &mut self,
        policy: Option<crate::effect::RuntimeDropPolicy>,
    ) -> Result<(), crate::line_task::LineRuntimeError> {
        self.assignment_discards.set_boundary(policy)
    }

    pub(crate) fn authorize_assignment_discard_handles(
        &mut self,
        handles: Vec<super::ownership::RuntimeAffineLineHandle>,
    ) -> Result<(), crate::line_task::LineRuntimeError> {
        self.assignment_discards.authorize_handles(handles)
    }

    pub fn bindings_snapshot(&self) -> Vec<RuntimeLocalSlot> {
        self.scopes
            .iter()
            .flat_map(|scope| scope.slots.iter().cloned())
            .collect()
    }

    pub(crate) fn into_slots(self) -> Vec<RuntimeLocalSlot> {
        self.scopes
            .into_iter()
            .flat_map(|scope| scope.slots)
            .collect()
    }

    pub(crate) fn replace_scopes_with_bindings(
        &mut self,
        scopes: impl IntoIterator<Item = Vec<RuntimeLocalBinding>>,
    ) {
        self.spare_scopes
            .extend(self.scopes.drain(..).map(|mut scope| {
                scope.clear();
                scope
            }));

        for bindings in scopes {
            let mut scope = self
                .spare_scopes
                .pop()
                .unwrap_or_else(|| RuntimeScope::with_capacity(bindings.len()));
            scope.clear();
            scope.reserve_bindings(bindings.len());
            for binding in bindings {
                scope.set(binding.local, binding.value);
            }
            self.scopes.push(scope);
        }

        if self.scopes.is_empty() {
            self.push_scope();
        }
    }

    pub fn bind_all(&mut self, bindings: impl IntoIterator<Item = RuntimeLocalBinding>) {
        for binding in bindings {
            self.set(binding.local, binding.value);
        }
    }

    pub(crate) fn bind_all_ref(&mut self, bindings: &[RuntimeLocalBinding]) {
        for binding in bindings {
            self.set_ref(binding.local, &binding.value);
        }
    }

    pub fn bind_all_root(&mut self, bindings: impl IntoIterator<Item = RuntimeLocalBinding>) {
        for binding in bindings {
            self.set_root(binding.local, binding.value);
        }
    }

    pub fn bind_all_root_ref(&mut self, bindings: &[RuntimeLocalBinding]) {
        if self.replace_root_bindings_ref(bindings) {
            return;
        }
        for binding in bindings {
            self.set_root_ref(binding.local, &binding.value);
        }
    }

    fn replace_root_bindings_ref(&mut self, bindings: &[RuntimeLocalBinding]) -> bool {
        if self.scopes.is_empty() {
            return bindings.is_empty();
        }
        self.scopes
            .first_mut()
            .is_some_and(|scope| scope.replace_binding_values_ref(bindings))
    }

    fn set_root_ref(&mut self, local: RuntimeLocalDeclarationId, value: &RuntimeValue) {
        self.ensure_root_scope();
        if let Some(scope) = self.scopes.first_mut() {
            scope.set_ref(local, value);
        }
    }

    fn ensure_root_scope(&mut self) {
        if self.scopes.is_empty() {
            self.scopes.push(RuntimeScope::default());
        }
    }
}

impl RuntimeScope {
    fn with_capacity(binding_capacity: usize) -> Self {
        Self {
            identity: RuntimeScopeIdentity::Anonymous,
            presentation_scope: None,
            flow_registry: None,
            function_context: super::RuntimeScopeFunctionContext::Lexical,
            slots: Vec::with_capacity(binding_capacity),
        }
    }

    fn reserve_bindings(&mut self, binding_capacity: usize) {
        let additional = binding_capacity.saturating_sub(self.slots.capacity());
        self.slots.reserve(additional);
    }

    fn set(&mut self, local: RuntimeLocalDeclarationId, value: RuntimeValue) {
        if let Some(binding) = self.slot_mut(local) {
            binding.value = value.into();
        } else {
            self.slots.push(RuntimeLocalSlot {
                local,
                value: value.into(),
            });
        }
    }

    fn set_ref(&mut self, local: RuntimeLocalDeclarationId, value: &RuntimeValue) {
        self.set(local, value.clone());
    }

    fn slot_mut(&mut self, local: RuntimeLocalDeclarationId) -> Option<&mut RuntimeLocalSlot> {
        self.slots
            .iter_mut()
            .rev()
            .find(|binding| binding.local == local)
    }

    fn bindings(&self) -> impl Iterator<Item = (RuntimeLocalDeclarationId, &RuntimeValue)> {
        self.slots
            .iter()
            .flat_map(|slot| slot.value.values().map(move |value| (slot.local, value)))
    }

    fn take_bindings(&mut self) -> Vec<RuntimeLocalBinding> {
        std::mem::take(&mut self.slots)
            .into_iter()
            .flat_map(|slot| {
                slot.value
                    .into_values()
                    .into_iter()
                    .map(move |value| RuntimeLocalBinding {
                        local: slot.local,
                        value,
                    })
            })
            .collect()
    }

    fn clear(&mut self) {
        self.presentation_scope = None;
        self.flow_registry = None;
        self.identity = RuntimeScopeIdentity::Anonymous;
        self.function_context = super::RuntimeScopeFunctionContext::Lexical;
        self.slots.clear();
    }

    fn replace_binding_values_ref(&mut self, bindings: &[RuntimeLocalBinding]) -> bool {
        if self.slots.len() != bindings.len()
            || !self
                .slots
                .iter()
                .zip(bindings)
                .all(|(current, next)| current.local == next.local)
        {
            return false;
        }
        for (current, next) in self.slots.iter_mut().zip(bindings) {
            current.value = next.value.clone().into();
        }
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn unit_environment_program() -> (RuntimeProgramOwner, RuntimeLocalDeclarationId) {
        use crate::pattern::RuntimeSemanticTypeId;
        use crate::plan::{
            RuntimeLocalDeclarationSeed, RuntimePlanBuilder, RuntimePlanTypeProjection,
            RuntimePlanTypeSeed,
        };

        let unit = RuntimeSemanticTypeId::from_bytes([71; 32]);
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [RuntimePlanTypeSeed::new(
                    unit,
                    RuntimePlanTypeProjection::Unit,
                )],
                [RuntimeLocalDeclarationSeed::new(
                    manual_local_source("arcweft-core.fixture.value.env.shared_admission.local"),
                    unit,
                )],
            )
            .unwrap();
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let declaration = builder
            .lower_pattern_seed_for_test(crate::plan::RuntimePatternSeed::new(
                unit,
                crate::plan::RuntimePatternSeedKind::Bind {
                    mutable: false,
                    local: admitted.local_ids()[0].clone(),
                },
            ))
            .unwrap()
            .binding_declarations()
            .next()
            .unwrap()
            .local();
        let plan = std::sync::Arc::new(builder.finish().unwrap());
        (RuntimeProgramOwner::Plan(plan), declaration)
    }

    #[test]
    fn environments_share_original_program_admission_before_projection() {
        use crate::entry::{RuntimeSchemaError, RuntimeSchemaLimits};
        use crate::value::{AwbcRuntimeValueSnapshotError, RuntimeRetainedValueAdmission};
        let (owner, declaration) = unit_environment_program();
        let make = || {
            let mut env = RuntimeEnv::default();
            env.set(declaration, RuntimeValue::Unit);
            env
        };
        let envs = [make(), make()];
        let images: Vec<_> = envs
            .iter()
            .map(|env| env.inert_rollback_image(&owner).unwrap())
            .collect();
        let mut live = RuntimeRetainedValueAdmission::for_program(
            owner.clone(),
            RuntimeSchemaLimits {
                max_nodes: 1,
                ..RuntimeSchemaLimits::engine_default()
            },
        );
        envs[0].admit_retained(&mut live).unwrap();
        let failure = envs[1].admit_retained(&mut live).unwrap_err();
        assert_eq!(
            failure,
            AwbcRuntimeValueSnapshotError::ProgramType(Box::new(
                crate::program_types::RuntimeProgramTypeError::Resource(Box::new(
                    RuntimeSchemaError::BudgetExceeded { budget: "nodes" }
                ))
            ))
        );
        assert_eq!(envs[0].admit_retained(&mut live).unwrap_err(), failure);
        let mut inert = RuntimeRetainedValueAdmission::for_program(
            owner.clone(),
            RuntimeSchemaLimits {
                max_nodes: 1,
                ..RuntimeSchemaLimits::engine_default()
            },
        );
        images[0].admit_retained(&mut inert).unwrap();
        assert_eq!(images[1].admit_retained(&mut inert).unwrap_err(), failure);
        assert_eq!(images[0].admit_retained(&mut inert).unwrap_err(), failure);
        assert_eq!(
            envs.iter()
                .map(|env| env.inert_rollback_image(&owner).unwrap())
                .collect::<Vec<_>>(),
            images
        );
        for limit in [0, 2] {
            let mut admission = RuntimeRetainedValueAdmission::for_program(
                owner.clone(),
                RuntimeSchemaLimits {
                    max_nodes: limit,
                    ..RuntimeSchemaLimits::engine_default()
                },
            );
            if limit == 0 {
                assert_eq!(envs[0].admit_retained(&mut admission).unwrap_err(), failure);
                continue;
            }
            for env in &envs {
                env.admit_retained(&mut admission).unwrap();
            }
            assert_eq!(
                envs.iter()
                    .map(|env| env.snapshot_admitted(&owner).unwrap())
                    .collect::<Vec<_>>(),
                images
            );
            let mut admission = RuntimeRetainedValueAdmission::for_program(
                owner.clone(),
                RuntimeSchemaLimits {
                    max_nodes: limit,
                    ..RuntimeSchemaLimits::engine_default()
                },
            );
            for image in &images {
                image.admit_retained(&mut admission).unwrap();
            }
            for (image, env) in images.iter().cloned().zip(&envs) {
                assert_eq!(&image.into_admitted_live(&owner).unwrap(), env);
            }
        }
        let mut invalid = images[1].clone();
        invalid.scopes[0].slots[0].value =
            crate::value::AwbcRuntimeValueSnapshot::Bool(true).into();
        let before = invalid.clone();
        let mut admission = RuntimeRetainedValueAdmission::for_program(
            owner,
            RuntimeSchemaLimits::engine_default(),
        );
        images[0].admit_retained(&mut admission).unwrap();
        let failure = invalid.admit_retained(&mut admission).unwrap_err();
        assert_eq!(
            images[0].admit_retained(&mut admission).unwrap_err(),
            failure
        );
        assert_eq!(invalid, before);
    }

    #[test]
    fn function_scope_binding_survives_lexical_scopes_and_authenticated_rollback() {
        use crate::effect_row::{DecisionControl, DecisionWork, EffectFormula};
        use crate::pattern::RuntimeSemanticTypeId;
        use crate::plan::{
            RuntimeEffectSet, RuntimeExprSeed, RuntimeExprSeedKind, RuntimeFunctionSiteBodyKind,
            RuntimeFunctionSiteDeclarationSeed, RuntimeFunctionTypeContract, RuntimePlanBuilder,
            RuntimePlanTypeProjection, RuntimePlanTypeSeed, RuntimeTypeBinder, RuntimeTypeScope,
        };
        struct Work;
        impl DecisionControl for Work {
            type Error = std::convert::Infallible;
            fn charge(&mut self, _: DecisionWork) -> Result<(), Self::Error> {
                Ok(())
            }
        }
        let unit = RuntimeSemanticTypeId::from_bytes([0xc1; 32]);
        let header = RuntimeSemanticTypeId::from_bytes([0xc2; 32]);
        let scoped_tuple = RuntimeSemanticTypeId::from_bytes([0xc3; 32]);
        let binder = RuntimeTypeBinder::new(0, 0, 1);
        let scope = RuntimeTypeScope::root().enter(binder).unwrap();
        let io = EffectFormula::literal(
            crate::effect_row::EffectSet::from_labels(["io.read"]).unwrap(),
            None,
        );
        let variable =
            EffectFormula::literal(Default::default(), Some(scope.bound_effect(0, 0).unwrap()));
        let predicate = io.subset(&variable, &mut Work).unwrap();
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(unit, RuntimePlanTypeProjection::Unit),
                    RuntimePlanTypeSeed::new(
                        scoped_tuple,
                        RuntimePlanTypeProjection::Tuple(Box::new([unit])),
                    )
                    .with_scope(scope.clone()),
                    RuntimePlanTypeSeed::new(
                        header,
                        RuntimePlanTypeProjection::Function {
                            contract: RuntimeFunctionTypeContract::new(
                                binder,
                                predicate,
                                EffectFormula::empty(),
                            ),
                            parameters: Box::new([]),
                            result: unit,
                        },
                    ),
                ],
                [crate::plan::RuntimeLocalDeclarationSeed::in_function(
                    manual_local_source("arcweft-core.fixture.value.env.charge.binding_a"),
                    scoped_tuple,
                    header,
                )],
            )
            .unwrap();
        let mut sites = Vec::new();
        for function_type in [Some(header), None] {
            let site = builder
                .reserve_function_site_seed(RuntimeFunctionSiteDeclarationSeed {
                    definition:
                        crate::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity(
                            [41; 32],
                        ),
                    role: crate::plan::RuntimeFunctionSemanticRole::Closure,
                    function_type,
                    inputs: Box::new([]),
                    result: unit,
                    body_kind: RuntimeFunctionSiteBodyKind::Expression,
                    effects: RuntimeEffectSet::empty(),
                })
                .unwrap();
            builder
                .define_function_site_seed(
                    &site,
                    if function_type.is_some() {
                        RuntimeExprSeed::new(
                            unit,
                            RuntimeExprSeedKind::Let {
                                binding: admitted.local_ids()[0].clone(),
                                expr: Box::new(RuntimeExprSeed::new(
                                    scoped_tuple,
                                    RuntimeExprSeedKind::Tuple(Box::new([RuntimeExprSeed::new(
                                        unit,
                                        RuntimeExprSeedKind::Value(RuntimeValue::Unit),
                                    )])),
                                )),
                                body: Box::new(RuntimeExprSeed::new(
                                    unit,
                                    RuntimeExprSeedKind::Value(RuntimeValue::Unit),
                                )),
                            },
                        )
                    } else {
                        RuntimeExprSeed::new(unit, RuntimeExprSeedKind::Value(RuntimeValue::Unit))
                    },
                )
                .unwrap();
            sites.push(site);
        }
        let plan = std::sync::Arc::new(builder.finish().unwrap());
        let sites = plan
            .function_sites()
            .iter()
            .enumerate()
            .map(|(index, _)| {
                crate::runtime_id::RuntimeFunctionSiteId::from_accepted_ordinal(
                    std::num::NonZeroU32::new(u32::try_from(index + 1).unwrap()).unwrap(),
                )
            })
            .collect::<Vec<_>>();
        let owner = RuntimeProgramOwner::Plan(std::sync::Arc::clone(&plan));
        let admission = plan
            .validate_function_site_input_refs(sites[0], &[], &[])
            .unwrap();
        let binding = admission.type_instantiation.unwrap();
        let mut env = RuntimeEnv::default();
        env.push_function_scope(
            sites[0],
            0,
            Some(binding.clone()),
            crate::value::RuntimeInputOrder::canonical(0),
        );
        env.push_scope();
        let crate::value::RuntimeExprKind::Let {
            binding: declaration,
            ..
        } = plan
            .function_sites()
            .iter()
            .next()
            .unwrap()
            .body()
            .expression()
            .unwrap()
            .kind()
        else {
            panic!("scoped function declares its local");
        };
        let declaration = *declaration;
        let value = RuntimeValue::Tuple(vec![RuntimeValue::Unit]);
        env.set(declaration, value.clone());
        assert_eq!(env.function_instantiation(), Some(binding.as_ref()));
        let suspended_source = env.source_function_context();
        env.push_function_scope(
            sites[1],
            0,
            None,
            crate::value::RuntimeInputOrder::canonical(0),
        );
        assert!(env.function_instantiation().is_none());
        assert_eq!(suspended_source.instantiation(), Some(binding.as_ref()));
        let mut retained = super::super::RuntimeRetainedValueAdmission::for_program(
            owner.clone(),
            crate::entry::RuntimeSchemaLimits::engine_default(),
        );
        suspended_source
            .admit_retained(
                &mut retained,
                crate::entry::schema::value_encoding::ValueAdmissionOrigin::Live,
            )
            .unwrap();
        env.pop_scope();
        assert_eq!(env.function_instantiation(), Some(binding.as_ref()));
        let image = env.inert_rollback_image(&owner).unwrap();
        let restored = RuntimeEnv::from_rollback_image(image.clone(), &owner).unwrap();
        assert_eq!(restored.function_instantiation(), Some(binding.as_ref()));
        assert_eq!(restored.get(declaration), Some(&value));
        let mut invalid_callable = image.clone();
        invalid_callable.scopes[2].slots[0].value =
            super::super::AwbcRuntimeValueSnapshot::Tuple(vec![
                super::super::AwbcRuntimeValueSnapshot::Callable(
                    super::super::AwbcRuntimeCallableSnapshot {
                        state: crate::runtime_id::RuntimeCallableStateId::from_zero_based(999)
                            .unwrap(),
                        retained_order: crate::value::RuntimeInputOrder::canonical(0),
                        retained: vec![],
                    },
                ),
            ])
            .into();
        let error = RuntimeEnv::from_rollback_image(invalid_callable, &owner).unwrap_err();
        assert!(error.contains("invalid typed place storage"), "{error}");
        assert!(error.contains("$[0]"), "{error}");
        assert_eq!(env.inert_rollback_image(&owner).unwrap(), image);
        let mut invalid_capture = env.try_capture_unrestricted(&[declaration]).unwrap();
        invalid_capture.set(declaration, RuntimeValue::Bool(true));
        assert!(invalid_capture.inert_rollback_image(&owner).is_err());
        let mut wrong_value = image.clone();
        wrong_value.scopes[2].slots[0].value =
            super::super::AwbcRuntimeValueSnapshot::from_runtime_value_for_program(
                &RuntimeValue::Bool(true),
                &owner,
            )
            .unwrap()
            .into();
        assert!(RuntimeEnv::from_rollback_image(wrong_value, &owner).is_err());
        let mut duplicate = image.clone();
        let repeated = duplicate.scopes[2].slots[0].clone();
        duplicate.scopes[2].slots.push(repeated);
        assert!(RuntimeEnv::from_rollback_image(duplicate, &owner).is_err());
        let mut unknown = image.clone();
        unknown.scopes[2].slots[0].local = local(99);
        assert!(RuntimeEnv::from_rollback_image(unknown, &owner).is_err());
        let mut detached = image.clone();
        detached.scopes[1].function_context = super::super::RuntimeScopeFunctionContext::Lexical;
        assert!(RuntimeEnv::from_rollback_image(detached, &owner).is_err());
        let mut missing = image.clone();
        missing.scopes[1].function_context = super::super::RuntimeScopeFunctionContext::Function {
            site: sites[0],
            instantiation: None,
            input_order: crate::value::RuntimeInputOrder::canonical(0).into(),
        };
        assert!(RuntimeEnv::from_rollback_image(missing, &owner).is_err());
        let mut wrong_owner = image.clone();
        wrong_owner.scopes[1].function_context =
            super::super::RuntimeScopeFunctionContext::Function {
                site: sites[1],
                instantiation: Some(binding.clone()),
                input_order: crate::value::RuntimeInputOrder::canonical(0).into(),
            };
        assert!(RuntimeEnv::from_rollback_image(wrong_owner, &owner).is_err());
        let mut encoded = serde_json::to_value(binding.as_ref()).unwrap();
        encoded["effects"][0] = serde_json::json!([]);
        let forged: crate::program_types::RuntimeFunctionEffectInstantiation =
            serde_json::from_value(encoded).unwrap();
        let mut wrong_effects = image;
        wrong_effects.scopes[1].function_context =
            super::super::RuntimeScopeFunctionContext::Function {
                site: sites[0],
                instantiation: Some(std::sync::Arc::new(forged)),
                input_order: crate::value::RuntimeInputOrder::canonical(0).into(),
            };
        assert!(RuntimeEnv::from_rollback_image(wrong_effects, &owner).is_err());
    }
    use crate::entry::{RuntimeNominalTypeId, TypeLayoutHash};
    use crate::value::{RuntimeNominalRecordValue, RuntimeSeq};
    use std::num::NonZeroU32;

    #[test]
    fn checked_assignment_rejects_wrong_old_value_evidence_without_losing_input() {
        use super::super::{
            RuntimeAssignment, RuntimePlaceDisplacement, RuntimePlaceInitialization,
        };
        let source = local(1);
        let mut env = RuntimeEnv::default();
        env.set(source, RuntimeValue::Bool(true));
        let absent = RuntimeAssignment::new(
            RuntimeMutablePlace::Local(source),
            RuntimePlaceDisplacement::Reachable {
                initialization: RuntimePlaceInitialization::Uninitialized,
                fields: Box::new([]),
            },
        );
        let rejected = env
            .assign_place(&absent, RuntimeValue::Bool(false))
            .unwrap_err();
        assert_eq!(
            rejected.into_parts(),
            (
                RuntimeEvalError::UninitializedLocal(source),
                RuntimeValue::Bool(false)
            )
        );
        assert_eq!(env.get(source), Some(&RuntimeValue::Bool(true)));
        let moved = env
            .read(&RuntimeLocalRead::from_admitted_parts(
                source,
                RuntimeLocalReadMode::Move,
            ))
            .unwrap();
        assert_eq!(moved, RuntimeValue::Bool(true));
        assert!(
            env.assign_place(&absent, RuntimeValue::Bool(false))
                .unwrap()
                .is_empty()
        );
        assert_eq!(env.get(source), Some(&RuntimeValue::Bool(false)));
    }

    #[test]
    fn field_inspection_copies_only_the_child_and_preserves_affine_owner_custody() {
        use crate::value::{RuntimeAgentField, RuntimeFieldProjection};
        let owner = local(1);
        let body = RuntimeValue::NeedHandle(crate::tests::reusable_need("need.resource-body"));
        let value = RuntimeValue::try_record(vec![
            ("uri".into(), RuntimeValue::String("resource://one".into())),
            ("body".into(), body.clone()),
        ])
        .unwrap();
        let mut env = RuntimeEnv::default();
        env.set(owner, value.clone());
        let place = RuntimeMutablePlace::Local(owner);
        let uri = RuntimeFieldProjection::Agent(RuntimeAgentField::ResourceUri);
        for _ in 0..2 {
            assert_eq!(
                uri.inspect(env.inspect_place(&place).unwrap()),
                Ok(RuntimeValue::String("resource://one".into()))
            );
        }
        assert_eq!(env.get(owner), Some(&value));
        let body_projection = RuntimeFieldProjection::Agent(RuntimeAgentField::ResourceBody);
        assert_eq!(
            body_projection.inspect(env.inspect_place(&place).unwrap()),
            Err(RuntimeEvalError::AffineFieldCopy)
        );
        assert_eq!(env.get(owner), Some(&value));
        let moved = env
            .read(&RuntimeLocalRead::from_admitted_parts(
                owner,
                RuntimeLocalReadMode::Move,
            ))
            .unwrap();
        assert_eq!(moved, value);
        assert_eq!(
            env.inspect_place(&place),
            Err(RuntimeEvalError::UninitializedLocal(owner))
        );
    }

    fn local(ordinal: u32) -> RuntimeLocalDeclarationId {
        RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::new(ordinal).unwrap())
    }

    #[test]
    fn program_capture_moves_commit_once_after_preparation_and_keep_source_order() {
        use crate::plan::RuntimeProgramTaskCapture as Capture;
        let affine = local(1);
        let scalar = local(2);
        let mut env = RuntimeEnv::default();
        let need = crate::tests::reusable_need("capture.move");
        let correlation = need.correlation();
        env.set(affine, RuntimeValue::NeedHandle(need));
        env.set(scalar, RuntimeValue::Bool(true));
        let captures = [Capture::copy(scalar), Capture::moved(affine)];

        drop(
            env.prepare_local_captures(
                captures.iter().map(|capture| (capture.local, capture.mode)),
            )
            .unwrap(),
        );
        assert!(
            matches!(env.get(affine), Some(RuntimeValue::NeedHandle(handle)) if handle.correlation() == correlation)
        );
        assert_eq!(env.get(scalar), Some(&RuntimeValue::Bool(true)));

        let mut child = env
            .prepare_local_captures(captures.iter().map(|capture| (capture.local, capture.mode)))
            .unwrap()
            .commit();
        assert_eq!(env.get(affine), None);
        assert_eq!(env.get(scalar), Some(&RuntimeValue::Bool(true)));
        assert_eq!(
            child.scopes[0]
                .slots
                .iter()
                .map(|slot| slot.local)
                .collect::<Vec<_>>(),
            vec![scalar, affine]
        );
        assert!(
            matches!(child.take(affine), Some(RuntimeValue::NeedHandle(handle)) if handle.correlation() == correlation)
        );
        assert_eq!(child.take(affine), None);
        assert_eq!(child.get(scalar), Some(&RuntimeValue::Bool(true)));
    }

    #[test]
    fn rejected_program_capture_preparation_preserves_all_earlier_moves() {
        use crate::plan::RuntimeProgramTaskCapture as Capture;
        let first = local(1);
        let second = local(2);
        let missing = local(3);
        let mut env = RuntimeEnv::default();
        let first_need = crate::tests::reusable_need("capture.first");
        let second_need = crate::tests::reusable_need("capture.second");
        let correlations = [first_need.correlation(), second_need.correlation()];
        env.set(first, RuntimeValue::NeedHandle(first_need));
        env.set(second, RuntimeValue::NeedHandle(second_need));
        assert!(matches!(
            env.prepare_local_captures([Capture::moved(first), Capture::copy(second)].into_iter().map(|capture| (capture.local, capture.mode))),
            Err(RuntimeEvalError::AffineLocalCopy(local)) if local == second
        ));
        assert!(matches!(
            env.prepare_local_captures([Capture::moved(first), Capture::moved(missing)].into_iter().map(|capture| (capture.local, capture.mode))),
            Err(RuntimeEvalError::UninitializedLocal(local)) if local == missing
        ));
        assert!(matches!(
            env.prepare_local_captures([Capture::moved(first), Capture::moved(first)].into_iter().map(|capture| (capture.local, capture.mode))),
            Err(RuntimeEvalError::DuplicateLocalCapture { local }) if local == first
        ));
        for (local, correlation) in [first, second].into_iter().zip(correlations) {
            assert!(
                matches!(env.get(local), Some(RuntimeValue::NeedHandle(handle)) if handle.correlation() == correlation)
            );
        }
    }

    #[test]
    fn checked_local_reads_copy_only_unrestricted_values_and_transfer_moves_once() {
        let affine = local(1);
        let scalar = local(2);
        let mut env = RuntimeEnv::default();
        let need = RuntimeValue::NeedHandle(crate::tests::reusable_need("need.local-read"));
        env.set(affine, need.clone());
        env.set(scalar, RuntimeValue::Bool(true));

        let copy_affine = RuntimeLocalRead::from_admitted_parts(affine, RuntimeLocalReadMode::Copy);
        assert_eq!(
            env.read(&copy_affine),
            Err(RuntimeEvalError::AffineLocalCopy(affine))
        );
        assert_eq!(env.get(affine), Some(&need));

        let copy_scalar = RuntimeLocalRead::from_admitted_parts(scalar, RuntimeLocalReadMode::Copy);
        assert_eq!(env.read(&copy_scalar), Ok(RuntimeValue::Bool(true)));
        assert_eq!(env.read(&copy_scalar), Ok(RuntimeValue::Bool(true)));

        let move_affine = RuntimeLocalRead::from_admitted_parts(affine, RuntimeLocalReadMode::Move);
        assert_eq!(env.read(&move_affine), Ok(need));
        assert_eq!(
            env.read(&move_affine),
            Err(RuntimeEvalError::UninitializedLocal(affine))
        );
    }

    #[test]
    fn whole_partial_assignment_requires_child_evidence_and_displaces_only_remaining_owners() {
        use crate::value::{
            RuntimeAssignment, RuntimeDisplacedField, RuntimePlaceDisplacement,
            RuntimePlaceInitialization,
        };
        let source = local(1);
        let first = RuntimeRecordFieldId::try_from_zero_based_ordinal(0).unwrap();
        let mut env = RuntimeEnv::default();
        env.set(
            source,
            RuntimeValue::try_record(vec![
                (
                    "first".into(),
                    RuntimeValue::NeedHandle(crate::tests::reusable_need("moved")),
                ),
                (
                    "second".into(),
                    RuntimeValue::NeedHandle(crate::tests::reusable_need("remaining")),
                ),
            ])
            .unwrap(),
        );
        let moved = env
            .read(&RuntimeLocalRead::from_admitted_place(
                source,
                RuntimeLocalReadMode::Move,
                vec![first].into_boxed_slice(),
            ))
            .unwrap();
        assert_eq!(
            moved,
            RuntimeValue::NeedHandle(crate::tests::reusable_need("moved"))
        );
        let assignment = |fields| {
            RuntimeAssignment::new(
                RuntimeMutablePlace::Local(source),
                RuntimePlaceDisplacement::Reachable {
                    initialization: RuntimePlaceInitialization::Initialized,
                    fields,
                },
            )
        };
        let rejected = env
            .assign_place(&assignment(Box::new([])), RuntimeValue::Bool(false))
            .unwrap_err();
        assert_eq!(rejected.into_parts().1, RuntimeValue::Bool(false));
        assert_eq!(env.bindings_snapshot()[0].storage().values().count(), 1);
        let displaced = env
            .assign_place(
                &assignment(
                    vec![RuntimeDisplacedField {
                        fields: vec![first].into_boxed_slice(),
                        initialization: RuntimePlaceInitialization::Uninitialized,
                    }]
                    .into_boxed_slice(),
                ),
                RuntimeValue::Bool(false),
            )
            .unwrap();
        assert_eq!(
            displaced,
            vec![RuntimeValue::NeedHandle(crate::tests::reusable_need(
                "remaining"
            ))]
        );
        assert_eq!(env.get(source), Some(&RuntimeValue::Bool(false)));
    }

    #[test]
    fn partial_field_move_preserves_siblings_and_rollback_then_restores_the_slot() {
        use crate::pattern::RuntimeSemanticTypeId;
        use crate::plan::{
            RuntimeLocalDeclarationSeed, RuntimePlanBuilder, RuntimePlanRecordField,
            RuntimePlanTypeProjection, RuntimePlanTypeSeed,
        };
        let identity = |value| RuntimeSemanticTypeId::from_bytes([value; 32]);
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [
                    RuntimePlanTypeSeed::new(identity(1), RuntimePlanTypeProjection::Unit),
                    RuntimePlanTypeSeed::new(identity(2), RuntimePlanTypeProjection::Bool),
                    RuntimePlanTypeSeed::new(
                        identity(3),
                        RuntimePlanTypeProjection::Need(identity(1)),
                    ),
                    RuntimePlanTypeSeed::new(
                        identity(4),
                        RuntimePlanTypeProjection::Record(Box::new([
                            RuntimePlanRecordField::new("owner", identity(3)),
                            RuntimePlanRecordField::new("other", identity(2)),
                        ])),
                    ),
                ],
                [RuntimeLocalDeclarationSeed::new(manual_local_source("arcweft-core.fixture.value.env.partial_field_move_preserves_siblings_and_rollback_then_restores_the_slot.binding_a"), identity(4))],
            )
            .unwrap();
        let pattern = builder
            .lower_pattern_seed_for_test(crate::plan::RuntimePatternSeed::new(
                identity(4),
                crate::plan::RuntimePatternSeedKind::Bind {
                    mutable: true,
                    local: admitted.local_ids()[0].clone(),
                },
            ))
            .unwrap();
        let source = pattern.binding_declarations().next().unwrap().local();
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let owner = RuntimeProgramOwner::Plan(std::sync::Arc::new(builder.finish().unwrap()));
        let field = RuntimeRecordFieldId::try_from_zero_based_ordinal(0).unwrap();
        let other = RuntimeRecordFieldId::try_from_zero_based_ordinal(1).unwrap();
        let mut env = RuntimeEnv::default();
        env.set(
            source,
            RuntimeValue::try_record(vec![
                (
                    "owner".into(),
                    RuntimeValue::NeedHandle(crate::tests::reusable_need("need.first")),
                ),
                ("other".into(), RuntimeValue::Bool(true)),
            ])
            .unwrap(),
        );
        let move_field = RuntimeLocalRead::from_admitted_place(
            source,
            RuntimeLocalReadMode::Move,
            vec![field].into_boxed_slice(),
        );
        let copy_other = RuntimeLocalRead::from_admitted_place(
            source,
            RuntimeLocalReadMode::Copy,
            vec![other].into_boxed_slice(),
        );
        assert_eq!(
            env.read(&move_field),
            Ok(RuntimeValue::NeedHandle(crate::tests::reusable_need(
                "need.first"
            )))
        );
        assert_eq!(env.read(&copy_other), Ok(RuntimeValue::Bool(true)));
        assert!(env.get(source).is_none());
        assert_eq!(env.bindings().count(), 1);
        assert_eq!(env.bindings_snapshot().len(), 1);
        assert!(!env.bindings_snapshot()[0].storage().is_vacant());
        let image = env.inert_rollback_image(&owner).unwrap();
        let mut wrong_child = image.clone();
        let encoded = serde_json::to_value(&wrong_child.scopes[0].slots[0].value).unwrap();
        let mut forged = encoded;
        let wrong = super::super::AwbcRuntimeValueSnapshot::from_runtime_value_for_program(
            &RuntimeValue::Unit,
            &owner,
        )
        .unwrap();
        forged["Record"]["fields"][1] = serde_json::json!({"Initialized": wrong});
        wrong_child.scopes[0].slots[0].value = serde_json::from_value(forged).unwrap();
        assert!(RuntimeEnv::from_rollback_image(wrong_child, &owner).is_err());
        let mut wrong_header = image.clone();
        let mut forged = serde_json::to_value(&wrong_header.scopes[0].slots[0].value).unwrap();
        forged["Record"]["header"]["Structural"]["names"][1] = serde_json::json!("foreign");
        wrong_header.scopes[0].slots[0].value = serde_json::from_value(forged).unwrap();
        assert!(RuntimeEnv::from_rollback_image(wrong_header, &owner).is_err());
        let mut restored = RuntimeEnv::from_rollback_image(image, &owner).unwrap();
        assert_eq!(
            restored.read(&move_field),
            Err(RuntimeEvalError::UninitializedLocal(source))
        );
        assert_eq!(restored.read(&copy_other), Ok(RuntimeValue::Bool(true)));
        assert!(
            restored
                .assign_runtime_place(
                    RuntimeMutablePlace::Fields {
                        base: source,
                        fields: vec![field].into_boxed_slice()
                    },
                    RuntimeValue::NeedHandle(crate::tests::reusable_need("need.second"))
                )
                .unwrap()
                .is_empty()
        );
        assert!(restored.get(source).is_some());
        let displaced = restored
            .assign_runtime_place(
                RuntimeMutablePlace::Local(source),
                RuntimeValue::Bool(false),
            )
            .unwrap();
        assert_eq!(displaced.len(), 1);
        assert!(
            matches!(&displaced[0], RuntimeValue::Record(record) if matches!(record.fields()[0].value(), RuntimeValue::NeedHandle(need) if need == &crate::tests::reusable_need("need.second")))
        );
    }

    #[test]
    fn moved_declaration_reinitializes_in_its_original_scope_after_rollback() {
        use crate::plan::{
            RuntimeLocalDeclarationSeed, RuntimePlanBuilder, RuntimePlanTypeProjection,
            RuntimePlanTypeSeed,
        };
        let boolean = crate::pattern::RuntimeSemanticTypeId::from_bytes([0x77; 32]);
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [RuntimePlanTypeSeed::new(
                    boolean,
                    RuntimePlanTypeProjection::Bool,
                )],
                [
                    RuntimeLocalDeclarationSeed::new(
                        manual_local_source("arcweft-core.fixture.value.env.moved.outer"),
                        boolean,
                    ),
                    RuntimeLocalDeclarationSeed::new(
                        manual_local_source("arcweft-core.fixture.value.env.moved.inner"),
                        boolean,
                    ),
                ],
            )
            .unwrap();
        let locals = admitted
            .local_ids()
            .iter()
            .map(|local| {
                builder
                    .lower_pattern_seed_for_test(crate::plan::RuntimePatternSeed::new(
                        boolean,
                        crate::plan::RuntimePatternSeedKind::Bind {
                            mutable: true,
                            local: local.clone(),
                        },
                    ))
                    .unwrap()
                    .binding_declarations()
                    .next()
                    .unwrap()
                    .local()
            })
            .collect::<Vec<_>>();
        let outer = locals[0];
        let inner = locals[1];
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let owner = RuntimeProgramOwner::Plan(std::sync::Arc::new(builder.finish().unwrap()));
        let mut env = RuntimeEnv::default();
        env.set(outer, RuntimeValue::Bool(false));
        assert_eq!(env.take(outer), Some(RuntimeValue::Bool(false)));
        let image = env.inert_rollback_image(&owner).unwrap();
        assert_eq!(
            image.scopes[0].slots,
            [RuntimeLocalSlot::new(
                outer,
                super::super::RuntimePlaceStorage::default()
            )]
        );
        let mut restored = RuntimeEnv::from_rollback_image(image, &owner).unwrap();
        restored.push_scope();
        restored.set(inner, RuntimeValue::Bool(false));
        let displaced = restored
            .assign_runtime_place(RuntimeMutablePlace::Local(outer), RuntimeValue::Bool(true))
            .unwrap();
        assert!(displaced.is_empty());
        restored.pop_scope();
        assert_eq!(restored.get(outer), Some(&RuntimeValue::Bool(true)));
        assert!(restored.get(inner).is_none());
    }

    #[test]
    fn empty_nearest_slot_does_not_resolve_an_outer_same_identity_value() {
        let source = local(1);
        let mut env = RuntimeEnv::default();
        env.set(source, RuntimeValue::Bool(false));
        env.push_scope();
        env.set(source, RuntimeValue::Bool(true));
        assert_eq!(env.take(source), Some(RuntimeValue::Bool(true)));
        assert!(env.get(source).is_none());
        assert!(env.take(source).is_none());
        let read = RuntimeLocalRead::from_admitted_parts(source, RuntimeLocalReadMode::Copy);
        assert_eq!(
            env.read(&read),
            Err(RuntimeEvalError::UninitializedLocal(source))
        );
        let displaced = env
            .assign_runtime_place(RuntimeMutablePlace::Local(source), RuntimeValue::Bool(true))
            .unwrap();
        assert!(displaced.is_empty());
        assert_eq!(env.get(source), Some(&RuntimeValue::Bool(true)));
        env.pop_scope();
        assert_eq!(env.get(source), Some(&RuntimeValue::Bool(false)));
    }

    #[test]
    fn rejected_place_write_retains_the_owned_input_and_existing_slots() {
        let mut env = RuntimeEnv::default();
        let target = local(1);
        env.set(target, RuntimeValue::Bool(false));
        let input = RuntimeValue::NeedHandle(crate::tests::reusable_need("need.rejected-write"));
        let error = env
            .assign_runtime_place(RuntimeMutablePlace::Local(local(2)), input)
            .unwrap_err();
        let (cause, retained) = error.into_parts();
        assert_eq!(cause, RuntimeEvalError::UnknownLocal(local(2)));
        assert_eq!(
            retained,
            RuntimeValue::NeedHandle(crate::tests::reusable_need("need.rejected-write"))
        );
        assert_eq!(env.get(target), Some(&RuntimeValue::Bool(false)));
        assert!(env.get(local(2)).is_none());
    }

    #[test]
    fn scopes_resolve_plan_local_ids_without_names() {
        let root = local(1);
        let shadow = local(2);
        let mut env = RuntimeEnv::default();
        env.set_root(root, RuntimeValue::Bool(true));
        env.push_scope();
        env.set(shadow, RuntimeValue::String("inner".to_owned()));

        assert_eq!(env.get(root), Some(&RuntimeValue::Bool(true)));
        assert_eq!(
            env.get(shadow),
            Some(&RuntimeValue::String("inner".to_owned()))
        );
        assert_eq!(
            env.bindings_snapshot(),
            vec![
                RuntimeLocalSlot {
                    local: root,
                    value: RuntimeValue::Bool(true).into(),
                },
                RuntimeLocalSlot {
                    local: shadow,
                    value: RuntimeValue::String("inner".to_owned()).into(),
                },
            ]
        );
    }

    #[test]
    fn reused_runtime_scope_owns_and_clears_its_typed_identity() {
        let identity = RuntimeScopeIdentity::Named(
            arcweft_id::DeclarationName::try_new("window").expect("valid scope name"),
        );
        let mut env = RuntimeEnv::default();
        env.push_scope_with_identity(identity.clone());
        assert_eq!(
            env.scopes.last().map(|scope| &scope.identity),
            Some(&identity)
        );

        env.pop_scope();
        env.push_scope();
        assert_eq!(
            env.scopes.last().map(|scope| &scope.identity),
            Some(&RuntimeScopeIdentity::Anonymous)
        );
    }

    #[test]
    fn field_assignment_uses_nominal_defining_order_identity() {
        let local = local(1);
        let field = RuntimeRecordFieldId::try_from_zero_based_ordinal(1).unwrap();
        let mut env = RuntimeEnv::default();
        env.set(
            local,
            RuntimeValue::NominalRecord(RuntimeNominalRecordValue::new(
                RuntimeNominalTypeId::try_new("game.Pair").unwrap(),
                crate::pattern::RuntimeSemanticTypeId::from_bytes([9; 32]),
                TypeLayoutHash::from_bytes([9; 32]),
                vec![
                    RuntimeValue::Bool(true),
                    RuntimeValue::String("old".to_owned()),
                ],
            )),
        );

        assert_eq!(
            env.assign_runtime_place(
                RuntimeMutablePlace::Fields {
                    base: local,
                    fields: vec![field].into_boxed_slice()
                },
                RuntimeValue::String("new".to_owned())
            ),
            Ok(vec![RuntimeValue::String("old".to_owned())])
        );
        let Some(RuntimeValue::NominalRecord(record)) = env.get(local) else {
            panic!("nominal record remains bound");
        };
        assert_eq!(
            record.field(field),
            Some(&RuntimeValue::String("new".to_owned()))
        );
    }

    #[test]
    fn sequence_pop_front_mutates_the_nearest_binding_and_moves_values() {
        let local = local(9);
        let mut env = RuntimeEnv::default();
        env.set_root(
            local,
            RuntimeValue::Seq(RuntimeSeq::values(vec![RuntimeValue::String(
                "outer".to_owned(),
            )])),
        );
        env.push_scope();
        env.set(
            local,
            RuntimeValue::Seq(RuntimeSeq::values(vec![
                RuntimeValue::String("first".to_owned()),
                RuntimeValue::String("second".to_owned()),
            ])),
        );

        assert_eq!(
            env.pop_sequence_front(&RuntimeMutablePlace::Local(local)),
            Ok(Some(RuntimeValue::String("first".to_owned())))
        );
        assert_eq!(
            env.get(local),
            Some(&RuntimeValue::Seq(RuntimeSeq::values(vec![
                RuntimeValue::String("second".to_owned(),)
            ])))
        );

        env.pop_scope();
        assert_eq!(
            env.get(local),
            Some(&RuntimeValue::Seq(RuntimeSeq::values(vec![
                RuntimeValue::String("outer".to_owned(),)
            ])))
        );
        assert_eq!(
            env.pop_sequence_front(&RuntimeMutablePlace::Local(local)),
            Ok(Some(RuntimeValue::String("outer".to_owned())))
        );
        assert_eq!(
            env.pop_sequence_front(&RuntimeMutablePlace::Local(local)),
            Ok(None)
        );
    }

    #[test]
    fn sequence_pop_front_mutates_a_nominal_vec_field_in_place() {
        let local = local(10);
        let field = RuntimeRecordFieldId::try_from_zero_based_ordinal(0).unwrap();
        let mut env = RuntimeEnv::default();
        env.set(
            local,
            RuntimeValue::NominalRecord(RuntimeNominalRecordValue::new(
                RuntimeNominalTypeId::try_new("game.Container").unwrap(),
                crate::pattern::RuntimeSemanticTypeId::from_bytes([10; 32]),
                TypeLayoutHash::from_bytes([10; 32]),
                vec![RuntimeValue::Seq(RuntimeSeq::values(vec![
                    RuntimeValue::String("first".to_owned()),
                    RuntimeValue::String("second".to_owned()),
                ]))],
            )),
        );

        let place = RuntimeMutablePlace::Fields {
            base: local,
            fields: vec![field].into_boxed_slice(),
        };
        assert_eq!(
            env.pop_sequence_front(&place),
            Ok(Some(RuntimeValue::String("first".to_owned())))
        );
        let Some(RuntimeValue::NominalRecord(record)) = env.get(local) else {
            panic!("nominal record remains bound after field mutation");
        };
        let Some(RuntimeValue::Seq(sequence)) = record.field(field) else {
            panic!("Vec stays in its nominal field");
        };
        assert_eq!(sequence.len(), 1);
        assert_eq!(
            sequence.value_at(0),
            RuntimeValue::String("second".to_owned())
        );
    }

    #[test]
    fn vector_end_mutation_targets_the_nearest_local_or_nominal_field() {
        let local = local(11);
        let field = RuntimeRecordFieldId::try_from_zero_based_ordinal(0).unwrap();
        let mut env = RuntimeEnv::default();
        env.set_root(local, RuntimeValue::Seq(RuntimeSeq::dense_i32(vec![1])));
        env.push_scope();
        env.set(
            local,
            RuntimeValue::NominalRecord(RuntimeNominalRecordValue::new(
                RuntimeNominalTypeId::try_new("game.Items").unwrap(),
                crate::pattern::RuntimeSemanticTypeId::from_bytes([11; 32]),
                TypeLayoutHash::from_bytes([11; 32]),
                vec![RuntimeValue::Seq(RuntimeSeq::dense_i32(vec![2]))],
            )),
        );
        let place = RuntimeMutablePlace::Fields {
            base: local,
            fields: vec![field].into_boxed_slice(),
        };
        assert_eq!(env.push_sequence_item(&place, RuntimeValue::i32(3)), Ok(()));
        assert_eq!(env.pop_vector_item(&place), Ok(Some(RuntimeValue::i32(3))));
        env.pop_scope();
        let place = RuntimeMutablePlace::Local(local);
        assert_eq!(env.pop_vector_item(&place), Ok(Some(RuntimeValue::i32(1))));
        assert_eq!(env.pop_vector_item(&place), Ok(None));
    }
}

#[cfg(test)]
fn manual_local_source(declaration: &str) -> crate::plan::RuntimeLocalDeclarationSource {
    // This fixture declares a semantic binding name independent of its value,
    // type, source offset, and builder-issued local ordinal.
    let mut identity = blake3::Hasher::new();
    identity.update(b"arcweft.manual-fixture-binding.v1\0");
    identity.update(declaration.as_bytes());
    crate::plan::RuntimeLocalDeclarationSource::Binding {
        identity: *identity.finalize().as_bytes(),
        declaration: crate::plan::RuntimeLocalBindingDeclaration::new(
            crate::plan::RuntimeLocalBindingKind::PatternBinding,
            false,
            crate::plan::RuntimeLocalBindingStorage::Derived,
        ),
    }
}
