$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prefix='flow-transfer-native-20261109.wip2'
$base=(& git rev-parse HEAD).Trim()
if($base -ne 'cbbea7f86213bc10b2a72b37f8065b981abe741e'){throw 'Unexpected base'}
$rust=@(git diff --name-only -- '*.rs')+@('crates/arcweft-core/src/pattern/matching.rs','crates/arcweft-core/src/pattern/retained_inputs.rs')
$rows=@(foreach($p in $rust){$item=Get-Item -LiteralPath $p;[ordered]@{path=$p;bytes=$item.Length;physicalLoc=[IO.File]::ReadAllLines($item.FullName).Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$list=[IO.File]::ReadAllText((Join-Path $e 'flow-transfer-native-owner-dev-list-r1.json'))|ConvertFrom-Json -Depth 100
$binary=($list.'rust-suites'.PSObject.Properties|Where-Object {$_.Value.'binary-id' -eq 'arcweft-core'}).Value.'binary-path'
$metadata=[ordered]@{version=1;base=$base;kind='intermediate-unaccepted-source-checkpoint';sourcesObservedAfterRun=$rows;unitTestBinary=[ordered]@{path=$binary;sha256=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant()};owner=[ordered]@{filter='test(flow_transfer) | test(engine::defer) | test(ownership::binary::tests::owned_slot) | test(pattern::tests)';features='all';profile='default';selected=52;passed=52;failed=0;filterSkipped=2340;seconds=0.537;newTests=5};checks=@([ordered]@{run='r1';exit=101;errors=9},[ordered]@{run='r2';exit=0;scope='lib';seconds=47.33;warnings=175},[ordered]@{run='r3';exit=101;scope='all-targets';errors=1;reason='test helper used missing Plan.flow method; repaired before successful nextest build'});notRun=@('final reverse-dependency acceptance','workspace quality gates','explicit Source argument transfer','affine presentation Flow-root transfer','full cancellation/private rollback argument matrix')}
$metadataPath=Join-Path $e ($prefix+'.metadata.json')
[IO.File]::WriteAllText($metadataPath,($metadata|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
$archive='docs/implementation/acceptance-evidence/task-flow-transfer-native-wip2.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($archive),[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($p in $rust){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,[IO.Path]::GetFullPath($p),'source/'+$p)}
    foreach($name in @('record-flow-transfer-native-wip2.ps1',($prefix+'.metadata.json'),'flow-transfer-native-dev-check-r1.log','flow-transfer-native-dev-check-r2.log','flow-transfer-native-dev-check-r3.log','flow-transfer-native-owner-dev-list-r1.log','flow-transfer-native-owner-dev-list-r1.json','flow-transfer-native-owner-dev-r1.log')){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $e $name),'evidence/'+$name)}
}finally{$zip.Dispose()}
$archiveHash=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()
$archiveBytes=(Get-Item -LiteralPath $archive).Length
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($archive));try{$entries=$zip.Entries.Count}finally{$zip.Dispose()}
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$status=$status.Replace('tracked実装WIPは0、4 actual untrackedのローカルcacheは保持している。','途中checkpointとその未達はgoto行で区別し、4 actual untrackedのローカルcacheは保持している。')
$old='Coreの静的／動的targetと座標付き引数を一つのcarrierへ移し、v1 Source codec・走査・digest・AWBCの保持slotを更新する途中checkpointを作業中。Nativeの保留入力／取消し・復元検査、Planの集約admission、Sourceの明示bindingと回帰検証は未完了で、途中版の正常動作は未検証。'
$new='基点cbbea7f86213bc10b2a72b37f8065b981abe741eからNativeの複数保留入力と元のsource／target instantiation検査を接続中。全入力の借用検査後だけdistinct whole-localをMoveし、inert入力は一つの資源bankで型・パターンを検査する。今回のowner開発runは新規5件を含む52件PASSだが、全逆依存と品質gateの最終受入ではない。描画ハンドルのFlow root移管・取消し／private rollbackの引数matrix、Plan／codecの完全admission、Sourceの明示bindingは未完了。[途中Source・実ログ](acceptance-evidence/task-flow-transfer-native-wip2.raw.zip)。'
if(!$status.Contains($old)){throw 'Current status goto text changed'}
$status=$status.Replace($old,$new)
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),[string][char]10),[Text.UTF8Encoding]::new($false))
$historyPath='docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@'

## 2026-11-09 Native Flow入力の途中checkpoint（受入未了）

基点・先行carrier公開Source cbbea7f86213bc10b2a72b37f8065b981abe741e、mainの既存checkoutで作業。今回もユーザーの途中commit指示による保存であり、明示引数gotoの完了受入ではない。式の評価と所有値の転送を分離した。callerが記述順に評価したdistinct whole-localだけを転送operandとし、全入力を借りて完全なABI・型・パターン・重複を検査した後でまとめてMoveする。入力ごとの途中Moveによる後続評価失敗時の所有値喪失を避けるためであり、言語の引数式をlocal構文へ制限する契約ではない。

Native保留exitは全引数と元のsource／target instantiationを保持する。私有rollbackのinert入力検査は元Plan・全formal・記述順座標と照合し、live値／binding能力を再構築せず、一つの資源bankの型・構造パターン・Copy義務を検査する。構造パターンpredicateは既存matcherから一か所へ移した。借用子要素の投影は値ownerのAPIで元storage由来を保持する。保留line handleはparameter座標ごとの独立したowned slot（既存version 1のtag24）へ登録する。Sans-I/Oと依存方向は変えず、new helperはpatternの構造検査、Envの一括Move、PlanのABI、Nativeのcleanup継続にそれぞれ属する。一般pattern bindingのlive capabilityをinert readerへ流用しない。

開発check r1は変更に起因する9 compile errorで終了101、非公開borrowed fieldの直接参照などを修復。r2のcargo check --locked -p arcweft-core --all-featuresはlib終了0／47.33秒・175警告。r3のall-targets checkはtest helperが存在しないPlan.flowを呼ぶ1 errorで終了101、既存Flow tableの行探索へ修復。その後のcargo nextest list --locked -p arcweft-core --all-featuresはtest build終了0（3分35秒）、選択52／全2392を点検。同じfilterのnextest run --no-tests failは52実行／52 PASS／2340 filter SKIP／0.537秒。新規5件は記述順転送、後続型違反／未初期化時の先行値保持、affine owner alias拒否、inert全入力の共有node上限、元パターンに反する保存値改変拒否。既存Goto／Choice／deferの復元と失敗filter、AWBCの既存入力検査、patternとslot codecも含む。dev runを直近完了Sema matrixや全逆依存受入へ加算しない。

未実行の全逆依存／workspace品質gate、描画ハンドルの最終Flow root移管・取消し、引数付きprivate rollbackの完全matrix、Plan／codecの完全preflightとSourceの明示bindingを引き続き実装する。Native公開saveを対応済みとしない。既受入の引数なし拒否、Generic Match、Style等は維持する。現状一覧の「途中版は未検証」は今回の限定runに合わせて訂正し、「tracked WIPは0」という時点依存の重複記述を除いた。先行結果・失敗・SHAは削除しない。
'@
$addition += [string][char]10+'原本 '+$archive+'：'+$entries+' entries／'+$archiveBytes+' bytes／SHA256 '+$archiveHash+'。ソース・ログ・catalog・metadataのみを格納し、実行ファイル／AWFBは含めない。'+[char]10
[IO.File]::WriteAllText($historyPath,($history+$addition).Replace(([string][char]13+[char]10),[string][char]10),[Text.UTF8Encoding]::new($false))
$owned=$rust+@($archive,$statusPath,$historyPath)
[IO.File]::WriteAllLines((Join-Path $e ($prefix+'.owned.txt')),$owned,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $e ($prefix+'.other.txt')),'',[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $e ($prefix+'.message.txt')),'wip(core): retain jointly admitted Native Flow inputs through cleanup'+[char]10,[Text.UTF8Encoding]::new($false))
[ordered]@{rustPaths=$rust.Count;archive=$archive;entries=$entries;bytes=$archiveBytes;sha256=$archiveHash}|ConvertTo-Json -Compress
