$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/scoped-binding-terms.final2-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/scoped-binding-terms.final2-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/scoped-binding-terms.final2-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1631 tests run: 1625 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1631\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/scoped-binding-terms.final2-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1631 -or $terminal.Count -ne 1631 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$previous=Get-Content -Raw "$root/borrowed-binding-relation.final-terminal.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Id|Sort-Object) @($selected | Where-Object {$_ -notmatch '\$types::constraints::transaction::operand::projection::tests::bindings::'} | Sort-Object)).Count){throw 'Previous selected test IDs changed'}
$failed=@($terminal | Where-Object Result -eq 'FAIL' | ForEach-Object Name | Sort-Object)
$baseline=Get-Content -Raw "$root/original-context-retention-fixed.owner-summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$new=@($terminal | Where-Object Name -Match 'types::constraints::transaction::operand::projection::tests::bindings::')
if($new.Count -ne 6 -or @($new | Where-Object Result -ne 'PASS').Count){throw 'Owner regressions missing'}
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob){throw 'Source changed'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    $baseText=@(git show "$($pin.ChangeBase):$($p.Path)" 2>$null); $baseLines=if($LASTEXITCODE -eq 0){$baseText.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '(^|/)(tests(/|\.rs$)|[^/]*_tests\.rs$|test_support\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=0;SHA256=$p.SHA256;Blob=$p.Blob}
})
$structure=Get-Content -Raw "$root/scoped-binding-terms.structure.json" | ConvertFrom-Json
if($structure.ExitCode -ne 0 -or (Get-Content -Raw "$root/scoped-binding-terms.structure.stdout") -notmatch '(?m)^blocking violations: 0\r?$'){throw 'Structural gate not verified'}
$baselineSource='b75f80f1db2c5b668762a36ac293fda14860eea2'
if($pin.ChangeBase -ne $baselineSource -or (git rev-parse HEAD) -ne $pin.Base){throw 'Published source/base mismatch'}
$terminal | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/scoped-binding-terms.final2-terminal.json"
[ordered]@{Version=1;Base=$pin.Base;Selected=1631;Passed=1625;Failed=6;Skipped=0;SlowTests=if($summary.Groups['slow'].Success){[int]$summary.Groups['slow'].Value}else{0};IdsEqual=$true;PreviousIdsRetainedWithSixAdditions=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;SourcePinsVerified=$true;ChangeBase=$pin.ChangeBase;Checkpoint=$pin.Base;SourcePublishedBeforeFinalValidation=$true;StructureExit=0;BlockingViolations=0;ClippyExit=0;FmtExit=0;Measurements=$measurements;Ownership='Bindings now own type or const ConstraintOperand values with actual scope and origin. The relation accepts borrowed operands, recurses through the shared exhaustive shape iterator and retains exact selected ports. Direct alias proof is a flat list of actual occurrences and looked-up replacement terms, with real intermediate scope transport and pointer-continuity checks; cycles remain provisional reference witnesses. Restored rows retain the actual Arc<TypeConstraintSolution> and exact sealed key. Original products use actual stored RHS operands and authenticated LHS binding owners. Projection lookup checks the stored scope against the admitted key owner rather than reconstructing a receiving scope. Nonbinding child scopes share the retained frame inventory. Existing direct-first-child vs sliced-child fork accounting is retained, including empty tuples. Test fixtures are cfg(test), with the obsolete redundant shape argument removed. No dependency, external public shape, unsafe, I/O, version or budget changes. Normalization currently retains initial carrier origin through projected; the iterative fold still needs corresponding child/header derivation output, certified effect substitution, capture seal and final Free authorization. This cut does not claim those complete.';ReverseEvidence='Current all-feature/all-target-platform normal/dev/build cargo tree re-observed 22 reverse packages. All changed producers and consumers are private to Sema; full owner/frontend/API compile tests cover the migrated API. Cargo inputs and external wire/public shapes are unchanged. The 21 consumer execution results remain pinned to 8b5e375a9c7b3096fe5ed2f65df556a463741a8d and are not a new run or a combined current total. Canonical structural gate completed with zero blocking violations.';Development='Initial production check failed on old alias facade exports, ambiguous overloaded view references, and the inherited receiver Arc migration; repaired, then library check passed. Fixture builds failed on raw binding views, Arc imports and map equality and were migrated without weakening assertions. The earlier 1630-test development run produced 1624 pass and the same 6 fail in 101.169 seconds, but source edits during it caused the runner input guard to reject it as final evidence. Review then repaired the tuple empty/sliced path, retained original branch accounting, removed the redundant test shape argument, and added the branch-budget regression. The checkpoint was published at user-authorized intermediate validation scope. Final2 is a separate complete four-step pinned run on the published source. Existing root/alias/capture assertions and exact budgets remain. Raw failures and the changed-input rejection are retained.'} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$root/scoped-binding-terms.summary.json"
Get-Content "$root/scoped-binding-terms.summary.json" -TotalCount 16
# Canonical counts measure inline test modules; cfg(test) helper items remain
# included in physical LOC. Classification follows the actual parent module.
$summary=Get-Content -Raw "$root/scoped-binding-terms.summary.json" | ConvertFrom-Json
$metricRows=Import-Csv "$root/scoped-binding-terms.structure/file_metrics.csv"
foreach($measurement in $summary.Measurements){
 $row=@($metricRows | Where-Object path -CEQ $measurement.Path)
 if($row.Count -ne 1 -or [int]$row[0].physical_lines -ne $measurement.PhysicalLOC -or [long]$row[0].bytes -ne $measurement.Bytes){throw 'Canonical measurement mismatch'}
 $measurement.EmbeddedTestLOC=[int]$row[0].embedded_test_lines
 $measurement | Add-Member NoteProperty EmbeddedTestLOCMeaning 'Canonical inline test-module source only; cfg(test) helper items outside modules remain included in physical LOC and were reviewed as fixture-only.'
}
$summary | Add-Member NoteProperty DependencyMetrics (Import-Csv "$root/scoped-binding-terms.structure/package_metrics.csv" | Where-Object package -CEQ 'arcweft-lang-sema')
$summary | Add-Member NoteProperty ClassificationNote 'test_support.rs is classified as test because its parent module is cfg(test); the canonical filename-based CSV classification is retained unchanged as raw evidence.'
$summary | ConvertTo-Json -Depth 9 | Set-Content "$root/scoped-binding-terms.summary.json" -Encoding utf8
