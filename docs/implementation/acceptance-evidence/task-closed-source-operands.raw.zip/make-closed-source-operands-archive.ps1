$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$archivePath='D:\git\arcweft\docs\implementation\acceptance-evidence\task-closed-source-operands.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive already exists'}
$publication=Get-Content -Raw "$root/closed-source-operands.publication.json" | ConvertFrom-Json
$summary=Get-Content -Raw "$root/closed-source-operands.summary.json" | ConvertFrom-Json
$pin=Get-Content -Raw "$root/closed-source-operands.final-input.json" | ConvertFrom-Json
$consumer=Get-Content -Raw "$root/closed-source-operands.consumer-summary.json" | ConvertFrom-Json
$broad=Get-Content -Raw "$root/closed-source-operands.broad-quality.json" | ConvertFrom-Json
if($consumer.Source -ne $publication.Source -or $consumer.Targets -ne 107 -or $consumer.Passed -ne 2507 -or $consumer.Failed -ne 2 -or $consumer.Skipped -ne 1 -or $broad.Source -ne $publication.Source -or $broad.Steps.Count -ne 3 -or @($broad.Steps | Where-Object ExitCode -ne 0).Count){throw 'Broad evidence is incomplete'}
if($summary.Passed -ne 1636 -or $summary.Failed -ne 6 -or $summary.ClippyExit -ne 0 -or $summary.FmtExit -ne 0 -or (git rev-parse HEAD) -ne $publication.Source -or @(git diff --name-only HEAD).Count){throw 'Value-context evidence incomplete'}
foreach($record in $pin.Paths){if((Get-FileHash -LiteralPath $record.Path -Algorithm SHA256).Hash -ne $record.SHA256){throw 'Value-context source input changed'}}
$files=@(Get-ChildItem -LiteralPath $root -File | Where-Object Name -Like 'closed-source-operands.*')
$files+=Get-Item "$root/make-closed-source-operands-archive.ps1", "$root/run-closed-source-operands-final.ps1", "$root/audit-closed-source-operands.ps1"

$files+=Get-ChildItem -LiteralPath "$root/closed-source-operands.structure" -File
$files+=Get-ChildItem -LiteralPath "$root/closed-source-operands-reverse", "$root/closed-source-operands-compiler" -File -Recurse
$files+=Get-Item "$root/run-closed-source-operands-broad.ps1", "$root/audit-closed-source-operands-consumers.ps1"

$entries=@($files | Sort-Object FullName -Unique | ForEach-Object {[pscustomobject]@{Path=[IO.Path]::GetRelativePath($root,$_.FullName).Replace([char]92,[char]47);Bytes=$_.Length;SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}})
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Parent=$publication.Parent;Selected=1642;Passed=1636;Failed=6;Skipped=0;Duplicates=0;ClippyExit=0;FmtExit=0;StructureExit=0;BlockingViolations=0;FullOwnerRun=$true;ConsumerPackages=21;ConsumerTargets=107;ConsumerPassed=2507;ConsumerFailed=2;ConsumerSkipped=1;WorkspaceCheckExit=0;WorkspaceClippyExit=0;SemaDoctestsPassed=2;ReverseGraphReusedFrom='5012e0c6d26655fe005d150c321d47051a21096f';ConsumersNotRerun=$false;LastBroadSource=$publication.Source;Commands=@('cargo nextest list --locked -p arcweft-lang-sema --all-features --lib --tests --message-format json','cargo nextest run --locked -p arcweft-lang-sema --all-features --lib --tests --no-fail-fast --no-tests fail --message-format libtest-json-plus','cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features','cargo fmt --all -- --check');Environment=@{CARGO_INCREMENTAL='0';NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1';JobsOverride=$false;ProfileOverride=$false};Entries=$entries}
$manifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($manifest | ConvertTo-Json -Depth 10))
Add-Type -AssemblyName System.IO.Compression
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite)
try {
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try {
        foreach ($record in $entries) {
            $entry=$zip.CreateEntry($record.Path,[IO.Compression.CompressionLevel]::Optimal)
            $target=$entry.Open()
            try {
                $bytes=[IO.File]::ReadAllBytes((Join-Path $root $record.Path))
                if ($bytes.Length -ne $record.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $record.SHA256) { throw 'Evidence changed while archiving' }
                $target.Write($bytes,0,$bytes.Length)
            } finally { $target.Dispose() }
        }
        $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal)
        $target=$entry.Open()
        try { $target.Write($manifestBytes,0,$manifestBytes.Length) } finally { $target.Dispose() }
    } finally { $zip.Dispose() }
} finally { $stream.Dispose() }
$verified=0
$rawBytes=0L
$read=[IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($read.Entries.Count -ne ($entries.Count+1)) { throw 'Archive entry count differs' }
    foreach ($entry in $read.Entries) {
        $inputStream=$entry.Open()
        $memory=[IO.MemoryStream]::new()
        try { $inputStream.CopyTo($memory); $bytes=$memory.ToArray() } finally { $inputStream.Dispose(); $memory.Dispose() }
        $expected=if ($entry.FullName -eq 'manifest.json') {
            [pscustomobject]@{Bytes=$manifestBytes.Length;SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($manifestBytes)).ToLowerInvariant()}
        } else { @($entries | Where-Object Path -CEQ $entry.FullName)[0] }
        if ($bytes.Length -ne $expected.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $expected.SHA256) { throw "Archive readback mismatch: $($entry.FullName)" }
        $rawBytes+=$bytes.Length
        $verified++
    }
} finally { $read.Dispose() }
[ordered]@{Version=1;Source=$publication.Source;Path=$archivePath;Entries=$verified;RawBytes=$rawBytes;Bytes=(Get-Item -LiteralPath $archivePath).Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();AllEntriesReadbackVerified=$true;ManifestVerified=$true} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/closed-source-operands.archive.json"
Get-Content "$root/closed-source-operands.archive.json"
