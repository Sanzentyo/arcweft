param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
& "$taskTemp/assert-no-arcweft-build.ps1"
$prefix=Join-Path $taskTemp $Stem
if(Test-Path "$prefix.source.json"){throw 'Epoch already exists'}
$paths=@(@((Get-Content "$taskTemp/line-initial-inputs-20261108.compiler-expectation-r2.source.json" -Raw|ConvertFrom-Json).inputs.path)+'crates/arcweft-core/src/engine/dialogue/scope.rs'|Sort-Object -Unique)
$epoch=@(foreach($path in $paths){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$base=(git rev-parse HEAD).Trim()
[ordered]@{base=$base;inputs=$epoch}|ConvertTo-Json -Depth 8|Set-Content "$prefix.source.json"
$started=[DateTime]::UtcNow
& cargo check --locked -p arcweft-core --all-features *> "$prefix.log"
$code=$LASTEXITCODE
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
[ordered]@{base=$base;command=@('check','--locked','-p','arcweft-core','--all-features');exitCode=$code;sourceInputs=$epoch.Count;sourceDrift=0;startedAt=$started.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content "$prefix.receipt.json"
Get-Content "$prefix.log" -Tail 35
exit $code
