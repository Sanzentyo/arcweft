$ErrorActionPreference='Stop'
$taskTemp=$PSScriptRoot
$terminal="$taskTemp/native-scope-result-20261108.final-core.runtime.terminal-audit.json"
while(-not (Test-Path -LiteralPath $terminal)){Start-Sleep -Seconds 2}
$core=Get-Content $terminal -Raw|ConvertFrom-Json
if($core.executed -ne 2330 -or $core.passed -ne 2330 -or $core.failed -ne 0){throw 'Final Core library is not passing'}
& "$taskTemp/run-line-root-frozen-nextest-20261108.ps1" -Stem 'native-scope-result-20261108.final-owners' -Selection @('--locked','-p','arcweft-compiler','--all-features','--test','evaluated_effects','--test','scoped_defer') -ExpectedMatches 166 -AdditionalPaths @('crates/arcweft-core/src/engine/dialogue/scope.rs')
if($LASTEXITCODE -ne 0){throw 'Final Compiler owners failed'}
& "$taskTemp/run-native-scope-workspace-quality-r2-20261108.ps1"
if($LASTEXITCODE -ne 0){throw 'Final workspace quality failed'}
