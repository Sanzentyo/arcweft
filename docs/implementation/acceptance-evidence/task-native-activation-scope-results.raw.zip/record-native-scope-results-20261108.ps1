$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='native-scope-result-20261108'
$source=(Get-Content "$taskTemp/$stem.source.verified.json" -Raw|ConvertFrom-Json).commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Unexpected published source'}
foreach($gate in @('check','clippy','structure','fmt')){
 $receipt=Get-Content "$taskTemp/$stem.workspace-quality-r2.$gate.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw "Gate unavailable: $gate"}
}
$terminal=Get-Content "$taskTemp/$stem.final-owners.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$unit=Get-Content "$taskTemp/$stem.final-core.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($terminal.executed -ne 166 -or $terminal.passed -ne 166 -or $terminal.failed -ne 0 -or $unit.passed -ne 2330 -or $unit.failed -ne 0){throw 'Owner terminal differs'}
$epoch=(Get-Content "$taskTemp/$stem.final-owners.source-freeze.json" -Raw|ConvertFrom-Json).paths
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$coreEpoch=(Get-Content "$taskTemp/$stem.final-core.source-freeze.json" -Raw|ConvertFrom-Json).paths
foreach($row in ($coreEpoch|Where-Object path -like 'crates/arcweft-core/*')){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Core owner source drift: $($row.path)"}}
$untracked=(Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json).files
foreach($row in $untracked){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked drift'}}
. "$taskTemp/convergence-image-git-bytes.ps1"
$metrics=Import-Csv "$taskTemp/$stem.structure-report-r2/file_metrics.csv"
$rows=@(foreach($path in (Get-Content "$taskTemp/$stem.source.owned.txt" | Where-Object {$_ -like '*.rs'})){
 $metric=@($metrics|Where-Object path -eq $path)
 if($metric.Count -ne 1){throw "Missing metrics: $path"}
 $present=@(git ls-tree --name-only b028f834e50ec94193a5ffbe1b821f58b762e342 -- $path)
 $oldLines=0
 if($present.Count){
  $old=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('b028f834e50ec94193a5ffbe1b821f58b762e342:'+$path))))
  $oldLines=($old -split "`n").Count-[int]$old.EndsWith("`n")
 }
 [ordered]@{path=$path;owner=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLines=[int]$metric[0].physical_lines;classification=$metric[0].classification;embeddedTestLines=[int]$metric[0].embedded_test_lines;growth=[int]$metric[0].physical_lines-$oldLines}
})
[ordered]@{version=1;source=$source;workingTree='Published source; no own uncommitted Rust paths; original 12 tracked / 6 actual untracked WIP preserved; only this evidence recording remains dirty.';files=$rows;cargoChanges=0;packageMetrics=@(Import-Csv "$taskTemp/$stem.structure-report-r2/package_metrics.csv" | Where-Object package -in @('arcweft-core','arcweft-compiler'));graph='Cargo graph unchanged: workspace 98 / resolved 846 / Core reverse 53. Fresh workspace compile gates do not constitute a fresh Core53 runtime matrix.';ownership='The actual Native activation frame owns one PendingActivationScopeResult. The original group/operation and actual scope depth authenticate the retained value under the original result type and invocation in the shared allowance. NativeDialogueScopeResult identifies the real physical cell by execution/activation, binary tag 23, all contract markers remain 1. Live values are moved; only admitted inert rollback images implement Clone.';cohesion='The scope owner module now owns scope exit and result retention together; the old scope cleanup implementation was removed from dialogue.rs. One complete issuer proof covers local drops and the pending result transfer/drop before pop/binding. All 9 Rust file byte/LOC/embedded-test growth is retained, including the new module. No dependency change, I/O, unsafe, fallback, legacy reader, persistent side table or API widening for file splitting. Core fan-out/fan-in remains its recorded Cargo closure, workspace 98 / resolved 846 / Core reverse 53.'}|ConvertTo-Json -Depth 12|Set-Content "$taskTemp/$stem.ownership-review.json"
$archive='docs/implementation/acceptance-evidence/task-native-activation-scope-results.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name.StartsWith($stem+'.') -or $_.Name -in @('record-native-scope-results-20261108.ps1','run-native-scope-workspace-quality-20261108.ps1','run-native-scope-workspace-quality-r2-20261108.ps1','run-native-scope-final-validation-20261108.ps1','run-line-root-frozen-nextest-20261108.ps1','run-native-scope-check-20261108.ps1')}|Sort-Object Name)
$items=@(foreach($file in $files){[ordered]@{path=$file.FullName;entry=$file.Name}})+@(Get-ChildItem "$taskTemp/$stem.structure-report-r2" -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.FullName;entry=('structure-report/'+$_.Name)}})
$entries=@(foreach($item in $items){[ordered]@{entry=$item.entry;bytes=(Get-Item -LiteralPath $item.path).Length;sha256=(Get-FileHash -LiteralPath $item.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($item in $items){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$item.path,$item.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Archive shape differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive content differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$source;priorSource='c7ad0e974c297fc51c47557790489e78fd1b42b5';probeBase='b028f834e50ec94193a5ffbe1b821f58b762e342'
 accepted='The remaining Native explicit init-scope regression now passes. Native and saved AWBC also pass Actor scope-result binding/discard across normal and explicitly targeted inner-dialogue cancellation: 2 backends x 2 destinations x 2 outcomes, preserving 1-op/512-step, 3 unique reveals, ordered logs, one acquire/release and release only after suspended cleanup completes. AWBC saves/cold restores public JSON at every step.'
 implementation='ExitScopeBind evaluates once into the actual activation-owned pending cell, reconciles its custody and parks the operation. Existing lexical defer progress drains cleanup, then one complete preflight transfers the result to the original pattern or drops it with current locals. Failed/cancelled scope exit discards the pending value. The sole physical cell is included in live/inert roots, rollback mapping and exact original-issuer slot inventory; original operation/type/depth/phase are checked in the shared admission allowance. Binary slot tag 23 is version 1; unknown tag test advances to 24 without a new schema or legacy reader.'
 validation=[ordered]@{owners=$terminal;coreAllFeaturesLibrary=$unit;finalSource='After review restored the existing explicit Default drop boundary in the moved scope owner, source 625deea6d6051469fc0c60a4e6808727fb42c21d was published as a coherent checkpoint under the user authorization for intermediate commits. The complete 2330-case Core library, 166-case Compiler owners and workspace gates are then rerun on those published Rust bytes.';forgeries='Retained operation, scope depth, original result type and enclosing frontier/depth are refused. The shared max_nodes=0 boundary refuses the same inert value. A separate Bool pending-result test executes both failed and cancelled scope exits without publishing it. The slot codec checks exact 61-byte tag-23 shape, human JSON, ordering/rendering, all truncated prefixes and trailing bytes.';gates='Fresh all-target/all-feature workspace check/Clippy, canonical structure gate and 9 Rust path fmt exit 0; warnings retained';sourceInputs=3417;sourceDrift=0;scope='Core all-feature 2330-case library and Compiler 166-case selections are separate invocations. Compiler test IDs each execute binding/discard and normal/inner-cancel branches. The Core failed/cancelled result case uses Bool, not an Actor failure-path claim. Native public Save was not added. A new full Core53 runtime matrix is still separate.'}
 history='Initial Core check passed and the original Compiler 164 cases all passed after the Native implementation. The new Core admission fixture initially failed as an orphan line task group; the corrected attached fixture then exposed two missing test imports before runtime. Final 3-case Core run passed all. Compiler 166-case run passed 164 with two new fixtures rejected at HIR readiness; a diagnostic-only Native probe reproduced the same failure. The fixture used an invented cancellation spelling and was corrected to the existing cancel on input(.SkipLine) grammar without budget/assertion reduction. A 166-case run passed all before final review. Review then restored the original explicit Default boundary authorization for scope drops; the final published source reran the full 2330-case Core library, 166 Compiler owners and workspace gates. Each original source epoch, actual executable identity, failure and compile-only preparation result is retained separately.'
 remaining='The concrete Native explicit scope condition in the initial-input row is resolved. Other accepted features stay accepted. The broader goal still has its independently tracked Native public Save, final full Core53/CLI consumer acceptance, platform/Tier2 and full Native-Web parity conditions; none are claimed by this owner cut.'
 preserved='122 older ledger records preserved. Original WIP is 12 tracked / 6 actual untracked, independently verified. Historical focused-wrapper held=14 labels are not actual WIP counts. Generic Match and all earlier accepted boundaries remain accepted.'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'nativeActivationScopeResults'){throw 'Record already exists'}
$fragment=([ordered]@{nativeActivationScopeResults=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($prop in $old.PSObject.Properties){if(($prop.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($prop.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Historical evidence changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| Line の初期所有入力 |')){
 "| Line の初期所有入力 | **返却Actor／Copy・root deferの既受入を保持。追加init／scoped条件を両backendで検証・公開済み** | root defer Source 5ba67c20a9aacafe3d1dd25939be42c92cddf52a、Native入力保持 5f3e6deedf4dca6d9251b72530f5edb354655e4c、保存AWBC子receiver c7ad0e974c297fc51c47557790489e78fd1b42b5 の受入を維持。Source $source は残っていたNative明示init scopeを修復。scope結果のActorをcleanup完了まで実activationに保持し、束縛／破棄×通常／内側対話取消し×2 backendの8条件を1-op／512-step・3 reveal・取得／解放各1回で通過し、解放がcleanupに先行しないことを確認。AWBCは毎step公開JSON保存／cold restore。Compiler owner 166／166 PASS・除外0、Core全feature library 2330／2330 PASS（認証／失敗・取消し破棄／codec関連3件を含む）。新保持状態の型・元exit・深さ改変と上限拒否、旧失敗と訂正理由は履歴へ保持。Native公開save等の別境界へ拡張しない。[実測・全SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 "| workspace check／Clippy・fmt・構造gate | **Native activation scope結果cutの全workspace gateは終了0** | Source $source の全target／全feature workspace check／Clippy、canonical構造gate、9 Rust path fmtが3417 Rust／Cargo／config／toolchain入力drift0で終了0。先行SourceのCore53 matrixを新Sourceの全件結果へ合成しない。Cargo依存変更0。全14 family・他platform／Tier2・全表示parityの最終受入へ拡張しない。[実測・構造責任・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — Native activation scopeの結果保持

Source **$source** は、初期所有入力の残条件だったNative明示init scopeの結果受取りを修復した。既存scope終了をdialogue/scope ownerへ移し、元ExitScopeBindを一度評価して実activationの単一pending cellへMoveする。cleanup待機中は結果を保持し、全scope-local dropと結果の束縛／破棄を一つのissuer proofで事前検査してからscopeをpopする。失敗・取消しexitは結果を公開しない。live／inert inventoryとprivate rollbackも同じcellを扱い、元operation／型／scope深さ／phaseを共有allowanceで検査する。NativeDialogueScopeResultはbinary tag 23、契約versionは1のまま、unknown tag拒否は24へ進める。

元の164件は全PASS。追加のActor結果は束縛／破棄×通常／実内側対話取消し×Native／保存AWBCの8条件で、元の1-op／512-step、3つの一度だけのreveal、Actor取得・解放各1回とlog順を維持し、cleanup完了前の解放を拒否した。AWBCは各step公開JSON save／cold restore。最終Compiler ownerは **166／166 PASS・除外0**。Core全feature libraryは関連3件を含む2330／2330 PASS。Coreの失敗・取消しexit unitはBool結果を使う範囲であり、Actorの失敗経路やNative公開Saveを検証したとはしない。

Core admission fixtureのorphan group失敗、紐付け後の2 import不足によるcompile失敗、追加Compiler fixtureのHIR readiness拒否2件と診断probe1件を保持。取消し構文を既存のcancel on input(.SkipLine)へ訂正し、予算・host assertionを緩めず166件全PASSとした。最終差分で移設前の明示Default drop許可を保持するよう訂正し、Source 625deea6d6051469fc0c60a4e6808727fb42c21d を途中checkpointとしてpushした。その公開Rust bytesでCore全2330件・Compiler166件・全workspace gateを再実行し、先行の3件runや166件runと異なるepochを一runへ合成しない。

全workspace all-target／all-feature check／Clippy、canonical構造gateと9 Rust path fmtは終了0。3417 Rust／Cargo／config／toolchain入力drift0。新scope ownerを含む9 Rustファイルのbyte／LOC／embedded tests／増分と構造責任を保持し、Cargo変更・I/O・unsafe・永続side table・legacy reader・version bumpはない。全Core53／CLI runtimeは別の最終検証として継続する。既受入Generic Match・root defer等を戻さず、現状の追加init／scoped条件を通過根拠で更新した。[各run・公開full SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;historicalRecordsPreserved=$old.PSObject.Properties.Name.Count;archiveEntries=$entries.Count;archiveSha256=$record.raw.sha256;compilerPassed=$terminal.passed;compilerFailed=$terminal.failed}|ConvertTo-Json -Compress
