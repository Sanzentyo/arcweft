$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='callable-result-join-reverse22-20261106'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -Depth 100}
$terminal=Read-Record ($stem+'.runtime.terminal-audit')
$receipt=Read-Record ($stem+'.runtime')
$inventory=Read-Record ($stem+'.catalog.inventory')
$freeze=Read-Record ($stem+'.source-freeze')
$qualityFreeze=Read-Record 'callable-result-join-branches1-20261106.source-freeze'
$lines=[IO.File]::ReadAllLines($receipt.log)
$summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
if($summary -lt 0){throw 'No terminal summary'}
$statusLines=if($terminal.caseRowSource -eq 'final-status-after-summary'){$lines[($summary+1)..($lines.Length-1)]}else{$lines[0..($summary-1)]}
$cases=@{}
foreach($line in $statusLines){if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
 $key=$Matches[2]+"`t"+$Matches[3]
 if($cases.ContainsKey($key)){throw 'Repeated terminal case'}
 $cases[$key]=$Matches[1]
}}
if($cases.Count -ne $terminal.executed){throw 'Terminal cases differ'}
$packageRows=@(foreach($group in ($inventory.rows | Where-Object status -eq 'matches' | Group-Object package)){
 $passed=0;$failed=0
 foreach($row in $group.Group){$key=$row.binary+"`t"+$row.test;if(-not $cases.ContainsKey($key)){throw 'Missing selected case'};if($cases[$key] -in @('PASS','SLOW')){$passed++}else{$failed++}}
 [ordered]@{package=$group.Name;executed=$group.Count;passed=$passed;failed=$failed}
})
$old=Read-Record 'view-agent-summary-reverse55-20261106.runtime.terminal-audit'
$oldFailures=@($old.failureSet | ForEach-Object {$_.binary+"`t"+$_.test} | Sort-Object)
$newFailures=@($terminal.failureSet | ForEach-Object {$_.binary+"`t"+$_.test} | Sort-Object)
$qualityIndex=@{};foreach($row in $qualityFreeze.paths){$qualityIndex[$row.path]=$row.sha256}
$qualityDrift=@($freeze.paths | Where-Object {-not $qualityIndex.ContainsKey($_.path) -or $qualityIndex[$_.path] -ne $_.sha256})
if($qualityDrift.Count -or $qualityIndex.Count -ne $freeze.paths.Count){throw 'Workspace quality and consumer Source bytes differ'}
$referencePath='docs/implementation/acceptance-evidence/accepted-generic-c3-c5-closure-audit.json'
$reference=Get-Content -LiteralPath $referencePath -Raw | ConvertFrom-Json
$genericGroups=@(foreach($group in $reference.groups.PSObject.Properties){
 $rows=@(foreach($case in $group.Value){$key=$case.binary+"`t"+$case.name;[ordered]@{binary=$case.binary;test=$case.name;status=$(if($cases.ContainsKey($key)){$cases[$key]}else{'MISSING'})}})
 [ordered]@{group=$group.Name;expected=$rows.Count;passed=@($rows|Where-Object status -in @('PASS','SLOW')).Count;missing=@($rows|Where-Object status -eq 'MISSING').Count;failed=@($rows|Where-Object status -notin @('PASS','SLOW','MISSING')).Count;rows=$rows}
})
$generic=[ordered]@{version=1;source=$receipt.base;reference=$referencePath;referenceSha256=(Get-FileHash -LiteralPath $referencePath).Hash.ToLowerInvariant();accepted='850534b9e9bc8c8872f6528dd00050a5e6e7699e';published='f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2';expected=0;passed=0;missing=0;failed=0;groups=$genericGroups;scope='Exact accepted binary/test identity comparison within the complete22-package callable-result diagnostic consumer run. Other CLI failures do not reopen accepted Generic Match.'}
$generic.expected=0;$generic.passed=0;$generic.missing=0;$generic.failed=0
foreach($group in $genericGroups){$generic.expected+=$group.expected;$generic.passed+=$group.passed;$generic.missing+=$group.missing;$generic.failed+=$group.failed}
if($generic.expected -ne 151){throw 'Accepted Generic Match reference set differs'}
$generic | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $t ($stem+'.generic-match.json')) -Encoding utf8
$cli=@($packageRows | Where-Object package -eq 'arcweft-cli')
$nonCli=@($packageRows | Where-Object package -ne 'arcweft-cli')
$record=[ordered]@{version=1;source=$receipt.base;terminal=$terminal;packages=$packageRows;runtimePackages=$packageRows.Count;hostBuildOnly=$terminal.noMatchingSelectedTests;cli=$cli;nonCli=[ordered]@{executed=0;passed=0;failed=0};failureComparison=[ordered]@{referenceSource=$old.base;referenceRun=$old.run;previousFailureCount=$old.failed;currentFailureCount=$terminal.failed;newFailureIds=@($newFailures|Where-Object {$_ -notin $oldFailures});noLongerFailingIds=@($oldFailures|Where-Object {$_ -notin $newFailures});note='Compare actual terminal IDs. The current result is a fresh full run, not arithmetic recomputation of the older result.'};quality=[ordered]@{sourceInputs=$freeze.paths.Count;sourceDrift=0;matchingInput='callable-result-join-reverse22-20261106';check=Read-Record 'callable-result-join-quality2-20261106-check';clippy=Read-Record 'callable-result-join-quality2-20261106-clippy';structure=Read-Record 'callable-result-join-quality2-20261106-structure';warnings='Warnings remain.'};genericMatch=[ordered]@{expected=$generic.expected;passed=$generic.passed;missing=$generic.missing;failed=$generic.failed;referenceSha256=$generic.referenceSha256};workingTree='The recorded original12 tracked WIP (including the two required borrowed summary reads) participated in the frozen Source input; this is not a pristine committed-tree claim. The overlapping test publication contains only its owned RAG assertion hunk.';recordedAt=[DateTime]::UtcNow.ToString('o')}
$record.nonCli.executed=0;$record.nonCli.passed=0;$record.nonCli.failed=0
foreach($row in $nonCli){$record.nonCli.executed+=$row.executed;$record.nonCli.passed+=$row.passed;$record.nonCli.failed+=$row.failed}
$record | ConvertTo-Json -Depth 25 | Set-Content -LiteralPath (Join-Path $t ($stem+'.consumer-audit.json')) -Encoding utf8
[ordered]@{source=$receipt.base;summary=$terminal.summary;packages=$packageRows.Count;hostBuildOnly=$terminal.noMatchingSelectedTests;cli=$cli;nonCli=$record.nonCli;newFailures=$record.failureComparison.newFailureIds;noLongerFailing=$record.failureComparison.noLongerFailingIds;qualitySourceDrift=0;generic=$record.genericMatch} | ConvertTo-Json -Depth 6
