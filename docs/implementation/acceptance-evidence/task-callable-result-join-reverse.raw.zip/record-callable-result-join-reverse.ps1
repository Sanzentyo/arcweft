$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='callable-result-join-reverse22-20261106'
$audit=Get-Content -LiteralPath (Join-Path $t ($stem+'.consumer-audit.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($audit.terminal.executed -ne 4130 -or $audit.terminal.passed -ne 4119 -or $audit.terminal.failed -ne 11 -or $audit.nonCli.failed -or $audit.genericMatch.passed -ne 151){throw 'Unexpected terminal result'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$historyPath='docs/implementation/convergence-evidence-history.md'
$statusPath='docs/implementation/current-status.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('callableResultJoinReverse')){throw 'Existing immutable result'}
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {$_.Name.StartsWith($stem+'.')})
$files+=@(Get-Item -LiteralPath (Join-Path $t 'audit-callable-result-join-reverse.ps1'),(Join-Path $t 'record-callable-result-join-reverse.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'run-presentation-projection-owner.ps1'))
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-callable-result-join-reverse.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$record.callableResultJoinReverse=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source='f2d9dc791bb0f7ecfc13b47792511086a5c31878';audit=$audit;scope='Complete22-package reverse closure for the typed diagnostic owner; not a complete workspace runtime or final platform acceptance.';correctionReason='Replace only the pending22 consumer run and old CLI totals in the single current list with this fresh terminal result. Preserve earlier full55 and focused runs unchanged. The old renamed Sema ID is absent by renaming, while the new unregistered-modifier case passes in this run. No new failures; all11 failures are CLI conditions already retained. Generic Match remains accepted/public with151 exact cases passing.';raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| CLI全target照合 |')){
 '| CLI全target照合 | **最新の全700実測は689 PASS／11 FAIL。戻り値診断は修復済み** | Source f2d9dc791bb0f7ecfc13b47792511086a5c31878の全22逆依存runでCLI全700を実行した実測。残る11 IDはfull-grammar現在line選択3件、Scroll解決1件、旧plan／unsafe fixture2件、run-edge1件、負例診断1件、verifier fixture3件。Thread戻り値診断・RAG・z-indexと他の既受入を未完了へ戻さない。以前の688 PASS／12 FAILや修復runは履歴に保持し、合算・再計算しない。[終端・全ID・入力・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
 '| 共有契約／推移的逆依存matrix | **戻り値診断の全22 packageを完走。4130実行4119 PASS／11 FAIL／24 skipped** | Source f2d9dc791bb0f7ecfc13b47792511086a5c31878、670.161秒、終了100。CLI以外3430件は全PASS、11失敗は上記CLIのみ。22 packageすべてに実行caseがあり、Source4113・case・実行ファイルdrift0。Generic Matchの既受入151件は全PASS、missing0／failed0。以前の全55の9579実行9553 PASS／26 FAILは履歴に保持する。これは当該ownerの逆依存境界であり、全workspace runtime・最終platform受入を主張しない。[実graph・各終端・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Callable-result diagnostic reverse closure completed

- Source f2d9dc791bb0f7ecfc13b47792511086a5c31878: complete22-package reverse closure,4130run4119PASS11FAIL24skipped,670.161s,exit100. CLI700run689PASS11FAIL; nonCLI3430run3430PASS. All22 packages have runtime cases. Source4113/case/executable drift0. This is a fresh full selected run, not arithmetic applied to the historical55-package failures.
- The exact accepted Generic Match151 cases allPASS,missing0/failed0,reference SHA82b6519b1ccbfcd4aee95d3ef8b69db686037924a7f9137de0fef0201d86b996. Acceptance/publication remains unchanged. The repaired Thread-result diagnostic and consumer fixtures pass. The old Sema test identity disappeared because the test was renamed; its new unregistered-modifier case is present and passes. Retain prior unsuccessful runs and source/commit identities.
- Supersedes the pending22-run statement and old current CLI totals, with the reason and all11 failing IDs retained. Dedicated doctest/wasm, final Tier2 and Native-Web image parity remain separate boundaries. Warnings remain. [Terminal, inventory, exact reference comparison and immutable raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Prior evidence changed: '+$key)}}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{version=1;source=$audit.source;rawPath=$rawPath;rawBytes=$raw.bytes;rawSha256=$raw.sha256;rawEntries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'callable-result-join-reverse-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'callable-result-join-reverse-documentation-audit.json')
