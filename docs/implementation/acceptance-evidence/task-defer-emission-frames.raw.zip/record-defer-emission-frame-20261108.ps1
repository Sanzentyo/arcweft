$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='defer-emission-frame-20261108'
$source=Get-Content -LiteralPath "$taskTemp/$prefix.source.verified.json" -Raw | ConvertFrom-Json
if((& git rev-parse HEAD).Trim() -ne $source.commit){throw 'Published source differs'}
$receipts=[ordered]@{}
foreach($name in @('compiler','scoped','runtime-plan','clippy','structure','fmt')){
 $receipt=Get-Content -LiteralPath "$taskTemp/$prefix.quality-final.$name.receipt.json" -Raw | ConvertFrom-Json
 if($receipt.exitCode -ne $(if($name -eq 'compiler'){100}else{0})){throw "Unexpected gate outcome: $name"}
 $receipts[$name]=$receipt
}
$freeze=Get-Content -LiteralPath "$taskTemp/$prefix.quality-final.source.json" -Raw | ConvertFrom-Json
foreach($row in $freeze.inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$ledgerPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($ledgerPath)
if($before.Contains('"deferEmissionFrames"')){throw 'Evidence already recorded'}
$archivePath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-defer-emission-frames.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Raw archive exists'}
$names=@(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*" | ForEach-Object Name)+@('run-defer-emission-frame-quality-20261108.ps1','run-defer-emission-frame-quality-final-20261108.ps1','record-defer-emission-frame-20261108.ps1') | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object {Join-Path $taskTemp $_}) -DestinationPath $archivePath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
 if($zip.Entries.Count -ne $entries.Count){throw 'Raw archive count differs'}
 foreach($entry in $zip.Entries){
  $expected=$entries | Where-Object entry -eq $entry.FullName
  $stream=$entry.Open()
  try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
  if($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256){throw 'Raw archive bytes differ'}
 }
}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';source=$source
 behavior=@('One construction-frame index selects the actual reserved defer definition, not a copied local table or a runtime fallback.', 'Exact scoped expression owners distinguish closed generic instances. HIR body projections and statement evaluation edges retain body-owned roots; nested defer roots keep their own frames.', 'Dialogue value/callback capture producers, Line plans and deferred bodies use the same selected physical frame. No runtime IDs, public grammar, dependencies or wire versions change.')
 actual=[ordered]@{
  compiler=[ordered]@{run=104;passed=100;failed=4;skipped=0;receipt=$receipts.compiler}
  scopedDefer=[ordered]@{run=30;passed=30;failed=0;skipped=0;receipt=$receipts.scoped}
  runtimePlan=[ordered]@{run=165;passed=165;failed=0;skipped=1;receipt=$receipts.'runtime-plan';note='Actual unit and integration run, including public API compile checks. Not combined with the previous 134-case owner run.'}
  positiveNativeCases=@('ordinary_defer::native_nested_deferred_line_uses_the_innermost_capture_frame','ordinary_defer::native_generic_deferred_line_uses_each_closed_capture_frame')
  boundaries=[ordered]@{operationBound=1;tickBound=512;nativeNestedReveals=2;nativeGenericReveals=3;genericInstantiations=@('integer literal 7','String literal value');stageAcquireAndRelease=1}
  quality=$receipts
  freeze=[ordered]@{base=$freeze.base;paths=$freeze.inputs.Count;selection='rg --files --hidden: *.rs, Cargo.toml, Cargo.lock, rust-toolchain*, .cargo/config*; target and .git excluded';drift=0;note='This is a new scoped input inventory, not a relabeling of the earlier complete 3834-input matrix.'}
 }
 developmentFailures=@(
  [ordered]@{receipt="$prefix.first.receipt.json";failure='E0583 module lookup';resolution='Explicit path attribute for a child of the explicitly imported final_flow.rs module.'},
  [ordered]@{receipt="$prefix.r1.receipt.json";failure='structural ExprId slot 50 had no admitted semantic owner';resolution='Visit every selected expression owner, including structural non-value nodes.'},
  [ordered]@{receipt="$prefix.r2.receipt.json";failure='unknown runtime local declaration 4';resolution='Traverse HIR-owned statement/body roots as well as selected expression dependencies.'},
  [ordered]@{receipt="$prefix.r3.receipt.json";failure='AffineGroupCapture';resolution='Physical frame mismatch is fixed; the owned activation input boundary remains open.'},
  [ordered]@{receipt="$prefix.positive.receipt.json";failure='Both combined Native/AWBC tests reached the AWBC deferred-dialogue rejection at tick 39 after Native passed';resolution='Keep separate named Native and saved-AWBC cases in the full 104-case run.'}
 )
 remainingFailures=@(
  'ordinary_defer::native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line: Line task captures require unrestricted values',
  'ordinary_defer::saved_awbc_ordinary_flow_defer_keeps_returned_line_actor_until_its_cleanup: invalid ordinary deferred scope transition at tick 15',
  'ordinary_defer::saved_awbc_nested_deferred_line_uses_the_innermost_capture_frame: deferred child suspended on a product-owned dialogue or choice boundary at tick 39',
  'ordinary_defer::saved_awbc_generic_deferred_line_uses_each_closed_capture_frame: same deferred child dialogue boundary at tick 39'
 )
 corrections=@('Replace the current unknown-local remaining-work clause because the same Actor input now passes the local lookup and reaches the separate affine-input guard. Native scalar nested/generic execution also passes with original operation limits.', 'The two newly named AWBC dialogue failures establish a missing ordinary-defer integration boundary; they do not reopen accepted Generic Match, Line/init or bounded Native features.', 'Collapse the cumulative ordinary-Flow current-status narrative into one current contract and the three concrete remaining boundaries. Preserve all earlier test counts, failures, raw archives and full Source SHAs in history and this append-only ledger.')
 reverseGraph=(Get-Content -LiteralPath "$taskTemp/line-out-producer-20261108.reverse-graph.json" -Raw | ConvertFrom-Json)
 ownershipReview=(Get-Content -LiteralPath "$taskTemp/$prefix.ownership-review.json" -Raw | ConvertFrom-Json -Depth 15)
 limits=@('No fresh full RuntimePlan reverse-closure16, Core53 or workspace-wide final matrix is claimed. Cargo dependency inputs are unchanged.', 'Core 2323 tests and 80 doctests at ddd7307237fb1697e15cc5cadf6efe00426ea07c are prior unchanged-Core-input evidence, not new runs.', 'AWBC capture custody, ordinary deferred-dialogue dispatch, owned initial Line input separation, cancellation and aggregate preconstruction limits still require implementation and validation.')
 raw=[ordered]@{path='task-defer-emission-frames.raw.zip';sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$fragment=([ordered]@{deferEmissionFrames=$record} | ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($ledgerPath,$after,[Text.UTF8Encoding]::new($false))
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — defer 本体が所有する Line emission frame

Source **$($source.commit)** を既存 main へ通常 commit/push し、親・tree・全 blob・完全差分を照合した。選択済みの scoped expression owner と HIR の本体・文の所有辺から、実際の reserved defer definition のローカル表を選ぶ。入れ子の登録と generic の closed instance を区別し、対話の value/callback 捕捉、Line plan、cleanup 本体を同じ frame に接続した。ローカル表の複製、実行時の名前解決 fallback、仮の runtime frame ID は追加しない。
evaluated_effects は実測104件中100 PASS／4 FAIL、通常deferは30 PASS。新しいNativeの入れ子と2型genericは、取得・解放各1回、2／3 reveal、1-op／512-stepの元上限で値とlog順序を確認した。RuntimePlanはunitとintegrationを含む165 PASS／既存fixture generator 1 SKIPで、前の134件と合成しない。RuntimePlan／Compilerの全target・全feature Clippy、6 path fmt、構造gateは終了0。冷えた公開API compile testとfanoutの所要時間も原本に残す。固定入力$($freeze.inputs.Count) pathの変動0。
元のActor再現のunknown local 4は解消し、次のAffineGroupCaptureまで進んだ。この根拠により現状の捕捉先誤りを削除し、Line開始時の所有入力と開始後の共有入力の分離を残す。AWBCの返却Actor登録拒否と、追加2入力のdefer子からの対話開始拒否も具体的な未達として保持する。既受入Generic Match／Line-init／Native範囲は変更しない。現状一覧の通常Flow行は累積した経緯を整理し、経緯・全SHA・実測はここおよびledgerに保持する。[原本と全結果](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。Core53／全workspaceの最終再検証は未実施。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=$status -split "`n"
$matching=@(0..($lines.Length-1) | Where-Object {$lines[$_].StartsWith('| 通常 Flow の scoped defer |')})
if($matching.Count -ne 1){throw 'Ordinary Flow status row differs'}
$lines[$matching[0]]='| 通常 Flow の scoped defer | **Native の既受入を保持。Source／AWBC の通常 cleanup・goto／Choice・待機・Flow registry は対象を検証・公開済み。全体受入は継続中** | 関数本体・明示scopeのLIFO、generic捕捉／戻り値、registryの読書き・drop／置換、cleanup後のgoto／Choice移譲、失敗時のcaller drain、待機と毎step version 1公開保存／cold restoreを検証済み。raw Return／Completeはopen scopeを拒否する。直接outするActor取得と効果付き関数の値継続もNative／保存付きAWBCで通過する。Source '+$source.commit+' はcleanup内Lineを実際のdefer frameへ接続し、入れ子・2型genericをNativeで検証したため、unknown local 4の旧残作業を削除した。全evaluated_effectsは104件中100 PASS／4 FAIL。残る実測は、Line開始時の所有入力と開始後の共有入力の未分離、AWBC通常deferでのLine handle登録拒否、AWBC defer子からの対話開始拒否（2ケース）の3境界。AWBC取消し・登録／子構築前の集約検査も継続中。必須registry読取りには静的存在証明が必要。累積していた経緯は履歴へ集約した。[全実測・訂正理由・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$gate=@(0..($lines.Length-1) | Where-Object {$lines[$_].StartsWith('| workspace check／Clippy・fmt・構造gate |')})
if($gate.Count -ne 1){throw 'Quality status row differs'}
$lines[$gate[0]]='| workspace check／Clippy・fmt・構造gate | **直近の全workspace gateはSource b6dfで終了0。追加Sourceのowner gateも終了0** | 全workspaceの直近入力はSource `b6df0c825805b9ac77cad6a9760761a861007679`。Coreの直近2323 PASS／doctest80 PASSはSource `ddd7307237fb1697e15cc5cadf6efe00426ea07c`で、以後Core入力は不変。最新Source '+$source.commit+' はRuntimePlan unit／integration 165 PASS／1 SKIP、Compilerの通常defer30 PASS、RuntimePlan・Compiler全target／全feature Clippy、6 path fmt、構造gateが終了0。Compiler evaluated_effectsの4失敗は通常Flow行で追跡する。旧cut別件数・初回失敗・警告・全SHAは履歴に保持する。新Sourceの全workspace／Core53最終再検証は未実施。他platform／Tier2の受入へ拡張しない。[全実測・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;entries=$entries.Count;rawSha256=$record.raw.sha256;compilerPassed=100;compilerFailed=4;runtimePlanPassed=165;scopedPassed=30} | ConvertTo-Json
