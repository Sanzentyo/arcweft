$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$prefix=Join-Path $taskTemp 'defer-emission-frame-20261108.quality-final'
$owned=@(
 'crates/arcweft-runtime-plan/src/final_flow.rs',
 'crates/arcweft-runtime-plan/src/final_flow/defer.rs',
 'crates/arcweft-runtime-plan/src/final_flow/emission_frame.rs',
 'crates/arcweft-runtime-plan/src/final_flow/line_plan.rs',
 'crates/arcweft-runtime-plan/src/semantic_facts.rs',
 'crates/arcweft-compiler/tests/evaluated_effects/ordinary_defer.rs'
)
& rustfmt --edition 2024 --config skip_children=true @owned
if($LASTEXITCODE -ne 0){throw 'Formatting failed'}
$inputs=@(rg --files --hidden -g '*.rs' -g 'Cargo.toml' -g 'Cargo.lock' -g 'rust-toolchain*' -g '.cargo/config*' -g '!target' -g '!.git' | Sort-Object -Unique)
$freeze=@(foreach($p in $inputs){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
if(Test-Path -LiteralPath "$prefix.source.json"){throw 'Evidence epoch exists'}
[ordered]@{base=(& git rev-parse HEAD).Trim();inputs=$freeze} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$prefix.source.json" -Encoding utf8NoBOM
function Assert-Inputs {
 foreach($row in $freeze){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Input drift: $($row.path)"}}
}
function Run-Cargo([string]$name,[string[]]$arguments){
 Assert-Inputs
 $started=[DateTime]::UtcNow
 & cargo @arguments *> "$prefix.$name.log"
 $code=$LASTEXITCODE
 Assert-Inputs
 [ordered]@{arguments=$arguments;exitCode=$code;sourceInputs=$freeze.Count;sourceDrift=0;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$prefix.$name.receipt.json" -Encoding utf8NoBOM
 Get-Content -LiteralPath "$prefix.$name.log" -Tail 10
}
Run-Cargo 'compiler' @('nextest','run','--locked','-p','arcweft-compiler','--test','evaluated_effects','--no-tests','fail','--no-fail-fast')
Run-Cargo 'scoped' @('nextest','run','--locked','-p','arcweft-compiler','--test','scoped_defer','--no-tests','fail','--no-fail-fast')
Run-Cargo 'runtime-plan' @('nextest','run','--locked','-p','arcweft-runtime-plan','--no-tests','fail','--no-fail-fast')
Run-Cargo 'clippy' @('clippy','--locked','-p','arcweft-runtime-plan','-p','arcweft-compiler','--all-targets','--all-features')
Assert-Inputs
& just structure-audit-gate *> "$prefix.structure.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{command='just structure-audit-gate';exitCode=$code;sourceInputs=$freeze.Count;sourceDrift=0} | ConvertTo-Json | Set-Content -LiteralPath "$prefix.structure.receipt.json" -Encoding utf8NoBOM
Get-Content -LiteralPath "$prefix.structure.log" -Tail 10
& rustfmt --check --edition 2024 --config skip_children=true @owned *> "$prefix.fmt.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{command='rustfmt --check --edition 2024 --config skip_children=true';exitCode=$code;paths=$owned;sourceDrift=0} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$prefix.fmt.receipt.json" -Encoding utf8NoBOM
