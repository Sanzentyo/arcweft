use std::collections::{BTreeMap, BTreeSet};
use arcweft_core::effect_row::{DecisionControl, DecisionWork, EffectDecision};
type GenericEffectReference = u8;
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum FormalOwner { Observation, Residual }
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
enum Atom {
    Formal { owner: FormalOwner, class: usize, parameter: usize },
    Presence { owner: FormalOwner, mask: usize },
}
type Decision = EffectDecision<Atom>;
#[derive(Debug)] enum PreparedEffectInvariant { UnclosedCell, TruthTableOverflow }
#[derive(Debug)] enum PreparedEffectFailure<E> { Control(E), Invariant(PreparedEffectInvariant), NonPointwiseObservation }
impl<E> From<PreparedEffectInvariant> for PreparedEffectFailure<E> {
    fn from(value: PreparedEffectInvariant) -> Self { Self::Invariant(value) }
}
struct Work<'a, C>(&'a mut C);
impl<C: DecisionControl> DecisionControl for Work<'_, C> {
    type Error = PreparedEffectFailure<C::Error>;
    fn charge(&mut self, work: DecisionWork) -> Result<(), Self::Error> {
        self.0.charge(work).map_err(PreparedEffectFailure::Control)
    }
}
struct Unmetered;
impl DecisionControl for Unmetered {
    type Error = std::convert::Infallible;
    fn charge(&mut self, _: DecisionWork) -> Result<(), Self::Error> { Ok(()) }
}
struct ObservationLayout { labels: Box<[u8]>, parameters: Box<[GenericEffectReference]> }

impl ObservationLayout {
    /// Quantify the lexical rows while retaining the whole valuation of the
    /// residual rows. A nonzero pattern may represent one or several labels.
    /// Its cardinality is unobservable in a canonical pointwise predicate.
    fn forall_except<C: DecisionControl>(
        self,
        retained: &BTreeSet<GenericEffectReference>,
        condition: Decision,
        work: &mut Work<'_, C>,
    ) -> Result<(Self, Decision), PreparedEffectFailure<C::Error>> {
        if self
            .parameters
            .iter()
            .all(|reference| retained.contains(reference))
        {
            return Ok((self, condition));
        }
        let mut parameters = Vec::new();
        let mut slots = Vec::new();
        for reference in &self.parameters {
            work.charge(DecisionWork::Visit)?;
            let slot = if retained.contains(reference) {
                work.charge(DecisionWork::Node)?;
                let slot = parameters.len();
                parameters.push(reference.clone());
                Some(slot)
            } else {
                None
            };
            work.charge(DecisionWork::Node)?;
            slots.push(slot);
        }
        let mut substitutions = BTreeMap::new();
        let mut quantified = BTreeSet::new();
        let mut groups: BTreeMap<usize, Vec<Atom>> = BTreeMap::new();
        for atom in condition.variables() {
            work.charge(DecisionWork::Visit)?;
            match *atom {
                Atom::Formal {
                    owner: FormalOwner::Observation,
                    class,
                    parameter,
                } => {
                    if substitutions.contains_key(atom) || quantified.contains(atom) {
                        continue;
                    }
                    work.charge(DecisionWork::Node)?;
                    if let Some(parameter) = slots[parameter] {
                        substitutions.insert(
                            atom.clone(),
                            Decision::variable(
                                Atom::Formal {
                                    owner: FormalOwner::Residual,
                                    class,
                                    parameter,
                                },
                                work,
                            )?,
                        );
                    } else {
                        quantified.insert(atom.clone());
                    }
                }
                Atom::Presence {
                    owner: FormalOwner::Observation,
                    mask,
                } => {
                    if quantified.contains(atom) {
                        continue;
                    }
                    let mut projection = 0;
                    for (index, slot) in slots.iter().enumerate() {
                        work.charge(DecisionWork::Visit)?;
                        if let Some(slot) = slot
                            && mask & (1usize << index) != 0
                        {
                            projection |= 1usize << slot;
                        }
                    }
                    work.charge(DecisionWork::Node)?;
                    quantified.insert(atom.clone());
                    if projection != 0 {
                        work.charge(DecisionWork::Node)?;
                        groups.entry(projection).or_default().push(atom.clone());
                    }
                }
                _ => return Err(PreparedEffectInvariant::UnclosedCell.into()),
            }
        }
        let refinements = 1usize
            .checked_shl(
                u32::try_from(slots.len() - parameters.len())
                    .map_err(|_| PreparedEffectInvariant::TruthTableOverflow)?,
            )
            .ok_or(PreparedEffectInvariant::TruthTableOverflow)?;
        let mut counterexample = condition.substitute(&substitutions, work)?.not(work)?;
        let mut singleton = Decision::constant(true);
        for (mask, observed) in groups {
            let requires_exact = observed.len() == refinements;
            let mut any = Decision::constant(false);
            for atom in observed {
                let present = Decision::variable(atom, work)?;
                // With only one available label there cannot be two distinct
                // refinements of the same nonzero residual pattern.
                singleton = singleton.and(&any.and(&present, work)?.not(work)?, work)?;
                any = any.or(&present, work)?;
            }
            let present = Decision::variable(
                Atom::Presence {
                    owner: FormalOwner::Residual,
                    mask,
                },
                work,
            )?;
            let absent = any.not(work)?;
            counterexample = counterexample.and(
                &present.conditional(
                    &if requires_exact {
                        any
                    } else {
                        Decision::constant(true)
                    },
                    &absent,
                    work,
                )?,
                work,
            )?;
        }
        let saturated = counterexample.exists(&quantified, work)?;
        let singleton = counterexample
            .and(&singleton, work)?
            .exists(&quantified, work)?;
        // Refining more labels can only admit more counterexamples. If the
        // two bounds agree, every legal multiplicity gives the same result.
        if saturated != singleton {
            return Err(PreparedEffectFailure::NonPointwiseObservation);
        }
        let condition = saturated
            .not(work)?
            .map_references(work, &mut |atom, _| match *atom {
                Atom::Formal {
                    owner: FormalOwner::Residual,
                    class,
                    parameter,
                } => Ok(Atom::Formal {
                    owner: FormalOwner::Observation,
                    class,
                    parameter,
                }),
                Atom::Presence {
                    owner: FormalOwner::Residual,
                    mask,
                } => Ok(Atom::Presence {
                    owner: FormalOwner::Observation,
                    mask,
                }),
                _ => Err(PreparedEffectInvariant::UnclosedCell.into()),
            })?;
        Ok((
            Self {
                labels: self.labels,
                parameters: parameters.into_boxed_slice(),
            },
            condition,
        ))
    }
}



fn main() {
    let mut meter = Unmetered;
    let mut work = Work(&mut meter);
    let presence = |mask| Atom::Presence { owner: FormalOwner::Observation, mask };
    let mut passed = 0u32;
    let mut unrepresentable = 0u32;
    for bits in 0u16..256 {
        let mut terms = (0..8).map(|i| Decision::constant(bits & (1 << i) != 0)).collect::<Vec<_>>();
        for mask in 1..=3 {
            let atom = Decision::variable(presence(mask), &mut work).unwrap();
            terms = terms.chunks_exact(2).map(|t| atom.conditional(&t[1], &t[0], &mut work).unwrap()).collect();
        }
        let expected = |cardinality: usize| (0..8).all(|i| {
            let projected_cardinality = (i & 5usize).count_ones() as usize;
            let realizable = if cardinality == 0 { projected_cardinality == 0 }
                else { (1..=cardinality).contains(&projected_cardinality) };
            !realizable || bits & (1 << i) != 0
        });
        let projected = ObservationLayout { labels: Box::new([]), parameters: Box::new([0, 1]) }
            .forall_except(&BTreeSet::from([0]), terms.pop().unwrap(), &mut work);
        if expected(1) != expected(2) {
            assert!(matches!(projected, Err(PreparedEffectFailure::NonPointwiseObservation)), "{bits}");
            unrepresentable += 1;
        } else {
            let (layout, value) = projected.unwrap_or_else(|err| panic!("table {bits:08b} expected absent={}, singleton={}, saturated={} but got {err:?}", expected(0), expected(1), expected(2)));
            assert_eq!(&*layout.parameters, &[0]);
            for present in [false, true] {
                let result = value.evaluate_with_control(|atom| {
                    assert_eq!(*atom, presence(1));
                    present
                }, &mut work).unwrap();
                assert_eq!(result, expected(usize::from(present)), "{bits}, {present}");
            }
            passed += 1;
        }
    }
    println!("256 truth tables | {passed} exact pointwise candidates | {unrepresentable} cardinality-dependent rejections");
}
