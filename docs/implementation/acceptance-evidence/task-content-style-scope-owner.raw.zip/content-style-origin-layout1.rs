pub fn rich_text_node_bytes() -> usize { std::mem::size_of::<arcweft_text_model::RichTextNode>() }
pub fn resolved_node_bytes() -> usize { std::mem::size_of::<arcweft_text_model::ResolvedRichTextNode>() }
pub fn style_origin_bytes() -> usize { std::mem::size_of::<arcweft_text_model::RichTextStyleOrigin>() }
