$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. (Join-Path $t 'convergence-image-git-bytes.ps1')
$prepared=Get-Content (Join-Path $t 'checkpoint-content-style-origin-20261106.prepared.json') -Raw | ConvertFrom-Json
$metadata=Get-Content (Join-Path $t 'rag-project-summary.metadata.json') -Raw | ConvertFrom-Json -Depth 100
$workspace=@($metadata.packages | Where-Object id -in $metadata.workspace_members)
$byId=@{}
foreach($package in $workspace){$byId[$package.id]=$package.name}
$edges=@(foreach($node in $metadata.resolve.nodes){
 if(-not $byId.ContainsKey($node.id)){continue}
 foreach($dependency in $node.deps){
  if($byId.ContainsKey($dependency.pkg)){
   [pscustomobject]@{from=$byId[$node.id];to=$byId[$dependency.pkg]}
  }
 }
})
function Count-Lines([string]$value){
 $reader=[IO.StringReader]::new($value);$count=0
 while($null -ne $reader.ReadLine()){$count++}
 $reader.Dispose();return $count
}
$rows=@(foreach($path in $prepared.paths.path){
 $bytes=[IO.File]::ReadAllBytes((Join-Path $PWD $path))
 $old=[byte[]]::new(0)
 if($path -ne 'crates/arcweft-compiler/tests/evaluated_effects/content_style_origin.rs'){$old=Read-GitBytes @('show',($prepared.base+':'+$path))}
 $owner=if($path -match '^crates/([^/]+)/'){$Matches[1]}else{'maintained-specification'}
 [ordered]@{path=$path;owner=$owner;bytes=$bytes.Length;loc=Count-Lines ([Text.Encoding]::UTF8.GetString($bytes));baseBytes=$old.Length;baseLoc=Count-Lines ([Text.Encoding]::UTF8.GetString($old));sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant();workspaceFanIn=@($edges | Where-Object to -eq $owner | Select-Object -ExpandProperty from -Unique).Count;workspaceFanOut=@($edges | Where-Object from -eq $owner | Select-Object -ExpandProperty to -Unique).Count}
})
$record=[ordered]@{
 version=1;source='3a98722cd92a229fc77f33d4423ef18c171b7596';base=$prepared.base;files=$rows
 graph='Actual retained metadata, targetall/featuresall/normal-build-dev; unchanged101 Cargo/toolchain pins. Direct workspace fan-in/out only, not external crates.'
 ownership=@(
 'Text-model owns the required closed authored/generated origin and bounded immutable product-source coordinates; no source text is copied. Authored origin payload is boxed so ordinary Text nodes do not pay the inline source-record size.'
 'Compiler projects the accepted application HIR Whole source once for modifier/Fx/Object scopes. Missing evidence rejects lowering; there is no source parsing, alternate resolver or fabricated origin.'
 'Materialization/rebasing/frame resolution preserve scope origin. Runtime formatter-generated color scopes explicitly carry Generated. Templates bind the typed origin in the existing version1 canonical digest; strict range decoding rejects reversed/out-of-bounds coordinates.'
 'Plan borrows the existing canonical catalog serializer and exposes records/templates. Delete the never-produced flat inline_styles/contribution model and every Frame/Stage/Context copy path, not a second style inventory. Dynamic CharacterDialogue settings remain runtime-owned.'
 'The obsolete CLI Character.dialogue_style/preset/line_options fixture is migrated to4 nested/sibling current typed scopes, preserving all3 exact colors,14px Ruby and2 child tasks. The protocol fixture previously fabricated unused EngineDefaults metadata; remove it with the obsolete type, rather than claim it was real runtime provenance.'
 'Existing consumer fixtures only lose removed constructor arguments/empty fields or mark manually generated scopes explicitly. Test graph/task/cascade/geometry/capture/restore/budget assertions remain. No production unsafe, I/O, scheduling/effect family, feature or dependency is added.'
 )
 limitations='Layout size_of observations are not speed benchmarks. Full30 runtime, workspace98 quality, wasm and doctests are separate checks.'
}
$record | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $t 'content-style-origin-owner-measurements.json') -Encoding utf8
[ordered]@{files=$rows.Count;source=$record.source;sourcePaths=@($rows|Where-Object owner -ne 'maintained-specification').Count;specPaths=@($rows|Where-Object owner -eq 'maintained-specification').Count} | ConvertTo-Json
