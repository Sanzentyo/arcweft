$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$source=Read-Record 'checkpoint-content-style-origin-20261106.verified'
$owner=Read-Record 'content-style-origin-owner2-20261106.runtime.terminal-audit'
$quality=[ordered]@{check=Read-Record 'content-style-origin-quality1-20261106-check';clippy=Read-Record 'content-style-origin-quality1-20261106-clippy';structure=Read-Record 'content-style-origin-quality1-20261106-structure'}
if($quality.check.exitCode -or $quality.clippy.exitCode -or $quality.structure.exitCode){throw 'Workspace quality failed'}
if($source.commit -ne '3a98722cd92a229fc77f33d4423ef18c171b7596' -or $owner.passed -ne 13 -or $owner.failed){throw 'Unexpected source or final owner result'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$historyPath='docs/implementation/convergence-evidence-history.md'
$statusPath='docs/implementation/current-status.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('contentStyleScopeOwner')){throw 'Existing immutable owner evidence'}
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 ($_.Name -match '^content-style-origin[-.]' -and $_.Name -notmatch '^content-style-origin-(quality|reverse)') -or $_.Name.StartsWith('checkpoint-content-style-origin-20261106.') -or $_.Name.StartsWith('cli-plan-current-style-probe.') -or $_.Name.StartsWith('cli-plan-inline-style-probe2.')
} | Where-Object Extension -in @('.json','.log','.arcw','.rs','.patch','.txt','.pathspec'))
$files+=@(Get-Item -LiteralPath (Join-Path $t 'record-content-style-scope-owner.ps1'),(Join-Path $t 'measure-content-style-origin.ps1'),(Join-Path $t 'run-presentation-projection-owner.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'rag-project-summary.metadata.json'),(Join-Path $t 'rag-project-summary.metadata.log'),(Join-Path $t 'font-family-arcweft-text-model.tree.txt'),(Join-Path $t 'font-family-arcweft-text-model.tree.log'))
$files+=@(Get-ChildItem -LiteralPath $t -File | Where-Object Name -like 'content-style-origin-quality1-20261106-*')
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'content-style-origin-quality1-20261106.structure-report') -File)
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-content-style-scope-owner.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$record.contentStyleScopeOwner=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;owner=$owner;quality=$quality;earlierOwner=Read-Record 'content-style-origin-owner1-20261106.runtime.terminal-audit';graph=Read-Record 'content-style-origin.graph';ownership=Read-Record 'content-style-origin-owner-measurements'
 layouts=[ordered]@{initial=Read-Record 'content-style-origin-layout1';final=Read-Record 'content-style-origin-layout2';scope='Measured x86_64 MSVC size_of: authored node112to80,resolved112to48,origin80to8 bytes. Not speed benchmarks. The earlier13PASS input used inline origin; the final13PASS input boxes only authored source data, with unchanged serialized shape.'}
 probes=[ordered]@{first=Read-Record 'cli-plan-current-style-probe.receipt';acceptedGap=Read-Record 'cli-plan-inline-style-probe2.receipt';reason='The first probe was denied and proves no catalog count; its corrected receipt retains the erroneous @null Count projection and correction reason. The accepted second current-grammar probe executes plan with1line/2children/1record but0inline styles, establishing the static metadata gap independently of the retired dynamic-layer fixture.'}
 behavior='Canonical Scope owns typed style, bounded authored product-source revision/range or explicit Generated origin, and nested body. Compiler uses the exact accepted HIR Whole anchor for modifier/Fx/Object; materialization/rebasing/frame resolution preserve it. Required strict codecs and existing version1 digest bind the origin. Plan borrows the canonical records/templates catalog, eliminating cloning and the never-produced parallel flat contribution list. Every consumer is migrated; no compatibility reader or version bump.'
 coverage='Final13 Rust tests pass:4CLI plan cases,1Compiler test that executes Native and decoded AWBC and both public frame-snapshot round trips,6existing formatted-content cases and2new strict range/digest/origin cases. Render-text is built in this selection but has no matching runtime case; its full consumers belong to the pending30 closure. Do not report the narrower build as runtime Render-text acceptance.'
 correctionReason='Replace only the pending static inline_styles source condition and retired plan fixture with this published typed owner result. Preserve all3 exact colors,14px Ruby and2 child tasks using current lexical scopes; active/shadowed has no global meaning across nested/sibling scopes. Remove the protocol fixture that fabricated EngineDefaults contributions with the deleted type. Keep older full700/689PASS11FAIL actual results unchanged;10 other CLI IDs remain owner conditions, not a fabricated700/10FAIL result. Do not reopen accepted Generic Match or other completed features.'
 validationScope='Original12tracked/6untracked WIP retained and present in frozen inputs4114; source/case/executable drift0. Final workspace98 all-target/all-feature/locked check/Clippy/structure exit0, warnings remain. Complete30reverse plusSema accepted-case replay is ongoing in session34824. Dedicated wasm/doctest and final Tier2/platform/image parity are separate boundaries.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| RichTextの部分layout指定／source factory |')){
  $line.Replace('static inline_styles出典と最終画像parityは継続する。','静的style出典は専用行に集約し、最終画像parityを継続する。')
  '| RichTextの静的style出典／plan公開 | **当該ownerを実装・検証・公開済み** | Source '+$source.commit+'。lexical scopeに型付きstyle・元product source revision／byte range・入れ子bodyを保持し、Content展開、Native／decoded AWBC、公開frame JSON保存復元でも保持する。planは同じcanonical records／templatesを借用して公開し、空の旧inline_styles／contribution modelと全受け渡しを削除した。最終入力13／13 PASS（CLI4、Compiler1、formatted6、codec2）、Source4114／case／実行ファイルdrift0。30逆依存とSema照合は下表で継続し、既受入のfactory・単位を未完了へ戻さない。[現行契約](../04-tooling/cli.md)、[全実測・旧probe・訂正理由・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| Callableの戻り値合流診断／元Source |')){
  $line.Replace('全22 consumerは下表で継続し、','全22 consumerの終端は履歴に保持し、')
 }elseif($line.StartsWith('| CLI全target照合 |')){
 '| CLI全target照合 | **planの出典ownerを修復済み。旧全700実測689 PASS／11 FAILは履歴に保持** | Source '+$source.commit+'の対象CLI plan4件はPASS。現在の全CLI終端はまだ主張しない。残る10 IDはfull-grammar現在line選択3件、Scroll解決1件、unsafe fixture1件、run-edge1件、負例診断1件、verifier fixture3件。Source f2d9dc791bb0f7ecfc13b47792511086a5c31878の全CLI700実行689 PASS／11 FAILは実測として保持し、700／10 FAILへ再計算しない。戻り値診断・RAG・z-index・Generic Matchと他の既受入を未完了へ戻さない。[各入力・全ID・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
 '| 共有契約／推移的逆依存matrix | **静的style出典の全30 package＋Generic Match照合用Semaを検証中** | Source '+$source.commit+'。元の実Cargo metadataとTextModel invert treeが30 packageで一致し、101 Cargo／toolchain入力hashが不変なためgraphを再利用、drift0。追加Semaを含む31選択の終端はまだ主張しない。以前の戻り値診断全22は4130実行4119 PASS／11 FAIL／24 skipped、CLI以外3430件は全PASS、Generic Match151／151 PASSの実測として保持する。[実graph・各終端・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 '| workspace check／Clippy・fmt・構造gate | **静的style出典Sourceの全98 check／Clippy・構造gateは終了0。警告は残る** | Source '+$source.commit+'、4114入力。最終入力の全98 all-target／all-feature／locked check・Clippy・構造gateと変更Rustのformat checkは終了0。以前のSourceの成功を付け替えず各epochを保持する。既存12 tracked／6 untrackedを保持。専用doctest／wasm・Tier2・最終Native-Web parityは別境界。[所有測定・各入力・全実測](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Canonical style-scope origins and plan catalog

- Source $($source.commit) publishes40paths. Canonical style scopes retain typed style, nested body and required Authored(bounded product-source revision/range) or Generated origin. Project original accepted HIR anchors once; preserve them through Content expansion/rebasing, resolved frames and saved snapshots. Existing version1 digests bind the origin. Plan borrows the existing canonical catalog records/templates serializer. Delete the empty flat contribution model and all Frame/Stage/Context copies; no second resolver, source reconstruction, legacy reader, version bump or new I/O.
- Final owner2:$($owner.summary),4114Source/case/executable drift0. Four CLI plan cases, one Compiler integration exercising Native/decoded AWBC and both public frame snapshot round trips, six existing formatting cases and two strict source/digest cases. Render-text is built but has no matching runtime test in this focused input. Earlier owner1 also13PASS on a different representation; retain its patch/pins separately. x86_64 MSVC size_of measured112to80 authored-node,112to48 resolved-node and80to8 origin bytes after boxing only the authored payload; these are layout observations, not speed benchmarks.
- The valid current-grammar plan probe exposed0inline styles for real color/layout scopes. The earlier denied probe's phantom null counts are corrected with their original error retained; it does not establish a catalog count. Migrate the retired Character.dialogue_style/preset/line_options fixture to four lexical scopes retaining all three exact colors,14px Ruby, source coordinates and the same2 child tasks. Remove the artificial EngineDefaults protocol record with the obsolete type. Static provenance is no longer pending at the owner boundary. Final workspace98 all-target/all-feature/locked check/Clippy/structure exit0, warnings remain; whole30reverse plusSema remains in progress. Keep prior full700/689PASS11FAIL as history; ten other CLI owner conditions remain, without inventing new totals. Generic Match remains accepted/public.
- [Source/patch identities, exact tests, graph, measurements, original probes and verified raw](acceptance-evidence/task-rich-text-property-identity.json); [only current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Prior evidence changed: '+$key)}}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{version=1;source=$source.commit;rawPath=$rawPath;rawBytes=$raw.bytes;rawSha256=$raw.sha256;rawEntries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0;qualityTerminalClaim=$true;reverseTerminalClaim=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'content-style-origin-owner-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'content-style-origin-owner-documentation-audit.json')
