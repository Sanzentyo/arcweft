$ErrorActionPreference='Stop'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$owner='bench-headless-owner2-20261103'
$receipt=Get-Content -LiteralPath "$taskEvidence/$owner.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if(-not $receipt.isPassingRun -or $receipt.executed -ne 2){throw 'Repair must pass before complementary runtime'}
$command=(Get-Content -LiteralPath "$taskEvidence/$owner.catalog.json" -Raw|ConvertFrom-Json).command
$selection=@($command[2..($command.Count-3)]);$selection[$selection.Count-1]='not ('+$selection[$selection.Count-1]+')'
$inventory=Get-Content -LiteralPath "$taskEvidence/$owner.catalog.inventory.json" -Raw|ConvertFrom-Json
$expected=@($inventory.rows|Where-Object {-not $_.ignored -and $_.status -ne 'matches'}).Count
$paths=(Get-Content -LiteralPath "$taskEvidence/$owner.source-freeze.json" -Raw|ConvertFrom-Json).paths.path
& "$taskEvidence/run-presentation-projection-owner.ps1" -Stem 'bench-headless-reverse1-20261103' -Selection $selection -ExpectedMatches $expected -AdditionalPaths $paths
if($LASTEXITCODE -notin @(0,100)){throw 'No valid complementary terminal result'}
& "$taskEvidence/run-action-payload-quality.ps1" -Epoch 'bench-headless-reverse1-20261103' -Stem 'bench-headless-quality1-20261103' -Packages @('arcweft-cli')
