$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Receipt([string]$name){Get-Content -LiteralPath "$taskEvidence/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$out="$taskEvidence/bench-headless.combined.json";if(Test-Path -LiteralPath $out){throw 'Preserve existing evidence'}
$owner='bench-headless-owner2-20261103';$rest='bench-headless-reverse1-20261103';$a=Receipt "$owner.source-freeze";$b=Receipt "$rest.source-freeze"
$map=@{};foreach($row in $a.paths){$map[$row.path]=$row.sha256};if($a.paths.Count -ne $b.paths.Count){throw 'Input set changed'}
foreach($row in $b.paths){if($map[$row.path] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$first=Receipt "$owner.binaries-before";$pins=Receipt "$rest.binaries-before";$map=@{};foreach($row in $first){$map[$row.binary]=$row.sha256};if($first.Count -ne $pins.Count){throw 'Executable set changed'}
foreach($row in $pins){if($map[$row.binary] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Executable drift'}}
$all=@{};$coverage=@{};$ignored=@{}
foreach($stem in @($owner,$rest)){
 $inventory=Receipt "$stem.catalog.inventory";$selected=@{}
 foreach($row in $inventory.rows){$key=$row.binary+"`t"+$row.test;if($row.ignored){$ignored[$key]=$row}else{$all[$key]=$row};if($row.status -eq 'matches'){$selected[$key]=$row}}
 $terminal=Receipt "$stem.runtime.terminal-audit";$seen=0;$after=$false
 foreach($line in [IO.File]::ReadLines("$taskEvidence/$stem.runtime.log")){
  if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
  if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
   $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test
   if(-not $selected.ContainsKey($key) -or $coverage.ContainsKey($key)){throw 'Unexpected/duplicate case'}
   $coverage[$key]=[ordered]@{package=$selected[$key].package;binary=$binary;test=$test;status=$status;run=$stem;kind='fresh-disjoint-selection'};$seen++
  }
 }
 if($seen -ne $selected.Count -or $seen -ne $terminal.executed){throw 'Missing terminal cases'}
}
if($coverage.Count -ne $all.Count -or @(Compare-Object @($coverage.Keys) @($all.Keys)).Count){throw 'Incomplete CLI closure'}
$cases=@($coverage.Values|Sort-Object binary,test);$fail=@($cases|Where-Object status -notin @('PASS','SLOW'))
$prior=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-bench-execution-target.json -Raw|ConvertFrom-Json -Depth 100
$oldKeys=@($prior.combined.cases|Where-Object package -eq 'arcweft-cli'|ForEach-Object {$_.binary+"`t"+$_.test})
$oldFails=@($prior.combined.cli.failureSet|ForEach-Object {$_.binary+"`t"+$_.test});$newFails=@($fail|ForEach-Object {$_.binary+"`t"+$_.test})
$removed=@($oldKeys|Where-Object {-not $coverage.ContainsKey($_)});if($removed.Count){throw 'Existing CLI case removed'}
$value=[ordered]@{version=1;base=$b.base;graph=(Receipt 'bench-headless.graph');sourceInputs=$b.paths.Count;sourceDrift=0;caseDrift=0;executableDrift=0;executables=$pins;focused=(Receipt "$owner.runtime.terminal-audit");complement=(Receipt "$rest.runtime.terminal-audit");distinctCases=$cases.Count;freshCases=$cases.Count;duplicateExecutions=0;passed=$cases.Count-$fail.Count;failed=$fail.Count;ignored=$ignored.Count;failureSet=$fail;cases=$cases;comparison=[ordered]@{baselineSource=$prior.source;retained=@($newFails|Where-Object {$_ -in $oldFails});added=@($newFails|Where-Object {$_ -notin $oldFails});resolved=@($oldFails|Where-Object {$_ -notin $newFails});addedCases=@($cases|Where-Object {($_.binary+"`t"+$_.test) -notin $oldKeys});removedCases=$removed};scope='Private CLI fixture migration; complete CLI reverse closure1 freshly covered by2 disjoint selections. No production change. This new run does not rerun normal Syntax25 or accepted Generic151; retain their exact earlier source/executable proof and original acceptance separately.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{executed=$cases.Count;passed=$value.passed;failed=$value.failed;ignored=$value.ignored;retained=$value.comparison.retained.Count;added=$value.comparison.added.Count;resolved=$value.comparison.resolved.Count;newCases=$value.comparison.addedCases.Count}|ConvertTo-Json -Compress
