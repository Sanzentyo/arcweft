$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/retained-normalization.final-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/retained-normalization.final-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/retained-normalization.final-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1635 tests run: 1629 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1635\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/retained-normalization.final-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1635 -or $terminal.Count -ne 1635 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$previous=Get-Content -Raw "$root/scoped-binding-terms.final2-terminal.json" | ConvertFrom-Json
$difference=@(Compare-Object -CaseSensitive @($previous.Id|Sort-Object) @($selected|Sort-Object))
if($difference.Count -ne 4 -or @($difference|Where-Object SideIndicator -NE '=>').Count){throw 'Previous test IDs changed'}
$newIds=@($difference.InputObject)
$new=@($terminal|Where-Object {$newIds -ccontains $_.Id})
if($new.Count -ne 4 -or @($new|Where-Object Result -ne 'PASS').Count){throw 'New regression missing'}
$failed=@($terminal|Where-Object Result -eq 'FAIL'|ForEach-Object Name|Sort-Object)
$baseline=Get-Content -Raw "$root/scoped-binding-terms.summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$metrics=Import-Csv "$root/retained-normalization.structure/file_metrics.csv"
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($pin.Base):$($p.Path)") -ne $p.Blob){throw 'Source changed'}
    $row=@($metrics|Where-Object path -CEQ $p.Path)
    if($row.Count -ne 1){throw 'Missing canonical metric'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    if([int]$row[0].physical_lines -ne $lines -or [long]$row[0].bytes -ne (Get-Item -LiteralPath $p.Path).Length){throw 'Canonical measurement mismatch'}
    $baseText=@(git show "$($pin.ChangeBase):$($p.Path)" 2>$null); $baseLines=if($LASTEXITCODE -eq 0){$baseText.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=[long]$row[0].bytes;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '(^|/)tests(/|\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=[int]$row[0].embedded_test_lines;SHA256=$p.SHA256;Blob=$p.Blob}
})
$structure=Get-Content -Raw "$root/retained-normalization.structure.json" | ConvertFrom-Json
if($structure.ExitCode -ne 0 -or (Get-Content -Raw "$root/retained-normalization.structure.stdout") -notmatch '(?m)^blocking violations: 0\r?$'){throw 'Structural gate not verified'}
$reverse=Get-Content -Raw "$root/retained-normalization.reverse.json" | ConvertFrom-Json
if($reverse.Count -ne 3 -or @($reverse|Where-Object ExitCode -ne 0).Count){throw 'Reverse graph failed'}
$packages=@(Get-Content "$root/retained-normalization.reverse-normal-dev-build.txt" | ForEach-Object { if($_ -match '^(arcweft-\S+) v'){$Matches[1]} } | Sort-Object -Unique)
if($packages.Count -ne 22){throw 'Unexpected reverse closure'}
if((git rev-parse HEAD) -ne $pin.Base -or @(git diff --name-only HEAD).Count){throw 'Published source/base mismatch'}
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/retained-normalization.final-terminal.json"
[ordered]@{Version=1;Source=$pin.Base;Tree=(git rev-parse 'HEAD^{tree}');Parent=$pin.ChangeBase;Selected=1635;Passed=1629;Failed=6;Skipped=0;SlowTests=if($summary.Groups['slow'].Success){[int]$summary.Groups['slow'].Value}else{0};IdsEqual=$true;PreviousIdsRetainedWithFourAdditions=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;SourcePinsVerified=$true;SourcePublishedBeforeFinalValidation=$true;StructureExit=0;BlockingViolations=0;ClippyExit=0;FmtExit=0;Measurements=$measurements;DependencyMetrics=(Import-Csv "$root/retained-normalization.structure/package_metrics.csv"|Where-Object package -CEQ 'arcweft-lang-sema');ReversePackages=$packages;ConsumersNotRerun=$true;LastBroadSource='8b5e375a9c7b3096fe5ed2f65df556a463741a8d';Ownership='One existing iterative projection fold retains admission, error order, binder entry, alias guards and scope transport. InspectValues produces raw inspection results; RetainOrigins produces move-only values and corresponding derivations. Structural rebuild moves child values into their parent and preserves distinct child and length proofs, exact source header and actual contents frame. Alias edges remain flat until the next shape/root, retaining actual occurrences and looked-up bindings. Terminal derivations no longer duplicate reconstructed subtrees. Root binding scope is authenticated before adoption. New private mode/fragment owners hold no separate traversal, capture table or Free union. No Cargo/public/wire/unsafe/I/O/version/budget changes. Transaction remains source/closure coordination; origin owns scoped value derivation. New tests observe ownership, source positions, alias/length correspondence, genuine local frame identity and exact 10001-node admission/drop. Broader projected/Derived consumers, certified effect substitution, capture seal, Free authorization and frontend recursive body inference remain unfinished.';Development='Initial library check passed, followed by two development nextest lists. Four regressions and the source/header assertions were finalized before the published checkpoint. The final script separately pins all 11 paths before/after every step. No changed-source development run is presented as final evidence. Warnings remain. Consumers are not rerun for this private provenance-retention migration; owner/frontend/API compile and full Sema behavior are covered. Previous 21-package results remain pinned to their original source and are not a combined current total.'}|ConvertTo-Json -Depth 9|Set-Content -Encoding utf8 "$root/retained-normalization.summary.json"
Get-Content "$root/retained-normalization.summary.json" -TotalCount 20
