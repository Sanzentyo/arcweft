$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-specified-values-20261108.source-checkpoint.verified.json'
if((git rev-parse HEAD).Trim() -ne $pub.commit){throw 'Checkpoint Source changed'}
$archive='docs/implementation/acceptance-evidence/task-style-specified-type-checkpoint.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(Get-ChildItem -LiteralPath $r -File -Filter 'style-specified-values-20261108*'|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')})+@((Get-Item "$r/run-style-quality-20261108.ps1"),(Get-Item $PSCommandPath))
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$entry=[ordered]@{
    version=1;date='2026-11-08';publication=$pub;status='Intermediate specified-type foundation only. Complete Style Source token/value/factory publication and consumer acceptance remain open.'
    model='CompileTimeStyleType projects ViewStyleValueKind and the typed construction operands without copying the final native value algebra. Native Color/Length declarations now retain ViewSpecifiedValue, with exact semantic type/value-kind validation and one Compiler publication path. Ordinary registered runtime quantities retain their separate type/unit. Runtime ownership and Compiler type projection reject specified Style values. Old fake Named(Color) and the separate Style Length scalar reader are removed.'
    semantic='Canonical semantic tag 104 and exact value/operand kind are retained; type comparison, mismatch, constraint shape, substitution, openness and nominal/generic visits use the same typed leaf. Review caught reserved Traversal tag 103 before execution and assigned 104. Arcweft-owned contract markers remain 1.'
    developmentChecks=@((Read-Record 'style-specified-values-20261108.dev-check-r1.json'),(Read-Record 'style-specified-values-20261108.dev-check-r2.json'))
    developmentCorrections='First check exposes 10 missing exhaustive Sema consumers; second exposes the missing Compiler runtime-projection rejection. Both failures remain raw history, not passes.'
    firstOwner=(Read-Record 'style-specified-values-20261108.owner-r1.runtime.terminal-audit.json');correctedOwner=(Read-Record 'style-specified-values-20261108.owner-r2.runtime.terminal-audit.json')
    testCorrection='Initial 99-case run: 98 pass/1 fail. The negative Action test selected handlers.first_mut(), assuming hash-sorted global order selected the authored handler. It now follows the original view.Main instruction span and BindHandler program identity, asserts one original handler and still forges/rejects the same payload type. No production Action admission was relaxed. Style Length facts now use the specified type/value while retaining exact negative/fractional values, unit/type/overflow rejection and ordinary numeric-root checks. One test was renamed to reflect its specified-value result.'
    quality=@(foreach($name in @('check','clippy','structure','fmt')){Read-Record "style-specified-values-20261108.quality.$name.receipt.json"})
    graph=(Read-Record 'style-specified-values-20261108.graph.json');consumerClosure='Cargo metadata gives 22 transitive reverse-dependency packages for Sema, including Compiler. The complete closure has not been rerun for this intermediate checkpoint.'
    pending='Remove the compiler nonempty-token refusal only with final checked token publication. Finish annotation ownership/type resolution, all static values/factories, token dependency/type/cycle handling, source maps, complete consumers and actual Native/Web samples. Existing accepted Generic Match, String, retained input, Action and other bounded cuts remain accepted.'
    archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();containsExecutables=$false;containsGeneratedBundles=$false}
}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'specifiedStyleTypeCheckpoint'){throw 'Checkpoint exists'}
$wrapper=[ordered]@{specifiedStyleTypeCheckpoint=$entry}|ConvertTo-Json -Depth 100
$inner=$wrapper.Substring($wrapper.IndexOf('{')+1).TrimEnd();$inner=$inner.Substring(0,$inner.LastIndexOf('}')).TrimEnd()
$new=$base.TrimEnd();$new=$new.Substring(0,$new.LastIndexOf('}')).TrimEnd()+','+"`n"+$inner+"`n}`n"
$after=$new|ConvertFrom-Json -Depth 100 -DateKind String
foreach($p in $prior.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($p.Name)|ConvertTo-Json -Depth 100 -Compress)){throw 'Historical record drift'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$new,[Text.UTF8Encoding]::new($false))
$current='D:/git/arcweft/docs/implementation/current-status.md'
$lines=@([IO.File]::ReadAllLines($current))
for($i=0;$i -lt $lines.Count;$i++){
    if($lines[$i].StartsWith('確認日 ')){$lines[$i]='確認日 2026-11-08、観察Source `'+$pub.commit+'`。項目ごとの受入・公開Sourceと検証範囲を下表で独立して追跡する。Style指定値型の基盤を中間公開し、Color／LengthのSource投影を統一した。Style tokenと全sample受入は継続中。tracked実装WIPは0、4 actual untrackedのローカルcacheは保持している。'}
    if($lines[$i].StartsWith('| View の保持 String 入力／公開target・IME hint・placeholder |')){$lines[$i]=$lines[$i].Replace('NativeはFontFamilyList型・Style tokenが未達。','NativeのFontFamilyList型・Style tokenは未達。Style指定値の型基盤はSource `'+$pub.commit+'` でColor／Lengthの投影を統一した中間公開で、token／全値familyのSource接続と22逆依存の全件確認を継続する。')}
    if($lines[$i].StartsWith('| 共有契約／推移的逆依存matrix |')){$lines[$i]=$lines[$i].Replace('最終2 run／2 feature pointを集計。','このSourceの最終2 run／2 feature pointを集計。後続Style型checkpointはowner／gateだけの確認で、この全件PASSを転用しない。')}
    if($lines[$i].StartsWith('| workspace check／Clippy・fmt・構造gate |')){$lines[$i]='| workspace check／Clippy・fmt・構造gate | **Style指定値型checkpointの全workspace gateは終了0** | Source `'+$pub.commit+'` の全98 package・全target・全feature・locked check／Clippy、canonical構造gate、変更20 Rust pathのfmtが終了0、3904入力drift0（警告あり）。ViewSpecifiedValueを保持する型付き境界へColor／Lengthを揃え、runtime持込みを拒否し、旧Named(Color)とStyle Length別readerを削除した。初回owner 98 PASS／1 FAILと修正後5 PASSを保持。全22逆依存、Style token／全値factory SourceとNative／Web表示の受入は別の継続条件。Stringの既受入は維持する。[gate・失敗・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
}
[IO.File]::WriteAllText($current,($lines -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
$history=@'

## 2026-11-08 — Style指定値の型とColor／Length投影checkpoint

Source `{{SOURCE}}` はStyle指定値と構築operandを、通常のruntime scalarとは別のsemantic型で保持する。値は既存ViewSpecifiedValueが所有し、Core runtime型／snapshotへの流入を拒否する。Colorの仮Named型とCompilerのStyle Length別readerを削除した。canonical identityは既存Traversalの103を維持し、新しい型に104を割当てる。型比較・診断・constraint・generic／nominal／substitutionの全leaf消費側を移行した。

初期checkはSemaのexhaustive分岐10箇所、次のcheckはCompiler runtime投影1箇所の不足で失敗した。修復後は全98 workspaceのlocked／全target／全feature check・Clippy、構造gate、変更20 Rust pathのfmtが終了0、3904入力drift0。初回owner99件は98 PASS／1 FAILで、Action負例のhandlers先頭仮定が不正な対象を選んだ。元view.Mainの命令が束縛したhandler IDを辿る形へ直し、同じpayload型改変拒否を維持した。Style Lengthの精度・符号・不正単位／型／overflow拒否と普通の数値rootを残し、新しい指定値factへ移した。修正後の5件は全PASSで、全22逆依存の再確認はまだ行っていない。

これは型基盤の中間公開で、Style token／FontFamilyListや残る値・factoryのSource接続、compiler token guardの除去、sample全体とNative／Web表示の受入は継続する。先行String全件runを新しいStyle Sourceの全件PASSへ読み替えず、Generic Match・保持入力・Action等の既受入も戻さない。既存141 recordの値を全件照合して保持した。

原本 `{{ARCHIVE}}` は{{ENTRIES}} entry／{{BYTES}} bytes、SHA256 `{{SHA}}`。実行ファイルと生成AWFBは含まない。詳細はregistryの `specifiedStyleTypeCheckpoint`。
'@
foreach($key in @('SOURCE','ARCHIVE','ENTRIES','BYTES','SHA')){$value=switch($key){SOURCE{$pub.commit};ARCHIVE{$entry.archive.path};ENTRIES{$entry.archive.entries};BYTES{$entry.archive.bytes};SHA{$entry.archive.sha256}};$history=$history.Replace(('{{'+$key+'}}'),[string]$value)}
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+"`n"+$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$entry.archive}|ConvertTo-Json -Depth 8|Set-Content "$r/style-specified-values-20261108.checkpoint-record.json" -Encoding utf8
Get-Content "$r/style-specified-values-20261108.checkpoint-record.json" -Raw
