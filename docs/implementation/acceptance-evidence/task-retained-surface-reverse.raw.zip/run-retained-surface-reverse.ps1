param([string]$ListAttempt='r1',[string]$RunAttempt='r1')
$ErrorActionPreference='Stop'
$e=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
$list='retained-surface-reverse-list-'+$ListAttempt
$prefix='retained-surface-reverse-run-'+$RunAttempt
$log=Join-Path $e ($prefix+'.log')
if(Test-Path -LiteralPath $log){throw 'Run log already exists'}
$spec=Get-Content -Raw -LiteralPath (Join-Path $e ($list+'.inputs.json')) | ConvertFrom-Json
function Assert-Frozen {
    if ((git rev-parse HEAD).Trim() -ne $spec.source -or (git rev-parse 'HEAD^{tree}').Trim() -ne $spec.tree -or @(git diff HEAD --name-only).Count) {throw 'Source/index drift'}
}
Assert-Frozen
$raw=[IO.File]::ReadLines((Join-Path $e ($list+'.log'))) | Where-Object {$_.StartsWith('{')} | Select-Object -Last 1
if(!$raw){throw 'No successful enumeration'}
$catalogPath=Join-Path $e ($prefix+'.catalog.json')
[IO.File]::WriteAllText($catalogPath,$raw,[Text.UTF8Encoding]::new($false))
$catalog=$raw | ConvertFrom-Json -AsHashtable
$selected=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$binaries=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$testPackages=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($suite in $catalog.'rust-suites'.Values){
    if($suite.'package-name' -notin $spec.packages){throw ('Unexpected package '+$suite.'package-name')}
    foreach($test in $suite.testcases.Keys){
        if($suite.testcases[$test].'filter-match'.status -ne 'matches'){continue}
        if(!$selected.Add($suite.'binary-id'+' '+$test)){throw ('Duplicate test '+$test)}
        [void]$binaries.Add($suite.'binary-path')
        [void]$testPackages.Add($suite.'package-name')
    }
}
foreach($owner in @('arcweft-view','arcweft-bundle','arcweft-runtime-driver','arcweft-compiler','arcweft-player-scene','arcweft-player-web','arcweft-player-native','arcweft-cli')){
    if(!$testPackages.Contains($owner)){throw "Missing owner $owner"}
}
$required=@(
    'arcweft-cli::check agent_observe_native::native_retained_panel_and_repeated_box_paint_their_clipped_style_boxes',
    'arcweft-cli::check agent_observe_native::keyed_scroll_descendants_keep_distinct_text_and_button_targets_in_native_observe',
    'arcweft-cli::check agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering',
    'arcweft-compiler::source_presentation_driver source_scroll_and_virtual_list_share_live_ownership_across_cold_restore',
    'arcweft-player-scene::dialogue_view standard_dialogue_view_preserves_vertical_ruby_and_final_panel_geometry',
    'arcweft-player-scene frame::view_geometry::tests::retained_surface_measures_its_children_in_the_same_box_as_paint',
    'arcweft-bundle::view_resource_codecs view_surface_budget_counts_painted_elements_and_decoder_rejects_the_removed_table',
    'arcweft-bundle::ime_player_rendered ime_generator_publishes_deterministic_controls_and_executable_callbacks'
)
foreach($test in $required){if(!$selected.Contains($test)){throw "Missing regression $test"}}
foreach($pkg in $catalog.'rust-build-meta'.'non-test-binaries'.Values){
    foreach($binary in $pkg){
        if($binary.kind -eq 'bin-exe'){[void]$binaries.Add((Join-Path $catalog.'rust-build-meta'.'target-directory' $binary.path))}
    }
}
if(!$binaries.Contains((Get-Item -LiteralPath 'target/debug/arcw.exe').FullName)){throw 'Missing arcw.exe'}
function Read-Pins {
    @(foreach($path in ($binaries | Sort-Object)){
        $file=Get-Item -LiteralPath $path
        [ordered]@{path=$path;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
    })
}
$arguments=@('nextest','run','--no-fail-fast','--no-tests','fail')+@($spec.arguments[2..($spec.arguments.Count-1)] | Where-Object {$_ -notin @('--message-format','json')})
[ordered]@{version=1;source=$spec.source;code=$spec.code;tree=$spec.tree;packages=$spec.packages;packageCount=$spec.packageCount;testsSelected=$selected.Count;testPackages=@($testPackages | Sort-Object);packagesWithNoSelectedTests=@($spec.packages | Where-Object {!$testPackages.Contains($_)});binaryCount=$binaries.Count;catalogSha256=(Get-FileHash -LiteralPath $catalogPath).Hash.ToLowerInvariant();arguments=$arguments} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.inputs.json')) -Encoding utf8
$before=Read-Pins
$before | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-before.json')) -Encoding utf8
Assert-Frozen
Write-Output ('Selected '+$selected.Count+' IDs in '+$testPackages.Count+' test packages with '+$binaries.Count+' original binaries.')
$watch=[Diagnostics.Stopwatch]::StartNew()
& cargo @arguments *> $log
$code=$LASTEXITCODE
$watch.Stop()
$after=Read-Pins
$after | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-after.json')) -Encoding utf8
$drift=@(for($i=0;$i -lt $before.Count;$i++){
    if($before[$i].path -ne $after[$i].path -or $before[$i].bytes -ne $after[$i].bytes -or $before[$i].sha256 -ne $after[$i].sha256){$before[$i].path}
})
Assert-Frozen
function Read-Statuses([string]$path) {
    $statuses=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
    foreach($line in [IO.File]::ReadLines($path)){
        if($line -match '^\s+(PASS|FAIL|SKIP|TIMEOUT|LEAK)\s+\[[^\]]+\]\s+\([^)]+\)\s+(\S+)\s+(.+?)\s*$'){
            $statuses[$Matches[2]+' '+$Matches[3]]=$Matches[1]
        }
    }
    return ,$statuses
}
$current=Read-Statuses $log
$baseline=Read-Statuses (Join-Path $e 'retained-scroll-reverse-run-r1.log')
$delta=@(foreach($key in ($current.Keys | Sort-Object)){
    if($baseline.ContainsKey($key) -and $current[$key] -ne $baseline[$key]){
        [ordered]@{id=$key;baseline=$baseline[$key];current=$current[$key]}
    }
})
$result=[ordered]@{
    version=1;source=$spec.source;code=$spec.code;tree=$spec.tree;exitCode=$code;seconds=$watch.Elapsed.TotalSeconds;sourceDrift=0;binaryDrift=$drift
    summary=@([IO.File]::ReadLines($log)|Where-Object {$_ -match 'Summary \['})
    testStatuses=@($current.Values|Group-Object|Select-Object Name,Count)
    cliStatuses=@(@(foreach($key in $current.Keys){if($key.StartsWith('arcweft-cli::') -or $key.StartsWith('arcweft-cli ')){$current[$key]}}) | Group-Object | Select-Object Name,Count)
    required=@(foreach($key in $required){[ordered]@{id=$key;status=$current[$key]}})
    nonPassing=@($current.Keys|Where-Object {$current[$_] -ne 'PASS'}|Sort-Object)
    comparison=[ordered]@{
        baseline='751128cbe0ce4311bbe11fda887bf4ee5712bf50';commonIds=@($current.Keys|Where-Object {$baseline.ContainsKey($_)}).Count;changes=$delta
        onlyInCurrent=@($current.Keys|Where-Object {!$baseline.ContainsKey($_)}|Sort-Object)
        onlyInBaselineCount=@($baseline.Keys|Where-Object {!$current.ContainsKey($_)}).Count
    }
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.results.json')) -Encoding utf8
[ordered]@{exitCode=$code;seconds=$watch.Elapsed.TotalSeconds;binaryDrift=$drift.Count;summary=$result.summary;changes=$delta;regressions=$result.required} | ConvertTo-Json -Depth 6 -Compress
exit $code
