$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='scope-results-integrated-20261108'
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
$ledger=$before|ConvertFrom-Json -Depth 100
$record=$ledger.scopeResultsNonCliConsumers
$archive=Join-Path (Get-Location) ('docs/implementation/acceptance-evidence/'+$record.raw.path)
if((Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant() -ne $record.raw.sha256){throw 'Unpublished archive changed'}
$required=@("$stem.metadata.json","$stem.metadata.log","$stem.metadata.receipt.json","$stem.graph-review.json",'run-source-frozen-matrix-20261108.ps1','audit-nextest-final-result.ps1','record-scope-results-noncli-20261108.ps1','fix-scope-results-noncli-archive-intake-20261108.ps1')
$zip=[IO.Compression.ZipFile]::Open($archive,[IO.Compression.ZipArchiveMode]::Update)
try{foreach($name in $required){if($zip.GetEntry($name)){throw 'Correction was already applied'};[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $taskTemp $name),$name)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try{
 $entries=@(foreach($entry in ($zip.Entries|Sort-Object FullName)){
    $path=Join-Path $taskTemp $entry.FullName
    if(-not (Test-Path -LiteralPath $path) -or $entry.Length -ne (Get-Item -LiteralPath $path).Length){throw 'Archive entry differs'}
    $stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
    if($hash -ne (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()){throw 'Archive hash differs'}
    [ordered]@{entry=$entry.FullName;bytes=$entry.Length;sha256=$hash}
 })
}finally{$zip.Dispose()}
$oldArchiveHash=$record.raw.sha256
$record.raw.sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()
$record.raw.entries=$entries
$record|Add-Member -NotePropertyName archiveIntakeCorrection -NotePropertyValue 'Before publication, the initial archive included the original eight run files but omitted graph/helper files because of PowerShell array-expression grouping. Added and hash-verified the missing graph and executed helper files; the original eight entries and actual test results are unchanged.'
$fragment=([ordered]@{scopeResultsNonCliConsumers=$record}|ConvertTo-Json -Depth 99).Trim().Replace("`r`n","`n")
$start=$before.LastIndexOf('"scopeResultsNonCliConsumers":')
$last=$before.LastIndexOf('}')
if($start -lt 0 -or $last -le $start){throw 'New unpublished record boundary missing'}
$after=$before.Substring(0,$start)+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($prop in $ledger.PSObject.Properties|Where-Object Name -ne 'scopeResultsNonCliConsumers'){if(($prop.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($prop.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Earlier record changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$old="raw ZIPは8 entries、SHA-256 $oldArchiveHash。"
$new="raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。公開前のarchive intakeでgraph／helper原本の欠落を訂正し、元の8 run entryと検証結果は保持した。"
if(-not $history.Contains($old)){throw 'Unpublished history archive reference missing'}
[IO.File]::WriteAllText($historyPath,$history.Replace($old,$new),[Text.UTF8Encoding]::new($false))
[ordered]@{entries=$entries.Count;archiveSha256=$record.raw.sha256;originalRunEntriesPreserved=8;earlierRecordsPreserved=123}|ConvertTo-Json
