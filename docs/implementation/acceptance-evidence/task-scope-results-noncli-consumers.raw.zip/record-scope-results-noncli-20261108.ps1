$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='scope-results-integrated-20261108'
$base=(git rev-parse HEAD).Trim()
if($base -ne '316e420431d3941387b1f4e71e47159a5309f9f9'){throw 'Unexpected evidence base'}
$terminal=Get-Content "$taskTemp/$stem.noncli.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 30
if($terminal.executed -ne 7341 -or $terminal.passed -ne 7341 -or $terminal.failed -ne 0 -or $terminal.skipped -ne 18 -or $terminal.sourceDrift -ne 0 -or $terminal.catalogCaseDrift -ne 0){throw 'Non-CLI terminal differs'}
$epoch=(Get-Content "$taskTemp/$stem.noncli.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20).paths
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Rust/Cargo/config/toolchain input drift: $($row.path)"}}
$graph=Get-Content "$taskTemp/$stem.graph-review.json" -Raw|ConvertFrom-Json -Depth 30
$catalog=Get-Content "$taskTemp/$stem.noncli.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$cases=@($catalog.rows|Where-Object status -eq 'matches')
$packages=@($cases.package|Sort-Object -Unique)
$unexecuted=@($graph.reversePackages|Where-Object {$_ -notin $packages})
if($packages.Count -ne 49 -or @($packages|Where-Object {$_ -notin $graph.reversePackages}).Count -or @($cases|Group-Object { $_.binary+'|'+$_.test }|Where-Object Count -gt 1).Count){throw 'Non-CLI corpus mismatch'}
if(@(Compare-Object $unexecuted @('arcweft','arcweft-bundle-assets','arcweft-render-web','arcweft-cli')).Count){throw 'Unmatched consumer differs'}
$pins=@(Get-Content "$taskTemp/$stem.noncli.binaries-before.json" -Raw|ConvertFrom-Json)
$untracked=(Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json).files
foreach($row in $untracked){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked drift'}}
$archive='docs/implementation/acceptance-evidence/task-scope-results-noncli-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object { $_.Name.StartsWith($stem+'.noncli.') -or $_.Name -in @($stem+'.metadata.json',$stem+'.metadata.log',$stem+'.metadata.receipt.json',$stem+'.graph-review.json','run-source-frozen-matrix-20261108.ps1','audit-nextest-final-result.ps1','record-scope-results-noncli-20261108.ps1') }|Sort-Object Name)
$entries=@(foreach($file in $files){[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Archive shape drift'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive content drift'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$base;production='625deea6d6051469fc0c60a4e6808727fb42c21d';priorPrimaryMatrixSource='245fe74354733f1ee57a25ac43f60b2fbaca5947'
 scope='Fresh non-CLI workspace all-feature lib/tests over the complete resolved Core reverse closure. CLI runs separately with defaults and is not combined with this result until its own terminal is observed.'
 graph=$graph;validation=$terminal;matchedPackages=$packages;compileOnlyNonCli=@('arcweft','arcweft-bundle-assets','arcweft-render-web');separateCli='The default-feature CLI 711-case invocation is building/running independently; its current result is not yet accepted here.'
 corpus=[ordered]@{selected=$cases.Count;unique=$cases.Count;overlap=0;ignored=18;actualTestExecutables=$pins.Count;actualPins=$pins;sourceInputs=3417;sourceDrift=0}
 correction='The historical generic audit selectedPackages=0 field counts explicit -p arguments; this invocation uses --workspace and actually matches 49 packages in its catalog. The old held=14 wrapper label is also historical; independently protected WIP remains 12 tracked / 6 actual untracked. Neither label means zero tested packages or a changed WIP inventory.'
 acceptance='7341/7341 pass, 18 ignored/default exclusions retained. The changed AWBC receiver graph, Native pending scope cell, original root defer and initial-input regressions are exercised by the full consumer selection. Earlier focused 2330/166 runs are retained separately and not added to this primary corpus.'
 remaining='The current CLI terminal, Native public Save, platform/Tier2 and final Native-Web parity are independent conditions. Generic Match and all earlier accepted feature boundaries remain accepted.'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath));$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'scopeResultsNonCliConsumers'){throw 'Record exists'}
$fragment=([ordered]@{scopeResultsNonCliConsumers=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}');$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($prop in $old.PSObject.Properties){if(($prop.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($prop.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Old record changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md';$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {if($_.StartsWith('| 共有契約／推移的逆依存matrix |')){
"| 共有契約／推移的逆依存matrix | **追加init／scoped修復後の非CLI：7341／7341 PASS、18 SKIP。CLIを別構成で照合中** | 検証Source $base、production 625deea6d6051469fc0c60a4e6808727fb42c21d。新しい解決済みCargo graphはworkspace 98／resolved 846／Core逆依存53で前回との差分0。非CLIのworkspace全feature lib／testsを1 runで49 package・7341件すべてPASS、既定除外18を維持。compile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-webの3。実test binary path／SHA256を前後照合し、3417 Rust／Cargo／config／toolchain入力drift0。先行owner runを総数へ加えず、CLI既定711件の現在の実行結果は終端確認後に別途反映する。旧8035件・5分割／2 feature pointの全結果と全SHAは履歴へ保持。[全選択・実binary・監査label訂正・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
}else{$_}})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md';$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — 追加init／scoped修復後の非CLI逆依存

検証Source **$base**、production **625deea6d6051469fc0c60a4e6808727fb42c21d** で、非CLI workspace全featureのlib／testsを1回実行し、**49 package・7341／7341 PASS・18 SKIP**、新規失敗0。Cargo metadataのworkspace98／resolved846／Core逆依存53は前回と同じで、非CLIのcompile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-web。実test executable $($pins.Count)本をそのpathで前後hash照合し、ビルド生成物を移動・コピー・退避していない。3417 Rust／Cargo／config／toolchain入力drift0。並列数・profile・assertion・budget・既定除外は変更しない。

generic監査のselectedPackages=0は明示-p引数の件数で、--workspace選択の実49 packageはcatalogから照合した。古いheld=14 labelも実WIP数と区別し、元12 tracked／6 actual untrackedを独立して保持した。Source **245fe74354733f1ee57a25ac43f60b2fbaca5947** の8035件／5 run／2 feature point、先行ownerの2330／166件は履歴として保持し、新しい1 runへ合算しない。CLI既定711件は別途ビルド・実行しており、この非CLI記録に未観測の結果を加えない。Generic Match等の受入は維持する。[全選択・監査・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$base;preservedRecords=$old.PSObject.Properties.Name.Count;passed=$terminal.passed;matchedPackages=$packages.Count;actualTestExecutables=$pins.Count;archiveEntries=$entries.Count;archiveSha256=$record.raw.sha256}|ConvertTo-Json
