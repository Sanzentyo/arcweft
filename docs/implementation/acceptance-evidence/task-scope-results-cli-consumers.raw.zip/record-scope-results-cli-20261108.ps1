$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='scope-results-integrated-20261108'
$base=(git rev-parse HEAD).Trim()
if($base -ne '09871682de53a76817911739a027d955bd147f31'){throw 'Unexpected evidence base'}
$audit=Get-Content "$taskTemp/$stem.combined-audit.json" -Raw|ConvertFrom-Json -Depth 100
if($audit.executed -ne 8052 -or $audit.newFailures.Count -or $audit.caseOverlap -ne 0){throw 'Unexpected primary corpus'}
$interrupted=Get-Content "$taskTemp/$stem.cli.interrupted.json" -Raw|ConvertFrom-Json
$archive='docs/implementation/acceptance-evidence/task-scope-results-cli-consumers.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
$helpers=@('run-source-frozen-cli-main-20261108.ps1','audit-nextest-final-result.ps1','audit-scope-results-integrated-r2-20261108.ps1','record-scope-results-cli-20261108.ps1','recover-scope-results-cli-pin-20261108.ps1')
$files=@(Get-ChildItem $taskTemp -File|Where-Object {$_.Name.StartsWith("$stem.cli.") -or $_.Name.StartsWith("$stem.cli-r2.") -or $_.Name -eq "$stem.combined-audit.json" -or $_.Name -in $helpers}|Sort-Object Name)
$entries=@(foreach($file in $files){[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash $file.FullName).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256 -or $entry.Length -ne $row.bytes){throw 'Archive drift'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$base;production='625deea6d6051469fc0c60a4e6808727fb42c21d';validation=$audit;interruptedAttempt=$interrupted
 sourceIdentity='Non-CLI frozen source 316e420431d3941387b1f4e71e47159a5309f9f9 and CLI retry frozen source 09871682de53a76817911739a027d955bd147f31 differ only in evidence documentation. All recorded Rust/Cargo/config/toolchain hashes agree with current files. CLI additionally freezes 200 fixture/sample inputs. CLI actual main executable is pinned before and after runtime at its real path.'
 correction='The first CLI attempt has 362 partial runtime statuses, no terminal summary/receipt, and no surviving process; the reason is unobserved. It is retained as interrupted and excluded from primary totals. The retry uses the unchanged corpus/defaults in a new epoch and never overwrites the interrupted logs. Earlier selectedPackages=0/held=14 wrapper labels retain the correction in scopeResultsNonCliConsumers.'
 acceptance='Primary corpus: two invocations / two feature points, 8052 distinct executed cases, no overlap. Focused owner runs are not added. Four observed CLI failures retain their original IDs and diagnostics; accepted Generic Match, Line/init, root defer, child Dialogue receivers and Native scope results remain accepted within their individual boundaries.'
 remaining='Scroll input construction, absent actual voice in fixture 011, and receiverless old promotion inputs account for the four existing CLI failures. Actual promotion implementation, Native public Save, other platforms/Tier2 and final Native-Web parity remain independently tracked.'
 nonCliRaw='task-scope-results-noncli-consumers.raw.zip'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledger='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledger));$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'scopeResultsIntegratedConsumers'){throw 'Record exists'}
$fragment=([ordered]@{scopeResultsIntegratedConsumers=$record}|ConvertTo-Json -Depth 100).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}');$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($p in $old.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($p.Name)|ConvertTo-Json -Depth 99 -Compress)){throw "Old record changed: $($p.Name)"}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledger),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| 共有契約／推移的逆依存matrix |')){
 "| 共有契約／推移的逆依存matrix | **追加init／scoped修復後：8052件中8048 PASS／4 FAIL／41 SKIP** | production 625deea6d6051469fc0c60a4e6808727fb42c21d。非CLI Source 316e420431d3941387b1f4e71e47159a5309f9f9 とCLI Source $base はRust入力が同一。Core逆依存53の非CLI全feature lib／testsは7341 PASS／18 SKIP、CLI既定lib／testsは707 PASS／4 FAIL／23 SKIP。2 run／2 feature point、8052件の重複0。実行50 package、compile-only3はarcweft／arcweft-bundle-assets／arcweft-render-web。3417 Rust／Cargo／config／toolchain入力とCLI追加200 fixture入力、実test executable・CLI本体を前後照合した。最初のCLI runは362件の途中で中断し、終端・原因は未観測のため合算しない。失敗4件は下のCLI行へ集約する。旧結果・full SHAは履歴へ保持。[全選択・中断原本・再実行・実binary](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| CLIの規定対象／全 check 照合 |')){
 "| CLIの規定対象／全 check 照合 | **追加修復後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | Source $base、production 625deea6d6051469fc0c60a4e6808727fb42c21d。新しい全lib／tests runの失敗4 IDは先行Sourceと一致し、新規失敗0。Scroll入力生成のshared callable意味解析、実音声なしの必須VoiceHandle、receiverなし旧promotion入力2件で拒否する。実CLI本体とtest binaryを元pathで前後hash照合し、3617入力drift0。最初の中断runを成功にせず、別epochの完了結果を掲載する。各機能の既受入は維持し、promotion本体は専用行で追跡する。[失敗ID・診断・中断と再実行原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$addition=@"

## 2026-11-08 — scope結果修復後の全Core逆依存・CLI終端

production **625deea6d6051469fc0c60a4e6808727fb42c21d** の入力で、非CLI Source **316e420431d3941387b1f4e71e47159a5309f9f9** とCLI Source **$base** のRust bytesを照合し、**8052件中8048 PASS／4 FAIL／41 SKIP**。非CLI7341 PASS／18 SKIP、CLI711件中707 PASS／4 FAIL／23 SKIP、2 run／2 feature point・重複0。Core逆依存53中50 packageを実行し3 packageはcompile-only。先行focused2330／166件を重ねない。既定jobs／profile／assertion／budget／除外を変更せず、生成物の移動・コピー・退避もない。

CLI初回は362件のpartial status後、実process・terminal summary・receiptがないことを確認した。中断理由は未観測で、完了扱いや件数合算をしない。ソース・binaryのhashを再照合し、同じ711件を新epochで再実行した。全3617入力と実CLI本体・test executableの前後drift0。以前の原本は上書きしていない。再実行後の補助scriptはJSONのUTC時刻をDateTimeへ自動変換後に再Parseした比較で誤って拒否したため、原時刻をDateKind String／DateTimeOffsetで比較し直してpinの先行と実hash不変を確認した。これは検証本体の失敗や再実行ではない。最終4失敗はScroll入力生成、実音声なしの必須VoiceHandle、旧receiverless promotion入力2件の同じIDで、新規失敗0。Generic Matchなど既受入cutは維持する。[各終端・実選択・中断原本・full SHA](acceptance-evidence/task-flow-registry-execution.json)。raw ZIP $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::AppendAllText($historyPath,"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{base=$base;preservedRecords=$old.PSObject.Properties.Name.Count;executed=$audit.executed;passed=$audit.passed;failed=$audit.failed;entries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json

