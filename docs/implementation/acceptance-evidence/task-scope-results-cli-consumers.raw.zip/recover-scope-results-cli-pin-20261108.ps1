$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='scope-results-integrated-20261108.cli-r2'
$pin=Get-Content "$taskTemp/$stem.main-before.json" -Raw|ConvertFrom-Json -DateKind String
$runtime=Get-Content "$taskTemp/$stem.runtime.json" -Raw|ConvertFrom-Json -DateKind String
$after=(Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant()
if($pin.sha256 -ne $after -or [DateTimeOffset]::Parse($pin.finishedAt) -ge [DateTimeOffset]::Parse($runtime.startedAt)){throw 'Actual main executable pin failure'}
$pins=Get-Content "$taskTemp/$stem.binaries-before.json" -Raw|ConvertFrom-Json
if(@($pins|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Test executable drift'}
[ordered]@{version=1;path=$pin.path;sha256=$pin.sha256;runtimeStartedAt=$runtime.startedAt;runtimeFinishedAt=$runtime.finishedAt;beforeRuntime=$true;binaryDrift=0;testExecutableDrift=0;correction='The original post-runtime helper failed its DateTime comparison because ConvertFrom-Json materialized the UTC string as a DateTime, then Parse converted its culture-formatted value without timezone. Re-reading the preserved raw timestamps with DateKind String and DateTimeOffset proves the pin completed before runtime; actual hashes are unchanged. No test is rerun and no original receipt is overwritten.';recordedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$taskTemp/$stem.main-audit.json"
& "$taskTemp/audit-nextest-final-result.ps1" -Run "$stem.runtime" -Catalog "$stem.catalog" -Freeze $stem
& "$taskTemp/audit-scope-results-integrated-r2-20261108.ps1"
