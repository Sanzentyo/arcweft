$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='scope-results-integrated-20261108'
if(Test-Path "$taskTemp/$stem.combined-audit.json"){throw 'Combined audit already exists'}
$graph=Get-Content "$taskTemp/$stem.graph-review.json" -Raw|ConvertFrom-Json -Depth 30
$all=@();$ignored=@();$runs=@();$pins=@()
foreach($part in @('noncli','cli')){
 $prefix="$taskTemp/$stem.$part"
 if($part -eq 'cli'){$prefix="$taskTemp/$stem.cli-r2"}
 $terminal=Get-Content "$prefix.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 30
 if($terminal.catalogCaseDrift -ne 0 -or $terminal.sourceDrift -ne 0){throw 'Source/catalog drift'}
 $freeze=Get-Content "$prefix.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20
 foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Current input drift: $($row.path)"}}
 $catalog=Get-Content "$prefix.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
 $matched=@($catalog.rows|Where-Object status -eq 'matches')
 if($matched.Count -ne $terminal.executed){throw 'Selection/terminal count differs'}
 foreach($case in $matched){$all += [pscustomobject]@{slice=$part;package=$case.package;binary=$case.binary;test=$case.test;key=($case.binary+'|'+$case.test)}}
 foreach($case in @($catalog.rows|Where-Object ignored)){$ignored += [pscustomobject]@{slice=$part;binary=$case.binary;test=$case.test;key=($case.binary+'|'+$case.test)}}
 $runs += [pscustomobject]@{slice=$part;sourceInputs=$freeze.paths.Count;terminal=$terminal}
 $pins += @(Get-Content "$prefix.binaries-before.json" -Raw|ConvertFrom-Json)
}
if(@($all|Group-Object key|Where-Object Count -gt 1).Count -or @($ignored|Group-Object key|Where-Object Count -gt 1).Count){throw 'Primary case overlap'}
$packages=@($all.package|Sort-Object -Unique)
if(@($packages|Where-Object {$_ -notin $graph.reversePackages}).Count){throw 'Matched package outside Core closure'}
$compileOnly=@($graph.reversePackages|Where-Object {$_ -notin $packages})
if(@(Compare-Object $compileOnly @('arcweft','arcweft-bundle-assets','arcweft-render-web')).Count){throw 'Unexpected unexecuted Core consumer'}
$required=@(
 'native_initial_owned_line_init_defer_preserves_explicit_scope',
 'saved_awbc_initial_owned_line_init_defer_retains_its_packet_while_a_child_dialogue_waits',
 'saved_awbc_initial_line_init_defer_rejects_forged_child_dialogue_receivers',
 'native_init_scope_result_moves_only_after_suspended_cleanup',
 'saved_awbc_init_scope_result_moves_only_after_suspended_cleanup'
)
foreach($name in $required){if(@($all|Where-Object {$_.binary -eq 'arcweft-compiler::evaluated_effects' -and $_.test.EndsWith('::'+$name)}).Count -ne 1){throw "Required regression missing/duplicated: $name"}}
$baseline=@(
 'agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering',
 'spec_valid_run_edge_fixture_now_executes',
 'verify_json_records_required_solver_checks',
 'verify_json_reports_missing_promotion_proof'
)
$failures=@($runs.terminal.failureSet|ForEach-Object {$_})
$newFailures=@($failures|Where-Object {$_.binary -ne 'arcweft-cli::check' -or $_.test -notin $baseline})
$missingBaseline=@($baseline|Where-Object {$_ -notin $failures.test})
if($runs[0].terminal.executed -ne 7341 -or $runs[1].terminal.executed -ne 711){throw 'Primary corpus size changed'}
$main=Get-Content "$taskTemp/$stem.cli-r2.main-audit.json" -Raw|ConvertFrom-Json
if(-not $main.beforeRuntime -or $main.binaryDrift -ne 0){throw 'Main executable identity unavailable'}
$receipt=[ordered]@{
 version=1;source=(git rev-parse HEAD).Trim();production='625deea6d6051469fc0c60a4e6808727fb42c21d';graph=$graph
 runs=$runs;executed=[int](($runs.terminal.executed|Measure-Object -Sum).Sum);passed=[int](($runs.terminal.passed|Measure-Object -Sum).Sum);failed=[int](($runs.terminal.failed|Measure-Object -Sum).Sum);skipped=[int](($runs.terminal.skipped|Measure-Object -Sum).Sum)
 matchedPackages=$packages;compileOnlyPackages=$compileOnly;uniqueCases=$all.Count;caseOverlap=0;ignoredCases=$ignored;ignoredOverlap=0;requiredRegressions=$required
 failures=$failures;newFailures=$newFailures;baselineFailuresNotPresent=$missingBaseline;actualExecutablePins=$pins;cliMain=$main
 scope='Two invocations and two feature points: non-CLI workspace all-features, CLI defaults. All Cargo jobs remain default; no profile, assertion, budget, ignored or default-filter changes. Focused owner runs are not added to this primary corpus. Native public Save, other platforms/Tier2 and final Native-Web parity are separate.'
 recordedAt=[DateTime]::UtcNow.ToString('o')
}
$receipt|ConvertTo-Json -Depth 70|Set-Content "$taskTemp/$stem.combined-audit.json"
[ordered]@{source=$receipt.source;executed=$receipt.executed;passed=$receipt.passed;failed=$receipt.failed;skipped=$receipt.skipped;matchedPackages=$packages.Count;compileOnly=$compileOnly;uniqueCases=$all.Count;overlap=0;newFailures=$newFailures;missingBaseline=$missingBaseline}|ConvertTo-Json -Depth 12

