$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Receipt([string]$name) { Get-Content -LiteralPath "$taskTemp/$name" -Raw|ConvertFrom-Json -Depth 100 }
$quality=[IO.File]::ReadAllText("$taskTemp/presentation-argument-key-quality.active.txt")
$stem='presentation-argument-key-reverse-20261101'
$focus=Read-Receipt 'presentation-argument-key-focus3-20261101.runtime.terminal-audit.json'
$focusFreeze=Read-Receipt 'presentation-argument-key-focus3-20261101.source-freeze.json'
$matrix=Read-Receipt "$stem.matrix.json"
$graph=Read-Receipt "$stem.graph.json"
$freeze=Read-Receipt "$stem.source-freeze.json"
$generic=Read-Receipt "$stem.generic-coverage.json"
$cli=Read-Receipt 'presentation-argument-key-full-cli-20261101.matrix.json'
$comparison=Read-Receipt 'presentation-argument-key-full-cli-20261101.cli-comparison.json'
$allCli=Read-Receipt 'presentation-argument-key-full-cli-20261101.all-cli-scope.json'
$publication=Read-Receipt 'checkpoint-presentation-argument-key.verified.json'
$owner=Read-Receipt 'presentation-argument-key.owner-review.json'
if($matrix.status -ne 'terminal' -or $matrix.rows.Count -ne 3 -or $cli.status -ne 'terminal' -or $cli.rows.Count -ne 2){throw 'Runtime cohort is not closed'}
if($focus.passed -ne 55 -or $focus.failed -ne 0 -or $focus.sourceDrift -ne 0 -or $focus.catalogCaseDrift -ne 0){throw 'Focus differs'}
if($publication.commit -ne (git rev-parse HEAD).Trim() -or $publication.commit -ne $freeze.base){throw 'Published source differs'}
if(@(Compare-Object $focusFreeze.paths $freeze.paths -Property path,bytes,sha256).Count){throw 'Published inputs differ from passing focused inputs'}
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}
$gates=@(foreach($gate in @('workspace-check','clippy','structure','fmt')){
    $receipt=Read-Receipt "$quality.$gate.json"
    if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw ('Failed quality gate: '+$gate)}
    [ordered]@{gate=$gate;receipt=$receipt}
})
$terminals=@($matrix.rows|ForEach-Object {$_.terminal})
if(@($terminals|Where-Object {$null -eq $_ -or $_.sourceDrift -ne 0 -or $_.catalogCaseDrift -ne 0}).Count){throw 'Unaudited normal runtime'}
$archivePath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-presentation-argument-key-raw.zip'
$manifestPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-presentation-argument-key-validation.json'
if((Test-Path -LiteralPath $archivePath) -or (Test-Path -LiteralPath $manifestPath)){throw 'Immutable evidence already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    $_.Name -like 'presentation-argument-key*' -or $_.Name -like 'checkpoint-presentation-argument-key.*' -or $_.Name -like '*presentation-argument-key*.ps1'
})+@(Get-ChildItem -LiteralPath "$taskTemp/$quality.structure-report" -File)
$files=@($files|Sort-Object FullName -Unique)
$archive=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try {foreach($file in $files){$entry=$file.FullName.Substring($taskTemp.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)}}finally{$archive.Dispose()}
$verified=0
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    foreach($entry in $archive.Entries){
        $original=Join-Path $taskTemp $entry.FullName
        $stream=$entry.Open()
        try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -ne (Get-FileHash -LiteralPath $original).Hash.ToLowerInvariant()){throw ('Archive drift: '+$entry.FullName)}
        $verified++
    }
}finally{$archive.Dispose()}
if($verified -ne $files.Count){throw 'Archive inventory drift'}
$result=[ordered]@{
    version=1;date=[DateTime]::UtcNow.ToString('yyyy-MM-dd');source=$publication.commit
    workingTree='main; original 14 tracked and 6 actual untracked WIP preserved; source published with empty index and task specification held separately'
    change='The shared role inventory owns stable tags and source spellings. A sealed PresentationArgumentKey retains the metadata family and full validated path, or a fixed role without a metadata key. The semantic C-seal derives these destinations once per physical execution slot, preserves authored order and compact ABI positions, and binds the keys into its version-1 canonical digest. SlotRef lowering consumes that sealed slot authority instead of resolving parameter schemas again. The copied source-name switch readers are removed.'
    publication=$publication;focus=$focus
    focusInputBridge='The 55-case focus ran at the original 39b540872e4b08f85e525ae97638d3f01c2fec96 base with the exact dirty source later published as this seven-path commit. Every one of its frozen input hashes equals the published-source reverse cohort; the earlier base is retained in the raw receipt rather than relabeled.'
    previousAttempts=@(
        (Read-Receipt 'presentation-argument-key-focus-20261101.runtime.terminal-audit.json'),
        (Read-Receipt 'presentation-argument-key-focus2-20261101.runtime.terminal-audit.json')
    )
    fixtureCorrection='Initial 54 PASS/1 FAIL: the new metadata fixture had no result annotation and selected no image call. The next 0 PASS/1 FAIL used the nonexistent Image type. The shared resource catalog names ImageSurface; using Handle<ImageSurface> gives 55/55 PASS with all original destination/order/type assertions intact. Production validation was not weakened. The second command selected only the semantic library and therefore has a distinct feature union; it is not combined with the three-package focus.'
    ownerReview=$owner;quality=$gates;structure=(Read-Receipt 'presentation-argument-key.structure-summary.json')
    reverse=[ordered]@{graph=$graph;matrix=$matrix;passed=($terminals|Measure-Object passed -Sum).Sum;failed=($terminals|Measure-Object failed -Sum).Sum;skipped=($terminals|Measure-Object skipped -Sum).Sum;inputs=$freeze.paths.Count;sourceDrift=0;catalogCaseDrift=0}
    genericCoverage=$generic
    additionalCli=[ordered]@{matrix=$cli;comparison=$comparison;allCliTargets=$allCli}
    limits=@(
        'This completes exact checked argument destinations and their use by the existing readonly reference ABI. It does not connect Source staging factories, ViewValue/Handle/Removed creation, commands/methods/driver or explicit execution-owned staging scope.'
        'Open-supply options outside the shared executable grammar remain unclassified. They acquire no guessed typed authority; executable consumers must require a sealed key. Image metadata order here is checked semantic order, not evidence of executing image commands.'
        'Already-live aggregate quotas, public Native save, complete task-family acceptance and Native/Web image parity are separate boundaries. Generic Match acceptance is preserved independently of those remaining conditions and CLI failures.'
        'Clippy also reports one redundant method closure in the new semantic test at presentation.rs:43; its full diagnostic is retained. No Cargo dependency, feature, unsafe, I/O, assertion, budget, operation count, default filter or test concurrency changed. Runtime commands and feature unions remain separate even where source inputs are identical. Clippy exit zero does not imply warning-free.'
        'No executable documentation example, host or capture path changed. Doctests, Core-specific default/Wasm checks and Tier 2 were not rerun for this key/semantic projection cut; their earlier receipts keep their original inputs.'
    )
    raw=[ordered]@{path='task-presentation-argument-key-raw.zip';entries=$files.Count;verifiedEntries=$verified;entryDrift=0;bytes=(Get-Item -LiteralPath $archivePath).Length;sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant()}
}
$result|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $manifestPath -Encoding utf8
[ordered]@{source=$publication.commit;focus=$focus.passed;reverse=$result.reverse;raw=$result.raw}|Select-Object source,focus,@{n='reversePassed';e={$_.reverse.passed}},@{n='reverseFailed';e={$_.reverse.failed}},raw|ConvertTo-Json -Depth 6 -Compress