$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskTemp/convergence-image-git-bytes.ps1"
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$publication=Get-Content "$taskTemp/checkpoint-presentation-argument-key.verified.json" -Raw|ConvertFrom-Json
$metadata=[IO.File]::ReadLines("$taskTemp/presentation-argument-key-reverse-20261101.metadata.log")|Where-Object {$_.StartsWith('{"packages"')}|Select-Object -Last 1|ConvertFrom-Json -Depth 100
$workspace=[Collections.Generic.HashSet[string]]::new([string[]]$metadata.workspace_members)
$owners=@('arcweft-interaction-model','arcweft-lang-sema','arcweft-compiler')
$graph=@(foreach($name in $owners){
    $package=@($metadata.packages|Where-Object name -eq $name)[0]
    $node=@($metadata.resolve.nodes|Where-Object id -eq $package.id)[0]
    $forward=@($node.dependencies|Where-Object {$workspace.Contains($_)})
    $reverse=@($metadata.resolve.nodes|Where-Object {$workspace.Contains($_.id) -and $package.id -in $_.dependencies})
    [ordered]@{owner=$name;workspaceFanIn=$reverse.Count;workspaceFanOut=$forward.Count}
})
$files=@(foreach($path in Get-Content "$taskTemp/presentation-argument-key.owned.txt"){
    $old=if($path -in @('crates/arcweft-interaction-model/tests/presentation_arguments.rs')) {''}else{[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',($publication.parent+':'+$path))))}
    $text=[IO.File]::ReadAllText((Join-Path (Get-Location) $path))
    $loc=[IO.File]::ReadAllLines((Join-Path (Get-Location) $path)).Count
    $oldLoc=if($old){($old -split "`n").Count-[int]$old.EndsWith("`n")}else{0}
    [ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;physicalLoc=$loc;basePhysicalLoc=$oldLoc;growth=$loc-$oldLoc;classification=$(if($path -like '*/tests/*'){'test'}else{'production'});embeddedTestLoc=0}
})
[ordered]@{
    version=1;source=$publication.commit;base=$publication.parent;workingTree='main; original WIP and task documentation held separately; published source blobs verified'
    files=$files;dependencyGraph=$graph
    decisions=@(
        'interaction-model owns the shared role/tag/source-spelling inventory, callable role grammar and sealed exact argument key. Deleted the copied string-switch readers. Metadata keeps both its Parameter/ProxyParameter role and non-empty validated identifier path; fixed fields cannot carry metadata keys. No Core, HIR, semantic-analysis, renderer or I/O dependency is added.'
        'The existing checked-call owner derives keys while sealing the executable operand inventory and binds them into its canonical version-1 digest. Its destination coordinates, original checked schema, source order, type facts and compact ABI position remain together. The new field is not a side table or a second resolver. The already-large module remains the cohesive checked-call seal/coordinate/encoder owner; this cut adds no unrelated state or HIR walk and does not widen APIs to split files.'
        'Compiler lowering consumes the sealed slot role for inert references rather than resolving the checked parameter schema again. The existing large lowering owner loses code; a broad unrelated decomposition is outside this boundary. Runtime calls retain their original exact slot-reference ABI and original-program admission.'
        'The public model tests cover domain distinction and strict codec rejection. The semantic regression follows the same operand-authority owner and exercises Japanese/dotted metadata paths, two distinct fields with the same role, fixed-vs-open compact order and authored argument order. No build settings, dependency/features, unsafe or I/O changed.'
    )
}|ConvertTo-Json -Depth 20|Set-Content "$taskTemp/presentation-argument-key.owner-review.json" -Encoding utf8
[ordered]@{owners=$owners.Count;paths=$files.Count;source=$publication.commit}|ConvertTo-Json -Compress