$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$manifest=Get-Content 'docs/implementation/acceptance-evidence/task-presentation-argument-key-validation.json' -Raw|ConvertFrom-Json -Depth 100
$source=$manifest.source
if((git rev-parse HEAD).Trim() -ne $source){throw 'Status source differs'}
$normal=$manifest.reverse
$cli=$manifest.additionalCli
$all=$cli.allCliTargets
$check=@($cli.matrix.rows|Where-Object group -eq 'check')[0].terminal
$extra=@($cli.matrix.rows|Where-Object group -eq 'additional-integration')[0].terminal
$library=@($normal.matrix.rows|Where-Object group -eq 'libraries')[0].terminal
$unit=@($normal.matrix.rows|Where-Object group -eq 'cli-unit')[0].terminal
$integration=@($normal.matrix.rows|Where-Object group -eq 'cli-integration')[0].terminal
$reference='[入力・終端・失敗履歴の原本](acceptance-evidence/task-presentation-argument-key-validation.json)'
$path='docs/implementation/current-status.md'
$lines=[Collections.Generic.List[string]]::new([string[]][IO.File]::ReadAllLines((Join-Path (Get-Location) $path)))
if(@($lines|Where-Object {$_.StartsWith('| Presentationのchecked引数key |')}).Count){throw 'Current boundary already recorded'}
$replacements=[ordered]@{
    '| Presentation共有語彙・型投影の逆依存matrix |'="| Presentation引数key・checked slotの逆依存matrix | **62 package・通常3群：$($normal.passed) PASS／$($normal.failed) FAIL／$($normal.skipped) ignored** | $source・$($normal.inputs)入力の実Cargo graphから推移的逆依存を選択した。library／integration $($library.passed) PASS、CLI lib／bin $($unit.passed) PASS、通常6 integration target $($integration.passed) PASS。all-features・locked・default filter、commandごとのcatalog／case／EXE／入力差分0を保持。Generic Matchの既受入151 IDは151／151 PASS。$reference。 |"
    '| CLI追加check target |'="| CLI追加check target | **$($check.passed) PASS／$($check.failed) FAIL／$($check.skipped) ignored。保持失敗IDとの比較を記録** | $source・$($normal.inputs)入力。前回3b1bd1a110c34a04f70ca38a680b000147e9b751の43失敗IDとの比較は、同一$(@($cli.comparison.sameFailureIds).Count)・新規$(@($cli.comparison.newFailureIds).Count)・解消$(@($cli.comparison.resolvedFailureIds).Count)・未選択$(@($cli.comparison.unselectedPriorFailureIds).Count)。異なる入力の原因同一性はIDだけから推定しない。$reference。 |"
    '| CLI追加3 integration target／全target照合 |'="| CLI追加3 integration target／全target照合 | **追加3 targetは$($extra.passed) PASS。全$($all.testableTargets.Count) targetは重複なし$($all.uniqueExecuted)実行・$($all.passed) PASS／$($all.failed) FAIL・$($all.ignored) ignored** | bracket_numeric_batch、environment_callable_tensor、native_host_contractsを追加した。同じ$($normal.inputs)入力集合の通常2 commandと追加2 commandで現行lib／bin／integration全targetを網羅し、未選択target・case重複0。feature unionとruntime commandは別に記録し、zero-case targetはcompile選択として区別する。$reference。 |"
    '| workspace check／Clippy・Core default／Wasm・fmt・構造gate |'="| workspace check／Clippy・fmt・構造gate | **各gate終了0・構造blocking0・警告は残存** | $source・$($normal.inputs)入力。workspace全97 package・全target・全feature・lockedのcheck／Clippy、変更Rust 7 path fmtを実行した。構造は$($manifest.structure.files) files／$($manifest.structure.rustFiles) Rust files・$($manifest.structure.physicalRustLoc) physical Rust LOC・$($manifest.structure.reviewTriggers) review trigger・blocking0。共有model、C-seal、Compilerの3 ownerを記録した。Core default／Wasm、doctest、Tier 2は今回未再実行とし、旧入力の原本を履歴に保持する。$reference。 |"
}
foreach($prefix in $replacements.Keys){
    $matches=@(for($i=0;$i -lt $lines.Count;$i++){if($lines[$i].StartsWith($prefix)){$i}})
    if($matches.Count -ne 1){throw ('Expected one current row: '+$prefix)}
    $lines[$matches[0]]=$replacements[$prefix]
}
$header=@(for($i=0;$i -lt $lines.Count;$i++){if($lines[$i].StartsWith('確認日:')){$i}})
if($header.Count -ne 1){throw 'Expected one status header'}
$lines[$header[0]]="確認日: 2026-11-01。最新の実装Sourceは$source。Presentationのchecked引数keyを4,047入力・対象55件で確認し、同じ入力集合の通常62逆依存は$($normal.passed) PASS／$($normal.failed) FAIL／$($normal.skipped) ignored。全CLI targetは$($all.passed) PASS／$($all.failed) FAIL／$($all.ignored) ignored。各commandのfeature union・結果は個別に保持する。元からの14 tracked／6 untracked WIPを保持し、公開canonicalと保持WIPを同一視せず、受入と未達は各行の境界・検証範囲で判定する。"
$position=@(for($i=0;$i -lt $lines.Count;$i++){if($lines[$i].StartsWith('| Presentationの共有slot住所 |')){$i}})
if($position.Count -ne 1){throw 'Expected one presentation owner row'}
$lines.Insert($position[0],"| Presentationのchecked引数key | **当該引数投影を検証・公開済み** | Source $source。共有grammarがrole・tag・Source名を所有し、param.*／proxy.param.*のfamilyと完全な識別子pathをsealed keyへ保持する。Semaが実行slotのキー・Source順・compact ABI位置を確定してversion 1のdigestへ含め、CompilerのSlotRef loweringもそのslot authorityを使う。異なるmetadata key、family、target domain、厳密なSerde拒否とSource解析を含む対象55／55 PASS。Source staging実行・driverはCore行の別境界。$reference。 |")
[IO.File]::WriteAllLines((Join-Path (Get-Location) $path),$lines,[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-01 — Presentation checked引数key

- Source公開: $source。親39b540872e4b08f85e525ae97638d3f01c2fec96、7 pathのpatchと全blob・remote mainを照合。元14 tracked／6 actual untracked WIPは保持。
- 共有role/tag/Source名の単一inventoryとsealed keyを導入し、コピーされたSource名switchを削除した。C-sealで各物理引数slotのfamily/keyを確定し、Source順とcompact ABI位置を別に保持、canonical version 1 digestへ含めた。既存SlotRef loweringは同slot authorityを消費する。
- 初回focusは54 PASS／1 FAILで新規fixtureのimage callが未採用。次の1件は未定義のImage型でFAIL。正式なImageSurface戻り型へfixtureを修正し、元の型・key・順序assertionを維持して55／55 PASS。初回のbase・入力hash・全失敗結果を原本へ保持した。第2回はSema libのみでfeature unionも別。最終focusの入力hashは公開後の4,047入力とすべて一致する。
- 当該Sourceの実Cargo graphは62逆依存。通常3 commandは$($normal.passed) PASS／$($normal.failed) FAIL／$($normal.skipped) ignored。既受入のGeneric Match 151 IDはすべて選択され151／151 PASS。accepted 850534b9e9bc8c8872f6528dd00050a5e6e7699e／published f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2は維持する。
- CLI追加checkは$($check.passed) PASS／$($check.failed) FAIL／$($check.skipped) ignored。保持43 IDとの比較は同一$(@($cli.comparison.sameFailureIds).Count)・新規$(@($cli.comparison.newFailureIds).Count)・解消$(@($cli.comparison.resolvedFailureIds).Count)・未選択$(@($cli.comparison.unselectedPriorFailureIds).Count)。追加3 targetは$($extra.passed) PASS。全$($all.testableTargets.Count) targetは$($all.uniqueExecuted) unique実行、$($all.passed) PASS／$($all.failed) FAIL・$($all.ignored) ignored。4 command・feature unionは統合runへ読み替えない。
- workspace check／Clippy・7 path fmt・構造gateは各終了0。構造は$($manifest.structure.files) files／$($manifest.structure.rustFiles) Rust files・$($manifest.structure.physicalRustLoc) physical Rust LOC、review trigger $($manifest.structure.reviewTriggers)・blocking 0。Clippyには新規fixtureのredundant closure 1件も残り、warning-freeとはしない。Core default／Wasm・doctest・Tier 2は未再実行。
- 現状一覧の更新理由は新しい実装・検証入力への集約。前回の共有matrix 3b1bd1a110c34a04f70ca38a680b000147e9b751・4,045入力の9019 PASS／0 FAIL／24 ignored、CLI 43 FAIL、Core default／Wasm成功、およびprivate Native body返却df73dc174657216a20c5c42317ad1205758b5316・Core 2,181 PASSは元の入力の履歴・原本として保持する。完了済み機能を全体goalの未完了だけで戻さない。
- Source staging factory・ViewValue/Handle/Removed生成・command/method・driverの接続を今回の引数投影から受入へ広げない。現状はcurrent-status.md一か所で判定する。
- 原本: [checked引数keyの検証](acceptance-evidence/task-presentation-argument-key-validation.json)、raw archiveは$($manifest.raw.entries) entries／$($manifest.raw.bytes) bytes、SHA-256 $($manifest.raw.sha256)。全entryをTemp原本と照合し差分0。
"@
[IO.File]::AppendAllText((Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'),$history+"`r`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Current status consolidated; previous history bytes retained.'