$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze = Get-Content -LiteralPath "$taskTemp/action-declaration-topology-owner3-20261102.source-freeze.json" -Raw | ConvertFrom-Json
$previous = Get-Content -LiteralPath "$taskTemp/action-declaration-sema-owner1-20261102.source-freeze.json" -Raw | ConvertFrom-Json
$delta = @($freeze.paths | Where-Object { $current = $_; @($previous.paths | Where-Object { $_.path -eq $current.path -and $_.sha256 -eq $current.sha256 }).Count -ne 1 })
if ($delta.Count -ne 1 -or $delta[0].path -ne 'crates/arcweft-lang-hir/src/final_project/tests/action_declaration.rs') { throw 'Unexpected quality reuse delta' }
[ordered]@{version=1;previous='action-declaration-sema-owner1-20261102';current='action-declaration-topology-owner3-20261102';paths=$delta;productionDrift=0;reason='Use assert_eq for the empty parameter inventory so Clippy adds no new assert_is_empty warning; the same behavioral assertion was rerun and passed.'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/action-declaration-quality-reuse-delta.json" -Encoding utf8
function Assert-Inputs {
    foreach ($row in $freeze.paths) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
Assert-Inputs
$started = [DateTime]::UtcNow.ToString('o')
$arguments = @('clippy','-p','arcweft-lang-hir','--all-targets','--all-features','--locked')
& cargo @arguments *> "$taskTemp/action-declaration-quality2-clippy-20261102.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/action-declaration-quality2-clippy-20261102.json" -Encoding utf8
exit $code
