$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$freeze = Get-Content -LiteralPath "$taskTemp/action-declaration-sema-repro1-20261102.source-freeze.json" -Raw | ConvertFrom-Json
$graphInputs = @($freeze.paths | Where-Object { $_.path -match '(Cargo\.(toml|lock)|rust-toolchain\.toml|\.cargo[/\\]config\.toml)$' })
foreach ($row in $graphInputs) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Graph input drift: $($row.path)" }
}
$original = Get-Content -LiteralPath "$taskTemp/presentation-frame-mcp-metadata-owner7-20261102.source-freeze.json" -Raw | ConvertFrom-Json
foreach ($row in $graphInputs) {
    $before = @($original.paths | Where-Object path -eq $row.path)
    if ($before.Count -ne 1 -or $before[0].sha256 -ne $row.sha256) { throw "Metadata reuse not proven: $($row.path)" }
}
$metadata = Get-Content -LiteralPath "$taskTemp/presentation-frame-driver.metadata.json" -Raw | ConvertFrom-Json -Depth 100
$roots = @('arcweft-lang-hir', 'arcweft-lang-sema')
$selected = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($package in $metadata.packages) {
    if ($package.name -in $roots) { [void]$selected.Add($package.id) }
}
do {
    $changed = $false
    foreach ($node in $metadata.resolve.nodes) {
        if ($selected.Contains($node.id)) { continue }
        foreach ($dependency in $node.deps) {
            if ($selected.Contains($dependency.pkg)) {
                [void]$selected.Add($node.id)
                $changed = $true
                break
            }
        }
    }
} while ($changed)
$packages = @($metadata.packages | Where-Object { $_.id -in $metadata.workspace_members -and $selected.Contains($_.id) } | Sort-Object name)
$result = [ordered]@{
    version = 1
    sourceBase = (git rev-parse HEAD).Trim()
    roots = $roots
    metadata = 'presentation-frame-driver.metadata.json'
    metadataReuse = 'Resolved all-feature graph; all Cargo/config/toolchain/lock inputs matched the pinned prior graph inputs.'
    graphInputs = $graphInputs
    graphInputDrift = 0
    targetEdges = 'All resolved normal/dev/build/target dependency edges'
    reversePackages = @($packages.name)
    reverseCount = $packages.Count
    workspaceCount = $metadata.workspace_members.Count
    resolvedPackages = $metadata.packages.Count
}
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$taskTemp/action-declaration.reverse-graph.json" -Encoding utf8
[pscustomobject]$result | Select-Object roots, reverseCount, workspaceCount, resolvedPackages, graphInputDrift | ConvertTo-Json
