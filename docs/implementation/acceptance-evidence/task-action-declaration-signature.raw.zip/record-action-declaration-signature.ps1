$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$source = 'a2688f77338bd0b34a7651d4910312045a59d6bf'
if ((git rev-parse HEAD).Trim() -ne $source) { throw 'Unexpected source' }
$utf8 = [Text.UTF8Encoding]::new($false)
function HashBytes([byte[]]$bytes) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() }
function Read-Receipt([string]$name) { Get-Content -LiteralPath "$e/$name.json" -Raw | ConvertFrom-Json }
$statusPath = 'D:/git/arcweft/docs/implementation/current-status.md'
$historyPath = 'D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$status = [IO.File]::ReadAllText($statusPath)
$history = [IO.File]::ReadAllBytes($historyPath)
$generic = @($status -split [char]10 | Where-Object { $_ -like '| Generic Match*' }) -join [char]10
$untracked = Read-Receipt 'task-documentation-final-untracked-before'
foreach ($row in $untracked.files) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Original untracked WIP changed: $($row.path)" }
}
$raw = 'docs/implementation/acceptance-evidence/task-action-declaration-signature.raw.zip'
if (Test-Path -LiteralPath $raw) { throw 'Archive already exists' }
$files = @(Get-ChildItem -LiteralPath $e -File | Where-Object {
    ($_.Name -like 'action-declaration*' -or $_.Name -like 'run-action-declaration*' -or $_.Name -like 'checkpoint-action-declaration*' -or $_.Name -like 'scroll-action*' -or $_.Name -eq 'scroll-canonical-action-probe.arcw') -and $_.Extension -in @('.json','.log','.patch','.txt','.ps1','.arcw')
})
$files += @(Get-Item -LiteralPath "$e/run-presentation-projection-owner.ps1", "$e/audit-nextest-final-result.ps1", "$e/record-action-declaration-signature.ps1")
$files += @(Get-ChildItem -LiteralPath "$e/action-declaration-quality1-20261102.structure-report" -File)
$entries = @(foreach ($file in ($files | Sort-Object FullName -Unique)) {
    $name = if ($file.Directory.Name -like '*.structure-report') { 'structure/' + $file.Name } else { $file.Name }
    [ordered]@{path=$name;source=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
})
$zip = [IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $raw),[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($row in $entries) {
        $output = $zip.CreateEntry($row.path,[IO.Compression.CompressionLevel]::Optimal).Open()
        $input = [IO.File]::OpenRead($row.source)
        try { $input.CopyTo($output) } finally { $input.Dispose(); $output.Dispose() }
    }
    $writer = [IO.StreamWriter]::new($zip.CreateEntry('manifest.json').Open(),$utf8)
    try { $writer.Write((@{version=1;source=$source;files=$entries}|ConvertTo-Json -Depth 8)) } finally { $writer.Dispose() }
} finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $raw))
try {
    foreach ($row in $entries) {
        $stream = $zip.GetEntry($row.path).Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($hash -ne $row.sha256) { throw "Archive entry drift: $($row.path)" }
    }
    if ($zip.Entries.Count -ne $entries.Count + 1) { throw 'Archive count drift' }
} finally { $zip.Dispose() }
$owned = @(Get-Content -LiteralPath "$e/checkpoint-action-declaration.owned.txt")
$metrics = @(Import-Csv -LiteralPath "$e/action-declaration-quality1-20261102.structure-report/file_metrics.csv" | Where-Object { $_.path -in $owned })
$record = [ordered]@{
    version=1; source=$source; publication=(Read-Receipt 'checkpoint-action-declaration.verified')
    boundary='Action declarations and fixed payload signatures; original HIR patterns/locals, declared Sema types, item-rooted checked semantic coordinates.'
    diagnosis=@('A declaration alone failed HIR topology sealing with InvalidOwnedPath because Action parameter patterns and locals had no item-owned roots.','After sealing the topology, the Sema regression failed LocalTypeUnavailable because Action parameters were omitted from signature type seeding.')
    attempts=@{hirRegression=(Read-Receipt 'action-declaration-topology-repro3-20261102.runtime.terminal-audit');semaRegression=(Read-Receipt 'action-declaration-sema-repro1-20261102.runtime.terminal-audit');setupFailures=@('HIR repro1: E0583 from an incorrect test child-module path, corrected with an explicit path.','HIR repro2: zero matches from an incorrect final_project prefix; actual public module is project.','HIR owner1: catalog compiled, runtime was not started because the expected count included 8 ignored cases. Actual ordinary count is 958.','The first standalone minimal matrix used Int, then the canonical i64 matrix corrected that probe error. Both raw results are retained.')}
    hirLibrary=(Read-Receipt 'action-declaration-topology-owner2-20261102.runtime.terminal-audit')
    semaLibrary=(Read-Receipt 'action-declaration-sema-owner1-20261102.runtime.terminal-audit')
    finalHirRegression=(Read-Receipt 'action-declaration-topology-owner3-20261102.runtime.terminal-audit')
    quality=@{check=(Read-Receipt 'action-declaration-quality1-check-20261102');clippy=(Read-Receipt 'action-declaration-quality1-clippy-20261102');structure=(Read-Receipt 'action-declaration-quality1-structure-20261102');finalHirClippy=(Read-Receipt 'action-declaration-quality2-clippy-20261102');reuseDelta=(Read-Receipt 'action-declaration-quality-reuse-delta');warnings='Workspace warnings remain. The new test assert_is_empty warning was corrected; final HIR Clippy and the regression were rerun.'}
    structure=@{files=3314;rustFiles=3183;rustPhysicalLoc=1792937;reviewTriggers=384;blocking=0;metrics=$metrics;disposition=@('HIR semantic_paths remains the sole snapshot-bound topology, origin, path and sealing authority. Non-callable item parameter roots share the existing parameter grammar and walker without fabricating a callable symbol. No I/O or second HIR model is introduced.','Sema patterns seeds the declared Action payload type through the existing canonical type environment and pattern seeding authority. Callable omitted-effect inference remains owned by accepted callable signatures.','semantic_coordinate and its catalog remain the sole checked coordinate grammar, canonical encoding and HIR-to-checked projection. Existing tags remain unchanged; the new tag is a grammar discriminator, not a contract version change.','New regressions follow the Action signature ownership boundary; the large parent test modules only declare their child. No dependency or visibility widening is used for file splitting.')}
    dependencyGraph=(Read-Receipt 'action-declaration.reverse-graph')
    remaining=@('The other targets and consumers in the 23-package reverse dependency closure are pending, not passed.','Typed message construction, emit/receive continuation behavior, dotted declaration spelling reconciliation and the Scroll CLI case are not accepted by this signature-only checkpoint.','Native/AWBC execution and Native/Web rendering acceptance are not inferred from HIR/Sema signature tests.')
    acceptedBoundaries='Generic Match and the other accepted feature boundaries remain accepted. No completed function is reopened from overall goal status.'
    workingTree=@{heldTracked=12;originalUntracked=$untracked.files.Count;heldPatchSha256='46402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac';untrackedDrift=0}
    historyPrefix=@{bytes=$history.Length;sha256=(HashBytes $history)};genericRowSha256=(HashBytes $utf8.GetBytes($generic))
    raw=@{path=$raw;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();payloadEntries=$entries.Count;entryHashDrift=0;buildArtifactsIncluded=$false}
}
$record | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-action-declaration-signature.json' -Encoding utf8
$lines = $status -split [char]10
for ($index=0; $index -lt $lines.Count; $index++) {
    if ($lines[$index] -like '確認日:*') { $lines[$index]='確認日: 2026-11-02。最新公開Sourceはa2688f77338bd0b34a7651d4910312045a59d6bf。Action宣言の署名解析を修復した。既存12 tracked／6 actual untracked WIPを保持している。全63逆依存の既存runと、Action変更の23逆依存で未実行の範囲を区別する。' }
}
$updated = $lines -join [char]10
$anchor = '| 未定義値パス／宣言defaultの診断'
$at = $updated.IndexOf($anchor,[StringComparison]::Ordinal)
if ($at -lt 0) { throw 'Status anchor missing' }
$row = '| Action宣言のpayload署名解析 | **宣言・署名の修復は検証・公開済み。送受信の受入は別境界** | Source a2688f77338bd0b34a7651d4910312045a59d6bf。Action自身の引数root・元pattern/localを既存HIR topologyに保持し、Semaが宣言型とchecked意味座標を確定する。宣言だけでのInvalidOwnedPathと、後段のLocalTypeUnavailableを再現して修復した。HIR通常958／958（8 ignored）、Sema1359／1359、workspace check／Clippy・構造gate終了0。最終test-only lint修正は当該1件とHIR Clippyを再実行した。実graphの23逆依存の残り、typed構築・emit／receive・dotted宣言の整合・Scroll CLIは、この署名解析の完了へ含めない。[失敗・修復・公開・検証範囲](acceptance-evidence/task-action-declaration-signature.json)。 |' + [char]10
$updated = $updated.Insert($at,$row)
if ((@($updated -split [char]10 | Where-Object { $_ -like '| Generic Match*' }) -join [char]10) -cne $generic) { throw 'Generic row changed' }
[IO.File]::WriteAllText($statusPath,$updated,$utf8)
$append = @"


## 2026-11-02 Action宣言・payload署名の所有／型付け修復

Source a2688f77338bd0b34a7651d4910312045a59d6bf、parent a7f47b0ef7ddf8196cec527382b041c7db451d09、tree b240efd1b8031b9ceee89a5d89878bd90170817f。
最小のAction宣言だけでHIR topologyがInvalidOwnedPathとなることを実testで再現した。Actionの元pattern/localをitem署名rootとして既存ownerへ登録し、架空のcallable symbolを作らずに修復した。
次のSema testはLocalTypeUnavailableで失敗し、宣言型を共通pattern seedへ接続して修復した。どちらの失敗原本も保持する。
HIR通常958 PASS／8 ignored、Sema1359 PASS。空引数・複数引数・明示公開ID・複数Actionと、checked型・元local・item意味座標を確認した。
workspace全target／全feature／locked check・Clippy、構造gateは終了0。構造3314 file／3183 Rust／1792937 Rust physical LOC、review trigger384／blocking0。警告は残る。
新testのClippy指摘1箇所をassert_eqへ直し、当該1件とHIR全target Clippyは再実行してPASS／終了0。他の検証はproduction差分0を根拠に再利用し、958件の新規通し再実行とはしない。
実graphは846 resolved／98 workspace、manifest等101入力差分0、HIR/Semaの推移的逆依存23 package。残るconsumer全件はこの時点で未実行として保持する。
修復は宣言・署名解析に限る。typed構築、emit／receive、採用例のdotted宣言整合、Scroll CLI、Native/AWBCやNative/Webの受入を完了とはしない。
既受入Generic Matchなどを戻す根拠はなく、現状のGeneric行はbyte不変。既存12 tracked／6 actual untracked WIPも保持した。
現状一覧には未達を一括列挙せず、この署名解析の完了と送受信の未検証範囲を同じ1行で区別した。原本は[Action署名](acceptance-evidence/task-action-declaration-signature.json)。
"@
$stream = [IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write)
try { $stream.Write($utf8.GetBytes($append)) } finally { $stream.Dispose() }
$after = [IO.File]::ReadAllBytes($historyPath)
if ((HashBytes $after[0..($history.Length-1)]) -ne (HashBytes $history)) { throw 'Historical prefix changed' }
[ordered]@{version=1;source=$source;genericUnchanged=$true;historyPrefixUnchanged=$true;originalUntrackedDrift=0;archiveEntries=$entries.Count;archiveBytes=(Get-Item -LiteralPath $raw).Length} | ConvertTo-Json | Set-Content -LiteralPath "$e/action-declaration-signature-doc-audit.json" -Encoding utf8
Get-Content -LiteralPath "$e/action-declaration-signature-doc-audit.json" -Raw
