$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '78c4fa6aeecad419e99cb271dac31096a1358863'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'closed-original-components.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='The closed original forest now stages one canonical CompletedConstraintComponent per exact original member through its real joint branch and the same closed-effects owner. CompletedOriginalMember retains producer/frontier/path correlation; the joint branch retains original proof inputs rather than a parallel value model. A complete component is built only after source opening identities are checked against the actual branch, and source records, equations, solutions and registered projections share the real completion. Duplicate application domain keys and missing projection source owners produce typed errors instead of silent overwrite or an expect panic. Component/projection construction takes only a graph read view and does not reopen templates, re-infer source C, prepare bodies or solve an effect minimum. All accepted members are staged before the closed forest is published; an operational error returns the same affine forest and rolls back newly allocated graph metadata. A member-specific rejection carries its original address. Closed source records own their exact completion Arc beside canonical actual/expected ports. Original equations validate those ports by direct borrow and owner/source-ordinal checks; the separate ClosedConstraintRelation field, mutable close_source_rows writer and unused whole-equation transport API are removed. The original source trace has only ActiveConstraintProbe values and the completed trace has only ClosedConstraintProbe values, so the old mixed ConstraintProbe enum, readers and into_closed path are deleted. The obsolete runtime state test source_trace_cannot_skip_or_repeat_completion is replaced by a_closed_source_keeps_its_exact_completion_owner; unavailable states are now encoded by separate Rust types, without a completed compilation claim. The existing canonical-source fixture keeps actual Named/header assertions, original C/operand identity and foreign-owner refusal through the direct source reader; it additionally checks the completed component output. Repeated scalar source fixtures thread their own real graph and freeze their actual C, with an explicit no-effect-variable assertion and no missing Future default. Two new fixtures cover canonical source/equation preservation with a real late Named body and explicit nonempty Future, and failure at a later member after an earlier component was staged, returning the same forest and retaining callback preparation for retry. The existing joint fixture also observes the automatically completed members. All tests remain unrun because full required Sema target checking fails; actual logs and intermediate stale-import failure are retained. The old eager transaction adapter still lacks original/Future phase input and is a compile failure, not an accepted compatibility path. Callback queue consumption, frontend switch, Fn-local quantified/guarded contracts, broad body-once and public acceptance remain unfinished. No allocation/copy preflight completeness, one-pass, performance or workspace success claim is made. No fake source, copied final relation side table, guessed Future row, legacy success reader, body replay, Cargo dependency/features, facade, layer reversal, I/O, unsafe, codec/version, budget, jobs or profile change is introduced. Existing accepted Generic Match/runtime results and resolved graph/reverse-dependency evidence are preserved; scanner and broad acceptance are not rerun. LOC/bytes/growth/test classification are review evidence, not file-spelling gates.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'closed-original-components.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03','dev04','dev05')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'closed-original-components.'+$iteration+$suffix}})
$names+=@('closed-original-components.source-publication.json','closed-original-components.ownership-review.json','closed-original-components.staged-review.json','closed-original-components.dev05-diagnostic-review.json')
$names+=@('run-closed-original-components-check.ps1','archive-closed-original-components.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-closed-original-components-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-closed-original-components-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'closed-original-components.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
