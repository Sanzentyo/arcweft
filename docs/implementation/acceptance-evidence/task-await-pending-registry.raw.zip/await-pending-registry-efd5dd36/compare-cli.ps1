$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-registry-await-20261110'
function ArcSha($path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
$qa=Get-Content (Join-Path $d 'quality.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$baseline=Get-Content (Join-Path $d 'baseline.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if(!$qa.cliSha256 -or $qa.cliSha256 -ne $sha -or $baseline.cliSha256 -eq $sha){throw 'Changed CLI artifact is not exact'}
$checks=@(foreach($before in $baseline.checks){
    $name=$before.name
    $source=Join-Path $d "$name.arcw"
    if((ArcSha $source) -ne $before.sourceSha256){throw "Baseline source drift $name"}
    $out=Join-Path $d "$name.after.json"
    $err=Join-Path $d "$name.after.stderr.log"
    & $cli check $source --json > $out 2> $err
    $code=$LASTEXITCODE
    $report=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
    $diagnostics=@($report.diagnostics|Where-Object { $_.diagnostic })
    $messages=@($diagnostics|ForEach-Object {$_.diagnostic.message})
    switch($name){
        'flow-pending-native-fs' {if($code -or $diagnostics.Count){throw 'Original registry read remains rejected'}}
        'flow-pending-native-fs-control' {if($code -or $diagnostics.Count){throw 'Control no longer checks'}}
        'flow-pending-in-thread' {if($code -ne 1 -or $diagnostics.Count -ne 1 -or $messages[0] -notmatch 'has no reached Flow scope'){throw 'Independent Thread no longer rejects access to its parent Flow registry'}}
        'flow-pending-registration-changes' {if($code -ne 1 -or $diagnostics.Count -ne 1 -or $messages[0] -notmatch 'requires a registration of the expected type on every reaching path'){throw "Repeat-path rejection differs: $($messages -join ',')"}}
        default {throw "Unrecognized replay $name"}
    }
    [ordered]@{name=$name;exit=$code;stage=$report.stage;diagnostics=@($diagnostics|ForEach-Object {$_.diagnostic.code});messages=$messages;sourceSha256=$before.sourceSha256;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
$runs=@(foreach($executor in 'bytecode-vm','awbc-product'){
    $source=Join-Path $d 'flow-pending-native-fs.arcw'
    $out=Join-Path $d "$executor.after.json"
    $err=Join-Path $d "$executor.after.stderr.log"
    if((ArcSha (Join-Path $d '.arcweft/save/observed.txt')) -ne $baseline.inputFileSha256){throw 'Input file drift'}
    & $cli run $source --entry entry.main --executor $executor --mode drain --steps 24 --max-ops 64 --json > $out 2> $err
    $code=$LASTEXITCODE
    $report=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
    if($code -or $report.final_status -ne 'done Return("ready payload")'){throw "Real CLI run did not return its file on $executor"}
    [ordered]@{executor=$executor;entry='entry.main';steps=24;maxOps=64;exit=$code;status=$report.final_status;sourceSha256=ArcSha $source;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
[ordered]@{version=1;base=$qa.base;cliSha256=$sha;checks=$checks;runs=$runs;inputFileSha256=$baseline.inputFileSha256}|ConvertTo-Json -Depth 12|Tee-Object -FilePath (Join-Path $d 'changed.receipt.json')

