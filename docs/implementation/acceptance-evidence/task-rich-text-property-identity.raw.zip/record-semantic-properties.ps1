$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Receipt([string]$name){Get-Content -Raw "$taskTemp/$name.json"|ConvertFrom-Json -Depth 100}
$source=Read-Receipt 'semantic-properties-source.verified'
$terminal=Read-Receipt 'semantic-properties-reverse1-20261104.runtime.terminal-audit'
$comparison=Read-Receipt 'semantic-properties-result-comparison'
if($source.commit -ne (git rev-parse HEAD).Trim() -or $terminal.executed -ne 7108 -or $terminal.failed -ne 14){throw 'Unexpected source/result'}
$cases=@(Read-Receipt 'semantic-properties-reverse1-20261104.runtime.cases')
$lookup=@{};foreach($case in $cases){$lookup[$case.binary+[char]9+$case.test]=$case}
$oldAux=@(Read-Receipt 'layout-presence-native-aux-coverage')
$aux=@(foreach($case in ($oldAux.cases|Sort-Object binary,test -Unique)){$row=$lookup[$case.binary+[char]9+$case.test];if($null -eq $row -or $row.status -notin @('PASS','SLOW')){throw 'Missing/failing auxiliary case'};$row})
if($aux.Count -ne 16 -or $oldAux.Count -ne 10){throw 'Auxiliary membership changed'}
$aux|ConvertTo-Json -Depth 10|Set-Content "$taskTemp/semantic-properties-native-aux-coverage.json"
$quality=@(foreach($name in @('semantic-properties-quality2-check','semantic-properties-quality2-clippy','semantic-properties-quality2-structure','semantic-properties-quality3-check','semantic-properties-quality3-clippy','semantic-properties-quality3-structure','semantic-properties-owner4-check','semantic-properties-owner4-clippy','semantic-properties-fmt')){$receipt=Read-Receipt $name;if($receipt.exitCode){throw "Failed gate $name"};[ordered]@{receipt=$name;result=$receipt}})
$history=[IO.File]::ReadAllBytes((Join-Path $PWD 'docs/implementation/convergence-evidence-history.md'))
$prefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
$keys=@('RichTextの部分layout指定／source factory',('Generic Match '+[char]96+'.1.2'+[char]96+' C3/C5'),'共有契約／推移的逆依存matrix','CLI全target照合','workspace check／Clippy・fmt・構造gate')
$oldRows=@([IO.File]::ReadAllLines((Join-Path $PWD 'docs/implementation/current-status.md'))|Where-Object {$_.StartsWith('| ') -and ($_ -split '\|')[1].Trim() -in $keys})
if($oldRows.Count -ne 5){throw 'Missing/duplicate current rows'}
[ordered]@{version=1;head=$source.commit;supersededCurrentRows=$oldRows;reason='New implementation/execution evidence completes semantic property identity; remove that completed boundary from the current remaining range while preserving all prior scoped acceptance.';historyPrefix=$prefix}|ConvertTo-Json -Depth 10|Set-Content "$taskTemp/semantic-properties-status-before.json"
foreach($row in (Read-Receipt 'task-documentation-final-untracked-before').files){if(-not(Test-Path -LiteralPath $row.path) -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
. "$taskTemp/write-verified-evidence-archive.ps1"
$archivePath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.raw.zip'
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like 'semantic-properties*' -and $_.Name -notlike '*next-construction*' -and $_.Extension -ne '.zip'})
foreach($directory in @('semantic-properties-quality2.structure-report','semantic-properties-quality3.structure-report')){$files+=@(Get-ChildItem -LiteralPath "$taskTemp/$directory" -File -Recurse)}
foreach($name in @('audit-semantic-property-tests.ps1','record-semantic-properties.ps1','run-presentation-projection-owner.ps1','run-action-payload-quality.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')){$files+=Get-Item -LiteralPath "$taskTemp/$name"}
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($taskTemp)) ([IO.Path]::GetFullPath((Join-Path $PWD $archivePath))) $files
$raw.path=$archivePath
$record=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');inspectedHead=$source.commit;source=$source
 state='Semantic reusable-property storage, merge and projection boundary validated. No whole-engine or source-factory acceptance is claimed.'
 workingTree='Original 12 tracked/6 actual untracked WIP retained; index empty before documentation updates.'
 implementation=@('Presentation derives 27 unique semantic settings from canonical content value contracts; conflicts reject instead of selecting a branch.','Stored descriptors exclude discriminator-only parameters, source names and call defaults. Writing mode and ruby position keep separate allowed variant sets.','Dialogue codec, complete Core type graph and fingerprint use that semantic projection for live/inert values.','Text model emits one sparse layout and one combined transform, without grouping by source selectors.')
 validation=[ordered]@{terminal=$terminal;graph=(Read-Receipt 'semantic-properties.graph');comparison=$comparison;nativeAuxiliaryTargets=10;nativeAuxiliaryDistinctCases=$aux;quality=$quality;sourceCaseExecutableDrift=0}
 qualityScope='All 98 check/Clippy/structure gates passed on quality3 input hashes. Two final text-model semicolons then passed owner check/Clippy. The last Dialogue changes restore a reading rejection and strengthen typography value assertions; these final test bytes compiled/executed in the 47-package run. No final all-98 rerun is claimed. Existing warnings remain; six owned Rust files passed rustfmt --check.'
 testMigration=@('Preserve live/inert full-content-shaped reading rejection and exact values for all four ruby typography settings.','Old private projector tests for Ruby source definitions and incomplete structural selectors are unrepresentable in admitted semantic rows. Applicable content exclusion/malformed payload boundaries remain covered by Presentation and Dialogue.')
 ownership=[ordered]@{measurements=(Read-Receipt 'semantic-properties-owner-measurements');disposition='Presentation remains the sole value-contract owner; its existing child derives identities. Dialogue retains one payload codec; text model removes source regrouping. The 1420-LOC catalog has only four new export lines and retains its existing cohesive descriptor responsibility. Driver changes only its consuming fixture. No dependency direction changes or new blocking structural findings.'}
 acceptanceScope='Earlier sparse-layout and Generic Match acceptance is preserved. Source factory execution, alias argument-order, full static provenance, dedicated doctest/wasm rerun, complete Native-Web parity and whole-goal completion are not claimed.'
 correctionReason='Remove completed common-property identity from the current remaining range based on this implementation and 18 passing owner/consumer cases. Matching 14 failed IDs do not prove identical causes; failures remain recorded.'
 supersededCurrentRows=$oldRows;historyPrefix=$prefix;raw=$raw
}
$record|ConvertTo-Json -Depth 100|Set-Content 'docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
[ordered]@{version=1;head=$source.commit;record='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json';raw=$raw.path;entries=$raw.entries.Count;sha256=$raw.sha256}|ConvertTo-Json|Set-Content "$taskTemp/semantic-properties-evidence-record.json"
Write-Output "Recorded raw entries=$($raw.entries.Count); sha256=$($raw.sha256)"