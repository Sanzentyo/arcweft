$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/scoped-effect-functions.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/scoped-effect-functions.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/scoped-effect-functions.consumer-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/scoped-effect-functions.archive.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/scoped-effect-functions.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -cne $pub.Source -or @(git diff --name-only HEAD).Count -or $owner.Source -cne $pub.Source -or $consumers.Source -cne $pub.Source -or $owner.Passed -ne 1672 -or $owner.Failed -ne 6 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2){throw 'Final evidence is incomplete'}
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
if((Get-FileHash $statusPath -Algorithm SHA256).Hash -cne $before.StatusSHA256){throw 'Current status changed'}
$status=[IO.File]::ReadAllText($statusPath)
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `6c515904c38bda8228f5839eb5053f54a2804963`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。本体内推論の修復を継続** | Native／AWBCの42と各step公開JSON保存復元の受入、完了値ごとのcapture保持・復元、checked sourceのΓ admission、template開放、対応operand portと実scopeの保持を維持する。最新Source `'+$pub.Source+'` では宣言schemeと導入時の依存引数を保持する推論行関数を同じcell集合で共同最小化し、scopeごとのwhole-row D⇒Cを評価してから局所形式引数を∀量化する。数学層の新9件を含む50件が全owner runでもPASS。残るのはreify入力の元operand導出への完全移行、checked primitive effect ownerと計算済み行のseal、引数全体の実Γ、futureを残すscope付き条件付きcompletion／MGU／rankと型ownerへの局所∀接続、frontend prepared value／effect接続・body一回準備・一括sealである。この基盤を再帰本体の実行受入とは判定しない。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[checked source](convergence-evidence-history.md#checked-source-value-scope)・[完了値](convergence-evidence-history.md#completed-output-capture-support)・[header port](convergence-evidence-history.md#typed-effect-header-ports)・[今回の数学層](convergence-evidence-history.md#scoped-effect-row-functions)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **同一SourceでSemaは1,672 PASS／6 FAIL、他21 consumerは2,507 PASS／2 FAIL／1 SKIP** | Source `'+$pub.Source+'`。全feature Sema lib／testsは1,678件を'+$owner.ExecutionSeconds.ToString('F3',[Globalization.CultureInfo]::InvariantCulture)+'秒で実行し、選択と終端の全IDが一致・重複0。直前の1,669 IDをすべて維持し、新9件がPASS。既知6失敗のIDと実診断は前回と一致（5 ExpressionCycle、1 PendingCallableEffectProjection）。他21 package・既定feature・規定107 targetは2,510選択IDと終端が一致・重複0。Compilerの既知2失敗は同じExpressionCycle（slot 17／19）。3 targetはcompile-only。Cargo入力差分0を確認して22 packageの依存graphを再利用し、実行結果は今回のSourceで新規採取した。owner全featureとconsumer既定featureは別sliceである。[全原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **今回の規定対象226件はPASS。全 check は未再実行** | Source `'+$pub.Source+'`、locked・既定feature／filter。library 196件と規定の統合6 target 30件が今回PASSし、binはcompile済み・runnable test 0件。全checkの修復や以前の失敗の再現は推定せず、以前の入力・件数・失敗は履歴と原本に保持する。[今回の原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **今回のworkspace全target／全feature check・Clippy、Sema doctest、整形・構造gateは終了0** | Source `'+$pub.Source+'` のlocked・workspace全target／全feature check／Clippy、Sema全feature doctest 2件、owner Clippy、workspace fmt check、canonical構造gateを今回実行した（review trigger 396・blocking 0）。step前後のcommit／tree／tracked差分0、変更13 pathのbyte pin・公開blobを照合した。警告と開発時のcompile失敗を原本に保持する。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanは9:08の終了0を履行済みとして維持し、今回は再実行していない。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持し、今回は未実行。Tier 2、新しい再帰本体のNative／AWBC・Native／Web受入は今回のhost検証から主張しない。[今回の原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
foreach($name in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($name)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row is not unique'}
    $replacement=$rows[$name]
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
if(@(Compare-Object -CaseSensitive $before.GenericMatchRow @(Get-Content $statusPath|Where-Object {$_.StartsWith('| Generic Match')})).Count){throw 'Accepted Generic Match changed'}
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
if((Get-Item $historyPath).Length -ne $before.HistoryBytes -or (Get-FileHash $historyPath -Algorithm SHA256).Hash -cne $before.HistorySHA256){throw 'History prefix changed'}
$addition=@'

## Scoped effect row functions

2026-11-13。Source `1914f17ba506ea591ed49cd5690bc31c27b332d3`、tree `be0f851d2cbaae549a16f4ab2a71f8cfb549d473`、親・変更基点 `334a0ee7decbbe741de71703cc289fec48e3c4fc`。既存mainで通常commit／non-forced pushし、変更13 blobを照合した。50件の限定PASS後に公開し、引数検査の集合lookupを維持した最終Sourceで全owner／consumer／品質を検証した。未追跡 `%SystemDrive%/` は保持した。

PreparedEffectGraphの単一function registryに、実宣言のschemeと、導入時の依存引数だけを持つUnknownを区別して保持する。unknownに宣言domainや本体式を作らず、共同のcell集合と既存のprincipal completionを使う。Application、同時置換、canonical replay、rollbackを同じgrammarへ移行した。宣言headerの不変なleaseは維持する。scope付きの条件はDとCを別々に保持し、双方をwhole有限行の命題としてcompileしてD⇒Cを作り、その後に当該scopeの形式引数を∀量化する。すべての行関数を共同で最小化し、内外を順に最小化する処理は入れていない。独立したcanonical replayでも新しい条件を確認する。

新9件は、内側e(F)=Fの受理、外側x=Fの拒否、{a}∩F⊆xの一様最小解x={a}、x∪y(F)={a}の比較不能解の拒否、whole-rowで偽のDと真のDの区別、実再帰schemeとunknownの共同closure・具体的なapplication、rollbackの条件破棄とidentity非再利用・別issuer拒否、予算不足・重複依存・arityの原子拒否を確認する。既存41件を含む限定50件はPASS。最初のcompileではローカル変数名がfunction定義を隠していたE0599を修復し、失敗logを保持した。元のbudget、候補数、probe／replay、取消し条件は変更していない。

最終Sourceの全feature Sema lib／testsは1,678件中1,672 PASS／6 FAIL／0 SKIP、@@SECONDS@@秒。5 binaryの選択と終端が全IDで一致・重複0。前回Source `6c515904c38bda8228f5839eb5053f54a2804963` の1,669 IDをすべて維持し、新9件はPASS。失敗IDと実診断は前回と同じ5 ExpressionCycle／1 PendingCallableEffectProjectionである。同じSourceの他21 package・既定feature・規定107 targetは2,510 ID、2,507 PASS／2 FAIL／1 SKIP、選択と終端が一致・重複0。Compilerの既知2失敗は同じflow_wait IDとExpressionCycle（slot 17／19）。3 targetはcompile-only。CLI226件とCompiler callable_execution376件はPASS。Cargo入力差分0を確認し22 packageのgraphを再利用、実行結果は新規採取した。

locked workspace全target／全feature check／Clippy、Sema全feature doctest 2件、owner Clippy、workspace fmt check、canonical構造gateは終了0。各stepのSource／tree／tracked差分0と変更13 pathのbyte pin・公開blobを照合した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。警告を保持した。構造gateは98 package・3,492 files・3,361 Rust files・1,895,271 Rust physical LOC、review trigger396・blocking0。合計成長574 physical LOCのうち、新functions module140、scoped module37、専用test302 LOC。所有者レビュー: registryとintroduction dependencyは既存の準備済み数学層、scope付き条件はその同じgraphの条件集合であり、別solver・source walker・権限catalogを作らない。既存closure／compilation／canonical replayを利用し、型ownerや外部APIへ責務を移さない。Semaの依存fan-in／out 8／15、dev4／0は変わらない。各pathのbytes・LOC・基点差を原本へ保持した。

このcutは、全unknownが今回の共同最小化に参加する数学的な入口を閉じた。futureを未解決の行関数として残すscope付き条件付きcompletion、元Γからのchecked primitive／計算済み行seal、型ownerの実frameへの接続、frontendの本体一回準備と最終sealは継続する。既知の再帰本体6＋2失敗の修復、Native／AWBC・Native／Webの追加受入とはしない。現状一覧の長い実装経緯を現在の責務と境界へ整理した理由は、この新旧基盤と未接続範囲を混同しないためである。以前の実測・full SHAは履歴と原本を保持し、Generic Match・caller-bound recursion・共有prefix・完了値capture・header portの既受入を戻さない。全体cargo cleanは9:08の履行を維持し、今回再実行していない。

[実装・検証原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)は@@ENTRIES@@ entry、展開時@@RAW_BYTES@@ bytes、ZIP @@ZIP_BYTES@@ bytes、SHA-256 `@@ZIP_SHA@@`。manifestと全entryの長さ・hash・portable pathを読み戻して照合した。
'@
$addition=$addition.Replace('@@SECONDS@@',$owner.ExecutionSeconds.ToString('F3',[Globalization.CultureInfo]::InvariantCulture)).Replace('@@ENTRIES@@',[string]$archive.Entries).Replace('@@RAW_BYTES@@',[string]$archive.RawBytes).Replace('@@ZIP_BYTES@@',[string]$archive.ZIPBytes).Replace('@@ZIP_SHA@@',$archive.SHA256.ToLowerInvariant()).Replace("`r`n","`n")+"`n"
[IO.File]::AppendAllText($historyPath,$addition,[Text.UTF8Encoding]::new($false))
$bytes=[IO.File]::ReadAllBytes($historyPath)
$prefix=[byte[]]::new([int]$before.HistoryBytes)
[Array]::Copy($bytes,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -cne $before.HistorySHA256){throw 'History prefix differs'}
git diff --check
if($LASTEXITCODE -ne 0){throw 'Documentation whitespace failed'}
