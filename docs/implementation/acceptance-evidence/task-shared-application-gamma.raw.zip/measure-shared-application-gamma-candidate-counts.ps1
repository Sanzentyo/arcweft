param([string]$Label,[string]$Binary)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$env:PATH=(Split-Path -Parent (uv python find 3.11 --no-project --offline).Trim())+';'+$env:PATH
$test='final_analysis::tests::t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once'
$script=Join-Path $d 'shared-application-gamma.final-candidate-counts.lldb'
$exe=(Resolve-Path -LiteralPath $Binary).Path
$sha=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
$log=Join-Path $d "$Label-candidates.lldb.log"
$start=(Get-Date).ToString('o')
& lldb --batch -s $script -- $exe --exact $test --nocapture *> $log
$code=$LASTEXITCODE
$starts=@(Select-String -LiteralPath $log -Pattern 'frame #0: .*prepare_resolved_candidates.*calls.rs:2417$').Count
$finished=@(Select-String -LiteralPath $log -Pattern 'frame #0: .*prepare_resolved_candidates.*calls.rs:2522$').Count
$failed=@(Select-String -LiteralPath $log -Pattern '^test result: FAILED\.|CallResolutionFailed' | ForEach-Object Line)
[ordered]@{version=1;test=$test;binary=$exe;sha256=$sha;started=$starts;finished=$finished;terminal_lines=$failed;lldb_exit=$code;began_at=$start;observed_at=(Get-Date).ToString('o')} | ConvertTo-Json -Depth 6 | Tee-Object -FilePath (Join-Path $d "$Label-candidates.json")

