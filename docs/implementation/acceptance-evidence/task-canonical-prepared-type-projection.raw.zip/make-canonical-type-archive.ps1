$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$publication=Get-Content -Raw -LiteralPath "$root\canonical-type.publication.json"|ConvertFrom-Json
$pin=Get-Content -Raw -LiteralPath "$root\canonical-type.final-input.json"|ConvertFrom-Json
$receipt=Get-Content -Raw -LiteralPath "$root\canonical-type.focused-receipt.json"|ConvertFrom-Json
$quality=Get-Content -Raw -LiteralPath "$root\canonical-type.quality.json"|ConvertFrom-Json
if($receipt.RunExit -ne 0 -or $receipt.Selected -ne 71 -or $quality.Tree -ne $publication.Tree -or $quality.ClippyExit -ne 0 -or $quality.FmtExit -ne 0 -or -not $publication.SelectedIdsEqualTerminal){throw 'Evidence incomplete'}
if(@(git -C 'D:\git\arcweft' diff --name-only 518d63e31dd2be9750158004b171a6174b2725a7 -- Cargo.toml Cargo.lock .cargo rust-toolchain.toml ':(glob)**/Cargo.toml').Count -ne 0){throw 'Cargo graph inputs changed'}
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Owner='arcweft-lang-sema::types::effect_domain::prepared::canonical';Measurements=$pin.Sources;Responsibility='One algebra adapter borrows principal effects and the original type-projection control. All structural traversal, binders, constants, payloads and rebuilding remain in the existing shared TypeKind fold.';Authority='Canonical annotations, including unknown authored rows, retain their meaning. Live terms require unconditional invariant pointwise observations. No checked type, scope-admission, annotation-completion or selected-call certificate is issued.';Failure='Original control abort, instantiation error and malformed/non-total/nonpointwise effects remain distinct. Input graph and type are immutable; no partial result is published.';GrowthReview='New 317-LOC child tests follow this projection owner: nested type/const/effect/predicate contracts, unknown versus live rows, representability, foreign/stale authority, inclusive budget and cancellation. No unrelated fixture/backend, extra type grammar, production visibility widening for physical splitting, dependency or I/O boundary.';GraphSource='d20f11a7fa9762662df0cdbbe042670207b0177b';GraphArchiveSHA256='412435c9c1315650bb8177d1e69135cc0612725177013e31b8b16b16fe2d7398';ClosurePackages=22;CargoInputsUnchanged=$true;Selection='71 all-feature private preparation/math/type/schema/component tests plus Sema all-target/all-feature Clippy and workspace fmt';ReusedEvidence='Full Sema 1563/1557 pass/6 fail and structure blocking 0 remain at source 72fcdc6c0c13315bd909db8182a4183f0e6b0092. No full-owner, consumer, workspace check/Clippy, structure, Wasm, doctest or Compiler rerun claimed here.';NewTests=5;BudgetsRelaxed=0;DependenciesChanged=0;VersionMarkersChanged=0}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$root\canonical-type.scope-and-ownership.json" -Encoding utf8
$files=[Collections.Generic.List[object]]::new()
Get-ChildItem -LiteralPath $root -File|Where-Object {
    ($_.Name.StartsWith('canonical-type.') -or $_.Name -eq 'make-canonical-type-archive.ps1') -and
    $_.Name -notin @('canonical-type.manifest.json','canonical-type.archive.json','canonical-type.docs-audit.json','canonical-type.docs-publication.json')
}|Sort-Object Name|ForEach-Object {$files.Add(@{name=$_.Name;path=$_.FullName})}
$manifest=[ordered]@{
    version=1;source=$publication.Source;tree=$publication.Tree;base=$publication.Parent
    phases=@(
        @{name='initial-owner-check';exit=0;note='All-target/all-feature check before new tests. Source hash inventory, tracked patch and byte-exact new adapter retained.'},
        @{name='initial-test-check';exit=101;selected=0;note='One nonexistent Formula-to-EffectRow conversion in a test produced two E0277 diagnostics. Replaced with the existing open-row constructor; no production API or assertion weakened. Source snapshots and diagnostics retained.'},
        @{name='final-selection';selected=71;passed=71;failed=0;selectedOut=1473;exit=0;seconds=4.653;note='Five new canonical projection tests are explicitly selected; selected/terminal IDs agree with no duplicates.'}
    )
    commands=@('CARGO_INCREMENTAL=0 cargo nextest list --locked -p arcweft-lang-sema --lib --all-features -E [filter in receipt] --message-format json','CARGO_INCREMENTAL=0 cargo nextest run --locked -p arcweft-lang-sema --lib --all-features -E [filter in receipt] --no-tests fail --no-fail-fast','CARGO_INCREMENTAL=0 cargo clippy --locked -p arcweft-lang-sema --all-targets --all-features','CARGO_INCREMENTAL=0 cargo fmt --all --check')
    files=@($files|ForEach-Object {$item=Get-Item -LiteralPath $_.path;@{name=$_.name;bytes=$item.Length;sha256=(Get-FileHash -LiteralPath $_.path -Algorithm SHA256).Hash.ToLowerInvariant()}})
}
$manifest|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$root\canonical-type.manifest.json" -Encoding utf8
$files.Add(@{name='manifest.json';path="$root\canonical-type.manifest.json"})
$archivePath='D:\git\arcweft\docs\implementation\acceptance-evidence\task-canonical-prepared-type-projection.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive exists'}
$zip=[IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.path,$file.name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    if($zip.Entries.Count -ne $files.Count){throw 'Entry count mismatch'}
    foreach($file in $files){
        $entry=$zip.GetEntry($file.name);$item=Get-Item -LiteralPath $file.path
        if($null -eq $entry -or $entry.Length -ne $item.Length){throw 'Entry length mismatch'}
        $stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -ne (Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant()){throw 'Entry hash mismatch'}
    }
    $raw=($zip.Entries|Measure-Object Length -Sum).Sum
}finally{$zip.Dispose()}
$archive=Get-Item -LiteralPath $archivePath
@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Entries=$files.Count;RawBytes=$raw;Bytes=$archive.Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();EveryEntryVerified=$true}|ConvertTo-Json|Set-Content -LiteralPath "$root\canonical-type.archive.json" -Encoding utf8
Get-Content -LiteralPath "$root\canonical-type.archive.json"
