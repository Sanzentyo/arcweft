$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/future-effect-functions.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/future-effect-functions.owner-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/future-effect-functions.archive.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/future-effect-functions.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -cne $pub.Source -or @(git diff --name-only HEAD).Count -or $owner.Passed -ne 1678 -or $owner.Failed -ne 6 -or $owner.ConsumerTestsRerun){throw 'Final owner evidence differs'}
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
if((Get-FileHash $statusPath).Hash -cne $before.StatusSHA256){throw 'Current status changed'}
$status=[IO.File]::ReadAllText($statusPath)
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `1914f17ba506ea591ed49cd5690bc31c27b332d3`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。本体内推論の修復を継続** | Native／AWBCの42と各step公開JSON保存復元、完了値ごとのcapture保持・復元、checked sourceのΓ admission、template開放、対応operand portと実scopeの保持を維持する。最新Source `'+$pub.Source+'` の数学層は、宣言schemeと導入時の依存引数を持つ推論行関数を共同で解き、scopeごとのwhole-row D⇒Cと局所∀を保持する。BindableとFutureを区別し、Futureが未解決ならclosureを公開せず、全実値を受け取って新しい効果labelも含めてから共同最小化・独立再検証する。新6件を含む数学層56件が全owner runでPASS。残るのはreify入力の元operand導出への完全移行、checked primitive effect ownerと計算済み行のseal、引数全体の実Γ、future未解決のまま子の解を返す条件付きcompletion／MGU／rankと型ownerへの局所∀接続、frontend prepared value／effect接続・body一回準備・一括sealである。実値が揃った後の入口を、中間の条件付き推論や再帰本体の実行受入とは判定しない。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[checked source](convergence-evidence-history.md#checked-source-value-scope)・[完了値](convergence-evidence-history.md#completed-output-capture-support)・[header port](convergence-evidence-history.md#typed-effect-header-ports)・[共同推論](convergence-evidence-history.md#scoped-effect-row-functions)・[将来値の保持](convergence-evidence-history.md#future-effect-function-specialization)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,678 PASS／6 FAIL。逆依存は直前Sourceの2,507 PASS／2 FAIL／1 SKIPを再利用** | 最新Source `'+$pub.Source+'` の全feature Sema lib／testsは1,684件、'+$owner.ExecutionSeconds.ToString('F3',[Globalization.CultureInfo]::InvariantCulture)+'秒、選択と終端の全ID一致・重複0。直前1,678 IDをすべて維持し、新6件はPASS。既知6失敗のIDと実診断は同じ5 ExpressionCycle／1 PendingCallableEffectProjection。crate内のprepared graphはfinal analysisへ未接続で、今回のowner runがそのschema／type／component consumerを含む。公開API・実行系・fixture・Cargo入力を変えず、他21 package・規定107 targetの結果はSource `1914f17ba506ea591ed49cd5690bc31c27b332d3` の2,510 IDを再利用し、最新Sourceの再実行とはしない。Compiler既知2失敗とslot 17／19もその入力の実測。owner全featureとconsumer既定featureは別sliceである。[最新owner原本](acceptance-evidence/task-future-effect-functions.raw.zip)・[直前の逆依存原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **直前Sourceの規定226件PASSを再利用。全 check は未再実行** | Source `1914f17ba506ea591ed49cd5690bc31c27b332d3`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS、binはcompile済み・runnable test 0件。最新の変更は未接続のcrate内数学層であり、この実行結果を元SHAのまま再利用する。全checkや今回の再実行とは主張しない。以前の入力・件数・失敗は履歴と原本に保持する。[実行原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)・[再利用範囲](convergence-evidence-history.md#future-effect-function-specialization)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新owner check／Clippy・fmt・構造gateは終了0。workspace品質の直前実測を再利用** | Source `'+$pub.Source+'` のlocked Sema全target／全feature check／Clippy、owner fmt check、canonical構造gateを今回実行した（review trigger396・blocking0）。変更9 pathのbyte pin・公開blobと各step前後のSource／tree／tracked差分0を照合。workspace全target／全feature check／Clippy・workspace fmt・Sema doctest 2件はSource `1914f17ba506ea591ed49cd5690bc31c27b332d3` の終了0を再利用する。crate内の未接続数学層への変更であり、公開API・doc実行例・他owner・Cargo入力・toolchain・featuresを維持する。警告と開発時のcompile失敗を原本へ保持した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanは9:08に履行済みで再実行していない。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持する。Tier 2・新しい再帰本体のNative／AWBC・Native／Web受入へ拡張しない。[最新owner原本](acceptance-evidence/task-future-effect-functions.raw.zip)・[直前の品質原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
foreach($name in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($name)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row is not unique'}
    $replacement=$rows[$name]
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
if((Get-Item $historyPath).Length -ne $before.HistoryBytes -or (Get-FileHash $historyPath).Hash -cne $before.HistorySHA256){throw 'History prefix changed'}
$addition=@'

## Future effect function specialization

2026-11-13。Source `72df8edc204aec4009fd04884f8b46dd4dbc5a15`、tree `d08e59a2f8c8eb324e125ff79d5b6af26209bef8`、親・変更基点 `59b57f9fa0cc13ecb91ad8cff3d4933c3f715ac4`。既存mainで通常commit／non-forced pushし、変更9 blobを照合した。前半のSource `1914f17ba506ea591ed49cd5690bc31c27b332d3` の共同推論に続き、FutureとBindableの導入時eligibilityを明示した。未追跡 `%SystemDrive%/` を保持する。

Futureは元のdependency signatureとscope付き条件のままPreparedEffectGraphに残り、実値なしのsolve_principalはUnresolvedFutureを返す。specialize_principalは全Futureの実際の有限行関数を検査してから、実値にだけ現れるlabelも含めてclass集合を作り、既存の共同principal solverへ入る。元graphを書き換えず独立に具体化できる。実値はclosureへ保持してcanonical replayで再検証する。未指定、重複、別issuer、Bindableへの代入、許可されない引数、unknown annotation、作業取消しを型付きで拒否する。実値が揃う前の条件付きMGUはこの入口の完了範囲に含めない。先行label集合のoutside classだけでは、後から来る新labelを一般化できないため、実値を先に集める順序にした。

最終Sourceの全feature Sema lib／testsは1,684件中1,678 PASS／6 FAIL／0 SKIP、72.211秒、slow0。5 binaryの選択と終端が全IDで一致・重複0。前回の1,678 IDをすべて維持し、新6件はPASS。失敗IDと実診断は前回と同じ5 ExpressionCycle／1 PendingCallableEffectProjection。数学層の既存50＋新6件は全owner runでも56 PASS。新labelの保持と独立具体化、パラメーター依存、一様な外側解と局所捕捉の拒否、Futureの実値によるNonPrincipal／Unsatisfiableの区別、入力admissionの原子性を確認した。開発時の構文エラーと存在しないpure constructorのE0599は修復し、失敗logを保持した。budget・候補数・probe／replay・取消し条件を弱めていない。

最新Sourceでlocked owner全target／全feature check／Clippy、owner fmt check、canonical構造gateは終了0。各step前後のSource／tree／tracked差分0と変更9 pathのbyte pin・公開blobを照合した。構造gateは98 package・3,494 files・3,363 Rust files・1,895,729 Rust physical LOC、review trigger396・blocking0。合計成長458 physical LOC。新component150 LOCは元の関数定義・scope条件のcompileを同じ数学ownerへ移し、実値の追加を扱う。専用test244 LOC。別solver、並列の権限catalog、source walker、外部API、依存edge、unsafe、versionを追加しない。CARGO_INCREMENTAL=0、jobs／profile上書きなし。警告を原本へ保持した。

逆依存は調査済みの同じ22 package graphを用いる。変更はcrate内のprepared graphで、final analysisへの接続は未実装、schema／type／component consumerは今回のSema全件に含まれる。公開API・実行系・CLI・fixture・Cargo入力・他ownerを変えていないため、他21 package／規定107 targetの2,510 ID（2,507 PASS／2 FAIL／1 SKIP）はSource `1914f17ba506ea591ed49cd5690bc31c27b332d3` の実行を再利用した。Compiler既知2失敗とExpressionCycle slot 17／19、CLI226 PASS、callable_execution376 PASSもその入力の実測であり、最新Sourceの再実行へ読み替えない。workspace全target／全feature check／Clippy・workspace fmt・Sema doctest2件の同Sourceの終了0も再利用する。公開doc実行例・toolchain・features・該当挙動を変えていない。判定理由と元Source付きreceiptを原本へ保持する。

現状一覧では実値が揃った後の入口と、未解決Futureを含む中間の条件付き推論を区別し、異なるSourceのowner／consumer結果を一つの新規runへ合算しない。元Γからのchecked primitive／計算済み行seal、型ownerの局所∀、条件付きMGU／rank、frontend本体一回準備・最終sealは継続する。既知の再帰本体6＋2失敗、Native／AWBC・Native／Webの追加受入を完了扱いにしない。Generic Match、caller-bound recursion、共有prefix、完了値capture、header portの既受入と、過去の実測・full SHAを保持する。全体cargo cleanは9:08の履行を維持した。

[最新owner原本](acceptance-evidence/task-future-effect-functions.raw.zip)は@@ENTRIES@@ entry、展開時@@RAW_BYTES@@ bytes、ZIP @@ZIP_BYTES@@ bytes、SHA-256 `@@ZIP_SHA@@`。全entryの長さ・hash・portable pathとmanifestを読み戻して照合。[再利用したconsumer／workspace品質原本](acceptance-evidence/task-scoped-effect-functions.raw.zip)のSourceとhashは別に保持する。
'@
$addition=$addition.Replace('@@ENTRIES@@',[string]$archive.Entries).Replace('@@RAW_BYTES@@',[string]$archive.RawBytes).Replace('@@ZIP_BYTES@@',[string]$archive.ZIPBytes).Replace('@@ZIP_SHA@@',$archive.SHA256.ToLowerInvariant()).Replace("`r`n","`n")+"`n"
[IO.File]::AppendAllText($historyPath,$addition,[Text.UTF8Encoding]::new($false))
git diff --check
if($LASTEXITCODE -ne 0){throw 'Documentation whitespace failed'}
