$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '8d30de9388e7fb7d5ed225ae703bac9bcefc5adb'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'prepared-projection-ports.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='ProjectionRequest retains one opened prepared operand and its real occurrence scope instead of a raw authored template. The lower request owner opens templates using the real branch application and mutable graph while preparing the request; a staged edit publishes no request or graph terms after a failed opening. Ordinary requests, transformed results and function-scheme instantiation use the same operand-owned opening API. The callable driver obtains the actual client graph loan and records any graph access failure. Result resolution reuses the registered opened term in the same scope and otherwise uses real prepared lexical transport; it no longer reopens the schema. Final projection finishing has only graph read capability and consumes the retained operand directly. Original forest freezing now retains original source actual/expected query types, projection value/input ports and original equation pattern/actual ports, in addition to binding and selected-original value queries; these are query ports and do not add later-use inference premises. The joint fixture reads its original registered operand instead of reconstructing a template in joint frames. Two new fixtures cover registering an unresolved Named/Future query before the Named body exists, repeated result reads without new terms, final closing with the actual Named body and an explicit nonempty Future row, final read term count unchanged, and late malformed-scope registration rollback. Tests remain unrun because full required Sema target checking fails. The dev02 private-field test error is repaired through the existing narrow projection API without widening private visibility. Old graph/closure fixture callers and final transaction for_path completion, the original forest to materialization bridge, frontend public switch, Fn-local quantified/guarded semantics and complete body-once acceptance remain unfinished. This is a user-authorized WIP checkpoint, not source or workspace acceptance. Growth is owned by the existing request/operand/original-freeze responsibilities, with meaningful tests in a child module. No parallel semantic catalog, fabricated source, empty missing Future substitution, legacy reader, body replay or new canonical identity path is added. Existing accepted Generic Match and runtime results remain accepted. Repeated value copying and complete allocation/copy preflight or performance have not been accepted. Cargo dependency/features, facade, layers, I/O, unsafe, codec/version, production budgets, jobs and profile are unchanged; valid resolved graph and reverse dependency evidence is reused. LOC, bytes, path/test classification and named inline test size are measured below, not used as source-spelling acceptance.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'prepared-projection-ports.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'prepared-projection-ports.'+$iteration+$suffix}})
$names+=@('prepared-projection-ports.source-publication.json','prepared-projection-ports.ownership-review.json','prepared-projection-ports.staged-review.json','prepared-projection-ports.dev03-diagnostic-review.json')
$names+=@('run-prepared-projection-ports-check.ps1','archive-prepared-projection-ports.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-prepared-projection-ports-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-prepared-projection-ports-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'prepared-projection-ports.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
