$ErrorActionPreference='Stop'
$r=$PSScriptRoot
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$g=Read-Record 'view-placeholder-20261108.graph.json'
$current=Read-Record 'view-placeholder-integrated-20261108.noncli-r2.catalog.inventory.json'
$previous=Read-Record 'ime-purpose-enter-key-integrated-20261108.noncli.catalog.inventory.json'
$owner=Read-Record 'view-placeholder-20261108.owner-r3.catalog.inventory.json'
function Case-Key($row){$row.binary+'::'+$row.test}
$selected=@($current.rows|Where-Object status -eq 'matches')
$keys=@($selected|ForEach-Object {Case-Key $_})
$prior=@($previous.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $g.packages.name})
$priorKeys=@($prior|ForEach-Object {Case-Key $_})
$missing=@(foreach($row in $prior){$key=Case-Key $row;if($key -notin $keys){$key}})
$new=@($keys|Where-Object {$_ -notin $priorKeys})
$required=@($owner.rows|Where-Object status -eq 'matches'|ForEach-Object {Case-Key $_})+@('arcweft-render-wgpu::geometry_runtime_control_styles::label_is_never_painted_as_placeholder_and_nonempty_value_wins')
$requiredMissing=@(foreach($key in $required){if(@($keys|Where-Object {$_ -ceq $key}).Count -ne 1){$key}})
$duplicates=@($keys|Group-Object|Where-Object Count -ne 1)
if($missing.Count -or $requiredMissing.Count -or $duplicates.Count -or $new.Count -ne 5){throw 'Coverage differs from prior closure and five new cases'}
$record=[ordered]@{version=1;production='84bcb1647b6453d43c79e57ae5431e886cc4db59';selected=$selected.Count;runtimePackages=@($selected.package|Sort-Object -Unique).Count;priorClosureCases=$prior.Count;priorMissing=$missing;newCases=$new;required=$required;requiredMissing=$requiredMissing;duplicates=$duplicates;note='Prior all-feature inventory projected through the current Cargo reverse closure. Every prior case remains selected, plus five new cases. Owner repetitions are not added to fresh totals.'}
$record|ConvertTo-Json -Depth 12|Set-Content "$r/view-placeholder-integrated-20261108.coverage-review.json" -Encoding utf8
$record|ConvertTo-Json -Depth 12
