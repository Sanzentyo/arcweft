param([string]$CliStem='view-placeholder-integrated-20261108.cli')
$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$log="$CliStem.runtime.log"
$lines=@(Get-Content "$r/$log")
$ids=@('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering','spec_valid_run_edge_fixture_now_executes','verify_json_records_required_solver_checks','verify_json_reports_missing_promotion_proof')
$rows=@(foreach($id in $ids){
    $indices=@(for($i=0;$i -lt $lines.Count;$i++){if($lines[$i] -match '^\s+FAIL' -and $lines[$i].Contains($id)){$i}})
    if(!$indices.Count){throw 'Expected failure block missing'}
    $start=$indices[0];$end=$lines.Count
    for($i=$start+1;$i -lt $lines.Count;$i++){if($lines[$i] -match '^\s+(PASS|FAIL|SKIP|SLOW)\s+\['){$end=$i;break}}
    $block=@($lines|Select-Object -Skip $start -First ($end-$start))
    $text=$block -join [Environment]::NewLine
    if($id -like 'agent_observe*'){
        if(!$text.Contains('shared callable resolution failed') -or !$text.Contains('slot: 15, kind: Expr')){throw 'Scroll diagnostic changed'}
        $cause='sema.final_analysis shared callable resolution, expression slot 15'
    }elseif($id -eq 'spec_valid_run_edge_fixture_now_executes'){
        if(!$text.Contains('active dialogue has no voice')){throw 'Voice diagnostic changed'}
        $cause='active dialogue has no voice'
    }else{
        if(!$text.Contains('"stage": "type-check"') -or !$text.Contains('slot: 8, kind: Expr }) has no admissible final type')){throw 'Promotion diagnostic changed'}
        $cause='type-check denied: sema.final_analysis, expression slot 8 has no admissible final type; solver phase was not reached'
    }
    [ordered]@{binary='arcweft-cli::check';test=$id;observedCause=$cause;logStartLine=($start+1);firstLines=@($block|Select-Object -First 38);diagnosticLines=@($block|Where-Object {$_ -match 'sema\.final_analysis|shared callable|has no admissible final type|active dialogue has no voice|"stage": "type-check"'})}
})
[ordered]@{version=1;production='84bcb1647b6453d43c79e57ae5431e886cc4db59';inspectedHead='58ab00be89f2ee19242e39d66fe71b072f49a443';log=$log;failureDiagnostics=$rows;note='Actual raw diagnostic blocks are checked for the same cause and exact expression coordinate as the preceding accepted record. Final failure IDs are compared independently with terminal audits.'}|ConvertTo-Json -Depth 14|Set-Content "$r/view-placeholder-integrated-20261108.failure-diagnostics.json" -Encoding utf8
$rows|ForEach-Object {[pscustomobject]@{test=$_.test;cause=$_.observedCause}}|ConvertTo-Json
