param([string]$CliStem='view-placeholder-integrated-20261108.cli')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$stem="$r/view-placeholder-integrated-20261108.cli-source-probe"
if(Test-Path ($stem+'.json')){throw 'Probe receipt exists'}
$main=Get-Content "$r/$CliStem.main-before.json" -Raw|ConvertFrom-Json
$manifest="$r/view-placeholder-probe/arcw.toml"
$source="$r/view-placeholder-probe/src/main.arcw"
$paths=@($main.path,$manifest,$source)
$before=@(foreach($path in $paths){[pscustomobject]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
if($before[0].sha256 -ne $main.sha256){throw 'Actual CLI differs from the integrated run'}
$started=[DateTime]::UtcNow.ToString('o')
& $main.path check --manifest-path $manifest --json *> ($stem+'.log')
$code=$LASTEXITCODE
foreach($row in $before){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Probe source or executable drift'}}
$report=Get-Content ($stem+'.log') -Raw|ConvertFrom-Json -Depth 80
[ordered]@{version=1;production='84bcb1647b6453d43c79e57ae5431e886cc4db59';inspectedHead=(git rev-parse HEAD).Trim();command=@($main.path,'check','--manifest-path',$manifest,'--json');sourceSha256=$before[2].sha256;manifestSha256=$before[1].sha256;exitCode=$code;status=$report.status;mainExecutableSha256=$before[0].sha256;binaryDrift=0;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Actual CLI type-check of mounted retained String input and named Action handlers, authored targets, typed IME hints and a distinct dynamically evaluated placeholder. Not an additional nextest case or Native/Web capture.'}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.json') -Encoding utf8
if($code -ne 0 -or $report.status -ne 'ok'){throw 'Actual CLI placeholder probe failed'}
Get-Content ($stem+'.json') -Raw
