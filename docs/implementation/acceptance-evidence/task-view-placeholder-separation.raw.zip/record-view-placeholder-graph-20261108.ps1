$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
& cargo metadata --locked --all-features --format-version 1 1> "$r/view-placeholder-20261108.metadata.json" 2> "$r/view-placeholder-20261108.metadata.log"
if($LASTEXITCODE -ne 0){throw 'Cargo metadata failed'}
$m=Get-Content "$r/view-placeholder-20261108.metadata.json" -Raw|ConvertFrom-Json -Depth 100
$root=@($m.packages|Where-Object name -eq 'arcweft-view')
if($root.Count -ne 1){throw 'Missing exact View owner'}
$closure=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
[void]$closure.Add($root[0].id)
do {
    $changed=$false
    foreach($node in $m.resolve.nodes){
        if(!$closure.Contains($node.id) -and @($node.dependencies|Where-Object {$closure.Contains($_)}).Count){$changed=$closure.Add($node.id) -or $changed}
    }
}while($changed)
$packages=@($m.packages|Where-Object {$_.id -in $m.workspace_members -and $closure.Contains($_.id)}|Sort-Object name|Select-Object name,id)
$owners=@('arcweft-view','arcweft-bundle','arcweft-lang-sema','arcweft-compiler','arcweft-runtime-driver','arcweft-player-scene','arcweft-render-wgpu')
if(@($owners|Where-Object {$_ -notin $packages.name}).Count){throw 'Changed production owner outside closure'}
$record=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();metadata='view-placeholder-20261108.metadata.json';metadataSha256=(Get-FileHash "$r/view-placeholder-20261108.metadata.json").Hash.ToLowerInvariant();workspacePackages=$m.workspace_members.Count;owners=$owners;selection='rdeps(=arcweft-view)';packages=$packages;packageCount=$packages.Count;nonCliFeaturePoint='workspace except CLI, all features, lib/tests';cliFeaturePoint='CLI defaults, lib/tests; actual main executable pinned in place'}
$record|ConvertTo-Json -Depth 8|Set-Content "$r/view-placeholder-20261108.graph.json" -Encoding utf8
$record|Select-Object version,base,workspacePackages,packageCount,selection|ConvertTo-Json
