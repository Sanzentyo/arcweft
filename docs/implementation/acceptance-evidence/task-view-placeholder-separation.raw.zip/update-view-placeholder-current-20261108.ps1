$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$a=Read-Record 'view-placeholder-20261108.acceptance-record.json'
$oracle=Read-Record 'view-placeholder-20261108.oracle.verified.json'
$n=Read-Record 'view-placeholder-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
$c=Read-Record 'view-placeholder-integrated-20261108.cli.runtime.terminal-audit.json'
$first=Read-Record 'view-placeholder-integrated-20261108.noncli.runtime.terminal-audit.json'
$coverage=Read-Record 'view-placeholder-integrated-20261108.coverage-review.json'
$lines=[Collections.Generic.List[string]]::new()
foreach($line in (Get-Content 'docs/implementation/current-status.md')){[void]$lines.Add($line)}
function Replace-Row([string]$prefix,[string]$replacement){
    $indices=@(for($i=0;$i -lt $lines.Count;$i++){if($lines[$i].StartsWith($prefix)){$i}})
    if($indices.Count -ne 1){throw ('Current row is not unique: '+$prefix)}
    $lines[$indices[0]]=$replacement
}
Replace-Row '確認日 ' ('確認日 2026-11-08、観察Source `'+$oracle.commit+'`。項目ごとの受入・公開Sourceと検証範囲を下表で独立して追跡する。実装と描画test訂正は公開済みで、tracked実装WIPは0。4 actual untrackedのローカルcacheは保持している。')
Replace-Row '| View の保持 String 入力／公開target・IME hint |' ('| View の保持 String 入力／公開target・IME hint・placeholder | **保持入力・target・hintの受入を維持。placeholderとlabelの分離を検証・公開済み** | 実装Source `84bcb1647b6453d43c79e57ae5431e886cc4db59`、描画test訂正 `'+$oracle.commit+'`。名前付き `placeholder = String式` とlabelを記述順のtyped programとして保持し、重複roleと不正ABIを拒否する。3種の入力欄で動的更新・空値submit・実AWFB・cold restore・古いsession拒否を検証。labelはsemantic名、placeholderは空値の描画hintとStyle状態だけに使い、旧補完・混同経路を削除した。評価エラーの順序とsemantic replacement、描画色・spacing・入力geometryも確認。横断件数と品質は下表へ集約する。旧sample移行・Scroll fixture・実Native／Web表示は別の継続条件。[途中の失敗・訂正理由・全SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
Replace-Row '| 共有契約／推移的逆依存matrix |' ('| 共有契約／推移的逆依存matrix | **新規'+$a.executed+'実行：'+$a.passed+' PASS／'+$a.failed+' FAIL／'+$a.skipped+' SKIP** | 最終Source `'+$oracle.commit+'`。View逆依存41 packageの非CLI全feature lib／testsは'+$n.executed+'／'+$n.passed+' PASS・'+$n.skipped+' SKIP、CLI既定は下行。先行の同じ範囲'+$coverage.priorClosureCases+'件は欠落0、追加5件も各1回・重複0。3900入力とCLI3924入力、catalog・実EXEの差分0。新規2 run／2 feature pointで、初回の描画assertion失敗、owner反復、先行10246件は加算しない。初回失敗と修正後の全件runを両方保持する。[終端・選択・失敗・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
Replace-Row '| CLIの規定対象／全 check 照合 |' ('| CLIの規定対象／全 check 照合 | **placeholder修復後のCLI既定'+$c.executed+'件：'+$c.passed+' PASS／'+$c.failed+' FAIL／'+$c.skipped+' SKIP** | 最終Source `'+$oracle.commit+'`。先行と同じ4失敗ID・実診断で、新規失敗0。Scrollのshared callable拒否、active dialogue has no voice、promotion2件のsolver到達前type-check拒否は未解消。実CLI本体とtest binaryを元pathで前後照合し、公開target・保持入力・named Action・typed IME hint・動的placeholderを含むSource checkも終了0／status ok。既受入は維持する。[診断・Source・EXE pin・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
Replace-Row '| workspace check／Clippy・fmt・構造gate |' ('| workspace check／Clippy・fmt・構造gate | **placeholder実装の全workspace gateと描画test訂正の対象gateは終了0** | 実装Source `84bcb1647b6453d43c79e57ae5431e886cc4db59` の全98 package・全target・全feature・locked check／Clippy、canonical構造gate、変更25 Rust pathのfmtが終了0、3900入力drift0（警告あり）。後続1 test fileだけの訂正は対象Clippy／fmtと描画owner、全逆依存で確認した。View-ownedの順序付きroleからBundle／driver／scene／rendererへ伝搬し、並行order table・旧reader・source再構成は追加しない。Cargo依存／feature／unsafe／version marker変更0。platform／Tier2／表示parityの最終受入とは区別する。[品質・責任レビュー・原本](acceptance-evidence/task-flow-registry-execution.json)。 |')
[IO.File]::WriteAllLines((Join-Path (Get-Location) 'docs/implementation/current-status.md'),$lines,[Text.UTF8Encoding]::new($false))
$history=@'

## 2026-11-08 — placeholderとアクセシビリティ名の分離

実装Sourceは `84bcb1647b6453d43c79e57ae5431e886cc4db59`、描画testだけの訂正は `{{ORACLE}}`。
Viewの順序付きtyped roleをSource／AWFB／driverへ通し、controlのlabelとplaceholderを別に保持する。
静的placeholderをlabelへ補完する経路と、labelをplaceholderとして描く経路を削除した。
3種の入力欄、動的再評価、空値submit、cold restore、stale session、実行エラーの記述順、semantic replacementを検証した。

初回dev checkの不存在フィールド参照とowner準備のtest child path誤りは、実行前の失敗として保持する。
owner-r2は4件中2 PASS／2 FAIL。Stringの加算を使ったfixtureは既存plannerの未対応演算だったため型付き条件式へ訂正し、
製品の重複roleをAWBC接続前に通していた実不具合は構造admissionへ移した。owner-r3は4／4 PASS。
初回consumer runは{{FIRST_EXECUTED}}件中{{FIRST_PASSED}} PASS／{{FIRST_FAILED}} FAIL。追加assertionが表示glyphの範囲と入力値のoffsetを混同していた。
訂正後は表示範囲を保持したまま、実際のfocused IME geometryが空の保持値だけを指すことを検証する。色・spacing・semantic名のassertionも維持した。
製品実装は変更せず、訂正した描画ownerと全逆依存を再実行した。途中の失敗を最終PASSへ上書きしない。

最終の新規2 runは{{EXECUTED}}実行／{{PASSED}} PASS／{{FAILED}} FAIL／{{SKIPPED}} SKIP。
View逆依存の非CLI全feature {{NONCLI}}件とCLI既定{{CLI}}件を区別し、owner反復・失敗run・先行10246件は加算しない。
先行の同じclosure {{PRIOR}}件は欠落0、追加5件も重複0。CLIの4失敗IDと実診断は先行と同じである。

現状一覧の「placeholder等の旧sample移行」は、機能自体の未実装とsample移行を混同するため、今回の受入と旧sample・Scroll・実表示の継続条件へ分離した。
旧IME Sourceの10246件と全SHAは元registryの履歴として保持し、異なるSourceの件数を現在の新規runとして重複掲載しない。
Generic Matchと既受入のbounded cutは変更していない。全体goalの未達による再開も行わない。

原本は `acceptance-evidence/task-view-placeholder-separation.raw.zip`（{{ENTRIES}} entry、{{BYTES}} bytes、SHA-256 `{{RAW_SHA}}`）。
実行ファイル・AWFBは含めず、実EXEは元pathのhashで照合した。詳細は `acceptance-evidence/task-flow-registry-execution.json` の `viewPlaceholderSeparation`。
'@
$values=@{ORACLE=$oracle.commit;FIRST_EXECUTED=$first.executed;FIRST_PASSED=$first.passed;FIRST_FAILED=$first.failed;EXECUTED=$a.executed;PASSED=$a.passed;FAILED=$a.failed;SKIPPED=$a.skipped;NONCLI=$n.executed;CLI=$c.executed;PRIOR=$coverage.priorClosureCases;ENTRIES=$a.raw.entries;BYTES=$a.raw.bytes;RAW_SHA=$a.raw.sha256}
foreach($key in $values.Keys){$history=$history.Replace(('{{'+$key+'}}'),[string]$values[$key])}
if($history.Contains('{{')){throw 'Unresolved history field'}
Add-Content 'docs/implementation/convergence-evidence-history.md' $history -Encoding utf8
Write-Output 'Updated one current ledger and appended the measured history.'
