$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$freeze=Get-Content "$r/view-placeholder-20261108.oracle-owner-r2.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Oracle source drift: '+$row.path)}}}
Assert-Inputs
& cargo clippy --locked -p arcweft-render-wgpu --test geometry_runtime_control_styles --all-features *> "$r/view-placeholder-20261108.oracle-clippy.log"
$clippy=$LASTEXITCODE
Assert-Inputs
& rustfmt --check --edition 2024 --config skip_children=true crates/arcweft-render-wgpu/tests/geometry_runtime_control_styles.rs *> "$r/view-placeholder-20261108.oracle-fmt.log"
$fmt=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$freeze.base;paths=@('crates/arcweft-render-wgpu/tests/geometry_runtime_control_styles.rs');clippyExitCode=$clippy;fmtExitCode=$fmt;sourceInputs=$freeze.paths.Count;sourceDrift=0;scope='Only one renderer test file changed after the full 98-package workspace quality run; product implementation, Cargo graph and structure ownership are unchanged.'}|ConvertTo-Json -Depth 8|Set-Content "$r/view-placeholder-20261108.oracle-quality.json" -Encoding utf8
if($clippy -ne 0 -or $fmt -ne 0){throw 'Oracle quality failed'}
