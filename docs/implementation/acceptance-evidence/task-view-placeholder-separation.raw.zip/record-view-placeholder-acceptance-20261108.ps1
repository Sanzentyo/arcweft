param([string]$CliStem='view-placeholder-integrated-20261108.cli')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$source=Read-Record 'view-placeholder-20261108.source.verified.json'
$oracle=Read-Record 'view-placeholder-20261108.oracle.verified.json'
$owner=Read-Record 'view-placeholder-20261108.owner-r3.runtime.terminal-audit.json'
$noncli=Read-Record 'view-placeholder-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
$cli=Read-Record "$CliStem.runtime.terminal-audit.json"
$main=Read-Record "$CliStem.main-audit.json"
$probe=Read-Record 'view-placeholder-integrated-20261108.cli-source-probe.json'
$coverage=Read-Record 'view-placeholder-integrated-20261108.coverage-review.json'
$quality=[ordered]@{}
foreach($name in @('check','clippy','structure','fmt')){$quality[$name]=Read-Record "view-placeholder-20261108.quality.$name.receipt.json";if($quality[$name].exitCode -ne 0){throw 'Required quality check failed'}}
if($oracle.commit -ne (git rev-parse HEAD).Trim() -or $owner.passed -ne 4 -or $noncli.failed -ne 0 -or $cli.executed -ne 711 -or $cli.failed -ne 4 -or $probe.exitCode -ne 0 -or $probe.status -ne 'ok' -or $probe.mainExecutableSha256 -ne $main.sha256 -or $coverage.requiredMissing.Count){throw 'Acceptance scope differs'}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'viewPlaceholderSeparation'){throw 'Acceptance record exists'}
$oldIds=@($prior.viewImeInputPolicyConsumers.cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)
$newIds=@($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)
$failureDiff=@(Compare-Object $oldIds $newIds)
if($failureDiff.Count){throw 'CLI failure set changed'}
$raw=@(Get-ChildItem -LiteralPath $r -File -Filter 'view-placeholder*'|Where-Object Extension -ne '.pathspec')+@(
    (Get-Item "$r/run-view-placeholder-quality-20261108.ps1"),
    (Get-Item "$r/run-view-placeholder-oracle-quality-20261108.ps1"),
    (Get-Item "$r/update-view-placeholder-current-20261108.ps1"),
    (Get-Item "$r/record-view-placeholder-graph-20261108.ps1"),
    (Get-Item "$r/audit-view-placeholder-coverage-20261108.ps1"),
    (Get-Item "$r/audit-view-placeholder-cli-failures-20261108.ps1"),
    (Get-Item "$r/run-view-placeholder-source-probe-20261108.ps1"),
    (Get-Item "$r/run-retained-input-frozen-matrix-20261108.ps1"),
    (Get-Item "$r/run-retained-input-cli-main-20261108.ps1"),
    (Get-Item "$r/audit-nextest-final-result.ps1"),
    (Get-Item $PSCommandPath))
$archive='docs/implementation/acceptance-evidence/task-view-placeholder-separation.raw.zip'
if(Test-Path $archive){throw 'Raw archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{
    foreach($file in ($raw|Sort-Object FullName -Unique)){
        if($file.Extension -notin @('.log','.json','.patch','.txt','.ps1')){throw ('Unexpected raw file: '+$file.Name)}
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    foreach($file in (Get-ChildItem "$r/view-placeholder-20261108.structure-report" -File)){
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('structure/'+$file.Name),[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
    foreach($p in @('arcw.toml','src/main.arcw')){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,"$r/view-placeholder-probe/$p",('probe/'+$p),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|dll|rlib|rmeta|pdb|awfb)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$entry=[ordered]@{
    version=1;date='2026-11-08';sourcePublication=$source;oraclePublication=$oracle;owner=$owner;nonCli=$noncli;cli=$cli;mainExecutable=$main;cliSourceProbe=$probe
    freshUniqueExecuted=($noncli.executed+$cli.executed);passed=($noncli.passed+$cli.passed);failed=($noncli.failed+$cli.failed);skipped=($noncli.skipped+$cli.skipped)
    graph=(Read-Record 'view-placeholder-20261108.graph.json');coverage=$coverage;quality=$quality;structureReview=(Read-Record 'view-placeholder-20261108.structure-review.json')
    observedCliDiagnostics=(Read-Record 'view-placeholder-integrated-20261108.failure-diagnostics.json');cliFailureIdChanges=$failureDiff
    initialDevelopmentCheck=(Read-Record 'view-placeholder-20261108.dev-check-r1.json');initialOwnerPreparation=(Read-Record 'view-placeholder-20261108.owner-r1.catalog.json');initialOwnerRun=(Read-Record 'view-placeholder-20261108.owner-r2.runtime.terminal-audit.json')
    initialConsumerRun=(Read-Record 'view-placeholder-integrated-20261108.noncli.runtime.terminal-audit.json');initialOracleOwner=(Read-Record 'view-placeholder-20261108.oracle-owner.runtime.terminal-audit.json');oracleOwner=(Read-Record 'view-placeholder-20261108.oracle-owner-r2.runtime.terminal-audit.json');oracleQuality=(Read-Record 'view-placeholder-20261108.oracle-quality.json')
    corrections=@('Initial development check: a new test referenced nonexistent TextInteractionPlan.clusters; corrected to character_bounds. Initial owner catalog: explicit test module child path was missing; corrected before runtime. Neither preparation ran tests.','Owner r2: two of four cases failed. A fixture used String addition unsupported by the existing runtime-plan arithmetic projection; replaced that fixture with an admitted typed conditional expression. The duplicate-role regression exposed validation deferred until AWBC admission; structural uniqueness now belongs to product admission, while actual String result ABI stays at AWBC admission. The unchanged evaluation-order and semantic-replacement cases already passed.','Owner r3 passes all four. The integrated run contains these cases once, plus the new renderer case. Do not add owner repetitions, failed trials, or earlier 10246 executions to the fresh total.')
    consumerOracleCorrection='Initial consumer run retained a new assertion that confused display-glyph source ranges with editor-value ranges. Display text keeps its own ranges for painting and observation; the focused IME/editor geometry maps placeholder offsets to the empty retained value. The corrected test verifies both distinct surfaces, empty surrounding text, and zero editor offsets while preserving glyph color, spacing and semantic-name assertions. Product implementation is unchanged; the correction changes one test file only. Focused renderer cases and the complete reverse closure are rerun; original failure is retained.'
    oracleApplicationCorrection='The first focused-oracle trial placed the focus setup on another scene by mistake: 14/15 passed, one failed because the placeholder scene was unfocused. Full diff review restored the unrelated scene and focused the intended fixture; the repeated owner passes 15/15. This is a test setup correction, with both raw runs retained.'
    authority='View owns one ordered Label/Placeholder expression algebra. Bundle rejects duplicate roles and non-String AWBC ABI. Compiler/driver consume checked programs directly. Runtime control and render control carry distinct optional strings; label is semantic name, placeholder is empty-value paint and PlaceholderShown input. Removed the static placeholder-to-label fallback and label-as-placeholder paint path; version 1 and retained String custody remain unchanged.'
    remaining='Legacy Source sample migration, authored Scroll product fixture, actual Native/Web display and capture acceptance, and the same four CLI failures remain distinct. Generic Match and all previously accepted bounded cuts retain their acceptance.'
    raw=$archiveInfo
}
$wrapper=[ordered]@{viewPlaceholderSeparation=$entry}|ConvertTo-Json -Depth 100
$inner=$wrapper.Substring($wrapper.IndexOf('{')+1).TrimEnd();$inner=$inner.Substring(0,$inner.LastIndexOf('}')).TrimEnd()
$newText=$base.TrimEnd();$newText=$newText.Substring(0,$newText.LastIndexOf('}')).TrimEnd()+','+[Environment]::NewLine+$inner+[Environment]::NewLine+'}'+[Environment]::NewLine
$after=$newText|ConvertFrom-Json -Depth 100 -DateKind String
foreach($p in $prior.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($p.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical entry drift: '+$p.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$newText,[Text.UTF8Encoding]::new($false))
[ordered]@{previousEntries=@($prior.PSObject.Properties).Count;currentEntries=@($after.PSObject.Properties).Count;historicalDrift=0;source=$source.commit;executed=$entry.freshUniqueExecuted;passed=$entry.passed;failed=$entry.failed;skipped=$entry.skipped;raw=$archiveInfo}|ConvertTo-Json -Depth 8|Set-Content "$r/view-placeholder-20261108.acceptance-record.json" -Encoding utf8
Get-Content "$r/view-placeholder-20261108.acceptance-record.json" -Raw
