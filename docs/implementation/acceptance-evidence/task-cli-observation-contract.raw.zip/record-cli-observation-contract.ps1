$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
. "$e/convergence-image-git-bytes.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
function Sha([byte[]]$bytes){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()}
$publication=Receipt 'checkpoint-cli-observation-contract.verified'
$source=(git rev-parse HEAD).Trim()
if($source -ne $publication.commit -or $publication.parent -ne '7fc7307cbdcf9253e905c9c296b7d82e4b5e3b18' -or $publication.paths.Count -ne 2){throw 'Review the source publication'}
$freeze=Receipt 'cli-observation-contract-owner3-20261103.source-freeze'
foreach($r in $freeze.paths){if((Get-FileHash -LiteralPath $r.path).Hash.ToLowerInvariant() -ne $r.sha256){throw "Source drift: $($r.path)"}}
$clippy=Receipt 'cli-observation-contract-clippy';$fmt=Receipt 'cli-observation-contract-fmt'
if($clippy.exitCode -or $fmt.exitCode){throw 'Required gate failed'}
$proof=Receipt 'cli-observation-contract.final-correction-proof'
if($proof.distinctPassingCases -ne 5 -or $proof.unchangedInputs -ne 4089){throw 'Unverified final input correction'}
$runs=@(foreach($i in @(1,2,3)){$stem="cli-observation-contract-owner$i-20261103";$inventory=Receipt "$stem.catalog.inventory";[ordered]@{stem=$stem;execution=(Receipt "$stem.runtime");terminal=(Receipt "$stem.runtime.terminal-audit");catalog=[ordered]@{matched=@($inventory.rows|Where-Object status -eq 'matches').Count;ignored=@($inventory.rows|Where-Object ignored).Count;filterMismatch=@($inventory.rows|Where-Object status -eq 'mismatch').Count}}})
if($runs[1].terminal.passed -ne 4 -or $runs[2].terminal.passed -ne 1 -or -not $runs[2].terminal.isPassingRun){throw 'Unexpected focused result'}
$untracked=Receipt 'task-documentation-final-untracked-before'
foreach($r in $untracked.files){if((Get-FileHash -LiteralPath $r.path).Hash.ToLowerInvariant() -ne $r.sha256){throw 'Original untracked WIP changed'}}
$history='docs/implementation/convergence-evidence-history.md';$before=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));$committed=Read-GitBytes @('show',"HEAD:$history")
if((Sha $before) -ne (Sha $committed)){throw 'History has unpublished edits'}
$prefixHash=Sha $before
$raw='docs/implementation/acceptance-evidence/task-cli-observation-contract.raw.zip'
$record='docs/implementation/acceptance-evidence/task-cli-observation-contract.json'
if((Test-Path -LiteralPath $raw) -or (Test-Path -LiteralPath $record)){throw 'Preserve evidence'}
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object{$_.Name.StartsWith('cli-observation-contract') -or $_.Name.StartsWith('checkpoint-cli-observation-contract.')})
$files+=@(foreach($name in @('record-cli-observation-contract.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1')){Get-Item -LiteralPath "$e/$name"})
$files=@($files|Sort-Object FullName -Unique);$entries=@()
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){$entry=$file.FullName.Substring($e.Length+1).Replace('\','/');[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Archive count mismatch'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry mismatch'}}}finally{$zip.Dispose()}
$value=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;workingTree='main; only original12 tracked and6 actual untracked WIP before evidence cut';scope='CLI integration assertions only; production, Cargo, source workload, steps, budgets, iteration/warmup and output contracts unchanged';publication=$publication;graph=(Receipt 'cli-observation-contract.graph');baseline=(Receipt 'cli-observation-contract.baseline');runs=$runs;finalInputProof=$proof;distinctPassingCases=5;freshFinalBundleCases=1;reusedUnchangedCaseResults=4;reusedExecutableClaim=$false;clippy=$clippy;format=$fmt;corrections=@('Profile and headless bench expected 3 operations for log plus return; actual typed runtime reports 2. Preserve exact2, one step and original measurement work; strengthen exact returned value, actual log, effect and return event. Remove one duplicate profile assertion.','Bundle final_status is the stable dialogue state. Preserve actual line identity using a separate execution of the same AWFB through the public typed bundle runner at the original2-step/64-op budget. Typed FlowEvents are intentionally omitted from JSON; the initial new JSON-based assertion failed, was corrected, and remains in history.','The typed event retains the authored canonical say.image.static_png, including its family. The initial shortened-ID expectation failed and was corrected to the exact authored declaration; old/new bytes were hash verified. This does not change runtime IDs or output to match an obsolete label.');cliFullSuite=[ordered]@{latestFullSource='aa96871cce4c88476230f3f90267e5d4a1d14b70';latestFixtureSource='4e39fbd5427fd7ec3e8c66bc48613832e84e4fec';executed=694;passed=661;failed=33;record='task-cli-yield-context.json';afterThisCut='The three affected previously failing IDs pass in this focused scope; the other30 failed IDs were not re-executed here. This is not a fresh694-case pass or a claimed full CLI integration acceptance.'};acceptedFeatures='Generic Match and all independent accepted boundaries remain accepted; no Sema, Core, runtime, codec, source fixture, dependency or specification bytes changed';sourceInputs=4090;sourceDrift=0;caseDrift=0;originalWip=[ordered]@{tracked=12;actualUntracked=6;heldPatchSha256=$publication.heldPatchSha256;untrackedHashDrift=0};historyPrefix=[ordered]@{bytes=$before.Length;sha256=$prefixHash;drift=0};raw=[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();entryDrift=0;entries=$entries};validationScope='CLI reverse closure contains only CLI. All-target/all-feature/locked nextest build compiles consumers; scoped Clippy and changed-file fmt pass. No full workspace, doctest, structural or wasm rerun is required by these integration assertion changes. Previous results remain evidence for their own source bytes.'}
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),($value|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$append=@"


## 2026-11-03 CLI profile／bench操作数・bundle状態と宣言IDの検査を同期

Source $source、parent 7fc7307cbdcf9253e905c9c296b7d82e4b5e3b18。CLI testの2 pathだけを変更し、production・Cargo・元source workload・step／操作budget・反復／warmup・公開JSON契約を保持した。旧Sourceaaの実出力ではlogとreturnの2操作、profileの実戻り値done、log.info/profile、benchの2反復・warmup1・1stepが成立していたため、旧3操作期待を厳密な2へ訂正し、実ログ／effect／return eventを追加検査した。重複したprofile assertionは一つにした。

bundleの状態はdialogueであり、元line IDを含む表示ではない。CLIは従来の5画像・AWFB・asset検査・元2step／64op・source再compileなし・絶対path非公開の検査を保持する。同じ生成AWFBを公開typed runnerでも実行し、FlowEvent::DialogueLineの元宣言say.image.static_pngが正確に一度発行されることを検査した。この追加API実行を別CLI caseとして加算しない。最初のJSON field仮定による4 PASS／1 FAILと、次の短縮ID期待による4 PASS／1 FAILは原本へ保持した。JSONが意図的に型付きeventを省くことと、宣言のcanonical family付きIDに従い、testだけを修復した。最後のbundle1／1 PASS、他4件は関連test本体・入力・環境不変で再利用し、5 distinct件の合格と照合する。最後の差分がbundleの期待ID一か所だけであることを4089入力と前後Source hashで証明し、同一EXEという主張はしない。

CLI自身の逆依存closureは1 package。all-target／all-feature／lockedでcatalog／nextest buildと対象実行を行い、Clippy・変更Rust fmtは終了0、警告は残る。Source／case差分0、既存12 tracked／6 actual untracked WIPを保持。以前の全CLI694件は661 PASS／33 FAILという実測のまま保持し、後続の対象3 IDの合格を全694件の新規合格や残る30 IDの再実行と扱わない。Generic Matchなどの既受入は維持する。[初回失敗・旧実出力・新規／再利用・Source公開full SHA・raw](acceptance-evidence/task-cli-observation-contract.json)。先頭$($before.Length) bytes（SHA256 $prefixHash）を保持してこの記録だけを追記した。
"@
$stream=[IO.File]::Open([IO.Path]::GetFullPath($history),[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes([IO.Path]::GetFullPath($history));$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length);if((Sha $prefix) -ne $prefixHash){throw 'History prefix changed'}
[ordered]@{source=$source;distinctPassing=5;freshFinal=1;reused=4;archiveEntries=$entries.Count;archiveBytes=$value.raw.bytes;archiveSha256=$value.raw.sha256;historyPrefixBytes=$before.Length;historyPrefixSha256=$prefixHash}|ConvertTo-Json -Depth 8
