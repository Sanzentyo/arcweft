# /// script
# requires-python = "==3.11.*"
# dependencies = []
# ///
"""Capture elapsed metered work for selected LLDB call scopes."""

import json
import os

import lldb


target = None
charge_bp = None
phase_by_id = {}
returns_by_pc = {}
threads = {}
reports = []


def register(frame, name):
    return frame.FindRegister(name).GetValueAsUnsigned()


def unsigned(frame, address):
    error = lldb.SBError()
    result = frame.GetThread().GetProcess().ReadUnsignedFromMemory(address, 8, error)
    if error.Fail():
        raise RuntimeError(str(error))
    return result


def thread_id(frame):
    return frame.GetThread().GetThreadID()


def current_state(frame):
    stack = threads.get(thread_id(frame))
    return stack[-1] if stack else None


def counter(frame, state):
    # The selected Windows artifact's apply_lower_delta reads this field.
    return unsigned(frame, state + 0x130)


def raise_limit(frame, _, __):
    value = frame.FindRegister("rdx")
    if value.GetValueAsUnsigned() == 4096:
        value.SetValueFromCString("16384")
    return False


def starts_state(frame, _, __):
    threads.setdefault(thread_id(frame), []).append({"pointer": None, "stages": [], "open": []})
    charge_bp.SetEnabled(True)
    return False


def find_state(frame, _, __):
    if (state := current_state(frame)) is not None:
        state["pointer"] = register(frame, "rdx")
    charge_bp.SetEnabled(False)
    return False


def phase_entry(frame, location, _):
    state = current_state(frame)
    if state is not None and state["pointer"] is not None:
        name = phase_by_id[location.GetBreakpoint().GetID()]
        state["stages"].append({"phase": name, "counter": counter(frame, state["pointer"])})
    return False


def publishes(frame, _, __):
    state = current_state(frame)
    if state is not None:
        threads[thread_id(frame)].pop()
    report = register(frame, "rcx")
    open_scopes = len(state["open"]) if state is not None else 0
    reports.append(
        {
            "consumed": unsigned(frame, report + 0x50),
            "limit": unsigned(frame, report + 0x58),
            "lower": counter(frame, state["pointer"]) if state is not None and state["pointer"] else 0,
            "open_scopes": open_scopes,
            "stages": state["stages"] if state is not None else [],
        }
    )
    with open(os.environ["ARCWEFT_METER_OUTPUT"], "w", encoding="utf-8") as output:
        json.dump(reports, output, indent=2)
    return False


def add(debugger, text, name):
    debugger.HandleCommand(f"breakpoint set {text} --skip-prologue false")
    bp = target.GetBreakpointAtIndex(target.GetNumBreakpoints() - 1)
    if not bp.GetNumLocations():
        raise RuntimeError(f"No executable location for {text}")
    bp.SetScriptCallbackFunction(f"{__name__}.{name}")
    return bp


def install(debugger):
    global target, charge_bp
    target = debugger.GetSelectedTarget()
    limits = "arcweft_lang_sema::callable::limits::"
    add(debugger, f'--name "{limits}ResolverWork::new"', "raise_limit")
    add(debugger, f'--name "{limits}CandidateConstraintWorkState::new"', "starts_state")
    charge_bp = add(debugger, f'--name "{limits}CandidateConstraintWorkState::apply_lower_delta"', "find_state")
    charge_bp.SetEnabled(False)
    add(debugger, f'--name "{limits}ResolverWorkFullReport::publish_into"', "publishes")
    root = "D:/git/arcweft/crates"
    markers = (
        ("arcweft-lang-sema/src/effect_row/prepared/closure.rs", 835, "root-compilation"),
        ("arcweft-lang-sema/src/effect_row/prepared/closure.rs", 836, "root-completion"),
        ("arcweft-lang-sema/src/effect_row/prepared/closure.rs", 857, "canonical-confirm"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 276, "merge-applications"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 299, "original-environment"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 307, "original-effect-inventory"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 308, "original-effect-inventory-end"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 324, "reconcile-type-binding"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 365, "reconcile-const-binding"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 404, "seal-original-type-branch"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 412, "freeze-original-effects"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 421, "bind-original-effects"),
        ("arcweft-lang-sema/src/types/constraints/transaction/component/original.rs", 427, "original-product-ready"),
        ("arcweft-lang-sema/src/types/constraints/normalization/effects.rs", 410, "close-original"),
        ("arcweft-lang-sema/src/types/constraints/normalization/effects.rs", 417, "confirm-original-scope"),
        ("arcweft-lang-sema/src/effect_row/prepared/completion/binding.rs", 122, "admit-final-constraints"),
        ("arcweft-lang-sema/src/effect_row/prepared/completion/binding.rs", 123, "final-snapshot-call"),
        ("arcweft-lang-sema/src/effect_row/prepared/read/freeze.rs", 79, "snapshot-start"),
        ("arcweft-lang-sema/src/effect_row/prepared/read/freeze.rs", 259, "snapshot-end"),
        ("arcweft-lang-sema/src/types/constraints/transaction.rs", 2319, "open-source-relation"),
        ("arcweft-lang-sema/src/types/constraints/transaction.rs", 2338, "accept-source-relation"),
    )
    for file, line, name in markers:
        try:
            bp = add(debugger, f'--file "{root}/{file}" --line {line}', "phase_entry")
        except RuntimeError:
            if name in {"prepare-start", "prepare-end", "confirm-start"}:
                raise
            print(f"No executable location for {name}: {file}:{line}")
            continue
        phase_by_id[bp.GetID()] = name





