$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$pub=Get-Content -Raw "$root/operand-reification.publication.json"|ConvertFrom-Json
function Assert-Source {
    if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse 'HEAD^{tree}') -ne $pub.Tree -or @(git diff --name-only HEAD).Count){throw 'Structure source changed'}
}
Assert-Source
$start=Get-Date
& cargo +nightly -Zscript tools/structure-audit.rs --root . --fail-on-blocking > "$root/operand-reification.structure.log" 2> "$root/operand-reification.structure.stderr"
$code=$LASTEXITCODE
Assert-Source
$log=[IO.File]::ReadAllText("$root/operand-reification.structure.log")
function Number($name){$m=[regex]::Match($log,'(?m)^'+[regex]::Escape($name)+': ([0-9]+)\r?$');if(!$m.Success){throw "Missing $name"};[int]$m.Groups[1].Value}
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;Log='operand-reification.structure.log';Files=(Number 'files scanned');RustFiles=(Number 'Rust files');RustPhysicalLOC=(Number 'Rust physical LOC');Packages=(Number 'workspace packages');ReviewTriggers=(Number 'review triggers');Blocking=(Number 'blocking violations')}|ConvertTo-Json|Set-Content -Encoding utf8 "$root/operand-reification.structure.json"
if($code -ne 0){throw 'Structure gate failed'}
Get-Content "$root/operand-reification.structure.json"


