$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/operand-reification.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/operand-reification.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/operand-reification.impact.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/operand-reification.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/operand-reification.structure.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/operand-reification.consumer-summary.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/operand-reification.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean'}
if($owner.Passed -ne 1719 -or $owner.Failed -ne 6 -or !$impact.ReverseConsumersRerun -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$archive.AllEntriesVerified -or $structure.ExitCode){throw 'Evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'History prefix changed'}
$status=[IO.File]::ReadAllText($statusPath)
$rows=@{}
$pattern='(?m)^\| 再帰関数値の終端効果 \|[^\r\n]*'
$row=[regex]::Match($status,$pattern).Value
if(!$row.Contains('reify入力の元operand導出、')){throw 'Expected unfinished type reification item missing'}
$row=$row.Replace('`643fec5b62fd4f3eb1d648214e65c4123c2430dd`','`SOURCE`').Replace('nullary残余条件の正確な簡約を検証・公開','nullary残余簡約と型reifyのoperand保持を検証・公開').Replace('新8件はPASS、64入力の元solver／独立replayとの照合を含む。','残余簡約8件・64入力の照合を維持。型のreify入口は元operandを受け、投影入力・出力・型束縛を既存RetainOrigins foldで閉じ、Source・child・aliasの導出と実フレームを保持する。等形の別binder下でのtype／effect移送・取消し時のscope復元・元applicationへのreopenを追加1件で確認した。').Replace('reify入力の元operand導出、','定数・effect-onlyのreify、Free許可の実導出による判定、').Replace('・[今回の簡約](convergence-evidence-history.md#nullary-effect-residual-reduction)','・[残余簡約](convergence-evidence-history.md#nullary-effect-residual-reduction)・[型reify](convergence-evidence-history.md#operand-derivations-through-type-reification)')
$rows['再帰関数値の終端効果']=$row
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,719 PASS／6 FAIL。後続21 packageは2,507 PASS／2 FAIL／1 SKIP** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,725件をSECONDS秒で実行。直前1,724 ID保持・新1件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。先行対象9件は8 PASS／新fixture 1 FAILで、applicationを実ambientより先に作ったfixtureを実際の導入順へ訂正し、その失敗も保持する。全feature metadata／全target reverse treeの22 packageを確認し、後続21 package／107 targetも今回は同じSourceで再実行した。2,510件中2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗はExpressionCycle slot 17／19で不変。公開Sourceに全consumer結果を付け替えた再利用ではなく、新しい実行である。[owner・全consumer・graph・全SHA原本](acceptance-evidence/task-operand-reification.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source `SOURCE`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件を今回再実行し、226 PASS。binはcompile済み・runnable test 0件。21 packageの全consumer照合に含め、選択・終端ID一致・重複0を確認した。以前の入力・件数・失敗・公開SHAと過去の再利用範囲は履歴と原本に保持する。[今回のCLI実行原本](acceptance-evidence/task-operand-reification.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace全target／全feature check・Clippy、fmt・doctest・構造gateは終了0** | Source `SOURCE` と同一のRust bytesでlocked workspace全target／全feature checkとClippy、workspace fmt、Sema doctest 2件を今回実行。構造gateはPACKAGES package・FILES files・RUSTFILES Rust files・RUSTLOC Rust LOC・REVIEWS review・blocking 0。6 Rust path・GROWTH物理LOC増。型reifyの全producerをoperand入口へ揃え、既存の導出保持foldと実フレーム移送を使い、raw TypeKindからreifyする入口を置換した。新しい型walker・Γの複製表・Source contextの再構築・依存・unsafe・互換readerは追加しない。Cargo graphは22 package、fan-in／outは12／19で不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告も原本に保持。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を維持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・graph・全consumer](acceptance-evidence/task-operand-reification.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'}
    $replacement=$rows[$key].Replace('SOURCE',$pub.Source).Replace('SECONDS',[string]$owner.ExecutionSeconds).Replace('PACKAGES',[string]$structure.Packages).Replace('RUSTFILES',[string]$structure.RustFiles).Replace('FILES',[string]$structure.Files).Replace('RUSTLOC',[string]$structure.RustPhysicalLOC).Replace('REVIEWS',[string]$structure.ReviewTriggers).Replace('GROWTH',[string]$owner.PhysicalGrowth)
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$status=[regex]::Replace($status,'この更新の基点の `main` と `origin/main` は `[a-f0-9]{40}`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Operand derivations through type reification

2026-11-13。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの6 Rust pathを通常commit／非force pushし、ownerが検証したdirty bytesと公開全blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- projection入力をraw TypeKindへ取り出して閉じていた経路を削除した。入力は元のoperand.view()、出力は実applicationが開いたtemplate operandとして、既存project_closed_operand／RetainOrigins foldへ渡す。Source・child・alias・effect headerの導出を対応するportで保持し、型束縛も同じoperandのままreifyする。TypeConstraintSolutionとCompletedGenericContextの型reify入口を全producerでConstraintOperandへ置換し、raw型の並行入口は残さない。
- reifyの既存移送foldはoperandの実lexical scopeをsourceとして用い、成功・取消しの双方で受け手scopeを復元する。新たな型walker、Source Γの再構築や許可表を作らない。追加1件はambientとFn-localのtype／effect参照、等形だが別の受け手binder、取消し復元と元applicationへのreopenを検証した。先行対象runの8 PASS／1 FAILは、fixtureがapplicationをambientより先に作っていた正当なescaping拒否であり、実導入順へfixtureを訂正した結果を全件runで確認した。
- 最終locked・全feature Sema lib／testsは1,725件／1,719 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,724 ID保持・新1件PASS・選択／終端ID一致・重複0、既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。残余簡約の8件と64入力照合も同じ全件runに含む。
- producerが変わるため今回は下流結果を再利用せず、full all-feature metadata／全target reverse treeの22 packageから、後続21 package／107 targetを同じSourceで再実行した。全2,510件／2,507 PASS／2 FAIL／1 SKIP、選択／終端ID一致・重複0。Compiler既知2失敗のExpressionCycle slot 17／19、CLI規定226 PASS、compile-only 3 targetを照合した。workspace全target／全feature checkとClippy、workspace fmt、Sema doctest 2件、構造gateは終了0。Cargo graph、fan-in 12／fan-out 19は不変。
- 6 path・$($owner.PhysicalGrowth)物理LOC増。既存の型閉包foldが導出保持を、既存のcompleted transportが実フレーム移送と出力ごとのcaptureを所有する。Supersedes: 現状一覧の「reify入力の元operand導出」を今回の型入口の実装・検証に基づき残作業から除き、constant／effect-only reify、Free許可の実導出による判定とprimitive effect行のΓ sealを別の未完了境界として明記した。全portのΓ統合、一般量化消去、frontend再帰本体推論の完了とはしない。過去の全SHA・実測・失敗・原本とGeneric Match・caller-bound recursion・共有prefixの受入を保持し、現在の一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-operand-reification.raw.zip](acceptance-evidence/task-operand-reification.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended current operand/consumer evidence.'
