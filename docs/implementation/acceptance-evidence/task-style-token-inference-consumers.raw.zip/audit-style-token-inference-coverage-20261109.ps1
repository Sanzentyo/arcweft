$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$old=Get-Content "$r/style-composites-integrated-20261109.noncli-r1.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$new=Get-Content "$r/style-token-inference-integrated-20261109.noncli-r1.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 20
$graph=Get-Content "$r/style-token-inference-20261109.graph.json" -Raw|ConvertFrom-Json -Depth 30
$before=@($old.rows|Where-Object {$_.status -eq 'matches' -and $_.package -in $graph.packages.name})
$after=@($new.rows|Where-Object status -eq 'matches')
$current=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $after){if(!$current.Add(($row.binary+[char]0+$row.test))){throw 'Duplicate current case'}}
$previous=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$missing=@(foreach($row in $before){$key=$row.binary+[char]0+$row.test;[void]$previous.Add($key);if(!$current.Contains($key)){$row}})
if($missing.Count){$missing|ConvertTo-Json -Depth 8|Set-Content "$r/style-token-inference-20261109.coverage.missing.json";throw 'Retained case missing'}
$added=@($after|Where-Object {!$previous.Contains(($_.binary+[char]0+$_.test))})
[ordered]@{
 version=1;baselineSource='eb4b9a820e7e74a106e4ca17405e50b642cb579b';currentSource='f8c17506c05ee9df614581d8df12e46a2c178464'
 baselineRetainedInCurrentClosure=$before.Count;missing=0;duplicates=0;additionalCurrentCases=$added.Count
 additionalByPackage=@($added|Group-Object package|ForEach-Object {[ordered]@{package=$_.Name;cases=$_.Count}})
 currentSelected=$after.Count;rename=@()
 scope='Project the previous View-closure catalog into the current Sema closure. Preserve all cases in the affected closure; lower native View/render-only packages remain covered by their unchanged earlier source. Do not relabel these scopes as the same complete workspace matrix.'
}|ConvertTo-Json -Depth 10|Set-Content "$r/style-token-inference-20261109.coverage.json"
Get-Content "$r/style-token-inference-20261109.coverage.json"

