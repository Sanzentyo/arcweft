param([Parameter(Mandatory)][string]$Epoch)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
& "$r/assert-no-arcweft-build.ps1"
$stem="$r/style-token-inference-20261109.native-$Epoch"
if(Test-Path ($stem+'.source.json')){throw 'Probe epoch exists'}
$paths=@((git ls-files -- '*.rs' '*.toml' '*.lock' '*.json' '*.stderr' '*.arcw' '*.awfagent' 'rust-toolchain*' '.cargo/*')|Where-Object {$_ -notlike 'docs/*'})
$paths+=@('crates/arcweft-lang-sema/src/final_analysis/model/style.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style.rs','crates/arcweft-lang-sema/src/final_analysis/model/style_number.rs','crates/arcweft-lang-sema/src/final_analysis/analyzer/expressions/style/primitives.rs','crates/arcweft-compiler/tests/view_product/style_primitives.rs')
$inputs=@(foreach($p in @($paths|Sort-Object -Unique)){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$inputs|ConvertTo-Json -Depth 8|Set-Content ($stem+'.source.json') -Encoding utf8
function Assert-Inputs {foreach($row in $inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Probe source drift: '+$row.path)}}}
$mainAudit=Get-Content "$r/style-token-inference-integrated-20261109.cli-r1.main-audit.json" -Raw|ConvertFrom-Json
$main=$mainAudit.path
$hash=(Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant()
if($hash -ne $mainAudit.sha256){throw 'Actual tested CLI changed before Source probe'}
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();status='reused';scope='Use the actual CLI pinned before and after CLI-r1 runtime, with no additional build';main=$mainAudit;sourceInputs=$inputs.Count;sourceDrift=0}|ConvertTo-Json -Depth 10|Set-Content ($stem+'.build-reuse.json') -Encoding utf8
$start=[DateTime]::UtcNow.ToString('o')
$checkCommand=@('check','--manifest-path','samples/native-text-input/arcw.toml','--json')
& $main @checkCommand *> ($stem+'.check.log')
$check=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant() -ne $hash){throw 'Actual CLI changed'}
$receipt=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();main=[ordered]@{path=$main;sha256=$hash};sourceInputs=$inputs.Count;sourceDrift=0;binaryDrift=0;checkCommand=$checkCommand;checkExitCode=$check;startedAt=$start;finishedAt=[DateTime]::UtcNow.ToString('o');scope='Actual CLI Source check, not interactive Native/Web acceptance'}
$receipt|ConvertTo-Json -Depth 12|Set-Content ($stem+'.check.json') -Encoding utf8
if($check -ne 0){exit $check}
$report=Get-Content ($stem+'.check.log') -Raw|ConvertFrom-Json -Depth 100
if($report.status -ne 'ok'){throw 'Check lacks successful status'}
$artifact='D:/git/arcweft/target/arcweft/native-text-input-inferred.awfb'
$bundleCommand=@('bundle','--manifest-path','samples/native-text-input/arcw.toml','--profile','main','--output',$artifact,'--json')
& $main @bundleCommand *> ($stem+'.bundle.log')
$bundle=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $main).Hash.ToLowerInvariant() -ne $hash){throw 'Actual CLI changed'}
$receipt.bundleCommand=$bundleCommand
$receipt.bundleExitCode=$bundle
if($bundle -eq 0){$receipt.artifact=[ordered]@{path=$artifact;bytes=(Get-Item -LiteralPath $artifact).Length;sha256=(Get-FileHash -LiteralPath $artifact).Hash.ToLowerInvariant()}}
$receipt.finishedAt=[DateTime]::UtcNow.ToString('o')
$receipt|ConvertTo-Json -Depth 12|Set-Content ($stem+'.json') -Encoding utf8
$receipt|ConvertTo-Json -Depth 12
exit $bundle
