$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$pub=Read-Record 'style-token-inference-20261109.source-checkpoint.verified.json'
$noncli=Read-Record 'style-token-inference-integrated-20261109.noncli-r1.runtime.terminal-audit.json'
$cli=Read-Record 'style-token-inference-integrated-20261109.cli-r1.runtime.terminal-audit.json'
$old=Read-Record 'style-composites-integrated-20261109.cli-r1.runtime.terminal-audit.json'
$main=Read-Record 'style-token-inference-integrated-20261109.cli-r1.main-audit.json'
$probe=Read-Record 'style-token-inference-20261109.native-r1.json'
$priorProbe=Read-Record 'style-composites-20261109.native-r1.json'
$coverage=Read-Record 'style-token-inference-20261109.coverage.json'
$diagnostics=Read-Record 'style-token-inference-integrated-20261109.failure-diagnostics.json'
if((git rev-parse HEAD).Trim() -ne '5560fb6f978ba09a7a591e9ed73c0c5921a96ed3'){throw 'Matrix recording base changed'}
if($noncli.actualExitCode -ne 0 -or $noncli.executed -ne 3622 -or $cli.executed -ne 711 -or $cli.failed -ne 4){throw 'Unexpected matrix result'}
if(@(Compare-Object @($old.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object) @($cli.failureSet|ForEach-Object {$_.binary+'::'+$_.test}|Sort-Object)).Count){throw 'CLI failure set changed'}
if($probe.checkExitCode -ne 0 -or $probe.bundleExitCode -ne 0 -or $probe.main.sha256 -ne $main.sha256 -or $main.binaryDrift -ne 0 -or $probe.artifact.sha256 -ne $priorProbe.artifact.sha256){throw 'Native Source probe or tested CLI mismatch'}
if($coverage.missing -ne 0 -or $coverage.duplicates -ne 0){throw 'Coverage changed'}
$archive='docs/implementation/acceptance-evidence/task-style-token-inference-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(foreach($filter in @('style-token-inference-integrated-20261109*','style-token-inference-20261109.native-r1*')){Get-ChildItem -LiteralPath $r -File -Filter $filter|Where-Object {$_.Extension -in @('.json','.log')}})
$files+=@('style-token-inference-20261109.coverage.json','run-style-token-inference-consumers-20261109.ps1','run-style-token-inference-cli-consumers-20261109.ps1','audit-style-token-inference-coverage-20261109.ps1','audit-style-token-inference-cli-failures-20261109.ps1','run-style-token-inference-native-source-probe-20261109.ps1','record-style-token-inference-consumers-20261109.ps1')|ForEach-Object {Get-Item -LiteralPath "$r/$_"}
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';productionPublication=$pub;recordingBase=(git rev-parse HEAD).Trim()
 status='Unannotated Style token inference passed complete Sema reverse-dependency execution apart from the same four diagnosed CLI failures. Environment and full sample/Native/Web acceptance remain open.'
 qualityReuse='Reuse styleTokenInferenceCheckpoint all98 workspace gates and final Sema lint/fmt for unchanged production/test/fixture bytes. The complete consumer runs here validate final arity-preflight and lint-correction bytes.'
 nonCli=$noncli;cli=$cli
 freshTotals=[ordered]@{executed=$noncli.executed+$cli.executed;passed=$noncli.passed+$cli.passed;failed=$noncli.failed+$cli.failed;skipped=$noncli.skipped+$cli.skipped;runs=2;featurePoints=2}
 coverage=$coverage
 failureDiagnostics=$diagnostics
 actualCli=$main;nativeSourceProbe=$probe
 scope='Metadata and target-all reverse tree agree on Sema22: nonCLI21 all-features and CLI1 defaults. All21 nonCLI selected packages have runtime cases. Project the prior View40 catalog into the current Sema21 selection: retained3618, missing0, duplicates0, additional4 Compiler3/Sema1. Previous native View/render consumer acceptance remains historical evidence; do not call this the same workspace matrix. Do not add owner50, earlier runs, separate Source probe or skipped cases to fresh executed totals.'
 pending='Environment Source publication, remaining sample migrations, real Native/Web operations/capture parity, and the unchanged four CLI failures. Accepted Generic Match, explicit Style construction and other completed functions remain accepted.'
 archive=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 147 -or $prior.PSObject.Properties.Name -contains 'styleTokenInferenceConsumers'){throw 'Unexpected registry'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "styleTokenInferenceConsumers": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$source=$pub.commit
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$styleRow='| Style 指定値・token・構築処理 | **明示型付き構築の受入を維持。未annotation推論を全Sema consumerで検証・公開** | 推論Source '+$source+'。構築・引数・数値・enum文法を共有し、元sheetの注釈／実利用からnative kindを絞る。forward aliasは単調queueで伝播し、全domainが一意になってから期待型を公開する。名前prefix推測や元HIR annotationの捏造を行わず、通常checkerが元initializerを検証する。全25 kind・64段alias・曖昧／矛盾／別sheet拒否をownerで確認し、その後のpreflight／lint整理を含む最終SourceでSema逆依存22 packageを実行した。横断実測とCLI既知4失敗は下表に集約する。残る実装範囲はEnvironment、残るsampleと実Native／Web操作／表示。[全SHA・実測・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$matrixRow='| 共有契約／推移的逆依存matrix | **今回Sema範囲4333実行：4329 PASS／4 FAIL／24 SKIP** | Source '+$source+'。metadata／target-all tree一致のSema逆依存22 packageを非CLI全feature21とCLI既定へ分けた。非CLIは3622／3622 PASS・1 SKIP・278.432秒、選択21 package全てがruntime caseを持つ。前回View catalogを今回範囲へ投影した旧3618件は欠落／重複0、追加4件はCompiler3／Sema1。Source／catalog／実EXE drift0。最終2 run／2 feature pointのみ集計し、owner50件・旧run・別Source probeを加算しない。前回のView範囲5388件の実測と受入は履歴へ保持し、今回再実行したとは記さない。[終端・coverage・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$cliRow='| CLIの規定対象／全 check 照合 | **Style推論統合後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | Source '+$source+'、'+[string]($cli.summary)+'。先行と同じ4失敗IDと実診断を照合し、新規失敗0。Scrollのshared callable Expr15拒否、active dialogue has no voice、promotion2件のsolver到達前Expr8 type-check拒否は未解消。元pathの実CLI本体とtest EXEを前後照合し、CLI SHA256は'+$main.sha256+'。同じ実CLIによるnative-text-input check／main-profile bundle生成も終了0、89命令／81840 bytes、生成物hashは前回と一致する。このprobeを711件へ加算しない。[診断・EXE pin・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status=(@($status -split $lf|ForEach-Object {
 if($_.StartsWith('| Style 指定値・token・構築処理 ')){$styleRow}
 elseif($_.StartsWith('| 共有契約／推移的逆依存matrix ')){$matrixRow}
 elseif($_.StartsWith('| CLIの規定対象／全 check 照合 ')){$cliRow}
 else{$_}
})) -join $lf
if(($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -cne $generic){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — Style token推論の全Sema consumer検証

推論Source $source、記録base 5560fb6f978ba09a7a591e9ed73c0c5921a96ed3 を固定した。owner後の引数数preflightとlint整理を含む最終bytesで、metadata／target-all tree一致のSema逆依存22 packageを実行した。非CLI全feature21 packageは3622／3622 PASS・1 SKIP・278.432秒、選択21 package全てにruntime caseがあり、3917入力／catalog／EXE差分0。前回View40 catalogの今回範囲3618件は欠落／重複0、追加4件はCompiler3／Sema1で、renameはない。前回のnative View／render-onlyの実行を今回と混同しない。

CLI既定は $($cli.summary)。先行の4失敗IDと実diagnosticを照合した。Scrollのshared callable resolution Expr15、voice不在、promotion2件のsolver前type-check Expr8拒否は継続し、新しい失敗はない。3941入力／catalog／EXE差分0、実target/debug/arcw.exeの前後pinはSHA256 $($main.sha256) で一致した。今回の最終2 run／2 feature pointは4333実行／4329 PASS／4 FAIL／24 SKIPであり、owner50件・旧run・別Source probeを加算していない。

同じ実CLIを追加buildなしで使い、native-text-inputのcheckはstatus ok、main-profile bundleは終了0・89命令・81840 bytes。元path $($probe.artifact.path) のSHA256 $($probe.artifact.sha256) は前回と一致し、3917入力／実CLI差分0。Source受付と生成物の検証であり、実Native／Web操作・画像parityの受入ではない。

現状一覧の「最終consumer実行中」を今回の終端結果へ訂正し、旧View範囲の現状重複は履歴へ移した。以前のSource／失敗／full SHA／実測は保持する。Environment、sampleと既知CLI4条件は具体的未達として残し、Generic Match等の完了を戻さない。既存147 registry propertyの値を全件照合して保持し、styleTokenInferenceConsumersを追加した。原本 $archive は$count entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。EXE／AWFB等のbuild artifactをZIPへコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;freshTotals=$entry.freshTotals;archive=$entry.archive}|ConvertTo-Json -Depth 6|Set-Content "$r/style-token-inference-20261109.consumer-acceptance-record.json"
Get-Content "$r/style-token-inference-20261109.consumer-acceptance-record.json"
