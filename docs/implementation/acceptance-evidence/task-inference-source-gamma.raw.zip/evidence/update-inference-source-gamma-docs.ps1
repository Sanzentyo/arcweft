$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/inference-source-gamma.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/inference-source-gamma.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/inference-source-gamma.consumer-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/inference-source-gamma.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD) -cne $pub.Source -or @(git diff --name-only HEAD).Count -or $owner.Passed -ne 1691 -or $owner.Failed -ne 6 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2){throw 'Final source or evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$status=[IO.File]::ReadAllText($statusPath)
$historyBytes=[IO.File]::ReadAllBytes($historyPath)
$accepted=[regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value
if(!$accepted){throw 'Accepted Generic Match row missing'}
[ordered]@{Version=1;Source=$pub.Source;StatusSHA256=(Get-FileHash $statusPath).Hash;HistorySHA256=(Get-FileHash $historyPath).Hash;HistoryBytes=$historyBytes.Length;AcceptedGenericMatch=$accepted;FrozenArchives=@(git ls-files 'docs/implementation/acceptance-evidence/*.zip'|ForEach-Object{[ordered]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_).Hash}})}|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/inference-source-gamma.docs-before.json"
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `78a8bbdc9acdb22af80da952b5934e883d1bdac2`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。元値のΓと導入参照のownerを接続し公開。本体内推論を継続** | 最新Source `'+$pub.Source+'`。Native／AWBCで42を返す既受入と各step公開JSON保存復元、完了値ごとのcapture、対応operand portと実scopeを維持する。元値・checked source値はBoundを実frameで検査・移送し、FreeとInferenceを元の宣言Γ・実import leaseで検査する。導入参照は選択したキーだけの実application leaseを保持し、子callは自分の準備済みSource Γを使う。期待型のleaseは親pathの実owner・限定範囲を照合してから受け取り、root lineageの権限を借りない。結果hintも移送済みoperandを読む。新6件と移行した既存条件は全ownerでPASS。数学層は宣言schemeと導入時の依存引数を持つ推論行関数を共同で解き、whole-row D⇒Cと局所∀を保持する。Bindable／Futureを区別し、全Future実値を受けて新labelを含め共同最小化・独立再検証する56件を維持する。残るのはreify入力の元operand導出、checked primitive effect ownerと計算済み行seal、Template／Result・再構築値を含む全portのΓ証明への統合、Future未解決の条件付きcompletion／MGU／rankと型ownerへの局所∀接続、frontend prepared value／effect接続・body一回準備・一括sealである。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[capture](convergence-evidence-history.md#completed-output-capture-support)・[header port](convergence-evidence-history.md#typed-effect-header-ports)・[共同推論](convergence-evidence-history.md#scoped-effect-row-functions)・[将来値](convergence-evidence-history.md#future-effect-function-specialization)・[今回のΓ・owner接続](convergence-evidence-history.md#inference-references-and-application-leases)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,691 PASS／6 FAIL。後続21 packageは2,507 PASS／2 FAIL／1 SKIP** | Source `'+$pub.Source+'` でlocked・全feature Sema lib／testsの1,697件を'+$owner.ExecutionSeconds+'秒で実行。選択・終端の全ID一致、重複0。直前1,691 IDを維持し、新6件がPASS。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。同じSourceの後続21 package・107 targetの2,510 IDも選択・終端一致。Compiler既知2失敗は同じExpressionCycle slot 17／19。CLI 226件・callable_execution 376件はPASS。owner全featureとconsumer既定featureを別sliceで保持する。途中Sourceでの追加18失敗と修復経過は履歴へ集約し、既受入機能を未完了へ戻さない。[今回の全原本・入力・診断](acceptance-evidence/task-inference-source-gamma.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **最新Sourceの規定226件PASS。全 check は未再実行** | Source `'+$pub.Source+'`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS。binはcompile済み・runnable test 0件。今回のΓ・producer移行に対する実行結果へ更新した。以前の入力・件数・失敗は履歴と原本に保持する。[今回の実行原本](acceptance-evidence/task-inference-source-gamma.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace check／Clippy・fmt・構造gateが終了0** | Source `'+$pub.Source+'` のlocked workspace全target／全feature check／Clippy、workspace fmt、Sema doctest 2件を実行。owner Clippyはworkspaceに包含。現在のCargo graphでSemaを含む逆依存22 packageを確認し、Cargo入力の変更0。全21 pathの公開blob・byte pin、各step前後のSource／tree／tracked差分0を照合した。実owner／Source Γの境界とcut全体684物理LOC増を対象に責務を確認し、構造gateはblocking 0。警告を原本に保持する。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・依存graph原本](acceptance-evidence/task-inference-source-gamma.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
foreach($name in $rows.Keys){$pattern='(?m)^\| '+[regex]::Escape($name)+' \|[^\r\n]*';if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'};$replacement=$rows[$name];$status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match)$replacement})}
if([regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value -cne $accepted){throw 'Accepted feature changed'}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$note=@"

## Inference references and application leases

2026-11-13。cut基点 ``$($pub.ChangeBase)``、中間Source ``1fcbe61ef8417cd8834168121244e0b24d748c0e``（tree ``e1401d798490ab9533f2ad889f32c3a1b1b25c39``）、最終実装・公開 Source ``$($pub.Source)``（tree ``$($pub.Tree)``、parent ``$($pub.Parent)``）。既存mainで21 Rust pathを通常commit／非force pushした。最終Sourceのtracked差分0、既存の未追跡 ``%SystemDrive%/`` を保持する。

- 元値のnon-Bound参照はFree／Inferenceとも実宣言Γ・import leaseで検査する。実applicationとキーの限定を保持する既存leaseを導入参照operandへ保持し、Original Productの左辺をraw original値として作る経路を置換した。型・const・効果・predicate・単独length、正当なimport、異種キー拒否、owner存続、予算0／取消しを検証。結果hintは移送済みoperandの座標を使う。
- 子applicationは準備済みauthorityのSource Γを保持し、root lineageと区別する。nested callでも期待型の既存leaseをSource Γへ渡し、実親pathからの再貸出と同じowner・限定captureかを、メーター付きで照合してからadmitする。同じキーと形を持つ別ownerを拒否する新条件を含む。ticket・通常制約・結果使用・関数instance／transformも実applicationの元Γを読む。権限を型から集める処理、別catalog、旧reader、pureへのfallbackは追加しない。
- 開発baselineは旧Source ``35af9d0545e7d0d9f50778cac7bd6ba922e6aa4f``＋初期test patchで1件／0 PASS／1 FAIL。中間Sourceは対象40 PASSの後、全owner 1,696件／1,672 PASS／24 FAIL／0 SKIPで追加18失敗を観測し、後続検証前に停止した。Source Γ検査を緩めず、application型を元値として渡していた数学fixtureを実template producerへ移し、ambient frame値は元Sourceのまま維持した。frontendのroot Γ流用・nested期待lease除外と、実owner検査を修復した。中間のcompile error、2件・9件・7件の失敗、診断用backtrace、最終313件PASSを原本に保持する。診断用コードは除去済みで、assertion・budget・既存test IDを弱めていない。
- 最終全feature ownerは1,697件／1,691 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、slow 0。直前1,691 IDを保持し、新6件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。実行ごとのSourceを区別し、中間24失敗を最終結果へ読み替えない。
- 現在のCargo graphの全22 packageを確認し、後続21 package・107 targetは同じ最終Sourceで2,510 ID／2,507 PASS／2 FAIL／1 SKIP。既知Compiler 2失敗とExpressionCycle slot 17／19は不変。CLI 226・callable_execution 376がPASS、3 targetはcompile-only。locked workspace全target／全feature check／Clippy、fmt、Sema doctest 2件、構造gateは終了0。旧runのSHAを最新へ付け替えていない。
- 21 path・684物理LOC増。application.rsの既存loan authorityとoriginal_context.rsの元Γが検査を所有し、53 LOCのparameter.rsが導入leafだけを構築する。transaction.rsは2,815 LOCで74増だが、同じfrontier／式state machineのSource producerとchecked operand消費を接続し、root lineageの役割を保持する。callable/constraints.rsは2,935 LOCで6増、continuation.rsは2,847 LOCで1減、analyzer/calls.rsは5,969 LOCで7減であり、既存の準備・呼出し責務を跨いだ別stateを追加しない。寸法・分類・fan-in／fan-outは原本へ保持。新しい型walker、Γ表、I/O owner、Cargo依存、unsafe、公開互換readerを追加しない。
- Supersedes: 現状一覧のfixture化・Bound移送の途中説明は、現在の元値Γ／導入owner／子Source Γの契約へ統合した。過去の全SHA、実測、失敗、frozen原本は保持する。Generic Match、caller-bound recursion、共有prefixの受入を維持する。本cutの範囲と全体の残作業は[current-status.md](current-status.md)だけに集約する。

原本 [task-inference-source-gamma.raw.zip](acceptance-evidence/task-inference-source-gamma.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
$bytes=[Text.UTF8Encoding]::new($false).GetBytes($note+"`n")
$stream=[IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write)
try{$stream.Write($bytes)}finally{$stream.Dispose()}
Write-Output 'Updated four current rows and appended source-specific evidence'