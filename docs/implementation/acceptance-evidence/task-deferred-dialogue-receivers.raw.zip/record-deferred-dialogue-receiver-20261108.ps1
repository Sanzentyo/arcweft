$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='deferred-dialogue-receiver-20261108'
$source=Get-Content -LiteralPath "$taskTemp/$prefix.source.verified.json" -Raw | ConvertFrom-Json
if((& git rev-parse HEAD).Trim() -ne $source.commit){throw 'Published source differs'}
$quality=[ordered]@{}
foreach($name in @('core','compiler','scoped','fanout','docs','clippy','structure','fmt')){
 $receipt=Get-Content -LiteralPath "$taskTemp/$prefix.quality.$name.receipt.json" -Raw | ConvertFrom-Json
 if($receipt.exitCode -ne $(if($name -eq 'compiler'){100}else{0})){throw "Unexpected quality result: $name"}
 $quality[$name]=$receipt
}
foreach($row in (Get-Content -LiteralPath "$taskTemp/$prefix.quality.source.json" -Raw | ConvertFrom-Json).inputs){
 if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Validated source differs: $($row.path)"}
}
$counts=[ordered]@{}
foreach($name in @('core','compiler','scoped','fanout')){
 $log=[IO.File]::ReadAllText("$taskTemp/$prefix.quality.$name.log")
 $summary=([regex]::Matches($log,'Summary[^\r\n]*'))[-1].Value
 $run=[regex]::Match($summary,'(\d+) tests run').Groups[1].Value
 $passed=[regex]::Match($summary,'(\d+) passed').Groups[1].Value
 $failed=[regex]::Match($summary,'(\d+) failed').Groups[1].Value
 $skipped=[regex]::Match($summary,'(\d+) skipped').Groups[1].Value
 $counts[$name]=[ordered]@{run=[int]$run;passed=[int]$passed;failed=[int]$failed;skipped=[int]$skipped;receipt=$quality[$name]}
}
if($counts.core.run -ne 2323 -or $counts.core.failed -ne 0 -or $counts.compiler.run -ne 113 -or $counts.compiler.passed -ne 112 -or $counts.compiler.failed -ne 1 -or $counts.scoped.run -ne 30 -or $counts.fanout.run -ne 4){throw 'Actual runtime counts require review'}
if(-not([IO.File]::ReadAllText("$taskTemp/$prefix.quality.docs.log").Contains('80 passed; 0 failed'))){throw 'Doctest count differs'}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if($before.Contains('"deferredDialogueReceivers"')){throw 'Evidence already exists'}
$archivePath='docs/implementation/acceptance-evidence/task-deferred-dialogue-receivers.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Raw archive exists'}
$names=@(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*" | ForEach-Object Name)+@('run-deferred-dialogue-receiver-quality-20261108.ps1','record-deferred-dialogue-receiver-20261108.ps1') | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object {Join-Path $taskTemp $_}) -DestinationPath $archivePath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try{
 if($zip.Entries.Count -ne $entries.Count){throw 'Archive count differs'}
 foreach($entry in $zip.Entries){
  $expected=$entries | Where-Object entry -eq $entry.FullName
  $stream=$entry.Open()
  try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
  if($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256){throw 'Archive entry differs'}
 }
}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';source=$source
 behavior=@('Product dialogue receivers identify an actual allocated ordinary fiber or an activation frame. Main and non-Line-owned children use the same dialogue dispatch, input handoff, publication and continuation protocol.', 'Foreground status exposes the real child dialogue activation while its caller is draining a defer. Each-step public JSON save/cold restore authenticates the existing receiver topology against actual retained child frames.', 'Failure closes the dialogue and traps its actual ordinary receiver so child and caller cleanup can drain. The real child cleanup and bank unwind are preflighted before final dialogue abandonment.', 'Native Line-work completion authenticates the actual receiver among retained session fibers, replacing the incorrect main-only status gate. Exact persistent owner and activation identities remain mandatory. No wire, codec or contract version changes.')
 actual=[ordered]@{core=$counts.core;compiler=$counts.compiler;scopedDefer=$counts.scoped;fanout=$counts.fanout;coreDocs=[ordered]@{passed=80;failed=0;receipt=$quality.docs};quality=$quality;operationBound=1;tickBound=512;conditions=@('original nested deferred Line, saved AWBC','original two closed generic deferred Lines, saved AWBC','Actor retained in another cleanup packet during a deferred Dialogue, Native and saved AWBC; actual public child waiting activation','deferred Dialogue cancellation returns to its owning cleanup, Native and saved AWBC; one Actor acquire and release','failed deferred Dialogue drains child cleanup and failed caller cleanup without executing either normal continuation, saved AWBC','missing or replaced actual deferred child receiver is rejected during save binding; rejected admission preserves the complete original executor snapshot and the original execution then completes')}
 development=@(
  [ordered]@{receipt="$prefix.first.receipt.json";result='2 PASS / 106 SKIP: original saved nested/generic deferred Lines now execute';scope='Initial receiver implementation, before the additional lifecycle projection and negative/cancellation tests.'},
  [ordered]@{receipt="$prefix.extended.receipt.json";result='4 PASS / 1 FAIL / 106 SKIP';failure='New Native deferred-dialogue cancellation input reached StaleCommandOutcome; the combined cancellation test stopped before AWBC.';resolution='Split the backend tests, then replace Native main-only receiver authentication with the exact retained receiver. This did not reopen earlier accepted Native inputs.'},
  [ordered]@{receipt="$prefix.cancel.receipt.json";result='1 PASS / 1 FAIL / 110 SKIP';failure='The split run confirmed AWBC cancellation passes and Native alone fails.'},
  [ordered]@{receipt="$prefix.cancel-r2.receipt.json";result='2 PASS / 110 SKIP';resolution='Native receiver repair passes the original new input alongside saved AWBC.'},
  [ordered]@{receipt="$prefix.tamper.receipt.json";result='0 PASS / 1 FAIL / 112 SKIP';failure='The new test incorrectly unwrapped save binding, which already correctly rejected the missing receiver.';resolution='Assert rejection at the actual binding admission boundary and compare the unchanged original snapshot.'},
  [ordered]@{receipt="$prefix.tamper-r2.receipt.json";result='1 PASS / 112 SKIP';note='This probe preceded the final child failure-close preflight and final formatting; the complete quality run covers those final bytes.'}
 )
 remainingFailures=@('ordinary_defer::native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line: AffineGroupCapture; initial owned Line inputs and post-reveal shared inputs are not separated')
 corrections=@('Remove the two current AWBC deferred-child Dialogue rejection cases because their exact original inputs now pass; retain the old 108-case 105 PASS/3 FAIL result and all earlier SHAs as history.', 'The newly reproduced Native cancellation failure was limited to an actual deferred child receiver and is repaired and verified here. Previously accepted Generic Match, Line/init, returned Actor captures and bounded Native inputs remain accepted.', 'The current evaluated_effects result is one 113-case run with 112 PASS/1 FAIL. Do not combine its counts with development probes or older full runs.')
 ownershipReview=(Get-Content -LiteralPath "$taskTemp/$prefix.ownership-review.json" -Raw | ConvertFrom-Json -Depth 15)
 limits=@('The remaining Native initial owned Line input is a separate boundary. No general cancellation or all-resource acceptance is inferred from the bounded deferred-dialogue cases.', 'Core53 reverse-closure and workspace all-target/all-feature check/Clippy have not been rerun for this source. Manifests and the resolved graph remain unchanged; the actual Core reverse closure has 53 packages.', 'Aggregate registration/child preconstruction limits, Native public save, remaining CLI failures and Native/Web visual acceptance remain wider convergence conditions. All lint warnings are retained; no performance improvement is claimed.')
 raw=[ordered]@{path='task-deferred-dialogue-receivers.raw.zip';sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$fragment=([ordered]@{deferredDialogueReceivers=$record} | ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$historyPath='docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText((Join-Path (Get-Location) $historyPath))
$addition=@"

## 2026-11-08 — defer 内 Dialogue の実受信 fiber と取消し・失敗継続

Source **$($source.commit)** を既存 main へ通常 commit/push し、親・tree・全 blob・完全差分を照合した。Product の受信先を main 固定から実際に割り当てられた通常 fiber／activation frame に統一し、defer 子も同じ開始・公開・結果継続を使う。実際の子の待機 activation を公開 status へ投影し、元の保存 admission が保持する child receiver の対応を確認する。失敗は実受信子を trap して child／caller の cleanup を drain し、最後の対話破棄前に当該子の cleanup と bank unwind を preflight する。公開 wire／codec は version 1 を維持する。
元の入れ子・2型 generic の AWBC 失敗2件が PASS したため、現状の開始拒否を削除した。返された Actor を別 cleanup packet に保持したまま子 Dialogue が待つ場合と取消す場合は Native／保存 AWBC で完走し、取得・解放各1回、1-op／512-step を維持。AWBC は毎 step 公開 JSON 保存／cold restore を行う。失敗時は通常継続を実行せず子 cleanup、失敗 caller cleanup の順で完了。受信子の suspension 削除・activation occurrence 改変は bind 時に拒否し、元 snapshot が不変なことと元実行の完走を確認した。
新しい取消入力で Native の main-only 完了検査が stale activation を誤報することを具体的に再現した。実 session fiber の persistent owner／activation の完全一致へ直し、分離した Native／AWBC の2件が PASS。開発時の 4 PASS／1 FAIL と 1 PASS／1 FAIL、および改変テストが既に拒否される bind を unwrap した初回失敗も原本に保持する。既受入済み Native、Generic Match、Line/init をこれらの別入力や全体 goal の未達で戻さない。
最終固定入力の Core2323 PASS、Compiler evaluated_effects113件中112 PASS／1 FAIL、scoped defer30 PASS、選択 fanout4 PASS／162 SKIP、Core doctest80 PASS。Core・Compiler全target／全feature Clippy、7 path fmt、構造gateは終了0。fanout の SKIP は選択外と既存 ignored generator を含み、全 RuntimePlan run とはしない。残る失敗は Native の初期所有 Line 入力が共有 Copy 捕捉へ入る1件。旧108件中105 PASS／3 FAIL と全 SHA は履歴のまま保持する。Core53／全workspace最終 matrix、全取消し・集約構築上限、Native公開save、CLI・Native/Webの残条件はこの owner run の受入に合算しない。[全実測・適用範囲・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText((Join-Path (Get-Location) $historyPath),$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$lines=$status -split "`n"
$match=@(0..($lines.Length-1) | Where-Object {$lines[$_].StartsWith('| 通常 Flow の scoped defer |')})
if($match.Count -ne 1){throw 'Current ordinary Flow row differs'}
$lines[$match[0]]='| 通常 Flow の scoped defer | **既受入を保持。返却Actor捕捉の既受入に加え、defer内Dialogue・取消しをNative／保存AWBC、失敗継続を保存AWBCで検証・公開済み。全体受入は継続中** | 関数本体・明示scopeのLIFO、generic捕捉／戻り値、registry読書き・drop／置換、cleanup後のgoto／Choice移譲、失敗caller drain、待機、open scopeのraw Return／Complete拒否を検証済み。返却Actorの直接・tuple・入れ子捕捉とfilter解放も維持する。Source '+$source.commit+' は実際のdefer子fiberへ対話の開始・公開・継続を接続し、元の入れ子・2型genericのAWBC失敗2件が通ったため旧開始拒否を削除した。別packetにActorを保持した子Dialogueの通常終了・取消し、実待機activationの公開status、失敗時の子／caller cleanup、受信slot改変の拒否と元状態保全を確認。AWBCは毎step version 1公開JSON保存／cold restore。Native取消しで新規再現したmain-only検査も実受信先の認証へ修復した。evaluated_effectsは113件中112 PASS／1 FAIL。残る実測は、初期所有Line入力と開始後の共有入力の未分離によるNativeのAffineGroupCapture 1件。全取消し・登録／子構築前の集約検査は継続中。必須registry読取りには静的存在証明が必要。[全実測・訂正理由・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$match=@(0..($lines.Length-1) | Where-Object {$lines[$_].StartsWith('| workspace check／Clippy・fmt・構造gate |')})
if($match.Count -ne 1){throw 'Current quality row differs'}
$lines[$match[0]]='| workspace check／Clippy・fmt・構造gate | **直近の全workspace gateはSource b6dfで終了0。追加Sourceのowner gateも終了0** | 全workspaceの直近入力はSource `b6df0c825805b9ac77cad6a9760761a861007679`。最新固定入力はCore2323 PASS／doctest80 PASS、Compiler scoped defer30 PASS、RuntimePlanの選択fanout4 PASS／162 SKIP。Core・Compiler全target／全feature Clippy、7 path fmt、構造gateが終了0。Compiler evaluated_effectsの現状は通常Flow行で追跡する。旧件数・初回失敗・警告・全SHAは履歴に保持する。Cargo変更0で実Core逆依存は53 packageだが、新Sourceの全workspace／Core53最終再検証は未実施。他platform／Tier2の受入へ拡張しない。[全実測・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath),($lines -join "`n"),[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;entries=$entries.Count;rawSha256=$record.raw.sha256;counts=$counts} | ConvertTo-Json -Depth 3
