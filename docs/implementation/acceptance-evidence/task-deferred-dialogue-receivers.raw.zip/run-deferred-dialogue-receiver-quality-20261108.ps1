$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix=Join-Path $taskTemp 'deferred-dialogue-receiver-20261108.quality'
$owned=@(Get-Content -LiteralPath "$taskTemp/deferred-dialogue-receiver-20261108.source.owned.txt")
& rustfmt --edition 2024 --config skip_children=true @owned
if($LASTEXITCODE -ne 0){throw 'Formatting failed'}
$inputs=@(rg --files --hidden -g '*.rs' -g 'Cargo.toml' -g 'Cargo.lock' -g 'rust-toolchain*' -g '.cargo/config*' -g '!target' -g '!.git' | Sort-Object -Unique)
$freeze=@(foreach($p in $inputs){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
if(Test-Path -LiteralPath "$prefix.source.json"){throw 'Source epoch already exists'}
[ordered]@{base=(& git rev-parse HEAD).Trim();inputs=$freeze} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$prefix.source.json" -Encoding utf8NoBOM
function Assert-Inputs {
 foreach($row in $freeze){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
}
function Run-Cargo([string]$name,[string[]]$arguments){
 Assert-Inputs
 $started=[DateTime]::UtcNow
 & cargo @arguments *> "$prefix.$name.log"
 $code=$LASTEXITCODE
 Assert-Inputs
 [ordered]@{arguments=$arguments;exitCode=$code;sourceInputs=$freeze.Count;sourceDrift=0;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$prefix.$name.receipt.json" -Encoding utf8NoBOM
 Get-Content -LiteralPath "$prefix.$name.log" -Tail 12
}
Run-Cargo 'core' @('nextest','run','--locked','-p','arcweft-core','--lib','--no-tests','fail','--no-fail-fast')
Run-Cargo 'compiler' @('nextest','run','--locked','-p','arcweft-compiler','--test','evaluated_effects','--no-tests','fail','--no-fail-fast')
Run-Cargo 'scoped' @('nextest','run','--locked','-p','arcweft-compiler','--test','scoped_defer','--no-tests','fail','--no-fail-fast')
Run-Cargo 'fanout' @('nextest','run','--locked','-p','arcweft-runtime-plan','-E','test(program_fanout)','--no-tests','fail','--no-fail-fast')
Run-Cargo 'docs' @('test','--locked','-p','arcweft-core','--doc')
Run-Cargo 'clippy' @('clippy','--locked','-p','arcweft-core','-p','arcweft-compiler','--all-targets','--all-features')
Assert-Inputs
& just structure-audit-gate *> "$prefix.structure.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{command='just structure-audit-gate';exitCode=$code;sourceInputs=$freeze.Count;sourceDrift=0} | ConvertTo-Json | Set-Content -LiteralPath "$prefix.structure.receipt.json" -Encoding utf8NoBOM
Get-Content -LiteralPath "$prefix.structure.log" -Tail 8
& rustfmt --check --edition 2024 --config skip_children=true @owned *> "$prefix.fmt.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{command='rustfmt --check --edition 2024 --config skip_children=true';exitCode=$code;paths=$owned;sourceDrift=0} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$prefix.fmt.receipt.json" -Encoding utf8NoBOM
