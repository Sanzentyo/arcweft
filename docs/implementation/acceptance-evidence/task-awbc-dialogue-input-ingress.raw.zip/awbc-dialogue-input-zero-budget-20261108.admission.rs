    #[test]
    fn live_and_inert_input_admission_share_order_replay_and_limit_checks() {
        use arcweft_interaction_model::input::{InputEpoch, InputSequence};
        let event = |sequence| RuntimeDialogueInputActionEvent::new(
            activation(), InputActionId::new("input.cancel").unwrap(), InputEpoch(1), InputSequence(sequence),
        );
        let first = event(1);
        let second = event(2);
        fn check(reducer: &impl LineTaskReducerView, first: &RuntimeDialogueInputActionEvent, second: &RuntimeDialogueInputActionEvent) {
            let admitted = reducer.inspect_input_action_events([second, first]).unwrap().into_pending_events();
            assert_eq!(admitted, [first.clone(), second.clone()]);
            assert!(matches!(reducer.inspect_input_action_events([first, first]).err().unwrap(), LineRuntimeError::DuplicateInputActionEvent { .. }));
            assert_eq!(reducer.inspect_input_action_events(std::iter::repeat_n(first, 65_537)).err().unwrap(), LineRuntimeError::InputActionHistoryLimitExceeded);
        }
        let mut live = LineTaskLiveState::new(&group(1), activation());
        check(&live, &first, &second);
        check(&live.snapshot(), &first, &second);
        live.accept_input_action_events(std::slice::from_ref(&first)).unwrap();
        let inert = live.snapshot();
        for failure in [live.inspect_input_action_events([&first]).err().unwrap(), inert.inspect_input_action_events([&first]).err().unwrap()] {
            assert_eq!(failure, LineRuntimeError::ConsumedInputActionEvent { event: first.clone() });
        }
        assert_eq!(live.snapshot(), inert);
    }
