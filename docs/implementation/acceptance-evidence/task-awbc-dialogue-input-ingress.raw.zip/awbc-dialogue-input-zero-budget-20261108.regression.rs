#[test]
fn native_deferred_dialogue_retains_cancellation_during_zero_operation_steps() {
    with_native_line_handle_steps(
        &deferred_dialogue_cancellation_source(),
        assert_deferred_cancellation_across_zero_operation_steps,
    );
}

#[test]
fn saved_awbc_deferred_dialogue_retains_cancellation_during_zero_operation_steps() {
    with_saved_awbc_steps(
        &deferred_dialogue_cancellation_source(),
        assert_deferred_cancellation_across_zero_operation_steps,
    );
}

fn assert_deferred_cancellation_across_zero_operation_steps(
    step: &mut dyn FnMut(
        arcweft_core::step::RuntimeStepInput,
        arcweft_core::step::RuntimeStepOptions,
    ) -> arcweft_core::step::RuntimeStepResult,
) {
    let mut packets = 0;
    execute_nested_line_handle_transfer(
        2,
        false,
        true,
        &["body", "cancelled", "released"],
        |mut input, options| {
            if !input.dialogue_input_actions.is_empty() {
                packets += 1;
                let tick = input.tick;
                let mut zero = options;
                zero.budget.max_ops = 0;
                for _ in 0..3 {
                    let result = step(input, zero);
                    assert_eq!(result.stats.executed_ops, 0);
                    assert!(result.output.diagnostics.is_empty(), "{:?}", result.output.diagnostics);
                    assert!(result.output.flow_events.is_empty());
                    assert!(result.output.requests.line_commands.is_empty());
                    input = arcweft_core::step::RuntimeStepInput { tick, ..Default::default() };
                }
            }
            step(input, options)
        },
    );
    assert_eq!(packets, 1, "one actual cancellation packet, with no resubmission");
}

