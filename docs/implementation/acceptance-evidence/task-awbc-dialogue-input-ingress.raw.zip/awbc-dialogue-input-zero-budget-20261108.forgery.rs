#[test]
fn saved_awbc_deferred_dialogue_rejects_forged_pending_cancellation_packets() {
    let mut checked = false;
    with_saved_awbc_steps_checking(
        &deferred_dialogue_cancellation_source(),
        |executor, save| {
            if checked { return executor; }
            for (index, entry) in save["dialogues"]["entries"].as_array().unwrap().iter().enumerate() {
                let Some(packet) = entry.pointer("/Active/frame/pending_input_actions/0") else { continue; };
                let before = executor.snapshot().unwrap();
                for mutation in 0..4 {
                    let mut forged = save.clone();
                    let frame = &mut forged["dialogues"]["entries"][index]["Active"]["frame"];
                    match mutation {
                        0 | 1 => {
                            let field = if mutation == 0 { "occurrence" } else { "owner_fiber" };
                            let value = &mut frame["pending_input_actions"][0]["activation"][field];
                            *value = (value.as_u64().unwrap() + 1).into();
                        }
                        2 => frame["pending_input_actions"].as_array_mut().unwrap().push(packet.clone()),
                        3 => frame["phase"]["Reducing"]["line_task"]["consumed_input_actions"].as_array_mut().unwrap().push(packet.clone()),
                        _ => unreachable!(),
                    }
                    let saved = serde_json::from_value(forged).unwrap();
                    assert!(executor.bind_product_save_snapshot(saved).is_err(), "forged pending input mutation {mutation}");
                    assert_eq!(executor.snapshot().unwrap(), before);
                }
                checked = true;
                break;
            }
            executor
        },
        assert_deferred_cancellation_across_zero_operation_steps,
    );
    assert!(checked, "the original unconsumed packet reached public save");
}

