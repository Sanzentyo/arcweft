$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='awbc-dialogue-input-zero-budget-20261108'
$base=(git rev-parse HEAD).Trim()
if($base -ne '17e34d99e32c4618ac6ed866a7ee9ccdcff441c5'){throw 'Unexpected source'}
$final=Get-Content "$taskTemp/$stem.owner-r4.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($final.executed -ne 3 -or $final.passed -ne 3 -or $final.failed -ne 0){throw 'Owner result differs'}
$history=Get-Content "$taskTemp/$stem.owner-r3.source-freeze.json" -Raw|ConvertFrom-Json
$historyPath='crates/arcweft-core/src/line_task.rs'
$historyHash=($history.paths|Where-Object { $_.path.Replace('\','/') -eq $historyPath }).sha256
if((Get-FileHash $historyPath).Hash.ToLowerInvariant() -ne $historyHash){throw 'Shared history owner changed'}
$runs=@(foreach($part in @('probe','fixed-r1','owner-r2','owner-r3','owner-r4')){
 $catalog=Get-Content "$taskTemp/$stem.$part.catalog.json" -Raw|ConvertFrom-Json
 $terminal=$null
 if(Test-Path "$taskTemp/$stem.$part.runtime.terminal-audit.json"){$terminal=Get-Content "$taskTemp/$stem.$part.runtime.terminal-audit.json" -Raw|ConvertFrom-Json}
 [ordered]@{attempt=$part;catalog=$catalog;terminal=$terminal}
})
$archive='docs/implementation/acceptance-evidence/task-awbc-dialogue-input-ingress.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
$files=@(Get-ChildItem $taskTemp -File|Where-Object {($_.Name.StartsWith($stem+'.') -and -not $_.Name.Contains('.workspace-quality.')) -or $_.Name -in @('record-awbc-dialogue-input-owner-20261108.ps1','run-source-frozen-matrix-20261108.ps1','audit-nextest-final-result.ps1')}|Sort-Object Name)
$entries=@(foreach($file in $files){[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash $file.FullName).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256 -or $entry.Length -ne $row.bytes){throw 'Archive drift'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$base;sourcePublication=(Get-Content "$taskTemp/$stem.source.verified.json" -Raw|ConvertFrom-Json -Depth 30)
 problem='A real cancellation packet delivered once at max_ops=0 was lost by Product AWBC: after 512 original one-op steps only body was logged and the held Actor was not released. Native completed the same input. This adds a concrete zero-budget ingress condition and does not reopen Generic Match, root defer or earlier Line/init acceptance.'
 owner='The original dialogue activation frame retains pending input actions. Product ingress borrows RuntimeStepInputRef, validates packet length and the actual live reducer/activation, combines pending and new identities through the sole LineTaskReducerView inspector, preflights revisions, then retains the packet. The reducer consumes that packet once. Version-one public save, private rollback, metadata admission and constructors all carry the same field; the old ephemeral resume parameter is deleted.'
 validation=$runs
 accepted='Source owner-r4: 3/3 pass, 136 filtered out. Native and publicly saved/cold-restored AWBC each retain one cancellation packet through three zero-operation steps, then finish the original 512-step/one-op flow with body/cancelled/released logs, two actual reveals and held Actor release. Four public-save forgeries (occurrence, owner_fiber, duplicate, consumed-history conflict) are rejected before execution publication; each rejection preserves the original snapshot, and the original run finishes.'
 sharedHistory=[ordered]@{path=$historyPath;sha256=$historyHash;run='owner-r3';test='line_task::retained_reducer_tests::live_and_inert_input_admission_share_order_replay_and_limit_checks';passed=$true;scope='The unchanged history owner checks ordered normalization, duplicate/replay refusal and the 65537th borrowed event limit against live and inert storage. Its earlier run is retained separately, not merged into owner-r4.'}
 corrections=@('owner-r2 is preparation exit101 only: the new test used private tuple constructors for InputEpoch/InputSequence; their public new constructors repaired the fixture.','owner-r3 has 3 pass / 1 fail: the new forgery test incorrectly required source binding to perform full restore admission. The final test follows both binding and restoration, rejects any execution publication and checks the unchanged snapshot. This is a test-contract correction, not evidence that a forged executable was admitted.','The source checkpoint and owner-r4 retain their actual recorded timestamps and frozen input hashes; the checkpoint was committed after the runtime terminal, while its result was being recovered. The follow-up removes only an unused LogicalDuration import after the borrowed-input signature migration. Full workspace gates and reverse consumers are still running/not yet accepted here.')
 remaining='Fresh all-feature Core reverse consumers, separate default CLI, workspace check/Clippy/structure/fmt, Native public Save, platform/Tier2 and final Native-Web parity retain their separate scope. Earlier 8052-case Source625 matrix is not relabeled as this new source.'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledger='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledger));$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'awbcDialogueInputIngress'){throw 'Record exists'}
$fragment=([ordered]@{awbcDialogueInputIngress=$record}|ConvertTo-Json -Depth 100).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}');$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($p in $old.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($p.Name)|ConvertTo-Json -Depth 99 -Compress)){throw "Old record changed: $($p.Name)"}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledger),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$row="| 対話取消入力のstep保留／保存admission | **Native／保存AWBCの追加owner条件を検証・公開。新Sourceの全逆依存・gateは照合中** | Source $base。取消packetを一度だけ渡し、操作予算0の3 stepを挟んでも元の512 step／1 op実行でcleanupとActor解放を完了する。保存AWBCは毎step公開JSON保存／cold restoreし、occurrence／owner fiber／重複／消費済み履歴の4改変を元状態不変で拒否した。現Sourceの3件PASSと、同じhistory ownerの先行live／inert並び順・再送・65537件上限PASSは別runとして保持する。新しい具体的な予算0条件を追加したもので、Generic Matchや既受入Line／initを未完了へ戻さない。先行Sourceの8052件を新Sourceの全件結果へ転用しない。[修復前の実不具合・fixture訂正・全SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
$anchor='## 横断検証の適用範囲'
if($status.Contains('| 対話取消入力のstep保留／保存admission |')){throw 'Status row exists'}
$status=$status.Replace($anchor,$row+"`n`n"+$anchor)
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$addition=@"

## 2026-11-08 — AWBC対話入力の予算0保留と公開保存

Source **$base** は、取消入力をstepの一時値から読む経路を削除し、元activationの保留packetに移した。修復前probeはNative PASS／保存AWBC FAILで、AWBCは元512 step後もbody logのみ・Actor未解放。修復後owner-r4は**3／3 PASS・136 SKIP**で、一度だけの取消入力を3回の0-operation stepと毎step公開JSON保存／cold restoreにまたがって保持し、元cleanup・解放・2 revealを完了する。occurrence／owner fiber／重複／消費済み履歴の4改変は、実行公開前に拒否し元snapshotを保持した。

live／inert共有検査の並び順・再送・65537件上限は、同じhistory ownerのowner-r3でPASSし、別runとして保持する。owner-r2の新testのprivate tuple constructor指定は準備失敗101でruntimeではない。owner-r3の新forgery testはsource bindとrestore admissionを混同して1失敗し、最終testを実際の二段階APIに合わせ、復元拒否・元状態不変・原本の継続実行を検査した。受入条件は緩めない。現Sourceの全workspace gate／Core逆依存／CLIは未完了で、先行625deea6d6051469fc0c60a4e6808727fb42c21dの8052件を転用しない。Generic Match等の既受入は保持する。[全実測・訂正理由・公開receipt・raw](acceptance-evidence/task-flow-registry-execution.json)。raw $($entries.Count) entries、SHA-256 $($record.raw.sha256)。Source後の補足変更は借用input APIへ移行後の未使用import削除だけである。
"@
[IO.File]::AppendAllText($historyPath,"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{base=$base;preservedRecords=$old.PSObject.Properties.Name.Count;rawEntries=$entries.Count;sha256=$record.raw.sha256;ownerPassed=3;forgeryConditions=4}|ConvertTo-Json

