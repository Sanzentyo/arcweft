
$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$root=Join-Path $env:TEMP 'arcweft-prefix-effects-20261110'
$previous=Join-Path $env:TEMP 'arcweft-recursive-callbacks-20261110'
$pin=Get-Content -LiteralPath (Join-Path $root 'source.local.json') -Raw|ConvertFrom-Json -AsHashtable
$prior=Get-Content -LiteralPath (Join-Path $previous 'quality/receipt.json') -Raw|ConvertFrom-Json -AsHashtable
function ArcSha($p){(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}
function Confirm-ArcSource {
    if((git rev-parse HEAD) -cne $pin.source -or (git rev-parse origin/main) -cne $pin.remote -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned source drift'}
    foreach($row in $pin.blobs){if((ArcSha $row.path) -cne $row.sha256){throw "Pinned byte drift $($row.path)"}}
}
Confirm-ArcSource
foreach($c in @(@{name='rdeps-default';args=@()},@{name='rdeps-all';args=@('--all-features')},@{name='rdeps-all-targets';args=@('--all-features','--target','all')})){
    $additional=$c.args
    $logs=foreach($owner in 'arcweft-lang-sema','arcweft-compiler'){
        $name=if($owner -ceq 'arcweft-lang-sema'){$c.name+'.log'}else{$c.name+'.compiler.log'}
        $path=Join-Path $root $name
        cargo tree --locked --workspace --invert $owner --prefix none --format '{p}' @additional 1> $path
        if($LASTEXITCODE){exit $LASTEXITCODE}
        $path
    }
    $p=@(Get-Content -LiteralPath $logs | ForEach-Object { if ($_ -match '^(arcweft-[\w-]+) v') { $Matches[1] } } | Sort-Object -Unique)
    $p | Set-Content -LiteralPath (Join-Path $root ($c.name+'.packages')) -Encoding utf8NoBOM
    "$($c.name) $($p.Count)"
}
$metadata=Join-Path $root 'metadata-host.json'
cargo metadata --locked --format-version 1 --all-features --filter-platform x86_64-pc-windows-msvc 1> $metadata
if($LASTEXITCODE){exit $LASTEXITCODE}
$doc=Get-Content -LiteralPath $metadata -Raw|ConvertFrom-Json -AsHashtable
$names=@{}; foreach($pkg in $doc.packages){$names[$pkg.id]=$pkg.name}
$seeds=@($doc.workspace_members|Where-Object {$names[$_] -in 'arcweft-lang-sema','arcweft-compiler'})
if($seeds.Count -ne 2){throw 'unexpected owner seed count'}
$known=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal);foreach($seed in $seeds){[void]$known.Add($seed)}
do {
    $added=0
    foreach($node in $doc.resolve.nodes){
        if($known.Contains($node.id)){continue}
        foreach($dep in $node.deps){if($known.Contains($dep.pkg)){[void]$known.Add($node.id);$added++;break}}
    }
} while($added)
$reverse=@($doc.workspace_members|Where-Object {$known.Contains($_)}|ForEach-Object {$names[$_]}|Sort-Object)
$reverse|Set-Content -LiteralPath (Join-Path $root 'metadata-host.packages') -Encoding utf8NoBOM
"metadata-host $($reverse.Count)"
foreach($name in 'rdeps-default','rdeps-all','rdeps-all-targets'){
    $rows=@(Get-Content -LiteralPath (Join-Path $root ($name+'.packages')))
    if(Compare-Object $reverse $rows){throw "dependency set mismatch $name"}
}
if($reverse.Count -ne 22 -or (Compare-Object $reverse @($prior.packages))){throw 'prior command selection no longer covers this graph'}
$quality=Join-Path $root 'quality'
New-Item -Path $quality -ItemType Directory -Force|Out-Null
$receipt=[ordered]@{version=1;source=$pin.source;packages=$reverse;active=$null;results=@();nextestTotals=$null}
$receiptPath=Join-Path $quality 'receipt.json'
function Save-ArcQuality {
    $pending=Join-Path $quality 'receipt.next.json'
    $receipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $pending -Encoding utf8NoBOM
    [IO.File]::Move($pending,$receiptPath,$true)
}
$focused=Join-Path $root 'focused-v2.log'
$focusedCommand=@('cargo','nextest','run','--locked','--no-fail-fast','--no-tests','fail','-p','arcweft-lang-sema','--lib','-p','arcweft-compiler','--test','flow_wait','-E','test(higher_order_effects) | binary(flow_wait)')
$waitPass=@(Select-String -LiteralPath $focused -Pattern 'PASS .*arcweft-compiler::flow_wait ' | ForEach-Object {$_.Line.Trim()})
if($waitPass.Count -ne 22 -or !(Select-String -LiteralPath $focused -Pattern '41 tests run: 41 passed, 1619 skipped')){throw 'missing final flow_wait evidence'}
$receipt.results+=,[ordered]@{name='compiler-flow-wait';command=$focusedCommand;exit=0;seconds=$null;summary=@('22 flow_wait cases of the 41 passing in the focused run; the Sema cases are counted in the full sema stage');totals=[ordered]@{run=22;pass=22;fail=0;skip=0};reusedSourceReceipt='focused-v2.log';logSha256=ArcSha $focused}
Save-ArcQuality
foreach($stage in $prior.results){
    Confirm-ArcSource
    $name=$stage.name
    $command=@($stage.command)
    if($name -ceq 'compiler-tests-16'){
        $withoutWait=[Collections.Generic.List[string]]::new()
        for($i=0;$i -lt $command.Count;$i++){
            if($command[$i] -ceq '--test' -and $command[$i+1] -ceq 'flow_wait'){$i+=1;continue}
            $withoutWait.Add($command[$i])
        }
        $command=@($withoutWait)
    }
    $log=Join-Path $quality ($name+'.log')
    $receipt.active=$name
    Save-ArcQuality
    $elapsed=[Diagnostics.Stopwatch]::StartNew()
    $program=$command[0];$arguments=$command[1..($command.Count-1)]
    & $program @arguments *> $log
    $code=$LASTEXITCODE
    $elapsed.Stop()
    Confirm-ArcSource
    $summary=@(Select-String -LiteralPath $log -Pattern 'Summary .*tests? run:|test result:'|ForEach-Object {$_.Line.Trim()})
    $totals=$null
    $nextest=@($summary|Where-Object {$_ -like 'Summary *'})
    if($nextest.Count -eq 1 -and $nextest[0] -match '(\d+) tests? run: (\d+) passed(?: \([^)]+\))?(?:, (\d+) failed)?, (\d+) skipped'){
        $totals=[ordered]@{run=[int]$Matches[1];pass=[int]$Matches[2];fail=if($Matches.ContainsKey(3)){[int]$Matches[3]}else{0};skip=[int]$Matches[4]}
    }
    $receipt.results+=,[ordered]@{name=$name;command=$command;exit=$code;seconds=[Math]::Round($elapsed.Elapsed.TotalSeconds,2);summary=$summary;totals=$totals;logSha256=ArcSha $log}
    $receipt.active=$null
    Save-ArcQuality
    "$name exit=$code $($summary -join ' | ')"
    if($code -ne 0 -or ($command[1] -ceq 'nextest' -and !$totals)){Get-Content -LiteralPath $log -Tail 22;exit 1}
}
$receipt.nextestTotals=[ordered]@{run=0;pass=0;fail=0;skip=0}
foreach($row in $receipt.results){if($row.totals){foreach($key in 'run','pass','fail','skip'){$receipt.nextestTotals[$key]+=$row.totals[$key]}}}
Confirm-ArcSource
Save-ArcQuality
$receipt.nextestTotals|ConvertTo-Json

