
$ErrorActionPreference='Stop'
$root=Join-Path $env:TEMP 'arcweft-prefix-effects-20261110'
$prev=Join-Path $env:TEMP 'arcweft-recursive-callbacks-20261110'
$staged=Join-Path $env:TEMP 'arcweft-staged-attached-default-20261110'
$recursive=Join-Path $env:TEMP 'arcweft-recursive-effect-20261110'
$pin=Get-Content -LiteralPath (Join-Path $root 'source.local.json') -Raw|ConvertFrom-Json -AsHashtable
$deadline=[DateTime]::UtcNow.AddMinutes(15)
do {
    $q=Get-Content -LiteralPath (Join-Path $root 'quality/receipt.json') -Raw|ConvertFrom-Json -AsHashtable
    $built=@($q.results|Where-Object {$_.name -ceq 'cli-final-build'})
    if(!$built.Count){Start-Sleep -Seconds 5}
} until($built.Count -or [DateTime]::UtcNow -gt $deadline)
if($built.Count -ne 1 -or $built[0].exit){throw 'Pinned CLI build did not finish successfully'}
if((git rev-parse HEAD) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Pinned source drift'}
$binary=(Resolve-Path .\target\debug\arcw.exe).Path
function ArcSha($p){(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}
$sha=ArcSha $binary
$terminal=Join-Path $root 'cli-terminal'
New-Item -Path $terminal -ItemType Directory -Force|Out-Null
$full=@('prefix','text','default','default')
$runCases=[ordered]@{
    'prefix-only-effect-residual'=@{path=$prev;logs=@()}
    'prefix-only-effect-residual-immediate'=@{path=$prev;logs=@()}
    'recursive-callback-shared-default'=@{path=$prev;logs=$full}
    'recursive-callback-shared-default-forward'=@{path=$root;logs=$full}
    'shared-body-inferred-callback'=@{path=$prev;logs=$full}
    'explicit-effect-equal-direct'=@{path=$root;logs=@('callback')}
}
$runs=foreach($name in $runCases.Keys){
    $case=$runCases[$name];$input=Join-Path $case.path "$name.arcw"
    foreach($executor in 'bytecode-vm','awbc-product'){
        $argsUsed=@('run',$input,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','512','--json')
        $out=Join-Path $terminal "$name.$executor.run.json";$err=Join-Path $terminal "$name.$executor.run.stderr"
        & $binary @argsUsed 1> $out 2> $err
        $code=$LASTEXITCODE
        if($code -or (Get-Item -LiteralPath $err).Length){throw "CLI failure $name/$executor exit=$code"}
        $j=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
        $maxOps=($j.steps|ForEach-Object {$_.stats.executed_ops}|Measure-Object -Maximum).Maximum
        $logs=@($j.steps[-1].observations.logs|ForEach-Object {$_.message})
        $violations=@($j.steps|Where-Object {$_.diagnostics.Count -or $_.assertion_failures.Count -or $_.assertion_diagnostics.Count})
        if($j.final_status -cne 'done Return("42")' -or ($logs -join '|') -cne ($case.logs -join '|') -or $maxOps -gt 1 -or $violations.Count){throw "Unexpected execution $name/$executor"}
        [ordered]@{name=$name;executor=$executor;command=$argsUsed;exit=$code;status=$j.final_status;steps=$j.steps.Count;maxOps=$maxOps;diagnosticSteps=$violations.Count;logs=$logs;inputSha256=ArcSha $input;reportSha256=ArcSha $out}
    }
}
$checkCases=[ordered]@{
    'explicit-effect-superset-direct'=@{path=$root;stage='runtime-plan-lower';pattern='project-call fixed source type*'}
    'explicit-effect-superset-curried'=@{path=$root;stage='runtime-plan-lower';pattern='project-call fixed source type*'}
    'shared-default-explicit-callback'=@{path=$prev;stage='runtime-plan-lower';pattern='project-call fixed source type*'}
    'recursive-body-self-value'=@{path=$recursive;stage='type-check';pattern='semantic expression dependency cycle*'}
    'cycle-ordinary-body'=@{path=$staged;stage='type-check';pattern='semantic expression dependency cycle*'}
    'cycle-retained-prefix'=@{path=$staged;stage='type-check';pattern='semantic expression dependency cycle*'}
    'recursive-inferred'=@{path=$staged;stage='type-check';pattern='semantic expression dependency cycle*'}
    'recursive-callback-rotation-no-entry'=@{path=$prev;stage='type-check';pattern='shared callable resolution failed*'}
}
$checks=foreach($name in $checkCases.Keys){
    $case=$checkCases[$name];$input=Join-Path $case.path "$name.arcw"
    $argsUsed=@('compile',$input,'--emit','check','--json')
    $out=Join-Path $terminal "$name.check.json";$err=Join-Path $terminal "$name.check.stderr"
    & $binary @argsUsed 1> $out 2> $err
    $code=$LASTEXITCODE
    $j=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
    if($code -ne 1 -or (Get-Item -LiteralPath $err).Length -or $j.stage -cne $case.stage -or $j.diagnostics[0].diagnostic.message -cnotlike $case.pattern){throw "Unexpected check $name exit=$code"}
    [ordered]@{name=$name;command=$argsUsed;exit=$code;status=$j.status;stage=$j.stage;diagnostics=$j.diagnostics;inputSha256=ArcSha $input;reportSha256=ArcSha $out}
}
if((ArcSha $binary) -cne $sha){throw 'CLI binary changed during execution'}
[ordered]@{version=1;source=$pin.source;binarySha256=$sha;runs=@($runs);checks=@($checks)}|ConvertTo-Json -Depth 14|Set-Content -LiteralPath (Join-Path $terminal 'receipt.json') -Encoding utf8NoBOM
$runs|ForEach-Object {"$($_.name) $($_.executor) $($_.status) steps=$($_.steps) maxOps=$($_.maxOps)"}
$checks|ForEach-Object {"$($_.name) exit=$($_.exit) $($_.stage)"}

