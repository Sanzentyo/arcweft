param([Parameter(Mandatory)][string]$Binary)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$label='effect-free-expected-types.second-candidate'
$recipe=Join-Path $d "$label.lldb"
$log=Join-Path $d "$label.lldb.log"
$test='final_analysis::tests::t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once'
$env:PATH=(Split-Path -Parent (uv python find 3.11 --no-project --offline).Trim())+';'+$env:PATH
$exe=(Resolve-Path -LiteralPath $Binary).Path
$sha=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
& lldb --batch -s $recipe -- $exe --exact $test --nocapture *> $log
$code=$LASTEXITCODE
if($sha -ne (Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()){throw 'Source binary changed.'}
[ordered]@{
    version=1;test=$test;binary=$exe;sha256=$sha;log_sha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant();
    lldb_exit=$code;observed_at=(Get-Date -Format o)
} | ConvertTo-Json | Tee-Object -FilePath (Join-Path $d "$label.json")
Select-String -LiteralPath $log -Pattern 'where = .*hit count' | Select-Object -Last 3 -ExpandProperty Line


