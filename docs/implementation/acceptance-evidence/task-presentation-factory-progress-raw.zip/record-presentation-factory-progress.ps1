$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$head='cf9dfb95f67bdcfd4eb4e43b1fbeb44924d0fc2f'
if((git rev-parse HEAD).Trim() -ne $head){throw 'Unexpected publication base'}
& "$taskTemp/assert-no-arcweft-build.ps1"
$quality='presentation-factory-execution-quality-20261101'
$run='presentation-factory-execution-focus5-20261101'
$terminal=Get-Content -LiteralPath "$taskTemp/$run.runtime.terminal-audit.json" -Raw | ConvertFrom-Json
if($terminal.actualExitCode -ne 0 -or $terminal.passed -ne 147 -or $terminal.sourceDrift -ne 0 -or $terminal.catalogCaseDrift -ne 0){throw 'Owner terminal is not passing'}
$gates=@(foreach($name in @('workspace-check','clippy','structure','fmt')){
    $record=Get-Content -LiteralPath "$taskTemp/$quality.$name.json" -Raw | ConvertFrom-Json
    if($record.exitCode -ne 0 -or $record.sourceDrift -ne 0){throw "Failed quality gate: $name"}
    [ordered]@{name=$name;record=$record}
})
$original=Get-Content -LiteralPath 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json' -Raw | ConvertFrom-Json
$changed=@($original.held | Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($changed.Count -ne 1 -or $changed[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or (git hash-object -- $changed[0].path).Trim() -ne '4df23c4afc860ca51ff3255befe87b69a16de39b'){throw 'Original WIP differs from its retained preservation proof'}
$untracked=@(git ls-files --others --exclude-standard)
if($untracked.Count -ne 6 -or @($untracked | Where-Object {$_ -notin @($original.held.path)}).Count){throw 'Unexpected untracked files'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath=Join-Path $evidence 'task-presentation-factory-progress-raw.zip'
$receiptPath=Join-Path $evidence 'task-presentation-factory-progress.json'
if((Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $receiptPath)){throw 'Immutable evidence already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
    $_.Name -like 'presentation-factory-abi-*-20261101*' -or
    $_.Name -like 'presentation-factory-execution-focus*-20261101*' -or
    $_.Name -like "$quality.*" -or
    $_.Name -like 'checkpoint-presentation-factory-abi.*' -or
    $_.Name -like 'checkpoint-presentation-factory-execution.*' -or
    $_.Name -in @('cargo-clean-user-request-20261101.json','presentation-factory-execution.reverse-closure.json','presentation-handle-contract.cli-preservation-proof.json','run-presentation-factory-execution-quality.ps1','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','record-presentation-factory-progress.ps1')
})+@(Get-ChildItem -LiteralPath "$taskTemp/$quality.structure-report" -File)
$files=@($files | Sort-Object FullName -Unique)
Add-Type -AssemblyName System.IO.Compression
$raw=@(foreach($file in $files){[ordered]@{name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try {for($index=0;$index -lt $files.Count;$index++){
    $entry=$archive.CreateEntry($raw[$index].name,[IO.Compression.CompressionLevel]::Optimal)
    $stream=$entry.Open()
    try {$bytes=[IO.File]::ReadAllBytes($files[$index].FullName);$stream.Write($bytes,0,$bytes.Length)} finally {$stream.Dispose()}
}} finally {$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {
    if($archive.Entries.Count -ne $raw.Count){throw 'Raw entry count differs'}
    foreach($row in $raw){$entry=$archive.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw "Raw entry differs: $($row.name)"}}
} finally {$archive.Dispose()}
$failures=@(foreach($stem in @('presentation-factory-abi-focus1-20261101','presentation-factory-abi-focus2-20261101','presentation-factory-execution-focus1-20261101','presentation-factory-execution-focus2-20261101','presentation-factory-execution-focus3-20261101','presentation-factory-execution-focus4-20261101')){
    $path="$taskTemp/$stem.runtime.terminal-audit.json"
    if(Test-Path -LiteralPath $path){Get-Content -LiteralPath $path -Raw | ConvertFrom-Json}else{Get-Content -LiteralPath "$taskTemp/$stem.catalog.json" -Raw | ConvertFrom-Json}
})
$receipt=[ordered]@{
    version=1;date='2026-11-01';status='Source image factory owner slice verified; whole presentation convergence remains in progress'
    publications=@(foreach($prefix in @('checkpoint-presentation-factory-abi','checkpoint-presentation-factory-execution')){Get-Content -LiteralPath "$taskTemp/$prefix.verified.json" -Raw | ConvertFrom-Json})
    owner=$terminal;quality=$gates
    graph=(Get-Content -LiteralPath "$taskTemp/presentation-factory-execution.reverse-closure.json" -Raw | ConvertFrom-Json)
    intermediateFailures=$failures
    coverage=@('Actual Source image factory in Native and canonical decoded AWBC, original retained product roles/key/type identity, argument evaluation order 12, exact Image/Root token family, completed owned result borrowed without detaching custody','AWBC snapshot and owned restore after every one-operation step','Original displaced token/body/type/invocation, live old-handle admission and rollback, full retirement queue rejects before body/cursor mutation','147 owner/related cases; 4052 source inputs; case, source and executable pins checked by retained runners')
    corrections=@('The initial Source tests attempted raw take_program_result for a presentation Handle. That API correctly rejects extraction without its ledger. Tests now inspect the actual completed borrowed result and also require the unchanged detached-custody rejection. Execution, source order, family and bank assertions remain mandatory.','Source execution failures exposed Native line-only projection and lexical/return custody bugs. Both were repaired through the shared presentation transition owner; no accepted feature was reopened.','The user explicitly requested another full cargo clean on 2026-11-01. This supersedes the earlier no-repeat working assumption; the earlier clean record is retained as history.')
    pendingAcceptance=@('Explicit scope capability producer and execution; public scope names never mint a grant','Retained View value producers, presentation commands and handle methods, driver integration','Complete aggregate construction/decoding preflight including future token/ledger metadata, all fibers and Source metadata policy before allocation','New-source full reverse-dependency and CLI runtime matrix; default/Wasm/doctest/Tier 2 and final image parity not rerun in this slice')
    structureDisposition='The callable catalogue owns operation/result/placement. Factory owns sealed retained-product layout and result type admission. Banks own displacement/retirement admission. Native and AWBC borrow genuine executable/scope owners and reuse the existing custody transition; format/let/match/return producers now carry actual escaping values. No second slot index or source reconstruction was added.'
    originalWip=[ordered]@{tracked=14;actualUntracked=6;unchangedOldHashes=19;benchWorkingBlob='4df23c4afc860ca51ff3255befe87b69a16de39b';benchSha256='133ae9de55b0bc7857420236b92148b8f104ac712d5c5903fcd2e0b36f01f0d7';heldPatchSha256='53b95c4ff3fb9ef6080f215b97cf7442033a1ff81f83da3ebe7db441b9d363b6';proof='presentation-handle-contract.cli-preservation-proof.json'}
    clean=(Get-Content -LiteralPath "$taskTemp/cargo-clean-user-request-20261101.json" -Raw | ConvertFrom-Json)
    raw=[ordered]@{path='task-presentation-factory-progress-raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$raw;entryCount=$raw.Count;entryDrift=0}
    recordedAt=[DateTime]::UtcNow.ToString('o')
}
$receipt | ConvertTo-Json -Depth 40 | Set-Content -LiteralPath $receiptPath -Encoding utf8
[ordered]@{source=$head;ownerPassed=$terminal.passed;rawEntries=$raw.Count;rawSha256=$receipt.raw.sha256;rawBytes=(Get-Item -LiteralPath $zipPath).Length;originalUntracked=$untracked.Count} | ConvertTo-Json
