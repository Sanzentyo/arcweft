#![allow(dead_code)]
#[path = "effect-lower-envelope.dev02.work-baseline.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod candidate;

use std::collections::BTreeSet;

macro_rules! measure {
    ($tree:ident, $width:expr, $layout:expr) => {{
        use $tree::{DecisionControl, DecisionWork, EffectDecision};
        struct Meter { visits: usize, nodes: usize }
        impl DecisionControl for Meter {
            type Error = std::convert::Infallible;

            fn charge(&mut self, work: DecisionWork) -> Result<(), Self::Error> {
                match work {
                    DecisionWork::Visit => self.visits += 1,
                    DecisionWork::Node => self.nodes += 1,
                }
                Ok(())
            }
        }
        let width: u32 = $width;
        let mut setup = Meter { visits: 0, nodes: 0 };
        let quantified: BTreeSet<_> = (1..=width).map(|local| 2 * local).collect();
        let mut relation = EffectDecision::constant(true);
        let shared = EffectDecision::variable(0, &mut setup).unwrap();
        for local in 1..=width {
            if $layout == "sparse" && local > 2 {
                break;
            }
            let output = EffectDecision::variable(2 * local, &mut setup).unwrap();
            let ambient = EffectDecision::variable(2 * local - 1, &mut setup).unwrap();
            let expected = match $layout {
                "branching" if local % 2 == 0 => shared.and(&ambient, &mut setup).unwrap(),
                "branching" => shared.or(&ambient, &mut setup).unwrap(),
                _ => shared.clone(),
            };
            let not_expected = expected.not(&mut setup).unwrap();
            let equation = output.conditional(&expected, &not_expected, &mut setup).unwrap();
            relation = relation.and(&equation, &mut setup).unwrap();
        }
        if $layout == "empty" {
            relation = EffectDecision::constant(false);
        }
        let mut meter = Meter { visits: 0, nodes: 0 };
        let completed = relation.complete_conditionally(&quantified, &mut meter).unwrap();
        (format!("{completed:?}"), meter.visits, meter.nodes)
    }};
}

fn main() {
    for width in [1, 2, 4, 8, 16] {
        for layout in ["shared", "branching", "sparse", "empty"] {
            let (before, old_visits, old_nodes) = measure!(baseline, width, layout);
            let (after, visits, nodes) = measure!(candidate, width, layout);
            assert_eq!(before, after, "{layout}, locals={width}");
            println!(
                "{layout:9} locals={width:2} visits={old_visits:6}->{visits:6} nodes={old_nodes:6}->{nodes:6}"
            );
        }
    }
}
