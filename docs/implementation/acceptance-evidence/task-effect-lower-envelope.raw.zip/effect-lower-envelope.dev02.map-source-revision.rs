use arcweft_source::{SourceDocument, SourceDocumentId, SourceName, SourceSetRevision};

fn document(id: &str, path: &str, source: &str) -> SourceDocument {
    SourceDocument::try_new(SourceDocumentId::try_new(id).unwrap(), SourceName::path(path), source)
        .unwrap()
}

fn main() {
    let baseline = [
        19, 70, 172, 142, 188, 99, 125, 150, 14, 57, 102, 89, 76, 68, 247, 229, 75, 89,
        223, 239, 172, 49, 211, 25, 233, 122, 178, 32, 65, 85, 249, 144,
    ];
    let candidate = [
        65, 100, 111, 216, 41, 5, 151, 141, 133, 229, 105, 166, 126, 23, 29, 144, 35, 130,
        97, 103, 128, 13, 143, 219, 83, 120, 88, 6, 144, 197, 246, 38,
    ];
    let cases = [
        ("Vec<i64>", "Vec<i64>", "vector"),
        ("Seq<i64>", "Seq<i64>", "sequence"),
        ("Array<i64, 3>", "Array<i64, 3>", "nonempty array"),
        ("Array<i64, 0>", "Array<i64, 0>", "empty array"),
        ("Slice<i64>", "Vec<i64>", "slice"),
        ("Option<i64>", "Option<i64>", "Some"),
        ("Option<i64>", "Option<i64>", "None"),
        ("Result<i64, String>", "Result<i64, String>", "Ok"),
        ("Result<i64, String>", "Result<i64, String>", "Err"),
    ];
    let manifest = document("arcweft-source://arcw.toml", "arcw.toml", "");
    let mut offset = 0;
    let mut baseline_hits = Vec::new();
    let mut candidate_hits = Vec::new();
    for (input_type, output_type, value) in cases {
        for (annotation, expression) in [
            ("", "values.map(increment)".to_owned()),
            ("#[pure]", "map(increment)(values)".to_owned()),
            (
                "#[pure]",
                format!(
                    "{{ let mapper: {input_type} -> {output_type} effects {{}} = map(increment); mapper(values) }}"
                ),
            ),
        ] {
            offset += 1;
            let source = format!(
                r#"
#[pure]
fn increment(item: i64) -> i64 {{ return item + 1i64 }}
{annotation}
pub fn root(values: {input_type}) -> {output_type} {{ {expression} }}
flow main() -> String {{ return "unused" }}
"#
            );
            let module = document("arcweft-source://src/main.arcw", "src/main.arcw", &source);
            let revision = SourceSetRevision::try_for_identities([module.identity(), manifest.identity()]).unwrap();
            if revision.as_bytes() == &baseline {
                baseline_hits.push(offset);
                println!("baseline={offset}/27 input={input_type} value={value} expression={expression} revision={}", revision.to_hex());
            }
            if revision.as_bytes() == &candidate {
                candidate_hits.push(offset);
                println!("candidate={offset}/27 input={input_type} value={value} expression={expression} revision={}", revision.to_hex());
            }
        }
    }
    assert_eq!(baseline_hits, [9]);
    assert_eq!(candidate_hits, [24, 27]); // Ok and Err have identical text; the first failing input is Ok.
}
