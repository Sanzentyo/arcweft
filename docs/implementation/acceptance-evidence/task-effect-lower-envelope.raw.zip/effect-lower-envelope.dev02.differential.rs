#![allow(dead_code)]
#[path = "effect-lower-envelope.dev02.work-baseline.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod candidate;

use std::collections::BTreeSet;

macro_rules! solve {
    ($owner:ident, $table:expr, $quantified:expr) => {{
        use $owner::{DecisionControl, DecisionWork, EffectDecision};

        struct Meter(usize);
        impl DecisionControl for Meter {
            type Error = std::convert::Infallible;
            fn charge(&mut self, _: DecisionWork) -> Result<(), Self::Error> {
                self.0 += 1;
                Ok(())
            }
        }

        let mut prepare = Meter(0);
        let mut level: Vec<_> = $table.iter().copied().map(EffectDecision::constant).collect();
        for variable in (0..7).rev() {
            let guard = EffectDecision::variable(variable, &mut prepare).unwrap();
            level = level.chunks_exact(2).map(|pair| {
                guard.conditional(&pair[1], &pair[0], &mut prepare).unwrap()
            }).collect();
        }
        let mut work = Meter(0);
        let result = level[0].complete_conditionally($quantified, &mut work).unwrap();
        (format!("{result:?}"), work.0)
    }};
}

fn main() {
    let mut seed = 0x16d_1de9_fc43_u64;
    let mut count = 0;
    let mut gains = 0;
    let mut ties = 0;
    let mut added_work = 0;
    for sample in 0..32 {
        let table: Vec<_> = (0..128).map(|slot| {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            match sample {
                0 => false,
                1 => true,
                2 => slot & 0b0100100 == 0,
                _ => seed & (1 << (sample % 63)) != 0,
            }
        }).collect();
        for quantifier_mask in [0, 1, 3, 6, 0b00001000, 0b01010101, 0b10101010, 127, 128, 255] {
            let quantified = (0..8).filter(|x| quantifier_mask & (1 << x) != 0).collect::<BTreeSet<_>>();
            let (expected, before) = solve!(baseline, table, &quantified);
            let (actual, after) = solve!(candidate, table, &quantified);
            assert_eq!(actual, expected, "sample={sample} mask={quantifier_mask:#010b}");
            count += 1;
            match after.cmp(&before) {
                std::cmp::Ordering::Less => gains += 1,
                std::cmp::Ordering::Equal => ties += 1,
                std::cmp::Ordering::Greater => added_work += 1,
            }
        }
    }
    println!("exact_outputs={count} fewer_charges={gains} equal_charges={ties} more_charges={added_work}");
}
