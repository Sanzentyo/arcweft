$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-project-within-group-20261111'
$pin=Get-Content -Raw -LiteralPath (Join-Path $d 'source.published.json')|ConvertFrom-Json
$q=Get-Content -Raw -LiteralPath (Join-Path $d 'quality-receipt.json')|ConvertFrom-Json
$plan=Get-Content -Raw -LiteralPath (Join-Path $d 'quality-plan.json')|ConvertFrom-Json
if(!$q.finished -or $q.source -cne $pin.source -or $q.results.Count -ne $plan.stages.Count+1 -or @($q.results|Where-Object exit -ne 0).Count){throw 'Incomplete quality evidence'}
if((git rev-parse HEAD) -cne $pin.source -or (git rev-parse origin/main) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only)){throw 'Published source changed'}
$totals=[ordered]@{pass=0;fail=0;skip=0}
foreach($row in $q.results){
    $file=Join-Path $d $row.log
    if((Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant() -cne $row.logSha256){throw "Validation log changed: $file"}
    if($row.totals){foreach($key in @('pass','fail','skip')){$totals[$key]+=$row.totals.$key}}
}
$entries=[ordered]@{}
$allowed=@('.log','.json','.stderr','.arcw','.ps1','.txt')
foreach($file in Get-ChildItem -LiteralPath $d -File){
    if($file.Extension -in $allowed -and $file.Name -notin @('archive-receipt.json','cargo-metadata.json','current-status-row.txt','history-section.txt')){$entries.Add($file.Name,$file.FullName)}
}
foreach($file in Get-ChildItem -LiteralPath (Join-Path $d 'first-run') -File){
    if($file.Extension -in $allowed){$entries.Add('first-run/'+$file.Name,$file.FullName)}
}
$value=Join-Path $env:TEMP 'arcweft-value-partial-20261111'
$prior=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$position=Join-Path $env:TEMP 'arcweft-within-group-model-20261111'
$extra=@(
    @('widened-parameter','closure-spread','immediate','twice','typed-parameter','triple-immediate','effects','direct-project','wide-effects','wide-effects-exact')|ForEach-Object {Join-Path $value "$_.arcw"}
)+@(
    Join-Path $prior 'explicit-effect-superset-curried.arcw'
    Join-Path $prior 'shared-default-explicit-callback-forward.arcw'
    Join-Path $position 'shared-generic-next-group.arcw'
    Join-Path $position 'shared-generic-same-group.arcw'
)
foreach($file in $extra){$entries.Add((Split-Path -Leaf $file),$file)}
foreach($entry in $entries.GetEnumerator()){
    if(!(Test-Path -LiteralPath $entry.Value -PathType Leaf)){throw "Missing evidence: $($entry.Key)"}
}
$archive=Join-Path (Resolve-Path -LiteralPath 'docs/implementation/acceptance-evidence').Path 'task-closed-declaration-positional-partial.raw.zip'
$stream=[IO.File]::Open($archive,[IO.FileMode]::CreateNew)
$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
try {
    foreach($entry in $entries.GetEnumerator()){
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$entry.Value,$entry.Key,[IO.Compression.CompressionLevel]::Optimal)
    }
}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try {
    if(Compare-Object @($entries.Keys) @($zip.Entries.FullName)){throw 'Archive contents differ'}
    foreach($entry in $entries.GetEnumerator()){
        $input=$zip.GetEntry($entry.Key).Open()
        try{
            $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($input))
            if($hash -cne (Get-FileHash -LiteralPath $entry.Value).Hash){throw "Archive hash mismatch: $($entry.Key)"}
        }finally{$input.Dispose()}
    }
}finally{$zip.Dispose()}
$receipt=[ordered]@{version=1;source=$pin.source;files=$entries.Count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();nextest=$totals;qualityStages=$q.results.Count;packages=$q.packages.Count;reusedSemaSource='988c09e9a59a9295a3f01f68c45c49500d87f732'}
$receipt|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $d 'archive-receipt.json') -Encoding utf8NoBOM
$receipt|ConvertTo-Json -Depth 7


