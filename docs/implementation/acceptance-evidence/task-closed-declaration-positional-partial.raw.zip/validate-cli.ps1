$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$d=Join-Path $env:TEMP 'arcweft-project-within-group-20261111'
$inputs=Join-Path $env:TEMP 'arcweft-value-partial-20261111'
$prior=Join-Path $env:TEMP 'arcweft-project-call-effects-20261111'
$position=Join-Path $env:TEMP 'arcweft-within-group-model-20261111'
$pin=Get-Content -Raw -LiteralPath (Join-Path $d 'source.local.json')|ConvertFrom-Json
$binary=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
function Hash([string] $Path){(Get-FileHash -LiteralPath $Path).Hash.ToLowerInvariant()}
$binaryHash=Hash $binary
function Confirm-Source {
    if((git rev-parse HEAD) -cne $pin.source -or (git diff --name-only) -or (git diff --cached --name-only) -or (Hash $binary) -cne $binaryHash){throw 'Source or executable drift'}
}
Confirm-Source
$cases=[ordered]@{}
foreach($name in @('widened-parameter','closure-spread','immediate','twice','typed-parameter','triple-immediate','direct-project')){
    $cases[$name]=@{input=(Join-Path $inputs "$name.arcw");logs=@()}
}
$cases['effects']=@{input=(Join-Path $inputs 'effects.arcw');logs=@('prefix','between','suffix','body')}
$cases['explicit-effect-superset-curried']=@{input=(Join-Path $prior 'explicit-effect-superset-curried.arcw');logs=@()}
$cases['shared-default-explicit-callback-forward']=@{input=(Join-Path $prior 'shared-default-explicit-callback-forward.arcw');logs=@('prefix','text','default','default')}
$cases['shared-generic-next-group']=@{input=(Join-Path $position 'shared-generic-next-group.arcw');logs=@()}
foreach($name in @('direct-immediate','direct-returned-explicit','bound-project')){
    $cases[$name]=@{input=(Join-Path $d "$name.arcw");logs=@()}
}
foreach($name in @('direct-effect-scalar','direct-effect-spread','closure-effect-spread-control')){
    $cases[$name]=@{input=(Join-Path $d "$name.arcw");logs=@('prefix','first','body','second','body')}
}
$cases['direct-mixed-prefix']=@{input=(Join-Path $d 'direct-mixed-prefix.arcw');logs=@('first','second','third','fourth','body')}
$results=foreach($name in $cases.Keys){
    foreach($executor in @('bytecode-vm','awbc-product')){
        Confirm-Source
        $case=$cases[$name]
        $output=Join-Path $d "$name.$executor.final.json"
        $stderr=Join-Path $d "$name.$executor.final.stderr"
        $argv=@('run',$case.input,'--runner','headless','--entry','entry.main','--executor',$executor,'--mode','one-op','--max-ops','1','--steps','512','--json')
        & $binary @argv 1> $output 2> $stderr
        $code=$LASTEXITCODE
        $r=Get-Content -Raw -LiteralPath $output|ConvertFrom-Json -AsHashtable
        $logs=if($r.steps.Count){@($r.steps[-1].observations.logs | ForEach-Object {$_.message})}else{@()}
        $max=($r.steps | ForEach-Object {$_.stats.executed_ops} | Measure-Object -Maximum).Maximum
        $violations=@($r.steps | Where-Object {$_.diagnostics.Count -or $_.assertion_failures.Count -or $_.assertion_diagnostics.Count})
        $ok=$code -eq 0 -and $r.final_status -ceq 'done Return("42")' -and $max -eq 1 -and ($logs -join '|') -ceq ($case.logs -join '|') -and !$violations.Count -and !$r.diagnostics.Count -and !(Get-Item -LiteralPath $stderr).Length
        [ordered]@{name=$name;executor=$executor;command=$argv;exit=$code;status=$r.final_status;stage=$r.stage;steps=$r.steps.Count;maxOps=$max;logs=$logs;diagnostics=$r.diagnostics;violations=$violations.Count;input=$case.input;inputSha256=Hash $case.input;reportSha256=Hash $output;verified=$ok}
    }
}
$negative=[ordered]@{
    'shared-generic-same-group'=(Join-Path $position 'shared-generic-same-group.arcw')
    'wide-effects'=(Join-Path $inputs 'wide-effects.arcw')
    'wide-effects-exact'=(Join-Path $inputs 'wide-effects-exact.arcw')
    'direct-variable-spread'=(Join-Path $d 'direct-variable-spread.arcw')
    'direct-named-short'=(Join-Path $d 'direct-named-short.arcw')
    'direct-returned'=(Join-Path $d 'direct-returned.arcw')
    'bound-returned-omitted'=(Join-Path $d 'bound-returned-omitted.arcw')
}
$checks=foreach($name in $negative.Keys){
    $input=$negative[$name]
    $output=Join-Path $d "$name.final.check.json"
    $stderr=Join-Path $d "$name.final.check.stderr"
    $argv=@('compile',$input,'--emit','check','--json')
    & $binary @argv 1> $output 2> $stderr
    $code=$LASTEXITCODE
    $r=Get-Content -Raw -LiteralPath $output|ConvertFrom-Json -AsHashtable
    [ordered]@{name=$name;command=$argv;exit=$code;status=$r.status;stage=$r.stage;diagnostics=$r.diagnostics;input=$input;inputSha256=Hash $input;reportSha256=Hash $output;expectedRejection=($code -eq 1 -and $r.stage -ceq 'type-check')}
}
Confirm-Source
[ordered]@{version=1;source=$pin.source;binarySha256=$binaryHash;executions=@($results);knownRejections=@($checks)} |
    ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $d 'cli-receipt.json') -Encoding utf8NoBOM
$results | ForEach-Object {"$($_.name) $($_.executor) exit=$($_.exit) status=$($_.status) max=$($_.maxOps) logs=$($_.logs -join ',') verified=$($_.verified)"}
$checks | ForEach-Object {"$($_.name) check exit=$($_.exit) stage=$($_.stage) expected=$($_.expectedRejection)"}
if(@($results | Where-Object {!$_.verified}).Count -or @($checks | Where-Object {!$_.expectedRejection}).Count){exit 1}
exit 0
