$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = 'f108dcc8d2a94b3fa94443ea46eedf1441778e22'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'completed-type-reification.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='Completed reification validates the exact operand origin and occurrence frames against the original graph, checks the same branch completion, then projects canonical algebra with its retained principal before reference transport. Canonical self-compatibility runs on completed canonical values. A reopened canonical solution is explicitly lifted into the prepared algebra before restoring its completed-origin operand. Future-result validation traverses the shared canonical grammar in the actual completed value scope, with each kind of Free port authorized only by that value capture and no active-path substitution or escaped inference identity. Unresolved grammar nodes and malformed lengths remain rejected, while authored omitted future rows retain their existing meaning. Reification, projection input and application sealing pass explicit original closure and graph loans. Test completion APIs no longer manufacture an implicit effect closure: callers must supply the bound original calculation, actual Future inputs or its real closed effects. The local malformed-scalar-row fixture freezes its actual original C with no effect queries or Future inputs. The other old fixture callers remain unmigrated, which raises test-target API diagnostics; no test or whole-target compilation success is claimed. Five new fixtures cover actual Named body output with an untouched unrelated body, missing Future input rejection and actual-value retry, rejection of a foreign completion for an equal type, refusal of receiver-only Free authority, and the completed value own type/const/effect ports, binders, omitted rows and malformed nodes. Test fault injection remains private. Production readers, branch metadata and actual source admission remain typed; no fake source context, source reconstruction, parallel type model, minimum solving or body re-preparation is introduced. The final transaction original-forest caller, full fixture migration, Fn-local quantified and guarded predicates, and frontend/public acceptance remain unfinished. Existing accepted Generic Match and runtime cuts are unchanged. Physical LOC, bytes, growth, test classification and inline test size are recorded for each owner. Cohesive completed-context transport owns scope/capture reification and validation. No Cargo dependency/feature, layer direction, I/O, unsafe, codec/version, production budget, jobs or profile change. Existing resolved Cargo graph and reverse-dependency evidence is reused; no workspace scanner or broad acceptance is claimed.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'completed-type-reification.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'completed-type-reification.'+$iteration+$suffix}})
$names+=@('completed-type-reification.source-publication.json','completed-type-reification.ownership-review.json','completed-type-reification.staged-review.json','completed-type-reification.dev02-diagnostic-review.json')
$names+=@('run-completed-type-reification-check.ps1','archive-completed-type-reification.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-completed-type-reification-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-completed-type-reification-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'completed-type-reification.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
