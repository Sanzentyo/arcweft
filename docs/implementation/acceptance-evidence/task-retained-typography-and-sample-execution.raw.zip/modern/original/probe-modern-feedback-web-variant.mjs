import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { createServer } from "node:http";
import { createRequire } from "node:module";
import { dirname, extname, join, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const output = resolve(process.argv[2] ?? dirname(fileURLToPath(import.meta.url)));
const root = resolve("web");
const { chromium } = createRequire(join(root, "package.json"))("playwright");
const { installManualLogicalClock, advanceLogicalClockSteps } = await import(
  pathToFileURL(join(root, "tests", "manual-logical-clock.mjs")).href
);
const wasm = join(root, "pkg", "arcweft_player_web_bg.wasm");
const bundle = await readFile(join(output, "modern-feedback-view.awfb"));
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const wasmHash = sha(await readFile(wasm));
const contentTypes = new Map([
  [".html", "text/html"], [".js", "application/javascript"], [".css", "text/css"],
  [".wasm", "application/wasm"], [".ttf", "font/ttf"], [".png", "image/png"],
]);
const server = createServer(async (request, response) => {
  const path = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
  if (path === "/favicon.ico") {
    response.writeHead(204).end();
    return;
  }
  if (path === "/validated-modern-feedback.awfb") {
    response.writeHead(200, { "content-type": "application/octet-stream" }).end(bundle);
    return;
  }
  const file = resolve(root, "." + path);
  if (!file.startsWith(root + sep)) {
    response.writeHead(400).end();
    return;
  }
  try {
    const bytes = await readFile(file);
    response.writeHead(200, { "content-type": contentTypes.get(extname(file)) }).end(bytes);
  } catch {
    response.writeHead(404).end();
  }
});
await new Promise((done) => server.listen(0, "127.0.0.1", done));
const browser = await chromium.launch({
  channel: process.env.ARW_PLAYWRIGHT_CHANNEL || "chrome",
  headless: true,
  args: ["--enable-unsafe-webgpu", "--use-angle=d3d11"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
page.on("console", (message) => {
  if (message.type() === "error") errors.push(message.text());
});
page.on("response", (response) => {
  if (response.status() >= 400) errors.push(response.status() + " " + response.url());
});
const checkpoints = [];
const changes = [];
async function snapshot() {
  return page.evaluate(() => ({
    runtime: window.__arcweftLastObservation,
    frame: window.__arcweftLastFrameObservation,
    fatal: window.__arcweftFatal,
  }));
}
function inventory(state) {
  return (state.frame?.text ?? []).map(({ text, visible_text, owner }) => ({
    text, visible_text, id: owner?.semantic_id, bounds: owner?.object_bounds,
  }));
}
async function capture(name) {
  const state = await snapshot();
  assert(!state.fatal, JSON.stringify(state.fatal));
  assert.equal(state.frame?.image_count, 1);
  const png = await page.locator("#arcweft-canvas").screenshot({ path: join(output, "web-" + name + ".png") });
  await writeFile(join(output, "web-" + name + ".json"), JSON.stringify(state));
  checkpoints.push({ name, tick: state.runtime.logical_tick, pngSha256: sha(png), text: inventory(state) });
}
async function reach(text, maxInputs = 8) {
  for (let i = 0; i <= maxInputs; i++) {
    const state = await snapshot();
    assert(!state.fatal, JSON.stringify(state.fatal));
    if (inventory(state).some((row) => row.text.includes(text))) return;
    if (i === maxInputs || !state.runtime?.dialogue) {
      assert.fail("cannot reach " + text + " from " + JSON.stringify(inventory(state)));
    }
    await page.keyboard.press("Enter");
    changes.push(await advanceLogicalClockSteps(page, 4));
  }
}
async function clickText(text) {
  const rows = inventory(await snapshot());
  const row = rows.find((item) => item.text === text);
  assert(row?.bounds, "missing rendered target " + text + ": " + JSON.stringify(rows));
  assert(row.bounds.width_milli > 0 && row.bounds.height_milli > 0);
  const canvas = await page.locator("#arcweft-canvas").boundingBox();
  await page.mouse.click(
    canvas.x + (row.bounds.x_milli + row.bounds.width_milli / 2) / 1000,
    canvas.y + (row.bounds.y_milli + row.bounds.height_milli / 2) / 1000,
  );
  changes.push(await advanceLogicalClockSteps(page, 4));
}
async function typeText(text) {
  await page.keyboard.type(text);
  changes.push(await advanceLogicalClockSteps(page, 4));
  assert(inventory(await snapshot()).some((row) => row.text.includes(text)), "input not rendered: " + text);
}
try {
  await installManualLogicalClock(page);
  const url = new URL("http://127.0.0.1:" + server.address().port + "/index.html");
  url.searchParams.set("bundle", "./validated-modern-feedback.awfb");
  url.searchParams.set("fonts", "./assets/arcweft-demo.ttf");
  await page.goto(url.href);
  await page.waitForFunction(() => Boolean(window.__arcweftFatal) ||
    Boolean(window.__arcweftLastFrameObservation?.text?.length), null, { timeout: 10_000 });
  await page.locator("#arcweft-canvas").focus();
  assert.equal(await page.locator("input, textarea, [contenteditable], button").count(), 0);
  await reach("Welcome to the Modern Feedback View");
  await capture("opening");
  await reach("Your name");
  await capture("name-panel");
  await clickText("Your name");
  await typeText("Ada");
  await clickText("Continue");
  await reach("Nice to meet you");
  assert(inventory(await snapshot()).some((row) => row.text.includes("Ada")));
  await capture("name-action");
  await reach("Write one sharp product idea");
  await capture("brief-panel");
  await clickText("Draft saved");
  assert(inventory(await snapshot()).some((row) => row.text === "Send brief"));
  await clickText("Write one sharp product idea");
  await typeText("Arc");
  await page.keyboard.press("Enter");
  changes.push(await advanceLogicalClockSteps(page, 4));
  await typeText("weave");
  await clickText("Send brief");
  await reach("Captured the view-backed brief");
  assert(inventory(await snapshot()).some((row) => row.text.includes("Arc\nweave")));
  await capture("brief-action");
  await reach("Welcome to the Modern Feedback View");
  await capture("loop-return");
  assert.deepEqual(errors, []);
  assert.equal(sha(await readFile(wasm)), wasmHash);
  console.log(JSON.stringify({ ok: true, bundleSha256: sha(bundle), wasmSha256: wasmHash, checkpoints, changes }));
} catch (error) {
  await writeFile(join(output, "web-failure.json"), JSON.stringify({ error: error.message, state: await snapshot(), checkpoints, errors }));
  throw error;
} finally {
  await browser.close();
  await new Promise((done) => server.close(done));
}
