$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='scope-termination-admission-20261107'
$sourceBase=(&git rev-parse HEAD).Trim()
$paths=@('crates/arcweft-core/src/awbc/tests.rs','crates/arcweft-core/src/awbc/tests/scope_termination.rs')
$inputPaths=@((Get-Content "$taskTemp/awbc-flow-transfer-custody-20261107.source-freeze.json" -Raw|ConvertFrom-Json).paths.path + $paths | Sort-Object -Unique)
$inputRows=@(foreach($path in $inputPaths){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
[ordered]@{version=1;base=$sourceBase;paths=$inputRows}|ConvertTo-Json -Depth 6|Set-Content "$taskTemp/$prefix.source-freeze.json" -Encoding utf8
$filter='test(/raw_(return|completion)_requires_all_lexical_scopes_to_exit_before_admission/)'
$listArgs=@('nextest','list','--locked','-p','arcweft-core','--lib','-E',$filter,'--message-format','json')
$started=[DateTime]::UtcNow
& cargo @listArgs > "$taskTemp/$prefix.list.json" 2> "$taskTemp/$prefix.list.stderr.log"
$code=$LASTEXITCODE
[ordered]@{version=1;arguments=$listArgs;exitCode=$code;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.list.receipt.json" -Encoding utf8
if($code){exit $code}
$list=Get-Content "$taskTemp/$prefix.list.json" -Raw|ConvertFrom-Json -Depth 100
$selected=@(foreach($binary in $list.'rust-suites'.PSObject.Properties){foreach($test in $binary.Value.testcases.PSObject.Properties){if($test.Value.'filter-match'.status -eq 'matches'){$test.Name}}})
if($selected.Count -ne 2){throw 'Rejection test selection is not exactly the two intended cases'}
foreach($check in @(
 @{name='owner';arguments=@('nextest','run','--locked','-p','arcweft-core','--lib','-E',$filter,'--no-tests','fail','--no-fail-fast')},
 @{name='clippy';arguments=@('clippy','--locked','-p','arcweft-core','--all-targets','--all-features')}
)){
 $started=[DateTime]::UtcNow;$arguments=$check.arguments
 & cargo @arguments *> "$taskTemp/$prefix.$($check.name).log"
 $code=$LASTEXITCODE
 $drift=@($inputRows|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
 $summary=@(Select-String -LiteralPath "$taskTemp/$prefix.$($check.name).log" -Pattern 'Summary \['|ForEach-Object {$_.Line})
 [ordered]@{version=1;sourceBase=$sourceBase;arguments=$arguments;exitCode=$code;sourceInputs=$inputRows.Count;sourceDrift=$drift;selectedTests=$selected;summary=$summary;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 6|Set-Content "$taskTemp/$prefix.$($check.name).receipt.json" -Encoding utf8
 Write-Output ($check.name+': exit '+$code+'; drift '+$drift)
 if($code -ne 0 -or $drift){exit 1}
}
& rustfmt --edition 2024 --config skip_children=true --check @paths *> "$taskTemp/$prefix.fmt.log"
$code=$LASTEXITCODE
[ordered]@{version=1;paths=$paths;exitCode=$code}|ConvertTo-Json -Depth 4|Set-Content "$taskTemp/$prefix.fmt.receipt.json" -Encoding utf8
exit $code
