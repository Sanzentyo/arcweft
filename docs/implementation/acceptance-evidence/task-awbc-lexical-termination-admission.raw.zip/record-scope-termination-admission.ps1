$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='scope-termination-admission-20261107'
$source=Get-Content "$taskTemp/$prefix.source.verified.json" -Raw|ConvertFrom-Json
if((&git rev-parse HEAD).Trim() -ne $source.commit){throw 'Test source is not current main'}
$quality=[ordered]@{}
foreach($name in @('owner','clippy','fmt')){
 $receipt=Get-Content "$taskTemp/$prefix.$name.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or ($name -ne 'fmt' -and $receipt.sourceDrift -ne 0)){throw "Unfinished gate $name"}
 $quality[$name]=$receipt
}
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Tested inputs changed'}
$previous=Get-Content "$taskTemp/awbc-flow-transfer-custody-20261107.source-freeze.json" -Raw|ConvertFrom-Json
$productionDrift=@($previous.paths|Where-Object {$_.path -ne 'crates/arcweft-core/src/awbc/tests.rs' -and (Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
if($productionDrift){throw 'Unexpected production or fixture change'}
$names=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*"|ForEach-Object {$_.Name})
$names+=@('run-scope-termination-admission.ps1','record-scope-termination-admission.ps1')
$names=@($names|Sort-Object -Unique)
$zipPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-awbc-lexical-termination-admission.raw.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Archive already exists'}
Compress-Archive -LiteralPath @($names|ForEach-Object {"$taskTemp/$_"}) -DestinationPath $zipPath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{foreach($entry in $archive.Entries){$row=$entries|Where-Object entry -eq $entry.FullName;$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($row.bytes -ne $entry.Length -or $row.sha256 -ne $hash){throw 'Archive entry mismatch'}};if($archive.Entries.Count -ne $entries.Count){throw 'Archive entry count mismatch'}}finally{$archive.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-07';source=$source
 scope='Prove the existing lexical termination admission contract; remove an erroneous remaining-work category without changing runtime behavior.'
 cases=@('Return and implicit Unit Complete with one or two open emitted scopes are rejected as ScopeDiscipline before execution. Product admission rejects the same artifacts.';'After only the inner of two scopes exits, verification still rejects termination.';'Once every required ExitScope is present, verification, canonical codec roundtrip and Product admission succeed for both terminators.')
 quality=$quality
 corrections=@('An open-scope raw Return was listed as remaining implementation work. It is invalid IR under the existing verifier contract, not an admitted Source return whose cleanup is missing. No new runtime return state is needed.';'Remove only that erroneous clause from the three earlier evidence limits and the later historical/current enumeration. Keep all actual run results, failures, commit SHAs and immutable raw archives. The earlier limited-run statements are not a current backlog.';'Source-level return cleanup is already exercised by the preceding compiler scoped_defer run of 30 passing cases, including nested return values and a waiting callback, in Native and saved decoded AWBC. These two new tests concern artifact admission and are a separate run.';'Production, fixture and Cargo inputs are unchanged. Reuse the completed 53-package matrix and workspace checks at b6df0c825805b9ac77cad6a9760761a861007679; do not add these two tests to its 7962-case count. Native, Line/init and Generic Match remain accepted.')
 correctedHistoricalLimitFields=@('ordinaryFlowDeferredRegistry.limits','valueBlockTrailingWriteStatements.limits','flowTransferInvocationUnwind.limits')
 reusedEvidence=[ordered]@{source='b6df0c825805b9ac77cad6a9760761a861007679';publication='db8f2dfece59fe4a434f0a419391bfa2dace49c8';productionFixtureCargoDrift=0;matrix=[ordered]@{run=7962;passed=7958;failed=4;skipped=41};compilerOwner=30;coreDoctests=80}
 raw=[ordered]@{path='task-awbc-lexical-termination-admission.raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$entries}
}
$jsonPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($jsonPath)
if($before.Contains('"awbcLexicalTerminationAdmission"')){throw 'Duplicate correction record'}
if([regex]::Matches($before,[regex]::Escape(', direct AWBC return from open scopes')).Count -ne 2 -or [regex]::Matches($before,[regex]::Escape('direct raw AWBC return from open scopes, ')).Count -ne 1){throw 'Historical limits differ from reviewed correction'}
$corrected=$before.Replace(', direct AWBC return from open scopes','').Replace('direct raw AWBC return from open scopes, ','')
$fragment=([ordered]@{awbcLexicalTerminationAdmission=$record}|ConvertTo-Json -Depth 80).Trim().Replace("`r`n","`n")
$last=$corrected.LastIndexOf('}')
$after=$corrected.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($jsonPath,$after,[Text.UTF8Encoding]::new($false))
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
if([regex]::Matches($history,[regex]::Escape('直接 raw AWBC return、')).Count -ne 1){throw 'Historical enumeration differs'}
$history=$history.Replace('直接 raw AWBC return、','')
$addition=@"

## 2026-11-07 — raw Return／Complete の scope admission と誤列挙の訂正

Test Source **$($source.commit)** を既存 main に通常 commit/push。1段・2段の lexical scope を開いた Return／Unit Complete は、既存 verifier の ScopeDiscipline と Product admission の両方で拒否する。2段の内側だけを閉じても拒否し、全 ExitScope 後は verifier・canonical codec 往復・Product admission が成功した。追加2件は PASS、Core全target／全feature Clippyと2 path fmtも終了0。元12 tracked／6 untracked WIPを保持した。
「開いた scope からの raw AWBC return」を実装残作業とした列挙は、不正成果物の拒否契約を実行未対応と取り違えていたため削除した。現在の一覧、直前の履歴文、過去3 recordのlimitsから当該句だけを削除し、この訂正理由を残す。実際の結果・失敗・full SHA・既存raw ZIPは保持する。正常Source returnのcleanup／戻り値／待機は前cutのNative／保存付きAWBC 30件の証拠を再利用し、追加2件と合算しない。
実装・fixture・Cargo入力は前cutから変更0。Core全53逆依存7962件（7958 PASS／4 FAIL／41 SKIP）とworkspace gate・Core doctest80件は Source b6df0c825805b9ac77cad6a9760761a861007679 の同一入力の実測を維持する。今回のtest-only cutの新規全件runとは表示しない。Native／Line-init／Generic Matchの既受入を維持する。[全実測・訂正対象・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
if([regex]::Matches($status,[regex]::Escape('直接 raw AWBC の開いた scope からの return、')).Count -ne 1){throw 'Current enumeration differs'}
$status=$status.Replace('直接 raw AWBC の開いた scope からの return、','').Replace('元 CLI 入力でも完全な log 順序を検証したため、','raw Return／Complete は open scope を verifier と Product admission が拒否し、全 ExitScope 後を受理する。元 CLI 入力でも完全な log 順序を検証したため、')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$contractPath='D:/git/arcweft/docs/05-build-and-security/product-awfb-bytecode.md'
$contract=[IO.File]::ReadAllText($contractPath)
$anchor='## Original program Source'
if(!$contract.Contains($anchor)){throw 'Contract anchor missing'}
$paragraph=@'
Before `Return` or implicit Unit `Complete`, emitted bytecode closes each open
lexical scope with `ExitScope`. Verification and Product admission reject a
terminator that leaves any such scope open. Source-level returns wait for their
registered cleanup under the [block-scope contract](../01-language/block-scopes.md).

'@
$contract=$contract.Replace($anchor,$paragraph.Replace("`r`n","`n")+"`n"+$anchor).Replace("`r`n","`n")
[IO.File]::WriteAllText($contractPath,$contract,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;entries=$entries.Count;rawSha256=$record.raw.sha256;productionFixtureCargoDrift=$productionDrift}|ConvertTo-Json -Depth 5
