param([Parameter(Mandatory)][string]$Iteration)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$evidenceDir = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$prefix = Join-Path $evidenceDir ('callable-callback-owner.' + $Iteration)
foreach ($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')) {
    if (Test-Path -LiteralPath ($prefix + $suffix)) { throw "Evidence exists: $prefix$suffix" }
}
$env:CARGO_INCREMENTAL = '0'
cargo fmt -p arcweft-lang-sema *> ($prefix + '-fmt-apply.log')
$applyExit = $LASTEXITCODE
cargo fmt -p arcweft-lang-sema -- --check *> ($prefix + '-fmt-check.log')
$fmtExit = $LASTEXITCODE
@{apply_exit=$applyExit; check_exit=$fmtExit} | ConvertTo-Json | Set-Content -LiteralPath ($prefix + '-fmt-result.json') -Encoding utf8NoBOM
if ($applyExit -ne 0 -or $fmtExit -ne 0) { throw 'Format failed' }
$inputPaths = @(git diff HEAD --name-only -- '*.rs')
$manifest = @{base=(git rev-parse HEAD); started=(Get-Date -Format o); incremental=$env:CARGO_INCREMENTAL; command='cargo check --locked -p arcweft-lang-sema --tests --all-features'; paths=@($inputPaths | ForEach-Object { @{path=$_; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath ($prefix + '-input.json') -Encoding utf8NoBOM
cargo check --locked -p arcweft-lang-sema --tests --all-features *> ($prefix + '-check.log')
$checkExit=$LASTEXITCODE
$lines = Get-Content -LiteralPath ($prefix + '-check.log')
$terminal = @($lines | Select-Object -Last 12)
$summary = @($lines | Where-Object { $_ -match '^error: could not compile `arcweft-lang-sema`' })
@{exit=$checkExit; finished=(Get-Date -Format o); terminal=$terminal; summary=$summary; fmt_exit=$fmtExit} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath ($prefix + '-result.json') -Encoding utf8NoBOM
foreach($file in $manifest.paths) {
    if ((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256) { throw "Input changed: $($file.path)" }
}
@{exit=$checkExit; summary=$summary; fmt_exit=$fmtExit; paths=$manifest.paths.Count} | ConvertTo-Json -Depth 3
