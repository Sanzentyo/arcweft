$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '6e771e92df957537783a57d592aa4f65766a4bd3'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'callable-callback-owner.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='CandidateConstraintCallbacks owns the actual accounting-context loan, prepared callable authority, client, callback issuer, next ordinal and active checkpoint identity together. The open driver retains its inference transaction and this callback owner; duplicate callback state and implementations are removed. Probe and materialization begin/close logic, exact-once client closure, source/fatal validation, retained work and opaque comparison share the same owner. Driver finish first closes its actual lower transaction under a real graph loan, then consumes it into ConstraintMaterialization and runs the common callback owner; it never constructs another inference transaction to consume canonical values. PreparedConstraintAuthority exposes a consuming canonical materialize_component entry that validates the actual client graph against both the callable authority and the completed owner lease. The loan ends before every callback and is checked again before each next ticket. Operational failures are retained by the canonical owner; the real client finish is still attempted and lower preparation failures keep precedence. Original open-path cycle diagnostics are moved into the canonical result owner during consuming phase transfer; closed original members no longer pass a separate placeholder cycle argument. The old driver materialize loop, callback operations and direct fields are deleted. Existing protocol, cancellation, foreign ticket/checkpoint, cleanup and source-identity fixtures now address the same callback owner without lowering assertions. Existing real original-member fixtures call the consuming manager finish with its owned diagnostics. There are no new test IDs in this cut. Initial extraction accidentally changed CandidateConstraintSourceContext fields in specialization, and the failed target check is retained; the final source limits the migration to the actual driver context. Required Sema target checks still fail at old eager closure and frontend/fixture migrations, so tests, final frontend switch, actual original-product callback dispatch and broad body-once/public acceptance remain unfinished. The new canonical entry is implemented but not public acceptance evidence. Existing root inline tests are measured separately, including pub(crate) visibility. The cohesive callback protocol belongs to its actual state owner, not arbitrary file-size partitions. No fake open source, initialization seed, graph, Future default, body replay, parallel final model, dependency/feature, facade, layer reversal, I/O, unsafe, codec/version, budget/jobs/profile change is introduced. No comprehensive allocation/copy, single-pass, performance, compilation or workspace success claim is made. Accepted Generic Match/runtime receipts and unchanged resolved graph/reverse-dependency evidence are retained; scanner and broad gates are unrun.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'callable-callback-owner.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'callable-callback-owner.'+$iteration+$suffix}})
$names+=@('callable-callback-owner.source-publication.json','callable-callback-owner.ownership-review.json','callable-callback-owner.staged-review.json','callable-callback-owner.dev03-diagnostic-review.json')
$names+=@('run-callable-callback-owner-check.ps1','archive-callable-callback-owner.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-callable-callback-owner-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-callable-callback-owner-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'callable-callback-owner.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
