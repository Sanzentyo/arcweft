$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$prefix = 'line-initial-inputs-20261108'
$migration = Get-Content "$taskTemp/$prefix.migration.verified.json" -Raw | ConvertFrom-Json
$source = Get-Content "$taskTemp/$prefix.receiver-fix.verified.json" -Raw | ConvertFrom-Json
$required = @('core', 'runtime-plan', 'compiler', 'clippy', 'docs')
foreach ($name in $required) {
    $receipt = Get-Content "$taskTemp/$prefix.owner-quality-r7.$name.receipt.json" -Raw | ConvertFrom-Json
    if ($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0) { throw "Owner check is not accepted: $name" }
}
$compilerLog = [IO.File]::ReadAllText("$taskTemp/$prefix.owner-quality-r7.compiler.log")
foreach ($name in @(
    'native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line',
    'saved_awbc_ordinary_flow_defer_reexports_an_actor_through_its_nested_line',
    'native_initial_copy_line_input_remains_available_in_its_caller',
    'saved_awbc_initial_copy_line_input_remains_available_in_its_caller'
)) {
    if ($compilerLog -notmatch ('PASS[^\r\n]*ordinary_defer::' + [regex]::Escape($name))) { throw "Missing actual acceptance: $name" }
}
$epoch = Get-Content "$taskTemp/$prefix.owner-quality-r7.source.json" -Raw | ConvertFrom-Json
foreach ($row in $epoch.inputs) {
    if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Changed source requires reconciliation: $($row.path)" }
}
$ledgerPath = 'docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger = [IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if ($ledger.Contains('"selectedInitialLineInputs"')) { throw 'Evidence already recorded' }
$runs = @(foreach ($file in Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*.receipt.json" | Sort-Object Name) {
    $receipt = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
    $logPath = $file.FullName.Replace('.receipt.json', '.log')
    $summary = $null
    if (Test-Path -LiteralPath $logPath) {
        $log = [IO.File]::ReadAllText($logPath)
        $found = [regex]::Matches($log, 'Summary \[[^\]]+\][^\r\n]*')
        if ($found.Count) { $summary = $found[$found.Count - 1].Value }
    }
    [ordered]@{ receiptFile = $file.Name; receipt = $receipt; actualSummary = $summary }
})
$review = Get-Content "$taskTemp/$prefix.ownership-review-r2.json" -Raw | ConvertFrom-Json -Depth 12
$archivePath = 'docs/implementation/acceptance-evidence/task-selected-line-inputs.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Archive already exists' }
$names = @(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*" | ForEach-Object Name) + @(
    'record-selected-line-inputs-20261108.ps1',
    'run-line-input-owner-check-20261108.ps1',
    'run-line-input-owner-check-r2-20261108.ps1',
    'run-line-input-owner-check-r3-20261108.ps1',
    'run-line-input-owner-check-r4-20261108.ps1',
    'run-line-input-owner-check-r5-20261108.ps1',
    'run-line-input-owner-check-r6-20261108.ps1',
    'run-line-input-owner-check-r7-20261108.ps1',
    'review-line-input-owners-20261108.ps1',
    'review-line-input-owners-r2-20261108.ps1'
) | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object { Join-Path $taskTemp $_ }) -DestinationPath $archivePath -CompressionLevel Optimal
$entries = @(foreach ($name in $names) {
    [ordered]@{ entry = $name; bytes = (Get-Item -LiteralPath "$taskTemp/$name").Length; sha256 = (Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant() }
})
$zip = [IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try {
    if ($zip.Entries.Count -ne $entries.Count) { throw 'Archive entry count differs' }
    foreach ($entry in $zip.Entries) {
        $expected = $entries | Where-Object entry -eq $entry.FullName
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256) { throw 'Archive entry differs' }
    }
} finally { $zip.Dispose() }
$record = [ordered]@{
    version = 1; date = '2026-11-08'; migration = $migration; source = $source
    status = 'Accepted for the named Actor re-export and caller-preserving Copy conditions, not full goal acceptance.'
    implementation = @(
        'Sema selects one whole-binding Copy/Move in the caller and gives the Line its independent initialized input frame.'
        'Core LineTaskGroup and Source retain explicit initial reads. Factories authenticate the complete free-input set; post-reveal shared inputs are derived separately.'
        'The AWBC activation function alone owns the positional initial ABI. Group shared inputs name actual typed root registers; no duplicate source-local capture catalog remains.'
        'Native prepared environments and AWBC selected operand packets admit all inputs before any Move. Copy retains the actual caller source; the receiving frame owns its transferred input.'
        'Actual pending Dialogue packet coordinates and activation-qualified Native local slots enter custody reconciliation and saved admission. Active frames no longer clone and retain initial payloads in another capture field.'
        'Copy admission uses producer proofs and input requirements, including function values, rather than a blanket carrier-type blacklist. All Arcweft contract markers remain 1.'
    )
    acceptance = @(
        'The same returned Actor moves into an ordinary defer, into its Cleanup Line, out to the receiver and into another nested defer on Native and saved AWBC.'
        'Copy String inputs remain usable in the original caller and are returned on both backends.'
        'Actor acquisition/release counts, two reveals, original log order, one-op execution and the original 512-step bound are unchanged. AWBC performs public JSON save and cold restore after each step.'
        'Source round trips preserve Copy/Move and distinct executable digests. Missing/duplicate/foreign seeds, duplicate encoded inputs and invalid mode tags are refused.'
    )
    validation = [ordered]@{
        finalEpoch = "$prefix.owner-quality-r7.source.json"; sourceInputs = $epoch.inputs.Count
        coreSourceOwner = '11 PASS, 2316 selected-out; this is not a fresh complete Core run.'
        coreDevelopment = 'The complete 2327-case development run passed 2325 and failed only the two new fixture cases, corrected and passed by the later selected Source owner run. Earlier 2325-case runs and compile errors remain distinct history.'
        runtimePlan = '165 PASS, 1 existing ignored fixture generator SKIP; includes public API compile-fail checks.'
        compiler = '146 PASS across evaluated_effects (116) and scoped_defer (30), 0 SKIP.'
        clippy = 'Core, RuntimePlan, Sema and Compiler: all targets/all features, exit 0; warnings retained.'
        docs = 'Core doctests, actual result retained in the raw log.'
        structure = Get-Content "$taskTemp/$prefix.structure.receipt.json" -Raw | ConvertFrom-Json
        ownership = $review
        remainingMatrix = 'Core reverse closure 53 and final workspace all-target/all-feature matrix are still pending for the new shared contract.'
        heldTrackedWip = 12; heldUntrackedWip = 6
    }
    corrections = @(
        'Delete the current claim that initial inputs and shared inputs remain undivided, because the published owning schemas now separate them.'
        'Delete the old current Native AffineGroupCapture and AWBC Copy-only ABI failures only for the same Actor re-export input, now passing on both backends.'
        'Keep every original command, failed/partial run, full commit SHA and archive. Do not recast 113/114/116-case catalogs or selected runs as a single rerun.'
        'The intermediate 9a99 checkpoint was published under the explicit user instruction permitting unchecked intermediate commits. The receiver fix follows at e5b5; no unrelated WIP was staged.'
        'Generic Match, Line/init, bounded Native acceptance and accepted ordinary defer/Dialogue behavior remain accepted. Overall goal incompletion does not reopen them.'
    )
    runs = $runs
    raw = [ordered]@{ path = 'task-selected-line-inputs.raw.zip'; sha256 = (Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant(); entries = $entries }
}
$fragment = ([ordered]@{ selectedInitialLineInputs = $record } | ConvertTo-Json -Depth 70).Trim().Replace("`r`n", "`n")
$last = $ledger.LastIndexOf('}')
$after = $ledger.Substring(0, $last).TrimEnd() + ",`n  " + $fragment.Substring(1, $fragment.Length - 2).Trim() + "`n}`n"
$null = $after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath), $after, [Text.UTF8Encoding]::new($false))
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$history = [IO.File]::ReadAllText((Join-Path (Get-Location) $historyPath))
$addition = @"

## 2026-11-08 — Line の初期所有入力と表示後の共有入力

Source **$($migration.commit)** と受信元修正 **$($source.commit)** を既存 main へ通常 commit/push し、親・tree・全 blob・完全差分を照合した。Sema が選ぶ全 binding の Copy／Move を Core／Source／AWBC の実 activation ABI に保持し、表示後に実際に使う共有 Copy 入力を分離した。AWBC は全 operand の検査と Copy 準備を終えてから Move する。Native は子の物理 slot と元 publisher の受信 execution を区別する。実待機 packet／activation frame を custody へ入れ、初期 payload の複製保持欄と旧入力 catalog を除去した。契約 version は1を維持する。

元の Actor 再返却は Native／毎 step 公開 JSON 保存・cold restore AWBC で PASS。Copy String の caller 再利用も両実行器で PASS。取得・解放各1回、2 reveal、元 log 順序、1-op／512-step を維持する。最終 Source owner 11 PASS／2316 選択外、RuntimePlan 165 PASS／既存 generator 1 SKIP、Compiler の evaluated_effects116＋scoped_defer30 は146 PASS／0 SKIP。Core・RuntimePlan・Sema・Compiler の全target／全feature Clippy は終了0。Core 全2327件の開発 run は2325 PASS／新規 fixture2 FAILで、その2件を後の選択runで修復確認した。全件の再実行に合算しない。中間3 PASS／1 FAIL、Core compile error、旧 slot／codec offset と fixture namespace の失敗も raw 原本へ保持する。

同じ元入力が通ったことを理由に、現状の「未分離」、Native AffineGroupCapture、AWBC Copy 専用 ABI 拒否を削除した。既受入の Generic Match／Line-init／Native／通常 defer／子 Dialogue を戻さない。全 Core53／workspace 最終matrix と範囲外の受入をこの検証へ合算しない。[全入力別結果・訂正・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIP は$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText((Join-Path (Get-Location) $historyPath), $history.TrimEnd() + "`n" + $addition.Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$statusPath = 'docs/implementation/current-status.md'
$status = [IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$oldRow = @($status -split "`n" | Where-Object { $_.StartsWith('| 通常 Flow の scoped defer |') })
if ($oldRow.Count -ne 1 -or -not $oldRow[0].Contains('初期所有Line入力')) { throw 'Current row differs' }
$newRow = '| 通常 Flow の scoped defer | **既受入を保持。defer内Dialogue・取消しをNative／保存AWBC、失敗継続を保存AWBCで検証・公開済み。全体受入は継続中** | 関数本体・明示scopeのLIFO、generic捕捉／戻り値、registry読書き・drop／置換、cleanup後のgoto／Choice移譲、失敗caller drain、待機、open scopeのraw Return／Complete拒否を検証済み。返却Actorの直接・tuple・入れ子捕捉とfilter解放を維持する。Source 4a6d9c3eb1ceb83f16718cf2a97be13519389b62 は実defer子fiberへ対話の開始・公開・継続を接続。通常終了・取消し、実待機activationの公開status、失敗時の子／caller cleanup、受信slot改変の拒否と元状態保全を確認した。AWBCは毎step version 1公開JSON保存／cold restore。初期所有入力は次行へ分け、解消した旧拒否と旧全件runの数値は履歴へ保持する。全取消し・登録／子構築前の集約検査は継続中。必須registry読取りには静的存在証明が必要。[実測・訂正理由・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$inputRow = '| Line の初期所有入力 | **返却ActorとCopy入力の対象条件を検証・公開済み** | Source ' + $source.commit + '（型／codec移行 ' + $migration.commit + '）。初期入力の選択Copy／Moveと表示後の共有Copy入力を分離し、実待機packetから実activation frameへ一度だけ所有を移す。通常defer内LineからActorを再返却する元入力と、Copy Stringをcallerで再利用する4条件がNative／保存AWBCでPASS。1-op／512-step、2 reveal、取得・解放各1回とlog順を維持。Sourceの往復・実行identity・欠落／重複／foreign／不正mode拒否を含む11件、RuntimePlan165件、Compiler対象146件がPASS。元入力の未分離・入口／verifier拒否はこの具体的根拠で現状から削除した。Core53／workspace最終matrixと他の未確認条件は合算しない。[型契約・各run・訂正・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status = $status.Replace($oldRow[0], $newRow + "`n" + $inputRow)
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath), $status, [Text.UTF8Encoding]::new($false))
[ordered]@{ source = $source.commit; archiveEntries = $entries.Count; archiveSha256 = $record.raw.sha256 } | ConvertTo-Json -Compress
