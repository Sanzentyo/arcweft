$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$verified = Get-Content "$PSScriptRoot/line-initial-inputs-20261108.migration.verified.json" -Raw | ConvertFrom-Json
$metadata = Get-Content "$PSScriptRoot/function-scope-20261107.metadata-all.json" -Raw | ConvertFrom-Json -Depth 60
$packages = @{}
foreach ($package in $metadata.packages) { $packages[$package.id] = $package }
$core = ($metadata.packages | Where-Object name -eq 'arcweft-core').id
$closure = [Collections.Generic.HashSet[string]]::new()
$null = $closure.Add($core)
do {
    $added = $false
    foreach ($node in $metadata.resolve.nodes) {
        if (-not $closure.Contains($node.id) -and @($node.deps | Where-Object { $closure.Contains($_.pkg) }).Count) {
            $null = $closure.Add($node.id)
            $added = $true
        }
    }
} while ($added)
$workspace = @($closure | Where-Object { $_ -in $metadata.workspace_members } | ForEach-Object { $packages[$_].name } | Sort-Object)
$paths = Get-Content "$PSScriptRoot/line-initial-inputs-20261108.migration.owned.txt" | Where-Object { $_ -like '*.rs' }
$rows = @(foreach ($path in $paths) {
    $old = & git show "$($verified.parent):$path"
    [ordered]@{
        path = $path
        bytes = (Get-Item -LiteralPath $path).Length
        physicalLoc = [IO.File]::ReadAllLines((Join-Path (Get-Location) $path)).Length
        baseLoc = @($old).Count
        classification = if ($path -match '/tests(/|\.rs$)' -or $path -like '*/tests.rs') { 'test' } else { 'production; embedded tests retain their owner' }
    }
})
[ordered]@{
    version = 1
    commit = $verified.commit
    trackedHeld = 12
    cargoChanged = @(git diff "$($verified.parent)" --name-only -- '*Cargo*').Count
    metadataSource = 'function-scope-20261107.metadata-all.json'
    metadataWorkspace = $metadata.workspace_members.Count
    coreReversePackages = $workspace
    coreReverseCount = $workspace.Count
    files = $rows
    dispositions = @(
        'Core LineTaskGroup owns selected initial transfers and derived shared inputs. Source preserves modes and factory authentication; no parallel capture catalog or legacy reader remains.'
        'AWBC activation function signature/input ownership alone owns initial inputs. Shared inputs name actual root registers. The slot algebra owns real packet/frame coordinates and canonical binary/JSON projections.'
        'Sema ownership flow keeps caller move facts and independent Line initialization in one graph. RuntimePlan consumes its checked capture decisions directly.'
        'Native environments and AWBC prepared register transfers preflight the entire selected packet before moves. Existing execution/dialogue/scope modules retain state transitions and tests; Core acquires no I/O.'
        'Existing large interpreter, verifier and slot files remain cohesive closed state/grammar owners; visibility is not widened to split files. Final scanner and broad reverse matrix remain pending.'
    )
} | ConvertTo-Json -Depth 8 | Set-Content "$PSScriptRoot/line-initial-inputs-20261108.ownership-review.json"
cargo tree --locked --workspace --all-features --target all --invert arcweft-core *> "$PSScriptRoot/line-initial-inputs-20261108.reverse-tree.log"
if ($LASTEXITCODE -ne 0) { throw 'Reverse graph failed' }
[ordered]@{ reverse = $workspace.Count; files = $rows.Count } | ConvertTo-Json -Compress
