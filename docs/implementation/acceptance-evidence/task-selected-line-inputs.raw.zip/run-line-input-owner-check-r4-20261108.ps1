$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix=Join-Path $PSScriptRoot 'line-initial-inputs-20261108.owner-quality-r4'
$epoch=Get-Content "$prefix.source.json" -Raw | ConvertFrom-Json
function Assert-Inputs {
 foreach($row in $epoch.inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
}
function Run-Cargo([string]$name,[string[]]$arguments){
 if(Test-Path "$prefix.$name.receipt.json"){throw "Receipt exists: $name"}
 Assert-Inputs
 $started=[DateTime]::UtcNow
 & cargo @arguments *> "$prefix.$name.log"
 $code=$LASTEXITCODE
 Assert-Inputs
 [ordered]@{arguments=$arguments;exitCode=$code;sourceInputs=$epoch.inputs.Count;sourceDrift=0;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 6 | Set-Content "$prefix.$name.receipt.json"
 Get-Content "$prefix.$name.log" -Tail 15
 if($code -ne 0){throw "Required owner check failed: $name ($code)"}
}
Run-Cargo 'core' @('nextest','run','--locked','-p','arcweft-core','--lib','--no-tests','fail','--no-fail-fast')
Run-Cargo 'runtime-plan' @('nextest','run','--locked','-p','arcweft-runtime-plan','--no-tests','fail','--no-fail-fast')
Run-Cargo 'compiler' @('nextest','run','--locked','-p','arcweft-compiler','--test','evaluated_effects','--test','scoped_defer','--no-tests','fail','--no-fail-fast')
Run-Cargo 'clippy' @('clippy','--locked','-p','arcweft-core','-p','arcweft-runtime-plan','-p','arcweft-lang-sema','-p','arcweft-compiler','--all-targets','--all-features')
Run-Cargo 'docs' @('test','--locked','-p','arcweft-core','--doc')