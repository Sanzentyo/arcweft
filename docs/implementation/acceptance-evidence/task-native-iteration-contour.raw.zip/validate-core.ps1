param(
    [Parameter(Mandatory)]
    [string]$Source
)
$ErrorActionPreference = 'Stop'
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_TERM_COLOR = 'never'
$env:NO_COLOR = '1'
$scratch = Split-Path -Parent $PSCommandPath
function Assert-PinnedSource {
    if ((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $Source) {
        throw 'Validation source changed.'
    }
    if (@(git diff --name-only $Source --).Count -or @(git diff --cached --name-only $Source --).Count) {
        throw 'Tracked validation inputs changed.'
    }
}
function Invoke-Validation {
    param([string]$Name, [string]$Program, [string[]]$Arguments)
    Assert-PinnedSource
    $log = Join-Path $scratch "$Name.log"
    $started = Get-Date -Format o
    Write-Output "Running $Name"
    & $Program @Arguments *> $log
    $code = $LASTEXITCODE
    Assert-PinnedSource
    $summary = @(Select-String -LiteralPath $log -Pattern '^error|^ *Finished|^ *Summary \[' |
        Select-Object -Last 10 -ExpandProperty Line)
    [ordered]@{
        version = 1
        source = $Source
        command = @($Program) + $Arguments
        exit = $code
        started = $started
        finished = Get-Date -Format o
        summary = $summary
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $scratch "$Name.result.json") -Encoding utf8NoBOM
    $summary
    Write-Output "Finished $Name with $code"
}
$selection = @('-E', 'rdeps(=arcweft-core)', '--no-fail-fast', '--no-tests', 'fail', '--status-level', 'all')
Invoke-Validation 'core-workspace-check' cargo @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Validation 'core-workspace-clippy' cargo @('clippy','--locked','--workspace','--all-targets','--all-features')
Invoke-Validation 'core-reverse' cargo (@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli') + $selection)
Invoke-Validation 'core-cli' cargo (@('nextest','run','--locked','-p','arcweft-cli','--lib','--bins') + $selection)
Invoke-Validation 'core-cli-fixtures' cargo (@('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens') + $selection)
Invoke-Validation 'core-structure' just @('structure-audit-gate')


