param([Parameter(Mandatory)][string]$Source)
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $PSCommandPath
if ((git rev-parse HEAD) -ne $Source) { throw 'CLI check Source changed' }
$fixture = Join-Path $dir 'loop-return-defer-zero.arcw'
$cli = (Resolve-Path target/debug/arcw.exe).Path
$expected = Get-Content (Join-Path $dir 'baseline-cli-cases.json') -Raw | ConvertFrom-Json -Depth 100
$states = foreach ($case in $expected.cases) {
    $tier = $case.tier
    $output = Join-Path $dir "cli-$tier.json"
    & $cli run --runner headless --executor $tier --entry entry.main --steps 512 --max-ops 1 --json $fixture > $output
    $exit = $LASTEXITCODE
    $result = Get-Content -LiteralPath $output -Raw | ConvertFrom-Json -Depth 100
    $actual = [ordered]@{
        tier=$tier
        exit=$exit
        status=$result.final_status
        steps=$result.steps.Count
        maxOps=($result.steps.stats.executed_ops | Measure-Object -Maximum).Maximum
        diagnostics=($result.steps.stats.diagnostics | Measure-Object -Sum).Sum
        logs=$result.steps[-1].observations.logs.message
    }
    if ($actual.exit -ne 0 -or $actual.status -ne $case.status -or $actual.steps -ne $case.steps -or $actual.maxOps -ne 1 -or $actual.diagnostics -ne 0 -or (Compare-Object $case.logs $actual.logs -SyncWindow 0)) {
        throw "CLI execution differs for $tier"
    }
    $actual
}
[ordered]@{version=1;source=$Source;cli_sha256=(Get-FileHash -LiteralPath $cli).Hash.ToLowerInvariant();cases=@($states)} |
    ConvertTo-Json -Depth 5 | Tee-Object -FilePath (Join-Path $dir 'cli-cases.json')
