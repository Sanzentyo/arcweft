$ErrorActionPreference = 'Stop'
$scratch = Split-Path -Parent $PSCommandPath
function Read-FailedTests([string]$Path) {
    $pattern = '^\s*(FAIL|TIMEOUT|LEAK|EXECFAIL) \[\s*[^\]]+\]\s*\([^)]*\)\s+(?<id>arcweft-.+)$'
    @(Select-String -LiteralPath $Path -Pattern $pattern | ForEach-Object {
        $_.Matches[0].Groups['id'].Value.Trim()
    } | Sort-Object -Unique)
}
$reference = Join-Path $env:LOCALAPPDATA 'Temp/arcweft-native-iterator-resume-20261123/core-reverse.log'
$base = @(Read-FailedTests $reference)
$actual = @(Read-FailedTests (Join-Path $scratch 'core-reverse.log'))
$old = @($actual | Where-Object {$_ -in $base})
$new = @($actual | Where-Object {$_ -notin $base})
$missing = @($base | Where-Object {$_ -notin $actual})
[ordered]@{
    version=1
    source=(Get-Content (Join-Path $scratch 'core-reverse.result.json') -Raw | ConvertFrom-Json).source
    previous_source='bed0dc40a6a0d967fbc0a4491043952d5201ab7f'
    previous_evidence='task-native-for-restore-admission.raw.zip'
    known_failure_ids=$old
    different_failure_ids=$new
    previous_failures_not_reproduced=$missing
} | ConvertTo-Json -Depth 6 | Tee-Object -FilePath (Join-Path $scratch 'same-scope-failure-comparison.json')

