$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='D:\git\arcweft'
$archivePath=Join-Path $repo 'docs/implementation/acceptance-evidence/task-original-producer-context.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Frozen archive already exists'}
$publication=Get-Content -Raw "$root/original-context.publication.json" | ConvertFrom-Json
$pin=Get-Content -Raw "$root/original-context.input.json" | ConvertFrom-Json
$focus=Get-Content -Raw "$root/original-context.focused-final.json" | ConvertFrom-Json
$clippy=Get-Content -Raw "$root/original-context.clippy.json" | ConvertFrom-Json
if((git rev-parse HEAD) -ne $publication.Source -or @(git diff --name-only HEAD).Count -or !$focus.PinsVerified -or $focus.ExitCode -ne 0 -or !$clippy.PinsVerified -or $clippy.ExitCode -ne 0){throw 'Context evidence prerequisites failed'}
foreach($record in $pin.Paths){if((Get-FileHash -LiteralPath $record.Path -Algorithm SHA256).Hash -ne $record.SHA256){throw 'Context input changed'}}
$events=@(Get-Content "$root/original-context.final-results.jsonl" | ForEach-Object {$_ | ConvertFrom-Json})
$terminal=@($events | Where-Object {$_.type -eq 'test' -and $_.event -in @('ok','failed','ignored')})
if($terminal.Count -ne 37 -or @($terminal | Where-Object event -ne 'ok').Count -or @($terminal | Group-Object name | Where-Object Count -gt 1).Count){throw 'Focused context cases differ'}
$files=@(Get-ChildItem -LiteralPath $root -File | Where-Object Name -Like 'original-context.*')
$files+=Get-Item "$root/make-original-context-archive.ps1"
$entries=@($files | Sort-Object FullName -Unique | ForEach-Object { [pscustomobject]@{Path=[IO.Path]::GetRelativePath($root,$_.FullName).Replace('\','/');Bytes=$_.Length;SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Parent=$publication.Parent;Focused=@{Selected=37;Passed=37;Failed=0;Duplicates=0;FilterExcludedNotRun=1548;NewContextCases=3};Clippy=@{Package='arcweft-lang-sema';Locked=$true;AllTargets=$true;AllFeatures=$true;ExitCode=0;WarningsRetained=$true};Environment=@{CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false};RootConsumerMigrationNotYetImplemented=$true;PreviousFullRunSource='217f927d7282d73cc3d91b1045c933f2c83c08c2';Entries=$entries}
$manifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($manifest | ConvertTo-Json -Depth 10))
Add-Type -AssemblyName System.IO.Compression
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite)
try {
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try {
        foreach ($record in $entries) {
            $entry=$zip.CreateEntry($record.Path,[IO.Compression.CompressionLevel]::Optimal)
            $target=$entry.Open()
            try {
                $bytes=[IO.File]::ReadAllBytes((Join-Path $root $record.Path))
                if ($bytes.Length -ne $record.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $record.SHA256) { throw 'Evidence changed while archiving' }
                $target.Write($bytes,0,$bytes.Length)
            } finally { $target.Dispose() }
        }
        $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal)
        $target=$entry.Open()
        try { $target.Write($manifestBytes,0,$manifestBytes.Length) } finally { $target.Dispose() }
    } finally { $zip.Dispose() }
} finally { $stream.Dispose() }
$verified=0
$rawBytes=0L
$read=[IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($read.Entries.Count -ne ($entries.Count+1)) { throw 'Archive entry count differs' }
    foreach ($entry in $read.Entries) {
        $inputStream=$entry.Open()
        $memory=[IO.MemoryStream]::new()
        try { $inputStream.CopyTo($memory); $bytes=$memory.ToArray() } finally { $inputStream.Dispose(); $memory.Dispose() }
        $expected=if ($entry.FullName -eq 'manifest.json') {
            [pscustomobject]@{Bytes=$manifestBytes.Length;SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($manifestBytes)).ToLowerInvariant()}
        } else { @($entries | Where-Object Path -CEQ $entry.FullName)[0] }
        if ($bytes.Length -ne $expected.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $expected.SHA256) { throw "Archive readback mismatch: $($entry.FullName)" }
        $rawBytes+=$bytes.Length
        $verified++
    }
} finally { $read.Dispose() }
[ordered]@{Version=1;Source=$publication.Source;Path=$archivePath;Entries=$verified;RawBytes=$rawBytes;Bytes=(Get-Item -LiteralPath $archivePath).Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();AllEntriesReadbackVerified=$true;ManifestVerified=$true} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/original-context.archive.json"
Get-Content "$root/original-context.archive.json"
