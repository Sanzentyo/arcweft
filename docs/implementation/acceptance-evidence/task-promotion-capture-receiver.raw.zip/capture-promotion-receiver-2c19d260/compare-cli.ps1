
$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-capture-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
$qa=Get-Content -LiteralPath (Join-Path $d 'quality.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$before=Get-Content -LiteralPath (Join-Path $d 'baseline.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$second=Get-Content -LiteralPath (Join-Path $d 'post-cli-baseline.receipt.json') -Raw|ConvertFrom-Json -AsHashtable
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($sha -ne $qa.cliSha256 -or $sha -in $before.cliSha256,$second.cliSha256 -or $before.source -ne $second.source){throw 'Baseline or changed artifact differs'}
git diff --quiet $before.source $qa.base -- 'crates/**' Cargo.toml Cargo.lock
if($LASTEXITCODE){throw 'Reviewed source changed since CLI baseline'}
$borrowed=@(
 'borrowed-capture','borrowed-capture-alias','borrowed-capture-direct','structural-capture',
 'borrowed-capture-transitive','borrowed-capture-proof','borrowed-capture-block',
 'borrowed-capture-conditional','borrowed-capture-match','borrowed-capture-if-let',
 'borrowed-capture-implicit','continuation-borrowed','continuation-two-prefixes'
)
function ReadArcResult($name,$command,$source,$expected){
    $out=Join-Path $d "$name.$command.after.json"
    $err=Join-Path $d "$name.$command.after.stderr.log"
    if($command -eq 'verify'){
        & $cli verify $source --mode test --backend emit --json > $out 2> $err
    }else{
        & $cli check $source --json > $out 2> $err
    }
    $code=$LASTEXITCODE
    $report=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json -AsHashtable
    $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
    if($code -ne 1 -or $report.status -ne 'denied' -or $report.stage -ne 'type-check' -or $diagnostics.Count -ne 1 -or $diagnostics[0].code -ne $expected -or $report.obligations -or $report.solver_checks){throw "Unexpected $name $command result $($diagnostics.code -join ',')"}
    $span=$diagnostics[0].span
    $spelling=(Get-Content -LiteralPath $source -Raw).Substring($span.start,$span.end-$span.start)
    if($expected -eq 'sema.lifetime.promotion_receiver'){
        $receiver=switch($name){
            'borrowed-capture-direct' {'^\(?\|\| -> i64 \{ let _ = loan; 42i64 \}\)?$'}
            'borrowed-capture-alias' {'^alias$'}
            'borrowed-capture-transitive' {'^outer$'}
            default {'^callback$'}
        }
        if($spelling -notmatch $receiver){throw "Unexpected $name receiver span $spelling"}
    }elseif($spelling -notmatch '\.promote\('){throw "Unexpected $name execution span $spelling"}
    [ordered]@{name=$name;command=$command;exit=$code;stage=$report.stage;code=$diagnostics[0].code;span=$spelling;inputSha256=ArcSha $source;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
}
$inputs=@(@($before.cases)+@($second.cases)|Where-Object stage -eq 'type-check')
$results=@(foreach($row in $inputs){
    $source=Join-Path $d "$($row.name).arcw"
    if((ArcSha $source) -ne $row.inputSha256){throw "Baseline input drift $($row.name)"}
    $expected=if($row.name -in $borrowed){'sema.lifetime.promotion_receiver'}else{'sema.lifetime.promotion_execution'}
    ReadArcResult $row.name 'check' $source $expected
    if($row.name -in 'borrowed-capture-proof','continuation-two-prefixes','terminal-owned'){
        ReadArcResult $row.name 'verify' $source $expected
    }
})
if($results.Count -ne 23 -or (ArcSha $cli) -ne $sha){throw 'CLI receipt differs'}
[ordered]@{version=1;base=$qa.base;cliSha256=$sha;cases=$results}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
$results|ForEach-Object {[pscustomobject]$_}|Format-Table name,command,code,span
