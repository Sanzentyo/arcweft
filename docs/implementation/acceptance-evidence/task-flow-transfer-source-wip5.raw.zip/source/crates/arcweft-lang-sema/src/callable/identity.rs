//! Validated callable scalar, path, provider, and candidate identities.
//!
//! This module intentionally keeps the closed callable identity hierarchy in
//! one place: family IDs feed `CallableCandidateId`, and their constructors
//! share the same scalar/path invariants. It contains no resolver execution or
//! embedded tests. The file is slightly above the structural-audit warning
//! threshold, but splitting one hierarchy across responsibility modules would
//! make the exact identity contract harder to audit without reducing a mixed
//! responsibility.

pub use arcweft_manifest_model::StandardEnvironmentId;

/// How an admitted catalog definition supplies its callee at an application.
/// The checked declaration identity and its schema are identical in both modes.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CatalogCallableDispatch {
    Direct,
    Value,
}

impl CatalogCallableDispatch {
    pub(crate) const fn requires_value_callee(self) -> bool {
        matches!(self, Self::Value)
    }

    /// Version-one stable callable identity constructors. Existing direct
    /// catalog bytes stay unchanged; value dispatch has its own constructor.
    pub(crate) const fn canonical_identity_tag(self) -> u8 {
        match self {
            Self::Direct => 0,
            Self::Value => 4,
        }
    }
}

use std::sync::Arc;

use arcweft_lang_hir::{
    identity::ExprId,
    symbol::{
        CallableDeclarationKey, CallableDeclarationOwner, CallablePackageId, ProjectSymbolRevision,
        ProjectSymbolWorldId,
    },
};
use arcweft_lang_syntax::ast::module_path::CanonicalModulePath;
use arcweft_presentation::{
    fx::FxSourceConstructor, rich_text::PresentationContentCallableDefinitionId,
};
use arcweft_rich_text_schema::RichTextCallableSchemaDigest;
use arcweft_source::{SourceDocumentIdentity, SourceSpan};

use crate::types::{SemanticTypeDigest, StandardMapFamily, TypeKind};

use super::{
    BuiltinIdentityError, CallableIdentityError, CallableIndexKind, CallableLimits,
    CallablePathError, CallableScalarError, CallableScalarKind, PRODUCTION_CALLABLE_LIMITS,
    RegisteredCallableCatalogDigest,
};

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CallableName(Arc<str>);

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct AdapterPackageId(Arc<str>);

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RustItemPath(Arc<str>);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CallableGroupIndex(u16);
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CallableParameterIndex(u16);
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CallableOverloadIndex(u16);
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CallableArgumentSlotIndex(u16);
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct FunctionValueOrdinal(u32);

impl CallableName {
    pub fn try_new(value: impl Into<Arc<str>>) -> Result<Self, CallableScalarError> {
        let value = value.into();
        validate_scalar(&value, CallableScalarKind::CallableName, |character| {
            matches!(
                character,
                '.' | ':' | '/' | '\\' | '(' | ')' | '[' | ']' | '{' | '}'
            )
        })?;
        Ok(Self(value))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl AdapterPackageId {
    pub fn try_new(value: impl Into<Arc<str>>) -> Result<Self, CallableScalarError> {
        let value = value.into();
        if value.is_empty() {
            return Err(CallableScalarError::Empty {
                kind: CallableScalarKind::AdapterPackageId,
            });
        }
        for (byte, character) in value.char_indices() {
            if character.is_control() {
                return Err(CallableScalarError::Control {
                    kind: CallableScalarKind::AdapterPackageId,
                    byte,
                });
            }
            if character.is_whitespace() || matches!(character, '/' | '\\' | ':' | '@') {
                return Err(CallableScalarError::ContainsSeparator {
                    kind: CallableScalarKind::AdapterPackageId,
                    byte,
                    separator: character,
                });
            }
        }
        Ok(Self(value))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl RustItemPath {
    pub fn try_new(value: impl Into<Arc<str>>) -> Result<Self, CallableScalarError> {
        let value = value.into();
        validate_scalar(&value, CallableScalarKind::RustItemPath, |_| false)?;
        Ok(Self(value))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

fn validate_scalar(
    value: &str,
    kind: CallableScalarKind,
    separator: impl Fn(char) -> bool,
) -> Result<(), CallableScalarError> {
    if value.is_empty() {
        return Err(CallableScalarError::Empty { kind });
    }
    for (byte, character) in value.char_indices() {
        if character.is_control() {
            return Err(CallableScalarError::Control { kind, byte });
        }
        if separator(character) {
            return Err(CallableScalarError::ContainsSeparator {
                kind,
                byte,
                separator: character,
            });
        }
    }
    Ok(())
}

impl CallableGroupIndex {
    pub(crate) const ZERO: Self = Self(0);

    pub fn try_from_usize(value: usize) -> Result<Self, CallableScalarError> {
        u16::try_from(value)
            .map(Self)
            .map_err(|_| CallableScalarError::IndexOverflow {
                kind: CallableIndexKind::Group,
                value,
            })
    }
    pub const fn get(self) -> usize {
        self.0 as usize
    }
}
impl CallableParameterIndex {
    pub fn try_from_usize(value: usize) -> Result<Self, CallableScalarError> {
        u16::try_from(value)
            .map(Self)
            .map_err(|_| CallableScalarError::IndexOverflow {
                kind: CallableIndexKind::Parameter,
                value,
            })
    }
    pub const fn get(self) -> usize {
        self.0 as usize
    }
}
impl CallableOverloadIndex {
    pub fn try_from_usize(value: usize) -> Result<Self, CallableScalarError> {
        u16::try_from(value)
            .map(Self)
            .map_err(|_| CallableScalarError::IndexOverflow {
                kind: CallableIndexKind::Overload,
                value,
            })
    }
    pub const fn get(self) -> usize {
        self.0 as usize
    }
}
impl CallableArgumentSlotIndex {
    pub fn try_from_usize(value: usize) -> Result<Self, CallableScalarError> {
        u16::try_from(value)
            .map(Self)
            .map_err(|_| CallableScalarError::IndexOverflow {
                kind: CallableIndexKind::ArgumentSlot,
                value,
            })
    }
    pub const fn get(self) -> usize {
        self.0 as usize
    }
}
impl FunctionValueOrdinal {
    pub fn try_from_usize(value: usize) -> Result<Self, CallableScalarError> {
        u32::try_from(value)
            .map(Self)
            .map_err(|_| CallableScalarError::IndexOverflow {
                kind: CallableIndexKind::FunctionValue,
                value,
            })
    }
    pub const fn get(self) -> usize {
        self.0 as usize
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CallablePath {
    segments: Arc<[CallableName]>,
}

impl CallablePath {
    pub fn try_new(
        segments: impl IntoIterator<Item = CallableName>,
    ) -> Result<Self, CallablePathError> {
        Self::try_new_with_limits(segments, &PRODUCTION_CALLABLE_LIMITS)
    }

    pub(crate) fn try_new_with_limits(
        segments: impl IntoIterator<Item = CallableName>,
        limits: &CallableLimits,
    ) -> Result<Self, CallablePathError> {
        let segments = segments.into_iter().collect::<Vec<_>>();
        if segments.is_empty() {
            return Err(CallablePathError::Empty);
        }
        if segments.len() > limits.max_path_segments() {
            return Err(CallablePathError::TooManySegments {
                actual: segments.len(),
                limit: limits.max_path_segments(),
            });
        }
        Ok(Self {
            segments: segments.into(),
        })
    }

    pub fn segments(&self) -> &[CallableName] {
        &self.segments
    }
    /// Returns the final segment of this validated non-empty path.
    ///
    /// # Panics
    ///
    /// Panics only if an internal invariant is violated; public constructors reject empty paths.
    pub fn leaf(&self) -> &CallableName {
        self.segments
            .last()
            .expect("validated non-empty callable path")
    }
    #[allow(
        clippy::len_without_is_empty,
        reason = "CallablePath is non-empty by construction"
    )]
    pub fn len(&self) -> usize {
        self.segments.len()
    }

    /// Returns the canonical dotted source spelling of this validated path.
    pub fn dotted_name(&self) -> String {
        self.segments
            .iter()
            .map(CallableName::as_str)
            .collect::<Vec<_>>()
            .join(".")
    }

    pub(crate) fn matches(&self, segments: &[&str]) -> bool {
        self.segments.len() == segments.len()
            && self
                .segments
                .iter()
                .zip(segments)
                .all(|(actual, expected)| actual.as_str() == *expected)
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct ReceiverMethodKey {
    receiver: TypeKind,
    method: CallableName,
}

impl ReceiverMethodKey {
    pub fn new(receiver: TypeKind, method: CallableName) -> Self {
        Self { receiver, method }
    }
    pub const fn receiver(&self) -> &TypeKind {
        &self.receiver
    }
    pub const fn method(&self) -> &CallableName {
        &self.method
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum CallableLookupKey {
    Free(CallablePath),
    Method(ReceiverMethodKey),
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ProjectCallablePath {
    package: CallablePackageId,
    module: CanonicalModulePath,
    path: CallablePath,
}

impl ProjectCallablePath {
    pub fn new(
        package: CallablePackageId,
        module: CanonicalModulePath,
        path: CallablePath,
    ) -> Self {
        Self {
            package,
            module,
            path,
        }
    }
    pub const fn package(&self) -> &CallablePackageId {
        &self.package
    }
    pub const fn module(&self) -> &CanonicalModulePath {
        &self.module
    }
    pub const fn path(&self) -> &CallablePath {
        &self.path
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum ProjectNameBinding {
    Callable(CallableDeclarationKey),
    AmbiguousCallables {
        declarations: Arc<[CallableDeclarationKey]>,
    },
    Environment(EnvironmentCallableId),
    NonCallable {
        path: ProjectCallablePath,
        ty: TypeKind,
    },
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum EnvironmentCallableOwner {
    Standard(StandardEnvironmentId),
    Adapter(AdapterPackageId),
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum EnvironmentCallableKind {
    Function,
    Method,
    RustFunction,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct EnvironmentCallableId {
    owner: EnvironmentCallableOwner,
    kind: EnvironmentCallableKind,
    key: CallableLookupKey,
    overload: CallableOverloadIndex,
    canonical: Arc<[u8]>,
}

/// Durable digest of one structural environment callable identity.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct EnvironmentCallableDigest([u8; 32]);

impl Ord for EnvironmentCallableId {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.canonical_identity_bytes()
            .cmp(&other.canonical_identity_bytes())
    }
}

impl PartialOrd for EnvironmentCallableId {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl EnvironmentCallableId {
    pub fn try_new(
        owner: EnvironmentCallableOwner,
        kind: EnvironmentCallableKind,
        key: CallableLookupKey,
        overload: CallableOverloadIndex,
    ) -> Result<Self, crate::types::GenericScopeError> {
        let canonical =
            super::digest::environment_identity_bytes(&owner, kind, &key, overload)?.into();
        Ok(Self {
            owner,
            kind,
            key,
            overload,
            canonical,
        })
    }

    /// The owning constructor has already validated and encoded the identity.
    /// Ordering and hashing never reevaluate an arbitrary receiver type.
    pub(crate) fn canonical_identity_bytes(&self) -> &[u8] {
        &self.canonical
    }
    pub const fn owner(&self) -> &EnvironmentCallableOwner {
        &self.owner
    }
    pub const fn kind(&self) -> EnvironmentCallableKind {
        self.kind
    }
    pub const fn key(&self) -> &CallableLookupKey {
        &self.key
    }
    pub const fn overload(&self) -> CallableOverloadIndex {
        self.overload
    }

    /// Returns the canonical durable digest for Agent and persistence
    /// projections. Accepted catalog generation belongs to
    /// [`CheckedCallableId`], not this structural declaration identity.
    #[must_use]
    pub fn semantic_digest(&self) -> EnvironmentCallableDigest {
        let mut hasher = blake3::Hasher::new();
        hasher.update(b"arcweft.environment-callable-id.v1\0");
        hasher.update(&self.canonical_identity_bytes());
        EnvironmentCallableDigest(*hasher.finalize().as_bytes())
    }
}

impl EnvironmentCallableDigest {
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    pub const fn into_bytes(self) -> [u8; 32] {
        self.0
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CallableAuthorityRank {
    Project,
    Standard,
    Adapter,
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum CallableProviderId {
    Project(CallablePackageId),
    Standard(StandardEnvironmentId),
    Adapter(AdapterPackageId),
}

impl EnvironmentCallableOwner {
    pub const fn authority(&self) -> CallableAuthorityRank {
        match self {
            Self::Standard(_) => CallableAuthorityRank::Standard,
            Self::Adapter(_) => CallableAuthorityRank::Adapter,
        }
    }
    pub fn provider(&self) -> CallableProviderId {
        match self {
            Self::Standard(id) => CallableProviderId::Standard(*id),
            Self::Adapter(id) => CallableProviderId::Adapter(id.clone()),
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum LanguageDocumentationFamily {
    Builtin,
    Fx,
    Agent,
    Presentation,
    Collection,
    Domain,
    Integer,
    Capacity,
    Trait,
    Constructor,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum VectorDimensions {
    Two,
    Three,
    Four,
}
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum MathCallableId {
    MatMulF32,
    MatrixAddF32,
    MatMulF64,
    MatrixAddF64,
    TensorAddF32,
    TensorAddF64,
}
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum FloatWidth {
    F32,
    F64,
}
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum StdFloatOperation {
    Abs,
    Floor,
    Ceil,
    Round,
    Trunc,
    Fract,
    Sqrt,
    Sin,
    Cos,
    Tan,
    Exp,
    Exp2,
    Ln,
    Log2,
    Log10,
    Powf,
    Atan2,
    MulAdd,
    IsNan,
    IsInfinite,
    IsFinite,
    IsSignPositive,
    IsSignNegative,
    ToBits,
    FromBits,
    ToF32,
    ToF64,
}
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct StdFloatCallableId {
    width: FloatWidth,
    operation: StdFloatOperation,
}

impl StdFloatCallableId {
    pub fn try_new(
        width: FloatWidth,
        operation: StdFloatOperation,
    ) -> Result<Self, BuiltinIdentityError> {
        if matches!(
            (width, operation),
            (FloatWidth::F32, StdFloatOperation::ToF32)
                | (FloatWidth::F64, StdFloatOperation::ToF64)
        ) {
            return Err(BuiltinIdentityError::UnsupportedConversion { width, operation });
        }
        Ok(Self { width, operation })
    }
    pub const fn width(self) -> FloatWidth {
        self.width
    }
    pub const fn operation(self) -> StdFloatOperation {
        self.operation
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CapabilityCallableId {
    EventEmit,
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum BuiltinCallableId {
    InlineFailureFallback,
    Panic,
    Fail,
    Bail,
    Ensure,
    Rgb,
    Sin,
    Cos,
    Vector { dimensions: VectorDimensions },
    Math(MathCallableId),
    StdFloat(StdFloatCallableId),
    Capability(CapabilityCallableId),
    Reduction(ReductionConstructorKind),
    Action(ActionCallableId),
}

/// Closed language operations on an original typed Action declaration.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ActionCallableId {
    Emit,
    Receive,
}

impl ActionCallableId {
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Emit => 0,
            Self::Receive => 1,
        }
    }
}

impl BuiltinCallableId {
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        let direct = [
            (&["fallback"][..], Self::InlineFailureFallback),
            (
                &["InlineFailure", "fallback"][..],
                Self::InlineFailureFallback,
            ),
            (&["panic"][..], Self::Panic),
            (&["fail"][..], Self::Fail),
            (&["bail"][..], Self::Bail),
            (&["ensure"][..], Self::Ensure),
            (&["emit"][..], Self::Action(ActionCallableId::Emit)),
            (&["receive"][..], Self::Action(ActionCallableId::Receive)),
            (&["rgb"][..], Self::Rgb),
            (&["sin"][..], Self::Sin),
            (&["cos"][..], Self::Cos),
            (
                &["vec2"][..],
                Self::Vector {
                    dimensions: VectorDimensions::Two,
                },
            ),
            (
                &["vec3"][..],
                Self::Vector {
                    dimensions: VectorDimensions::Three,
                },
            ),
            (
                &["vec4"][..],
                Self::Vector {
                    dimensions: VectorDimensions::Four,
                },
            ),
            (
                &["math", "matmul_f32"][..],
                Self::Math(MathCallableId::MatMulF32),
            ),
            (
                &["math", "matrix_add_f32"][..],
                Self::Math(MathCallableId::MatrixAddF32),
            ),
            (
                &["math", "matmul_f64"][..],
                Self::Math(MathCallableId::MatMulF64),
            ),
            (
                &["math", "matrix_add_f64"][..],
                Self::Math(MathCallableId::MatrixAddF64),
            ),
            (
                &["math", "tensor_add_f32"][..],
                Self::Math(MathCallableId::TensorAddF32),
            ),
            (
                &["math", "tensor_add_f64"][..],
                Self::Math(MathCallableId::TensorAddF64),
            ),
            (
                &["event", "emit"][..],
                Self::Capability(CapabilityCallableId::EventEmit),
            ),
        ];
        if let Some((_, id)) = direct
            .into_iter()
            .find(|(segments, _)| path.matches(segments))
        {
            return Some(id);
        }
        resolve_std_float(path)
            .or_else(|| ReductionConstructorKind::resolve(path).map(BuiltinCallableId::Reduction))
    }
}

fn resolve_std_float(path: &CallablePath) -> Option<BuiltinCallableId> {
    let [std, width, operation] = path.segments() else {
        return None;
    };
    if std.as_str() != "std" {
        return None;
    }
    let width = match width.as_str() {
        "f32" => FloatWidth::F32,
        "f64" => FloatWidth::F64,
        _ => return None,
    };
    let operation = match operation.as_str() {
        "abs" => StdFloatOperation::Abs,
        "floor" => StdFloatOperation::Floor,
        "ceil" => StdFloatOperation::Ceil,
        "round" => StdFloatOperation::Round,
        "trunc" => StdFloatOperation::Trunc,
        "fract" => StdFloatOperation::Fract,
        "sqrt" => StdFloatOperation::Sqrt,
        "sin" => StdFloatOperation::Sin,
        "cos" => StdFloatOperation::Cos,
        "tan" => StdFloatOperation::Tan,
        "exp" => StdFloatOperation::Exp,
        "exp2" => StdFloatOperation::Exp2,
        "ln" => StdFloatOperation::Ln,
        "log2" => StdFloatOperation::Log2,
        "log10" => StdFloatOperation::Log10,
        "powf" => StdFloatOperation::Powf,
        "atan2" => StdFloatOperation::Atan2,
        "mul_add" => StdFloatOperation::MulAdd,
        "is_nan" => StdFloatOperation::IsNan,
        "is_infinite" => StdFloatOperation::IsInfinite,
        "is_finite" => StdFloatOperation::IsFinite,
        "is_sign_positive" => StdFloatOperation::IsSignPositive,
        "is_sign_negative" => StdFloatOperation::IsSignNegative,
        "to_bits" => StdFloatOperation::ToBits,
        "from_bits" => StdFloatOperation::FromBits,
        "to_f32" => StdFloatOperation::ToF32,
        "to_f64" => StdFloatOperation::ToF64,
        _ => return None,
    };
    StdFloatCallableId::try_new(width, operation)
        .ok()
        .map(BuiltinCallableId::StdFloat)
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct EnumVariantSignatureId {
    owner: SemanticTypeDigest,
    case: u32,
}

/// One declaration-backed record constructor. Parameter spelling is carried
/// by its accepted fields; the result nominal owns the stable identity.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct RecordConstructorSignatureId {
    owner: SemanticTypeDigest,
}

impl RecordConstructorSignatureId {
    pub(crate) const fn new(owner: SemanticTypeDigest) -> Self {
        Self { owner }
    }

    pub const fn owner(&self) -> SemanticTypeDigest {
        self.owner
    }
}
impl EnumVariantSignatureId {
    /// Identifies one constructor by its declaration-template owner and
    /// declaration ordinal. The completed application owns its instantiated
    /// result type. Diagnostic spelling is not part of equality or hashing.
    pub(crate) const fn new(owner: SemanticTypeDigest, case: u32) -> Self {
        Self { owner, case }
    }

    pub const fn owner(&self) -> SemanticTypeDigest {
        self.owner
    }

    pub const fn case(&self) -> u32 {
        self.case
    }
}
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ResultConstructorKind {
    Ok,
    Err,
}

impl ResultConstructorKind {
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        if path.matches(&["Ok"]) {
            Some(Self::Ok)
        } else if path.matches(&["Err"]) {
            Some(Self::Err)
        } else {
            None
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum OptionConstructorKind {
    Some,
}

impl OptionConstructorKind {
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        path.matches(&["Some"]).then_some(Self::Some)
    }
}

/// Core `Reduction` constructor selected by a source callable path.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ReductionConstructorKind {
    Unchanged,
}

impl ReductionConstructorKind {
    /// Resolves one canonical `Reduction` constructor path.
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        path.matches(&["Reduction", "unchanged"])
            .then_some(Self::Unchanged)
    }
}

/// Resolves the sema-owned `Fx.<constructor>` namespace shape while leaving
/// terminal constructor identity and its parameter/property schema to the
/// presentation owner.  Paths outside the exact two-segment namespace are
/// intentionally not considered language Fx callables.
pub(crate) fn resolve_fx_source_constructor(path: &CallablePath) -> Option<FxSourceConstructor> {
    let [namespace, member] = path.segments() else {
        return None;
    };
    (namespace.as_str() == "Fx")
        .then(|| FxSourceConstructor::from_source_name(member.as_str()))
        .flatten()
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum AgentIntrinsicSignatureId {
    Observe,
    Expect,
    Deny,
    Checkpoint,
    Note,
    Attach,
    ChoiceAction,
    Viewport,
    Layer,
    Object,
    Capture,
    ReadResource,
    EntityMeta,
    ProjectNeighbors,
    Signal,
    Metric,
    StatePath,
    ObservationPath,
    State,
    Observation,
    Diagnostics,
    Exists,
    ActionEnabled,
    All,
    Any,
    Not,
    Wait,
    AdvanceText,
    ViewportPoint,
    PointerClick,
    Invoke,
    RagQuery,
}

impl AgentIntrinsicSignatureId {
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        let entries = [
            (&["observe"][..], Self::Observe),
            (&["expect"][..], Self::Expect),
            (&["deny"][..], Self::Deny),
            (&["checkpoint"][..], Self::Checkpoint),
            (&["note"][..], Self::Note),
            (&["attach"][..], Self::Attach),
            (&["choice_action"][..], Self::ChoiceAction),
            (&["viewport"][..], Self::Viewport),
            (&["layer"][..], Self::Layer),
            (&["object"][..], Self::Object),
            (&["capture"][..], Self::Capture),
            (&["read_resource"][..], Self::ReadResource),
            (&["entity_meta"][..], Self::EntityMeta),
            (&["project_neighbors"][..], Self::ProjectNeighbors),
            (&["signal"][..], Self::Signal),
            (&["metric"][..], Self::Metric),
            (&["state_path"][..], Self::StatePath),
            (&["observation_path"][..], Self::ObservationPath),
            (&["state"][..], Self::State),
            (&["observation"][..], Self::Observation),
            (&["diagnostics"][..], Self::Diagnostics),
            (&["exists"][..], Self::Exists),
            (&["action_enabled"][..], Self::ActionEnabled),
            (&["all"][..], Self::All),
            (&["any"][..], Self::Any),
            (&["not"][..], Self::Not),
            (&["wait"][..], Self::Wait),
            (&["advance_text"][..], Self::AdvanceText),
            (&["viewport_point"][..], Self::ViewportPoint),
            (&["pointer", "click"][..], Self::PointerClick),
            (&["invoke"][..], Self::Invoke),
            (&["rag", "query"][..], Self::RagQuery),
        ];
        entries
            .into_iter()
            .find_map(|(segments, id)| path.matches(segments).then_some(id))
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct LocalCallableId {
    local: arcweft_lang_hir::identity::LocalId,
}
impl LocalCallableId {
    pub(crate) const fn from_checked_local(local: arcweft_lang_hir::identity::LocalId) -> Self {
        Self { local }
    }

    pub const fn local(&self) -> arcweft_lang_hir::identity::LocalId {
        self.local
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct FunctionValueSignatureId {
    expression: ExprId,
    ordinal: FunctionValueOrdinal,
}
impl FunctionValueSignatureId {
    pub(crate) fn new(expression: ExprId, ordinal: FunctionValueOrdinal) -> Self {
        Self {
            expression,
            ordinal,
        }
    }
    pub const fn expression(&self) -> ExprId {
        self.expression
    }
    pub const fn ordinal(&self) -> FunctionValueOrdinal {
        self.ordinal
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum CollectionMethodId {
    Len,
    Filter,
    Sum,
    Contains,
    Collect { item: TypeKind },
    Traverse { source: TypeKind },
    Parallel { traversal: TypeKind },
}

impl CollectionMethodId {
    pub fn resolve(method: &CallableName) -> Option<Self> {
        match method.as_str() {
            "len" => Some(Self::Len),
            "filter" => Some(Self::Filter),
            "sum" => Some(Self::Sum),
            "contains" => Some(Self::Contains),
            _ => None,
        }
    }
}

impl StandardMapFamily {
    pub(crate) fn overload(self) -> CallableOverloadIndex {
        CallableOverloadIndex::try_from_usize(usize::from(self.ordinal()))
            .expect("closed standard map overloads are representable")
    }
}

pub use arcweft_interaction_model::presentation::PresentationHandleMethodId;

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum IntegerMethodId {
    Clamp,
    Min,
    Max,
}

impl IntegerMethodId {
    pub fn resolve(receiver: &TypeKind, method: &CallableName) -> Option<Self> {
        if !receiver.is_integer() {
            return None;
        }
        match method.as_str() {
            "clamp" => Some(Self::Clamp),
            "min" => Some(Self::Min),
            "max" => Some(Self::Max),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ProbeComparisonId {
    Eq,
    Ne,
    NotEq,
    Gt,
    Greater,
    Ge,
    GreaterOrEqual,
    Lt,
    Less,
    Le,
    LessOrEqual,
}

/// Canonical semantic operation shared by the accepted probe-comparison
/// spellings.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ProbeComparisonOperator {
    Eq,
    NotEq,
    Greater,
    GreaterOrEqual,
    Less,
    LessOrEqual,
}

impl ProbeComparisonId {
    pub fn resolve(method: &CallableName) -> Option<Self> {
        match method.as_str() {
            "eq" => Some(Self::Eq),
            "ne" => Some(Self::Ne),
            "not_eq" => Some(Self::NotEq),
            "gt" => Some(Self::Gt),
            "greater" => Some(Self::Greater),
            "ge" => Some(Self::Ge),
            "greater_or_equal" => Some(Self::GreaterOrEqual),
            "lt" => Some(Self::Lt),
            "less" => Some(Self::Less),
            "le" => Some(Self::Le),
            "less_or_equal" => Some(Self::LessOrEqual),
            _ => None,
        }
    }

    pub const fn operator(self) -> ProbeComparisonOperator {
        match self {
            Self::Eq => ProbeComparisonOperator::Eq,
            Self::Ne | Self::NotEq => ProbeComparisonOperator::NotEq,
            Self::Gt | Self::Greater => ProbeComparisonOperator::Greater,
            Self::Ge | Self::GreaterOrEqual => ProbeComparisonOperator::GreaterOrEqual,
            Self::Lt | Self::Less => ProbeComparisonOperator::Less,
            Self::Le | Self::LessOrEqual => ProbeComparisonOperator::LessOrEqual,
        }
    }
}
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum DomainMethodId {
    FxSampleOrdinalPhase,
    ObservedObjectRequireRole,
    MapGet {
        key: TypeKind,
        value: TypeKind,
    },
    ProbeCompare {
        value: TypeKind,
        operation: ProbeComparisonId,
    },
    DiagnosticsHasError,
    RagContextPackSummary,
    Context,
    WithContext,
}

impl DomainMethodId {
    pub fn resolve(receiver: &TypeKind, method: &CallableName) -> Option<Self> {
        let name = method.as_str();
        if matches!(receiver, TypeKind::Named(name) if name == "FxSampleContext")
            && name == "ordinal_phase"
        {
            return Some(Self::FxSampleOrdinalPhase);
        }
        if matches!(receiver, TypeKind::Vec(item) if item.as_ref() == &TypeKind::ObservedObject)
            && name == "require_role"
        {
            return Some(Self::ObservedObjectRequireRole);
        }
        if let TypeKind::Map { key, value, .. } = receiver
            && name == "get"
        {
            return Some(Self::MapGet {
                key: key.as_ref().clone(),
                value: value.as_ref().clone(),
            });
        }
        if let TypeKind::Probe(value) = receiver
            && let Some(operation) = ProbeComparisonId::resolve(method)
        {
            return Some(Self::ProbeCompare {
                value: value.as_ref().clone(),
                operation,
            });
        }
        if receiver == &TypeKind::AgentBuiltin(crate::types::AgentBuiltinType::Diagnostics)
            && name == "has_error"
        {
            return Some(Self::DiagnosticsHasError);
        }
        if receiver == &TypeKind::RagContextPack && name == "summary" {
            return Some(Self::RagContextPackSummary);
        }
        if matches!(
            receiver,
            TypeKind::Need(_) | TypeKind::Option(_) | TypeKind::Result { .. }
        ) {
            match name {
                "context" => return Some(Self::Context),
                "with_context" => return Some(Self::WithContext),
                _ => {}
            }
        }
        None
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct CapacityMethodId {
    receiver: TypeKind,
    method: CallableName,
    arity: u16,
}
impl CapacityMethodId {
    pub fn try_new(
        receiver: TypeKind,
        method: CallableName,
        arity: usize,
    ) -> Result<Self, CallableIdentityError> {
        let arity = u16::try_from(arity).map_err(|_| CallableScalarError::IndexOverflow {
            kind: CallableIndexKind::Parameter,
            value: arity,
        })?;
        if !Self::supports_shape(&receiver, method.as_str(), usize::from(arity)) {
            return Err(CallableIdentityError::InvalidCapacityMethod);
        }
        Ok(Self {
            receiver,
            method,
            arity,
        })
    }
    pub const fn receiver(&self) -> &TypeKind {
        &self.receiver
    }
    pub const fn method(&self) -> &CallableName {
        &self.method
    }
    pub const fn arity(&self) -> usize {
        self.arity as usize
    }

    pub fn operation(&self) -> super::CheckedCapacityOperation {
        use super::CheckedCapacityOperation;
        match self.method().as_str() {
            "with_capacity" => CheckedCapacityOperation::WithCapacity,
            "pop" => CheckedCapacityOperation::Pop,
            "pop_front" => CheckedCapacityOperation::PopFront,
            "push" => CheckedCapacityOperation::Push,
            "reserve" => CheckedCapacityOperation::Reserve,
            "shrink_to" => CheckedCapacityOperation::ShrinkTo,
            "shrink" => CheckedCapacityOperation::Shrink,
            _ => unreachable!("CapacityMethodId retains a supported method identity"),
        }
    }

    pub(crate) fn is_supported_shape(&self) -> bool {
        Self::supports_shape(self.receiver(), self.method().as_str(), self.arity())
    }

    fn supports_shape(receiver: &TypeKind, method: &str, arity: usize) -> bool {
        match (receiver, method, arity) {
            (TypeKind::String | TypeKind::Bytes | TypeKind::Vec(_), "with_capacity", 1) => true,
            (TypeKind::Vec(_), "pop" | "pop_front", 0) => true,
            (TypeKind::Vec(_), "push", 1) => true,
            (TypeKind::Vec(_) | TypeKind::String | TypeKind::Bytes, "reserve" | "shrink_to", 1) => {
                true
            }
            (TypeKind::Vec(_) | TypeKind::String | TypeKind::Bytes, "shrink", 0) => true,
            _ => false,
        }
    }

    pub(crate) fn resolve_associated(
        receiver: &TypeKind,
        member: &CallableName,
        authored_arity: usize,
    ) -> Result<Option<Self>, CallableIdentityError> {
        if member.as_str() != "with_capacity"
            || !matches!(
                receiver,
                TypeKind::String | TypeKind::Bytes | TypeKind::Vec(_)
            )
        {
            return Ok(None);
        }
        if !Self::supports_shape(receiver, member.as_str(), authored_arity) {
            return Ok(None);
        }
        Self::try_new(receiver.clone(), member.clone(), authored_arity).map(Some)
    }

    pub fn resolve(receiver: &TypeKind, method: &CallableName, arity: usize) -> Option<Self> {
        Self::try_new(receiver.clone(), method.clone(), arity).ok()
    }

    pub(crate) fn result_type(&self) -> TypeKind {
        match (self.receiver(), self.method().as_str()) {
            (receiver, "with_capacity") => receiver.clone(),
            (TypeKind::Vec(item), "pop" | "pop_front") => TypeKind::Option(item.clone()),
            (TypeKind::Vec(_), "push") => TypeKind::Unit,
            (
                TypeKind::Vec(_) | TypeKind::String | TypeKind::Bytes,
                "reserve" | "shrink_to" | "shrink",
            ) => TypeKind::Unit,
            _ => unreachable!("CapacityMethodId constructors retain a supported method identity"),
        }
    }
}

/// Closed authored stage methods with stable argument names and types.
///
/// Stage operations are not collection-capacity helpers. Their dedicated
/// identity keeps `scope` and `crossfade` visible to shared resolution.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum StageMethodId {
    Acquire,
    Look,
}

impl StageMethodId {
    pub fn resolve(receiver: &TypeKind, method: &CallableName, arity: usize) -> Option<Self> {
        match (receiver, method.as_str(), arity) {
            (TypeKind::StageApi(_), "acquire", 1) => Some(Self::Acquire),
            (
                TypeKind::StageActorHandle(crate::types::StageActorHandleType::Exact(_)),
                "look",
                1 | 2,
            ) => Some(Self::Look),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum LineContextMethodId {
    VoiceHandle,
}

impl LineContextMethodId {
    pub fn resolve(receiver: &TypeKind, method: &CallableName, arity: usize) -> Option<Self> {
        matches!(
            (receiver, method.as_str(), arity),
            (TypeKind::LineContext, "voice_handle", 0)
        )
        .then_some(Self::VoiceHandle)
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum LineScheduleCallableId {
    At,
}

impl LineScheduleCallableId {
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        path.matches(&["at"]).then_some(Self::At)
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum DropCallableId {
    Drop,
    DropWithPolicy,
    DropOptional,
    OnDrop,
}

/// Stable schema coordinates for the standard `fmt` callable.
///
/// The names in the source surface are resolved to these parameter identities
/// by the selected callable schema. Consumers must not rediscover them from
/// authored labels.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum FmtParameterId {
    Value,
    Style,
    Locale,
    Currency,
    NoneValue,
    Color,
    OnError,
    Fallback,
    DiscardError,
}

impl FmtParameterId {
    pub const fn index(self) -> usize {
        match self {
            Self::Value => 0,
            Self::Style => 1,
            Self::Locale => 2,
            Self::Currency => 3,
            Self::NoneValue => 4,
            Self::Color => 5,
            Self::OnError => 6,
            Self::Fallback => 7,
            Self::DiscardError => 8,
        }
    }

    pub const fn source_name(self) -> &'static str {
        match self {
            Self::Value => "value",
            Self::Style => "style",
            Self::Locale => "locale",
            Self::Currency => "currency",
            Self::NoneValue => "none",
            Self::Color => "color",
            Self::OnError => "on_error",
            Self::Fallback => "fallback",
            Self::DiscardError => "discard_error",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum PromotionCallableId {
    Promote,
    PromoteUnchecked,
    Assume,
}
impl PromotionCallableId {
    pub fn resolve(path: &CallablePath) -> Option<Self> {
        if path.matches(&["promote"]) {
            Some(Self::Promote)
        } else if path.matches(&["promote_unchecked"]) {
            Some(Self::PromoteUnchecked)
        } else if path.matches(&["assume"]) {
            Some(Self::Assume)
        } else {
            None
        }
    }
}

/// Version of the immutable programmatic trait callable catalog.
///
/// The field is deliberately private: changing any installed declaration,
/// signature, effect contract, or witness mapping requires changing the
/// repository-owned constant rather than manufacturing a version at a call
/// site.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct StandardTraitCatalogVersion(u32);

pub const STANDARD_TRAIT_CATALOG_VERSION: StandardTraitCatalogVersion =
    StandardTraitCatalogVersion(1);

impl StandardTraitCatalogVersion {
    pub const fn as_u32(self) -> u32 {
        self.0
    }
}

/// Structural identity of one programmatically installed standard callable.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct StandardCallableDeclarationId {
    owner: CallableDeclarationOwner,
    catalog_ordinal: u32,
}

impl StandardCallableDeclarationId {
    pub const fn owner(&self) -> CallableDeclarationOwner {
        self.owner
    }

    pub const fn catalog_ordinal(&self) -> u32 {
        self.catalog_ordinal
    }
}

/// Structural identity of one callable in a detached source check.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct DetachedCallableDeclarationId {
    owner: CallableDeclarationOwner,
    source_ordinal: u32,
}

impl DetachedCallableDeclarationId {
    pub const fn owner(&self) -> CallableDeclarationOwner {
        self.owner
    }

    pub const fn source_ordinal(&self) -> u32 {
        self.source_ordinal
    }
}

/// Structural declaration retained by one checked callable identity.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum CheckedCallableDeclaration {
    Project(CallableDeclarationKey),
    Detached(DetachedCallableDeclarationId),
    Environment(EnvironmentCallableId),
    Standard(StandardCallableDeclarationId),
}

impl Ord for CheckedCallableDeclaration {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        fn tag(value: &CheckedCallableDeclaration) -> u8 {
            match value {
                CheckedCallableDeclaration::Project(_) => 0,
                CheckedCallableDeclaration::Detached(_) => 1,
                CheckedCallableDeclaration::Environment(_) => 2,
                CheckedCallableDeclaration::Standard(_) => 3,
            }
        }
        tag(self)
            .cmp(&tag(other))
            .then_with(|| match (self, other) {
                (Self::Project(left), Self::Project(right)) => left.cmp(right),
                (Self::Detached(left), Self::Detached(right)) => left.cmp(right),
                (Self::Environment(left), Self::Environment(right)) => left
                    .canonical_identity_bytes()
                    .cmp(&right.canonical_identity_bytes()),
                (Self::Standard(left), Self::Standard(right)) => left.cmp(right),
                _ => std::cmp::Ordering::Equal,
            })
    }
}

impl PartialOrd for CheckedCallableDeclaration {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

/// Exact semantic context in which a callable declaration was accepted.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedCallableContext {
    Project {
        world: ProjectSymbolWorldId,
        revision: ProjectSymbolRevision,
        catalog: RegisteredCallableCatalogDigest,
        standard: StandardTraitCatalogVersion,
    },
    Detached {
        source: SourceDocumentIdentity,
        standard: StandardTraitCatalogVersion,
    },
    Environment {
        catalog: RegisteredCallableCatalogDigest,
    },
    Standard {
        version: StandardTraitCatalogVersion,
    },
}

/// Revision-bound semantic identity of one callable declaration.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CheckedCallableId {
    context: CheckedCallableContext,
    declaration: CheckedCallableDeclaration,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CheckedCallableDigest([u8; 32]);

/// Source-bound closure identity within one checked callable.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CheckedClosureId {
    owner: CheckedCallableId,
    expression: SourceSpan,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CheckedClosureDigest([u8; 32]);

impl CheckedClosureDigest {
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CheckedEffectCallableId {
    Declaration(CheckedCallableId),
    Closure(CheckedClosureId),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CheckedCallableIdentityError {
    ContextMismatch,
    ProjectPackageMismatch,
    ClosureSourceMismatch,
}

impl CheckedCallableId {
    pub(crate) fn for_project(
        world: ProjectSymbolWorldId,
        revision: ProjectSymbolRevision,
        catalog: RegisteredCallableCatalogDigest,
        standard: StandardTraitCatalogVersion,
        declaration: CallableDeclarationKey,
    ) -> Result<Self, CheckedCallableIdentityError> {
        if declaration.package() != world.package() {
            return Err(CheckedCallableIdentityError::ProjectPackageMismatch);
        }
        Ok(Self {
            context: CheckedCallableContext::Project {
                world,
                revision,
                catalog,
                standard,
            },
            declaration: CheckedCallableDeclaration::Project(declaration),
        })
    }

    pub(crate) fn for_environment(
        catalog: RegisteredCallableCatalogDigest,
        declaration: EnvironmentCallableId,
    ) -> Self {
        Self {
            context: CheckedCallableContext::Environment { catalog },
            declaration: CheckedCallableDeclaration::Environment(declaration),
        }
    }

    pub const fn context(&self) -> &CheckedCallableContext {
        &self.context
    }

    pub const fn declaration(&self) -> &CheckedCallableDeclaration {
        &self.declaration
    }

    /// Returns the canonical one-way semantic digest used by runtime lowering.
    ///
    /// The digest retains the complete accepted generation and structural
    /// declaration. It is deliberately not a display spelling and cannot be
    /// decoded back into a checked identity.
    #[must_use]
    pub fn semantic_digest(&self) -> CheckedCallableDigest {
        let mut encoder = CheckedCallableDigestEncoder::new();
        encoder.context(&self.context);
        encoder.declaration(&self.declaration);
        CheckedCallableDigest(encoder.finish())
    }
}

impl CheckedCallableDigest {
    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    pub const fn into_bytes(self) -> [u8; 32] {
        self.0
    }
}

struct CheckedCallableDigestEncoder {
    hasher: blake3::Hasher,
}

impl CheckedCallableDigestEncoder {
    fn new() -> Self {
        Self::with_domain(b"arcweft.checked-callable.v1\0")
    }

    fn with_domain(domain: &[u8]) -> Self {
        let mut hasher = blake3::Hasher::new();
        hasher.update(domain);
        Self { hasher }
    }

    fn finish(self) -> [u8; 32] {
        *self.hasher.finalize().as_bytes()
    }

    fn byte(&mut self, value: u8) {
        self.hasher.update(&[value]);
    }

    fn u32(&mut self, value: u32) {
        self.hasher.update(&value.to_le_bytes());
    }

    fn u64(&mut self, value: u64) {
        self.hasher.update(&value.to_le_bytes());
    }

    fn string(&mut self, value: &str) {
        let length = u32::try_from(value.len())
            .expect("validated callable identity strings fit the u32 digest contract");
        self.u32(length);
        self.hasher.update(value.as_bytes());
    }

    fn segments(&mut self, segments: &[arcweft_lang_syntax::ast::module_path::ModuleSegment]) {
        let length = u32::try_from(segments.len())
            .expect("validated callable identity paths fit the u32 digest contract");
        self.u32(length);
        for segment in segments {
            self.string(segment.as_str());
        }
    }

    fn context(&mut self, context: &CheckedCallableContext) {
        match context {
            CheckedCallableContext::Project {
                world,
                revision,
                catalog,
                standard,
            } => {
                self.byte(0);
                self.string(world.package().as_str());
                self.string(world.root_document().as_str());
                self.string(world.profile());
                self.hasher.update(revision.as_source_set().as_bytes());
                self.hasher.update(catalog.as_bytes());
                self.u32(standard.as_u32());
            }
            CheckedCallableContext::Detached { source, standard } => {
                self.byte(1);
                self.string(source.id().as_str());
                self.hasher.update(source.revision().as_bytes());
                self.u64(source.source_len());
                self.u32(standard.as_u32());
            }
            CheckedCallableContext::Environment { catalog } => {
                self.byte(2);
                self.hasher.update(catalog.as_bytes());
            }
            CheckedCallableContext::Standard { version } => {
                self.byte(3);
                self.u32(version.as_u32());
            }
        }
    }

    fn declaration(&mut self, declaration: &CheckedCallableDeclaration) {
        match declaration {
            CheckedCallableDeclaration::Project(CallableDeclarationKey::Existing(declaration)) => {
                self.byte(0);
                self.string(declaration.package().as_str());
                self.segments(declaration.module().segments());
                self.byte(declaration.owner().digest_tag());
                self.segments(declaration.owner_path());
                self.string(declaration.name());
            }
            CheckedCallableDeclaration::Project(CallableDeclarationKey::TraitRequirement(
                declaration,
            )) => {
                self.byte(1);
                let owner = declaration.trait_declaration();
                self.string(owner.package().as_str());
                self.segments(owner.module().segments());
                self.string(owner.name().as_str());
                self.string(declaration.method().as_str());
            }
            CheckedCallableDeclaration::Project(CallableDeclarationKey::ImplMethod(
                declaration,
            )) => {
                self.byte(2);
                let owner = declaration.implementation();
                self.string(owner.package().as_str());
                self.segments(owner.module().segments());
                self.u32(owner.source_ordinal());
                self.byte(declaration.kind().digest_tag());
                self.string(declaration.method().as_str());
            }
            CheckedCallableDeclaration::Project(CallableDeclarationKey::Flow(declaration)) => {
                self.byte(6);
                self.string(declaration.package().as_str());
                self.segments(declaration.module().segments());
                self.string(declaration.public_id().as_str());
                self.byte(match declaration.publication() {
                    arcweft_lang_hir::symbol::FlowPublicationKind::ModuleScoped => 0,
                    arcweft_lang_hir::symbol::FlowPublicationKind::AuthoredAbsolute => 1,
                });
            }
            CheckedCallableDeclaration::Detached(declaration) => {
                self.byte(3);
                self.byte(declaration.owner().digest_tag());
                self.u32(declaration.source_ordinal());
            }
            CheckedCallableDeclaration::Environment(declaration) => {
                self.byte(4);
                self.hasher.update(&declaration.canonical_identity_bytes());
            }
            CheckedCallableDeclaration::Standard(declaration) => {
                self.byte(5);
                self.byte(declaration.owner().digest_tag());
                self.u32(declaration.catalog_ordinal());
            }
        }
    }
}

impl CheckedClosureId {
    pub(crate) fn from_checked_expression(
        owner: CheckedCallableId,
        expression: SourceSpan,
    ) -> Result<Self, CheckedCallableIdentityError> {
        if let CheckedCallableContext::Detached { source, .. } = owner.context()
            && expression.source() != source
        {
            return Err(CheckedCallableIdentityError::ClosureSourceMismatch);
        }
        Ok(Self { owner, expression })
    }

    pub const fn owner(&self) -> &CheckedCallableId {
        &self.owner
    }

    pub const fn expression(&self) -> &SourceSpan {
        &self.expression
    }

    /// Stable closure identity including its checked lexical owner and exact
    /// document revision/range. Consumers do not reconstruct an owner from
    /// source spelling or substitute the enclosing declaration's identity.
    pub fn semantic_digest(&self) -> CheckedClosureDigest {
        let mut encoder =
            CheckedCallableDigestEncoder::with_domain(b"arcweft.checked-closure.v1\0");
        encoder.context(self.owner.context());
        encoder.declaration(self.owner.declaration());
        let source = self.expression.source();
        encoder.string(source.id().as_str());
        encoder.hasher.update(source.revision().as_bytes());
        encoder.u64(source.source_len());
        encoder.u64(
            u64::try_from(self.expression.range().start())
                .expect("validated source offsets fit u64"),
        );
        encoder.u64(
            u64::try_from(self.expression.range().end()).expect("validated source offsets fit u64"),
        );
        CheckedClosureDigest(encoder.finish())
    }
}

/// Closed identity of one content callable.
///
/// Language operations are identified by their exact presentation definition
/// row and owner-issued schema digest. A text proxy Object operation
/// additionally carries the exact accepted nominal owner and checked schema
/// dependency, so equal-shaped declarations cannot collapse into one callable.
/// The Object operation is derived from the latter variant; it is not stored
/// as a second identity field.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ContentCallableIdentity {
    Language {
        definition: PresentationContentCallableDefinitionId,
        schema: RichTextCallableSchemaDigest,
    },
    TextProxyObject {
        owner: SemanticTypeDigest,
        definition: super::CallableSchemaDependencyDigest,
    },
}

impl ContentCallableIdentity {
    pub const fn language(
        definition: PresentationContentCallableDefinitionId,
        schema: RichTextCallableSchemaDigest,
    ) -> Self {
        Self::Language { definition, schema }
    }

    pub(crate) const fn text_proxy_object(
        owner: SemanticTypeDigest,
        definition: super::CallableSchemaDependencyDigest,
    ) -> Self {
        Self::TextProxyObject { owner, definition }
    }

    /// Stable family tag for canonical callable-schema encoding.
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Language { .. } => 0,
            Self::TextProxyObject { .. } => 1,
        }
    }

    /// Returns the exact presentation definition for a language content row.
    pub const fn definition(self) -> Option<PresentationContentCallableDefinitionId> {
        match self {
            Self::Language { definition, .. } => Some(definition),
            Self::TextProxyObject { .. } => None,
        }
    }

    /// Returns the owner-issued presentation schema digest for a language row.
    pub const fn schema(self) -> Option<RichTextCallableSchemaDigest> {
        match self {
            Self::Language { schema, .. } => Some(schema),
            Self::TextProxyObject { .. } => None,
        }
    }

    pub const fn is_text_proxy_object(self) -> bool {
        matches!(self, Self::TextProxyObject { .. })
    }

    pub const fn owner(self) -> Option<SemanticTypeDigest> {
        match self {
            Self::Language { .. } => None,
            Self::TextProxyObject { owner, .. } => Some(owner),
        }
    }

    pub const fn definition_digest(self) -> Option<super::CallableSchemaDependencyDigest> {
        match self {
            Self::Language { .. } => None,
            Self::TextProxyObject { definition, .. } => Some(definition),
        }
    }
}

#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum CallableCandidateId {
    FxConstructor(FxSourceConstructor),
    EnumVariant(EnumVariantSignatureId),
    Result(ResultConstructorKind),
    Option(OptionConstructorKind),
    Builtin(BuiltinCallableId),
    Agent(AgentIntrinsicSignatureId),
    Presentation(super::PresentationCallableId),
    Dialogue(super::DialogueCallableId),
    Content(ContentCallableIdentity),
    Project(CallableDeclarationKey),
    Detached(DetachedCallableDeclarationId),
    Environment(EnvironmentCallableId),
    Standard(StandardCallableDeclarationId),
    Local(LocalCallableId),
    FunctionValue(FunctionValueSignatureId),
    CollectionMethod(CollectionMethodId),
    PresentationHandleMethod(PresentationHandleMethodId),
    IntegerMethod(IntegerMethodId),
    DomainMethod(DomainMethodId),
    CapacityMethod(CapacityMethodId),
    StageMethod(StageMethodId),
    LineContextMethod(LineContextMethodId),
    LineSchedule(LineScheduleCallableId),
    Drop(DropCallableId),
    Promotion(PromotionCallableId),
    RecordConstructor(RecordConstructorSignatureId),
    StringMethod(arcweft_core::value::RuntimeStringOperation),
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CallableFamily {
    FxConstructor,
    EnumConstructor,
    ResultConstructor,
    OptionConstructor,
    Builtin,
    Agent,
    Presentation,
    Dialogue,
    Content,
    Project,
    Environment,
    Lexical,
    FunctionValue,
    CollectionMethod,
    PresentationHandleMethod,
    IntegerMethod,
    DomainMethod,
    TraitMethod,
    CapacityMethod,
    StageMethod,
    LineContextMethod,
    LineSchedule,
    Drop,
    Promotion,
    RecordConstructor,
    StringMethod,
}

impl CallableFamily {
    /// Every production callable family in stable semantic-audit order.
    pub const ALL: [Self; 26] = [
        Self::FxConstructor,
        Self::EnumConstructor,
        Self::ResultConstructor,
        Self::OptionConstructor,
        Self::Builtin,
        Self::Agent,
        Self::Presentation,
        Self::Dialogue,
        Self::Project,
        Self::Environment,
        Self::Lexical,
        Self::FunctionValue,
        Self::CollectionMethod,
        Self::PresentationHandleMethod,
        Self::IntegerMethod,
        Self::DomainMethod,
        Self::TraitMethod,
        Self::CapacityMethod,
        Self::StageMethod,
        Self::LineContextMethod,
        Self::LineSchedule,
        Self::Drop,
        Self::Promotion,
        Self::Content,
        Self::RecordConstructor,
        Self::StringMethod,
    ];
}

impl CallableCandidateId {
    /// Flow declarations selected as applications are non-returning transfer
    /// targets. Ordinary Flow reference values do not grant call rights.
    pub(crate) const fn is_flow_transfer(&self) -> bool {
        matches!(self, Self::Project(CallableDeclarationKey::Flow(_)))
    }

    pub(crate) const fn intrinsic_family(&self) -> CallableFamily {
        match self {
            Self::FxConstructor(_) => CallableFamily::FxConstructor,
            Self::EnumVariant(_) => CallableFamily::EnumConstructor,
            Self::Result(_) => CallableFamily::ResultConstructor,
            Self::Option(_) => CallableFamily::OptionConstructor,
            Self::Builtin(_) => CallableFamily::Builtin,
            Self::Agent(_) => CallableFamily::Agent,
            Self::Presentation(_) => CallableFamily::Presentation,
            Self::Dialogue(_) => CallableFamily::Dialogue,
            Self::Content(_) => CallableFamily::Content,
            Self::Project(_) | Self::Detached(_) | Self::Standard(_) => CallableFamily::Project,
            Self::Environment(_) => CallableFamily::Environment,
            Self::Local(_) => CallableFamily::Lexical,
            Self::FunctionValue(_) => CallableFamily::FunctionValue,
            Self::CollectionMethod(_) => CallableFamily::CollectionMethod,
            Self::PresentationHandleMethod(_) => CallableFamily::PresentationHandleMethod,
            Self::IntegerMethod(_) => CallableFamily::IntegerMethod,
            Self::DomainMethod(_) => CallableFamily::DomainMethod,
            Self::CapacityMethod(_) => CallableFamily::CapacityMethod,
            Self::StageMethod(_) => CallableFamily::StageMethod,
            Self::LineContextMethod(_) => CallableFamily::LineContextMethod,
            Self::LineSchedule(_) => CallableFamily::LineSchedule,
            Self::Drop(_) => CallableFamily::Drop,
            Self::Promotion(_) => CallableFamily::Promotion,
            Self::RecordConstructor(_) => CallableFamily::RecordConstructor,
            Self::StringMethod(_) => CallableFamily::StringMethod,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum LanguageCallableFamily {
    FxConstructor,
    EnumConstructor,
    ResultConstructor,
    OptionConstructor,
    Builtin,
    Agent,
    Presentation,
    Dialogue,
    CollectionMethod,
    PresentationHandleMethod,
    IntegerMethod,
    DomainMethod,
    CapacityMethod,
    StageMethod,
    LineContextMethod,
    LineSchedule,
    Drop,
    Promote,
    Assume,
    Content,
    RecordConstructor,
    StringMethod,
}
