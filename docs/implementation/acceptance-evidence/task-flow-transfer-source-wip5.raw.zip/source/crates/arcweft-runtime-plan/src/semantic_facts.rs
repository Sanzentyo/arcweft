//! Accepted-generation semantic facts consumed by final-HIR runtime lowering.
//!
//! Runtime lowering is intentionally below semantic analysis in the crate
//! graph. The compiler therefore projects checked decisions into this closed
//! vocabulary and binds them to the exact executable HIR generation. Facts are
//! keyed by qualified final-HIR IDs; source-order counters, byte ranges,
//! display labels, and reconstructed paths are not accepted as identities.
//!
//! The closed fact vocabulary, staging input, immutable inventory, and atomic
//! admission remain one cohesive boundary so their families cannot drift into
//! partial schemas. HIR-owned graph traversal is delegated to HIR rather than
//! duplicated here; only runtime-plan validation and storage stay in this
//! module.

use arcweft_lang_hir::identity::HirValueTypeOwner;
use std::{
    collections::{BTreeMap, BTreeSet},
    sync::Arc,
};

mod flow_include;
mod nominal_definitions;
mod suspension;
pub use nominal_definitions::RuntimeNominalDefinition;

use arcweft_character::presentation_name::CharacterPresentationCatalogData;
use arcweft_core::entry::{
    RuntimeBytesFormat, RuntimeCallableId, RuntimeMapKind as RuntimePlanMapKind,
    RuntimeNominalRecordShape, RuntimeNominalSchemaGraph, RuntimeNominalSchemaGraphError,
    RuntimeNominalTypeId, RuntimeSchemaLimits, RuntimeTypeSchema, TypeLayoutHash,
};
pub use arcweft_core::pattern::RuntimeSemanticTypeId;
use arcweft_core::pattern::{
    RuntimeBuiltinVariantIdentity, RuntimeCheckedRecordTypeError, RuntimeCheckedType,
    RuntimeCheckedVariantCase, RuntimeOpaqueTypeAdmission, RuntimeOpaqueTypeOwner,
    RuntimeOpaqueTypeProducerId, RuntimeVariantIdentity,
};
use arcweft_core::plan::{
    FlowRuntimeId, RuntimeAgentTypeProjection, RuntimeBuiltinIteratorFamily,
    RuntimeDialogueValueRole, RuntimeLineId, RuntimeNominalRecordDomainFieldSeed,
    RuntimeNominalRecordDomainSeed, RuntimePlanRecordField, RuntimePlanSequenceKind,
    RuntimePlanTypeProjection, RuntimePlanTypeSeed, RuntimeReceiverMode, RuntimeVariantCaseSeed,
    RuntimeVariantDomainSeed,
};
use arcweft_core::runtime_id::RuntimeDialogueValueSlotId;
use arcweft_core::step::RuntimeHostCallMode;
use arcweft_core::task::{NeedProducerRequestProjection, NeedProducerTaskPlan};
use arcweft_core::value::{
    RuntimeAgentField, RuntimeIntrinsic, RuntimeNominalRecordLayout, RuntimeOpaquePersistence,
    RuntimeOpaqueValueClass, RuntimeRecordFieldId, RuntimeSignedIntWidth, RuntimeUnsignedIntWidth,
    RuntimeValue,
};
use arcweft_dialogue::{CharacterDialoguePolicyTypeGraph, CharacterDialoguePolicyVariantOwner};
use arcweft_id::runtime_program::RuntimePureProgramId;
use arcweft_id::{DeclarationIdentityFamily, PublicId};
use arcweft_lang_hir::expr::{
    HirAwaitBranchKind, HirCallArgument, HirCallInvocation, HirChoiceCompactAction, HirChoiceItem,
    HirExprKind, HirPlaceholderKind, HirRecordField,
};
use arcweft_lang_hir::identity::{
    CaptureId, ExprId, HirModuleId, HirSnapshotId, ItemId, LocalId, PatternId, StmtId, TypeId,
};
use arcweft_lang_hir::item::{
    HirEntryMember, HirEnumVariantPayload, HirImplMember, HirItemFamily, HirItemKind,
};
use arcweft_lang_hir::leaf::HirName;
use arcweft_lang_hir::module::HirModule;
use arcweft_lang_hir::pattern::{HirPatternField, HirPatternKind};
use arcweft_lang_hir::project::AcceptedDialogueLineInventory;
use arcweft_lang_hir::project::{
    HirAnalysisProjectView, HirRuntimeExecutableOwner, HirRuntimeIteratorWitnessMethodRole,
    HirRuntimeReachabilityEdge, HirRuntimeReachabilityEdgeKind, HirRuntimeReachabilityError,
    HirRuntimeReachabilityIdentity, HirRuntimeReachabilityRootKind, HirRuntimeReachabilitySite,
    HirRuntimeSemanticReachability,
};
use arcweft_lang_hir::source_index::{
    HirCallableSourceOwner, HirExprSourceRole, HirSourcePresence, HirSourceQuery, HirSourceSite,
};
use arcweft_lang_hir::stmt::{HirCancelTrigger, HirStmtKind, HirTrigger};
use arcweft_lang_hir::symbol::ImplMethodDeclarationId;
use arcweft_lang_hir::symbol::{
    CallableDeclarationKey, CallableDeclarationOwner, nominal::ProjectNominalDeclarationId,
};
use arcweft_lang_syntax::name::CallArgumentName;
use arcweft_text_model::DialogueContentSpec;
use thiserror::Error;

use crate::assertion_identity::RuntimeAssertionMode;

mod callable_specialization;
mod character_dialogue;
pub use callable_specialization::{
    RuntimeCallableSpecializationFact, RuntimeCallableSpecializationFactError,
    RuntimeCallableSpecializationKey, RuntimeCallableValueSpecialization,
    RuntimeProjectCallableSourceFact, RuntimeProjectCallableSourceKey,
    RuntimeProjectCallableSourceOrigin, RuntimeProjectCallableValueTarget,
};
mod character_dialogue_generation;
mod content;
pub use character_dialogue::RuntimeCharacterDialogueCall;
mod dialogue_target;
pub use dialogue_target::RuntimeDialogueApplicationTarget;
mod defer;
pub use defer::RuntimeDeferFact;
mod registry_write;
pub use registry_write::RuntimeRegistryWriteFact;
mod display;
pub use display::{
    RuntimeFormatExecutableScope, RuntimeFormatTemplateFact, RuntimeFormatTemplateKey,
    RuntimeProjectDisplayValue, RuntimeResolvedFormatCall,
};
mod evaluated_effect;
mod flow;
mod lexical_scope;
mod scope_continuation;
pub use scope_continuation::{
    RuntimeScopeContinuation, RuntimeScopeContinuationError, RuntimeScopeFact, RuntimeScopeOrigin,
    RuntimeScopeOwner,
};
mod project_function;
mod type_dependencies;

use arcweft_lang_sema::final_analysis::CheckedLocalUseAuthority;
pub use content::{
    RuntimeContentFragmentFact, RuntimeContentFragmentFactError, RuntimeContentFragmentId,
    RuntimeDialogueEffectCaptureKey, RuntimeDialogueEffectOperationFact,
    RuntimeDialogueEffectProgramFact, RuntimeDialogueEffectProgramKey, RuntimeDialogueMarkFact,
    RuntimeDialogueMarkKey, RuntimeDialogueValueCaptureKey, RuntimeExecutableCaptureFact,
    RuntimeExecutableCaptureFactError,
};
pub use evaluated_effect::{
    RuntimeDropFadeFact, RuntimeDropPolicyFact, RuntimeEffectFieldFact, RuntimeEvaluatedEffect,
    RuntimeEvaluatedEffectFact, RuntimeEvaluatedEffectOperandFact, RuntimeLogLevel,
};
pub use flow::{RuntimeFlowFact, RuntimeFlowFactError};
pub use project_function::{
    RuntimeClosureCaptureFact, RuntimeClosureInstanceFact, RuntimeClosureInstanceKey,
    RuntimeClosureLexicalOwner, RuntimeClosureParameterFact, RuntimeExecutableTypeProjection,
    RuntimeProjectAttachedDefaultCapture, RuntimeProjectAttachedDefaultFunctionFact,
    RuntimeProjectContinuationAbi, RuntimeProjectFunctionBody, RuntimeProjectFunctionCallInput,
    RuntimeProjectFunctionCallOutcome, RuntimeProjectFunctionCallPlan,
    RuntimeProjectFunctionCallSpecialization, RuntimeProjectFunctionExecution,
    RuntimeProjectFunctionExpressionPayload, RuntimeProjectFunctionExpressionSemanticFact,
    RuntimeProjectFunctionFactError, RuntimeProjectFunctionInstanceFact,
    RuntimeProjectFunctionInstanceKey, RuntimeProjectFunctionInstanceSemanticFacts,
    RuntimeProjectFunctionParameterAbi, RuntimeProjectFunctionParameterMaterialization,
    RuntimeProjectFunctionParameterSource, RuntimeProjectFunctionPatternPayload,
    RuntimeProjectFunctionPatternSemanticFact, RuntimeProjectFunctionRootFact,
    RuntimeProjectFunctionRootRole, RuntimeProjectFunctionStatementPayload,
    RuntimeProjectFunctionStatementSemanticFact, RuntimeResidualValue,
};

/// Stable semantic identity for a registered callable or value that is not
/// owned by one project HIR item.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeRegisteredValueId([u8; 32]);

impl RuntimeRegisteredValueId {
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }
}

/// Exact normalized shape of a semantic type owned by the Agent Prelude.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeAgentTypeShape {
    DebugStatePath,
    ObservationFieldPath,
    Probe(Box<RuntimeNormalizedType>),
    Predicate,
    Observation,
    ObservedObject,
    BoundingBox,
    ActionName,
    ActionTarget,
    ActionResult,
    DataShape(Box<RuntimeNormalizedType>),
    EntityMetadata,
    SourceAnchor,
    ProjectGraphNeighborhood,
    ProjectGraphSymbol,
    ProjectGraphEdge,
    CaptureTarget,
    CaptureReference,
    Resource,
    RagContextPack,
    ObservedObjectId,
    Diagnostics,
    WaitError,
    ViewportPoint,
    RagError,
    SourcePosition,
    ProjectFlowControlSummary,
    ProjectGraphSummary,
    BinaryResourceBody,
    BinaryData,
}

/// Runtime-relevant shape paired with an exact semantic type identity.
///
/// `Opaque` is not an unresolved type. It is a fully resolved semantic type
/// whose runtime operations are owned by a registered producer rather than the
/// Arcweft core value algebra. Its exact identity remains in
/// [`RuntimeNormalizedType::identity`].
#[derive(Clone, Debug, Eq, PartialEq)]
#[allow(
    clippy::large_enum_variant,
    reason = "checked type facts preserve a direct exhaustive semantic shape; they are immutable generation-bound inputs rather than a hot runtime value representation"
)]
pub enum RuntimeTypeShape {
    PresentationResource(arcweft_interaction_model::presentation::PresentationResourceKind),
    BoundType(arcweft_core::plan::RuntimeBoundTypeReference),
    Unit,
    Never,
    Bool,
    Signed(RuntimeSignedIntWidth),
    Unsigned(RuntimeUnsignedIntWidth),
    F32,
    F64,
    String,
    Color,
    Char,
    Bytes,
    Duration,
    Progress,
    DenseNumeric(arcweft_core::math::RuntimeDenseNumericType),
    EntityReference(arcweft_core::value::RuntimeEntityReferenceType<Box<RuntimeNormalizedType>>),
    AgentValue,
    Range(Box<RuntimeNormalizedType>),
    Iterator(Box<RuntimeNormalizedType>),
    Sequence {
        kind: RuntimeSequenceKind,
        item: Box<RuntimeNormalizedType>,
    },
    Array {
        item: Box<RuntimeNormalizedType>,
        length: arcweft_core::plan::RuntimeArrayLength,
    },
    Map {
        kind: RuntimePlanMapKind,
        key: Box<RuntimeNormalizedType>,
        value: Box<RuntimeNormalizedType>,
    },
    Need(Box<RuntimeNormalizedType>),
    Traversal {
        source: Box<RuntimeNormalizedType>,
        mapping: Box<RuntimeNormalizedType>,
    },
    Stream {
        item: Box<RuntimeNormalizedType>,
        error: Box<RuntimeNormalizedType>,
    },
    Parser {
        item: Box<RuntimeNormalizedType>,
        error: Box<RuntimeNormalizedType>,
    },
    Result {
        value: Box<RuntimeNormalizedType>,
        error: Box<RuntimeNormalizedType>,
        value_payload: Box<RuntimeNormalizedType>,
        error_payload: Box<RuntimeNormalizedType>,
    },
    Option {
        item: Box<RuntimeNormalizedType>,
        some_payload: Box<RuntimeNormalizedType>,
    },
    BuiltinVariant {
        owner: RuntimeBuiltinVariantIdentity,
        cases: Box<[Option<RuntimeNormalizedType>]>,
    },
    ThreadHandle(Box<RuntimeNormalizedType>),
    Shared(Box<RuntimeNormalizedType>),
    Reference(Box<RuntimeNormalizedType>),
    Function {
        contract: arcweft_core::plan::RuntimeFunctionTypeContract,
        parameters: Box<[RuntimeNormalizedType]>,
        result: Box<RuntimeNormalizedType>,
    },
    Nominal {
        nominal: RuntimeResolvedNominal,
        arguments: Box<[RuntimeNormalizedType]>,
    },
    Tuple(Box<[RuntimeNormalizedType]>),
    Record(Box<[RuntimeRecordTypeField]>),
    Choice(Box<[RuntimeNormalizedType]>),
    Opaque {
        producer: RuntimeOpaqueTypeProducerId,
        admission: RuntimeOpaqueTypeAdmission,
        value_class: RuntimeOpaqueValueClass,
        persistence: RuntimeOpaquePersistence,
        arguments: Box<[RuntimeNormalizedType]>,
    },
    Agent(RuntimeAgentTypeShape),
}

/// One declaration-ordered field of an exact anonymous record runtime type.
///
/// The label is retained for runtime record mechanics and diagnostics. Exact
/// type equality is owned by declaration position plus the recursive semantic
/// type, so a diagnostic rename cannot change Match or checked-type identity.
#[derive(Clone, Debug)]
pub struct RuntimeRecordTypeField {
    diagnostic_name: String,
    ty: RuntimeNormalizedType,
}

impl PartialEq for RuntimeRecordTypeField {
    fn eq(&self, other: &Self) -> bool {
        self.ty == other.ty
    }
}

impl Eq for RuntimeRecordTypeField {}

impl RuntimeRecordTypeField {
    pub fn new(diagnostic_name: impl Into<String>, ty: RuntimeNormalizedType) -> Self {
        Self {
            diagnostic_name: diagnostic_name.into(),
            ty,
        }
    }

    pub fn diagnostic_name(&self) -> &str {
        &self.diagnostic_name
    }

    pub const fn ty(&self) -> &RuntimeNormalizedType {
        &self.ty
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeSequenceKind {
    Vec,
    Array,
    Slice,
    Seq,
}

/// One deterministic descent from a normalized runtime type to a checked leaf.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeTypeProjectionStep {
    EntityPayload,
    TraversalSource,
    TraversalMapping,
    SequenceItem,
    MapKey,
    MapValue,
    NominalArgument(u32),
    TupleItem(u32),
    RecordField(u32),
    ChoiceAlternative(u32),
    OpaqueArgument(u32),
    ResultOk,
    ResultError,
    OptionItem,
    BuiltinVariantCase(u32),
    AgentProbeValue,
    AgentDataShapeValue,
}

/// Typed location of the first checked-type projection failure.
#[derive(Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeTypeProjectionPath(Box<[RuntimeTypeProjectionStep]>);

impl RuntimeTypeProjectionPath {
    #[must_use]
    pub fn root() -> Self {
        Self(Box::new([]))
    }

    #[must_use]
    pub fn pushed(&self, step: RuntimeTypeProjectionStep) -> Self {
        let mut steps = self.0.to_vec();
        steps.push(step);
        Self(steps.into_boxed_slice())
    }

    #[must_use]
    pub const fn steps(&self) -> &[RuntimeTypeProjectionStep] {
        &self.0
    }
}

/// Closed diagnostic category for shapes outside the checked value algebra.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeUnsupportedTypeShape {
    Traversal,
    Bound,
    Range,
    Iterator,
    Stream,
    Parser,
    ThreadHandle,
    Shared,
    Reference,
    Function,
}

/// Failure to project a normalized semantic type into the closed runtime algebra.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeCheckedTypeProjectionError {
    #[error("runtime type `{type_label}` has no opaque producer evidence")]
    MissingOpaqueProducerEvidence {
        semantic_identity: RuntimeSemanticTypeId,
        path: RuntimeTypeProjectionPath,
        type_label: String,
    },
    #[error("runtime type shape `{shape:?}` is not representable")]
    UnsupportedRuntimeShape {
        semantic_identity: RuntimeSemanticTypeId,
        path: RuntimeTypeProjectionPath,
        shape: RuntimeUnsupportedTypeShape,
    },
    #[error("builtin variant `{owner:?}` has a non-canonical payload schema")]
    InvalidBuiltinVariant {
        semantic_identity: RuntimeSemanticTypeId,
        path: RuntimeTypeProjectionPath,
        owner: RuntimeBuiltinVariantIdentity,
    },
    #[error("record runtime type has a non-canonical field schema")]
    InvalidRecord {
        semantic_identity: RuntimeSemanticTypeId,
        path: RuntimeTypeProjectionPath,
        reason: RuntimeCheckedRecordTypeError,
    },
}

/// One normalized semantic type that can be compared without source spelling.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeNormalizedType {
    identity: RuntimeSemanticTypeId,
    scope: arcweft_core::plan::RuntimeTypeScope,
    shape: RuntimeTypeShape,
}

/// One exact case selected directly from a normalized runtime variant type.
///
/// This borrowed view retains the exact normalized payload under the core
/// builtin case schema. Synthetic lowering paths cannot substitute a raw
/// item type for the case's structural payload type or erase its identity.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct RuntimeNormalizedVariantSelection<'a> {
    owner: &'a RuntimeNormalizedType,
    ordinal: u32,
    payload: Option<&'a RuntimeNormalizedType>,
}

impl RuntimeNormalizedVariantSelection<'_> {
    pub(crate) const fn owner(&self) -> &RuntimeNormalizedType {
        self.owner
    }

    pub(crate) const fn ordinal(&self) -> u32 {
        self.ordinal
    }

    pub(crate) const fn payload(&self) -> Option<&RuntimeNormalizedType> {
        self.payload
    }

    pub(crate) fn single_payload_item(
        &self,
    ) -> Result<Option<&RuntimeNormalizedType>, RuntimeNormalizedVariantSelectionError> {
        match self.payload {
            Some(payload) => match payload.shape() {
                RuntimeTypeShape::Tuple(items) if items.len() == 1 => Ok(items.first()),
                RuntimeTypeShape::Tuple(items) => {
                    Err(RuntimeNormalizedVariantSelectionError::PayloadArity {
                        owner: self.owner.identity(),
                        ordinal: self.ordinal,
                        actual: items.len(),
                    })
                }
                _ => Err(RuntimeNormalizedVariantSelectionError::NonTuplePayload {
                    owner: self.owner.identity(),
                    ordinal: self.ordinal,
                }),
            },
            None => Ok(None),
        }
    }
}

#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub(crate) enum RuntimeNormalizedVariantSelectionError {
    #[error("normalized type {owner:?} is not a closed runtime variant owner")]
    InvalidOwner { owner: RuntimeSemanticTypeId },
    #[error("normalized variant type {owner:?} disagrees with the {builtin:?} case schema")]
    InvalidCaseSchema {
        owner: RuntimeSemanticTypeId,
        builtin: RuntimeBuiltinVariantIdentity,
    },
    #[error("normalized variant type {owner:?} has {count} cases, exceeding u32 ordinals")]
    CaseCountOverflow {
        owner: RuntimeSemanticTypeId,
        count: usize,
    },
    #[error("normalized variant type {owner:?} has no case {ordinal} among {case_count} cases")]
    CaseOrdinal {
        owner: RuntimeSemanticTypeId,
        ordinal: u32,
        case_count: u32,
    },
    #[error("normalized variant type {owner:?} case {ordinal} disagrees with its declared payload")]
    PayloadMismatch {
        owner: RuntimeSemanticTypeId,
        ordinal: u32,
    },
    #[error("normalized variant type {owner:?} case {ordinal} payload is not a tuple")]
    NonTuplePayload {
        owner: RuntimeSemanticTypeId,
        ordinal: u32,
    },
    #[error(
        "normalized variant type {owner:?} case {ordinal} payload has {actual} fields instead of one"
    )]
    PayloadArity {
        owner: RuntimeSemanticTypeId,
        ordinal: u32,
        actual: usize,
    },
}

impl RuntimeNormalizedType {
    pub const fn new(identity: RuntimeSemanticTypeId, shape: RuntimeTypeShape) -> Self {
        Self {
            identity,
            scope: arcweft_core::plan::RuntimeTypeScope::root(),
            shape,
        }
    }

    pub fn with_scope(mut self, scope: arcweft_core::plan::RuntimeTypeScope) -> Self {
        self.scope = scope;
        self
    }

    pub const fn scope(&self) -> &arcweft_core::plan::RuntimeTypeScope {
        &self.scope
    }

    pub const fn identity(&self) -> RuntimeSemanticTypeId {
        self.identity
    }

    pub const fn shape(&self) -> &RuntimeTypeShape {
        &self.shape
    }

    fn matches_entity_type(&self, expected: &arcweft_lang_sema::types::TypeKind) -> bool {
        let RuntimeTypeShape::EntityReference(actual) = self.shape() else {
            return false;
        };
        let arcweft_lang_sema::types::TypeKind::Ref(entity) = expected else {
            return false;
        };
        entity.runtime_reference_type().is_some_and(|expected| {
            expected.matches_type(actual, |expected, actual| {
                expected
                    .semantic_identity_digest()
                    .is_ok_and(|identity| identity.as_bytes() == actual.identity().as_bytes())
            })
        })
    }

    /// Borrows the result of the accepted awaitable constructor, preserving
    /// the distinction between a Need and a scoped Thread handle.
    pub(crate) fn awaited_payload(&self) -> Option<&Self> {
        match self.shape() {
            RuntimeTypeShape::Need(item) | RuntimeTypeShape::ThreadHandle(item) => Some(item),
            _ => None,
        }
    }

    pub(crate) fn variant_selection(
        &self,
        ordinal: u32,
    ) -> Result<RuntimeNormalizedVariantSelection<'_>, RuntimeNormalizedVariantSelectionError> {
        match self.shape() {
            RuntimeTypeShape::Result {
                value,
                error,
                value_payload,
                error_payload,
            } => {
                self.validate_unary_case_payload(0, value, value_payload)?;
                self.validate_unary_case_payload(1, error, error_payload)?;
                self.select_builtin_case(
                    RuntimeBuiltinVariantIdentity::Result,
                    ordinal,
                    [Some(value_payload.as_ref()), Some(error_payload.as_ref())].into_iter(),
                )
            }
            RuntimeTypeShape::Option { item, some_payload } => {
                self.validate_unary_case_payload(0, item, some_payload)?;
                self.select_builtin_case(
                    RuntimeBuiltinVariantIdentity::Option,
                    ordinal,
                    [Some(some_payload.as_ref()), None].into_iter(),
                )
            }
            RuntimeTypeShape::BuiltinVariant { owner, cases } => {
                self.select_builtin_case(*owner, ordinal, cases.iter().map(Option::as_ref))
            }
            _ => Err(RuntimeNormalizedVariantSelectionError::InvalidOwner {
                owner: self.identity(),
            }),
        }
    }

    fn validate_unary_case_payload(
        &self,
        ordinal: u32,
        item: &Self,
        payload: &Self,
    ) -> Result<(), RuntimeNormalizedVariantSelectionError> {
        // The aggregate type inventory owns each identity's definition. A
        // unary case must reference that exact item, not an equal checked shape.
        if matches!(payload.shape(), RuntimeTypeShape::Tuple(items)
            if matches!(items.as_ref(), [actual] if actual.identity() == item.identity()))
        {
            Ok(())
        } else {
            Err(RuntimeNormalizedVariantSelectionError::PayloadMismatch {
                owner: self.identity(),
                ordinal,
            })
        }
    }

    fn select_builtin_case<'a>(
        &'a self,
        builtin: RuntimeBuiltinVariantIdentity,
        ordinal: u32,
        cases: impl ExactSizeIterator<Item = Option<&'a Self>>,
    ) -> Result<RuntimeNormalizedVariantSelection<'a>, RuntimeNormalizedVariantSelectionError> {
        let schemas = builtin.cases();
        let case_count = u32::try_from(cases.len()).map_err(|_| {
            RuntimeNormalizedVariantSelectionError::CaseCountOverflow {
                owner: self.identity(),
                count: cases.len(),
            }
        })?;
        if cases.len() != schemas.len() {
            return Err(RuntimeNormalizedVariantSelectionError::InvalidCaseSchema {
                owner: self.identity(),
                builtin,
            });
        }
        if ordinal >= case_count {
            return Err(RuntimeNormalizedVariantSelectionError::CaseOrdinal {
                owner: self.identity(),
                ordinal,
                case_count,
            });
        }
        let mut selected = None;
        for ((index, payload), schema) in cases.enumerate().zip(schemas) {
            if schema.has_payload() != payload.is_some() {
                return Err(RuntimeNormalizedVariantSelectionError::InvalidCaseSchema {
                    owner: self.identity(),
                    builtin,
                });
            }
            if u32::try_from(index).ok() == Some(ordinal) {
                selected = payload;
            }
        }
        Ok(RuntimeNormalizedVariantSelection {
            owner: self,
            ordinal,
            payload: selected,
        })
    }

    pub fn checked_type(&self) -> Result<RuntimeCheckedType, RuntimeCheckedTypeProjectionError> {
        self.checked_type_at(&RuntimeTypeProjectionPath::root())
    }

    /// Projects this accepted semantic type into the single plan-owned type
    /// graph. Child references remain semantic identities until the aggregate
    /// builder atomically rewrites the complete batch to plan-local IDs.
    pub fn runtime_plan_type_seed(
        &self,
    ) -> Result<RuntimePlanTypeSeed, RuntimeCheckedTypeProjectionError> {
        Ok(
            RuntimePlanTypeSeed::new(self.identity, self.runtime_plan_type_projection())
                .with_scope(self.scope.clone()),
        )
    }

    fn runtime_plan_type_projection(&self) -> RuntimePlanTypeProjection<RuntimeSemanticTypeId> {
        let child = |ty: &RuntimeNormalizedType| ty.identity();
        match self.shape() {
            RuntimeTypeShape::BoundType(reference) => {
                RuntimePlanTypeProjection::BoundType(*reference)
            }
            RuntimeTypeShape::Never => RuntimePlanTypeProjection::Never,
            RuntimeTypeShape::Unit => RuntimePlanTypeProjection::Unit,
            RuntimeTypeShape::Bool => RuntimePlanTypeProjection::Bool,
            RuntimeTypeShape::Signed(width) => RuntimePlanTypeProjection::Signed(*width),
            RuntimeTypeShape::Unsigned(width) => RuntimePlanTypeProjection::Unsigned(*width),
            RuntimeTypeShape::F32 => RuntimePlanTypeProjection::F32,
            RuntimeTypeShape::F64 => RuntimePlanTypeProjection::F64,
            RuntimeTypeShape::String => RuntimePlanTypeProjection::String,
            RuntimeTypeShape::Color => RuntimePlanTypeProjection::Color,
            RuntimeTypeShape::Char => RuntimePlanTypeProjection::Char,
            RuntimeTypeShape::Bytes => RuntimePlanTypeProjection::Bytes,
            RuntimeTypeShape::Duration => RuntimePlanTypeProjection::Duration,
            RuntimeTypeShape::Progress => RuntimePlanTypeProjection::Progress,
            RuntimeTypeShape::DenseNumeric(dense) => {
                RuntimePlanTypeProjection::DenseNumeric(*dense)
            }
            RuntimeTypeShape::EntityReference(reference) => {
                RuntimePlanTypeProjection::EntityReference(
                    reference.as_ref().map(|payload| payload.identity()),
                )
            }
            RuntimeTypeShape::AgentValue => RuntimePlanTypeProjection::AgentValue,
            RuntimeTypeShape::PresentationResource(kind) => {
                RuntimePlanTypeProjection::PresentationResource(*kind)
            }
            RuntimeTypeShape::Range(item) => RuntimePlanTypeProjection::Range(child(item)),
            RuntimeTypeShape::Iterator(item) => RuntimePlanTypeProjection::Iterator(child(item)),
            RuntimeTypeShape::Sequence { kind, item } => RuntimePlanTypeProjection::Sequence {
                kind: kind.runtime_plan_kind(),
                item: child(item),
            },
            RuntimeTypeShape::Array { item, length } => RuntimePlanTypeProjection::Array {
                item: child(item),
                length: *length,
            },
            RuntimeTypeShape::Map { kind, key, value } => RuntimePlanTypeProjection::Map {
                kind: *kind,
                key: child(key),
                value: child(value),
            },
            RuntimeTypeShape::Need(item) => RuntimePlanTypeProjection::Need(child(item)),
            RuntimeTypeShape::Traversal { source, mapping } => {
                RuntimePlanTypeProjection::Traversal {
                    source: child(source),
                    mapping: child(mapping),
                }
            }
            RuntimeTypeShape::Stream { item, error } => RuntimePlanTypeProjection::Stream {
                item: child(item),
                error: child(error),
            },
            RuntimeTypeShape::Parser { .. } => {
                unreachable!("unsupported Parser shape cannot enter RuntimePlan type admission")
            }
            RuntimeTypeShape::Result {
                value,
                error,
                value_payload,
                error_payload,
            } => RuntimePlanTypeProjection::Result {
                value: child(value),
                error: child(error),
                value_payload: child(value_payload),
                error_payload: child(error_payload),
            },
            RuntimeTypeShape::Option { item, some_payload } => RuntimePlanTypeProjection::Option {
                item: child(item),
                some_payload: child(some_payload),
            },
            RuntimeTypeShape::BuiltinVariant { owner, cases } => {
                RuntimePlanTypeProjection::BuiltinVariant {
                    owner: *owner,
                    cases: cases
                        .iter()
                        .map(|payload| payload.as_ref().map(RuntimeNormalizedType::identity))
                        .collect(),
                }
            }
            RuntimeTypeShape::ThreadHandle(result) => {
                RuntimePlanTypeProjection::ThreadHandle(child(result))
            }
            RuntimeTypeShape::Shared(inner) => RuntimePlanTypeProjection::Shared(child(inner)),
            RuntimeTypeShape::Reference(inner) => {
                RuntimePlanTypeProjection::Reference(child(inner))
            }
            RuntimeTypeShape::Function {
                contract,
                parameters,
                result,
            } => RuntimePlanTypeProjection::Function {
                contract: contract.clone(),
                parameters: parameters
                    .iter()
                    .map(RuntimeNormalizedType::identity)
                    .collect(),
                result: child(result),
            },
            RuntimeTypeShape::Nominal { nominal, arguments } => {
                RuntimePlanTypeProjection::Nominal {
                    nominal: nominal.runtime_nominal_id(),
                    layout: nominal.layout(),
                    arguments: arguments
                        .iter()
                        .map(RuntimeNormalizedType::identity)
                        .collect(),
                }
            }
            RuntimeTypeShape::Tuple(items) => RuntimePlanTypeProjection::Tuple(
                items.iter().map(RuntimeNormalizedType::identity).collect(),
            ),
            RuntimeTypeShape::Record(fields) => RuntimePlanTypeProjection::Record(
                fields
                    .iter()
                    .map(|field| {
                        RuntimePlanRecordField::new(field.diagnostic_name(), field.ty().identity())
                    })
                    .collect(),
            ),
            RuntimeTypeShape::Choice(items) => RuntimePlanTypeProjection::Choice(
                items.iter().map(RuntimeNormalizedType::identity).collect(),
            ),
            RuntimeTypeShape::Opaque {
                producer,
                admission,
                value_class,
                persistence,
                arguments,
            } => RuntimePlanTypeProjection::Opaque {
                producer: producer.clone(),
                admission: *admission,
                value_class: *value_class,
                persistence: *persistence,
                arguments: arguments
                    .iter()
                    .map(RuntimeNormalizedType::identity)
                    .collect(),
            },
            RuntimeTypeShape::Agent(agent) => {
                RuntimePlanTypeProjection::Agent(agent.runtime_plan_projection())
            }
        }
    }

    pub(crate) fn append_runtime_plan_type_seeds(
        &self,
        seeds: &mut Vec<RuntimePlanTypeSeed>,
    ) -> Result<(), RuntimeCheckedTypeProjectionError> {
        seeds.push(self.runtime_plan_type_seed()?);
        for child in self.children() {
            child.append_runtime_plan_type_seeds(seeds)?;
        }
        Ok(())
    }

    fn children(&self) -> Vec<&RuntimeNormalizedType> {
        match self.shape() {
            RuntimeTypeShape::EntityReference(reference) => {
                reference.payload().map(Box::as_ref).into_iter().collect()
            }
            RuntimeTypeShape::PresentationResource(_) => Vec::new(),
            RuntimeTypeShape::Range(item)
            | RuntimeTypeShape::Iterator(item)
            | RuntimeTypeShape::ThreadHandle(item)
            | RuntimeTypeShape::Shared(item)
            | RuntimeTypeShape::Reference(item)
            | RuntimeTypeShape::Sequence { item, .. }
            | RuntimeTypeShape::Array { item, .. }
            | RuntimeTypeShape::Need(item)
            | RuntimeTypeShape::Agent(RuntimeAgentTypeShape::Probe(item)) => vec![item],
            RuntimeTypeShape::Map { key, value, .. }
            | RuntimeTypeShape::Traversal {
                source: key,
                mapping: value,
            }
            | RuntimeTypeShape::Stream {
                item: key,
                error: value,
            }
            | RuntimeTypeShape::Parser {
                item: key,
                error: value,
            } => vec![key, value],
            RuntimeTypeShape::Result {
                value: key,
                error: value,
                value_payload,
                error_payload,
            } => vec![key, value, value_payload, error_payload],
            RuntimeTypeShape::Option { item, some_payload } => vec![item, some_payload],
            RuntimeTypeShape::BuiltinVariant { cases, .. } => {
                cases.iter().filter_map(Option::as_ref).collect()
            }
            RuntimeTypeShape::Function {
                parameters, result, ..
            } => parameters
                .iter()
                .chain(std::iter::once(result.as_ref()))
                .collect(),
            RuntimeTypeShape::Nominal { arguments, .. }
            | RuntimeTypeShape::Tuple(arguments)
            | RuntimeTypeShape::Choice(arguments)
            | RuntimeTypeShape::Opaque { arguments, .. } => arguments.iter().collect(),
            RuntimeTypeShape::Record(fields) => {
                fields.iter().map(RuntimeRecordTypeField::ty).collect()
            }
            RuntimeTypeShape::BoundType(_)
            | RuntimeTypeShape::Never
            | RuntimeTypeShape::Unit
            | RuntimeTypeShape::Bool
            | RuntimeTypeShape::Signed(_)
            | RuntimeTypeShape::Unsigned(_)
            | RuntimeTypeShape::F32
            | RuntimeTypeShape::F64
            | RuntimeTypeShape::String
            | RuntimeTypeShape::Color
            | RuntimeTypeShape::Char
            | RuntimeTypeShape::Bytes
            | RuntimeTypeShape::Duration
            | RuntimeTypeShape::Progress
            | RuntimeTypeShape::DenseNumeric(_)
            | RuntimeTypeShape::AgentValue
            | RuntimeTypeShape::Agent(_) => Vec::new(),
        }
    }

    fn checked_type_at(
        &self,
        path: &RuntimeTypeProjectionPath,
    ) -> Result<RuntimeCheckedType, RuntimeCheckedTypeProjectionError> {
        if matches!(
            self.shape(),
            RuntimeTypeShape::Function { .. } | RuntimeTypeShape::Need(_)
        ) {
            return Ok(RuntimeCheckedType::ExecutableRef(self.identity()));
        }
        if let Some(checked) = self.checked_leaf_type() {
            return Ok(checked);
        }
        if let Some(shape) = unsupported_runtime_shape(self.shape()) {
            return Err(self.unsupported(path, shape));
        }
        Ok(match self.shape() {
            RuntimeTypeShape::PresentationResource(kind) => {
                RuntimeCheckedType::PresentationResource(*kind)
            }
            RuntimeTypeShape::Sequence { item, .. } => RuntimeCheckedType::Sequence(Box::new(
                item.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::SequenceItem))?,
            )),
            RuntimeTypeShape::Map { kind, key, value } => RuntimeCheckedType::Map {
                kind: *kind,
                key: Box::new(
                    key.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::MapKey))?,
                ),
                value: Box::new(
                    value.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::MapValue))?,
                ),
            },
            RuntimeTypeShape::Array { item, length } => RuntimeCheckedType::Array {
                item: Box::new(
                    item.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::SequenceItem))?,
                ),
                length: length
                    .constant()
                    .ok_or_else(|| self.unsupported(path, RuntimeUnsupportedTypeShape::Bound))?,
            },
            RuntimeTypeShape::Nominal { nominal, arguments } => RuntimeCheckedType::Nominal {
                nominal: nominal.runtime_nominal_id(),
                semantic_identity: self.identity(),
                layout: nominal.layout(),
                arguments: arguments
                    .iter()
                    .enumerate()
                    .map(|(index, argument)| {
                        argument.checked_type_at(&path.pushed(
                            RuntimeTypeProjectionStep::NominalArgument(projection_index(index)),
                        ))
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            },
            RuntimeTypeShape::Choice(alternatives) => RuntimeCheckedType::Choice(
                alternatives
                    .iter()
                    .enumerate()
                    .map(|(index, alternative)| {
                        alternative.checked_type_at(&path.pushed(
                            RuntimeTypeProjectionStep::ChoiceAlternative(projection_index(index)),
                        ))
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            RuntimeTypeShape::Tuple(items) => RuntimeCheckedType::Tuple(
                items
                    .iter()
                    .enumerate()
                    .map(|(index, item)| {
                        item.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::TupleItem(
                            projection_index(index),
                        )))
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            RuntimeTypeShape::Record(fields) => {
                let mut checked = Vec::with_capacity(fields.len());
                for (index, field) in fields.iter().enumerate() {
                    let field_path = path.pushed(RuntimeTypeProjectionStep::RecordField(
                        projection_index(index),
                    ));
                    let field_id = RuntimeRecordFieldId::try_from_zero_based_ordinal(index)
                        .map_err(|_| RuntimeCheckedTypeProjectionError::InvalidRecord {
                            semantic_identity: self.identity(),
                            path: field_path.clone(),
                            reason: RuntimeCheckedRecordTypeError::FieldOrdinalOverflow,
                        })?;
                    checked.push((
                        field_id,
                        field.diagnostic_name().to_owned(),
                        field.ty().checked_type_at(&field_path)?,
                    ));
                }
                RuntimeCheckedType::try_record(checked).map_err(|reason| {
                    RuntimeCheckedTypeProjectionError::InvalidRecord {
                        semantic_identity: self.identity(),
                        path: path.clone(),
                        reason,
                    }
                })?
            }
            RuntimeTypeShape::Result {
                value,
                error,
                value_payload,
                error_payload,
            } => {
                let value =
                    value.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::ResultOk))?;
                let error =
                    error.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::ResultError))?;
                let checked_value_payload = value_payload.checked_type_at(
                    &path.pushed(RuntimeTypeProjectionStep::BuiltinVariantCase(0)),
                )?;
                let checked_error_payload = error_payload.checked_type_at(
                    &path.pushed(RuntimeTypeProjectionStep::BuiltinVariantCase(1)),
                )?;
                if checked_value_payload != RuntimeCheckedType::Tuple(vec![value.clone()])
                    || checked_error_payload != RuntimeCheckedType::Tuple(vec![error.clone()])
                {
                    return Err(RuntimeCheckedTypeProjectionError::InvalidBuiltinVariant {
                        semantic_identity: self.identity(),
                        path: path.clone(),
                        owner: RuntimeBuiltinVariantIdentity::Result,
                    });
                }
                RuntimeCheckedType::Result {
                    ok: Box::new(value),
                    error: Box::new(error),
                }
            }
            RuntimeTypeShape::Option { item, some_payload } => {
                let item =
                    item.checked_type_at(&path.pushed(RuntimeTypeProjectionStep::OptionItem))?;
                let checked_payload = some_payload.checked_type_at(
                    &path.pushed(RuntimeTypeProjectionStep::BuiltinVariantCase(0)),
                )?;
                if checked_payload != RuntimeCheckedType::Tuple(vec![item.clone()]) {
                    return Err(RuntimeCheckedTypeProjectionError::InvalidBuiltinVariant {
                        semantic_identity: self.identity(),
                        path: path.clone(),
                        owner: RuntimeBuiltinVariantIdentity::Option,
                    });
                }
                RuntimeCheckedType::Option(Box::new(item))
            }
            RuntimeTypeShape::BuiltinVariant { owner, cases } => {
                let payloads = cases
                    .iter()
                    .enumerate()
                    .map(|(index, payload)| {
                        payload
                            .as_ref()
                            .map(|payload| {
                                payload.checked_type_at(&path.pushed(
                                    RuntimeTypeProjectionStep::BuiltinVariantCase(
                                        projection_index(index),
                                    ),
                                ))
                            })
                            .transpose()
                    })
                    .collect::<Result<Vec<_>, RuntimeCheckedTypeProjectionError>>()?;
                RuntimeCheckedType::try_builtin_variant(*owner, payloads).map_err(|_| {
                    RuntimeCheckedTypeProjectionError::InvalidBuiltinVariant {
                        semantic_identity: self.identity(),
                        path: path.clone(),
                        owner: *owner,
                    }
                })?
            }
            RuntimeTypeShape::Opaque {
                producer,
                admission,
                value_class,
                persistence,
                ..
            } => RuntimeCheckedType::Opaque {
                owner: RuntimeOpaqueTypeOwner::with_admission(
                    producer.clone(),
                    self.identity(),
                    *admission,
                    *value_class,
                    *persistence,
                ),
            },
            RuntimeTypeShape::BoundType(_)
            | RuntimeTypeShape::Never
            | RuntimeTypeShape::Unit
            | RuntimeTypeShape::Bool
            | RuntimeTypeShape::Signed(_)
            | RuntimeTypeShape::Unsigned(_)
            | RuntimeTypeShape::F32
            | RuntimeTypeShape::F64
            | RuntimeTypeShape::String
            | RuntimeTypeShape::Color
            | RuntimeTypeShape::Char
            | RuntimeTypeShape::Bytes
            | RuntimeTypeShape::Duration
            | RuntimeTypeShape::Progress
            | RuntimeTypeShape::DenseNumeric(_)
            | RuntimeTypeShape::EntityReference(_)
            | RuntimeTypeShape::AgentValue
            | RuntimeTypeShape::Range(_)
            | RuntimeTypeShape::Iterator(_)
            | RuntimeTypeShape::Need(_)
            | RuntimeTypeShape::Traversal { .. }
            | RuntimeTypeShape::Stream { .. }
            | RuntimeTypeShape::Parser { .. }
            | RuntimeTypeShape::ThreadHandle(_)
            | RuntimeTypeShape::Shared(_)
            | RuntimeTypeShape::Reference(_)
            | RuntimeTypeShape::Function { .. } => {
                unreachable!("leaf and unsupported shapes returned before recursive projection")
            }
            RuntimeTypeShape::Agent(agent) => {
                RuntimeCheckedType::Agent(agent.try_project(|child, step| {
                    child.checked_type_at(&path.pushed(step)).map(Box::new)
                })?)
            }
        })
    }

    fn checked_leaf_type(&self) -> Option<RuntimeCheckedType> {
        match self.shape() {
            RuntimeTypeShape::Never => Some(RuntimeCheckedType::Never),
            RuntimeTypeShape::Unit => Some(RuntimeCheckedType::Unit),
            RuntimeTypeShape::Bool => Some(RuntimeCheckedType::Bool),
            RuntimeTypeShape::Signed(width) => Some(RuntimeCheckedType::Signed(*width)),
            RuntimeTypeShape::Unsigned(width) => Some(RuntimeCheckedType::Unsigned(*width)),
            RuntimeTypeShape::F32 => Some(RuntimeCheckedType::F32),
            RuntimeTypeShape::F64 => Some(RuntimeCheckedType::F64),
            RuntimeTypeShape::String => Some(RuntimeCheckedType::String),
            RuntimeTypeShape::Color => Some(RuntimeCheckedType::Color),
            RuntimeTypeShape::Char => Some(RuntimeCheckedType::Char),
            RuntimeTypeShape::Bytes => Some(RuntimeCheckedType::Bytes),
            RuntimeTypeShape::Duration => Some(RuntimeCheckedType::Duration),
            RuntimeTypeShape::Progress => Some(RuntimeCheckedType::Progress),
            RuntimeTypeShape::DenseNumeric(dense) => Some(RuntimeCheckedType::DenseNumeric(*dense)),
            RuntimeTypeShape::EntityReference(reference) => {
                Some(RuntimeCheckedType::EntityReference(
                    reference.as_ref().map(|payload| payload.identity()),
                ))
            }
            RuntimeTypeShape::AgentValue => Some(RuntimeCheckedType::AgentValue),
            _ => None,
        }
    }

    fn unsupported(
        &self,
        path: &RuntimeTypeProjectionPath,
        shape: RuntimeUnsupportedTypeShape,
    ) -> RuntimeCheckedTypeProjectionError {
        RuntimeCheckedTypeProjectionError::UnsupportedRuntimeShape {
            semantic_identity: self.identity(),
            path: path.clone(),
            shape,
        }
    }
}

fn projection_index(index: usize) -> u32 {
    u32::try_from(index).expect("normalized type collections fit the u32 contract")
}

fn unsupported_runtime_shape(shape: &RuntimeTypeShape) -> Option<RuntimeUnsupportedTypeShape> {
    match shape {
        RuntimeTypeShape::BoundType(_) => Some(RuntimeUnsupportedTypeShape::Bound),
        RuntimeTypeShape::Range(_) => Some(RuntimeUnsupportedTypeShape::Range),
        RuntimeTypeShape::Iterator(_) => Some(RuntimeUnsupportedTypeShape::Iterator),
        RuntimeTypeShape::Traversal { .. } => Some(RuntimeUnsupportedTypeShape::Traversal),
        RuntimeTypeShape::Stream { .. } => Some(RuntimeUnsupportedTypeShape::Stream),
        RuntimeTypeShape::Parser { .. } => Some(RuntimeUnsupportedTypeShape::Parser),
        RuntimeTypeShape::ThreadHandle(_) => Some(RuntimeUnsupportedTypeShape::ThreadHandle),
        RuntimeTypeShape::Shared(_) => Some(RuntimeUnsupportedTypeShape::Shared),
        RuntimeTypeShape::Reference(_) => Some(RuntimeUnsupportedTypeShape::Reference),
        RuntimeTypeShape::Function { .. } => Some(RuntimeUnsupportedTypeShape::Function),
        _ => None,
    }
}

impl RuntimeAgentTypeShape {
    fn runtime_plan_projection(&self) -> RuntimeAgentTypeProjection<RuntimeSemanticTypeId> {
        self.try_project(|value, _step| Ok::<_, std::convert::Infallible>(value.identity()))
            .unwrap_or_else(|impossible| match impossible {})
    }

    fn try_project<R, E>(
        &self,
        mut project: impl FnMut(&RuntimeNormalizedType, RuntimeTypeProjectionStep) -> Result<R, E>,
    ) -> Result<RuntimeAgentTypeProjection<R>, E> {
        Ok(match self {
            Self::DebugStatePath => RuntimeAgentTypeProjection::DebugStatePath,
            Self::ObservationFieldPath => RuntimeAgentTypeProjection::ObservationFieldPath,
            Self::Probe(value) => RuntimeAgentTypeProjection::Probe(project(
                value,
                RuntimeTypeProjectionStep::AgentProbeValue,
            )?),
            Self::Predicate => RuntimeAgentTypeProjection::Predicate,
            Self::Observation => RuntimeAgentTypeProjection::Observation,
            Self::ObservedObject => RuntimeAgentTypeProjection::ObservedObject,
            Self::BoundingBox => RuntimeAgentTypeProjection::BoundingBox,
            Self::ActionName => RuntimeAgentTypeProjection::ActionName,
            Self::ActionTarget => RuntimeAgentTypeProjection::ActionTarget,
            Self::ActionResult => RuntimeAgentTypeProjection::ActionResult,
            Self::DataShape(value) => RuntimeAgentTypeProjection::DataShape(project(
                value,
                RuntimeTypeProjectionStep::AgentDataShapeValue,
            )?),
            Self::EntityMetadata => RuntimeAgentTypeProjection::EntityMetadata,
            Self::SourceAnchor => RuntimeAgentTypeProjection::SourceAnchor,
            Self::ProjectGraphNeighborhood => RuntimeAgentTypeProjection::ProjectGraphNeighborhood,
            Self::ProjectGraphSymbol => RuntimeAgentTypeProjection::ProjectGraphSymbol,
            Self::ProjectGraphEdge => RuntimeAgentTypeProjection::ProjectGraphEdge,
            Self::CaptureTarget => RuntimeAgentTypeProjection::CaptureTarget,
            Self::CaptureReference => RuntimeAgentTypeProjection::CaptureReference,
            Self::Resource => RuntimeAgentTypeProjection::Resource,
            Self::RagContextPack => RuntimeAgentTypeProjection::RagContextPack,
            Self::ObservedObjectId => RuntimeAgentTypeProjection::ObservedObjectId,
            Self::Diagnostics => RuntimeAgentTypeProjection::Diagnostics,
            Self::WaitError => RuntimeAgentTypeProjection::WaitError,
            Self::ViewportPoint => RuntimeAgentTypeProjection::ViewportPoint,
            Self::RagError => RuntimeAgentTypeProjection::RagError,
            Self::SourcePosition => RuntimeAgentTypeProjection::SourcePosition,
            Self::ProjectFlowControlSummary => {
                RuntimeAgentTypeProjection::ProjectFlowControlSummary
            }
            Self::ProjectGraphSummary => RuntimeAgentTypeProjection::ProjectGraphSummary,
            Self::BinaryResourceBody => RuntimeAgentTypeProjection::BinaryResourceBody,
            Self::BinaryData => RuntimeAgentTypeProjection::BinaryData,
        })
    }
}

impl RuntimeSequenceKind {
    const fn runtime_plan_kind(self) -> RuntimePlanSequenceKind {
        match self {
            Self::Vec => RuntimePlanSequenceKind::Vec,
            Self::Array => RuntimePlanSequenceKind::Array,
            Self::Slice => RuntimePlanSequenceKind::Slice,
            Self::Seq => RuntimePlanSequenceKind::Seq,
        }
    }
}

/// Exact project callable and its final-HIR owner item.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeProjectCallable {
    declaration: CallableDeclarationKey,
    accepted_identity: arcweft_lang_sema::semantic_coordinate::AcceptedDeclarationSemanticId,
    owner: ItemId,
    source_owner: HirCallableSourceOwner,
    runtime: RuntimeCallableId,
    attached_content_abi: Option<RuntimeCallableAttachedContentAbi>,
}

impl RuntimeProjectCallable {
    pub fn try_new(
        declaration: CallableDeclarationKey,
        accepted_identity: arcweft_lang_sema::semantic_coordinate::AcceptedDeclarationSemanticId,
        owner: ItemId,
        source_owner: HirCallableSourceOwner,
        runtime: RuntimeCallableId,
        attached_content_abi: Option<RuntimeCallableAttachedContentAbi>,
    ) -> Result<Self, RuntimeProjectCallableError> {
        if !accepted_identity.matches_declaration(&declaration) {
            return Err(RuntimeProjectCallableError::DeclarationIdentityMismatch);
        }
        if let Some(attached) = &attached_content_abi {
            attached.validate_owner(owner)?;
        }
        Ok(Self {
            declaration,
            accepted_identity,
            owner,
            source_owner,
            runtime,
            attached_content_abi,
        })
    }

    pub const fn declaration(&self) -> &CallableDeclarationKey {
        &self.declaration
    }

    /// Accepted definition identity retained independently of dispatch identity
    /// and generation-local HIR joins. Full function/body sealing is separate.
    pub const fn accepted_identity(
        &self,
    ) -> arcweft_lang_sema::semantic_coordinate::AcceptedDeclarationSemanticId {
        self.accepted_identity
    }

    pub const fn owner(&self) -> ItemId {
        self.owner
    }

    pub const fn source_owner(&self) -> HirCallableSourceOwner {
        self.source_owner
    }

    pub const fn runtime(&self) -> &RuntimeCallableId {
        &self.runtime
    }

    pub const fn attached_content_abi(&self) -> Option<&RuntimeCallableAttachedContentAbi> {
        self.attached_content_abi.as_ref()
    }
}

#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum RuntimeProjectCallableError {
    #[error("runtime project callable definition identity belongs to another declaration")]
    DeclarationIdentityMismatch,
    #[error(transparent)]
    AttachedContent(#[from] RuntimeCallableAttachedContentAbiError),
}

/// Exact declaration-side ABI for one callable-owned attached-content slot.
///
/// Generation-local HIR IDs are execution joins only. The checked default
/// coordinate/digest remain the semantic authority, so helper lowering never
/// adopts a call-site operand or reopens source/schema spelling.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeCallableAttachedContentAbi {
    group: arcweft_lang_sema::callable::CallableGroupIndex,
    abi_position: u32,
    presence: arcweft_lang_sema::callable::CallableParameterPresence,
    binding: LocalId,
    binding_ty: RuntimeNormalizedType,
    abi_ty: RuntimeNormalizedType,
    default: Option<RuntimeCallableAttachedContentDefault>,
}

impl RuntimeCallableAttachedContentAbi {
    pub fn try_new(
        group: arcweft_lang_sema::callable::CallableGroupIndex,
        abi_position: u32,
        presence: arcweft_lang_sema::callable::CallableParameterPresence,
        binding: LocalId,
        binding_ty: RuntimeNormalizedType,
        abi_ty: RuntimeNormalizedType,
        default: Option<RuntimeCallableAttachedContentDefault>,
    ) -> Result<Self, RuntimeCallableAttachedContentAbiError> {
        use arcweft_lang_sema::callable::CallableParameterPresence;

        let valid = match presence {
            CallableParameterPresence::Required => binding_ty == abi_ty && default.is_none(),
            CallableParameterPresence::Optional => {
                binding_ty == abi_ty
                    && matches!(abi_ty.shape(), RuntimeTypeShape::Option { .. })
                    && default.is_none()
            }
            CallableParameterPresence::Defaulted => {
                matches!(
                    abi_ty.shape(),
                    RuntimeTypeShape::Option { item, .. } if item.as_ref() == &binding_ty
                ) && default.is_some()
            }
        };
        if !valid {
            return Err(RuntimeCallableAttachedContentAbiError::InvalidPresenceShape);
        }
        Ok(Self {
            group,
            abi_position,
            presence,
            binding,
            binding_ty,
            abi_ty,
            default,
        })
    }

    fn validate_owner(&self, owner: ItemId) -> Result<(), RuntimeCallableAttachedContentAbiError> {
        if self.binding.module() != owner.module()
            || self
                .default
                .as_ref()
                .is_some_and(|default| default.source().module() != owner.module())
        {
            return Err(RuntimeCallableAttachedContentAbiError::ForeignOwner);
        }
        Ok(())
    }

    pub const fn presence(&self) -> arcweft_lang_sema::callable::CallableParameterPresence {
        self.presence
    }

    pub const fn group(&self) -> arcweft_lang_sema::callable::CallableGroupIndex {
        self.group
    }

    pub const fn abi_position(&self) -> u32 {
        self.abi_position
    }

    pub const fn binding(&self) -> LocalId {
        self.binding
    }

    pub const fn binding_ty(&self) -> &RuntimeNormalizedType {
        &self.binding_ty
    }

    pub const fn abi_ty(&self) -> &RuntimeNormalizedType {
        &self.abi_ty
    }

    pub const fn default(&self) -> Option<&RuntimeCallableAttachedContentDefault> {
        self.default.as_ref()
    }

    pub(crate) fn append_runtime_plan_type_seeds(
        &self,
        seeds: &mut Vec<RuntimePlanTypeSeed>,
    ) -> Result<(), RuntimeCheckedTypeProjectionError> {
        self.binding_ty.append_runtime_plan_type_seeds(seeds)?;
        self.abi_ty.append_runtime_plan_type_seeds(seeds)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeCallableAttachedContentDefault {
    source: ExprId,
    coordinate: arcweft_lang_sema::semantic_coordinate::StableCheckedValueCoordinate,
    digest: arcweft_lang_sema::callable::CheckedDeclarationDefaultExpressionDigest,
}

impl RuntimeCallableAttachedContentDefault {
    pub const fn new(
        source: ExprId,
        coordinate: arcweft_lang_sema::semantic_coordinate::StableCheckedValueCoordinate,
        digest: arcweft_lang_sema::callable::CheckedDeclarationDefaultExpressionDigest,
    ) -> Self {
        Self {
            source,
            coordinate,
            digest,
        }
    }

    pub const fn source(&self) -> ExprId {
        self.source
    }

    pub const fn coordinate(
        &self,
    ) -> &arcweft_lang_sema::semantic_coordinate::StableCheckedValueCoordinate {
        &self.coordinate
    }

    pub const fn digest(
        &self,
    ) -> arcweft_lang_sema::callable::CheckedDeclarationDefaultExpressionDigest {
        self.digest
    }
}

#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum RuntimeCallableAttachedContentAbiError {
    #[error("runtime callable attached-content presence/type/default rows are inconsistent")]
    InvalidPresenceShape,
    #[error("runtime callable attached-content binding or default belongs to another HIR owner")]
    ForeignOwner,
}

/// Declaration authority of one exact structural nominal. Rust declarations
/// retain their accepted source lease and never acquire a synthetic HIR item.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedNominalSource {
    Project {
        declaration: ProjectNominalDeclarationId,
        owner: ItemId,
    },
    ClosedVariant {
        proof: arcweft_lang_sema::final_analysis::CheckedVariantOwner,
    },
    BuiltinRecord {
        owner: arcweft_lang_sema::env::nominal::AcceptedNominalId,
    },
    CharacterDialoguePolicy {
        owner: CharacterDialoguePolicyVariantOwner,
    },
    AcceptedRust(Arc<arcweft_lang_sema::final_analysis::RuntimeAcceptedRustNominalProjection>),
}

/// Exact source nominal and its executable identity.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedNominal {
    source: RuntimeResolvedNominalSource,
    runtime_nominal: RuntimeNominalTypeId,
    identity: RuntimeSemanticTypeId,
    layout: TypeLayoutHash,
    source_graph: Arc<RuntimeNominalSchemaGraph>,
}

impl RuntimeResolvedNominal {
    pub const fn project(
        declaration: ProjectNominalDeclarationId,
        owner: ItemId,
        runtime_nominal: RuntimeNominalTypeId,
        identity: RuntimeSemanticTypeId,
        layout: TypeLayoutHash,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
    ) -> Self {
        Self {
            source: RuntimeResolvedNominalSource::Project { declaration, owner },
            runtime_nominal,
            identity,
            layout,
            source_graph,
        }
    }

    pub fn accepted_rust(
        projection: arcweft_lang_sema::final_analysis::RuntimeAcceptedRustNominalProjection,
    ) -> Self {
        Self {
            runtime_nominal: projection.nominal().clone(),
            identity: projection.root(),
            layout: projection.layout(),
            source_graph: Arc::clone(projection.graph()),
            source: RuntimeResolvedNominalSource::AcceptedRust(Arc::new(projection)),
        }
    }

    pub fn closed_variant(
        proof: arcweft_lang_sema::final_analysis::CheckedVariantOwner,
        runtime_nominal: RuntimeNominalTypeId,
        identity: RuntimeSemanticTypeId,
        layout: TypeLayoutHash,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
    ) -> Self {
        Self {
            source: RuntimeResolvedNominalSource::ClosedVariant { proof },
            runtime_nominal,
            identity,
            layout,
            source_graph,
        }
    }

    pub fn builtin_record(
        owner: arcweft_lang_sema::env::nominal::AcceptedNominalId,
        runtime_nominal: RuntimeNominalTypeId,
        identity: RuntimeSemanticTypeId,
        layout: TypeLayoutHash,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
    ) -> Self {
        Self {
            source: RuntimeResolvedNominalSource::BuiltinRecord { owner },
            runtime_nominal,
            identity,
            layout,
            source_graph,
        }
    }

    /// Retains an exact nominal owner from the shared CharacterDialogue
    /// policy graph.
    pub fn character_dialogue_policy(
        owner: CharacterDialoguePolicyVariantOwner,
        policy_types: &Arc<CharacterDialoguePolicyTypeGraph>,
    ) -> Self {
        let RuntimeVariantIdentity::Nominal {
            nominal,
            semantic_identity,
            layout,
        } = policy_types.identity(owner)
        else {
            unreachable!("CharacterDialogue policy owners are nominal variants")
        };
        Self {
            source: RuntimeResolvedNominalSource::CharacterDialoguePolicy { owner },
            runtime_nominal: nominal.clone(),
            identity: *semantic_identity,
            layout: *layout,
            source_graph: Arc::clone(policy_types.schema_graph()),
        }
    }

    pub const fn source(&self) -> &RuntimeResolvedNominalSource {
        &self.source
    }

    fn valid_for_project(&self, project: HirAnalysisProjectView<'_>) -> bool {
        match &self.source {
            RuntimeResolvedNominalSource::Project { .. } => true,
            RuntimeResolvedNominalSource::ClosedVariant { .. } => true,
            RuntimeResolvedNominalSource::BuiltinRecord { .. } => true,
            RuntimeResolvedNominalSource::CharacterDialoguePolicy { .. } => true,
            RuntimeResolvedNominalSource::AcceptedRust(projection) => {
                projection.validate_project(project).is_ok()
            }
        }
    }

    pub const fn identity(&self) -> RuntimeSemanticTypeId {
        self.identity
    }

    pub const fn layout(&self) -> TypeLayoutHash {
        self.layout
    }

    pub const fn source_graph(&self) -> &Arc<RuntimeNominalSchemaGraph> {
        &self.source_graph
    }

    #[must_use]
    pub fn runtime_nominal_id(&self) -> RuntimeNominalTypeId {
        self.runtime_nominal.clone()
    }

    #[must_use]
    /// Projects the checked nominal owner retained by this accepted fact.
    ///
    /// # Panics
    ///
    /// Panics only if an accepted project declaration violates the invariant
    /// that its qualified name is a valid runtime nominal identity.
    pub fn checked_type(&self) -> RuntimeCheckedType {
        RuntimeCheckedType::Nominal {
            nominal: self.runtime_nominal_id(),
            semantic_identity: self.identity,
            layout: self.layout,
            arguments: Vec::new(),
        }
    }
}

/// Complete writable-place decision for one final-HIR assignment.
///
/// The compiler projects this once from semantic analysis. Runtime lowerers
/// consume its local base, exact nominal layout identity, field ordinal, and
/// normalized operand types without reinterpreting HIR place syntax.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeAssignmentFact {
    place: RuntimeResolvedPlace,
    value_type: RuntimeNormalizedType,
}

/// One source-ordered Pending observer projected from checked semantics.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeAwaitPendingObserverFact {
    pattern: PatternId,
}

impl RuntimeAwaitPendingObserverFact {
    pub const fn new(pattern: PatternId) -> Self {
        Self { pattern }
    }

    pub const fn pattern(&self) -> PatternId {
        self.pattern
    }
}

/// Checked temporal operand and its Pending observers for one Await expression.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeAwaitFact {
    operand: ExprId,
    observers: Box<[RuntimeAwaitPendingObserverFact]>,
}

/// Exact runtime Flow selected for one compact Choice `goto` arm.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeChoiceGotoFact {
    arm: u32,
    target: RuntimeProjectItem,
}

impl RuntimeChoiceGotoFact {
    pub const fn new(arm: u32, target: RuntimeProjectItem) -> Self {
        Self { arm, target }
    }

    pub const fn arm(&self) -> u32 {
        self.arm
    }

    pub const fn target(&self) -> &RuntimeProjectItem {
        &self.target
    }
}

/// Generation-bound semantic additions consumed when lowering one Choice.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeChoiceFact {
    public_id: Option<PublicId>,
    option_ids: Box<[PublicId]>,
    gotos: Box<[RuntimeChoiceGotoFact]>,
}

impl RuntimeChoiceFact {
    pub fn new(
        public_id: Option<PublicId>,
        option_ids: impl Into<Box<[PublicId]>>,
        gotos: impl Into<Box<[RuntimeChoiceGotoFact]>>,
    ) -> Self {
        Self {
            public_id,
            option_ids: option_ids.into(),
            gotos: gotos.into(),
        }
    }

    pub const fn public_id(&self) -> Option<&PublicId> {
        self.public_id.as_ref()
    }

    pub fn option_ids(&self) -> &[PublicId] {
        &self.option_ids
    }

    pub fn gotos(&self) -> &[RuntimeChoiceGotoFact] {
        &self.gotos
    }

    pub fn goto_for_arm(&self, arm: u32) -> Option<&RuntimeProjectItem> {
        self.gotos
            .binary_search_by_key(&arm, RuntimeChoiceGotoFact::arm)
            .ok()
            .map(|index| self.gotos[index].target())
    }
}

impl RuntimeAwaitFact {
    pub fn new(
        operand: ExprId,
        observers: impl Into<Box<[RuntimeAwaitPendingObserverFact]>>,
    ) -> Self {
        Self {
            operand,
            observers: observers.into(),
        }
    }

    pub const fn operand(&self) -> ExprId {
        self.operand
    }

    pub fn observers(&self) -> &[RuntimeAwaitPendingObserverFact] {
        &self.observers
    }
}

/// Closed carrier consumed by one checked prefix Try expression.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeTryCarrierFact {
    Result {
        success: RuntimeNormalizedType,
        residual: Box<RuntimeNormalizedType>,
    },
    Option {
        success: RuntimeNormalizedType,
    },
}

impl RuntimeTryCarrierFact {
    pub const fn success(&self) -> &RuntimeNormalizedType {
        match self {
            Self::Result { success, .. } | Self::Option { success } => success,
        }
    }

    pub fn residual(&self) -> Option<&RuntimeNormalizedType> {
        match self {
            Self::Result { residual, .. } => Some(residual.as_ref()),
            Self::Option { .. } => None,
        }
    }
}

/// Exact lexical owner that receives one checked Try residual.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeAcceptedDeclarationSemanticId([u8; 32]);

impl RuntimeAcceptedDeclarationSemanticId {
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    pub const fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }
}

/// Exact lexical owner that receives one checked Try residual.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeTryBoundaryOwner {
    Infallible,
    CarrierBlock(ExprId),
    Thread(ExprId),
    ExplicitFunctionSite(ExprId),
    ImplicitFunctionSite(ExprId),
    Callable(RuntimeAcceptedDeclarationSemanticId),
}

/// Generation-bound Try carrier and propagation-boundary fact.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeTryFact {
    operand: ExprId,
    carrier_type: RuntimeNormalizedType,
    carrier: RuntimeTryCarrierFact,
    boundary: RuntimeTryBoundaryOwner,
    boundary_type: RuntimeNormalizedType,
}

/// Generation-bound implicit callable projection for one `_` abstraction.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeImplicitCallableFact {
    definition: arcweft_lang_sema::final_analysis::FinalAnalysisImplicitCallableDefinition,
    formal: arcweft_lang_sema::final_analysis::CheckedExecutionParameter,
    captures: Box<[RuntimeImplicitCallableCaptureFact]>,
    parameter: RuntimeNormalizedType,
    result: RuntimeNormalizedType,
    placeholders: Box<[ExprId]>,
}

impl RuntimeImplicitCallableFact {
    pub fn try_new(
        definition: arcweft_lang_sema::final_analysis::FinalAnalysisImplicitCallableDefinition,
        formal: arcweft_lang_sema::final_analysis::CheckedExecutionParameter,
        parameter: RuntimeNormalizedType,
        result: RuntimeNormalizedType,
        placeholders: Box<[ExprId]>,
        authority: &CheckedLocalUseAuthority,
    ) -> Result<Self, RuntimeImplicitCallableAuthorityError> {
        if !matches!(formal.origin(), arcweft_lang_sema::final_analysis::CheckedExecutionParameterOrigin::Implicit(identity) if *identity == definition.identity())
            || formal.authority() != authority
            || formal.definition_identity() != definition.definition_identity()
            || formal.pattern().is_some()
            || !formal.bindings().is_empty()
        {
            return Err(RuntimeImplicitCallableAuthorityError);
        }
        let captures = definition
            .captures()
            .iter()
            .map(|origin| {
                let transfer = authority
                    .value_transfer_at(
                        arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Capture {
                            owner: definition.owner(),
                            local: origin.local(),
                        },
                    )
                    .ok_or(RuntimeImplicitCallableAuthorityError)?;
                if transfer.local() != origin.local()
                    || !transfer.fields().is_empty()
                    || transfer.mode()
                        == arcweft_lang_sema::final_analysis::CheckedLocalReadMode::Borrow
                {
                    return Err(RuntimeImplicitCallableAuthorityError);
                }
                Ok(RuntimeImplicitCallableCaptureFact {
                    origin: origin.clone(),
                    transfer,
                })
            })
            .collect::<Result<Box<[_]>, _>>()?;
        Ok(Self {
            definition,
            formal,
            captures,
            parameter,
            result,
            placeholders,
        })
    }

    pub const fn identity(
        &self,
    ) -> arcweft_lang_sema::final_analysis::CheckedImplicitCallableIdentity {
        self.definition.identity()
    }

    pub const fn control(&self) -> arcweft_lang_sema::final_analysis::CheckedExecutableControlRole {
        self.definition.control()
    }

    pub const fn parameter(&self) -> &RuntimeNormalizedType {
        &self.parameter
    }

    pub const fn formal(&self) -> &arcweft_lang_sema::final_analysis::CheckedExecutionParameter {
        &self.formal
    }

    pub const fn result(&self) -> &RuntimeNormalizedType {
        &self.result
    }

    pub const fn placeholders(&self) -> &[ExprId] {
        &self.placeholders
    }

    pub const fn definition(
        &self,
    ) -> &arcweft_lang_sema::final_analysis::FinalAnalysisImplicitCallableDefinition {
        &self.definition
    }
    pub const fn definition_identity(
        &self,
    ) -> arcweft_lang_sema::final_analysis::CheckedExecutionDefinitionIdentity {
        self.definition.definition_identity()
    }
    pub const fn captures(&self) -> &[RuntimeImplicitCallableCaptureFact] {
        &self.captures
    }
}

/// Capture origin and closed transfer selected from the same accepted authority.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeImplicitCallableCaptureFact {
    origin: arcweft_lang_sema::final_analysis::CheckedImplicitCallableCaptureOrigin,
    transfer: arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer,
}
impl RuntimeImplicitCallableCaptureFact {
    pub const fn position(&self) -> u32 {
        self.origin.position()
    }
    pub const fn local(&self) -> LocalId {
        self.origin.local()
    }
    pub const fn origin(
        &self,
    ) -> &arcweft_lang_sema::semantic_coordinate::StableCheckedBindingCoordinate {
        self.origin.origin()
    }
    pub const fn transfer(&self) -> &arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer {
        &self.transfer
    }
}
#[derive(Clone, Debug, Eq, Error, PartialEq)]
#[error("implicit callable formal or capture lacks its accepted execution authority")]
pub struct RuntimeImplicitCallableAuthorityError;

/// Generation-bound once-only pipeline and its checked `^` uses.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimePipeFact {
    binding_identity: arcweft_lang_sema::final_analysis::CheckedPipeBindingIdentity,
    left: ExprId,
    right: ExprId,
    placeholders: Box<[ExprId]>,
}

impl RuntimePipeFact {
    pub const fn new(
        binding_identity: arcweft_lang_sema::final_analysis::CheckedPipeBindingIdentity,
        left: ExprId,
        right: ExprId,
        placeholders: Box<[ExprId]>,
    ) -> Self {
        Self {
            binding_identity,
            left,
            right,
            placeholders,
        }
    }

    pub const fn binding_identity(
        &self,
    ) -> arcweft_lang_sema::final_analysis::CheckedPipeBindingIdentity {
        self.binding_identity
    }

    pub const fn left(&self) -> ExprId {
        self.left
    }

    pub const fn right(&self) -> ExprId {
        self.right
    }

    pub const fn placeholders(&self) -> &[ExprId] {
        &self.placeholders
    }
}

impl RuntimeTryFact {
    pub const fn new(
        operand: ExprId,
        carrier_type: RuntimeNormalizedType,
        carrier: RuntimeTryCarrierFact,
        boundary: RuntimeTryBoundaryOwner,
        boundary_type: RuntimeNormalizedType,
    ) -> Self {
        Self {
            operand,
            carrier_type,
            carrier,
            boundary,
            boundary_type,
        }
    }

    pub const fn operand(&self) -> ExprId {
        self.operand
    }

    pub const fn carrier_type(&self) -> &RuntimeNormalizedType {
        &self.carrier_type
    }

    pub const fn carrier(&self) -> &RuntimeTryCarrierFact {
        &self.carrier
    }

    pub const fn boundary(&self) -> RuntimeTryBoundaryOwner {
        self.boundary
    }

    pub const fn boundary_type(&self) -> &RuntimeNormalizedType {
        &self.boundary_type
    }
}

fn try_boundary_type_matches(fact: &RuntimeTryFact) -> bool {
    match (fact.carrier(), fact.boundary_type().shape()) {
        (
            RuntimeTryCarrierFact::Result { residual, .. },
            RuntimeTypeShape::Result { error, .. },
        ) => {
            residual.as_ref() == error.as_ref()
                || matches!(residual.shape(), RuntimeTypeShape::Never)
        }
        (RuntimeTryCarrierFact::Option { .. }, RuntimeTypeShape::Option { .. }) => true,
        _ => false,
    }
}

/// Checked iterator dispatch before plan-local type and method IDs are issued.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeIteratorFact {
    Builtin(Box<RuntimeBuiltinIteratorFact>),
    Witness(Box<RuntimeIteratorWitnessFact>),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeBuiltinIteratorFact {
    family: RuntimeBuiltinIteratorFamily,
    item: RuntimeNormalizedType,
    iterator: RuntimeNormalizedType,
    next_value: RuntimeNormalizedType,
    step: RuntimeNormalizedType,
}

impl RuntimeBuiltinIteratorFact {
    pub const fn new(
        family: RuntimeBuiltinIteratorFamily,
        item: RuntimeNormalizedType,
        iterator: RuntimeNormalizedType,
        next_value: RuntimeNormalizedType,
        step: RuntimeNormalizedType,
    ) -> Self {
        Self {
            family,
            item,
            iterator,
            next_value,
            step,
        }
    }

    pub const fn family(&self) -> RuntimeBuiltinIteratorFamily {
        self.family
    }

    pub const fn item(&self) -> &RuntimeNormalizedType {
        &self.item
    }

    pub const fn iterator(&self) -> &RuntimeNormalizedType {
        &self.iterator
    }

    pub const fn next_value(&self) -> &RuntimeNormalizedType {
        &self.next_value
    }

    pub const fn step(&self) -> &RuntimeNormalizedType {
        &self.step
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeIteratorWitnessFact {
    item: RuntimeNormalizedType,
    iterator: RuntimeNormalizedType,
    executable: RuntimeIteratorWitnessExecutableFact,
}

impl RuntimeIteratorWitnessFact {
    pub const fn new(
        item: RuntimeNormalizedType,
        iterator: RuntimeNormalizedType,
        executable: RuntimeIteratorWitnessExecutableFact,
    ) -> Self {
        Self {
            item,
            iterator,
            executable,
        }
    }

    pub const fn item(&self) -> &RuntimeNormalizedType {
        &self.item
    }

    pub const fn iterator(&self) -> &RuntimeNormalizedType {
        &self.iterator
    }

    pub const fn executable(&self) -> &RuntimeIteratorWitnessExecutableFact {
        &self.executable
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeIteratorWitnessExecutableFact {
    TraitCalls {
        into_iter: ImplMethodDeclarationId,
        next: ImplMethodDeclarationId,
    },
    IdentityIntoIterator {
        next: ImplMethodDeclarationId,
    },
}

impl RuntimeAssignmentFact {
    pub const fn new(place: RuntimeResolvedPlace, value_type: RuntimeNormalizedType) -> Self {
        Self { place, value_type }
    }

    pub const fn place(&self) -> &RuntimeResolvedPlace {
        &self.place
    }

    pub const fn value_type(&self) -> &RuntimeNormalizedType {
        &self.value_type
    }
}

/// One checked nominal-record fact paired with its executable field layout.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedNominalRecord {
    nominal: RuntimeResolvedNominal,
    layout: Arc<RuntimeNominalRecordLayout>,
    fields: Box<[RuntimeResolvedNominalRecordField]>,
}

/// One defining-order nominal-record field with its exact normalized type.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedNominalRecordField {
    name: Option<String>,
    ty: RuntimeNormalizedType,
}

/// Runtime-only source retained from one C2-sealed record-expression row.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeRecordExpressionSource {
    Expression(ExprId),
    Binding(LocalId),
}

/// One source-ordered executable record-expression field.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RuntimeRecordExpressionField {
    field: RuntimeRecordFieldId,
    source: RuntimeRecordExpressionSource,
}

impl RuntimeRecordExpressionField {
    pub const fn new(field: RuntimeRecordFieldId, source: RuntimeRecordExpressionSource) -> Self {
        Self { field, source }
    }

    pub const fn field(&self) -> RuntimeRecordFieldId {
        self.field
    }

    pub const fn source(&self) -> RuntimeRecordExpressionSource {
        self.source
    }
}

/// Atomic executable projection of one nominal-record expression.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeRecordExpressionFact {
    nominal: RuntimeResolvedNominalRecord,
    fields: Box<[RuntimeRecordExpressionField]>,
}

/// Runtime-only source retained from one C2-sealed record-pattern row.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeRecordPatternSource {
    Pattern(PatternId),
    Binding(LocalId),
}

/// One source-ordered executable record-pattern field.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RuntimeRecordPatternField {
    field: RuntimeRecordFieldId,
    source: RuntimeRecordPatternSource,
}

impl RuntimeRecordPatternField {
    pub const fn new(field: RuntimeRecordFieldId, source: RuntimeRecordPatternSource) -> Self {
        Self { field, source }
    }

    pub const fn field(&self) -> RuntimeRecordFieldId {
        self.field
    }

    pub const fn source(&self) -> RuntimeRecordPatternSource {
        self.source
    }
}

/// Exact runtime disposition of an authored record-pattern rest row.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeRecordPatternRest {
    Absent,
    Ignore,
    Binding(LocalId),
}

/// Atomic executable projection of one nominal-record pattern.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeRecordPatternFact {
    owner: RuntimeRecordPatternOwner,
    fields: Box<[RuntimeRecordPatternField]>,
    rest: RuntimeRecordPatternRest,
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum RuntimeRecordPatternOwner {
    Nominal(RuntimeResolvedNominalRecord),
    Structural(RuntimeNormalizedType),
}

/// Invalid executable record plan projected from checked semantics.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeRecordPlanError {
    #[error("record plan contains field {field} more than once")]
    DuplicateField { field: RuntimeRecordFieldId },
    #[error("record plan references field {field} outside its nominal layout")]
    UnknownField { field: RuntimeRecordFieldId },
    #[error("complete record plan has {actual} fields, expected {expected}")]
    Incomplete { expected: usize, actual: usize },
    #[error("structural record pattern owner is not an exact checked record type")]
    InvalidStructuralOwner,
}

fn validate_runtime_record_fields(
    field_count: usize,
    fields: impl IntoIterator<Item = RuntimeRecordFieldId>,
    require_complete: bool,
) -> Result<(), RuntimeRecordPlanError> {
    let mut seen = BTreeSet::new();
    for field in fields {
        if usize::try_from(field.zero_based()).map_or(true, |ordinal| ordinal >= field_count) {
            return Err(RuntimeRecordPlanError::UnknownField { field });
        }
        if !seen.insert(field) {
            return Err(RuntimeRecordPlanError::DuplicateField { field });
        }
    }
    if require_complete && seen.len() != field_count {
        return Err(RuntimeRecordPlanError::Incomplete {
            expected: field_count,
            actual: seen.len(),
        });
    }
    Ok(())
}

impl RuntimeRecordExpressionFact {
    pub fn try_new(
        nominal: RuntimeResolvedNominalRecord,
        fields: impl Into<Box<[RuntimeRecordExpressionField]>>,
    ) -> Result<Self, RuntimeRecordPlanError> {
        let fields = fields.into();
        validate_runtime_record_fields(
            nominal.layout().len(),
            fields.iter().map(|field| field.field),
            true,
        )?;
        Ok(Self { nominal, fields })
    }

    pub const fn nominal(&self) -> &RuntimeResolvedNominalRecord {
        &self.nominal
    }

    pub const fn fields(&self) -> &[RuntimeRecordExpressionField] {
        &self.fields
    }

    fn nominal_mut(&mut self) -> &mut RuntimeResolvedNominalRecord {
        &mut self.nominal
    }
}

impl RuntimeRecordPatternFact {
    pub fn try_new(
        nominal: RuntimeResolvedNominalRecord,
        fields: impl Into<Box<[RuntimeRecordPatternField]>>,
        rest: RuntimeRecordPatternRest,
    ) -> Result<Self, RuntimeRecordPlanError> {
        let fields = fields.into();
        validate_runtime_record_fields(
            nominal.layout().len(),
            fields.iter().map(|field| field.field),
            matches!(rest, RuntimeRecordPatternRest::Absent),
        )?;
        Ok(Self {
            owner: RuntimeRecordPatternOwner::Nominal(nominal),
            fields,
            rest,
        })
    }

    pub fn try_structural(
        owner: RuntimeNormalizedType,
        fields: impl Into<Box<[RuntimeRecordPatternField]>>,
        rest: RuntimeRecordPatternRest,
    ) -> Result<Self, RuntimeRecordPlanError> {
        let RuntimeTypeShape::Record(schema) = owner.shape() else {
            return Err(RuntimeRecordPlanError::InvalidStructuralOwner);
        };
        if !matches!(owner.checked_type(), Ok(RuntimeCheckedType::Record(_))) {
            return Err(RuntimeRecordPlanError::InvalidStructuralOwner);
        }
        let fields = fields.into();
        validate_runtime_record_fields(
            schema.len(),
            fields.iter().map(|field| field.field),
            matches!(rest, RuntimeRecordPatternRest::Absent),
        )?;
        Ok(Self {
            owner: RuntimeRecordPatternOwner::Structural(owner),
            fields,
            rest,
        })
    }

    pub const fn nominal(&self) -> Option<&RuntimeResolvedNominalRecord> {
        match &self.owner {
            RuntimeRecordPatternOwner::Nominal(nominal) => Some(nominal),
            RuntimeRecordPatternOwner::Structural(_) => None,
        }
    }

    pub const fn structural(&self) -> Option<&RuntimeNormalizedType> {
        match &self.owner {
            RuntimeRecordPatternOwner::Structural(ty) => Some(ty),
            RuntimeRecordPatternOwner::Nominal(_) => None,
        }
    }

    pub const fn fields(&self) -> &[RuntimeRecordPatternField] {
        &self.fields
    }

    pub const fn rest(&self) -> RuntimeRecordPatternRest {
        self.rest
    }

    fn nominal_mut(&mut self) -> Option<&mut RuntimeResolvedNominalRecord> {
        match &mut self.owner {
            RuntimeRecordPatternOwner::Nominal(nominal) => Some(nominal),
            RuntimeRecordPatternOwner::Structural(_) => None,
        }
    }
}

/// Failure to pair a nominal fact with an executable record layout.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeNominalRecordFactError {
    #[error("nominal record fact has runtime identity {actual:?}, expected {expected:?}")]
    NominalIdentity {
        expected: RuntimeNominalTypeId,
        actual: RuntimeNominalTypeId,
    },
    #[error("nominal record fact has a different semantic identity")]
    SemanticIdentity {
        expected: RuntimeSemanticTypeId,
        actual: RuntimeSemanticTypeId,
    },
    #[error("nominal record fact has a different layout identity")]
    LayoutIdentity {
        expected: TypeLayoutHash,
        actual: TypeLayoutHash,
    },
    #[error("nominal record layout shape {actual:?} differs from its source definition")]
    SourceShape { actual: RuntimeNominalRecordShape },
    #[error("nominal record fact has {actual} normalized fields, expected {expected}")]
    FieldCount { expected: usize, actual: usize },
    #[error("nominal record field {ordinal} resolved as {actual:?}, expected {expected:?}")]
    FieldName {
        ordinal: usize,
        expected: Option<String>,
        actual: Option<String>,
    },
    #[error("nominal record field {ordinal} has a different checked projection")]
    FieldType { ordinal: usize },
}

impl RuntimeResolvedNominalRecord {
    /// Pairs one accepted nominal fact with its executable record layout.
    ///
    /// # Panics
    ///
    /// Panics only if an accepted project declaration violates the invariant
    /// that its qualified name is a valid runtime nominal identity.
    pub fn try_new(
        nominal: RuntimeResolvedNominal,
        layout: Arc<RuntimeNominalRecordLayout>,
        fields: impl IntoIterator<Item = (Option<String>, RuntimeNormalizedType)>,
    ) -> Result<Self, RuntimeNominalRecordFactError> {
        let expected = nominal.runtime_nominal_id();
        if layout.nominal() != &expected {
            return Err(RuntimeNominalRecordFactError::NominalIdentity {
                expected,
                actual: layout.nominal().clone(),
            });
        }
        if layout.semantic_identity() != nominal.identity() {
            return Err(RuntimeNominalRecordFactError::SemanticIdentity {
                expected: nominal.identity(),
                actual: layout.semantic_identity(),
            });
        }
        if layout.layout() != nominal.layout() {
            return Err(RuntimeNominalRecordFactError::LayoutIdentity {
                expected: nominal.layout(),
                actual: layout.layout(),
            });
        }
        if !matches!(
            nominal.source_graph().definition(nominal.identity()).map(|definition| definition.body()),
            Some(arcweft_core::entry::RuntimeNominalSchemaBody::Record { shape, .. })
                if *shape == layout.shape()
        ) {
            return Err(RuntimeNominalRecordFactError::SourceShape {
                actual: layout.shape(),
            });
        }
        let fields = fields
            .into_iter()
            .map(|(name, ty)| RuntimeResolvedNominalRecordField { name, ty })
            .collect::<Vec<_>>()
            .into_boxed_slice();
        if fields.len() != layout.fields().len() {
            return Err(RuntimeNominalRecordFactError::FieldCount {
                expected: layout.fields().len(),
                actual: fields.len(),
            });
        }
        for (ordinal, (field, accepted)) in fields.iter().zip(layout.fields()).enumerate() {
            if field.name.as_deref() != accepted.name() {
                return Err(RuntimeNominalRecordFactError::FieldName {
                    ordinal,
                    expected: accepted.name().map(str::to_owned),
                    actual: field.name.clone(),
                });
            }
            if field.ty.checked_type().ok().as_ref() != Some(accepted.checked_type()) {
                return Err(RuntimeNominalRecordFactError::FieldType { ordinal });
            }
        }
        Ok(Self {
            nominal,
            layout,
            fields,
        })
    }

    pub const fn nominal(&self) -> &RuntimeResolvedNominal {
        &self.nominal
    }

    pub const fn layout(&self) -> &Arc<RuntimeNominalRecordLayout> {
        &self.layout
    }

    pub const fn fields(&self) -> &[RuntimeResolvedNominalRecordField] {
        &self.fields
    }

    #[must_use]
    pub fn checked_type(&self) -> RuntimeCheckedType {
        self.layout.checked_type()
    }
}

impl RuntimeResolvedNominalRecordField {
    pub fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    pub const fn ty(&self) -> &RuntimeNormalizedType {
        &self.ty
    }
}

/// Stable entity identity paired with its closed accepted owner kind.
///
/// Retained declarations keep their exact HIR owner. Registered Characters
/// keep the externally validated Character public identity without fabricating
/// an [`ItemId`]. Runtime lowering never reconstructs either identity from
/// source syntax.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeProjectItemOwner {
    Retained(ItemId),
    StructuralFlow {
        owner: ItemId,
        runtime: FlowRuntimeId,
    },
    ExternalCharacter,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeProjectItem {
    public_id: PublicId,
    family: DeclarationIdentityFamily,
    owner: RuntimeProjectItemOwner,
}

impl RuntimeProjectItem {
    pub fn new_retained(
        public_id: PublicId,
        family: DeclarationIdentityFamily,
        owner: ItemId,
    ) -> Self {
        Self {
            public_id,
            family,
            owner: RuntimeProjectItemOwner::Retained(owner),
        }
    }

    pub fn new_external_character(public_id: PublicId) -> Self {
        Self {
            public_id,
            family: DeclarationIdentityFamily::Character,
            owner: RuntimeProjectItemOwner::ExternalCharacter,
        }
    }

    pub fn new_structural_flow(public_id: PublicId, owner: ItemId, runtime: FlowRuntimeId) -> Self {
        Self {
            public_id,
            family: DeclarationIdentityFamily::Flow,
            owner: RuntimeProjectItemOwner::StructuralFlow { owner, runtime },
        }
    }

    pub const fn public_id(&self) -> &PublicId {
        &self.public_id
    }

    pub const fn family(&self) -> DeclarationIdentityFamily {
        self.family
    }

    pub const fn owner(&self) -> &RuntimeProjectItemOwner {
        &self.owner
    }

    pub const fn retained_owner(&self) -> Option<ItemId> {
        match &self.owner {
            RuntimeProjectItemOwner::Retained(owner) => Some(*owner),
            RuntimeProjectItemOwner::StructuralFlow { .. }
            | RuntimeProjectItemOwner::ExternalCharacter => None,
        }
    }

    pub const fn flow_runtime_id(&self) -> Option<&FlowRuntimeId> {
        match &self.owner {
            RuntimeProjectItemOwner::StructuralFlow { runtime, .. } => Some(runtime),
            RuntimeProjectItemOwner::Retained(_) | RuntimeProjectItemOwner::ExternalCharacter => {
                None
            }
        }
    }
}

/// Checked meaning of one final-HIR path expression.
#[derive(Clone, Debug, PartialEq)]
pub enum RuntimeResolvedValue {
    Local(LocalId),
    RegistryRead(arcweft_lang_sema::final_analysis::CheckedRegistryRead),
    Place(RuntimeResolvedPlace),
    ProjectCallable {
        callable: RuntimeProjectCallable,
        target: RuntimeProjectCallableValueTarget,
    },
    ExternalCallable(
        Box<arcweft_lang_sema::final_analysis::CheckedExternalCallableValueProjection>,
    ),
    /// Final Sema's accepted expression, actual entity payload and type key.
    Entity(arcweft_lang_sema::final_analysis::CheckedEntityValueProjection),
    /// Checked one-way lowering of a durable `say.*` identity into the
    /// path-only runtime line domain.
    DialogueLine(RuntimeLineId),
    Intrinsic(RuntimeIntrinsic),
    Registered(RuntimeRegisteredValueId),
    Constant(RuntimeValue),
}

impl RuntimeResolvedValue {
    /// A complete declaration or registered value owns its identity without
    /// evaluating the source namespace prefix of a selected expression.
    pub(crate) const fn has_static_qualifier(&self) -> bool {
        matches!(
            self,
            Self::ProjectCallable { .. }
                | Self::ExternalCallable(_)
                | Self::Entity(_)
                | Self::Intrinsic(_)
                | Self::Registered(_)
        )
    }
}

/// Checked projection selected for one final-HIR member expression.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedSelect {
    Method,
    Field {
        owner: RuntimeSemanticTypeId,
        field: RuntimeRecordFieldId,
        receiver: arcweft_lang_sema::final_analysis::CheckedFieldReceiver,
    },
    OpaqueRecord {
        owner: RuntimeSemanticTypeId,
        producer: RuntimeOpaqueTypeProducerId,
        field: RuntimeRecordFieldId,
        field_type: RuntimeSemanticTypeId,
        receiver: arcweft_lang_sema::final_analysis::CheckedFieldReceiver,
    },
    AgentField {
        field: RuntimeAgentField,
        receiver: arcweft_lang_sema::final_analysis::CheckedFieldReceiver,
    },
    ProgressField {
        field: arcweft_core::value::RuntimeProgressField,
        receiver: arcweft_lang_sema::final_analysis::CheckedFieldReceiver,
    },
}

impl RuntimeResolvedSelect {
    /// Exact checked source of the field receiver, independent of writability.
    pub const fn receiver(
        &self,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedFieldReceiver> {
        match self {
            Self::Method => None,
            Self::Field { receiver, .. }
            | Self::OpaqueRecord { receiver, .. }
            | Self::AgentField { receiver, .. }
            | Self::ProgressField { receiver, .. } => Some(*receiver),
        }
    }
}

/// One source-ordered case in a complete normalized runtime variant schema.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeNormalizedVariantCase {
    name: String,
    payload: Option<Box<RuntimeNormalizedType>>,
}

/// Source-ordered variant cases whose cardinality is representable by every
/// runtime ordinal and wire boundary.
///
/// The private row/count pair is sealed together so downstream selection and
/// diagnostics never need a lossy `usize -> u32` conversion or a saturated
/// success value.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeNormalizedVariantCases {
    rows: Box<[RuntimeNormalizedVariantCase]>,
    count: u32,
}

impl RuntimeNormalizedVariantCases {
    fn try_new(
        rows: Box<[RuntimeNormalizedVariantCase]>,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let count = u32::try_from(rows.len())
            .map_err(|_| RuntimeResolvedVariantError::CaseCountOverflow { count: rows.len() })?;
        Ok(Self { rows, count })
    }

    #[must_use]
    pub const fn count(&self) -> u32 {
        self.count
    }
}

impl std::ops::Deref for RuntimeNormalizedVariantCases {
    type Target = [RuntimeNormalizedVariantCase];

    fn deref(&self) -> &Self::Target {
        &self.rows
    }
}

impl AsRef<[RuntimeNormalizedVariantCase]> for RuntimeNormalizedVariantCases {
    fn as_ref(&self) -> &[RuntimeNormalizedVariantCase] {
        &self.rows
    }
}

impl RuntimeNormalizedVariantCase {
    #[must_use]
    pub fn new(name: impl Into<String>, payload: Option<RuntimeNormalizedType>) -> Self {
        Self {
            name: name.into(),
            payload: payload.map(Box::new),
        }
    }

    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }

    #[must_use]
    pub fn payload(&self) -> Option<&RuntimeNormalizedType> {
        self.payload.as_deref()
    }

    fn checked_case(&self) -> Result<RuntimeCheckedVariantCase, RuntimeCheckedTypeProjectionError> {
        Ok(RuntimeCheckedVariantCase {
            name: self.name.clone(),
            payload: self
                .payload()
                .map(RuntimeNormalizedType::checked_type)
                .transpose()?
                .map(Box::new),
        })
    }
}

#[derive(Clone, Copy)]
struct RuntimeNormalizedVariantCaseRef<'a> {
    name: &'a str,
    payload: Option<&'a RuntimeNormalizedType>,
}

impl<'a> RuntimeNormalizedVariantCaseRef<'a> {
    fn from_case(case: &'a RuntimeNormalizedVariantCase) -> Self {
        Self {
            name: case.name(),
            payload: case.payload(),
        }
    }
}

/// Exact semantic owner of one runtime enum case.
///
/// Project, Character, and base-environment variants retain one complete
/// normalized case table. Checked cases are derived views rather than a
/// parallel payload authority. Option and Result retain their normalized type
/// arguments and expose the same internal source-ordered selection algebra.
#[derive(Clone, Debug, Eq, PartialEq)]
#[allow(
    clippy::large_enum_variant,
    reason = "variant owners retain their complete normalized semantic arguments as immutable checker evidence without adding a second indirection contract"
)]
pub enum RuntimeVariantOwner {
    Nominal {
        nominal: RuntimeResolvedNominal,
        arguments: Box<[RuntimeNormalizedType]>,
        cases: RuntimeNormalizedVariantCases,
    },
    CharacterNominal {
        identity: RuntimeSemanticTypeId,
        nominal: RuntimeNominalTypeId,
        layout: TypeLayoutHash,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
        cases: RuntimeNormalizedVariantCases,
    },
    BuiltinClosed {
        identity: RuntimeSemanticTypeId,
        nominal: RuntimeNominalTypeId,
        layout: TypeLayoutHash,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
        cases: RuntimeNormalizedVariantCases,
    },
    RuntimeBuiltin {
        identity: RuntimeSemanticTypeId,
        owner: RuntimeBuiltinVariantIdentity,
        cases: RuntimeNormalizedVariantCases,
    },
    Option {
        identity: RuntimeSemanticTypeId,
        item: RuntimeNormalizedType,
        cases: RuntimeNormalizedVariantCases,
    },
    Result {
        identity: RuntimeSemanticTypeId,
        ok: RuntimeNormalizedType,
        error: RuntimeNormalizedType,
        cases: RuntimeNormalizedVariantCases,
    },
}

impl RuntimeVariantOwner {
    /// Selects an accepted case from this complete executable definition.
    pub fn select_case(
        self,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<RuntimeResolvedVariant, RuntimeResolvedVariantError> {
        RuntimeResolvedVariant::try_new(self, ordinal, selected_name)
    }

    pub const fn semantic_identity(&self) -> RuntimeSemanticTypeId {
        match self {
            Self::Nominal { nominal, .. } => nominal.identity(),
            Self::CharacterNominal { identity, .. }
            | Self::BuiltinClosed { identity, .. }
            | Self::RuntimeBuiltin { identity, .. }
            | Self::Option { identity, .. }
            | Self::Result { identity, .. } => *identity,
        }
    }
    fn append_normalized_types<'a>(&'a self, types: &mut Vec<&'a RuntimeNormalizedType>) {
        match self {
            Self::Nominal {
                arguments, cases, ..
            } => {
                types.extend(arguments.iter());
                types.extend(
                    cases
                        .iter()
                        .filter_map(RuntimeNormalizedVariantCase::payload),
                );
            }
            Self::CharacterNominal { cases, .. }
            | Self::BuiltinClosed { cases, .. }
            | Self::RuntimeBuiltin { cases, .. } => {
                types.extend(
                    cases
                        .iter()
                        .filter_map(RuntimeNormalizedVariantCase::payload),
                );
            }
            Self::Option { item, cases, .. } => {
                types.push(item);
                types.extend(
                    cases
                        .iter()
                        .filter_map(RuntimeNormalizedVariantCase::payload),
                );
            }
            Self::Result {
                ok, error, cases, ..
            } => {
                types.push(ok);
                types.push(error);
                types.extend(
                    cases
                        .iter()
                        .filter_map(RuntimeNormalizedVariantCase::payload),
                );
            }
        }
    }

    fn runtime_plan_domain_seed(&self) -> Option<RuntimeVariantDomainSeed> {
        let (owner, nominal, layout, cases) = match self {
            Self::Nominal { nominal, cases, .. } => (
                nominal.identity(),
                nominal.runtime_nominal_id(),
                nominal.layout(),
                cases.as_ref(),
            ),
            Self::CharacterNominal {
                identity,
                nominal,
                layout,
                cases,
                ..
            }
            | Self::BuiltinClosed {
                identity,
                nominal,
                layout,
                cases,
                ..
            } => (*identity, nominal.clone(), *layout, cases.as_ref()),
            Self::RuntimeBuiltin { .. } => return None,
            Self::Option { .. } | Self::Result { .. } => return None,
        };
        Some(RuntimeVariantDomainSeed::new(
            owner,
            nominal,
            layout,
            cases.iter().map(|case| {
                RuntimeVariantCaseSeed::new(
                    case.name(),
                    case.payload().map(RuntimeNormalizedType::identity),
                )
            }),
        ))
    }

    fn selected_case(
        &self,
        ordinal: u32,
    ) -> Result<RuntimeNormalizedVariantCaseRef<'_>, RuntimeResolvedVariantError> {
        let ordinal_index = usize::try_from(ordinal).ok();
        let selected = match self {
            Self::Nominal { cases, .. }
            | Self::CharacterNominal { cases, .. }
            | Self::BuiltinClosed { cases, .. } => ordinal_index
                .and_then(|ordinal| cases.get(ordinal))
                .map(RuntimeNormalizedVariantCaseRef::from_case),
            Self::RuntimeBuiltin { cases, .. } => ordinal_index
                .and_then(|ordinal| cases.get(ordinal))
                .map(RuntimeNormalizedVariantCaseRef::from_case),
            Self::Option { cases, .. } | Self::Result { cases, .. } => ordinal_index
                .and_then(|ordinal| cases.get(ordinal))
                .map(RuntimeNormalizedVariantCaseRef::from_case),
        };
        selected.ok_or(RuntimeResolvedVariantError::CaseOrdinal {
            ordinal,
            case_count: self.case_count(),
        })
    }

    fn case_count(&self) -> u32 {
        match self {
            Self::Nominal { cases, .. }
            | Self::CharacterNominal { cases, .. }
            | Self::BuiltinClosed { cases, .. }
            | Self::RuntimeBuiltin { cases, .. } => cases.count(),
            Self::Option { cases, .. } | Self::Result { cases, .. } => cases.count(),
        }
    }

    fn project_checked_type(
        &self,
    ) -> Result<RuntimeCheckedType, RuntimeCheckedTypeProjectionError> {
        Ok(match self {
            Self::Nominal {
                nominal,
                arguments,
                cases,
            } => RuntimeCheckedType::Variant {
                owner: arcweft_core::pattern::RuntimeVariantIdentity::Nominal {
                    nominal: nominal.runtime_nominal_id(),
                    semantic_identity: nominal.identity(),
                    layout: nominal.layout(),
                },
                arguments: arguments
                    .iter()
                    .map(RuntimeNormalizedType::checked_type)
                    .collect::<Result<Vec<_>, _>>()?,
                cases: cases
                    .iter()
                    .map(RuntimeNormalizedVariantCase::checked_case)
                    .collect::<Result<Vec<_>, _>>()?,
            },
            Self::CharacterNominal {
                identity,
                nominal,
                layout,
                cases,
                ..
            }
            | Self::BuiltinClosed {
                identity,
                nominal,
                layout,
                cases,
                ..
            } => RuntimeCheckedType::Variant {
                owner: arcweft_core::pattern::RuntimeVariantIdentity::Nominal {
                    nominal: nominal.clone(),
                    semantic_identity: *identity,
                    layout: *layout,
                },
                arguments: Vec::new(),
                cases: cases
                    .iter()
                    .map(RuntimeNormalizedVariantCase::checked_case)
                    .collect::<Result<Vec<_>, _>>()?,
            },
            Self::RuntimeBuiltin {
                identity,
                owner,
                cases,
            } => {
                let payloads = cases
                    .iter()
                    .map(|case| {
                        case.payload()
                            .map(RuntimeNormalizedType::checked_type)
                            .transpose()
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                RuntimeCheckedType::try_builtin_variant(*owner, payloads).map_err(|_| {
                    RuntimeCheckedTypeProjectionError::InvalidBuiltinVariant {
                        semantic_identity: *identity,
                        path: RuntimeTypeProjectionPath::default(),
                        owner: *owner,
                    }
                })?
            }
            Self::Option {
                identity,
                item,
                cases,
            } => {
                let checked = RuntimeCheckedType::Option(Box::new(item.checked_type()?));
                validate_normalized_builtin_cases(
                    *identity,
                    RuntimeBuiltinVariantIdentity::Option,
                    cases,
                    &checked,
                )?;
                checked
            }
            Self::Result {
                identity,
                ok,
                error,
                cases,
            } => {
                let checked = RuntimeCheckedType::Result {
                    ok: Box::new(ok.checked_type()?),
                    error: Box::new(error.checked_type()?),
                };
                validate_normalized_builtin_cases(
                    *identity,
                    RuntimeBuiltinVariantIdentity::Result,
                    cases,
                    &checked,
                )?;
                checked
            }
        })
    }
}

fn validate_normalized_builtin_cases(
    semantic_identity: RuntimeSemanticTypeId,
    owner: RuntimeBuiltinVariantIdentity,
    cases: &[RuntimeNormalizedVariantCase],
    checked: &RuntimeCheckedType,
) -> Result<(), RuntimeCheckedTypeProjectionError> {
    if cases.len() != owner.cases().len()
        || cases.iter().enumerate().any(|(ordinal, case)| {
            u32::try_from(ordinal)
                .ok()
                .and_then(|ordinal| checked.variant_case(ordinal))
                .is_none_or(|expected| {
                    expected.name != case.name
                        || expected.payload.as_deref()
                            != case
                                .payload()
                                .and_then(|payload| payload.checked_type().ok())
                                .as_ref()
                })
        })
    {
        return Err(RuntimeCheckedTypeProjectionError::InvalidBuiltinVariant {
            semantic_identity,
            path: RuntimeTypeProjectionPath::root(),
            owner,
        });
    }
    Ok(())
}

/// Complete checked variant owner and its canonical selected case.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeCheckedVariantSelection {
    owner: RuntimeCheckedType,
    ordinal: u32,
    case: RuntimeCheckedVariantCase,
}

impl RuntimeCheckedVariantSelection {
    #[must_use]
    pub const fn owner(&self) -> &RuntimeCheckedType {
        &self.owner
    }

    #[must_use]
    pub const fn ordinal(&self) -> u32 {
        self.ordinal
    }

    #[must_use]
    pub const fn case(&self) -> &RuntimeCheckedVariantCase {
        &self.case
    }

    #[must_use]
    pub fn name(&self) -> &str {
        &self.case.name
    }

    #[must_use]
    pub fn payload(&self) -> Option<&RuntimeCheckedType> {
        match &self.case.payload {
            Some(payload) => Some(payload.as_ref()),
            None => None,
        }
    }
}

/// Failure to reconcile one semantically selected case with its complete owner.
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeResolvedVariantError {
    #[error("source nominal graph projection failed: {source}")]
    SourceGraph {
        source: Box<RuntimeNominalSchemaGraphError>,
    },
    #[error("variant owner checked-type projection failed")]
    CheckedTypeProjection(#[from] RuntimeCheckedTypeProjectionError),
    #[error("variant case ordinal {ordinal} is outside {case_count} cases")]
    CaseOrdinal { ordinal: u32, case_count: u32 },
    #[error("variant owner has {count} cases, exceeding the u32 runtime ordinal domain")]
    CaseCountOverflow { count: usize },
    #[error("variant case {ordinal} resolved as `{actual}`, expected `{expected}`")]
    CaseName {
        ordinal: u32,
        expected: String,
        actual: String,
    },
    #[error("CharacterDialogue policy graph contains an unsupported checked type shape")]
    InvalidDialoguePolicyType,
    #[error("CharacterDialogue policy graph owner is not a nominal variant")]
    InvalidDialoguePolicyOwner,
}

/// Checked enum case selected for a variant expression, constructor call, or pattern.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedVariant {
    owner: RuntimeVariantOwner,
    ordinal: u32,
}

impl RuntimeResolvedVariant {
    /// Reference forms admitted by checked variant resolution. A qualified
    /// enum member is a Select; it does not become a record-field projection.
    fn accepts_expression_kind(kind: &HirExprKind) -> bool {
        matches!(
            kind,
            HirExprKind::ShortVariant(_) | HirExprKind::Path(_) | HirExprKind::Select(_)
        )
    }

    fn try_new(
        owner: RuntimeVariantOwner,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let selected = owner.selected_case(ordinal)?;
        if selected.name != selected_name {
            return Err(RuntimeResolvedVariantError::CaseName {
                ordinal,
                expected: selected.name.to_owned(),
                actual: selected_name.to_owned(),
            });
        }
        Ok(Self { owner, ordinal })
    }

    /// Retains a case directly from its accepted project enum declaration.
    pub fn project(
        owner: RuntimeResolvedNominal,
        arguments: Box<[RuntimeNormalizedType]>,
        ordinal: u32,
        selected_name: &str,
        cases: Box<[RuntimeNormalizedVariantCase]>,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let cases = RuntimeNormalizedVariantCases::try_new(cases)?;
        Self::try_new(
            RuntimeVariantOwner::Nominal {
                nominal: owner,
                arguments,
                cases,
            },
            ordinal,
            selected_name,
        )
    }

    /// Retains a Character nominal case already admitted by checked final HIR.
    pub fn character(
        identity: RuntimeSemanticTypeId,
        nominal: RuntimeNominalTypeId,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
        cases: Box<[RuntimeNormalizedVariantCase]>,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let cases = RuntimeNormalizedVariantCases::try_new(cases)?;
        let layout = source_graph.try_layout_hash(identity).map_err(|source| {
            RuntimeResolvedVariantError::SourceGraph {
                source: Box::new(source),
            }
        })?;
        Self::try_new(
            RuntimeVariantOwner::CharacterNominal {
                identity,
                nominal,
                layout,
                source_graph,
                cases,
            },
            ordinal,
            selected_name,
        )
    }

    /// Retains a case from one source-ordered base-environment enum schema.
    pub fn builtin_closed(
        identity: RuntimeSemanticTypeId,
        nominal: RuntimeNominalTypeId,
        source_graph: Arc<RuntimeNominalSchemaGraph>,
        cases: Box<[RuntimeNormalizedVariantCase]>,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let cases = RuntimeNormalizedVariantCases::try_new(cases)?;
        let layout = source_graph.try_layout_hash(identity).map_err(|source| {
            RuntimeResolvedVariantError::SourceGraph {
                source: Box::new(source),
            }
        })?;
        Self::try_new(
            RuntimeVariantOwner::BuiltinClosed {
                identity,
                nominal,
                layout,
                source_graph,
                cases,
            },
            ordinal,
            selected_name,
        )
    }

    /// Retains one language-selected case from the shared CharacterDialogue
    /// policy graph. Source aliases resolve to graph ordinals here; the graph
    /// retains canonical case names and payload types.
    pub fn character_dialogue_policy(
        policy_types: Arc<CharacterDialoguePolicyTypeGraph>,
        owner: CharacterDialoguePolicyVariantOwner,
        ordinal: u32,
        selected_language_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let index = usize::try_from(ordinal).ok();
        let case = index
            .and_then(|index| policy_types.cases(owner).get(index))
            .ok_or(RuntimeResolvedVariantError::CaseOrdinal {
                ordinal,
                case_count: u32::try_from(policy_types.cases(owner).len())
                    .expect("policy case inventory is bounded"),
            })?;
        if case.language_name() != selected_language_name && case.name() != selected_language_name {
            return Err(RuntimeResolvedVariantError::CaseName {
                ordinal,
                expected: case.language_name().to_owned(),
                actual: selected_language_name.to_owned(),
            });
        }
        let RuntimeCheckedType::Variant {
            owner:
                RuntimeVariantIdentity::Nominal {
                    semantic_identity, ..
                },
            arguments,
            cases,
        } = policy_types.checked_type(owner)
        else {
            return Err(RuntimeResolvedVariantError::InvalidDialoguePolicyOwner);
        };
        if !arguments.is_empty() || *semantic_identity != policy_types.semantic_identity(owner) {
            return Err(RuntimeResolvedVariantError::InvalidDialoguePolicyOwner);
        }
        let schema_cases = policy_types.cases(owner);
        if cases.len() != schema_cases.len() {
            return Err(RuntimeResolvedVariantError::InvalidDialoguePolicyOwner);
        }
        let normalized_cases = cases
            .iter()
            .zip(schema_cases)
            .map(|(case, schema)| {
                if case.name != schema.name()
                    || case.payload.is_some() != schema.payload().is_some()
                {
                    return Err(RuntimeResolvedVariantError::InvalidDialoguePolicyOwner);
                }
                let payload = schema
                    .payload()
                    .map(|payload| {
                        let checked = policy_types
                            .checked_payload_type(payload)
                            .map_err(|_| RuntimeResolvedVariantError::InvalidDialoguePolicyType)?;
                        dialogue_policy_normalized_type(&policy_types, &checked)
                    })
                    .transpose()?;
                Ok(RuntimeNormalizedVariantCase::new(
                    case.name.clone(),
                    payload,
                ))
            })
            .collect::<Result<Vec<_>, RuntimeResolvedVariantError>>()?
            .into_boxed_slice();
        Self::project(
            RuntimeResolvedNominal::character_dialogue_policy(owner, &policy_types),
            Box::new([]),
            ordinal,
            case.name(),
            normalized_cases,
        )
        .and_then(|variant| {
            if variant.owner().semantic_identity() == *semantic_identity
                && variant.ordinal() == ordinal
                && variant.selected_name()? == case.name()
            {
                Ok(variant)
            } else {
                Err(RuntimeResolvedVariantError::InvalidDialoguePolicyOwner)
            }
        })
    }

    pub fn runtime_builtin(
        identity: RuntimeSemanticTypeId,
        owner: RuntimeBuiltinVariantIdentity,
        cases: Box<[RuntimeNormalizedVariantCase]>,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let cases = RuntimeNormalizedVariantCases::try_new(cases)?;
        Self::try_new(
            RuntimeVariantOwner::RuntimeBuiltin {
                identity,
                owner,
                cases,
            },
            ordinal,
            selected_name,
        )
    }

    /// Retains one accepted Option case after reconciling its closed name.
    pub fn option(
        identity: RuntimeSemanticTypeId,
        item: RuntimeNormalizedType,
        cases: Box<[RuntimeNormalizedVariantCase]>,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let cases = RuntimeNormalizedVariantCases::try_new(cases)?;
        let owner = RuntimeVariantOwner::Option {
            identity,
            item,
            cases,
        };
        owner.project_checked_type()?;
        Self::try_new(owner, ordinal, selected_name)
    }

    /// Retains one accepted Result case after reconciling its closed name.
    pub fn result(
        identity: RuntimeSemanticTypeId,
        ok: RuntimeNormalizedType,
        error: RuntimeNormalizedType,
        cases: Box<[RuntimeNormalizedVariantCase]>,
        ordinal: u32,
        selected_name: &str,
    ) -> Result<Self, RuntimeResolvedVariantError> {
        let owner = RuntimeVariantOwner::Result {
            identity,
            ok,
            error,
            cases: RuntimeNormalizedVariantCases::try_new(cases)?,
        };
        owner.project_checked_type()?;
        Self::try_new(owner, ordinal, selected_name)
    }

    pub const fn owner(&self) -> &RuntimeVariantOwner {
        &self.owner
    }

    pub const fn ordinal(&self) -> u32 {
        self.ordinal
    }

    /// Returns the selected name borrowed from the complete owner table.
    pub fn selected_name(&self) -> Result<&str, RuntimeResolvedVariantError> {
        self.owner
            .selected_case(self.ordinal)
            .map(|selected| selected.name)
    }

    /// Returns the selected normalized payload borrowed from its sole owner.
    pub fn selected_payload_type(
        &self,
    ) -> Result<Option<&RuntimeNormalizedType>, RuntimeResolvedVariantError> {
        self.owner
            .selected_case(self.ordinal)
            .map(|selected| selected.payload)
    }

    /// Reconciles the selected semantic case with the complete checked owner.
    pub fn checked_selection(
        &self,
    ) -> Result<RuntimeCheckedVariantSelection, RuntimeResolvedVariantError> {
        self.owner.selected_case(self.ordinal)?;
        let owner = self.owner.project_checked_type()?;
        let case =
            owner
                .variant_case(self.ordinal)
                .ok_or(RuntimeResolvedVariantError::CaseOrdinal {
                    ordinal: self.ordinal,
                    case_count: self.owner.case_count(),
                })?;
        Ok(RuntimeCheckedVariantSelection {
            owner,
            ordinal: self.ordinal,
            case,
        })
    }
}

fn dialogue_policy_normalized_type(
    policy_types: &Arc<CharacterDialoguePolicyTypeGraph>,
    checked: &RuntimeCheckedType,
) -> Result<RuntimeNormalizedType, RuntimeResolvedVariantError> {
    use RuntimeCheckedType as Checked;
    let identity = match checked {
        Checked::Nominal {
            semantic_identity, ..
        } => *semantic_identity,
        Checked::Opaque { owner } => owner.semantic_identity(),
        _ => checked.semantic_identity_digest(),
    };
    let shape = match checked {
        Checked::Unit => RuntimeTypeShape::Unit,
        Checked::Never => RuntimeTypeShape::Never,
        Checked::Bool => RuntimeTypeShape::Bool,
        Checked::String => RuntimeTypeShape::String,
        Checked::Color => RuntimeTypeShape::Color,
        Checked::EntityReference(reference) => RuntimeTypeShape::EntityReference(
            reference
                .as_ref()
                .try_map(|_| Err(RuntimeResolvedVariantError::InvalidDialoguePolicyType))?,
        ),
        Checked::Sequence(item) => RuntimeTypeShape::Sequence {
            kind: RuntimeSequenceKind::Seq,
            item: Box::new(dialogue_policy_normalized_type(policy_types, item)?),
        },
        Checked::Tuple(items) => RuntimeTypeShape::Tuple(
            items
                .iter()
                .map(|item| dialogue_policy_normalized_type(policy_types, item))
                .collect::<Result<Vec<_>, _>>()?
                .into_boxed_slice(),
        ),
        Checked::Choice(items) => RuntimeTypeShape::Choice(
            items
                .iter()
                .map(|item| dialogue_policy_normalized_type(policy_types, item))
                .collect::<Result<Vec<_>, _>>()?
                .into_boxed_slice(),
        ),
        Checked::Opaque { owner } => RuntimeTypeShape::Opaque {
            producer: owner.producer().clone(),
            admission: owner.admission(),
            value_class: owner.value_class(),
            persistence: owner.persistence(),
            arguments: Box::new([]),
        },
        Checked::Nominal {
            semantic_identity: owner_identity,
            arguments,
            ..
        } => {
            let owner = policy_types
                .owner_for_semantic_identity(*owner_identity)
                .ok_or(RuntimeResolvedVariantError::InvalidDialoguePolicyType)?;
            if identity != *owner_identity {
                return Err(RuntimeResolvedVariantError::InvalidDialoguePolicyType);
            }
            RuntimeTypeShape::Nominal {
                nominal: RuntimeResolvedNominal::character_dialogue_policy(owner, policy_types),
                arguments: arguments
                    .iter()
                    .map(|argument| dialogue_policy_normalized_type(policy_types, argument))
                    .collect::<Result<Vec<_>, _>>()?
                    .into_boxed_slice(),
            }
        }
        _ => return Err(RuntimeResolvedVariantError::InvalidDialoguePolicyType),
    };
    Ok(RuntimeNormalizedType::new(identity, shape))
}

/// Typed failure while consuming one ABI-positioned runtime call operand list.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum RuntimeResolvedCallError {
    #[error("external declaration application differs from its checked value call")]
    ExternalApplicationMismatch,
    #[error("CharacterDialogue operation does not consume its complete source-ordered operand row")]
    CharacterDialogueSourceRow,
    #[error("Vec mutation does not have its checked receiver, argument, and result shape")]
    VecMutationCallShape,
    #[error("runtime call ABI position {position} is outside operand count {operand_count}")]
    AbiPositionOutOfRange { position: u32, operand_count: u32 },
    #[error("runtime call repeats ABI position {position}")]
    DuplicateAbiPosition { position: u32 },
    #[error("runtime call omits ABI position {position}")]
    MissingAbiPosition { position: u32 },
    #[error("runtime call contains duplicate operand origin")]
    DuplicateOperandOrigin,
    #[error("runtime call physical operands are not in canonical source order")]
    NonCanonicalSourceOrder,
    #[error(
        "runtime call request role evidence disagrees with operand origin at ABI position {position}"
    )]
    RequestRoleIdentity { position: u32 },
    #[error("runtime call contains more than one receiver operand")]
    MultipleReceivers,
    #[error("runtime attached-content ABI position {actual} is not the final position {expected}")]
    NonTerminalAttachedContentPosition { expected: u32, actual: u32 },
    #[error("runtime call attached-content operand does not match the selected callable interface")]
    AttachedContentInterfaceMismatch,
    #[error("ordinary project-function call dispatch disagrees with its checked call plan")]
    ProjectFunctionPlanMismatch,
    #[error("ordinary project-function call result disagrees with its checked call outcome")]
    ProjectFunctionResultMismatch,
    #[error(
        "ordinary project-function call operands do not match its logical materialization plan"
    )]
    ProjectFunctionMaterializationMismatch,
    #[error("Need producer role is attached to a call that does not produce Need<T>")]
    NeedProducerResultNotNeed,
    #[error("Need producer call must retain only source-ordered scalar arguments")]
    NeedProducerOperandShape,
    #[error("Need producer admission argument count differs from its call operands")]
    NeedProducerAdmissionCount,
    #[error("Need producer admission type differs at argument {ordinal}")]
    NeedProducerAdmissionType { ordinal: u32 },
    #[error("Need producer dispatch is not a registered or manifest-bound extern call")]
    NeedProducerDispatch,
    #[error("Need producer plan is not bound to the checked call-site authority")]
    NeedProducerSiteMismatch,
    #[error("Need producer payload type differs from the instantiated Need<T> item")]
    NeedProducerPayloadTypeMismatch,
    #[error("Need producer plan request differs from the selected call dispatch")]
    NeedProducerPlanMismatch,
}

/// Runtime attached-content value retained separately from ordinary authored
/// arguments while participating in the same terminal call ABI transaction.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedAttachedContent {
    Required {
        source: ExprId,
        ty: RuntimeNormalizedType,
    },
    OptionalPresent {
        source: ExprId,
        ty: RuntimeNormalizedType,
    },
    OptionalOmitted {
        ty: RuntimeNormalizedType,
    },
    DefaultedPresent {
        source: ExprId,
        ty: RuntimeNormalizedType,
    },
    DefaultedOmitted {
        ty: RuntimeNormalizedType,
    },
}

impl RuntimeResolvedAttachedContent {
    pub const fn source(&self) -> Option<ExprId> {
        match self {
            Self::Required { source, .. }
            | Self::OptionalPresent { source, .. }
            | Self::DefaultedPresent { source, .. } => Some(*source),
            Self::OptionalOmitted { .. } | Self::DefaultedOmitted { .. } => None,
        }
    }

    /// Returns the exact final checked ABI type. Omitted attached content
    /// retains this row so `None` can be lowered without reopening the callee
    /// schema or reconstructing a standard nominal from source spelling.
    pub const fn ty(&self) -> &RuntimeNormalizedType {
        match self {
            Self::Required { ty, .. }
            | Self::OptionalPresent { ty, .. }
            | Self::OptionalOmitted { ty }
            | Self::DefaultedPresent { ty, .. }
            | Self::DefaultedOmitted { ty } => ty,
        }
    }
}

/// Final ABI-positioned row for the one terminal attached-content operand.
/// The call-site ABI position includes physical rest expansion; the distinct
/// declaration-owned logical position remains on
/// `RuntimeCallableAttachedContentAbi`. Its group is owned once by
/// [`RuntimeResolvedCall::completed_group`].
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimePositionedAttachedContent {
    abi_position: u32,
    content: RuntimeResolvedAttachedContent,
}

impl RuntimePositionedAttachedContent {
    pub const fn new(abi_position: u32, content: RuntimeResolvedAttachedContent) -> Self {
        Self {
            abi_position,
            content,
        }
    }

    pub const fn abi_position(&self) -> u32 {
        self.abi_position
    }

    pub const fn content(&self) -> &RuntimeResolvedAttachedContent {
        &self.content
    }

    pub fn into_content(self) -> RuntimeResolvedAttachedContent {
        self.content
    }
}

/// One compiler-selected call dispatch for an exact final-HIR call expression.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedCall {
    dispatch: RuntimeResolvedCallDispatch,
    completed_group: arcweft_lang_sema::callable::CallableGroupIndex,
    /// Sole source-ordered physical operand row. Every member retains its
    /// checked ABI destination; consumers evaluate this row once in order and
    /// use the positions only to install the resulting values.
    operands: Box<[RuntimeResolvedCallOperand]>,
    attached_content: Option<RuntimePositionedAttachedContent>,
    project_function: Option<RuntimeProjectFunctionCallPlan>,
    external_application:
        Option<arcweft_lang_sema::final_analysis::CheckedExternalCallableApplicationProjection>,
    need_producer: Option<RuntimeResolvedNeedProducer>,
    mutation: Option<RuntimeResolvedCallMutation>,
    result: RuntimeCallResultShape,
}

/// Exact checked producer authority projected from one selected callable
/// schema. The payload is retained as the instantiated result's `Need<T>`;
/// it is never copied into the Sema-owned producer role.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedNeedProducer {
    execution: RuntimeResolvedNeedProducerExecution,
    need_type: RuntimeNormalizedType,
}

/// The source-owned executable path selected for an ordinary Need.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedNeedProducerExecution {
    Host {
        plan: NeedProducerTaskPlan,
        admission: arcweft_lang_sema::CheckedNeedProducerAdmission,
    },
    /// Retains its checked call producer definition in the common executable
    /// fact view; live capture admission belongs to the original Program source.
    ProgramFanout,
    ProgramActionReceive,
}

/// Selected ordinary Program producer, independent of Host task families.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeProgramNeedKind {
    Fanout,
    ActionReceive,
}

/// Borrowed exact types from an admitted fanout call, without a second schema.
pub(crate) struct RuntimeProgramFanoutContract<'a> {
    pub source: &'a RuntimeNormalizedType,
    pub mapping: &'a RuntimeNormalizedType,
    pub limit: &'a RuntimeNormalizedType,
    pub item: &'a RuntimeNormalizedType,
    pub need: &'a RuntimeNormalizedType,
    pub result: &'a RuntimeNormalizedType,
    pub aggregate: &'a RuntimeNormalizedType,
}

impl RuntimeResolvedNeedProducer {
    pub fn try_host(
        plan: NeedProducerTaskPlan,
        need_type: RuntimeNormalizedType,
        admission: arcweft_lang_sema::CheckedNeedProducerAdmission,
    ) -> Result<Self, RuntimeResolvedCallError> {
        let RuntimeTypeShape::Need(item) = need_type.shape() else {
            return Err(RuntimeResolvedCallError::NeedProducerResultNotNeed);
        };
        if plan.site() != admission.site() {
            return Err(RuntimeResolvedCallError::NeedProducerSiteMismatch);
        }
        if item.identity() != plan.payload_type() {
            return Err(RuntimeResolvedCallError::NeedProducerPayloadTypeMismatch);
        }
        if plan.argument_count() != admission.arguments().len()
            || plan.argument_types().len() != admission.arguments().len()
            || plan
                .argument_types()
                .iter()
                .zip(admission.arguments())
                .any(|(plan_type, admission)| plan_type.as_bytes() != admission.ty().as_bytes())
        {
            return Err(RuntimeResolvedCallError::NeedProducerAdmissionCount);
        }
        Ok(Self {
            execution: RuntimeResolvedNeedProducerExecution::Host { plan, admission },
            need_type,
        })
    }

    pub fn try_program_fanout(
        need_type: RuntimeNormalizedType,
    ) -> Result<Self, RuntimeResolvedCallError> {
        if !matches!(need_type.shape(), RuntimeTypeShape::Need(_)) {
            return Err(RuntimeResolvedCallError::NeedProducerResultNotNeed);
        }
        Ok(Self {
            execution: RuntimeResolvedNeedProducerExecution::ProgramFanout,
            need_type,
        })
    }

    pub const fn need_type(&self) -> &RuntimeNormalizedType {
        &self.need_type
    }

    pub fn try_program_action_receive(
        need_type: RuntimeNormalizedType,
    ) -> Result<Self, RuntimeResolvedCallError> {
        if !matches!(need_type.shape(), RuntimeTypeShape::Need(_)) {
            return Err(RuntimeResolvedCallError::NeedProducerResultNotNeed);
        }
        Ok(Self {
            execution: RuntimeResolvedNeedProducerExecution::ProgramActionReceive,
            need_type,
        })
    }

    pub const fn execution(&self) -> &RuntimeResolvedNeedProducerExecution {
        &self.execution
    }
}

/// Checked mutation owned by one final call fact.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedCallMutation {
    VecPopFront {
        source: ExprId,
        place: RuntimeResolvedPlace,
    },
    VecPop {
        source: ExprId,
        place: RuntimeResolvedPlace,
    },
    VecPush {
        source: ExprId,
        place: RuntimeResolvedPlace,
    },
}

impl RuntimeResolvedCallMutation {
    pub const fn source(&self) -> ExprId {
        match self {
            Self::VecPopFront { source, .. }
            | Self::VecPop { source, .. }
            | Self::VecPush { source, .. } => *source,
        }
    }
}

/// Complete checked local-rooted address shared by reads and writes.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedPlace {
    Local(LocalId),
    Fields {
        base: LocalId,
        fields: Box<[RuntimeRecordFieldId]>,
    },
}

impl RuntimeResolvedPlace {
    fn accepts_types(&self, root: &RuntimeNormalizedType, value: &RuntimeNormalizedType) -> bool {
        let Self::Fields { fields, .. } = self else {
            return root == value;
        };
        if fields.is_empty() {
            return false;
        }
        let RuntimeTypeShape::Nominal { nominal, .. } = root.shape() else {
            return false;
        };
        let graph = nominal.source_graph();
        let mut identity = nominal.identity();
        for (ordinal, field) in fields.iter().enumerate() {
            let Some(definition) = graph.definition(identity) else {
                return false;
            };
            let arcweft_core::entry::RuntimeNominalSchemaBody::Record {
                fields: declared, ..
            } = definition.body()
            else {
                return false;
            };
            let Some(selected) = declared
                .get(field.zero_based() as usize)
                .filter(|selected| selected.field() == *field)
            else {
                return false;
            };
            if ordinal + 1 == fields.len() {
                return normalized_type_matches_schema(value, selected.schema(), graph);
            }
            let RuntimeTypeSchema::NominalRef(next) = selected.schema() else {
                return false;
            };
            identity = next.semantic_identity();
        }
        false
    }

    pub fn try_from_checked(
        place: &arcweft_lang_sema::final_analysis::CheckedPlace,
    ) -> Option<Self> {
        if place.fields().is_empty() {
            return Some(Self::Local(place.local()));
        }
        Some(Self::Fields {
            base: place.local(),
            fields: place
                .fields()
                .iter()
                .map(|field| field.runtime_field())
                .collect::<Option<Box<[_]>>>()?,
        })
    }
    pub const fn local(&self) -> LocalId {
        match self {
            Self::Local(local) | Self::Fields { base: local, .. } => *local,
        }
    }
    pub fn matches_access(
        &self,
        access: &arcweft_lang_sema::final_analysis::CheckedLocalAccess,
    ) -> bool {
        match access {
            arcweft_lang_sema::final_analysis::CheckedLocalAccess::ValueTransfer(transfer) => {
                self.matches_checked(&transfer.place())
            }
            arcweft_lang_sema::final_analysis::CheckedLocalAccess::PlaceAccess(access) => {
                self.matches_checked(access.place())
            }
        }
    }
    pub fn matches_checked(&self, place: &arcweft_lang_sema::final_analysis::CheckedPlace) -> bool {
        match self {
            Self::Local(local) => place.local_id() == *local && place.fields().is_empty(),
            Self::Fields { base, fields } => {
                place.local_id() == *base
                    && !fields.is_empty()
                    && fields.len() == place.fields().len()
                    && fields
                        .iter()
                        .zip(place.fields())
                        .all(|(field, selected)| selected.runtime_field().as_ref() == Some(field))
            }
        }
    }
}

impl RuntimeResolvedCall {
    /// Validates the ABI-position permutation without changing source order.
    pub fn try_new(
        dispatch: RuntimeResolvedCallDispatch,
        completed_group: arcweft_lang_sema::callable::CallableGroupIndex,
        operands: Vec<RuntimeResolvedCallOperand>,
        positioned_attached_content: Option<RuntimePositionedAttachedContent>,
        project_function: Option<RuntimeProjectFunctionCallPlan>,
        result: RuntimeCallResultShape,
    ) -> Result<Self, RuntimeResolvedCallError> {
        let operand_count = u32::try_from(operands.len()).map_err(|_| {
            RuntimeResolvedCallError::AbiPositionOutOfRange {
                position: u32::MAX,
                operand_count: u32::MAX,
            }
        })?;
        let mut abi_positions = vec![false; operands.len()];
        if operands
            .windows(2)
            .any(|pair| pair[0].origin() >= pair[1].origin())
        {
            return Err(RuntimeResolvedCallError::NonCanonicalSourceOrder);
        }
        let mut origins = BTreeSet::new();
        let mut receivers = 0_u8;
        for operand in &operands {
            let position = operand.abi_position();
            if matches!(
                operand.origin(),
                RuntimeResolvedCallOperandOrigin::Argument { .. }
            ) != operand.request_role_identity().is_some()
            {
                return Err(RuntimeResolvedCallError::RequestRoleIdentity { position });
            }
            let index = usize::try_from(position).map_err(|_| {
                RuntimeResolvedCallError::AbiPositionOutOfRange {
                    position,
                    operand_count,
                }
            })?;
            let Some(seen) = abi_positions.get_mut(index) else {
                return Err(RuntimeResolvedCallError::AbiPositionOutOfRange {
                    position,
                    operand_count,
                });
            };
            if std::mem::replace(seen, true) {
                return Err(RuntimeResolvedCallError::DuplicateAbiPosition { position });
            }
            if !origins.insert(operand.origin().clone()) {
                return Err(RuntimeResolvedCallError::DuplicateOperandOrigin);
            }
            if matches!(operand.origin(), RuntimeResolvedCallOperandOrigin::Receiver) {
                receivers = receivers.saturating_add(1);
            }
        }
        if receivers > 1 {
            return Err(RuntimeResolvedCallError::MultipleReceivers);
        }
        if let Some(position) = abi_positions.iter().position(|seen| !seen) {
            return Err(RuntimeResolvedCallError::MissingAbiPosition {
                position: u32::try_from(position).map_err(|_| {
                    RuntimeResolvedCallError::MissingAbiPosition { position: u32::MAX }
                })?,
            });
        }
        if let Some(positioned) = &positioned_attached_content {
            let expected = u32::try_from(operands.len()).map_err(|_| {
                RuntimeResolvedCallError::NonTerminalAttachedContentPosition {
                    expected: u32::MAX,
                    actual: positioned.abi_position(),
                }
            })?;
            if positioned.abi_position() != expected {
                return Err(
                    RuntimeResolvedCallError::NonTerminalAttachedContentPosition {
                        expected,
                        actual: positioned.abi_position(),
                    },
                );
            }
        }
        if let RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::CharacterDialogue(dialogue),
        ) = &dispatch
        {
            if positioned_attached_content.is_some()
                || project_function.is_some()
                || !dialogue.accepts_source_row(&operands, result)
            {
                return Err(RuntimeResolvedCallError::CharacterDialogueSourceRow);
            }
        } else if operands
            .iter()
            .any(|operand| matches!(operand.origin(), RuntimeResolvedCallOperandOrigin::Callee))
        {
            return Err(RuntimeResolvedCallError::CharacterDialogueSourceRow);
        }
        let direct_project_callable = dispatch.project_callable();
        let project_function_matches = match (&dispatch, &project_function) {
            (
                RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Declaration(
                    direct,
                )),
                Some(plan),
            ) => {
                direct == plan.callable()
                    && matches!(plan.input(), RuntimeProjectFunctionCallInput::Direct)
            }
            (RuntimeResolvedCallDispatch::Value { callee }, Some(plan)) => {
                plan.input().callee() == Some(*callee)
            }
            (
                RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Declaration(
                    _,
                )),
                None,
            ) => true,
            (_, None) => true,
            (_, Some(_)) => false,
        };
        if !project_function_matches {
            return Err(RuntimeResolvedCallError::ProjectFunctionPlanMismatch);
        }
        if let Some(plan) = &project_function {
            let mut covered = vec![false; operands.len()];
            for materialization in plan.current_group_materialization() {
                let indices = materialization.operand_indices();
                let expected_group =
                    u32::try_from(materialization.group().get()).map_err(|_| {
                        RuntimeResolvedCallError::ProjectFunctionMaterializationMismatch
                    })?;
                let expected = RuntimeCallParameterCoordinate::new(
                    expected_group,
                    materialization.parameter(),
                );
                for index in indices {
                    let index = usize::try_from(*index).map_err(|_| {
                        RuntimeResolvedCallError::ProjectFunctionMaterializationMismatch
                    })?;
                    let Some(operand) = operands.get(index) else {
                        return Err(
                            RuntimeResolvedCallError::ProjectFunctionMaterializationMismatch,
                        );
                    };
                    if covered[index] {
                        return Err(
                            RuntimeResolvedCallError::ProjectFunctionMaterializationMismatch,
                        );
                    }
                    covered[index] = true;
                    let origin_matches = match materialization.kind() {
                        arcweft_lang_hir::item::HirParameterKind::ExtensionReceiver => {
                            matches!(operand.origin(), RuntimeResolvedCallOperandOrigin::Receiver)
                        }
                        arcweft_lang_hir::item::HirParameterKind::Fixed
                        | arcweft_lang_hir::item::HirParameterKind::RestPositional => {
                            matches!(
                                operand.origin(),
                                RuntimeResolvedCallOperandOrigin::Argument { .. }
                            ) && operand.parameter() == Some(expected)
                        }
                    };
                    if !origin_matches {
                        return Err(
                            RuntimeResolvedCallError::ProjectFunctionMaterializationMismatch,
                        );
                    }
                }
            }
            if covered.iter().any(|covered| !covered) {
                return Err(RuntimeResolvedCallError::ProjectFunctionMaterializationMismatch);
            }
        }
        if project_function.as_ref().is_some_and(|plan| {
            !matches!(
                (plan.outcome(), result),
                (
                    RuntimeProjectFunctionCallOutcome::Continue { .. },
                    RuntimeCallResultShape::PartialFunction
                ) | (
                    RuntimeProjectFunctionCallOutcome::Invoke { .. },
                    RuntimeCallResultShape::Value
                )
            )
        }) {
            return Err(RuntimeResolvedCallError::ProjectFunctionResultMismatch);
        }
        let project_attached = project_function
            .as_ref()
            .map(RuntimeProjectFunctionCallPlan::callable)
            .or(direct_project_callable)
            .and_then(RuntimeProjectCallable::attached_content_abi);
        if project_function.is_some() || direct_project_callable.is_some() {
            let interface_matches = match project_attached {
                Some(interface) if completed_group.get() < interface.group().get() => {
                    positioned_attached_content.is_none()
                }
                Some(interface) if completed_group == interface.group() => {
                    positioned_attached_content
                        .as_ref()
                        .is_some_and(|positioned| {
                            runtime_attached_content_matches_interface(
                                positioned.content(),
                                interface,
                            )
                        })
                }
                Some(_) => false,
                None => positioned_attached_content.is_none(),
            };
            if !interface_matches {
                return Err(RuntimeResolvedCallError::AttachedContentInterfaceMismatch);
            }
        }
        Ok(Self {
            dispatch,
            completed_group,
            operands: operands.into_boxed_slice(),
            attached_content: positioned_attached_content,
            project_function,
            external_application: None,
            need_producer: None,
            mutation: None,
            result,
        })
    }

    /// Attaches the exact selected producer role and Sema admission after
    /// checking that they describe this call's source-ordered argument row.
    pub fn try_with_need_producer(
        mut self,
        producer: RuntimeResolvedNeedProducer,
    ) -> Result<Self, RuntimeResolvedCallError> {
        if self.result != RuntimeCallResultShape::Value
            || self.project_function.is_some()
            || self.attached_content.is_some()
            || self.mutation.is_some()
            || !matches!(producer.need_type().shape(), RuntimeTypeShape::Need(_))
        {
            return Err(RuntimeResolvedCallError::NeedProducerResultNotNeed);
        }
        match producer.execution() {
            RuntimeResolvedNeedProducerExecution::Host { plan, admission } => {
                let target_admitted = match (self.dispatch(), plan.request()) {
                    (
                        RuntimeResolvedCallDispatch::Static(
                            RuntimeResolvedStaticCallTarget::Registered(_),
                        ),
                        NeedProducerRequestProjection::AssetLoad { .. },
                    ) => true,
                    (
                        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Host(
                            host,
                        )),
                        NeedProducerRequestProjection::ExternCapability {
                            capability,
                            operation,
                            contract,
                            ..
                        },
                    ) => {
                        matches!(
                            host.owner(),
                            RuntimeResolvedHostCallOwner::ExternCapability { .. }
                        ) && host.mode() == RuntimeHostCallMode::Suspend
                            && host.contract().is_some_and(|selected| {
                                selected.as_bytes() == contract.as_bytes()
                                    && selected.as_bytes() == plan.contract().as_bytes()
                            })
                            && capability.0 == host.capability()
                            && operation == host.operation()
                    }
                    (
                        RuntimeResolvedCallDispatch::Static(_)
                        | RuntimeResolvedCallDispatch::Value { .. },
                        _,
                    ) => false,
                };
                if !target_admitted {
                    return Err(RuntimeResolvedCallError::NeedProducerDispatch);
                }
                let admitted_arguments = admission.arguments();
                if admitted_arguments.len() != self.operands.len() {
                    return Err(RuntimeResolvedCallError::NeedProducerAdmissionCount);
                }
                for (ordinal, (admitted, operand)) in admitted_arguments
                    .iter()
                    .zip(self.operands.iter())
                    .enumerate()
                {
                    let source_ordinal = ordinal;
                    let ordinal = u32::try_from(ordinal)
                        .map_err(|_| RuntimeResolvedCallError::NeedProducerAdmissionCount)?;
                    if !matches!(
                        operand.origin(),
                        RuntimeResolvedCallOperandOrigin::Argument { .. }
                    ) || !matches!(
                        operand.projection(),
                        RuntimeResolvedCallOperandProjection::Scalar
                    ) {
                        return Err(RuntimeResolvedCallError::NeedProducerOperandShape);
                    }
                    if admitted.ty().as_bytes() != operand.ty().identity().as_bytes() {
                        return Err(RuntimeResolvedCallError::NeedProducerAdmissionType {
                            ordinal,
                        });
                    }
                    let source_name = match operand.binding() {
                        RuntimeResolvedCallOperandBinding::Positional => None,
                        RuntimeResolvedCallOperandBinding::Named(name) => Some(name.as_str()),
                    };
                    let binding_matches = plan
                        .request()
                        .argument_binding(source_ordinal)
                        .is_some_and(|binding| binding.accepts_source_name(source_name));
                    if !binding_matches {
                        return Err(RuntimeResolvedCallError::NeedProducerPlanMismatch);
                    }
                }
            }
            RuntimeResolvedNeedProducerExecution::ProgramActionReceive => {
                if !matches!(
                    self.dispatch(),
                    RuntimeResolvedCallDispatch::Static(
                        RuntimeResolvedStaticCallTarget::ProgramNeed(
                            RuntimeProgramNeedKind::ActionReceive
                        )
                    )
                ) || self.action_receive_contract(producer.need_type()).is_none()
                {
                    return Err(RuntimeResolvedCallError::NeedProducerDispatch);
                }
            }
            RuntimeResolvedNeedProducerExecution::ProgramFanout => {
                if !matches!(
                    self.dispatch(),
                    RuntimeResolvedCallDispatch::Static(
                        RuntimeResolvedStaticCallTarget::ProgramNeed(
                            RuntimeProgramNeedKind::Fanout
                        )
                    )
                ) || self.program_fanout_contract(producer.need_type()).is_none()
                {
                    return Err(RuntimeResolvedCallError::NeedProducerDispatch);
                }
            }
        }
        if self.need_producer.replace(producer).is_some() {
            return Err(RuntimeResolvedCallError::NeedProducerResultNotNeed);
        }
        Ok(self)
    }

    /// Attaches a checked in-place operation after validating the complete
    /// call row that this operation consumes.
    pub fn try_with_mutation(
        mut self,
        mutation: RuntimeResolvedCallMutation,
    ) -> Result<Self, RuntimeResolvedCallError> {
        let (source, dispatch, operand_count) = match &mutation {
            RuntimeResolvedCallMutation::VecPopFront { source, .. } => {
                (*source, RuntimeResolvedStaticCallTarget::VecPopFront, 1)
            }
            RuntimeResolvedCallMutation::VecPop { source, .. } => {
                (*source, RuntimeResolvedStaticCallTarget::VecPop, 1)
            }
            RuntimeResolvedCallMutation::VecPush { source, .. } => {
                (*source, RuntimeResolvedStaticCallTarget::VecPush, 2)
            }
        };
        let valid_shape = self.operands.len() == operand_count
            && matches!(
                self.operands.first(),
                Some(RuntimeResolvedCallOperand {
                    origin: RuntimeResolvedCallOperandOrigin::Receiver,
                    source: RuntimeResolvedCallOperandSource::Expression(actual),
                    ..
                }) if *actual == source
            )
            && (operand_count == 1
                || matches!(
                    self.operands.get(1),
                    Some(RuntimeResolvedCallOperand {
                        origin: RuntimeResolvedCallOperandOrigin::Argument {
                            argument: 0,
                            slot: 0
                        },
                        source: RuntimeResolvedCallOperandSource::Expression(_),
                        ..
                    })
                ))
            && self.dispatch == RuntimeResolvedCallDispatch::Static(dispatch)
            && self.attached_content.is_none()
            && self.project_function.is_none()
            && self.result == RuntimeCallResultShape::Value;
        if !valid_shape || self.mutation.is_some() {
            return Err(RuntimeResolvedCallError::VecMutationCallShape);
        }
        self.mutation = Some(mutation);
        Ok(self)
    }

    pub const fn dispatch(&self) -> &RuntimeResolvedCallDispatch {
        &self.dispatch
    }

    pub const fn operands(&self) -> &[RuntimeResolvedCallOperand] {
        &self.operands
    }

    /// Whether an authored callee expression is evaluated as a runtime value.
    /// Static name/type selectors are not evaluated; a value callee or a
    /// receiver retained in the checked source operand row is evaluated.
    pub(crate) fn evaluates_callee(&self, expression: ExprId) -> bool {
        matches!(self.dispatch(), RuntimeResolvedCallDispatch::Value { callee } if *callee == expression)
            || self.operands().iter().any(|operand| {
                operand.source() == RuntimeResolvedCallOperandSource::Expression(expression)
            })
    }

    /// Derived ABI view. The stored row remains source-ordered; this iterator
    /// performs no evaluation and allocates no parallel operand inventory.
    pub fn abi_operands(&self) -> impl Iterator<Item = &RuntimeResolvedCallOperand> {
        (0..self.operands.len()).filter_map(|position| {
            let position = u32::try_from(position).ok()?;
            self.operands
                .iter()
                .find(|operand| operand.abi_position() == position)
        })
    }

    pub const fn completed_group(&self) -> arcweft_lang_sema::callable::CallableGroupIndex {
        self.completed_group
    }

    pub const fn attached_content(&self) -> Option<&RuntimeResolvedAttachedContent> {
        match &self.attached_content {
            Some(attached) => Some(attached.content()),
            None => None,
        }
    }

    pub const fn positioned_attached_content(&self) -> Option<&RuntimePositionedAttachedContent> {
        self.attached_content.as_ref()
    }

    pub const fn project_function(&self) -> Option<&RuntimeProjectFunctionCallPlan> {
        self.project_function.as_ref()
    }

    pub fn try_with_external_application(
        mut self,
        owner: ExprId,
        application: arcweft_lang_sema::final_analysis::CheckedExternalCallableApplicationProjection,
    ) -> Result<Self, RuntimeResolvedCallError> {
        if application.origin().expression() != owner
            || application.group() != self.completed_group
            || !matches!(self.dispatch, RuntimeResolvedCallDispatch::Value { .. })
            || self.project_function.is_some()
            || self.attached_content.is_some()
            || self.external_application.is_some()
        {
            return Err(RuntimeResolvedCallError::ExternalApplicationMismatch);
        }
        self.external_application = Some(application);
        Ok(self)
    }

    pub const fn external_application(
        &self,
    ) -> Option<&arcweft_lang_sema::final_analysis::CheckedExternalCallableApplicationProjection>
    {
        self.external_application.as_ref()
    }

    pub const fn need_producer(&self) -> Option<&RuntimeResolvedNeedProducer> {
        self.need_producer.as_ref()
    }

    /// Calls whose execution retains original Source require a producer
    /// definition from the same global or closed local-use authority.
    pub const fn requires_producer_definition(&self) -> bool {
        matches!(
            self.dispatch,
            RuntimeResolvedCallDispatch::Static(
                RuntimeResolvedStaticCallTarget::Host(_)
                    | RuntimeResolvedStaticCallTarget::ProgramNeed(_)
            )
        )
    }

    pub const fn mutation(&self) -> Option<&RuntimeResolvedCallMutation> {
        self.mutation.as_ref()
    }

    pub const fn result(&self) -> RuntimeCallResultShape {
        self.result
    }

    pub(crate) fn program_fanout(&self) -> Option<RuntimeProgramFanoutContract<'_>> {
        let producer = self.need_producer()?;
        if !matches!(
            producer.execution(),
            RuntimeResolvedNeedProducerExecution::ProgramFanout
        ) {
            return None;
        }
        self.program_fanout_contract(producer.need_type())
    }

    pub(crate) fn action_receive(
        &self,
    ) -> Option<(&RuntimeNormalizedType, &RuntimeNormalizedType)> {
        let producer = self.need_producer()?;
        if !matches!(
            producer.execution(),
            RuntimeResolvedNeedProducerExecution::ProgramActionReceive
        ) {
            return None;
        }
        self.action_receive_contract(producer.need_type())
    }

    fn action_receive_contract<'a>(
        &'a self,
        need: &'a RuntimeNormalizedType,
    ) -> Option<(&'a RuntimeNormalizedType, &'a RuntimeNormalizedType)> {
        let [channel] = self.operands() else {
            return None;
        };
        let RuntimeTypeShape::Need(payload) = need.shape() else {
            return None;
        };
        let RuntimeTypeShape::EntityReference(reference) = channel.ty().shape() else {
            return None;
        };
        if self.completed_group.get() != 0
            || !matches!(
                channel.origin(),
                RuntimeResolvedCallOperandOrigin::Argument {
                    argument: 0,
                    slot: 0
                }
            )
            || channel.parameter() != Some(RuntimeCallParameterCoordinate::new(0, 0))
            || !matches!(
                channel.projection(),
                RuntimeResolvedCallOperandProjection::Scalar
            )
            || reference.family() != Some(arcweft_id::ProjectEntityReferenceFamily::Action)
            || reference.payload().map(|ty| ty.as_ref()) != Some(payload.as_ref())
        {
            return None;
        }
        Some((channel.ty(), payload))
    }

    fn program_fanout_contract<'a>(
        &'a self,
        need_type: &'a RuntimeNormalizedType,
    ) -> Option<RuntimeProgramFanoutContract<'a>> {
        let [receiver, limit] = self.operands() else {
            return None;
        };
        if self.completed_group.get() != 0
            || !matches!(
                receiver.origin(),
                RuntimeResolvedCallOperandOrigin::Receiver
            )
            || !matches!(
                limit.origin(),
                RuntimeResolvedCallOperandOrigin::Argument {
                    argument: 0,
                    slot: 0
                }
            )
            || limit.parameter() != Some(RuntimeCallParameterCoordinate::new(0, 0))
            || !matches!(limit.binding(), RuntimeResolvedCallOperandBinding::Named(name) if name.as_str() == "limit")
            || !matches!(
                limit.ty().shape(),
                RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::U32)
            )
            || self.operands().iter().any(|operand| {
                !matches!(
                    operand.projection(),
                    RuntimeResolvedCallOperandProjection::Scalar
                )
            })
        {
            return None;
        }
        let RuntimeTypeShape::Traversal { source, mapping } = receiver.ty().shape() else {
            return None;
        };
        let item = match source.shape() {
            RuntimeTypeShape::Sequence {
                kind:
                    RuntimeSequenceKind::Vec | RuntimeSequenceKind::Seq | RuntimeSequenceKind::Slice,
                item,
            }
            | RuntimeTypeShape::Array { item, .. } => item,
            _ => return None,
        };
        let RuntimeTypeShape::Function {
            parameters,
            result: need,
            ..
        } = mapping.shape()
        else {
            return None;
        };
        let [parameter] = parameters.as_ref() else {
            return None;
        };
        let RuntimeTypeShape::Need(result) = need.shape() else {
            return None;
        };
        let RuntimeTypeShape::Result { value, error, .. } = result.shape() else {
            return None;
        };
        let RuntimeTypeShape::Need(aggregate) = need_type.shape() else {
            return None;
        };
        let RuntimeTypeShape::Result {
            value: collection,
            error: aggregate_error,
            ..
        } = aggregate.shape()
        else {
            return None;
        };
        let RuntimeTypeShape::Sequence {
            kind: RuntimeSequenceKind::Vec,
            item: aggregate_item,
        } = collection.shape()
        else {
            return None;
        };
        if parameter != item.as_ref()
            || value.as_ref() != aggregate_item.as_ref()
            || error != aggregate_error
        {
            return None;
        }
        Some(RuntimeProgramFanoutContract {
            source,
            mapping,
            limit: limit.ty(),
            item,
            need,
            result,
            aggregate,
        })
    }

    fn accepts_traversal_type(&self, result: Option<&RuntimeNormalizedType>) -> bool {
        let [source, mapping] = self.operands() else {
            return false;
        };
        let Some(RuntimeTypeShape::Traversal {
            source: expected_source,
            mapping: expected_mapping,
        }) = result.map(RuntimeNormalizedType::shape)
        else {
            return false;
        };
        self.completed_group.get() == 0
            && self.result == RuntimeCallResultShape::Value
            && self.attached_content.is_none()
            && self.project_function.is_none()
            && self.need_producer.is_none()
            && self.mutation.is_none()
            && matches!(source.origin(), RuntimeResolvedCallOperandOrigin::Receiver)
            && matches!(
                mapping.origin(),
                RuntimeResolvedCallOperandOrigin::Argument {
                    argument: 0,
                    slot: 0
                }
            )
            && mapping.parameter() == Some(RuntimeCallParameterCoordinate::new(0, 0))
            && self.operands().iter().all(|operand| {
                matches!(
                    operand.projection(),
                    RuntimeResolvedCallOperandProjection::Scalar
                )
            })
            && expected_source.as_ref() == source.ty()
            && expected_mapping.as_ref() == mapping.ty()
    }

    /// Whether this target is represented by a structural expression payload
    /// rather than the common positioned Call/Apply carrier. Such payloads
    /// must consume the shared source-order ANF materialization before they
    /// may interpret operands by semantic/ABI role.
    pub const fn requires_specialized_operand_anf(&self) -> bool {
        if self.flow_transfer_target().is_some() {
            return true;
        }
        matches!(
            self.dispatch,
            RuntimeResolvedCallDispatch::Static(
                RuntimeResolvedStaticCallTarget::Agent(_)
                    | RuntimeResolvedStaticCallTarget::AgentProbeComparison(_)
                    | RuntimeResolvedStaticCallTarget::AgentDiagnosticsHasError
                    | RuntimeResolvedStaticCallTarget::Variant(_)
                    | RuntimeResolvedStaticCallTarget::RecordConstructor { .. }
                    | RuntimeResolvedStaticCallTarget::Reduction(_)
                    | RuntimeResolvedStaticCallTarget::CharacterDialogue(_)
                    | RuntimeResolvedStaticCallTarget::Traverse
            )
        )
    }

    /// A Flow declaration application binds a non-returning transfer, rather
    /// than constructing a returning project-function frame.
    pub const fn flow_transfer_target(
        &self,
    ) -> Option<&arcweft_lang_hir::symbol::FlowDeclarationId> {
        match &self.dispatch {
            RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Declaration(
                callable,
            )) => match callable.declaration() {
                CallableDeclarationKey::Flow(flow) => Some(flow),
                _ => None,
            },
            _ => None,
        }
    }
}

fn runtime_attached_content_matches_interface(
    content: &RuntimeResolvedAttachedContent,
    interface: &RuntimeCallableAttachedContentAbi,
) -> bool {
    use arcweft_lang_sema::callable::CallableParameterPresence;

    content.ty() == interface.abi_ty()
        && matches!(
            (interface.presence(), content),
            (
                CallableParameterPresence::Required,
                RuntimeResolvedAttachedContent::Required { .. }
            ) | (
                CallableParameterPresence::Optional,
                RuntimeResolvedAttachedContent::OptionalPresent { .. }
                    | RuntimeResolvedAttachedContent::OptionalOmitted { .. }
            ) | (
                CallableParameterPresence::Defaulted,
                RuntimeResolvedAttachedContent::DefaultedPresent { .. }
                    | RuntimeResolvedAttachedContent::DefaultedOmitted { .. }
            )
        )
}

/// Closed dispatch authority. Static targets are exhaustive and never encode
/// value-callee classification; value dispatch retains its exact HIR callee.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedCallDispatch {
    Static(RuntimeResolvedStaticCallTarget),
    Value { callee: ExprId },
}

impl RuntimeResolvedCallDispatch {
    pub const fn project_callable(&self) -> Option<&RuntimeProjectCallable> {
        match self {
            Self::Static(RuntimeResolvedStaticCallTarget::Declaration(callable)) => Some(callable),
            Self::Static(RuntimeResolvedStaticCallTarget::Host(host)) => match host.owner() {
                RuntimeResolvedHostCallOwner::ExternCapability { callable, .. } => Some(callable),
                RuntimeResolvedHostCallOwner::Agent { .. } => None,
            },
            Self::Static(
                RuntimeResolvedStaticCallTarget::Intrinsic(_)
                | RuntimeResolvedStaticCallTarget::PresentationSlot(_)
                | RuntimeResolvedStaticCallTarget::PresentationFactory { .. }
                | RuntimeResolvedStaticCallTarget::PresentationView { .. }
                | RuntimeResolvedStaticCallTarget::PresentationHandleMethod { .. }
                | RuntimeResolvedStaticCallTarget::Format(_)
                | RuntimeResolvedStaticCallTarget::VecPopFront
                | RuntimeResolvedStaticCallTarget::VecPop
                | RuntimeResolvedStaticCallTarget::VecPush
                | RuntimeResolvedStaticCallTarget::Agent(_)
                | RuntimeResolvedStaticCallTarget::AgentProbeComparison(_)
                | RuntimeResolvedStaticCallTarget::AgentDiagnosticsHasError
                | RuntimeResolvedStaticCallTarget::Variant(_)
                | RuntimeResolvedStaticCallTarget::RecordConstructor { .. }
                | RuntimeResolvedStaticCallTarget::Reduction(_)
                | RuntimeResolvedStaticCallTarget::CharacterDialogue(_)
                | RuntimeResolvedStaticCallTarget::StandardMap(_)
                | RuntimeResolvedStaticCallTarget::StandardMapPrefix(_)
                | RuntimeResolvedStaticCallTarget::Traverse
                | RuntimeResolvedStaticCallTarget::TraitMethod { .. }
                | RuntimeResolvedStaticCallTarget::ProgramNeed(_)
                | RuntimeResolvedStaticCallTarget::Registered(_)
                | RuntimeResolvedStaticCallTarget::Line(_),
            )
            | Self::Value { .. } => None,
        }
    }
}

/// Closed runtime dispatch selected by the shared semantic resolver.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeLineCallable {
    AcquireActor {
        character: arcweft_character::id::CharacterId,
    },
    ActorLook {
        character: arcweft_character::id::CharacterId,
        actor: ExprId,
        look: ExprId,
        crossfade: Option<ExprId>,
    },
    VoiceHandle,
    Schedule {
        anchor: ExprId,
        callback: ExprId,
    },
}

/// Closed runtime dispatch selected by the shared semantic resolver.
#[derive(Clone, Debug, Eq, PartialEq)]
#[allow(
    clippy::large_enum_variant,
    reason = "the closed selected-target vocabulary deliberately retains exact typed owners without target-specific indirection"
)]
pub enum RuntimeResolvedStaticCallTarget {
    Intrinsic(RuntimeIntrinsic),
    /// Core-owned address/removal operation with its selected compact role ABI.
    PresentationSlot(arcweft_core::presentation::RuntimePresentationSlotCall),
    PresentationFactory {
        call: Arc<arcweft_core::presentation::RuntimePresentationFactoryCall>,
        resource_type: RuntimeNormalizedType,
        body_type: RuntimeNormalizedType,
    },
    PresentationView {
        call: Arc<arcweft_core::presentation::RuntimePresentationViewCall>,
        resource_type: RuntimeNormalizedType,
        body_type: RuntimeNormalizedType,
    },
    PresentationHandleMethod {
        method: arcweft_interaction_model::presentation::PresentationHandleMethodId,
        receiver: ExprId,
    },
    Format(RuntimeResolvedFormatCall),
    /// Checked in-place Vec operations consumed by expression lowering.
    VecPopFront,
    VecPop,
    VecPush,
    /// Owns the checked collection and unary Need-returning function value.
    Traverse,
    /// An ordinary Need whose executable kernel is owned by its producer fact.
    ProgramNeed(RuntimeProgramNeedKind),
    Agent(crate::agent::RuntimeAgentIntrinsic),
    AgentProbeComparison(arcweft_core::value::RuntimeAgentCompareOp),
    AgentDiagnosticsHasError,
    Declaration(RuntimeProjectCallable),
    /// Typed enum case selected by the shared callable resolver.
    ///
    /// Constructor calls are values in the runtime expression algebra, not
    /// registered callables or string-selected intrinsics.
    Variant(RuntimeResolvedVariant),
    /// Nominal record construction through a checked value receiver. The
    /// receiver participates in source-order evaluation; field storage uses
    /// the declaration's existing canonical record layout.
    RecordConstructor {
        record: RuntimeResolvedNominalRecord,
        receiver: ExprId,
    },
    /// Core-owned `Reduction` value construction selected by semantic identity.
    Reduction(RuntimeReductionConstructor),
    /// Exact immutable dialogue producer operation, consumed through source-row ANF.
    CharacterDialogue(RuntimeCharacterDialogueCall),
    /// One checked standard `map` overload with exact callback and receiver
    /// expression coordinates. The ordinary callable identity is retained by
    /// semantic analysis; this projection selects its closed executable
    /// constructor family without falling through to a registered backend.
    StandardMap(RuntimeStandardMapCall),
    /// Captures the first group's evaluated mapping into an ordinary
    /// executable function site for the remaining receiver group.
    StandardMapPrefix(RuntimeStandardMapPrefix),
    TraitMethod {
        method: ImplMethodDeclarationId,
        receiver: RuntimeReceiverMode,
    },
    /// A checked line capability retained as typed operation identity. It has
    /// no ordinary runtime-call fallback and is consumed only by line-plan
    /// lowering.
    Line(RuntimeLineCallable),
    Registered(arcweft_lang_sema::callable::CheckedCallableId),
    Host(RuntimeResolvedHostCall),
}

/// Closed, instantiated constructor family selected for one standard `map`
/// call. Generic arguments are read from the call's normalized operand/result
/// types; the family variant prevents a spelling or callable-digest lookup at
/// lowering time.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeStandardMapFamily {
    Vec,
    Seq,
    Array,
    Slice,
    Option,
    Result,
}

impl From<RuntimeStandardMapFamily> for arcweft_core::value::RuntimeStandardMapFamily {
    fn from(family: RuntimeStandardMapFamily) -> Self {
        match family {
            RuntimeStandardMapFamily::Vec => Self::Vec,
            RuntimeStandardMapFamily::Seq => Self::Seq,
            RuntimeStandardMapFamily::Array => Self::Array,
            RuntimeStandardMapFamily::Slice => Self::Slice,
            RuntimeStandardMapFamily::Option => Self::Option,
            RuntimeStandardMapFamily::Result => Self::Result,
        }
    }
}

/// Iterator state and owned accumulation type issued for a collection Map.
/// Array accumulates into Vec and seals its exact result only after iteration.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeStandardMapCollection {
    iteration: RuntimeBuiltinIteratorFact,
    accumulator: RuntimeNormalizedType,
}

impl RuntimeStandardMapCollection {
    pub fn new(iteration: RuntimeBuiltinIteratorFact, accumulator: RuntimeNormalizedType) -> Self {
        Self {
            iteration,
            accumulator,
        }
    }

    pub const fn iteration(&self) -> &RuntimeBuiltinIteratorFact {
        &self.iteration
    }

    pub const fn accumulator(&self) -> &RuntimeNormalizedType {
        &self.accumulator
    }
}

/// Exact final-HIR operands of one fully applied standard `map` call.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeStandardMapCall {
    family: RuntimeStandardMapFamily,
    mapping: ExprId,
    receiver: ExprId,
    order: RuntimeStandardMapOperandOrder,
    collection: Option<Box<RuntimeStandardMapCollection>>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeStandardMapPrefix {
    family: RuntimeStandardMapFamily,
    mapping: ExprId,
    collection: Option<Box<RuntimeStandardMapCollection>>,
}

impl RuntimeStandardMapPrefix {
    pub fn new(
        family: RuntimeStandardMapFamily,
        mapping: ExprId,
        collection: Option<RuntimeStandardMapCollection>,
    ) -> Self {
        Self {
            family,
            mapping,
            collection: collection.map(Box::new),
        }
    }
    pub const fn family(&self) -> RuntimeStandardMapFamily {
        self.family
    }
    pub const fn mapping(&self) -> ExprId {
        self.mapping
    }
    pub fn collection(&self) -> Option<&RuntimeStandardMapCollection> {
        self.collection.as_deref()
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeStandardMapOperandOrder {
    MappingThenReceiver,
    ReceiverThenMapping,
}

impl RuntimeStandardMapCall {
    pub fn new(
        family: RuntimeStandardMapFamily,
        mapping: ExprId,
        receiver: ExprId,
        order: RuntimeStandardMapOperandOrder,
        collection: Option<RuntimeStandardMapCollection>,
    ) -> Self {
        Self {
            family,
            mapping,
            receiver,
            order,
            collection: collection.map(Box::new),
        }
    }

    pub const fn family(&self) -> RuntimeStandardMapFamily {
        self.family
    }

    pub const fn mapping(&self) -> ExprId {
        self.mapping
    }

    pub const fn receiver(&self) -> ExprId {
        self.receiver
    }

    pub const fn order(&self) -> RuntimeStandardMapOperandOrder {
        self.order
    }

    pub fn collection(&self) -> Option<&RuntimeStandardMapCollection> {
        self.collection.as_deref()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedHostCall {
    owner: RuntimeResolvedHostCallOwner,
    public_id: String,
    capability: String,
    operation: String,
    mode: RuntimeHostCallMode,
    deterministic: bool,
}

impl RuntimeResolvedHostCall {
    pub fn extern_capability(
        callable: RuntimeProjectCallable,
        contract: arcweft_core::step::HostCallContractDigest,
        mode: RuntimeHostCallMode,
    ) -> Result<Self, RuntimeResolvedHostCallError> {
        let CallableDeclarationKey::Existing(declaration) = callable.declaration() else {
            return Err(RuntimeResolvedHostCallError::MissingDeclarationIdentity);
        };
        if declaration.owner() != CallableDeclarationOwner::ExternCapability {
            return Err(RuntimeResolvedHostCallError::NotExternCapability);
        }
        let capability = declaration
            .owner_path()
            .iter()
            .map(arcweft_lang_syntax::ast::module_path::ModuleSegment::as_str)
            .collect::<Vec<_>>()
            .join(".");
        if capability.is_empty() {
            return Err(RuntimeResolvedHostCallError::EmptyCapabilityPath);
        }
        let operation = declaration.name().to_owned();
        Ok(Self {
            owner: RuntimeResolvedHostCallOwner::ExternCapability { callable, contract },
            public_id: format!("{capability}.{operation}"),
            capability,
            operation,
            mode,
            deterministic: false,
        })
    }

    pub fn agent(schema: &arcweft_lang_sema::callable::CallableSignatureSchema) -> Option<Self> {
        let arcweft_lang_sema::callable::CallableValidator::Agent(intrinsic) = schema.validator()
        else {
            return None;
        };
        let intrinsic = crate::agent::RuntimeAgentIntrinsic::from(*intrinsic);
        let operation = intrinsic.host_operation()?;
        Some(Self {
            owner: RuntimeResolvedHostCallOwner::Agent {
                intrinsic,
                schema: schema.semantic_digest(),
            },
            public_id: format!("agent.{operation}"),
            capability: "agent".to_owned(),
            operation: operation.to_owned(),
            mode: RuntimeHostCallMode::Suspend,
            deterministic: false,
        })
    }

    pub const fn owner(&self) -> &RuntimeResolvedHostCallOwner {
        &self.owner
    }

    pub fn public_id(&self) -> &str {
        &self.public_id
    }

    pub fn capability(&self) -> &str {
        &self.capability
    }

    pub fn operation(&self) -> &str {
        &self.operation
    }

    pub const fn contract(&self) -> Option<arcweft_core::step::HostCallContractDigest> {
        match &self.owner {
            RuntimeResolvedHostCallOwner::ExternCapability { contract, .. } => Some(*contract),
            RuntimeResolvedHostCallOwner::Agent { .. } => None,
        }
    }

    /// The selected manifest or callable schema owns the producer contract;
    /// evaluated arguments and source-expression bodies do not redefine it.
    pub const fn producer_contract(&self) -> arcweft_core::task::NeedProducerContractDigest {
        let bytes = match &self.owner {
            RuntimeResolvedHostCallOwner::ExternCapability { contract, .. } => contract.as_bytes(),
            RuntimeResolvedHostCallOwner::Agent { schema, .. } => schema.as_bytes(),
        };
        arcweft_core::task::NeedProducerContractDigest::from_bytes(*bytes)
    }

    pub const fn mode(&self) -> RuntimeHostCallMode {
        self.mode
    }

    pub const fn deterministic(&self) -> bool {
        self.deterministic
    }
}

#[derive(Clone, Copy, Debug, Eq, Error, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeResolvedHostCallError {
    #[error("extern capability host call has no declaration identity")]
    MissingDeclarationIdentity,
    #[error("host-call declaration is not owned by an extern capability")]
    NotExternCapability,
    #[error("extern capability host call has an empty capability path")]
    EmptyCapabilityPath,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedHostCallOwner {
    ExternCapability {
        callable: RuntimeProjectCallable,
        contract: arcweft_core::step::HostCallContractDigest,
    },
    Agent {
        intrinsic: crate::agent::RuntimeAgentIntrinsic,
        schema: arcweft_lang_sema::callable::CallableSignatureSchemaDigest,
    },
}

/// Closed core `Reduction` constructor vocabulary below semantic analysis.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeReductionConstructor {
    Unchanged,
}

/// ABI operand origin retained by the final runtime carrier.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeResolvedCallOperandOrigin {
    /// Evaluated value callee of a closed structural producer operation.
    Callee,
    Receiver,
    Argument {
        argument: u32,
        slot: u32,
    },
}

/// Exact checked callable-schema destination of one scalar runtime operand.
/// This coordinate is retained independently from authored argument order so
/// named and positional spellings project to the same runtime authority.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeCallParameterCoordinate {
    group: u32,
    parameter: u32,
}

impl RuntimeCallParameterCoordinate {
    pub const fn new(group: u32, parameter: u32) -> Self {
        Self { group, parameter }
    }

    pub const fn group(self) -> u32 {
        self.group
    }

    pub const fn parameter(self) -> u32 {
        self.parameter
    }
}

/// Exact final-HIR source for one runtime operand.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeResolvedCallOperandSource {
    Expression(ExprId),
    CompactNumericElement { sequence: ExprId, ordinal: u32 },
}

/// Authored/runtime argument binding disposition.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeResolvedCallOperandBinding {
    Positional,
    Named(CallArgumentName),
}

/// Accepted scalar or spread-container runtime projection.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedCallOperandProjection {
    Scalar,
    SpreadContainer(RuntimeResolvedSpreadContainer),
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeMapKind {
    Ordered,
    Sorted,
    BTree,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeResolvedSpreadContainer {
    Vec,
    Seq,
    Slice,
    Array {
        len: usize,
    },
    MapValue {
        kind: RuntimeMapKind,
        key: RuntimeNormalizedType,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeResolvedCallOperand {
    abi_position: u32,
    origin: RuntimeResolvedCallOperandOrigin,
    source: RuntimeResolvedCallOperandSource,
    ty: RuntimeNormalizedType,
    binding: RuntimeResolvedCallOperandBinding,
    projection: RuntimeResolvedCallOperandProjection,
    parameter: Option<RuntimeCallParameterCoordinate>,
    request_role_identity: Option<arcweft_lang_sema::callable::CheckedCallRequestRoleIdentity>,
}

impl RuntimeResolvedCallOperand {
    #[expect(
        clippy::too_many_arguments,
        reason = "one physical operand retains complete source, ABI, projection and accepted role evidence"
    )]
    pub fn new(
        abi_position: u32,
        origin: RuntimeResolvedCallOperandOrigin,
        source: RuntimeResolvedCallOperandSource,
        ty: RuntimeNormalizedType,
        binding: RuntimeResolvedCallOperandBinding,
        projection: RuntimeResolvedCallOperandProjection,
        parameter: Option<RuntimeCallParameterCoordinate>,
        request_role_identity: Option<arcweft_lang_sema::callable::CheckedCallRequestRoleIdentity>,
    ) -> Self {
        Self {
            abi_position,
            origin,
            source,
            ty,
            binding,
            projection,
            parameter,
            request_role_identity,
        }
    }

    pub const fn abi_position(&self) -> u32 {
        self.abi_position
    }

    pub const fn origin(&self) -> &RuntimeResolvedCallOperandOrigin {
        &self.origin
    }
    pub const fn source(&self) -> RuntimeResolvedCallOperandSource {
        self.source
    }
    pub const fn ty(&self) -> &RuntimeNormalizedType {
        &self.ty
    }
    pub const fn binding(&self) -> &RuntimeResolvedCallOperandBinding {
        &self.binding
    }
    pub const fn projection(&self) -> &RuntimeResolvedCallOperandProjection {
        &self.projection
    }

    /// Sealed checked role retained without spelling-based reconstruction.
    pub const fn request_role_identity(
        &self,
    ) -> Option<arcweft_lang_sema::callable::CheckedCallRequestRoleIdentity> {
        self.request_role_identity
    }

    pub const fn parameter(&self) -> Option<RuntimeCallParameterCoordinate> {
        self.parameter
    }
}

/// Whether a checked call produces its declared value or a partial function.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeCallResultShape {
    Value,
    PartialFunction,
}

/// Checked assertion disposition for an exact final-HIR assertion statement.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeAssertionAdmission {
    Discharged,
    Runtime(RuntimeAssertionMode),
    OmittedDebug,
}

/// Opaque, read-only compiler admission for one reachable `On` statement.
///
/// The compiler-to-runtime-plan staging boundary is the only constructor.
/// Callers cannot manufacture or change the admitted trigger meaning after
/// the single semantic-fact transaction has been sealed.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeTriggerAdmission {
    kind: RuntimeTriggerAdmissionKind,
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum RuntimeTriggerAdmissionKind {
    Input,
    InputAction(arcweft_interaction_model::input::InputActionId),
    Event,
    Signal,
    Timeout,
    Mark(RuntimeDialogueMarkFact),
    Select,
    Task,
    Scope,
    Expression,
}

impl RuntimeTriggerAdmission {
    const fn new(kind: RuntimeTriggerAdmissionKind) -> Self {
        Self { kind }
    }

    pub const fn input() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Input)
    }

    pub const fn input_action(action: arcweft_interaction_model::input::InputActionId) -> Self {
        Self::new(RuntimeTriggerAdmissionKind::InputAction(action))
    }

    pub const fn event() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Event)
    }

    pub const fn signal() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Signal)
    }

    pub const fn timeout() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Timeout)
    }

    pub const fn mark(mark: RuntimeDialogueMarkFact) -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Mark(mark))
    }

    pub const fn select() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Select)
    }

    pub const fn task() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Task)
    }

    pub const fn scope() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Scope)
    }

    pub const fn expression() -> Self {
        Self::new(RuntimeTriggerAdmissionKind::Expression)
    }

    pub const fn dialogue_mark(&self) -> Option<&RuntimeDialogueMarkFact> {
        match &self.kind {
            RuntimeTriggerAdmissionKind::Mark(mark) => Some(mark),
            RuntimeTriggerAdmissionKind::Input
            | RuntimeTriggerAdmissionKind::InputAction(_)
            | RuntimeTriggerAdmissionKind::Event
            | RuntimeTriggerAdmissionKind::Signal
            | RuntimeTriggerAdmissionKind::Timeout
            | RuntimeTriggerAdmissionKind::Select
            | RuntimeTriggerAdmissionKind::Task
            | RuntimeTriggerAdmissionKind::Scope
            | RuntimeTriggerAdmissionKind::Expression => None,
        }
    }

    pub const fn input_action_id(
        &self,
    ) -> Option<&arcweft_interaction_model::input::InputActionId> {
        match &self.kind {
            RuntimeTriggerAdmissionKind::InputAction(action) => Some(action),
            _ => None,
        }
    }
}

/// Checked capture metadata that is not derivable from lexical HIR alone.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeCheckedCapture {
    projection: arcweft_lang_hir::project::HirSelectedCapture,
    ty: RuntimeNormalizedType,
    origin: arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin,
}

/// One executable dialogue application projected from checked semantics.
#[derive(Clone, Debug, PartialEq)]
pub struct RuntimeDialogueApplication {
    target: RuntimeDialogueApplicationTarget,
    content: DialogueContentSpec,
    line_result: RuntimeNormalizedType,
    effects: arcweft_core::plan::RuntimeEffectSet,
    result_outputs: BTreeMap<StmtId, ExprId>,
}

impl RuntimeDialogueApplication {
    pub fn new(
        target: RuntimeDialogueApplicationTarget,
        content: DialogueContentSpec,
        line_result: RuntimeNormalizedType,
        effects: arcweft_core::plan::RuntimeEffectSet,
        result_outputs: BTreeMap<StmtId, ExprId>,
    ) -> Self {
        Self {
            target,
            content,
            line_result,
            effects,
            result_outputs,
        }
    }

    pub const fn target(&self) -> &RuntimeDialogueApplicationTarget {
        &self.target
    }

    pub const fn content(&self) -> &DialogueContentSpec {
        &self.content
    }

    pub const fn line_result(&self) -> &RuntimeNormalizedType {
        &self.line_result
    }

    /// The checked effect authority shared by the generated line bodies.
    pub const fn effects(&self) -> &arcweft_core::plan::RuntimeEffectSet {
        &self.effects
    }

    pub fn result_output_application(&self, statement: StmtId) -> Option<ExprId> {
        self.result_outputs.get(&statement).copied()
    }

    pub fn result_outputs(&self) -> &BTreeMap<StmtId, ExprId> {
        &self.result_outputs
    }
}

/// Typed trigger for one effectful inline dialogue call.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeDialogueEffectTrigger {
    Content,
    Delay {
        duration: arcweft_core::time::LogicalDuration,
        duration_type: RuntimeNormalizedType,
        schedule_handle_type: RuntimeNormalizedType,
    },
}

/// Accepted authored expression supplying one document-local dialogue slot.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeDialogueValueExpression {
    slot: RuntimeDialogueValueSlotId,
    role: RuntimeDialogueValueRole,
    expression: ExprId,
    ty: RuntimeNormalizedType,
    project_display: Option<RuntimeProjectDisplayValue>,
}

impl RuntimeDialogueValueExpression {
    pub const fn new(
        slot: RuntimeDialogueValueSlotId,
        role: RuntimeDialogueValueRole,
        expression: ExprId,
        ty: RuntimeNormalizedType,
    ) -> Self {
        Self {
            slot,
            role,
            expression,
            ty,
            project_display: None,
        }
    }

    pub fn new_project_display(
        slot: RuntimeDialogueValueSlotId,
        expression: ExprId,
        source_type: RuntimeNormalizedType,
        content_type: RuntimeNormalizedType,
        method: RuntimeTraitMethodInstanceKey,
        template: RuntimeFormatTemplateKey,
    ) -> Self {
        Self {
            slot,
            role: RuntimeDialogueValueRole::Content,
            expression,
            ty: content_type,
            project_display: Some(RuntimeProjectDisplayValue::new(
                source_type,
                method,
                template,
            )),
        }
    }

    pub const fn slot(&self) -> RuntimeDialogueValueSlotId {
        self.slot
    }

    pub const fn role(&self) -> RuntimeDialogueValueRole {
        self.role
    }

    pub const fn expression(&self) -> ExprId {
        self.expression
    }

    pub const fn ty(&self) -> &RuntimeNormalizedType {
        &self.ty
    }

    pub const fn source_type(&self) -> &RuntimeNormalizedType {
        match &self.project_display {
            Some(project) => project.source_type(),
            None => &self.ty,
        }
    }

    pub const fn project_display(&self) -> Option<&RuntimeProjectDisplayValue> {
        self.project_display.as_ref()
    }
}

/// Trait authority selected by final semantic analysis for one executable
/// implementation method.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeTraitIdentity {
    Project(ItemId),
    StandardIterator,
    StandardIntoIterator,
    StandardDisplayText,
}

/// One closed executable instance of a trait method. A declaration may have
/// several monomorphized bodies and therefore is not a complete lookup key.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeTraitMethodInstanceKey {
    declaration: ImplMethodDeclarationId,
    self_type: RuntimeSemanticTypeId,
}

/// One closed executable that selected a method after global reachability
/// was sealed. The use is scoped to a concrete instance and expression.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeTraitMethodUseScope {
    Program(RuntimePureProgramId),
    ProjectFunction(RuntimeProjectFunctionInstanceKey),
    Closure(RuntimeClosureInstanceKey),
    TraitMethod(RuntimeTraitMethodInstanceKey),
}

impl RuntimeTraitMethodUseScope {
    fn for_executable(scope: RuntimeExecutableSemanticScope<'_>) -> Option<Self> {
        match scope {
            RuntimeExecutableSemanticScope::Global => None,
            RuntimeExecutableSemanticScope::Program(program) => Some(Self::Program(program)),
            RuntimeExecutableSemanticScope::ProjectFunction(key) => {
                Some(Self::ProjectFunction(key.clone()))
            }
            RuntimeExecutableSemanticScope::Closure(key) => Some(Self::Closure(key.clone())),
            RuntimeExecutableSemanticScope::TraitMethod(key) => {
                Some(Self::TraitMethod(key.clone()))
            }
        }
    }
}

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct RuntimeTraitMethodInstanceUse {
    scope: RuntimeTraitMethodUseScope,
    expression: ExprId,
}

impl RuntimeTraitMethodInstanceUse {
    pub const fn new(scope: RuntimeTraitMethodUseScope, expression: ExprId) -> Self {
        Self { scope, expression }
    }

    pub const fn scope(&self) -> &RuntimeTraitMethodUseScope {
        &self.scope
    }
    pub const fn expression(&self) -> ExprId {
        self.expression
    }
}

impl RuntimeTraitMethodInstanceKey {
    pub const fn new(
        declaration: ImplMethodDeclarationId,
        self_type: RuntimeSemanticTypeId,
    ) -> Self {
        Self {
            declaration,
            self_type,
        }
    }

    pub const fn declaration(&self) -> &ImplMethodDeclarationId {
        &self.declaration
    }
    pub const fn self_type(&self) -> RuntimeSemanticTypeId {
        self.self_type
    }
}

/// Generation-bound method identity consumed by final-HIR runtime lowering.
///
/// The runtime method ID is assigned deterministically by the compiler from
/// the ordered set of checked conformances. The implementation/member pair is
/// the sole body owner; no detached method catalog or source lookup is
/// retained.
#[derive(Clone, Debug)]
pub struct RuntimeTraitMethodFact {
    key: RuntimeTraitMethodInstanceKey,
    implementation: ItemId,
    member: u16,
    trait_identity: RuntimeTraitIdentity,
    self_type: RuntimeNormalizedType,
    definition: Arc<arcweft_lang_sema::final_analysis::CheckedExecutionInputAbi>,
    closed_callable: Option<RuntimeCallableId>,
    closed_semantics: Option<RuntimeProjectFunctionInstanceSemanticFacts>,
    instance_uses: Box<[RuntimeTraitMethodInstanceUse]>,
}

impl RuntimeTraitMethodFact {
    pub fn try_new(
        declaration: ImplMethodDeclarationId,
        implementation: ItemId,
        member: u16,
        trait_identity: RuntimeTraitIdentity,
        self_type: RuntimeNormalizedType,
        definition: Arc<arcweft_lang_sema::final_analysis::CheckedExecutionInputAbi>,
    ) -> Result<Self, RuntimeSemanticFactsError> {
        if !matches!(definition.source(),
            arcweft_lang_sema::final_analysis::CheckedExecutionSource::InvokeBody(
                arcweft_lang_sema::final_analysis::CheckedExecutionBodyOwner::Declaration {
                    declaration: CallableDeclarationKey::ImplMethod(actual),
                    role: arcweft_lang_hir::project::HirDeclarationBodyRootRole::ImplFunctionBody,
                }
            ) if actual == &declaration)
        {
            return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
        }
        Ok(Self {
            key: RuntimeTraitMethodInstanceKey::new(declaration, self_type.identity()),
            implementation,
            member,
            trait_identity,
            self_type,
            definition,
            closed_callable: None,
            closed_semantics: None,
            instance_uses: Box::new([]),
        })
    }

    /// Compiler-owned closed body projection for one generic impl instance.
    pub fn try_new_closed(
        declaration: ImplMethodDeclarationId,
        implementation: ItemId,
        member: u16,
        trait_identity: RuntimeTraitIdentity,
        self_type: RuntimeNormalizedType,
        definition: Arc<arcweft_lang_sema::final_analysis::CheckedExecutionInputAbi>,
        callable: RuntimeCallableId,
        semantics: RuntimeProjectFunctionInstanceSemanticFacts,
        instance_uses: Box<[RuntimeTraitMethodInstanceUse]>,
    ) -> Result<Self, RuntimeSemanticFactsError> {
        if definition.environment().local_uses() != semantics.local_uses() {
            return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
        }
        let mut value = Self::try_new(
            declaration,
            implementation,
            member,
            trait_identity,
            self_type,
            definition,
        )?;
        value.closed_callable = Some(callable);
        value.closed_semantics = Some(semantics);
        value.instance_uses = instance_uses;
        Ok(value)
    }

    pub const fn key(&self) -> &RuntimeTraitMethodInstanceKey {
        &self.key
    }

    pub const fn declaration(&self) -> &ImplMethodDeclarationId {
        self.key.declaration()
    }

    pub const fn implementation(&self) -> ItemId {
        self.implementation
    }

    pub const fn member(&self) -> u16 {
        self.member
    }

    pub const fn trait_identity(&self) -> &RuntimeTraitIdentity {
        &self.trait_identity
    }

    pub const fn self_type(&self) -> &RuntimeNormalizedType {
        &self.self_type
    }

    pub const fn definition(
        &self,
    ) -> &Arc<arcweft_lang_sema::final_analysis::CheckedExecutionInputAbi> {
        &self.definition
    }

    pub const fn closed_semantics(&self) -> Option<&RuntimeProjectFunctionInstanceSemanticFacts> {
        self.closed_semantics.as_ref()
    }

    pub const fn closed_callable(&self) -> Option<&RuntimeCallableId> {
        self.closed_callable.as_ref()
    }

    pub const fn instance_uses(&self) -> &[RuntimeTraitMethodInstanceUse] {
        &self.instance_uses
    }
}

impl RuntimeCheckedCapture {
    pub const fn new(
        projection: arcweft_lang_hir::project::HirSelectedCapture,
        ty: RuntimeNormalizedType,
        origin: arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin,
    ) -> Self {
        Self {
            projection,
            ty,
            origin,
        }
    }

    pub const fn capture(&self) -> CaptureId {
        self.projection.capture()
    }

    pub const fn projection(&self) -> &arcweft_lang_hir::project::HirSelectedCapture {
        &self.projection
    }

    pub const fn source(&self) -> LocalId {
        self.projection.local()
    }

    pub const fn origin(
        &self,
    ) -> &arcweft_lang_sema::semantic_coordinate::StableCheckedBindingCoordinate {
        self.origin.coordinate()
    }

    pub const fn checked_origin(
        &self,
    ) -> &arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin {
        &self.origin
    }

    pub const fn ty(&self) -> &RuntimeNormalizedType {
        &self.ty
    }
}

#[derive(Clone, Debug)]
struct RuntimeExpressionFact {
    origin: arcweft_lang_sema::semantic_coordinate::CheckedExpressionOrigin,
}

/// Borrowed validation projection; accepted facts retain the only owned rows.
enum RuntimeExpressionTypeView<'types> {
    Facts(&'types BTreeMap<HirValueTypeOwner, RuntimeExecutableTypeProjection>),
    Projected(BTreeMap<ExprId, &'types RuntimeNormalizedType>),
}

impl<'types> FromIterator<(ExprId, &'types RuntimeNormalizedType)>
    for RuntimeExpressionTypeView<'types>
{
    fn from_iter<T: IntoIterator<Item = (ExprId, &'types RuntimeNormalizedType)>>(rows: T) -> Self {
        Self::Projected(rows.into_iter().collect())
    }
}

impl<'types> RuntimeExpressionTypeView<'types> {
    fn get(&self, owner: &ExprId) -> Option<&'types RuntimeNormalizedType> {
        match self {
            Self::Facts(facts) => facts
                .get(&HirValueTypeOwner::Expression(*owner))
                .and_then(RuntimeExecutableTypeProjection::ty),
            Self::Projected(types) => types.get(owner).copied(),
        }
    }

    fn contains_key(&self, owner: &ExprId) -> bool {
        self.get(owner).is_some()
    }

    fn keys(&self) -> impl Iterator<Item = &ExprId> {
        self.iter().map(|(owner, _)| owner)
    }

    fn iter(&self) -> impl Iterator<Item = (&ExprId, &'types RuntimeNormalizedType)> {
        let (facts, projected) = match self {
            Self::Facts(facts) => (Some(*facts), None),
            Self::Projected(types) => (None, Some(types)),
        };
        facts
            .into_iter()
            .flat_map(|facts| facts.iter())
            .filter_map(|(owner, fact)| match owner {
                HirValueTypeOwner::Expression(owner) => fact.ty().map(|ty| (owner, ty)),
                _ => None,
            })
            .chain(
                projected
                    .into_iter()
                    .flat_map(|types| types.iter())
                    .map(|(owner, ty)| (owner, *ty)),
            )
    }
}

/// Original checked authority for an ordinary program or a retained View Match.
/// A View Match keeps its one original catalog row, including its checked root.
#[derive(Clone, Debug)]
pub enum RuntimePureProgramAdmission {
    Ordinary(Arc<arcweft_lang_sema::final_analysis::CheckedDeterministicProgram>),
    ViewMatch(Arc<arcweft_lang_sema::final_analysis::CompilerLocalViewMatchCatalogRow>),
}

impl RuntimePureProgramAdmission {
    pub fn checked_program(
        &self,
    ) -> &arcweft_lang_sema::final_analysis::CheckedDeterministicProgram {
        match self {
            Self::Ordinary(program) => program,
            Self::ViewMatch(source) => source.checked_program(),
        }
    }
}

/// Runtime type projection of one admitted value or body root's complete ABI.
/// Free bindings and full formal inputs retain the admission's stable order.
#[derive(Clone, Debug)]
pub struct RuntimePureProgramFact {
    program: RuntimePureProgramId,
    admission: RuntimePureProgramAdmission,
    input_types: Box<[RuntimeNormalizedType]>,
    result: RuntimeNormalizedType,
    function_type: RuntimeNormalizedType,
    body_kind: arcweft_core::plan::RuntimeFunctionSiteBodyKind,
}

impl RuntimePureProgramFact {
    /// Uses the admitted definition authority; runtime program IDs remain
    /// generation-local joins and do not identify a stable lexical definition.
    pub fn definition_identity(
        &self,
    ) -> arcweft_lang_sema::final_analysis::CheckedExecutionDefinitionIdentity {
        self.admission().input_abi().definition_identity()
    }

    /// Retains the accepted lexical body role even when lowering promotes an
    /// expression body to control-transfer execution.
    pub fn semantic_role(&self) -> arcweft_core::plan::RuntimeFunctionSemanticRole {
        use arcweft_core::plan::RuntimeFunctionSemanticRole;
        use arcweft_lang_sema::final_analysis::{
            CheckedExecutionBodyOwner, CheckedExecutionSource,
        };
        match self.admission().input_abi().source() {
            CheckedExecutionSource::InvokeBody(CheckedExecutionBodyOwner::CallableValue(_))
            | CheckedExecutionSource::ExportMutation(CheckedExecutionBodyOwner::CallableValue(_)) => {
                RuntimeFunctionSemanticRole::Closure
            }
            CheckedExecutionSource::InvokeBody(CheckedExecutionBodyOwner::Declaration {
                ..
            })
            | CheckedExecutionSource::ExportMutation(CheckedExecutionBodyOwner::Declaration {
                ..
            })
            | CheckedExecutionSource::EvaluateValue(_)
            | CheckedExecutionSource::SelectMatch(_)
            | CheckedExecutionSource::ExportBinding(_)
            | CheckedExecutionSource::ExportIteration(_) => RuntimeFunctionSemanticRole::Ordinary,
        }
    }

    pub fn try_new(
        program: RuntimePureProgramId,
        admission: RuntimePureProgramAdmission,
        input_types: Box<[RuntimeNormalizedType]>,
        result: RuntimeNormalizedType,
        function_type: RuntimeNormalizedType,
    ) -> Result<Self, RuntimeSemanticFactsError> {
        use arcweft_lang_sema::final_analysis::CheckedExecutionInputRole;
        let abi = admission.checked_program().input_abi();
        if !abi
            .function_type()
            .and_then(|ty| ty.semantic_identity_digest().ok())
            .is_some_and(|identity| identity.as_bytes() == function_type.identity().as_bytes())
            || !matches!(function_type.shape(), RuntimeTypeShape::Function { parameters, result: declared_result, .. }
                if parameters.as_ref() == input_types.as_ref() && declared_result.as_ref() == &result)
        {
            return Err(RuntimeSemanticFactsError::InvalidPureProgram { program });
        }
        let expression_body = match abi.source() {
            arcweft_lang_sema::final_analysis::CheckedExecutionSource::InvokeBody(
                arcweft_lang_sema::final_analysis::CheckedExecutionBodyOwner::Declaration {
                    declaration,
                    role,
                },
            ) => {
                let view = abi
                    .hir_topology()
                    .declaration(declaration)
                    .map_err(|_| RuntimeSemanticFactsError::InvalidPureProgram { program })?;
                let root = view
                    .body()
                    .roots()
                    .iter()
                    .find(|root| root.role() == *role)
                    .ok_or(RuntimeSemanticFactsError::InvalidPureProgram { program })?;
                root.projection().kind() != arcweft_lang_hir::body_edges::HirBodyKind::Thread
            }
            _ => true,
        };
        let body_kind = if !matches!(abi.source(), arcweft_lang_sema::final_analysis::CheckedExecutionSource::ExportBinding(_) | arcweft_lang_sema::final_analysis::CheckedExecutionSource::ExportIteration(_) | arcweft_lang_sema::final_analysis::CheckedExecutionSource::SelectMatch(_) | arcweft_lang_sema::final_analysis::CheckedExecutionSource::ExportMutation(_)) && expression_body && abi.control() == arcweft_lang_sema::final_analysis::CheckedExecutableControlRole::ExpressionCompatible {
            arcweft_core::plan::RuntimeFunctionSiteBodyKind::Expression
        } else { arcweft_core::plan::RuntimeFunctionSiteBodyKind::Executable };
        let free_inputs = abi
            .inputs()
            .iter()
            .filter(|input| matches!(input.role(), CheckedExecutionInputRole::Free))
            .count();
        if free_inputs.checked_add(abi.parameters().len()) != Some(input_types.len())
            || abi.result().value_type().is_none()
        {
            return Err(RuntimeSemanticFactsError::InvalidPureProgram { program });
        }
        for (source, projected) in abi
            .inputs()
            .iter()
            .filter(|input| matches!(input.role(), CheckedExecutionInputRole::Free))
            .map(|input| input.binding().ty())
            .chain(abi.parameters().iter().map(|parameter| parameter.ty()))
            .chain(abi.result().value_type())
            .zip(input_types.iter().chain([&result]))
        {
            if !source
                .semantic_identity_digest()
                .or_else(|_| {
                    source.semantic_identity_digest_in_scope(&abi.environment().type_scope())
                })
                .is_ok_and(|digest| digest.as_bytes() == projected.identity().as_bytes())
            {
                return Err(RuntimeSemanticFactsError::InvalidPureProgram { program });
            }
        }
        Ok(Self {
            program,
            admission,
            input_types,
            result,
            function_type,
            body_kind,
        })
    }

    pub const fn program(&self) -> RuntimePureProgramId {
        self.program
    }

    pub fn admission(&self) -> &arcweft_lang_sema::final_analysis::CheckedDeterministicProgram {
        self.admission.checked_program()
    }

    pub fn view_match_catalog(
        &self,
    ) -> Option<&Arc<arcweft_lang_sema::final_analysis::CompilerLocalViewMatchCatalogRow>> {
        match &self.admission {
            RuntimePureProgramAdmission::Ordinary(_) => None,
            RuntimePureProgramAdmission::ViewMatch(source) => Some(source),
        }
    }

    pub fn source(&self) -> &arcweft_lang_sema::final_analysis::CheckedExecutionSource {
        self.admission().input_abi().source()
    }

    pub fn reachability_owner(&self) -> HirRuntimeExecutableOwner {
        self.admission().reachability_owner()
    }

    pub const fn input_types(&self) -> &[RuntimeNormalizedType] {
        &self.input_types
    }

    pub const fn function_type(&self) -> &RuntimeNormalizedType {
        &self.function_type
    }

    pub fn free_inputs(
        &self,
    ) -> impl Iterator<
        Item = (
            &arcweft_lang_sema::final_analysis::CheckedExecutionInput,
            &RuntimeNormalizedType,
        ),
    > {
        self.admission()
            .input_abi()
            .inputs()
            .iter()
            .filter(|input| {
                matches!(
                    input.role(),
                    arcweft_lang_sema::final_analysis::CheckedExecutionInputRole::Free
                )
            })
            .zip(self.input_types.iter())
    }

    pub fn parameters(
        &self,
    ) -> impl Iterator<
        Item = (
            &arcweft_lang_sema::final_analysis::CheckedExecutionParameter,
            &RuntimeNormalizedType,
        ),
    > {
        let free_count = self.free_inputs().count();
        self.admission()
            .input_abi()
            .parameters()
            .iter()
            .zip(self.input_types.iter().skip(free_count))
    }

    pub const fn result(&self) -> &RuntimeNormalizedType {
        &self.result
    }

    pub const fn body_kind(&self) -> arcweft_core::plan::RuntimeFunctionSiteBodyKind {
        self.body_kind
    }
}

/// Mutable staging owner used by semantic analysis before generation binding.
///
/// Staged facts are not executable. [`RuntimePlanSemanticFacts::try_new`]
/// validates every owner and nested project identity before publication.
#[derive(Debug)]
pub struct RuntimePlanSemanticFactInput {
    callable_sources: Vec<RuntimeProjectCallableSourceFact>,
    callable_specializations: Vec<RuntimeCallableSpecializationFact>,
    expression_specializations: Vec<(ExprId, RuntimeCallableValueSpecialization)>,
    local_declaration_order: Vec<LocalId>,
    type_projections: Vec<(HirValueTypeOwner, RuntimeExecutableTypeProjection)>,
    flows: Vec<(ItemId, RuntimeFlowFact)>,
    includes: Vec<arcweft_lang_sema::final_analysis::CheckedIncludeFlowTarget>,
    suspensions: Vec<(
        StmtId,
        arcweft_lang_sema::final_analysis::CheckedSuspensionStatement,
    )>,
    expression_scopes: Vec<(ExprId, crate::semantic_facts::RuntimeScopeFact)>,
    statement_scopes: Vec<(StmtId, crate::semantic_facts::RuntimeScopeFact)>,
    thread_producers: Vec<(
        ExprId,
        arcweft_lang_sema::CheckedExpressionProducerDefinition,
    )>,
    call_producers: Vec<(
        ExprId,
        arcweft_lang_sema::CheckedExpressionProducerDefinition,
    )>,
    expression_facts: Vec<(ExprId, RuntimeExpressionFact)>,
    expression_literals: Vec<(ExprId, RuntimeValue)>,
    expression_residual_values: Vec<(ExprId, RuntimeResidualValue)>,
    pattern_literals: Vec<(PatternId, RuntimeValue)>,
    pattern_items: Vec<(
        PatternId,
        arcweft_lang_sema::final_analysis::CheckedEntityPatternProjection,
    )>,
    values: Vec<(ExprId, RuntimeResolvedValue)>,
    checked_local_uses: Option<Arc<arcweft_lang_sema::final_analysis::CheckedLocalUseCatalog>>,
    selects: Vec<(ExprId, RuntimeResolvedSelect)>,
    nominal_records: Vec<(ExprId, RuntimeRecordExpressionFact)>,
    pattern_nominal_records: Vec<(PatternId, RuntimeRecordPatternFact)>,
    expression_variants: Vec<(ExprId, RuntimeResolvedVariant)>,
    pattern_variants: Vec<(PatternId, RuntimeResolvedVariant)>,
    calls: Vec<(ExprId, RuntimeResolvedCall)>,
    postfix_candidates: Vec<(ExprId, ExprId)>,
    trait_methods: Vec<RuntimeTraitMethodFact>,
    iterations: Vec<(StmtId, RuntimeIteratorFact)>,
    assertions: Vec<(StmtId, RuntimeAssertionAdmission)>,
    triggers: BTreeMap<StmtId, RuntimeTriggerAdmission>,
    assignments: Vec<(StmtId, RuntimeAssignmentFact)>,
    registry_writes: Vec<(StmtId, RuntimeRegistryWriteFact)>,
    evaluated_effects: Vec<(ExprId, RuntimeEvaluatedEffectFact)>,
    defers: Vec<(StmtId, RuntimeDeferFact)>,
    choices: Vec<(ExprId, RuntimeChoiceFact)>,
    awaits: Vec<(ExprId, RuntimeAwaitFact)>,
    tries: Vec<(ExprId, RuntimeTryFact)>,
    implicit_callables: Vec<(ExprId, RuntimeImplicitCallableFact)>,
    pipes: Vec<(ExprId, RuntimePipeFact)>,
    pure_programs: Vec<RuntimePureProgramFact>,
    value_contract_types: Vec<RuntimeNormalizedType>,
    pure_program_semantics: Vec<(
        RuntimePureProgramId,
        RuntimeProjectFunctionInstanceSemanticFacts,
    )>,
    project_function_instances: Vec<RuntimeProjectFunctionInstanceFact>,
    root_closures: Vec<RuntimeClosureInstanceFact>,
    project_function_roots: Vec<RuntimeProjectFunctionRootFact>,
    dialogue_applications: BTreeMap<ExprId, RuntimeDialogueApplication>,
    dialogue_content_fragments: Vec<RuntimeContentFragmentFact>,
    format_templates: Vec<RuntimeFormatTemplateFact>,
    dialogue_lines: Option<Arc<AcceptedDialogueLineInventory>>,
    character_presentation_catalog: Option<Arc<CharacterPresentationCatalogData>>,
    character_dialogue_policy_types:
        Option<Arc<arcweft_dialogue::CharacterDialoguePolicyTypeGraph>>,
    character_dialogue_generation:
        Option<character_dialogue_generation::RuntimeCharacterDialogueGenerationFact>,
}

impl RuntimePlanSemanticFactInput {
    pub fn new() -> Self {
        Self {
            callable_sources: Vec::new(),
            callable_specializations: Vec::new(),
            expression_specializations: Vec::new(),
            local_declaration_order: Vec::new(),
            type_projections: Vec::new(),
            flows: Vec::new(),
            includes: Vec::new(),
            suspensions: Vec::new(),
            expression_scopes: Vec::new(),
            statement_scopes: Vec::new(),
            thread_producers: Vec::new(),
            call_producers: Vec::new(),
            expression_facts: Vec::new(),
            expression_literals: Vec::new(),
            expression_residual_values: Vec::new(),
            pattern_literals: Vec::new(),
            pattern_items: Vec::new(),
            values: Vec::new(),
            checked_local_uses: None,
            selects: Vec::new(),
            nominal_records: Vec::new(),
            pattern_nominal_records: Vec::new(),
            expression_variants: Vec::new(),
            pattern_variants: Vec::new(),
            calls: Vec::new(),
            postfix_candidates: Vec::new(),
            trait_methods: Vec::new(),
            iterations: Vec::new(),
            assertions: Vec::new(),
            triggers: BTreeMap::new(),
            assignments: Vec::new(),
            registry_writes: Vec::new(),
            evaluated_effects: Vec::new(),
            defers: Vec::new(),
            choices: Vec::new(),
            awaits: Vec::new(),
            tries: Vec::new(),
            implicit_callables: Vec::new(),
            pipes: Vec::new(),
            pure_programs: Vec::new(),
            value_contract_types: Vec::new(),
            pure_program_semantics: Vec::new(),
            project_function_instances: Vec::new(),
            root_closures: Vec::new(),
            project_function_roots: Vec::new(),
            dialogue_applications: BTreeMap::new(),
            dialogue_content_fragments: Vec::new(),
            format_templates: Vec::new(),
            dialogue_lines: None,
            character_presentation_catalog: None,
            character_dialogue_policy_types: None,
            character_dialogue_generation: None,
        }
    }

    /// Appends one runtime-domain HIR local and its exact normalized type in
    /// canonical project order. Final plan-local identity issuance belongs
    /// exclusively to [`arcweft_core::plan::RuntimePlanBuilder`].
    pub fn push_local_declaration(
        &mut self,
        owner: LocalId,
        ty: RuntimeNormalizedType,
        origin: arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin,
    ) {
        self.local_declaration_order.push(owner);
        self.type_projections.push((
            HirValueTypeOwner::Local(owner),
            RuntimeExecutableTypeProjection::local(owner, ty, origin),
        ));
    }

    /// Publishes a local together with the function-shaped scope that owns it.
    pub fn push_contextual_local_declaration(
        &mut self,
        owner: LocalId,
        ty: RuntimeNormalizedType,
        context: RuntimeNormalizedType,
        origin: arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin,
    ) {
        self.local_declaration_order.push(owner);
        self.type_projections.push((
            HirValueTypeOwner::Local(owner),
            RuntimeExecutableTypeProjection::contextual_local(owner, ty, context, origin),
        ));
    }

    pub fn push_semantic_value_projection(
        &mut self,
        projection: arcweft_lang_sema::final_analysis::CheckedSemanticValueProjection,
    ) {
        let owner = projection.owner();
        if let HirValueTypeOwner::Local(local) = owner {
            self.local_declaration_order.push(local);
        }
        self.type_projections.push((
            owner,
            RuntimeExecutableTypeProjection::semantic_value(projection),
        ));
    }

    pub fn push_flow(&mut self, owner: ItemId, flow: RuntimeFlowFact) {
        self.flows.push((owner, flow));
    }

    pub fn push_expression_scope(
        &mut self,
        owner: ExprId,
        identity: crate::semantic_facts::RuntimeScopeFact,
    ) {
        self.expression_scopes.push((owner, identity));
    }

    pub fn push_statement_scope(
        &mut self,
        owner: StmtId,
        identity: crate::semantic_facts::RuntimeScopeFact,
    ) {
        self.statement_scopes.push((owner, identity));
    }

    pub fn push_include(
        &mut self,
        target: arcweft_lang_sema::final_analysis::CheckedIncludeFlowTarget,
    ) {
        self.includes.push(target);
    }

    pub fn push_suspension(
        &mut self,
        owner: StmtId,
        suspension: arcweft_lang_sema::final_analysis::CheckedSuspensionStatement,
    ) {
        self.suspensions.push((owner, suspension));
    }

    /// Stages the accepted normalized type of one selected runtime-domain
    /// final-HIR expression.
    pub fn push_thread_producer(
        &mut self,
        owner: ExprId,
        admission: arcweft_lang_sema::CheckedExpressionProducerDefinition,
    ) {
        self.thread_producers.push((owner, admission));
    }
    pub fn push_call_producer(
        &mut self,
        owner: ExprId,
        definition: arcweft_lang_sema::CheckedExpressionProducerDefinition,
    ) {
        self.call_producers.push((owner, definition));
    }
    pub fn push_expression_type(
        &mut self,
        owner: ExprId,
        ty: RuntimeNormalizedType,
        origin: arcweft_lang_sema::semantic_coordinate::CheckedExpressionOrigin,
    ) {
        self.expression_facts
            .push((owner, RuntimeExpressionFact { origin }));
        self.type_projections.push((
            HirValueTypeOwner::Expression(owner),
            RuntimeExecutableTypeProjection::value(HirValueTypeOwner::Expression(owner), ty),
        ));
    }

    pub fn push_expression_origin(
        &mut self,
        owner: ExprId,
        origin: arcweft_lang_sema::semantic_coordinate::CheckedExpressionOrigin,
    ) {
        self.expression_facts
            .push((owner, RuntimeExpressionFact { origin }));
    }

    pub fn push_callable_source(&mut self, fact: RuntimeProjectCallableSourceFact) {
        self.callable_sources.push(fact);
    }
    pub fn push_callable_specialization(&mut self, fact: RuntimeCallableSpecializationFact) {
        self.callable_specializations.push(fact);
    }
    pub fn push_expression_specialization(
        &mut self,
        owner: ExprId,
        fact: RuntimeCallableValueSpecialization,
    ) {
        self.expression_specializations.push((owner, fact));
    }

    /// Stages the accepted normalized type of one runtime-domain final-HIR
    /// pattern.
    pub fn push_pattern_type(&mut self, owner: PatternId, ty: RuntimeNormalizedType) {
        self.type_projections.push((
            HirValueTypeOwner::Pattern(owner),
            RuntimeExecutableTypeProjection::value(HirValueTypeOwner::Pattern(owner), ty),
        ));
    }

    pub fn push_expression_literal(&mut self, owner: ExprId, value: RuntimeValue) {
        self.expression_literals.push((owner, value));
    }

    /// Stages one runtime value produced by a checked compile-time call.
    pub fn push_expression_residual_value(&mut self, owner: ExprId, value: RuntimeResidualValue) {
        self.expression_residual_values.push((owner, value));
    }

    pub fn push_pattern_literal(&mut self, owner: PatternId, value: RuntimeValue) {
        self.pattern_literals.push((owner, value));
    }

    pub fn push_pattern_entity(
        &mut self,
        owner: PatternId,
        item: arcweft_lang_sema::final_analysis::CheckedEntityPatternProjection,
    ) {
        self.pattern_items.push((owner, item));
    }

    pub fn push_value(&mut self, owner: ExprId, value: RuntimeResolvedValue) {
        self.values.push((owner, value));
    }

    /// Stages the complete checked local-use authority with its accepted HIR
    /// generation lease; individual rows cannot be spliced across analyses.
    pub fn attach_checked_local_uses(
        &mut self,
        catalog: Arc<arcweft_lang_sema::final_analysis::CheckedLocalUseCatalog>,
    ) {
        self.checked_local_uses = Some(catalog);
    }

    pub fn push_select(&mut self, owner: ExprId, select: RuntimeResolvedSelect) {
        self.selects.push((owner, select));
    }

    pub fn push_nominal_record(&mut self, owner: ExprId, record: RuntimeRecordExpressionFact) {
        self.nominal_records.push((owner, record));
    }

    pub fn push_pattern_nominal_record(
        &mut self,
        owner: PatternId,
        record: RuntimeRecordPatternFact,
    ) {
        self.pattern_nominal_records.push((owner, record));
    }

    pub fn push_expression_variant(&mut self, owner: ExprId, variant: RuntimeResolvedVariant) {
        self.expression_variants.push((owner, variant));
    }

    pub fn push_pattern_variant(&mut self, owner: PatternId, variant: RuntimeResolvedVariant) {
        self.pattern_variants.push((owner, variant));
    }

    pub fn push_type(&mut self, owner: TypeId, ty: RuntimeNormalizedType) {
        self.type_projections.push((
            HirValueTypeOwner::Type(owner),
            RuntimeExecutableTypeProjection::value(HirValueTypeOwner::Type(owner), ty),
        ));
    }

    pub fn push_call(&mut self, owner: ExprId, call: RuntimeResolvedCall) {
        self.calls.push((owner, call));
    }

    /// Stages the exact semantic winner for one immutable postfix ambiguity.
    pub fn push_postfix_candidate(&mut self, owner: ExprId, candidate: ExprId) {
        self.postfix_candidates.push((owner, candidate));
    }

    pub fn push_iteration(&mut self, owner: StmtId, evidence: RuntimeIteratorFact) {
        self.iterations.push((owner, evidence));
    }

    pub fn push_trait_method(&mut self, method: RuntimeTraitMethodFact) {
        self.trait_methods.push(method);
    }

    pub fn push_assertion(&mut self, owner: StmtId, admission: RuntimeAssertionAdmission) {
        self.assertions.push((owner, admission));
    }

    pub fn push_input_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Input)
    }

    pub fn push_input_action_trigger(
        &mut self,
        owner: StmtId,
        action: arcweft_interaction_model::input::InputActionId,
    ) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::InputAction(action))
    }

    pub fn push_event_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Event)
    }

    pub fn push_signal_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Signal)
    }

    pub fn push_timeout_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Timeout)
    }

    pub fn push_mark_trigger(
        &mut self,
        owner: StmtId,
        mark: RuntimeDialogueMarkFact,
    ) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Mark(mark))
    }

    pub fn push_select_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Select)
    }

    pub fn push_task_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Task)
    }

    pub fn push_scope_trigger(&mut self, owner: StmtId) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Scope)
    }

    pub fn push_expression_trigger(
        &mut self,
        owner: StmtId,
    ) -> Result<(), RuntimeSemanticFactsError> {
        self.insert_trigger(owner, RuntimeTriggerAdmissionKind::Expression)
    }

    fn insert_trigger(
        &mut self,
        owner: StmtId,
        kind: RuntimeTriggerAdmissionKind,
    ) -> Result<(), RuntimeSemanticFactsError> {
        match self.triggers.entry(owner) {
            std::collections::btree_map::Entry::Vacant(entry) => {
                entry.insert(RuntimeTriggerAdmission::new(kind));
                Ok(())
            }
            std::collections::btree_map::Entry::Occupied(_) => {
                Err(RuntimeSemanticFactsError::DuplicateFact {
                    family: RuntimeSemanticFactFamily::Trigger,
                })
            }
        }
    }

    /// Stages the sole checked writable place for one assignment statement.
    pub fn push_assignment(&mut self, owner: StmtId, assignment: RuntimeAssignmentFact) {
        self.assignments.push((owner, assignment));
    }

    pub fn push_registry_write(&mut self, write: RuntimeRegistryWriteFact) {
        self.registry_writes
            .push((write.address().statement(), write));
    }

    pub fn push_evaluated_effect(&mut self, owner: ExprId, effect: RuntimeEvaluatedEffectFact) {
        self.evaluated_effects.push((owner, effect));
    }

    pub fn push_defer(&mut self, owner: StmtId, defer: RuntimeDeferFact) {
        self.defers.push((owner, defer));
    }

    pub fn push_await(&mut self, owner: ExprId, fact: RuntimeAwaitFact) {
        self.awaits.push((owner, fact));
    }

    pub fn push_choice(&mut self, owner: ExprId, fact: RuntimeChoiceFact) {
        self.choices.push((owner, fact));
    }

    pub fn push_try(&mut self, owner: ExprId, fact: RuntimeTryFact) {
        self.tries.push((owner, fact));
    }

    pub fn push_implicit_callable(&mut self, owner: ExprId, fact: RuntimeImplicitCallableFact) {
        self.implicit_callables.push((owner, fact));
    }

    pub fn push_pipe(&mut self, owner: ExprId, fact: RuntimePipeFact) {
        self.pipes.push((owner, fact));
    }

    pub fn push_capture(&mut self, capture: RuntimeCheckedCapture) {
        self.type_projections.push((
            HirValueTypeOwner::Capture(capture.capture()),
            RuntimeExecutableTypeProjection::captured(capture),
        ));
    }

    pub fn push_pure_program(&mut self, program: RuntimePureProgramFact) {
        self.pure_programs.push(program);
    }

    pub fn push_pure_program_semantics(
        &mut self,
        program: RuntimePureProgramId,
        semantics: RuntimeProjectFunctionInstanceSemanticFacts,
    ) {
        self.pure_program_semantics.push((program, semantics));
    }

    /// Stages one fully closed ordinary project-function instance. Equal keys
    /// must carry equal facts; publication rejects conflicting projections.
    pub fn push_project_function_instance(&mut self, instance: RuntimeProjectFunctionInstanceFact) {
        self.project_function_instances.push(instance);
    }

    pub fn push_root_closure(&mut self, closure: RuntimeClosureInstanceFact) {
        self.root_closures.push(closure);
    }

    pub fn push_project_function_root(&mut self, root: RuntimeProjectFunctionRootFact) {
        self.project_function_roots.push(root);
    }

    pub fn push_format_template(&mut self, template: RuntimeFormatTemplateFact) {
        self.format_templates.push(template);
    }

    /// Stages the complete dialogue projection for the same single
    /// `RuntimePlanSemanticFacts::try_new` transaction as all other facts.
    pub fn attach_dialogue_projection(
        &mut self,
        catalog: Option<Arc<CharacterPresentationCatalogData>>,
        applications: BTreeMap<ExprId, RuntimeDialogueApplication>,
        fragments: Vec<RuntimeContentFragmentFact>,
        dialogue_lines: Arc<AcceptedDialogueLineInventory>,
    ) -> Result<(), RuntimeSemanticFactsError> {
        if !self.dialogue_applications.is_empty()
            || !self.dialogue_content_fragments.is_empty()
            || self.dialogue_lines.is_some()
            || self.character_presentation_catalog.is_some()
        {
            return Err(RuntimeSemanticFactsError::DuplicateFact {
                family: RuntimeSemanticFactFamily::DialogueApplication,
            });
        }
        let mut has_instance_dialogue = false;
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.iter(),
            self.root_closures.iter(),
            self.trait_methods.iter(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics
                .visit_dialogue_applications(scope, &mut |_, _, _| has_instance_dialogue = true);
        }
        if (applications.is_empty() && !has_instance_dialogue) != catalog.is_none() {
            return Err(RuntimeSemanticFactsError::DialogueCatalogPresenceMismatch);
        }
        self.dialogue_applications = applications;
        self.dialogue_content_fragments = fragments;
        self.dialogue_lines = Some(dialogue_lines);
        self.character_presentation_catalog = catalog;
        Ok(())
    }
}

impl Default for RuntimePlanSemanticFactInput {
    fn default() -> Self {
        Self::new()
    }
}

impl RuntimePlanSemanticFactInput {
    /// Publishes a retained consumer's declared type into the same plan type graph.
    pub fn push_value_contract_type(&mut self, ty: RuntimeNormalizedType) {
        self.value_contract_types.push(ty);
    }
}

/// Immutable semantic fact set bound to one exact executable project generation.
#[derive(Clone, Debug)]
pub struct RuntimePlanSemanticFacts {
    callable_sources: BTreeMap<RuntimeProjectCallableSourceKey, RuntimeProjectCallableSourceFact>,
    callable_specializations:
        BTreeMap<RuntimeCallableSpecializationKey, RuntimeCallableSpecializationFact>,
    expression_specializations: BTreeMap<ExprId, RuntimeCallableValueSpecialization>,
    nominal_definitions: BTreeMap<RuntimeSemanticTypeId, RuntimeNominalDefinition>,
    reachability: HirRuntimeReachabilityIdentity,
    program_reachability: Option<HirRuntimeReachabilityIdentity>,
    runtime_owners: BTreeSet<HirRuntimeExecutableOwner>,
    snapshots: BTreeMap<HirModuleId, HirSnapshotId>,
    local_declaration_order: Box<[LocalId]>,
    type_projections: BTreeMap<HirValueTypeOwner, RuntimeExecutableTypeProjection>,
    flows: BTreeMap<ItemId, RuntimeFlowFact>,
    includes: BTreeMap<StmtId, arcweft_lang_sema::final_analysis::CheckedIncludeFlowTarget>,
    suspensions: BTreeMap<StmtId, arcweft_lang_sema::final_analysis::CheckedSuspensionStatement>,
    expression_scopes: BTreeMap<ExprId, crate::semantic_facts::RuntimeScopeFact>,
    statement_scopes: BTreeMap<StmtId, crate::semantic_facts::RuntimeScopeFact>,
    thread_producers: BTreeMap<ExprId, arcweft_lang_sema::CheckedExpressionProducerDefinition>,
    call_producers: BTreeMap<ExprId, arcweft_lang_sema::CheckedExpressionProducerDefinition>,
    expression_facts: BTreeMap<ExprId, RuntimeExpressionFact>,
    expression_children: BTreeMap<ExprId, Box<[ExprId]>>,
    expression_literals: BTreeMap<ExprId, RuntimeValue>,
    expression_residual_values: BTreeMap<ExprId, RuntimeResidualValue>,
    pattern_literals: BTreeMap<PatternId, RuntimeValue>,
    pattern_items:
        BTreeMap<PatternId, arcweft_lang_sema::final_analysis::CheckedEntityPatternProjection>,
    values: BTreeMap<ExprId, RuntimeResolvedValue>,
    checked_local_uses: Option<Arc<arcweft_lang_sema::final_analysis::CheckedLocalUseCatalog>>,
    selects: BTreeMap<ExprId, RuntimeResolvedSelect>,
    nominal_records: BTreeMap<ExprId, RuntimeRecordExpressionFact>,
    pattern_nominal_records: BTreeMap<PatternId, RuntimeRecordPatternFact>,
    expression_variants: BTreeMap<ExprId, RuntimeResolvedVariant>,
    pattern_variants: BTreeMap<PatternId, RuntimeResolvedVariant>,
    calls: BTreeMap<ExprId, RuntimeResolvedCall>,
    postfix_candidates: BTreeMap<ExprId, ExprId>,
    trait_methods: BTreeMap<RuntimeTraitMethodInstanceKey, RuntimeTraitMethodFact>,
    iterations: BTreeMap<StmtId, RuntimeIteratorFact>,
    assertions: BTreeMap<StmtId, RuntimeAssertionAdmission>,
    triggers: BTreeMap<StmtId, RuntimeTriggerAdmission>,
    assignments: BTreeMap<StmtId, RuntimeAssignmentFact>,
    registry_writes: BTreeMap<StmtId, RuntimeRegistryWriteFact>,
    evaluated_effects: BTreeMap<ExprId, RuntimeEvaluatedEffectFact>,
    defers: BTreeMap<StmtId, RuntimeDeferFact>,
    choices: BTreeMap<ExprId, RuntimeChoiceFact>,
    awaits: BTreeMap<ExprId, RuntimeAwaitFact>,
    tries: BTreeMap<ExprId, RuntimeTryFact>,
    implicit_callables: BTreeMap<ExprId, RuntimeImplicitCallableFact>,
    pipes: BTreeMap<ExprId, RuntimePipeFact>,
    pure_programs: BTreeMap<RuntimePureProgramId, RuntimePureProgramFact>,
    value_contract_types: Vec<RuntimeNormalizedType>,
    pure_program_semantics:
        BTreeMap<RuntimePureProgramId, RuntimeProjectFunctionInstanceSemanticFacts>,
    project_function_instances:
        BTreeMap<RuntimeProjectFunctionInstanceKey, RuntimeProjectFunctionInstanceFact>,
    root_closures: BTreeMap<ExprId, RuntimeClosureInstanceFact>,
    project_function_roots:
        BTreeMap<(ItemId, RuntimeProjectFunctionRootRole), RuntimeProjectFunctionRootFact>,
    dialogue_applications: BTreeMap<ExprId, RuntimeDialogueApplication>,
    dialogue_content_fragments: Vec<RuntimeContentFragmentFact>,
    format_templates: BTreeMap<RuntimeFormatTemplateKey, RuntimeFormatTemplateFact>,
    dialogue_lines: Option<Arc<AcceptedDialogueLineInventory>>,
    character_presentation_catalog: Option<Arc<CharacterPresentationCatalogData>>,
    character_dialogue_policy_types:
        Option<Arc<arcweft_dialogue::CharacterDialoguePolicyTypeGraph>>,
    character_dialogue_generation:
        Option<character_dialogue_generation::RuntimeCharacterDialogueGenerationFact>,
}

/// Sole executable semantic-fact view selected before lowering one body.
///
/// A closed project-function instance never falls back to the global open
/// catalog. Keeping the mode choice in this owner type prevents individual
/// expression/pattern/flow helpers from drifting into family-specific lookup
/// rules.
#[derive(Clone, Copy)]
pub enum RuntimeExecutableSemanticFactView<'facts> {
    Global(&'facts RuntimePlanSemanticFacts),
    ProjectInstance(&'facts RuntimeProjectFunctionInstanceSemanticFacts),
}

/// Exact lexical executable that owns one selected semantic-fact view.
/// Nested closures retain their own closed key instead of being collapsed to
/// the root project instance or reconstructed from a raw expression owner.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeExecutableSemanticScope<'facts> {
    Global,
    Program(RuntimePureProgramId),
    ProjectFunction(&'facts RuntimeProjectFunctionInstanceKey),
    Closure(&'facts RuntimeClosureInstanceKey),
    TraitMethod(&'facts RuntimeTraitMethodInstanceKey),
}

/// One `_` abstraction in its exact closed executable. Expression identity
/// alone is shared by monomorphized bodies and cannot identify a function
/// site or its synthetic parameter owner.
#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(crate) struct RuntimeImplicitCallableSiteKey {
    scope: RuntimeExecutableSiteScope,
    expression: ExprId,
}

#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(crate) enum RuntimeExecutableSiteScope {
    Global,
    Program(RuntimePureProgramId),
    ProjectFunction(RuntimeProjectFunctionInstanceKey),
    Closure(RuntimeClosureInstanceKey),
    TraitMethod(RuntimeTraitMethodInstanceKey),
}

impl From<RuntimeExecutableSemanticScope<'_>> for RuntimeExecutableSiteScope {
    fn from(scope: RuntimeExecutableSemanticScope<'_>) -> Self {
        match scope {
            RuntimeExecutableSemanticScope::Global => RuntimeExecutableSiteScope::Global,
            RuntimeExecutableSemanticScope::Program(program) => {
                RuntimeExecutableSiteScope::Program(program)
            }
            RuntimeExecutableSemanticScope::ProjectFunction(key) => {
                RuntimeExecutableSiteScope::ProjectFunction(key.clone())
            }
            RuntimeExecutableSemanticScope::Closure(key) => {
                RuntimeExecutableSiteScope::Closure(key.clone())
            }
            RuntimeExecutableSemanticScope::TraitMethod(key) => {
                RuntimeExecutableSiteScope::TraitMethod(key.clone())
            }
        }
    }
}

impl RuntimeImplicitCallableSiteKey {
    pub(crate) fn new(scope: RuntimeExecutableSemanticScope<'_>, expression: ExprId) -> Self {
        Self {
            scope: scope.into(),
            expression,
        }
    }
}

/// One lexical scope and the only semantic catalog valid while lowering it.
#[derive(Clone, Copy)]
pub struct RuntimeScopedExecutableSemanticFactView<'facts> {
    scope: RuntimeExecutableSemanticScope<'facts>,
    facts: RuntimeExecutableSemanticFactView<'facts>,
}

impl<'facts> RuntimeScopedExecutableSemanticFactView<'facts> {
    pub fn semantic_value_type(
        self,
        owner: HirValueTypeOwner,
    ) -> Option<&'facts arcweft_lang_sema::types::CompileTimeCallableType> {
        match self.facts {
            RuntimeExecutableSemanticFactView::ProjectInstance(facts) => {
                facts.semantic_value_type(owner)
            }
            RuntimeExecutableSemanticFactView::Global(facts) => facts.semantic_value_type(owner),
        }
    }
    pub const fn program(
        program: RuntimePureProgramId,
        facts: &'facts RuntimeProjectFunctionInstanceSemanticFacts,
    ) -> Self {
        Self {
            scope: RuntimeExecutableSemanticScope::Program(program),
            facts: RuntimeExecutableSemanticFactView::ProjectInstance(facts),
        }
    }

    pub const fn global(facts: &'facts RuntimePlanSemanticFacts) -> Self {
        Self {
            scope: RuntimeExecutableSemanticScope::Global,
            facts: RuntimeExecutableSemanticFactView::Global(facts),
        }
    }

    pub const fn project_function(
        key: &'facts RuntimeProjectFunctionInstanceKey,
        facts: &'facts RuntimeProjectFunctionInstanceSemanticFacts,
    ) -> Self {
        Self {
            scope: RuntimeExecutableSemanticScope::ProjectFunction(key),
            facts: RuntimeExecutableSemanticFactView::ProjectInstance(facts),
        }
    }

    pub const fn closure(
        key: &'facts RuntimeClosureInstanceKey,
        facts: &'facts RuntimeProjectFunctionInstanceSemanticFacts,
    ) -> Self {
        Self {
            scope: RuntimeExecutableSemanticScope::Closure(key),
            facts: RuntimeExecutableSemanticFactView::ProjectInstance(facts),
        }
    }

    pub const fn trait_method(
        key: &'facts RuntimeTraitMethodInstanceKey,
        facts: &'facts RuntimeProjectFunctionInstanceSemanticFacts,
    ) -> Self {
        Self {
            scope: RuntimeExecutableSemanticScope::TraitMethod(key),
            facts: RuntimeExecutableSemanticFactView::ProjectInstance(facts),
        }
    }

    pub const fn scope(self) -> RuntimeExecutableSemanticScope<'facts> {
        self.scope
    }

    pub const fn facts(self) -> RuntimeExecutableSemanticFactView<'facts> {
        self.facts
    }

    pub const fn is_project_instance(self) -> bool {
        self.facts.is_project_instance()
    }

    pub fn expression_type(self, owner: ExprId) -> Option<&'facts RuntimeNormalizedType> {
        self.facts.expression_type(owner)
    }
    pub fn expression_coordinate(
        self,
        owner: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::semantic_coordinate::CheckedSemanticPath> {
        self.facts.expression_coordinate(owner)
    }
    pub fn expression_specialization(
        self,
        owner: ExprId,
    ) -> Option<&'facts RuntimeCallableValueSpecialization> {
        self.facts.expression_specialization(owner)
    }
    pub fn expression_source_type(self, owner: ExprId) -> Option<&'facts RuntimeNormalizedType> {
        self.expression_specialization(owner)
            .map(RuntimeCallableValueSpecialization::source)
            .or_else(|| self.expression_type(owner))
    }

    pub fn expression_scope(
        self,
        owner: ExprId,
    ) -> Option<&'facts crate::semantic_facts::RuntimeScopeFact> {
        self.facts.expression_scope(owner)
    }

    pub fn statement_scope(
        self,
        owner: StmtId,
    ) -> Option<&'facts crate::semantic_facts::RuntimeScopeFact> {
        self.facts.statement_scope(owner)
    }

    pub fn expression_children(self, owner: ExprId) -> Option<&'facts [ExprId]> {
        self.facts.expression_children(owner)
    }

    pub fn expression_literal(self, owner: ExprId) -> Option<&'facts RuntimeValue> {
        self.facts.expression_literal(owner)
    }

    pub fn expression_variant(self, owner: ExprId) -> Option<&'facts RuntimeResolvedVariant> {
        self.facts.expression_variant(owner)
    }

    pub fn value(self, owner: ExprId) -> Option<&'facts RuntimeResolvedValue> {
        self.facts.value(owner)
    }

    pub fn call(self, owner: ExprId) -> Option<&'facts RuntimeResolvedCall> {
        self.facts.call(owner)
    }
    pub fn call_producer(
        self,
        owner: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::CheckedExpressionProducerDefinition> {
        self.facts.call_producer(owner)
    }
    pub fn thread_producer(
        self,
        owner: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::CheckedExpressionProducerDefinition> {
        self.facts.thread_producer(owner)
    }

    pub fn select(self, owner: ExprId) -> Option<&'facts RuntimeResolvedSelect> {
        self.facts.select(owner)
    }

    pub fn nominal_record(self, owner: ExprId) -> Option<&'facts RuntimeRecordExpressionFact> {
        self.facts.nominal_record(owner)
    }

    pub fn postfix_candidate(self, owner: ExprId) -> Option<ExprId> {
        self.facts.postfix_candidate(owner)
    }

    pub fn implicit_callable(self, owner: ExprId) -> Option<&'facts RuntimeImplicitCallableFact> {
        self.facts.implicit_callable(owner)
    }

    pub fn pipe(self, owner: ExprId) -> Option<&'facts RuntimePipeFact> {
        self.facts.pipe(owner)
    }

    pub fn choice(self, owner: ExprId) -> Option<&'facts RuntimeChoiceFact> {
        self.facts.choice(owner)
    }

    pub fn awaited(self, owner: ExprId) -> Option<&'facts RuntimeAwaitFact> {
        self.facts.awaited(owner)
    }

    pub fn tried(self, owner: ExprId) -> Option<&'facts RuntimeTryFact> {
        self.facts.tried(owner)
    }

    pub fn assignment(self, owner: StmtId) -> Option<&'facts RuntimeAssignmentFact> {
        self.facts.assignment(owner)
    }

    pub fn registry_write(self, owner: StmtId) -> Option<&'facts RuntimeRegistryWriteFact> {
        self.facts.registry_write(owner)
    }

    pub fn evaluated_effect(self, owner: ExprId) -> Option<&'facts RuntimeEvaluatedEffectFact> {
        self.facts.evaluated_effect(owner)
    }

    pub fn defer(self, owner: StmtId) -> Option<&'facts RuntimeDeferFact> {
        self.facts.defer(owner)
    }

    pub fn iteration(self, owner: StmtId) -> Option<&'facts RuntimeIteratorFact> {
        self.facts.iteration(owner)
    }

    pub fn assertion(self, owner: StmtId) -> Option<RuntimeAssertionAdmission> {
        self.facts.assertion(owner)
    }

    pub fn trigger(self, owner: StmtId) -> Option<&'facts RuntimeTriggerAdmission> {
        self.facts.trigger(owner)
    }

    pub fn local_type(self, owner: LocalId) -> Option<&'facts RuntimeNormalizedType> {
        self.facts.local_type(owner)
    }

    pub fn local_origin(
        self,
        owner: LocalId,
    ) -> Option<&'facts arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin> {
        self.facts.local_origin(owner)
    }

    pub fn checked_local_value_transfer(
        self,
        site: arcweft_lang_sema::final_analysis::CheckedLocalUseSite,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer> {
        self.facts.checked_local_value_transfer(site)
    }

    pub fn checked_local_place_access(
        self,
        source: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedLocalPlaceAccess> {
        self.facts.checked_local_place_access(source)
    }

    pub fn checked_guard_copy_locals(self, guard: ExprId) -> Vec<LocalId> {
        self.facts.checked_guard_copy_locals(guard)
    }

    pub fn checked_synthetic_use(
        self,
        expression: ExprId,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedSyntheticUse> {
        self.facts.checked_synthetic_use(expression)
    }

    pub fn checked_captures_at(
        self,
        owner: ExprId,
    ) -> Vec<arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer> {
        self.facts.checked_captures_at(owner)
    }

    pub fn checked_copy_requirement(
        self,
        local: LocalId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedLocalCopyRequirement> {
        self.facts.checked_copy_requirement(local)
    }

    pub fn checked_synthetic_copy_requirement(
        self,
        callable: arcweft_lang_sema::final_analysis::CheckedImplicitCallableIdentity,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedSyntheticCopyRequirement> {
        self.facts.checked_synthetic_copy_requirement(callable)
    }

    pub fn dialogue_application(self, owner: ExprId) -> Option<&'facts RuntimeDialogueApplication> {
        self.facts.dialogue_application(owner)
    }

    pub fn dialogue_content_fragment_for_source(
        self,
        source: ExprId,
    ) -> Option<&'facts RuntimeContentFragmentFact> {
        self.facts.dialogue_content_fragment_for_source(source)
    }

    pub fn closure_instance(self, owner: ExprId) -> Option<&'facts RuntimeClosureInstanceFact> {
        self.facts.closure_instance(owner)
    }
}

impl<'facts> RuntimeExecutableSemanticFactView<'facts> {
    pub fn checked_local_place_access(
        self,
        source: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedLocalPlaceAccess> {
        match self {
            Self::Global(facts) => facts.checked_local_place_access(source),
            Self::ProjectInstance(facts) => facts.local_uses().place_access_at(source),
        }
    }

    pub fn suspension(
        self,
        owner: StmtId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedSuspensionStatement> {
        match self {
            Self::Global(facts) => facts.suspensions.get(&owner),
            Self::ProjectInstance(facts) => {
                facts.statement(owner).and_then(|row| match row.payload() {
                    RuntimeProjectFunctionStatementPayload::Suspension(suspension) => {
                        Some(suspension)
                    }
                    _ => None,
                })
            }
        }
    }
    pub fn checked_local_value_transfer(
        self,
        site: arcweft_lang_sema::final_analysis::CheckedLocalUseSite,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer> {
        match self {
            Self::Global(facts) => facts.checked_local_value_transfer(site),
            Self::ProjectInstance(facts) => facts.local_uses().value_transfer_at(site),
        }
    }

    pub(crate) fn is_pattern_guard(self, guard: ExprId) -> bool {
        match self {
            Self::Global(facts) => facts
                .checked_local_uses
                .as_ref()
                .is_some_and(|catalog| catalog.is_pattern_guard(guard)),
            Self::ProjectInstance(facts) => facts.local_uses().is_pattern_guard(guard),
        }
    }

    pub fn checked_guard_copy_locals(self, guard: ExprId) -> Vec<LocalId> {
        match self {
            Self::Global(facts) => facts.checked_guard_copy_locals(guard),
            Self::ProjectInstance(facts) => facts.local_uses().guard_copy_locals(guard),
        }
    }

    pub fn checked_synthetic_use(
        self,
        expression: ExprId,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedSyntheticUse> {
        match self {
            Self::Global(facts) => facts.checked_synthetic_use(expression),
            Self::ProjectInstance(facts) => facts.local_uses().synthetic_at(expression),
        }
    }

    pub fn checked_captures_at(
        self,
        owner: ExprId,
    ) -> Vec<arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer> {
        match self {
            Self::Global(facts) => facts.checked_captures_at(owner).collect(),
            Self::ProjectInstance(facts) => facts.local_uses().captures_at(owner),
        }
    }

    pub fn checked_copy_requirement(
        self,
        local: LocalId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedLocalCopyRequirement> {
        match self {
            Self::Global(facts) => facts.checked_copy_requirement(local),
            Self::ProjectInstance(facts) => facts.local_uses().copy_requirement(local),
        }
    }

    pub fn checked_synthetic_copy_requirement(
        self,
        callable: arcweft_lang_sema::final_analysis::CheckedImplicitCallableIdentity,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedSyntheticCopyRequirement> {
        match self {
            Self::Global(facts) => facts.checked_synthetic_copy_requirement(callable),
            Self::ProjectInstance(facts) => facts.local_uses().synthetic_copy_requirement(callable),
        }
    }

    pub(crate) fn visit_scope_continuations(
        self,
        visitor: &mut impl FnMut(RuntimeScopeOwner, &'facts RuntimeScopeContinuation),
    ) {
        match self {
            Self::Global(facts) => {
                for (owner, fact) in &facts.expression_scopes {
                    if let Some(continuation) = fact.continuation() {
                        visitor(RuntimeScopeOwner::Expression(*owner), continuation);
                    }
                }
                for (owner, fact) in &facts.statement_scopes {
                    if let Some(continuation) = fact.continuation() {
                        visitor(RuntimeScopeOwner::Statement(*owner), continuation);
                    }
                }
            }
            Self::ProjectInstance(facts) => {
                for row in facts.expressions() {
                    if let RuntimeProjectFunctionExpressionPayload::Scope(fact) = row.payload()
                        && let Some(continuation) = fact.continuation()
                    {
                        visitor(RuntimeScopeOwner::Expression(row.owner()), continuation);
                    }
                }
                for row in facts.statements() {
                    if let RuntimeProjectFunctionStatementPayload::Scope(fact) = row.payload()
                        && let Some(continuation) = fact.continuation()
                    {
                        visitor(RuntimeScopeOwner::Statement(row.owner()), continuation);
                    }
                }
            }
        }
    }

    pub(crate) fn visit_expression_owners(self, visitor: &mut impl FnMut(ExprId)) {
        match self {
            Self::Global(facts) => {
                for owner in facts.expression_children.keys() {
                    visitor(*owner);
                }
            }
            Self::ProjectInstance(facts) => {
                for expression in facts.expressions() {
                    visitor(expression.owner());
                }
            }
        }
    }

    pub(crate) fn visit_runtime_expression_types(
        self,
        visitor: &mut impl FnMut(ExprId, &'facts RuntimeNormalizedType),
    ) {
        match self {
            Self::Global(facts) => {
                for (owner, projection) in &facts.type_projections {
                    if let HirValueTypeOwner::Expression(owner) = owner
                        && let Some(ty) = projection.ty()
                    {
                        visitor(*owner, ty);
                    }
                }
            }
            Self::ProjectInstance(facts) => {
                for projection in facts.type_projection() {
                    if let RuntimeExecutableTypeProjection::Value {
                        owner: HirValueTypeOwner::Expression(owner),
                        ty,
                    } = projection
                    {
                        visitor(*owner, ty);
                    }
                }
            }
        }
    }

    pub(crate) fn visit_untyped_evaluated_effect_pipes(
        self,
        visitor: &mut impl FnMut(ExprId, &'facts RuntimePipeFact),
    ) {
        match self {
            Self::Global(facts) => {
                for owner in facts.evaluated_effects.keys() {
                    if facts.expression_type(*owner).is_none()
                        && let Some(pipe) = facts.pipe(*owner)
                    {
                        visitor(*owner, pipe);
                    }
                }
            }
            Self::ProjectInstance(facts) => {
                for row in facts.expressions() {
                    if facts.expression_type(row.owner()).is_none()
                        && let RuntimeProjectFunctionExpressionPayload::EvaluatedEffect {
                            pipe: Some(pipe),
                            ..
                        } = row.payload()
                    {
                        visitor(row.owner(), pipe);
                    }
                }
            }
        }
    }

    pub const fn global(facts: &'facts RuntimePlanSemanticFacts) -> Self {
        Self::Global(facts)
    }

    pub const fn project_instance(
        facts: &'facts RuntimeProjectFunctionInstanceSemanticFacts,
    ) -> Self {
        Self::ProjectInstance(facts)
    }

    pub const fn is_project_instance(self) -> bool {
        matches!(self, Self::ProjectInstance(_))
    }

    pub fn expression_type(self, owner: ExprId) -> Option<&'facts RuntimeNormalizedType> {
        match self {
            Self::Global(facts) => facts.expression_type(owner),
            Self::ProjectInstance(facts) => facts.expression_type(owner),
        }
    }
    pub fn expression_coordinate(
        self,
        owner: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::semantic_coordinate::CheckedSemanticPath> {
        match self {
            Self::Global(facts) => facts.expression_coordinate(owner),
            Self::ProjectInstance(facts) => facts.expression_coordinate(owner),
        }
    }
    pub fn expression_specialization(
        self,
        owner: ExprId,
    ) -> Option<&'facts RuntimeCallableValueSpecialization> {
        match self {
            Self::Global(facts) => facts.expression_specialization(owner),
            Self::ProjectInstance(facts) => facts.expression_specialization(owner),
        }
    }
    pub fn expression_source_type(self, owner: ExprId) -> Option<&'facts RuntimeNormalizedType> {
        self.expression_specialization(owner)
            .map(RuntimeCallableValueSpecialization::source)
            .or_else(|| self.expression_type(owner))
    }

    pub fn expression_scope(
        self,
        owner: ExprId,
    ) -> Option<&'facts crate::semantic_facts::RuntimeScopeFact> {
        match self {
            Self::Global(facts) => facts.expression_scopes.get(&owner),
            Self::ProjectInstance(facts) => facts.expression_scope(owner),
        }
    }

    pub fn include(
        self,
        owner: StmtId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedIncludeFlowTarget> {
        match self {
            Self::Global(facts) => facts.includes.get(&owner),
            Self::ProjectInstance(facts) => {
                facts.statement(owner).and_then(|row| match row.payload() {
                    RuntimeProjectFunctionStatementPayload::Include(target) => Some(target),
                    _ => None,
                })
            }
        }
    }

    pub fn statement_scope(
        self,
        owner: StmtId,
    ) -> Option<&'facts crate::semantic_facts::RuntimeScopeFact> {
        match self {
            Self::Global(facts) => facts.statement_scopes.get(&owner),
            Self::ProjectInstance(facts) => facts.statement_scope(owner),
        }
    }

    pub fn pattern_type(self, owner: PatternId) -> Option<&'facts RuntimeNormalizedType> {
        match self {
            Self::Global(facts) => facts.pattern_type(owner),
            Self::ProjectInstance(facts) => facts.pattern_type(owner),
        }
    }

    pub(crate) fn visit_local_declarations(
        self,
        visitor: &mut impl FnMut(
            LocalId,
            &'facts RuntimeNormalizedType,
            &'facts arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin,
            Option<&'facts RuntimeNormalizedType>,
        ),
    ) {
        match self {
            Self::Global(facts) => {
                for local in &facts.local_declaration_order {
                    let fact = facts
                        .type_projections
                        .get(&HirValueTypeOwner::Local(*local))
                        .expect("accepted local order and fact map remain correlated");
                    visitor(
                        *local,
                        fact.ty().expect("runtime local type"),
                        fact.local_origin().expect("runtime local origin"),
                        fact.local_context(),
                    );
                }
            }
            Self::ProjectInstance(facts) => {
                for projection in facts.type_projection() {
                    if let RuntimeExecutableTypeProjection::Local {
                        owner,
                        ty,
                        origin,
                        context,
                    } = projection
                    {
                        visitor(*owner, ty, origin, context.as_ref());
                    }
                }
            }
        }
    }

    pub fn local_type(self, owner: LocalId) -> Option<&'facts RuntimeNormalizedType> {
        match self {
            Self::Global(facts) => facts.local_type(owner),
            Self::ProjectInstance(facts) => facts.local_type(owner),
        }
    }

    pub fn local_origin(
        self,
        owner: LocalId,
    ) -> Option<&'facts arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin> {
        match self {
            Self::Global(facts) => facts.local_origin(owner),
            Self::ProjectInstance(facts) => facts.local_origin(owner),
        }
    }

    pub fn ty(self, owner: TypeId) -> Option<&'facts RuntimeNormalizedType> {
        match self {
            Self::Global(facts) => facts.ty(owner),
            Self::ProjectInstance(facts) => facts.source_type(owner),
        }
    }

    /// Returns `None` only when `owner` is absent from the selected catalog.
    /// A present leaf expression returns `Some(&[])`.
    pub fn expression_children(self, owner: ExprId) -> Option<&'facts [ExprId]> {
        match self {
            Self::Global(facts) => facts
                .expression_children
                .get(&owner)
                .map(|children| children.as_ref()),
            Self::ProjectInstance(facts) => facts.expression_children(owner),
        }
    }

    pub fn expression_literal(self, owner: ExprId) -> Option<&'facts RuntimeValue> {
        match self {
            Self::Global(facts) => facts.expression_literal(owner),
            Self::ProjectInstance(facts) => facts.expression_literal(owner),
        }
    }

    pub fn pattern_literal(self, owner: PatternId) -> Option<&'facts RuntimeValue> {
        match self {
            Self::Global(facts) => facts.pattern_literal(owner),
            Self::ProjectInstance(facts) => facts.pattern_literal(owner),
        }
    }

    pub fn pattern_entity(
        self,
        owner: PatternId,
    ) -> Option<&'facts arcweft_lang_sema::final_analysis::CheckedEntityPatternProjection> {
        match self {
            Self::Global(facts) => facts.pattern_entity(owner),
            Self::ProjectInstance(facts) => facts.pattern_entity(owner),
        }
    }

    pub fn value(self, owner: ExprId) -> Option<&'facts RuntimeResolvedValue> {
        match self {
            Self::Global(facts) => facts.value(owner),
            Self::ProjectInstance(facts) => facts.value(owner),
        }
    }

    pub fn select(self, owner: ExprId) -> Option<&'facts RuntimeResolvedSelect> {
        match self {
            Self::Global(facts) => facts.select(owner),
            Self::ProjectInstance(facts) => facts.select(owner),
        }
    }

    pub fn nominal_record(self, owner: ExprId) -> Option<&'facts RuntimeRecordExpressionFact> {
        match self {
            Self::Global(facts) => facts.nominal_record(owner),
            Self::ProjectInstance(facts) => facts.nominal_record(owner),
        }
    }

    pub fn pattern_nominal_record(
        self,
        owner: PatternId,
    ) -> Option<&'facts RuntimeRecordPatternFact> {
        match self {
            Self::Global(facts) => facts.pattern_nominal_record(owner),
            Self::ProjectInstance(facts) => facts.pattern_nominal_record(owner),
        }
    }

    pub fn expression_variant(self, owner: ExprId) -> Option<&'facts RuntimeResolvedVariant> {
        match self {
            Self::Global(facts) => facts.expression_variant(owner),
            Self::ProjectInstance(facts) => facts.expression_variant(owner),
        }
    }

    pub fn pattern_variant(self, owner: PatternId) -> Option<&'facts RuntimeResolvedVariant> {
        match self {
            Self::Global(facts) => facts.pattern_variant(owner),
            Self::ProjectInstance(facts) => facts.pattern_variant(owner),
        }
    }

    pub fn call_producer(
        self,
        owner: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::CheckedExpressionProducerDefinition> {
        match self {
            Self::Global(facts) => facts.call_producer(owner),
            Self::ProjectInstance(facts) => facts.producer(owner).filter(|producer| {
                producer.kind() == arcweft_lang_sema::CheckedExpressionProducerKind::Call
            }),
        }
    }
    pub fn thread_producer(
        self,
        owner: ExprId,
    ) -> Option<&'facts arcweft_lang_sema::CheckedExpressionProducerDefinition> {
        match self {
            Self::Global(facts) => facts.thread_producer(owner),
            Self::ProjectInstance(facts) => facts.producer(owner).filter(|producer| {
                producer.kind() == arcweft_lang_sema::CheckedExpressionProducerKind::Thread
            }),
        }
    }
    pub fn call(self, owner: ExprId) -> Option<&'facts RuntimeResolvedCall> {
        match self {
            Self::Global(facts) => facts.call(owner),
            Self::ProjectInstance(facts) => facts.call(owner),
        }
    }

    pub fn postfix_candidate(self, owner: ExprId) -> Option<ExprId> {
        match self {
            Self::Global(facts) => facts.postfix_candidate(owner),
            Self::ProjectInstance(facts) => facts.postfix_candidate(owner),
        }
    }

    pub fn iteration(self, owner: StmtId) -> Option<&'facts RuntimeIteratorFact> {
        match self {
            Self::Global(facts) => facts.iteration(owner),
            Self::ProjectInstance(facts) => facts.iteration(owner),
        }
    }

    pub fn assertion(self, owner: StmtId) -> Option<RuntimeAssertionAdmission> {
        match self {
            Self::Global(facts) => facts.assertion(owner),
            Self::ProjectInstance(facts) => facts.assertion(owner),
        }
    }

    pub fn trigger(self, owner: StmtId) -> Option<&'facts RuntimeTriggerAdmission> {
        match self {
            Self::Global(facts) => facts.trigger(owner),
            Self::ProjectInstance(facts) => facts.trigger(owner),
        }
    }

    pub fn assignment(self, owner: StmtId) -> Option<&'facts RuntimeAssignmentFact> {
        match self {
            Self::Global(facts) => facts.assignment(owner),
            Self::ProjectInstance(facts) => facts.assignment(owner),
        }
    }

    pub fn registry_write(self, owner: StmtId) -> Option<&'facts RuntimeRegistryWriteFact> {
        match self {
            Self::Global(facts) => facts.registry_write(owner),
            Self::ProjectInstance(facts) => facts.registry_write(owner),
        }
    }

    pub fn evaluated_effect(self, owner: ExprId) -> Option<&'facts RuntimeEvaluatedEffectFact> {
        match self {
            Self::Global(facts) => facts.evaluated_effect(owner),
            Self::ProjectInstance(facts) => facts.evaluated_effect(owner),
        }
    }

    pub fn defer(self, owner: StmtId) -> Option<&'facts RuntimeDeferFact> {
        match self {
            Self::Global(facts) => facts.defer(owner),
            Self::ProjectInstance(facts) => facts.defer(owner),
        }
    }

    pub fn awaited(self, owner: ExprId) -> Option<&'facts RuntimeAwaitFact> {
        match self {
            Self::Global(facts) => facts.awaited(owner),
            Self::ProjectInstance(facts) => facts.awaited(owner),
        }
    }

    pub fn choice(self, owner: ExprId) -> Option<&'facts RuntimeChoiceFact> {
        match self {
            Self::Global(facts) => facts.choice(owner),
            Self::ProjectInstance(facts) => facts.choice(owner),
        }
    }

    pub fn tried(self, owner: ExprId) -> Option<&'facts RuntimeTryFact> {
        match self {
            Self::Global(facts) => facts.tried(owner),
            Self::ProjectInstance(facts) => facts.tried(owner),
        }
    }

    pub fn implicit_callable(self, owner: ExprId) -> Option<&'facts RuntimeImplicitCallableFact> {
        match self {
            Self::Global(facts) => facts.implicit_callable(owner),
            Self::ProjectInstance(facts) => facts.implicit_callable(owner),
        }
    }

    pub fn pipe(self, owner: ExprId) -> Option<&'facts RuntimePipeFact> {
        match self {
            Self::Global(facts) => facts.pipe(owner),
            Self::ProjectInstance(facts) => facts.pipe(owner),
        }
    }

    pub fn capture(self, owner: CaptureId) -> Option<&'facts RuntimeCheckedCapture> {
        match self {
            Self::Global(facts) => facts.capture(owner),
            Self::ProjectInstance(facts) => facts.capture(owner),
        }
    }

    pub fn dialogue_application(self, owner: ExprId) -> Option<&'facts RuntimeDialogueApplication> {
        match self {
            Self::Global(facts) => facts.dialogue_application(owner),
            Self::ProjectInstance(facts) => facts.dialogue_application(owner),
        }
    }

    /// Selects a closed closure only from a closed project-instance catalog.
    /// Returning `None` in global mode is intentional: ordinary global
    /// closures use the generation-global FunctionSite authority instead.
    pub fn closure_instance(self, owner: ExprId) -> Option<&'facts RuntimeClosureInstanceFact> {
        match self {
            Self::Global(facts) => facts.root_closure(owner),
            Self::ProjectInstance(facts) => facts.closure_instance(owner),
        }
    }

    pub fn dialogue_content_fragment_for_source(
        self,
        source: ExprId,
    ) -> Option<&'facts RuntimeContentFragmentFact> {
        match self {
            Self::Global(facts) => facts.dialogue_content_fragment_for_source(source),
            Self::ProjectInstance(facts) => facts.dialogue_content_fragment_for_source(source),
        }
    }
}

#[derive(Clone, Copy)]
struct RuntimeSemanticOwnerSet<'a> {
    runtime: &'a HirRuntimeSemanticReachability<'a>,
    programs: Option<&'a HirRuntimeSemanticReachability<'a>>,
    program_free_locals: Option<&'a BTreeSet<LocalId>>,
}

/// Borrowed complete executable catalogs. Every consumer keeps the root's
/// exact lexical scope while visiting its nested closure catalogs.
fn instance_semantic_roots<'facts>(
    functions: impl Iterator<Item = &'facts RuntimeProjectFunctionInstanceFact> + 'facts,
    closures: impl Iterator<Item = &'facts RuntimeClosureInstanceFact> + 'facts,
    methods: impl Iterator<Item = &'facts RuntimeTraitMethodFact> + 'facts,
    programs: impl Iterator<
        Item = (
            RuntimePureProgramId,
            &'facts RuntimeProjectFunctionInstanceSemanticFacts,
        ),
    > + 'facts,
) -> impl Iterator<
    Item = (
        RuntimeScopedExecutableSemanticFactView<'facts>,
        &'facts RuntimeProjectFunctionInstanceSemanticFacts,
    ),
> + 'facts {
    functions
        .map(|instance| {
            (
                RuntimeScopedExecutableSemanticFactView::project_function(
                    instance.key(),
                    instance.semantics(),
                ),
                instance.semantics(),
            )
        })
        .chain(closures.map(|closure| {
            (
                RuntimeScopedExecutableSemanticFactView::closure(
                    closure.key(),
                    closure.semantics(),
                ),
                closure.semantics(),
            )
        }))
        .chain(methods.filter_map(|method| {
            let semantics = method.closed_semantics()?;
            Some((
                RuntimeScopedExecutableSemanticFactView::trait_method(method.key(), semantics),
                semantics,
            ))
        }))
        .chain(programs.map(|(program, semantics)| {
            (
                RuntimeScopedExecutableSemanticFactView::program(program, semantics),
                semantics,
            )
        }))
}

impl<'a> RuntimeSemanticOwnerSet<'a> {
    fn admits_reachability(self, identity: &HirRuntimeReachabilityIdentity) -> bool {
        self.runtime.identity() == identity
            || self
                .programs
                .is_some_and(|owners| owners.identity() == identity)
    }

    const fn runtime_only(runtime: &'a HirRuntimeSemanticReachability<'a>) -> Self {
        Self {
            runtime,
            programs: None,
            program_free_locals: None,
        }
    }

    const fn with_programs(
        runtime: &'a HirRuntimeSemanticReachability<'a>,
        programs: &'a HirRuntimeSemanticReachability<'a>,
        program_free_locals: &'a BTreeSet<LocalId>,
    ) -> Self {
        Self {
            runtime,
            programs: Some(programs),
            program_free_locals: Some(program_free_locals),
        }
    }

    fn contains_expression(self, owner: ExprId) -> bool {
        self.runtime.contains_expression(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_expression(owner))
    }

    fn contains_pattern(self, owner: PatternId) -> bool {
        self.runtime.contains_pattern(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_pattern(owner))
    }

    fn contains_statement(self, owner: StmtId) -> bool {
        self.runtime.contains_statement(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_statement(owner))
    }

    fn contains_type(self, owner: TypeId) -> bool {
        self.runtime.contains_type(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_type(owner))
    }

    fn contains_local(self, owner: LocalId) -> bool {
        self.runtime.contains_local(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_local(owner))
            || self
                .program_free_locals
                .is_some_and(|locals| locals.contains(&owner))
    }

    fn contains_capture(self, owner: CaptureId) -> bool {
        self.runtime.contains_capture(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_capture(owner))
    }

    fn contains_runtime_owner(self, owner: &HirRuntimeExecutableOwner) -> bool {
        self.runtime.contains_runtime_owner(owner)
            || self
                .programs
                .is_some_and(|owners| owners.contains_runtime_owner(owner))
    }

    fn executable_owners(
        self,
        owner: &HirRuntimeExecutableOwner,
    ) -> Option<&'a arcweft_lang_hir::project::HirRuntimeExecutableSemanticOwners> {
        self.runtime.executable_owners(owner).or_else(|| {
            self.programs
                .and_then(|owners| owners.executable_owners(owner))
        })
    }

    fn expressions(self) -> BTreeSet<ExprId> {
        self.runtime
            .expressions()
            .chain(
                self.programs
                    .into_iter()
                    .flat_map(HirRuntimeSemanticReachability::expressions),
            )
            .collect()
    }

    fn locals(self) -> BTreeSet<LocalId> {
        self.runtime
            .locals()
            .chain(self.programs.into_iter().flat_map(|owners| owners.locals()))
            .chain(
                self.program_free_locals
                    .into_iter()
                    .flat_map(|locals| locals.iter().copied()),
            )
            .collect()
    }

    fn reachable_executables(self) -> BTreeSet<HirRuntimeExecutableOwner> {
        self.runtime
            .reachable_executables()
            .chain(
                self.programs
                    .into_iter()
                    .flat_map(HirRuntimeSemanticReachability::reachable_executables),
            )
            .cloned()
            .collect()
    }

    fn edges_from(
        self,
        source: HirRuntimeReachabilitySite,
    ) -> impl Iterator<Item = &'a HirRuntimeReachabilityEdge> + 'a {
        self.runtime.edge_from(source).chain(
            self.programs
                .into_iter()
                .flat_map(move |owners| owners.edge_from(source)),
        )
    }

    fn selected_expression_type_owners(
        self,
    ) -> Result<BTreeSet<ExprId>, RuntimeSemanticFactsError> {
        let mut owners = self
            .runtime
            .selected_expression_type_owners()
            .map_err(|error| {
                RuntimeSemanticFactsError::RuntimeReachability(HirRuntimeReachabilityError::from(
                    error,
                ))
            })?;
        if let Some(programs) = self.programs {
            owners.extend(
                programs
                    .selected_expression_type_owners()
                    .map_err(|error| {
                        RuntimeSemanticFactsError::RuntimeReachability(
                            HirRuntimeReachabilityError::from(error),
                        )
                    })?,
            );
        }
        Ok(owners)
    }

    fn selected_expression_children(
        self,
    ) -> Result<BTreeMap<ExprId, Box<[ExprId]>>, RuntimeSemanticFactsError> {
        let mut children: BTreeMap<ExprId, Box<[ExprId]>> = BTreeMap::new();
        // Each lexical partition owns the runtime child relation, including
        // an empty row for a closure value whose body executes in another
        // partition. The aggregate structural edge map omits those value rows.
        for reachability in std::iter::once(self.runtime).chain(self.programs) {
            for executable in reachability.reachable_executables() {
                let owners = reachability
                    .executable_owners(executable)
                    .ok_or(RuntimeSemanticFactsError::ReachabilityMismatch)?;
                for owner in owners.expressions() {
                    let row = owners.expression_children(owner);
                    if children
                        .insert(owner, Box::from(row))
                        .is_some_and(|previous| previous.as_ref() != row)
                    {
                        return Err(RuntimeSemanticFactsError::ReachabilityMismatch);
                    }
                }
            }
        }
        Ok(children)
    }

    fn patterns(self) -> BTreeSet<PatternId> {
        self.runtime
            .patterns()
            .chain(
                self.programs
                    .into_iter()
                    .flat_map(HirRuntimeSemanticReachability::patterns),
            )
            .collect()
    }
}

impl RuntimePlanSemanticFacts {
    pub const fn reachability(&self) -> &HirRuntimeReachabilityIdentity {
        &self.reachability
    }

    /// Reports whether one executable owner was admitted by the sole checked
    /// reachability closure used to construct these facts.
    pub fn contains_runtime_owner(&self, owner: &HirRuntimeExecutableOwner) -> bool {
        self.runtime_owners.contains(owner)
    }

    /// Validates every staged fact against the exact accepted executable module leases.
    #[allow(
        clippy::too_many_lines,
        reason = "fact publication validates every family and cross-owner identity in one all-or-nothing accepted-generation transaction"
    )]
    pub fn try_new(
        project: HirAnalysisProjectView<'_>,
        runtime_owners: &HirRuntimeSemanticReachability<'_>,
        input: RuntimePlanSemanticFactInput,
    ) -> Result<Self, RuntimeSemanticFactsError> {
        Self::try_new_with_owner_set(
            project,
            RuntimeSemanticOwnerSet::runtime_only(runtime_owners),
            input,
        )
    }

    pub fn try_new_with_programs(
        project: HirAnalysisProjectView<'_>,
        runtime_owners: &HirRuntimeSemanticReachability<'_>,
        program_owners: &HirRuntimeSemanticReachability<'_>,
        input: RuntimePlanSemanticFactInput,
    ) -> Result<Self, RuntimeSemanticFactsError> {
        if runtime_owners
            .roots()
            .any(|root| root.kind() == HirRuntimeReachabilityRootKind::CheckedProgram)
            || program_owners
                .roots()
                .any(|root| root.kind() != HirRuntimeReachabilityRootKind::CheckedProgram)
        {
            return Err(RuntimeSemanticFactsError::ReachabilityMismatch);
        }
        let program_free_locals = input
            .pure_programs
            .iter()
            .flat_map(|program| {
                program
                    .free_inputs()
                    .map(|(input, _)| input.binding().local())
            })
            .collect::<BTreeSet<_>>();
        Self::try_new_with_owner_set(
            project,
            RuntimeSemanticOwnerSet::with_programs(
                runtime_owners,
                program_owners,
                &program_free_locals,
            ),
            input,
        )
    }

    fn try_new_with_owner_set(
        project: HirAnalysisProjectView<'_>,
        runtime_owners: RuntimeSemanticOwnerSet<'_>,
        input: RuntimePlanSemanticFactInput,
    ) -> Result<Self, RuntimeSemanticFactsError> {
        let supplied_snapshots = project
            .modules()
            .map(|(_, module)| (module.module_id(), module.snapshot_id()))
            .collect::<Box<[_]>>();
        if supplied_snapshots.as_ref() != runtime_owners.runtime.identity().module_snapshots()
            || runtime_owners.programs.is_some_and(|owners| {
                supplied_snapshots.as_ref() != owners.identity().module_snapshots()
                    || owners.identity().symbol_world()
                        != runtime_owners.runtime.identity().symbol_world()
                    || owners.identity().symbol_revision()
                        != runtime_owners.runtime.identity().symbol_revision()
            })
        {
            return Err(RuntimeSemanticFactsError::ReachabilityMismatch);
        }
        let modules = project
            .modules()
            .map(|(_, module)| (module.module_id(), module.as_ref()))
            .collect::<BTreeMap<_, _>>();
        let snapshots = modules
            .iter()
            .map(|(id, module)| (*id, module.snapshot_id()))
            .collect();

        let pure_program_semantics = collect_unique(
            input.pure_program_semantics.into_iter(),
            RuntimeSemanticFactFamily::PureProgram,
        )?;
        if pure_program_semantics.len() != input.pure_programs.len() {
            return Err(RuntimeSemanticFactsError::ReachabilityMismatch);
        }
        for program in &input.pure_programs {
            let semantics = pure_program_semantics.get(&program.program()).ok_or(
                RuntimeSemanticFactsError::InvalidPureProgram {
                    program: program.program(),
                },
            )?;
            let abi = program.admission().input_abi();
            if semantics.partition().executable() != &program.reachability_owner()
                || !runtime_owners
                    .programs
                    .is_some_and(|owners| owners.identity() == semantics.partition().reachability())
                || semantics.local_uses() != abi.environment().local_uses()
            {
                return Err(RuntimeSemanticFactsError::InvalidPureProgram {
                    program: program.program(),
                });
            }
        }

        let project_function_instances = collect_unique(
            input
                .project_function_instances
                .into_iter()
                .map(|instance| (instance.key().clone(), instance)),
            RuntimeSemanticFactFamily::ProjectFunctionInstance,
        )?;
        for instance in project_function_instances.values() {
            let catalog = instance.semantics().local_uses();
            if catalog
                .generation()
                .validate_analysis_lease(project)
                .is_err()
                || catalog.generation().symbol_world()
                    != runtime_owners.runtime.identity().symbol_world()
                || catalog.generation().symbol_revision()
                    != runtime_owners.runtime.identity().symbol_revision()
                || !matches!(
                    catalog.instance_identity(),
                    Some(arcweft_lang_sema::final_analysis::CheckedLocalUseInstanceIdentity::ProjectFunction {
                        declaration,
                        instantiation,
                    }) if declaration == instance.callable().declaration()
                        && *instantiation == instance.key().instantiation()
                )
            {
                return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
            }
            validate_project_function_instance(&modules, runtime_owners, instance)?;
        }
        let root_closures = collect_unique(
            input
                .root_closures
                .into_iter()
                .map(|closure| (closure.owner(), closure)),
            RuntimeSemanticFactFamily::ClosureInstance,
        )?;
        if root_closures
            .values()
            .any(|closure| closure.key().enclosing_owner().is_some())
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
        let project_function_roots = collect_unique(
            input
                .project_function_roots
                .into_iter()
                .map(|root| ((root.entry(), root.role()), root)),
            RuntimeSemanticFactFamily::ProjectFunctionRoot,
        )?;
        let mut root_instances_by_callable = BTreeMap::new();
        for root in project_function_roots.values() {
            validate_project_function_root(
                &modules,
                runtime_owners,
                &project_function_instances,
                root,
            )?;
            match root_instances_by_callable
                .insert(root.instance().callable().clone(), root.instance().clone())
            {
                Some(previous) if previous != *root.instance() => {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionRoot);
                }
                Some(_) | None => {}
            }
        }
        let mut instance_expression_owners = BTreeSet::new();
        let mut instance_pattern_owners = BTreeSet::new();
        let mut instance_local_owners = BTreeSet::new();
        let mut instance_type_owners = BTreeSet::new();
        let mut instance_capture_owners = BTreeSet::new();
        let mut instance_statement_owners = BTreeSet::new();
        for (scope, semantics) in instance_semantic_roots(
            project_function_instances.values(),
            root_closures.values(),
            input.trait_methods.iter(),
            pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            let program_scope = matches!(scope.scope(), RuntimeExecutableSemanticScope::Program(_));
            semantics.visit_type_projections(&mut |projection| match projection.owner() {
                HirValueTypeOwner::Expression(owner) => {
                    if !program_scope || !runtime_owners.runtime.contains_expression(owner) {
                        instance_expression_owners.insert(owner);
                    }
                }
                HirValueTypeOwner::Pattern(owner) => {
                    if !program_scope || !runtime_owners.runtime.contains_pattern(owner) {
                        instance_pattern_owners.insert(owner);
                    }
                }
                HirValueTypeOwner::Local(owner) => {
                    if !program_scope
                        || (!runtime_owners.runtime.contains_local(owner)
                            && !semantics.partition().input_locals().contains(&owner))
                    {
                        instance_local_owners.insert(owner);
                    }
                }
                HirValueTypeOwner::Type(owner) => {
                    if !program_scope || !runtime_owners.runtime.contains_type(owner) {
                        instance_type_owners.insert(owner);
                    }
                }
                HirValueTypeOwner::Capture(owner) => {
                    if !program_scope || !runtime_owners.runtime.contains_capture(owner) {
                        instance_capture_owners.insert(owner);
                    }
                }
            });
            semantics.visit_statement_owners(&mut |owner| {
                if !program_scope || !runtime_owners.runtime.contains_statement(owner) {
                    instance_statement_owners.insert(owner);
                }
            });
        }
        let expected_local_declarations = runtime_owners
            .locals()
            .into_iter()
            .filter(|owner| !instance_local_owners.contains(owner))
            .collect::<Vec<_>>();

        let callable_sources = callable_specialization::admit_sources(input.callable_sources)?;
        let callable_specializations = callable_specialization::admit_specializations(
            input.callable_specializations,
            &callable_sources,
            &project_function_instances,
        )?;
        for source in callable_sources.values() {
            validate_callable(&modules, source.callable())?;
            let mut types = Vec::new();
            source.append_normalized_types(&mut types);
            for ty in types {
                validate_normalized_type(&modules, ty)?;
            }
        }
        for specialization in callable_specializations.values() {
            let mut types = Vec::new();
            specialization.append_normalized_types(&mut types);
            for ty in types {
                validate_normalized_type(&modules, ty)?;
            }
        }
        let thread_producers = collect_unique(
            input.thread_producers,
            RuntimeSemanticFactFamily::ThreadProducer,
        )?;
        for (owner, definition) in &thread_producers {
            let authority = input
                .checked_local_uses
                .as_ref()
                .map(|catalog| CheckedLocalUseAuthority::Global(Arc::clone(catalog)));
            if definition.kind() != arcweft_lang_sema::CheckedExpressionProducerKind::Thread
                || authority
                    .as_ref()
                    .is_none_or(|authority| !definition.matches_authority(*owner, authority))
            {
                return Err(RuntimeSemanticFactsError::InvalidProducerDefinition {
                    expression: *owner,
                });
            }
            require_expr_family(
                &modules,
                runtime_owners,
                *owner,
                RuntimeSemanticFactFamily::ThreadProducer,
                |kind| {
                    matches!(kind, HirExprKind::Thread(thread)
                    if definition.thread().is_some_and(|checked| checked.matches_source(thread)))
                },
            )?;
        }
        let call_producers = collect_unique(
            input.call_producers,
            RuntimeSemanticFactFamily::CallProducer,
        )?;
        for (owner, definition) in &call_producers {
            let authority = input
                .checked_local_uses
                .as_ref()
                .map(|catalog| CheckedLocalUseAuthority::Global(Arc::clone(catalog)));
            if definition.kind() != arcweft_lang_sema::CheckedExpressionProducerKind::Call
                || authority
                    .as_ref()
                    .is_none_or(|authority| !definition.matches_authority(*owner, authority))
            {
                return Err(RuntimeSemanticFactsError::InvalidProducerDefinition {
                    expression: *owner,
                });
            }
            require_expr_family(
                &modules,
                runtime_owners,
                *owner,
                RuntimeSemanticFactFamily::CallProducer,
                |kind| matches!(kind, HirExprKind::Call(_)),
            )?;
        }
        let expression_facts = collect_unique(
            input.expression_facts,
            RuntimeSemanticFactFamily::ExpressionType,
        )?;
        for (owner, fact) in &expression_facts {
            if !fact.origin.validate_owner(project, *owner) {
                return Err(RuntimeSemanticFactsError::InvalidExpressionOrigin {
                    expression: *owner,
                });
            }
        }
        let mut type_projections = BTreeMap::new();
        for (owner, projection) in input.type_projections {
            if type_projections.insert(owner, projection).is_some() {
                let family = match owner {
                    HirValueTypeOwner::Expression(_) => RuntimeSemanticFactFamily::ExpressionType,
                    HirValueTypeOwner::Pattern(_) => RuntimeSemanticFactFamily::PatternType,
                    HirValueTypeOwner::Local(_) => RuntimeSemanticFactFamily::LocalDeclaration,
                    HirValueTypeOwner::Type(_) => RuntimeSemanticFactFamily::Type,
                    HirValueTypeOwner::Capture(_) => RuntimeSemanticFactFamily::Capture,
                };
                return Err(RuntimeSemanticFactsError::DuplicateFact { family });
            }
        }
        for (owner, projection) in &type_projections {
            let active = match owner {
                HirValueTypeOwner::Expression(owner) => {
                    runtime_owners.contains_expression(*owner)
                        && !instance_expression_owners.contains(owner)
                }
                HirValueTypeOwner::Pattern(owner) => {
                    runtime_owners.contains_pattern(*owner)
                        && !instance_pattern_owners.contains(owner)
                }
                HirValueTypeOwner::Local(owner) => {
                    runtime_owners.contains_local(*owner) && !instance_local_owners.contains(owner)
                }
                HirValueTypeOwner::Type(owner) => {
                    runtime_owners.contains_type(*owner) && !instance_type_owners.contains(owner)
                }
                HirValueTypeOwner::Capture(owner) => {
                    runtime_owners.contains_capture(*owner)
                        && !instance_capture_owners.contains(owner)
                }
            };
            let semantic_admitted = match projection {
                RuntimeExecutableTypeProjection::SemanticValue { projection } => {
                    projection.belongs_to(runtime_owners.runtime.identity())
                        || runtime_owners
                            .programs
                            .is_some_and(|owners| projection.belongs_to(owners.identity()))
                }
                _ => true,
            };
            if *owner != projection.owner()
                || matches!(
                    projection,
                    RuntimeExecutableTypeProjection::Value {
                        owner: HirValueTypeOwner::Local(_) | HirValueTypeOwner::Capture(_),
                        ..
                    }
                )
                || projection.semantic_value_type().is_some() && (!active || !semantic_admitted)
            {
                return Err(RuntimeSemanticFactsError::InvalidTypeProjection { owner: *owner });
            }
            if let Some(ty) = projection.ty() {
                validate_normalized_type(&modules, ty)?;
            }
        }
        let expression_types = RuntimeExpressionTypeView::Facts(&type_projections);
        let mut expression_specializations = BTreeMap::new();
        for (owner, specialization) in input.expression_specializations {
            let definition = callable_specializations
                .get(specialization.key())
                .ok_or(RuntimeCallableSpecializationFactError::Expression { expression: owner })?;
            if expression_types.get(&owner) != Some(definition.target())
                || specialization.source() != definition.source()
                || expression_specializations
                    .insert(owner, specialization)
                    .is_some()
            {
                return Err(RuntimeCallableSpecializationFactError::Expression {
                    expression: owner,
                }
                .into());
            }
        }
        for (owner, ty) in expression_types.iter() {
            if instance_expression_owners.contains(owner) {
                return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                    family: RuntimeSemanticFactFamily::ExpressionType,
                });
            }
            resolve_expr(&modules, *owner)?;
            require_runtime_expression_owner(
                runtime_owners,
                *owner,
                RuntimeSemanticFactFamily::ExpressionType,
            )?;
            validate_normalized_type(&modules, ty)?;
        }
        let mut expression_children = runtime_owners.selected_expression_children()?;
        expression_children.retain(|owner, _| !instance_expression_owners.contains(owner));
        for (owner, children) in &expression_children {
            require_runtime_expression_owner(
                runtime_owners,
                *owner,
                RuntimeSemanticFactFamily::ExpressionChildren,
            )?;
            if !runtime_owners.contains_expression(*owner)
                || children
                    .iter()
                    .any(|child| !runtime_owners.contains_expression(*child))
            {
                return Err(RuntimeSemanticFactsError::InactiveExpressionFact {
                    expression: *owner,
                    family: RuntimeSemanticFactFamily::ExpressionChildren,
                });
            }
        }

        let pattern_types = type_projections
            .iter()
            .filter_map(|(owner, projection)| match owner {
                HirValueTypeOwner::Pattern(owner) => projection.ty().map(|ty| (*owner, ty)),
                _ => None,
            })
            .collect::<BTreeMap<_, _>>();
        for (owner, ty) in &pattern_types {
            if instance_pattern_owners.contains(owner) {
                return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                    family: RuntimeSemanticFactFamily::PatternType,
                });
            }
            resolve_pattern(&modules, *owner)?;
            require_runtime_pattern_owner(
                runtime_owners,
                *owner,
                RuntimeSemanticFactFamily::PatternType,
            )?;
            validate_normalized_type(&modules, ty)?;
        }

        let local_declarations = type_projections
            .iter()
            .filter_map(|(owner, projection)| match owner {
                HirValueTypeOwner::Local(owner) => Some((*owner, projection)),
                _ => None,
            })
            .collect::<BTreeMap<_, _>>();
        let expected_local_set = expected_local_declarations
            .iter()
            .copied()
            .collect::<BTreeSet<_>>();
        if let Some(local) = input
            .local_declaration_order
            .iter()
            .find(|local| !expected_local_set.contains(local))
        {
            return Err(RuntimeSemanticFactsError::ExtraLocalDeclaration { local: *local });
        }
        if let Some(local) = expected_local_declarations
            .iter()
            .find(|local| !local_declarations.contains_key(local))
        {
            return Err(RuntimeSemanticFactsError::MissingLocalDeclaration { local: *local });
        }
        for (owner, expected_owner) in input
            .local_declaration_order
            .iter()
            .zip(&expected_local_declarations)
        {
            if owner != expected_owner {
                return Err(
                    RuntimeSemanticFactsError::NonCanonicalLocalDeclarationOrder {
                        expected: *expected_owner,
                        actual: *owner,
                    },
                );
            }
            let projection = local_declarations[owner];
            if projection.semantic_value_type().is_some() {
                continue;
            }
            let ty = projection
                .ty()
                .ok_or(RuntimeSemanticFactsError::MissingLocalDeclaration { local: *owner })?;
            if projection
                .local_origin()
                .is_none_or(|origin| !origin.validate_owner(project, *owner))
            {
                return Err(RuntimeSemanticFactsError::InvalidLocalOrigin { local: *owner });
            }
            validate_normalized_type(&modules, ty)?;
            let valid = match projection.local_context() {
                None => ty.scope().is_root(),
                Some(context) => {
                    validate_normalized_type(&modules, context)?;
                    context.scope().is_root()
                        && matches!(context.shape(), RuntimeTypeShape::Function { contract, .. }
                        if context.scope().enter(contract.binder()).is_ok_and(|scope| &scope == ty.scope()))
                }
            };
            if !valid {
                return Err(RuntimeSemanticFactsError::MissingLocalDeclaration { local: *owner });
            }
        }

        let flows = collect_unique(input.flows, RuntimeSemanticFactFamily::FlowIdentity)?;
        for (item, fact) in &flows {
            let resolved = resolve_item(&modules, *item)?;
            if !matches!(resolved.kind(), HirItemKind::Flow(_)) {
                return Err(RuntimeSemanticFactsError::WrongItemFamily {
                    item: *item,
                    actual: resolved.kind().family(),
                });
            }
            if !runtime_owners.contains_runtime_owner(&HirRuntimeExecutableOwner::Item(*item)) {
                return Err(RuntimeSemanticFactsError::OwnerOutsideReachability {
                    owner: HirRuntimeExecutableOwner::Item(*item),
                });
            }
            if fact.owner() != *item
                || fact.definition().validate_project(project).is_err()
                || !matches!(fact.definition().source(),
                    arcweft_lang_sema::final_analysis::CheckedExecutionSource::InvokeBody(
                        arcweft_lang_sema::final_analysis::CheckedExecutionBodyOwner::Declaration {
                            declaration,
                            ..
                        }
                    ) if fact.definition().hir_topology().declaration(declaration)
                        .is_ok_and(|view| view.body().source_item() == *item)
                )
                || !matches!(fact.definition().environment().local_uses(),
                    CheckedLocalUseAuthority::Global(catalog)
                        if catalog.generation().symbol_world() == runtime_owners.runtime.identity().symbol_world()
                            && catalog.generation().symbol_revision() == runtime_owners.runtime.identity().symbol_revision()
                            && input.checked_local_uses.as_ref().is_none_or(|selected| selected == catalog)
                )
            {
                return Err(RuntimeSemanticFactsError::InvalidFlowDefinition { item: *item });
            }
        }

        let includes = flow_include::admit_global(
            project,
            &modules,
            runtime_owners,
            &instance_statement_owners,
            input.includes,
        )?;
        let suspensions = suspension::admit_global(
            &modules,
            runtime_owners,
            &instance_statement_owners,
            &expression_types,
            input.suspensions,
        )?;
        let expression_scopes = collect_unique(
            input.expression_scopes,
            RuntimeSemanticFactFamily::ExpressionScope,
        )?;
        let statement_scopes = collect_unique(
            input.statement_scopes,
            RuntimeSemanticFactFamily::StatementScope,
        )?;
        lexical_scope::validate_global_scopes(
            project,
            &modules,
            runtime_owners,
            &instance_expression_owners,
            &instance_statement_owners,
            &expression_scopes,
            &statement_scopes,
        )?;

        let expression_literals = collect_unique(
            input.expression_literals,
            RuntimeSemanticFactFamily::ExpressionLiteral,
        )?;
        for expression in expression_literals.keys() {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::ExpressionLiteral,
                |kind| {
                    matches!(
                        kind,
                        HirExprKind::Literal(_) | HirExprKind::NumericBracketSequence(_)
                    )
                },
            )?;
        }

        let expression_residual_values = collect_unique(
            input.expression_residual_values,
            RuntimeSemanticFactFamily::ResidualValue,
        )?;
        for (expression, residual) in &expression_residual_values {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::ResidualValue,
                |kind| matches!(kind, HirExprKind::Call(_)),
            )?;
            if expression_literals.contains_key(expression)
                || !matches!(residual.value(), RuntimeValue::Color(_))
                || !expression_types
                    .get(expression)
                    .is_some_and(|ty| matches!(ty.shape(), RuntimeTypeShape::Color))
            {
                return Err(RuntimeSemanticFactsError::InvalidResidualValue {
                    expression: *expression,
                });
            }
        }

        let pattern_literals = collect_unique(
            input.pattern_literals,
            RuntimeSemanticFactFamily::PatternLiteral,
        )?;
        for pattern in pattern_literals.keys() {
            require_pattern_family(
                &modules,
                runtime_owners,
                *pattern,
                RuntimeSemanticFactFamily::PatternLiteral,
                |kind| matches!(kind, HirPatternKind::Literal(_)),
            )?;
        }

        let pattern_items =
            collect_unique(input.pattern_items, RuntimeSemanticFactFamily::PatternItem)?;
        for (pattern, item) in &pattern_items {
            require_pattern_family(
                &modules,
                runtime_owners,
                *pattern,
                RuntimeSemanticFactFamily::PatternItem,
                |kind| matches!(kind, HirPatternKind::EntityReference(_)),
            )?;
            if !item.validate_owner(project, *pattern) {
                return Err(RuntimeSemanticFactsError::InvalidEntityPatternOrigin {
                    pattern: *pattern,
                });
            }
            validate_entity_pattern_type(*pattern, pattern_types.get(pattern).copied(), item)?;
        }

        if let Some(catalog) = input.checked_local_uses.as_ref() {
            let generation = catalog.generation();
            if generation.validate_analysis_lease(project).is_err()
                || generation.symbol_world() != runtime_owners.runtime.identity().symbol_world()
                || generation.symbol_revision()
                    != runtime_owners.runtime.identity().symbol_revision()
            {
                return Err(RuntimeSemanticFactsError::WrongProjectGeneration);
            }
        }
        let local_uses: BTreeMap<
            arcweft_lang_sema::final_analysis::CheckedLocalUseSite,
            &arcweft_lang_sema::final_analysis::CheckedLocalAccess,
        > = collect_unique(
            input
                .checked_local_uses
                .as_ref()
                .into_iter()
                .flat_map(|catalog| catalog.rows()),
            RuntimeSemanticFactFamily::LocalUse,
        )?;
        for (&site, &row) in &local_uses {
            use arcweft_lang_sema::final_analysis::CheckedLocalUseSite;
            let valid = match site {
                CheckedLocalUseSite::Place(owner) => modules
                    .get(&owner.module())
                    .is_some_and(|module| {
                        row.place_access().is_some()
                            && module.resolve_expr(owner).is_ok()
                            && row.local().module() == owner.module()
                            && module.resolve_local(row.local()).is_ok()
                    }),
                CheckedLocalUseSite::Expression(owner)
                | CheckedLocalUseSite::RecordField { owner, .. }
                | CheckedLocalUseSite::Capture { owner, .. } => modules
                    .get(&owner.module())
                    .is_some_and(|module| {
                        row.value_transfer().is_some()
                            && module.resolve_expr(owner).is_ok()
                            && row.local().module() == owner.module()
                            && module.resolve_local(row.local()).is_ok()
                            && !matches!(site, CheckedLocalUseSite::Capture { local, .. } if local != row.local())
                    }),
                CheckedLocalUseSite::StatementCapture { owner, local } => modules
                    .get(&owner.module())
                    .is_some_and(|module| {
                        row.value_transfer().is_some()
                            && module.resolve_stmt(owner).is_ok()
                            && local == row.local()
                            && module.resolve_local(local).is_ok()
                    }),
            };
            if !valid {
                return Err(RuntimeSemanticFactsError::InvalidLocalUse { site });
            }
        }
        let synthetic_uses: BTreeMap<
            ExprId,
            arcweft_lang_sema::final_analysis::CheckedSyntheticUse,
        > = collect_unique(
            input
                .checked_local_uses
                .as_ref()
                .into_iter()
                .flat_map(|catalog| catalog.synthetic_rows()),
            RuntimeSemanticFactFamily::SyntheticUse,
        )?;
        for &expression in synthetic_uses.keys() {
            if modules
                .get(&expression.module())
                .is_none_or(|module| module.resolve_expr(expression).is_err())
            {
                return Err(RuntimeSemanticFactsError::InvalidSyntheticUse { expression });
            }
        }
        let values = collect_unique(input.values, RuntimeSemanticFactFamily::Value)?;
        for (expression, value) in &values {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Value,
                |kind| {
                    matches!(
                        kind,
                        HirExprKind::Path(_)
                            | HirExprKind::Select(_)
                            | HirExprKind::EntityReference(_)
                            | HirExprKind::ShortVariant(_)
                            | HirExprKind::LifetimePath(_)
                    )
                },
            )?;
            validate_resolved_value(
                &modules,
                runtime_owners,
                RuntimeValueOriginContext::Project(project),
                *expression,
                expression_types.get(expression),
                value,
            )?;
            if let RuntimeResolvedValue::Place(place) = value {
                let sites = [
                    arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Expression(*expression),
                    arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Place(*expression),
                ];
                let rows = sites
                    .into_iter()
                    .filter_map(|site| local_uses.get(&site).copied())
                    .collect::<Vec<_>>();
                if rows.is_empty()
                    || rows.iter().any(|access| !place.matches_access(access))
                    || local_declarations
                        .get(&place.local())
                        .and_then(|root| root.ty())
                        .zip(expression_types.get(expression))
                        .is_none_or(|(root, value)| !place.accepts_types(root, value))
                {
                    return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                        expression: *expression,
                        expected: RuntimeSemanticFactFamily::Value,
                    });
                }
            }
            if matches!(value, RuntimeResolvedValue::Entity(_))
                && !matches!(
                    expression_types
                        .get(expression)
                        .map(RuntimeNormalizedType::shape),
                    Some(RuntimeTypeShape::EntityReference(_))
                )
            {
                return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                    expression: *expression,
                    expected: RuntimeSemanticFactFamily::Value,
                });
            }
            match (resolve_expr(&modules, *expression)?, value) {
                (HirExprKind::Path(_), RuntimeResolvedValue::DialogueLine(_))
                | (
                    HirExprKind::EntityReference(_),
                    RuntimeResolvedValue::Local(_)
                    | RuntimeResolvedValue::ProjectCallable { .. }
                    | RuntimeResolvedValue::ExternalCallable(_)
                    | RuntimeResolvedValue::Intrinsic(_)
                    | RuntimeResolvedValue::Registered(_),
                ) => {
                    return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                        expression: *expression,
                        expected: RuntimeSemanticFactFamily::Value,
                    });
                }
                (
                    HirExprKind::EntityReference(_),
                    RuntimeResolvedValue::Entity(_)
                    | RuntimeResolvedValue::DialogueLine(_)
                    | RuntimeResolvedValue::Constant(_),
                )
                | (HirExprKind::Path(_), _) => {}
                (HirExprKind::LifetimePath(_), RuntimeResolvedValue::RegistryRead(_)) => {}
                (HirExprKind::Select(_), value) if value.has_static_qualifier() => {}
                _ => {
                    return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                        expression: *expression,
                        expected: RuntimeSemanticFactFamily::Value,
                    });
                }
            }
        }

        let selects = collect_unique(input.selects, RuntimeSemanticFactFamily::Select)?;
        for (expression, select) in &selects {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Select,
                |kind| matches!(kind, HirExprKind::Select(_)),
            )?;
            validate_select(&modules, *expression, select)?;
        }

        let mut nominal_records = collect_unique(
            input.nominal_records,
            RuntimeSemanticFactFamily::NominalRecord,
        )?;
        for (expression, record) in &nominal_records {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::NominalRecord,
                |kind| matches!(kind, HirExprKind::Record(_) | HirExprKind::RecordLiteral(_)),
            )?;
            validate_record_expression_fact(&modules, *expression, record)?;
        }

        let mut pattern_nominal_records = collect_unique(
            input.pattern_nominal_records,
            RuntimeSemanticFactFamily::PatternNominalRecord,
        )?;
        for (pattern, record) in &pattern_nominal_records {
            require_pattern_family(
                &modules,
                runtime_owners,
                *pattern,
                RuntimeSemanticFactFamily::PatternNominalRecord,
                |kind| matches!(kind, HirPatternKind::Record { .. }),
            )?;
            validate_record_pattern_fact(&modules, *pattern, record)?;
            if record
                .structural()
                .is_some_and(|owner| pattern_types.get(pattern).copied() != Some(owner))
            {
                return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                    pattern: *pattern,
                    expected: RuntimeSemanticFactFamily::PatternNominalRecord,
                });
            }
        }

        let mut nominal_layouts = BTreeMap::new();
        for record in nominal_records.values_mut() {
            intern_nominal_record_layout(record.nominal_mut(), &mut nominal_layouts)?;
        }
        for record in pattern_nominal_records.values_mut() {
            if let Some(nominal) = record.nominal_mut() {
                intern_nominal_record_layout(nominal, &mut nominal_layouts)?;
            }
        }

        let expression_variants = collect_unique(
            input.expression_variants,
            RuntimeSemanticFactFamily::ExpressionVariant,
        )?;
        for (expression, variant) in &expression_variants {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::ExpressionVariant,
                RuntimeResolvedVariant::accepts_expression_kind,
            )?;
            validate_variant(&modules, variant)?;
        }

        let pattern_variants = collect_unique(
            input.pattern_variants,
            RuntimeSemanticFactFamily::PatternVariant,
        )?;
        for (pattern, variant) in &pattern_variants {
            require_pattern_family(
                &modules,
                runtime_owners,
                *pattern,
                RuntimeSemanticFactFamily::PatternVariant,
                |kind| matches!(kind, HirPatternKind::Variant(_)),
            )?;
            validate_variant(&modules, variant)?;
        }

        let types = type_projections
            .iter()
            .filter_map(|(owner, projection)| match owner {
                HirValueTypeOwner::Type(owner) => projection.ty().map(|ty| (*owner, ty)),
                _ => None,
            })
            .collect::<BTreeMap<_, _>>();
        for (owner, ty) in &types {
            if instance_type_owners.contains(owner) {
                return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                    family: RuntimeSemanticFactFamily::Type,
                });
            }
            let hir_type = module_for(&modules, owner.module())?
                .resolve_type(*owner)
                .map_err(|_| RuntimeSemanticFactsError::UnresolvedType { ty: *owner })?;
            require_runtime_type_owner(runtime_owners, *owner)?;
            if hir_type.is_poisoned() {
                return Err(RuntimeSemanticFactsError::PoisonedType { ty: *owner });
            }
            validate_normalized_type(&modules, ty)?;
        }

        let calls = collect_unique(input.calls, RuntimeSemanticFactFamily::Call)?;
        let mut referenced_project_function_instances = project_function_roots
            .values()
            .map(|root| root.instance().clone())
            .collect::<BTreeSet<_>>();
        for specialization in callable_specializations.values() {
            referenced_project_function_instances
                .extend(specialization.selections().values().cloned());
        }
        let mut callable_values = values
            .iter()
            .map(|(owner, value)| {
                (
                    *owner,
                    value,
                    expression_specializations
                        .get(owner)
                        .map(RuntimeCallableValueSpecialization::source)
                        .or_else(|| expression_types.get(owner)),
                )
            })
            .collect::<Vec<_>>();
        for (_, semantics) in instance_semantic_roots(
            project_function_instances.values(),
            root_closures.values(),
            input.trait_methods.iter(),
            pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            let mut specializations = Vec::new();
            semantics.visit_specializations(&mut |owner, spec, ty| {
                specializations.push((owner, spec, ty))
            });
            for (owner, spec, ty) in specializations {
                if callable_specializations
                    .get(spec.key())
                    .is_none_or(|definition| {
                        definition.source() != spec.source() || Some(definition.target()) != ty
                    })
                {
                    return Err(RuntimeCallableSpecializationFactError::Expression {
                        expression: owner,
                    }
                    .into());
                }
            }
            semantics.visit_callable_values(&mut |owner, value, ty| {
                callable_values.push((owner, value, ty))
            });
        }
        for (expression, value, ty) in callable_values {
            if let RuntimeResolvedValue::ProjectCallable { callable, target } = value {
                let (accepted_callable, accepted_type) = match target {
                    RuntimeProjectCallableValueTarget::Closed(instance) => {
                        let fact = project_function_instances.get(instance).ok_or(
                            RuntimeSemanticFactsError::MissingProjectFunctionInstance {
                                expression,
                            },
                        )?;
                        referenced_project_function_instances.insert(instance.clone());
                        (fact.callable(), fact.callable_type())
                    }
                    RuntimeProjectCallableValueTarget::Source(source) => {
                        let fact = callable_sources
                            .get(source)
                            .ok_or(RuntimeCallableSpecializationFactError::Inventory)?;
                        (fact.callable(), fact.function_type())
                    }
                };
                if accepted_callable != callable || ty != Some(accepted_type) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
        }
        for (expression, call) in &calls {
            if instance_expression_owners.contains(expression) {
                return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                    family: RuntimeSemanticFactFamily::Call,
                });
            }
            let kind = resolve_expr(&modules, *expression)?;
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Call,
            )?;
            let (hir_call, attached_body) = match kind {
                HirExprKind::Call(hir_call) => (hir_call, None),
                HirExprKind::AttachedContentApplication(application) => {
                    let Some(invocation) = application.family().invocation() else {
                        return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                            expression: *expression,
                            expected: RuntimeSemanticFactFamily::Call,
                        });
                    };
                    (invocation, Some(application.body_presence()))
                }
                _ => {
                    return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                        expression: *expression,
                        expected: RuntimeSemanticFactFamily::Call,
                    });
                }
            };
            validate_call(
                &modules,
                &expression_types,
                *expression,
                expression_specializations
                    .get(expression)
                    .map(RuntimeCallableValueSpecialization::source)
                    .or_else(|| expression_types.get(expression)),
                hir_call,
                attached_body,
                call,
            )?;
            validate_project_function_call_materialization(&modules, call)?;
            if let Some(instance) = validate_project_function_instance_reference(
                *expression,
                call,
                expression_specializations
                    .get(expression)
                    .map(RuntimeCallableValueSpecialization::source)
                    .or_else(|| expression_types.get(expression)),
                &project_function_instances,
                &callable_sources,
                &callable_specializations,
            )? {
                referenced_project_function_instances.insert(instance);
            }
            let executable = match call.dispatch() {
                RuntimeResolvedCallDispatch::Static(
                    RuntimeResolvedStaticCallTarget::Declaration(callable),
                ) => Some(HirRuntimeExecutableOwner::Item(callable.owner())),
                RuntimeResolvedCallDispatch::Static(
                    RuntimeResolvedStaticCallTarget::TraitMethod { method, .. },
                ) => Some(HirRuntimeExecutableOwner::ImplMethod(method.clone())),
                RuntimeResolvedCallDispatch::Static(
                    RuntimeResolvedStaticCallTarget::Intrinsic(_)
                    | RuntimeResolvedStaticCallTarget::PresentationSlot(_)
                    | RuntimeResolvedStaticCallTarget::PresentationFactory { .. }
                    | RuntimeResolvedStaticCallTarget::PresentationView { .. }
                    | RuntimeResolvedStaticCallTarget::PresentationHandleMethod { .. }
                    | RuntimeResolvedStaticCallTarget::Format(_)
                    | RuntimeResolvedStaticCallTarget::VecPopFront
                    | RuntimeResolvedStaticCallTarget::VecPop
                    | RuntimeResolvedStaticCallTarget::VecPush
                    | RuntimeResolvedStaticCallTarget::Agent(_)
                    | RuntimeResolvedStaticCallTarget::AgentProbeComparison(_)
                    | RuntimeResolvedStaticCallTarget::AgentDiagnosticsHasError
                    | RuntimeResolvedStaticCallTarget::Variant(_)
                    | RuntimeResolvedStaticCallTarget::RecordConstructor { .. }
                    | RuntimeResolvedStaticCallTarget::Reduction(_)
                    | RuntimeResolvedStaticCallTarget::StandardMap(_)
                    | RuntimeResolvedStaticCallTarget::StandardMapPrefix(_)
                    | RuntimeResolvedStaticCallTarget::Traverse
                    | RuntimeResolvedStaticCallTarget::ProgramNeed(_)
                    | RuntimeResolvedStaticCallTarget::CharacterDialogue(_)
                    | RuntimeResolvedStaticCallTarget::Line(_)
                    | RuntimeResolvedStaticCallTarget::Registered(_)
                    | RuntimeResolvedStaticCallTarget::Host(_),
                )
                | RuntimeResolvedCallDispatch::Value { .. } => None,
            };
            if let Some(owner) = executable
                && !runtime_owners.contains_runtime_owner(&owner)
            {
                return Err(RuntimeSemanticFactsError::OwnerOutsideReachability { owner });
            }
        }
        for (_, semantics) in instance_semantic_roots(
            project_function_instances.values(),
            root_closures.values(),
            input.trait_methods.iter(),
            pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            let mut expression_types = BTreeMap::new();
            semantics.visit_type_projections(&mut |projection| {
                if let (HirValueTypeOwner::Expression(owner), Some(ty)) =
                    (projection.owner(), projection.ty())
                {
                    expression_types.insert(owner, ty);
                }
            });
            semantics.visit_specializations(&mut |owner, spec, _| {
                expression_types.insert(owner, spec.source());
            });
            let mut closed_calls = Vec::new();
            semantics.visit_calls(&mut |owner, call| closed_calls.push((owner, call)));
            for (owner, call) in closed_calls {
                if let Some(invoked) = validate_project_function_instance_reference(
                    owner,
                    call,
                    expression_types.get(&owner).copied(),
                    &project_function_instances,
                    &callable_sources,
                    &callable_specializations,
                )? {
                    referenced_project_function_instances.insert(invoked);
                }
            }
        }
        if project_function_instances
            .keys()
            .any(|key| !referenced_project_function_instances.contains(key))
        {
            return Err(RuntimeSemanticFactsError::UnreferencedProjectFunctionInstance);
        }

        let choices = collect_unique(input.choices, RuntimeSemanticFactFamily::Choice)?;
        for (expression, fact) in &choices {
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Choice,
            )?;
            let HirExprKind::Choice(choice) = resolve_expr(&modules, *expression)? else {
                return Err(RuntimeSemanticFactsError::InvalidChoiceFact {
                    expression: *expression,
                });
            };
            if fact.option_ids().len() != choice.body().items().len()
                || fact
                    .public_id()
                    .is_some_and(|id| id.as_str().split('.').next() != Some("choice"))
                || fact
                    .option_ids()
                    .iter()
                    .any(|id| id.as_str().split('.').next() != Some("choice"))
            {
                return Err(RuntimeSemanticFactsError::InvalidChoiceFact {
                    expression: *expression,
                });
            }
            let mut previous = None;
            for goto in fact.gotos() {
                if previous.is_some_and(|previous| previous >= goto.arm()) {
                    return Err(RuntimeSemanticFactsError::InvalidChoiceFact {
                        expression: *expression,
                    });
                }
                let index = usize::try_from(goto.arm()).map_err(|_| {
                    RuntimeSemanticFactsError::InvalidChoiceFact {
                        expression: *expression,
                    }
                })?;
                if !matches!(
                    choice.body().items().get(index),
                    Some(HirChoiceItem::CompactArm(arm))
                        if matches!(arm.action(), HirChoiceCompactAction::Goto(_))
                ) || goto.target().family() != DeclarationIdentityFamily::Flow
                {
                    return Err(RuntimeSemanticFactsError::InvalidChoiceFact {
                        expression: *expression,
                    });
                }
                validate_project_item(&modules, goto.target())?;
                let RuntimeProjectItemOwner::StructuralFlow { owner, runtime } =
                    goto.target().owner()
                else {
                    return Err(RuntimeSemanticFactsError::InvalidChoiceFact {
                        expression: *expression,
                    });
                };
                if flows.get(owner).map(RuntimeFlowFact::identity) != Some(runtime) {
                    return Err(RuntimeSemanticFactsError::InvalidChoiceFact {
                        expression: *expression,
                    });
                }
                previous = Some(goto.arm());
            }
        }

        let awaits = collect_unique(input.awaits, RuntimeSemanticFactFamily::Await)?;
        for (expression, fact) in &awaits {
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Await,
            )?;
            let HirExprKind::Await(awaited) = resolve_expr(&modules, *expression)? else {
                return Err(RuntimeSemanticFactsError::InvalidAwaitFact {
                    expression: *expression,
                });
            };
            if awaited.operand() != fact.operand()
                || fact.observers().len() != awaited.branches().len()
            {
                return Err(RuntimeSemanticFactsError::InvalidAwaitFact {
                    expression: *expression,
                });
            }
            let Some(operand) = expression_types.get(&fact.operand()) else {
                return Err(RuntimeSemanticFactsError::InvalidAwaitFact {
                    expression: *expression,
                });
            };
            let Some(item) = operand.awaited_payload() else {
                return Err(RuntimeSemanticFactsError::InvalidAwaitFact {
                    expression: *expression,
                });
            };
            if expression_types.get(expression) != Some(item) {
                return Err(RuntimeSemanticFactsError::InvalidAwaitFact {
                    expression: *expression,
                });
            }
            for (authored, checked) in awaited.branches().iter().zip(fact.observers()) {
                if authored.kind() != HirAwaitBranchKind::Pending
                    || authored.pattern() != Some(checked.pattern())
                    || !matches!(
                        pattern_types
                            .get(&checked.pattern())
                            .copied()
                            .map(RuntimeNormalizedType::shape),
                        Some(RuntimeTypeShape::Progress)
                    )
                {
                    return Err(RuntimeSemanticFactsError::InvalidAwaitFact {
                        expression: *expression,
                    });
                }
            }
        }

        let implicit_callables = collect_unique(
            input.implicit_callables,
            RuntimeSemanticFactFamily::ImplicitCallable,
        )?;
        for (expression, fact) in &implicit_callables {
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::ImplicitCallable,
            )?;
            let Some(expression_type) = expression_types.get(expression) else {
                return Err(RuntimeSemanticFactsError::InvalidImplicitCallableFact {
                    expression: *expression,
                });
            };
            let RuntimeTypeShape::Function {
                parameters, result, ..
            } = expression_type.shape()
            else {
                return Err(RuntimeSemanticFactsError::InvalidImplicitCallableFact {
                    expression: *expression,
                });
            };
            if parameters.len() != 1
                || &parameters[0] != fact.parameter()
                || result.as_ref() != fact.result()
                || fact.placeholders().is_empty()
                || !all_unique(fact.placeholders())
                || fact.definition().owner() != *expression
                || !matches!(fact.formal().authority(), CheckedLocalUseAuthority::Global(catalog)
                    if input.checked_local_uses.as_ref() == Some(catalog))
            {
                return Err(RuntimeSemanticFactsError::InvalidImplicitCallableFact {
                    expression: *expression,
                });
            }
            for placeholder in fact.placeholders() {
                if !matches!(
                    resolve_expr(&modules, *placeholder)?,
                    HirExprKind::Placeholder(HirPlaceholderKind::PartialApplication)
                ) || (*placeholder != *expression
                    && expression_types.get(placeholder) != Some(fact.parameter()))
                    || synthetic_uses.get(placeholder).is_none_or(|row| {
                        row.owner()
                            != arcweft_lang_sema::final_analysis::CheckedSyntheticUseOwner::ImplicitParameter(
                                fact.identity(),
                            )
                    })
                {
                    return Err(RuntimeSemanticFactsError::InvalidImplicitCallableFact {
                        expression: *expression,
                    });
                }
            }
            for capture in fact.captures() {
                if !local_declarations.contains_key(&capture.local())
                    || input
                        .checked_local_uses
                        .as_ref()
                        .and_then(|catalog| {
                            catalog.value_transfer_at(
                                arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Capture {
                                    owner: *expression,
                                    local: capture.local(),
                                },
                            )
                        })
                        .as_ref()
                        != Some(capture.transfer())
                {
                    return Err(RuntimeSemanticFactsError::InvalidImplicitCallableFact {
                        expression: *expression,
                    });
                }
            }
        }

        let pipes = collect_unique(input.pipes, RuntimeSemanticFactFamily::Pipe)?;
        for (expression, fact) in &pipes {
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Pipe,
            )?;
            let HirExprKind::Pipe(pipe) = resolve_expr(&modules, *expression)? else {
                return Err(RuntimeSemanticFactsError::InvalidPipeFact {
                    expression: *expression,
                });
            };
            let Some(left_type) = expression_types.get(&fact.left()) else {
                return Err(RuntimeSemanticFactsError::InvalidPipeFact {
                    expression: *expression,
                });
            };
            if pipe.left() != fact.left()
                || pipe.right() != fact.right()
                || !all_unique(fact.placeholders())
            {
                return Err(RuntimeSemanticFactsError::InvalidPipeFact {
                    expression: *expression,
                });
            }
            for placeholder in fact.placeholders() {
                if !matches!(
                    resolve_expr(&modules, *placeholder)?,
                    HirExprKind::Placeholder(HirPlaceholderKind::PipeLeft)
                ) || expression_types.get(placeholder) != Some(left_type)
                    || synthetic_uses.get(placeholder).is_none_or(|row| {
                        row.owner()
                            != arcweft_lang_sema::final_analysis::CheckedSyntheticUseOwner::Pipe(
                                fact.binding_identity(),
                            )
                    })
                {
                    return Err(RuntimeSemanticFactsError::InvalidPipeFact {
                        expression: *expression,
                    });
                }
            }
        }

        let try_facts = collect_unique(input.tries, RuntimeSemanticFactFamily::Try)?;
        for (expression, fact) in &try_facts {
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::Try,
            )?;
            let HirExprKind::Try(tried) = resolve_expr(&modules, *expression)? else {
                return Err(RuntimeSemanticFactsError::InvalidTryFact {
                    expression: *expression,
                });
            };
            let result_matches = match fact.boundary() {
                RuntimeTryBoundaryOwner::ImplicitFunctionSite(boundary) => implicit_callables
                    .get(&boundary)
                    .is_some_and(|callable| callable.result() == fact.carrier().success()),
                RuntimeTryBoundaryOwner::Infallible
                | RuntimeTryBoundaryOwner::CarrierBlock(_)
                | RuntimeTryBoundaryOwner::Thread(_)
                | RuntimeTryBoundaryOwner::ExplicitFunctionSite(_)
                | RuntimeTryBoundaryOwner::Callable(_) => {
                    expression_types.get(expression) == Some(fact.carrier().success())
                }
            };
            if tried.operand() != fact.operand() || !result_matches {
                return Err(RuntimeSemanticFactsError::InvalidTryFact {
                    expression: *expression,
                });
            }
            let Some(operand) = expression_types.get(&fact.operand()) else {
                return Err(RuntimeSemanticFactsError::InvalidTryFact {
                    expression: *expression,
                });
            };
            if operand != fact.carrier_type() {
                return Err(RuntimeSemanticFactsError::InvalidTryFact {
                    expression: *expression,
                });
            }
            let carrier_matches = match (fact.carrier(), operand.shape()) {
                (
                    RuntimeTryCarrierFact::Result { success, residual },
                    RuntimeTypeShape::Result { value, error, .. },
                ) => success == value.as_ref() && residual.as_ref() == error.as_ref(),
                (
                    RuntimeTryCarrierFact::Option { success },
                    RuntimeTypeShape::Option { item, .. },
                ) => success == item.as_ref(),
                _ => false,
            };
            if !carrier_matches || !try_boundary_type_matches(fact) {
                return Err(RuntimeSemanticFactsError::InvalidTryFact {
                    expression: *expression,
                });
            }
            match fact.boundary() {
                RuntimeTryBoundaryOwner::Infallible => {
                    if !matches!(
                        fact.carrier(),
                            RuntimeTryCarrierFact::Result { residual, .. }
                                if matches!(residual.shape(), RuntimeTypeShape::Never)
                    ) {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    }
                }
                RuntimeTryBoundaryOwner::CarrierBlock(boundary) => {
                    let HirExprKind::ComputationBlock(block) = resolve_expr(&modules, boundary)?
                    else {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    };
                    let family_matches = matches!(
                        (block.kind(), fact.carrier()),
                        (
                            arcweft_lang_hir::expr::HirComputationBlockKind::Result,
                            RuntimeTryCarrierFact::Result { .. }
                        ) | (
                            arcweft_lang_hir::expr::HirComputationBlockKind::Option,
                            RuntimeTryCarrierFact::Option { .. }
                        )
                    );
                    if !family_matches
                        || expression_types.get(&boundary) != Some(fact.boundary_type())
                    {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    }
                }
                RuntimeTryBoundaryOwner::Thread(boundary) => {
                    let kind = resolve_expr(&modules, boundary)?;
                    let result = expression_types
                        .get(&boundary)
                        .and_then(|ty| match ty.shape() {
                            RuntimeTypeShape::ThreadHandle(result) => Some(result.as_ref()),
                            _ => None,
                        });
                    if !matches!(kind, HirExprKind::Thread(_))
                        || result != Some(fact.boundary_type())
                    {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    }
                }
                RuntimeTryBoundaryOwner::ExplicitFunctionSite(boundary) => {
                    let kind = resolve_expr(&modules, boundary)?;
                    let valid_owner = matches!(kind, HirExprKind::Closure(_));
                    let boundary_result =
                        expression_types
                            .get(&boundary)
                            .and_then(|ty| match ty.shape() {
                                RuntimeTypeShape::Function { result, .. } => Some(result.as_ref()),
                                _ => None,
                            });
                    if !valid_owner || boundary_result != Some(fact.boundary_type()) {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    }
                }
                RuntimeTryBoundaryOwner::ImplicitFunctionSite(boundary) => {
                    if implicit_callables
                        .get(&boundary)
                        .is_none_or(|callable| callable.result() != fact.boundary_type())
                    {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    }
                }
                RuntimeTryBoundaryOwner::Callable(boundary) => {
                    if !boundary.as_bytes().iter().any(|byte| *byte != 0) {
                        return Err(RuntimeSemanticFactsError::InvalidTryFact {
                            expression: *expression,
                        });
                    }
                }
            }
        }

        for (owner, fact) in &expression_scopes {
            lexical_scope::validate_continuation(
                &modules,
                RuntimeScopeOwner::Expression(*owner),
                fact,
                expression_types.get(owner),
                try_facts.iter().map(|(owner, tried)| (*owner, tried)),
            )?;
        }
        for (owner, fact) in &statement_scopes {
            lexical_scope::validate_continuation(
                &modules,
                RuntimeScopeOwner::Statement(*owner),
                fact,
                None,
                try_facts.iter().map(|(owner, tried)| (*owner, tried)),
            )?;
        }

        let postfix_candidates = collect_unique(
            input.postfix_candidates,
            RuntimeSemanticFactFamily::PostfixCandidate,
        )?;
        for (expression, candidate) in &postfix_candidates {
            let kind = resolve_expr(&modules, *expression)?;
            require_runtime_expression_owner(
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::PostfixCandidate,
            )?;
            resolve_expr(&modules, *candidate)?;
            require_runtime_expression_owner(
                runtime_owners,
                *candidate,
                RuntimeSemanticFactFamily::PostfixCandidate,
            )?;
            let HirExprKind::PostfixBracket(postfix) = kind else {
                return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                    expression: *expression,
                    expected: RuntimeSemanticFactFamily::PostfixCandidate,
                });
            };
            let arcweft_lang_hir::dialogue_application::HirPostfixBracketCandidates::Ambiguous {
                index,
                dialogue,
            } = postfix.candidates()
            else {
                return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                    expression: *expression,
                    expected: RuntimeSemanticFactFamily::PostfixCandidate,
                });
            };
            if candidate != index && candidate != dialogue {
                return Err(RuntimeSemanticFactsError::WrongPostfixCandidate {
                    expression: *expression,
                    candidate: *candidate,
                });
            }
        }

        for expression in runtime_owners
            .expressions()
            .into_iter()
            .filter(|owner| !instance_expression_owners.contains(owner))
        {
            if matches!(
                resolve_expr(&modules, expression)?,
                HirExprKind::PostfixBracket(_)
            ) && !postfix_candidates.contains_key(&expression)
            {
                return Err(RuntimeSemanticFactsError::MissingPostfixCandidate { expression });
            }
        }
        validate_complete_expression_types(
            runtime_owners,
            &expression_types,
            &instance_expression_owners,
        )?;
        for owner in expression_children.keys() {
            if !expression_facts.contains_key(owner) {
                return Err(RuntimeSemanticFactsError::MissingExpressionOrigin {
                    expression: *owner,
                });
            }
        }
        if let Some(owner) = expression_facts
            .keys()
            .find(|owner| !expression_children.contains_key(owner))
        {
            return Err(RuntimeSemanticFactsError::InactiveExpressionFact {
                expression: *owner,
                family: RuntimeSemanticFactFamily::ExpressionChildren,
            });
        }
        validate_complete_pattern_types(
            runtime_owners,
            &type_projections,
            &instance_pattern_owners,
        )?;

        let trait_methods = collect_unique(
            input
                .trait_methods
                .into_iter()
                .map(|method| (method.key().clone(), method)),
            RuntimeSemanticFactFamily::TraitMethod,
        )?;
        for method in trait_methods.values() {
            validate_trait_method(&modules, method)?;
            if method.definition().validate_project(project).is_err() {
                return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
            }
            let owner = HirRuntimeExecutableOwner::ImplMethod(method.declaration().clone());
            if !runtime_owners.contains_runtime_owner(&owner) && method.instance_uses().is_empty() {
                return Err(RuntimeSemanticFactsError::OwnerOutsideReachability { owner });
            }
            if method.key().self_type() != method.self_type().identity() {
                return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
            }
            if let Some(semantics) = method.closed_semantics() {
                let catalog = semantics.local_uses();
                if catalog
                    .generation()
                    .validate_analysis_lease(project)
                    .is_err()
                    || catalog.generation().symbol_world()
                        != runtime_owners.runtime.identity().symbol_world()
                    || catalog.generation().symbol_revision()
                        != runtime_owners.runtime.identity().symbol_revision()
                    || !matches!(
                        catalog.instance_identity(),
                        Some(arcweft_lang_sema::final_analysis::CheckedLocalUseInstanceIdentity::DisplayText {
                            declaration,
                            self_type,
                        }) if declaration == &arcweft_lang_hir::symbol::CallableDeclarationKey::ImplMethod(
                            method.declaration().clone(),
                        ) && self_type.as_bytes() == method.key().self_type().as_bytes()
                    )
                {
                    return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
                }
                if semantics.partition().executable() != &owner
                    || !runtime_owners.admits_reachability(semantics.partition().reachability())
                {
                    return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
                }
                let callable = method
                    .closed_callable()
                    .ok_or(RuntimeSemanticFactsError::InvalidTraitMethodIdentity)?;
                let lexical_owner = RuntimeClosureLexicalOwner::TraitMethod(method.key().clone());
                validate_project_function_semantic_catalog(
                    &modules,
                    runtime_owners,
                    Some(&lexical_owner),
                    RuntimeExecutableLexicalAuthority::Callable(callable),
                    semantics,
                    None,
                )?;
                for projection in semantics.type_projection() {
                    if let Some(ty) = projection.ty() {
                        validate_normalized_type(&modules, ty)?;
                    }
                }
            } else if method.closed_callable().is_some()
                || method.definition().instance_identity().is_some()
                || !matches!(method.definition().environment().local_uses(),
                    CheckedLocalUseAuthority::Global(catalog)
                        if input.checked_local_uses.as_ref().is_none_or(|selected| selected == catalog)
                            && catalog.generation().symbol_world() == runtime_owners.runtime.identity().symbol_world()
                            && catalog.generation().symbol_revision() == runtime_owners.runtime.identity().symbol_revision()
                )
            {
                return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
            }
        }

        let iterations = collect_unique(input.iterations, RuntimeSemanticFactFamily::Iteration)?;
        if iterations
            .keys()
            .any(|owner| instance_statement_owners.contains(owner))
        {
            return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                family: RuntimeSemanticFactFamily::Iteration,
            });
        }
        for (statement, evidence) in &iterations {
            require_stmt_family(
                &modules,
                runtime_owners,
                *statement,
                RuntimeSemanticFactFamily::Iteration,
                |kind| matches!(kind, HirStmtKind::For(_)),
            )?;
            match evidence {
                RuntimeIteratorFact::Builtin(builtin) => {
                    for ty in [
                        builtin.item(),
                        builtin.iterator(),
                        builtin.next_value(),
                        builtin.step(),
                    ] {
                        validate_normalized_type(&modules, ty)?;
                    }
                }
                RuntimeIteratorFact::Witness(witness) => {
                    validate_normalized_type(&modules, witness.item())?;
                    validate_normalized_type(&modules, witness.iterator())?;
                }
            }
            validate_iterator_witness_method_edges(
                runtime_owners,
                *statement,
                match resolve_stmt(&modules, *statement)? {
                    HirStmtKind::For(for_stmt) => expression_types
                        .get(&for_stmt.source())
                        .ok_or(RuntimeSemanticFactsError::InvalidTraitMethodIdentity)?
                        .identity(),
                    _ => return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity),
                },
                evidence,
                &trait_methods,
            )?;
        }

        let assertions = collect_unique(input.assertions, RuntimeSemanticFactFamily::Assertion)?;
        if assertions
            .keys()
            .any(|owner| instance_statement_owners.contains(owner))
        {
            return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                family: RuntimeSemanticFactFamily::Assertion,
            });
        }
        for statement in assertions.keys() {
            require_stmt_family(
                &modules,
                runtime_owners,
                *statement,
                RuntimeSemanticFactFamily::Assertion,
                |kind| matches!(kind, HirStmtKind::Assertion { .. }),
            )?;
        }

        let triggers = input.triggers;
        let expected_triggers = modules
            .values()
            .flat_map(|module| module.statements().map(|(statement, _)| statement))
            .filter(|statement| runtime_owners.contains_statement(*statement))
            .filter(|statement| !instance_statement_owners.contains(statement))
            .filter(|statement| {
                matches!(
                    resolve_stmt(&modules, *statement),
                    Ok(HirStmtKind::On { .. } | HirStmtKind::CancelRule { .. })
                )
            })
            .collect::<BTreeSet<_>>();
        if triggers
            .keys()
            .any(|owner| instance_statement_owners.contains(owner))
        {
            return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                family: RuntimeSemanticFactFamily::Trigger,
            });
        }
        for statement in triggers.keys() {
            // HIR participates only in the reachable trigger owner-set check.
            // The checked trigger variant and payload were selected by the
            // compiler's exhaustive projection and are never reclassified
            // from `HirTrigger` here.
            require_stmt_family(
                &modules,
                runtime_owners,
                *statement,
                RuntimeSemanticFactFamily::Trigger,
                |kind| {
                    matches!(
                        kind,
                        HirStmtKind::On { .. } | HirStmtKind::CancelRule { .. }
                    )
                },
            )?;
        }
        if let Some(statement) = expected_triggers
            .iter()
            .find(|statement| !triggers.contains_key(statement))
        {
            return Err(RuntimeSemanticFactsError::MissingTriggerFact {
                statement: *statement,
            });
        }

        let evaluated_effects = collect_unique(
            input.evaluated_effects,
            RuntimeSemanticFactFamily::EvaluatedEffect,
        )?;
        if evaluated_effects
            .keys()
            .any(|owner| instance_expression_owners.contains(owner))
        {
            return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                family: RuntimeSemanticFactFamily::EvaluatedEffect,
            });
        }
        for (expression, effect) in &evaluated_effects {
            require_expr_family(
                &modules,
                runtime_owners,
                *expression,
                RuntimeSemanticFactFamily::EvaluatedEffect,
                |kind| matches!(kind, HirExprKind::Call(_) | HirExprKind::Pipe(_)),
            )?;
            let needs_pipe = matches!(resolve_expr(&modules, *expression)?, HirExprKind::Pipe(_))
                && !effect.effect().uses_pipe_address();
            if needs_pipe != pipes.contains_key(expression) {
                return Err(RuntimeSemanticFactsError::InvalidPipeFact {
                    expression: *expression,
                });
            }
            if expression_types
                .get(expression)
                .is_some_and(|ty| ty != effect.result())
            {
                return Err(RuntimeSemanticFactsError::InvalidEvaluatedEffectFact {
                    expression: *expression,
                });
            }
            evaluated_effect::validate_evaluated_effect(
                &modules,
                &expression_types,
                &calls,
                *expression,
                effect,
            )?;
        }

        let defers = collect_unique(input.defers, RuntimeSemanticFactFamily::Defer)?;
        let capture_authority = input.checked_local_uses.as_ref().map(|catalog| {
            arcweft_lang_sema::final_analysis::CheckedLocalUseAuthority::Global(Arc::clone(catalog))
        });
        if defers
            .keys()
            .any(|owner| instance_statement_owners.contains(owner))
        {
            return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                family: RuntimeSemanticFactFamily::Defer,
            });
        }
        for (statement, defer) in &defers {
            defer::validate_defer(
                &modules,
                runtime_owners,
                |local| local_declarations.get(local).and_then(|fact| fact.ty()),
                &expression_types,
                capture_authority.as_ref(),
                *statement,
                defer,
            )?;
        }

        let assignments = collect_unique(input.assignments, RuntimeSemanticFactFamily::Assignment)?;
        let expected_assignments = modules
            .values()
            .flat_map(|module| module.statements().map(|(statement, _)| statement))
            .filter(|statement| runtime_owners.contains_statement(*statement))
            .filter(|statement| !instance_statement_owners.contains(statement))
            .filter(|statement| {
                matches!(
                    resolve_stmt(&modules, *statement),
                    Ok(HirStmtKind::Assign { .. })
                )
            })
            .collect::<BTreeSet<_>>();
        if assignments
            .keys()
            .any(|owner| instance_statement_owners.contains(owner))
        {
            return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                family: RuntimeSemanticFactFamily::Assignment,
            });
        }
        if let Some(statement) = expected_assignments
            .iter()
            .find(|statement| !assignments.contains_key(statement))
        {
            return Err(RuntimeSemanticFactsError::MissingAssignmentFact {
                statement: *statement,
            });
        }
        for (statement, assignment) in &assignments {
            require_stmt_family(
                &modules,
                runtime_owners,
                *statement,
                RuntimeSemanticFactFamily::Assignment,
                |kind| matches!(kind, HirStmtKind::Assign { .. }),
            )?;
            validate_assignment(
                &modules,
                |local| local_declarations.get(local).and_then(|fact| fact.ty()),
                &expression_types,
                &values,
                local_uses
                    .get(
                        &arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Place(
                            match resolve_stmt(&modules, *statement)? {
                                HirStmtKind::Assign { target, .. } => *target,
                                _ => {
                                    return Err(RuntimeSemanticFactsError::InvalidAssignmentFact {
                                        statement: *statement,
                                    });
                                }
                            },
                        ),
                    )
                    .and_then(|access| access.place_access()),
                *statement,
                assignment,
            )?;
        }

        let registry_writes = collect_unique(
            input.registry_writes,
            RuntimeSemanticFactFamily::RegistryWrite,
        )?;
        for module in modules.values() {
            for (owner, statement) in module.statements() {
                if runtime_owners.contains_statement(owner)
                    && !instance_statement_owners.contains(&owner)
                    && matches!(statement.kind(), HirStmtKind::LifetimeSet { .. })
                    && !registry_writes.contains_key(&owner)
                {
                    return Err(RuntimeSemanticFactsError::MissingRegistryWriteFact {
                        statement: owner,
                    });
                }
            }
        }
        for (owner, write) in &registry_writes {
            if instance_statement_owners.contains(owner) {
                return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                    family: RuntimeSemanticFactFamily::RegistryWrite,
                });
            }
            require_stmt_family(
                &modules,
                runtime_owners,
                *owner,
                RuntimeSemanticFactFamily::RegistryWrite,
                |kind| matches!(kind, HirStmtKind::LifetimeSet { .. }),
            )?;
            write.validate(&modules, &expression_types, *owner)?;
        }

        let captures = type_projections
            .iter()
            .filter_map(|(owner, projection)| match owner {
                HirValueTypeOwner::Capture(owner) => {
                    projection.capture().map(|capture| (*owner, capture))
                }
                _ => None,
            })
            .collect::<BTreeMap<_, _>>();
        for (id, checked) in &captures {
            let id = *id;
            if instance_capture_owners.contains(&id) {
                return Err(RuntimeSemanticFactsError::InstanceOwnedGlobalFact {
                    family: RuntimeSemanticFactFamily::Capture,
                });
            }
            let capture = module_for(&modules, id.module())?
                .resolve_capture(id)
                .map_err(|_| RuntimeSemanticFactsError::UnresolvedCapture { capture: id })?;
            require_runtime_capture_owner(runtime_owners, id)?;
            if runtime_owners
                .executable_owners(&HirRuntimeExecutableOwner::CallableBody(capture.closure()))
                .is_none_or(|owners| !owners.capture_plan().contains(checked.projection()))
            {
                return Err(RuntimeSemanticFactsError::InvalidCaptureProjection { capture: id });
            }
            module_for(&modules, capture.local().module())?
                .resolve_local(capture.local())
                .map_err(|_| RuntimeSemanticFactsError::UnresolvedLocal {
                    local: capture.local(),
                })?;
            require_runtime_local_reference(runtime_owners, capture.local())?;
            if !checked.origin.validate_owner(project, checked.source()) {
                return Err(RuntimeSemanticFactsError::InvalidCaptureProjection { capture: id });
            }
            validate_normalized_type(&modules, checked.ty())?;
        }

        let pure_programs =
            validate_pure_programs(project, &modules, runtime_owners, input.pure_programs)?;
        for ty in &input.value_contract_types {
            validate_normalized_type(&modules, ty)?;
        }
        let dialogue_applications = input.dialogue_applications;
        let dialogue_content_fragments = input.dialogue_content_fragments;
        let mut fragment_ids = BTreeSet::new();
        let mut fragment_sources = BTreeSet::new();
        let mut fragment_templates = BTreeSet::new();
        for fragment in &dialogue_content_fragments {
            if !fragment_ids.insert(fragment.id())
                || !fragment_sources.insert(fragment.source())
                || !fragment_templates.insert(fragment.template().id())
            {
                return Err(RuntimeSemanticFactsError::DuplicateContentFragment {
                    expression: fragment.source(),
                });
            }
            require_runtime_expression_owner(
                runtime_owners,
                fragment.source(),
                RuntimeSemanticFactFamily::DialogueApplication,
            )?;
            for value in fragment.values() {
                require_runtime_expression_owner(
                    runtime_owners,
                    value.expression(),
                    RuntimeSemanticFactFamily::DialogueApplication,
                )?;
                validate_normalized_type(&modules, value.ty())?;
                validate_normalized_type(&modules, value.source_type())?;
                if expression_types.get(&value.expression()) != Some(value.source_type()) {
                    return Err(RuntimeSemanticFactsError::InvalidContentFragment {
                        expression: fragment.source(),
                    });
                }
            }
            for effect in fragment.effects() {
                if !validate_dialogue_effect_operation(
                    &modules,
                    &expression_types,
                    &calls,
                    effect.operation(),
                ) || effect.operation().evaluated_effect_operation().is_none()
                    && evaluated_effects.contains_key(&effect.operation().application())
                {
                    return Err(RuntimeSemanticFactsError::InvalidContentFragment {
                        expression: fragment.source(),
                    });
                }
                for capture in effect.captures() {
                    validate_normalized_type(&modules, capture.ty())?;
                    if local_declarations
                        .get(&capture.local())
                        .and_then(|fact| fact.ty())
                        != Some(capture.ty())
                        || capture_authority.as_ref().is_none_or(|authority| {
                            !capture.matches_authority(
                                arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Capture {
                                    owner: effect.operation().root(),
                                    local: capture.local(),
                                },
                                authority,
                            )
                        })
                    {
                        return Err(RuntimeSemanticFactsError::InvalidContentFragment {
                            expression: fragment.source(),
                        });
                    }
                }
            }
        }
        let mut global_mark_facts = BTreeMap::new();
        for fragment in &dialogue_content_fragments {
            for mark in fragment.marks() {
                if global_mark_facts
                    .insert(mark.coordinate().clone(), mark.key())
                    .is_some()
                {
                    return Err(RuntimeSemanticFactsError::InvalidContentFragment {
                        expression: fragment.source(),
                    });
                }
            }
        }
        for (statement, admission) in &triggers {
            let hir = resolve_stmt(&modules, *statement)?;
            if let HirStmtKind::CancelRule {
                trigger: HirCancelTrigger::InputAction(action),
                ..
            } = hir
            {
                if admission.input_action_id().map(|id| id.as_str()) != Some(action.as_str()) {
                    return Err(RuntimeSemanticFactsError::InvalidTriggerFact {
                        statement: *statement,
                    });
                }
            }
            match (hir, admission.dialogue_mark()) {
                (
                    HirStmtKind::On {
                        trigger: HirTrigger::Mark(source),
                        ..
                    },
                    Some(mark),
                ) if source.ordinal() == mark.coordinate().ordinal()
                    && global_mark_facts.get(mark.coordinate()) == Some(&mark.key()) => {}
                (
                    HirStmtKind::On {
                        trigger: HirTrigger::Mark(_),
                        ..
                    },
                    _,
                )
                | (_, Some(_)) => {
                    return Err(RuntimeSemanticFactsError::InvalidTriggerFact {
                        statement: *statement,
                    });
                }
                (_, None) => {}
            }
        }
        let mut duplicate_instance_template = None;
        for (scope, semantics) in instance_semantic_roots(
            project_function_instances.values(),
            root_closures.values(),
            trait_methods.values(),
            pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_content_fragments(scope, &mut |_, fragment| {
                if !fragment_templates.insert(fragment.template().id())
                    && duplicate_instance_template.is_none()
                {
                    duplicate_instance_template = Some(fragment.source());
                }
            });
        }
        if let Some(expression) = duplicate_instance_template {
            return Err(RuntimeSemanticFactsError::DuplicateContentFragment { expression });
        }
        let mut format_templates = BTreeMap::new();
        for template in input.format_templates {
            if !fragment_templates.insert(template.template().id())
                || format_templates
                    .insert(template.key().clone(), template)
                    .is_some()
            {
                return Err(RuntimeSemanticFactsError::DuplicateFact {
                    family: RuntimeSemanticFactFamily::FormatTemplate,
                });
            }
        }
        let dialogue_lines = input.dialogue_lines;
        let character_presentation_catalog = input.character_presentation_catalog;
        let character_dialogue_policy_types = input.character_dialogue_policy_types;
        let character_dialogue_generation = input.character_dialogue_generation;
        if let Some(declaration) = &character_dialogue_generation {
            character_dialogue_generation::validate_declaration(project, &modules, declaration)?;
        }
        let mut has_instance_dialogue = false;
        for (scope, semantics) in instance_semantic_roots(
            project_function_instances.values(),
            root_closures.values(),
            trait_methods.values(),
            pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics
                .visit_dialogue_applications(scope, &mut |_, _, _| has_instance_dialogue = true);
        }
        if (dialogue_applications.is_empty() && !has_instance_dialogue)
            != character_presentation_catalog.is_none()
        {
            return Err(RuntimeSemanticFactsError::DialogueCatalogPresenceMismatch);
        }

        let facts = Self {
            callable_sources,
            callable_specializations,
            expression_specializations,
            reachability: runtime_owners.runtime.identity().clone(),
            program_reachability: runtime_owners
                .programs
                .map(|owners| owners.identity().clone()),
            runtime_owners: runtime_owners.reachable_executables(),
            snapshots,
            nominal_definitions: BTreeMap::new(),
            local_declaration_order: expected_local_declarations
                .into_iter()
                .filter(|local| {
                    type_projections[&HirValueTypeOwner::Local(*local)]
                        .ty()
                        .is_some()
                })
                .collect(),
            type_projections,
            flows,
            includes,
            suspensions,
            expression_scopes,
            statement_scopes,
            thread_producers,
            call_producers,
            expression_facts,
            expression_children,
            expression_literals,
            expression_residual_values,
            pattern_literals,
            pattern_items,
            values,
            checked_local_uses: input.checked_local_uses,
            selects,
            nominal_records,
            pattern_nominal_records,
            expression_variants,
            pattern_variants,
            calls,
            postfix_candidates,
            trait_methods,
            iterations,
            assertions,
            triggers,
            assignments,
            registry_writes,
            evaluated_effects,
            defers,
            choices,
            awaits,
            tries: try_facts,
            implicit_callables,
            pipes,
            pure_programs,
            value_contract_types: input.value_contract_types,
            pure_program_semantics,
            project_function_instances,
            root_closures,
            project_function_roots,
            dialogue_applications,
            dialogue_content_fragments,
            format_templates,
            dialogue_lines,
            character_presentation_catalog,
            character_dialogue_policy_types,
            character_dialogue_generation,
        };
        for program in facts.pure_programs.values() {
            let semantics = facts.pure_program_semantics.get(&program.program()).ok_or(
                RuntimeSemanticFactsError::InvalidPureProgram {
                    program: program.program(),
                },
            )?;
            let lexical = RuntimeClosureLexicalOwner::Program(program.program());
            validate_project_function_semantic_catalog(
                &modules,
                runtime_owners,
                Some(&lexical),
                RuntimeExecutableLexicalAuthority::Program(program),
                semantics,
                None,
            )?;
            let scope = facts.program_scope(program)?;
            for (input, ty) in program.free_inputs() {
                if scope.local_type(input.binding().local()) != Some(ty) {
                    return Err(RuntimeSemanticFactsError::InvalidPureProgram {
                        program: program.program(),
                    });
                }
            }
            if let arcweft_lang_sema::final_analysis::CheckedExecutionSource::EvaluateValue(root) =
                program.source()
                && scope.expression_type(*root) != Some(program.result())
            {
                return Err(RuntimeSemanticFactsError::InvalidPureProgram {
                    program: program.program(),
                });
            }
        }
        display::validate_selected_format_catalog(&facts, runtime_owners)?;
        for owner in facts.expression_facts.keys() {
            if matches!(resolve_expr(&modules, *owner)?, HirExprKind::Closure(_))
                && !facts.is_pure_program_closure(*owner)
                && !facts.root_closures.contains_key(owner)
            {
                return Err(RuntimeSemanticFactsError::MissingClosureInstance {
                    expression: *owner,
                });
            }
        }
        for closure in facts.root_closures.values() {
            let callable = RuntimeCallableId::from_checked_digest(
                closure
                    .key()
                    .closure()
                    .owner()
                    .semantic_digest()
                    .into_bytes(),
            );
            validate_closure_instance(
                &modules,
                runtime_owners,
                None,
                RuntimeExecutableLexicalAuthority::Callable(&callable),
                RuntimeExecutableSemanticFactView::Global(&facts),
                closure.owner(),
                closure,
            )?;
        }
        if let Some(catalog) = facts.character_presentation_catalog.as_ref() {
            let dialogue_owners = RuntimeSemanticOwnerSet::runtime_only(runtime_owners.runtime);
            for (owner, application) in &facts.dialogue_applications {
                facts.validate_dialogue_application(
                    &modules,
                    dialogue_owners,
                    catalog,
                    *owner,
                    application,
                )?;
            }
            let lines = facts
                .dialogue_lines
                .as_deref()
                .ok_or(RuntimeSemanticFactsError::DialogueCatalogPresenceMismatch)?;
            for (_, semantics) in instance_semantic_roots(
                facts.project_function_instances.values(),
                facts.root_closures.values(),
                facts.trait_methods.values(),
                facts
                    .pure_program_semantics
                    .iter()
                    .map(|(program, semantics)| (*program, semantics)),
            ) {
                validate_project_instance_dialogue_applications(
                    &modules,
                    catalog,
                    lines,
                    facts.character_dialogue_generation().map(Arc::as_ref),
                    semantics,
                )?;
            }
        }
        Ok(facts)
    }

    fn validate_dialogue_application(
        &self,
        modules: &BTreeMap<HirModuleId, &HirModule>,
        runtime_owners: RuntimeSemanticOwnerSet<'_>,
        catalog: &CharacterPresentationCatalogData,
        owner: ExprId,
        application: &RuntimeDialogueApplication,
    ) -> Result<(), RuntimeSemanticFactsError> {
        let fragment = self
            .dialogue_content_fragments
            .iter()
            .find(|fragment| fragment.template().id() == application.content().template_id())
            .ok_or(RuntimeSemanticFactsError::DialogueTemplateMismatch { expression: owner })?;
        require_expr_family(
            modules,
            runtime_owners,
            owner,
            RuntimeSemanticFactFamily::DialogueApplication,
            |kind| {
                matches!(
                    kind,
                    HirExprKind::AttachedContentApplication(application)
                        if matches!(
                            application.family(),
                            arcweft_lang_hir::dialogue_application::HirAttachedContentApplicationFamily::DialogueLine {
                                ..
                            }
                        )
                )
            },
        )?;
        let accepted = self
            .dialogue_lines
            .as_ref()
            .and_then(|lines| lines.for_semantic_expr(owner))
            .ok_or(RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner })?;
        let accepted_runtime_line = RuntimeLineId::from_source_entity_body(accepted.id().as_str())
            .map_err(|_| RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner })?;
        if &accepted_runtime_line != application.content().line()
            || accepted.text_key().as_str() != application.content().text_key().as_str()
        {
            return Err(RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner });
        }
        require_runtime_expression_owner(
            runtime_owners,
            application.target().expression(),
            RuntimeSemanticFactFamily::DialogueApplication,
        )?;
        application.validate_target(
            modules,
            owner,
            self.expression_type(application.target().expression()),
        )?;
        validate_normalized_type(modules, application.line_result())?;
        for (statement, output_application) in application.result_outputs() {
            if *output_application != owner {
                return Err(RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner });
            }
            require_runtime_statement_owner(
                runtime_owners,
                *statement,
                RuntimeSemanticFactFamily::DialogueApplication,
            )?;
            let HirStmtKind::Out { value, .. } = resolve_stmt(modules, *statement)? else {
                return Err(RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner });
            };
            if self.expression_type(*value) != Some(application.line_result()) {
                return Err(RuntimeSemanticFactsError::MissingDialogueValueType {
                    dialogue: owner,
                    value: *value,
                });
            }
        }
        if application.content().character().semantic_digest() != catalog.semantic_digest() {
            return Err(RuntimeSemanticFactsError::DialogueCharacterPlanMismatch {
                expression: owner,
            });
        }
        character_dialogue_generation::validate_application(
            owner,
            application,
            catalog,
            self.character_dialogue_generation().map(Arc::as_ref),
        )?;
        for (index, value) in fragment.values().iter().enumerate() {
            let expected = RuntimeDialogueValueSlotId::from_zero_based(index).ok_or(
                RuntimeSemanticFactsError::TooManyDialogueValueSlots { expression: owner },
            )?;
            if value.slot() != expected {
                return Err(RuntimeSemanticFactsError::NonCanonicalDialogueValueSlot {
                    expression: owner,
                    expected,
                    actual: value.slot(),
                });
            }
            resolve_expr(modules, value.expression())?;
            require_runtime_expression_owner(
                runtime_owners,
                value.expression(),
                RuntimeSemanticFactFamily::DialogueApplication,
            )?;
            if self.expression_type(value.expression()) != Some(value.source_type()) {
                return Err(RuntimeSemanticFactsError::MissingDialogueValueType {
                    dialogue: owner,
                    value: value.expression(),
                });
            }
        }
        for (index, effect) in fragment.effects().iter().enumerate() {
            let expected =
                arcweft_core::runtime_id::RuntimeDialogueEffectSiteId::from_zero_based(index)
                    .ok_or(RuntimeSemanticFactsError::TooManyDialogueValueSlots {
                        expression: owner,
                    })?;
            let trigger_valid = match effect.trigger() {
                RuntimeDialogueEffectTrigger::Content => true,
                RuntimeDialogueEffectTrigger::Delay {
                    duration_type,
                    schedule_handle_type,
                    ..
                } => {
                    matches!(duration_type.shape(), RuntimeTypeShape::Duration)
                        && validate_normalized_type(modules, duration_type).is_ok()
                        && validate_normalized_type(modules, schedule_handle_type).is_ok()
                }
            };
            if effect.site() != expected
                || !trigger_valid
                || !self.expression_reaches(owner, effect.operation().root())
                || !(effect.operation().root() == effect.operation().application()
                    || self.expression_reaches(
                        effect.operation().root(),
                        effect.operation().application(),
                    ))
                || !validate_dialogue_effect_operation(
                    modules,
                    &RuntimeExpressionTypeView::Facts(&self.type_projections),
                    &self.calls,
                    effect.operation(),
                )
                || effect.operation().evaluated_effect_operation().is_none()
                    && self
                        .evaluated_effect(effect.operation().application())
                        .is_some()
            {
                return Err(RuntimeSemanticFactsError::InvalidDialogueEffectSite {
                    dialogue: owner,
                    site: effect.site(),
                });
            }
        }
        Ok(())
    }

    fn expression_reaches(&self, owner: ExprId, target: ExprId) -> bool {
        let mut pending = self.expression_children(owner).to_vec();
        let mut visited = BTreeSet::new();
        while let Some(expression) = pending.pop() {
            if expression == target {
                return true;
            }
            if visited.insert(expression) {
                pending.extend_from_slice(self.expression_children(expression));
            }
        }
        false
    }

    /// Revalidates that the facts are consumed by the exact generation that
    /// admitted them. Stable IDs surviving a reload do not make stale facts valid.
    pub fn validate_generation(
        &self,
        project: HirAnalysisProjectView<'_>,
    ) -> Result<(), RuntimeSemanticFactsError> {
        let actual = project
            .modules()
            .map(|(_, module)| (module.module_id(), module.snapshot_id()))
            .collect::<BTreeMap<_, _>>();
        if actual != self.snapshots {
            return Err(RuntimeSemanticFactsError::WrongProjectGeneration);
        }
        let mut valid = true;
        let mut pending = self.all_normalized_type_roots();
        while let Some(ty) = pending.pop() {
            if let RuntimeTypeShape::Nominal { nominal, .. } = ty.shape() {
                valid &= nominal.valid_for_project(project);
            }
            pending.extend(ty.children());
        }
        for record in self.nominal_records.values() {
            valid &= record.nominal().nominal().valid_for_project(project);
        }
        for record in self
            .pattern_nominal_records
            .values()
            .filter_map(RuntimeRecordPatternFact::nominal)
        {
            valid &= record.nominal().valid_for_project(project);
        }
        self.visit_variant_owners(&mut |owner| {
            if let RuntimeVariantOwner::Nominal { nominal, .. } = owner {
                valid &= nominal.valid_for_project(project);
            }
        });
        self.visit_scoped_calls(&mut |_, owner, call| {
            if let Some(application) = call.external_application() {
                valid &= application.origin().validate_owner(project, owner);
            }
        });
        if valid {
            Ok(())
        } else {
            Err(RuntimeSemanticFactsError::WrongProjectGeneration)
        }
    }

    pub fn expression_literal(&self, expression: ExprId) -> Option<&RuntimeValue> {
        self.expression_literals.get(&expression).or_else(|| {
            self.expression_residual_values
                .get(&expression)
                .map(RuntimeResidualValue::value)
        })
    }

    /// Returns the exact checked compile-time call application that produced
    /// one residualized runtime value.
    pub fn expression_residual_value(&self, expression: ExprId) -> Option<&RuntimeResidualValue> {
        self.expression_residual_values.get(&expression)
    }

    /// Returns the sole accepted normalized type of one selected runtime-domain
    /// final-HIR expression.
    pub fn call_producer(
        &self,
        expression: ExprId,
    ) -> Option<&arcweft_lang_sema::CheckedExpressionProducerDefinition> {
        self.call_producers.get(&expression)
    }
    pub fn thread_producer(
        &self,
        expression: ExprId,
    ) -> Option<&arcweft_lang_sema::CheckedExpressionProducerDefinition> {
        self.thread_producers.get(&expression)
    }
    pub fn expression_type(&self, expression: ExprId) -> Option<&RuntimeNormalizedType> {
        self.type_projections
            .get(&HirValueTypeOwner::Expression(expression))
            .and_then(RuntimeExecutableTypeProjection::ty)
    }

    pub fn expression_coordinate(
        &self,
        expression: ExprId,
    ) -> Option<&arcweft_lang_sema::semantic_coordinate::CheckedSemanticPath> {
        self.expression_facts
            .get(&expression)
            .map(|fact| fact.origin.coordinate())
    }

    /// Returns the sole accepted normalized type of one runtime-domain
    /// final-HIR pattern.
    pub fn pattern_type(&self, pattern: PatternId) -> Option<&RuntimeNormalizedType> {
        self.type_projections
            .get(&HirValueTypeOwner::Pattern(pattern))
            .and_then(RuntimeExecutableTypeProjection::ty)
    }

    /// Sole accepted normalized semantic type of one runtime-domain final-HIR
    /// local.
    pub fn local_type(&self, local: LocalId) -> Option<&RuntimeNormalizedType> {
        self.type_projections
            .get(&HirValueTypeOwner::Local(local))
            .and_then(RuntimeExecutableTypeProjection::ty)
    }

    pub fn local_context(&self, local: LocalId) -> Option<&RuntimeNormalizedType> {
        self.type_projections
            .get(&HirValueTypeOwner::Local(local))
            .and_then(RuntimeExecutableTypeProjection::local_context)
    }

    pub fn local_origin(
        &self,
        local: LocalId,
    ) -> Option<&arcweft_lang_sema::semantic_coordinate::CheckedLocalBindingOrigin> {
        self.type_projections
            .get(&HirValueTypeOwner::Local(local))
            .and_then(RuntimeExecutableTypeProjection::local_origin)
    }

    /// Runtime-domain locals in canonical final-HIR inventory order.
    ///
    /// # Panics
    ///
    /// Panics only if accepted local-order metadata is inconsistent with the
    /// corresponding local fact map.
    pub fn local_declarations(
        &self,
    ) -> impl ExactSizeIterator<Item = (LocalId, &RuntimeNormalizedType)> {
        self.local_declaration_order.iter().map(|local| {
            (
                *local,
                self.local_type(*local)
                    .expect("accepted local order and fact map remain correlated"),
            )
        })
    }

    /// Complete recursive semantic type batch required by the aggregate plan
    /// builder. Duplicate identities remain in traversal order so the sole
    /// interner can reject inconsistent projections atomically.
    pub fn runtime_plan_type_seeds(
        &self,
    ) -> Result<Vec<RuntimePlanTypeSeed>, RuntimeCheckedTypeProjectionError> {
        let mut seeds = Vec::new();
        for ty in self.all_normalized_type_roots() {
            ty.append_runtime_plan_type_seeds(&mut seeds)?;
        }
        seeds.extend(
            self.nominal_definitions
                .values()
                .filter_map(RuntimeNominalDefinition::closed_owner_type_seed),
        );
        if let Some(policy_types) = &self.character_dialogue_policy_types {
            seeds.extend(policy_types.type_seeds());
        }
        Ok(seeds)
    }

    /// Borrows source-issued nominal documents carried by the selected facts.
    /// The plan builder consumes their joined proof against its candidate rows.
    pub fn runtime_plan_nominal_schema(
        &self,
    ) -> Result<RuntimeNominalSchemaGraph, RuntimeNominalSchemaGraphError> {
        let mut graphs = Vec::new();
        let mut pending = self.all_normalized_type_roots();
        while let Some(ty) = pending.pop() {
            if let RuntimeTypeShape::Nominal { nominal, .. } = ty.shape() {
                graphs.push(Arc::clone(nominal.source_graph()));
            }
            pending.extend(ty.children());
        }
        for record in self.nominal_records.values() {
            graphs.push(Arc::clone(record.nominal().nominal().source_graph()));
        }
        for record in self
            .pattern_nominal_records
            .values()
            .filter_map(RuntimeRecordPatternFact::nominal)
        {
            graphs.push(Arc::clone(record.nominal().source_graph()));
        }
        self.visit_variant_owners(&mut |owner| match owner {
            RuntimeVariantOwner::Nominal { nominal, .. } => {
                graphs.push(Arc::clone(nominal.source_graph()))
            }
            RuntimeVariantOwner::CharacterNominal { source_graph, .. }
            | RuntimeVariantOwner::BuiltinClosed { source_graph, .. } => {
                graphs.push(Arc::clone(source_graph))
            }
            RuntimeVariantOwner::RuntimeBuiltin { .. }
            | RuntimeVariantOwner::Option { .. }
            | RuntimeVariantOwner::Result { .. } => {}
        });
        if let Some(policy_types) = &self.character_dialogue_policy_types {
            graphs.push(Arc::clone(policy_types.schema_graph()));
        }
        RuntimeNominalSchemaGraph::try_merge(
            graphs.iter().map(Arc::as_ref),
            RuntimeSchemaLimits::engine_default(),
        )
    }

    /// Complete source-owned record definitions, independent of expression use.
    pub fn runtime_plan_nominal_record_domain_seeds(&self) -> Vec<RuntimeNominalRecordDomainSeed> {
        self.nominal_definitions
            .values()
            .filter_map(RuntimeNominalDefinition::record_seed)
            .collect()
    }
    /// Complete non-Option/Result variant schemas. Repeated owners remain in
    /// the batch for exact builder-level conflict validation.
    pub fn runtime_plan_variant_domain_seeds(&self) -> Vec<RuntimeVariantDomainSeed> {
        let mut seeds = self
            .nominal_definitions
            .values()
            .filter_map(RuntimeNominalDefinition::variant_seed)
            .collect::<Vec<_>>();
        if let Some(policy_types) = &self.character_dialogue_policy_types {
            seeds.extend(policy_types.variant_domain_seeds());
        }
        seeds
    }

    fn visit_variant_owners(&self, visit: &mut impl FnMut(&RuntimeVariantOwner)) {
        for variant in self
            .expression_variants
            .values()
            .chain(self.pattern_variants.values())
            .chain(
                self.calls
                    .values()
                    .filter_map(|call| match call.dispatch() {
                        RuntimeResolvedCallDispatch::Static(
                            RuntimeResolvedStaticCallTarget::Variant(variant),
                        ) => Some(variant),
                        _ => None,
                    }),
            )
        {
            visit(variant.owner());
        }
        for (_, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_catalogs(&mut |catalog| {
                for row in catalog.expressions() {
                    let variant = match row.payload() {
                        RuntimeProjectFunctionExpressionPayload::Variant(variant) => Some(variant),
                        RuntimeProjectFunctionExpressionPayload::Call(call) => {
                            match call.dispatch() {
                                RuntimeResolvedCallDispatch::Static(
                                    RuntimeResolvedStaticCallTarget::Variant(variant),
                                ) => Some(variant),
                                _ => None,
                            }
                        }
                        _ => None,
                    };
                    if let Some(variant) = variant {
                        visit(variant.owner());
                    }
                }
                for row in catalog.patterns() {
                    if let Some(variant) = catalog.pattern_variant(row.owner()) {
                        visit(variant.owner());
                    }
                }
            });
        }
    }

    fn all_normalized_type_roots(&self) -> Vec<&RuntimeNormalizedType> {
        let mut roots = Vec::new();
        for source in self.callable_sources.values() {
            source.append_normalized_types(&mut roots);
        }
        for specialization in self.callable_specializations.values() {
            specialization.append_normalized_types(&mut roots);
        }
        if let Some(declaration) = self.character_dialogue_generation() {
            declaration.visit_type_refs(&mut |ty| roots.push(ty));
        }
        for definition in self.nominal_definitions.values() {
            definition.append_types(&mut roots);
        }
        for projection in self.type_projections.values() {
            roots.extend(projection.ty());
            roots.extend(projection.local_context());
        }
        roots.extend(self.flows.values().map(RuntimeFlowFact::function_type));
        roots.extend(self.value_contract_types.iter());
        for scope in self
            .expression_scopes
            .values()
            .chain(self.statement_scopes.values())
        {
            scope.append_normalized_types(&mut roots);
        }
        for program in self.pure_programs.values() {
            roots.push(program.function_type());
            roots.extend(program.input_types());
            roots.push(program.result());
        }
        for semantics in self.pure_program_semantics.values() {
            semantics.append_normalized_types(&mut roots);
        }
        for call in self.calls.values() {
            call.append_normalized_types(&mut roots);
        }
        for value in self.values.values() {
            value.append_normalized_types(&mut roots);
        }
        for instance in self.project_function_instances.values() {
            instance.append_normalized_types(&mut roots);
        }
        for closure in self.root_closures.values() {
            closure.append_normalized_types(&mut roots);
        }
        for application in self.dialogue_applications.values() {
            application.append_normalized_types(&mut roots);
        }
        for fragment in &self.dialogue_content_fragments {
            fragment.append_normalized_types(&mut roots);
            roots.extend(
                fragment
                    .values()
                    .iter()
                    .map(RuntimeDialogueValueExpression::source_type),
            );
        }
        for effect in self.evaluated_effects.values() {
            roots.push(effect.result());
            effect
                .effect()
                .visit_operand_types(&mut |ty| roots.push(ty));
        }
        for defer in self.defers.values() {
            roots.extend(
                defer
                    .captures()
                    .iter()
                    .map(RuntimeExecutableCaptureFact::ty),
            );
        }
        for record in self.nominal_records.values() {
            record.append_normalized_types(&mut roots);
        }
        for record in self.pattern_nominal_records.values() {
            record.append_normalized_types(&mut roots);
        }
        for assignment in self.assignments.values() {
            roots.push(assignment.value_type());
        }
        roots.extend(
            self.registry_writes
                .values()
                .map(RuntimeRegistryWriteFact::value_type),
        );
        for tried in self.tries.values() {
            tried.append_normalized_types(&mut roots);
        }
        for callable in self.implicit_callables.values() {
            roots.extend([callable.parameter(), callable.result()]);
        }
        roots.extend(
            self.trait_methods
                .values()
                .map(RuntimeTraitMethodFact::self_type),
        );
        for method in self.trait_methods.values() {
            if let Some(semantics) = method.closed_semantics() {
                semantics.visit_type_projections(&mut |projection| {
                    roots.extend(projection.ty());
                });
            }
        }
        for iteration in self.iterations.values() {
            iteration.append_normalized_types(&mut roots);
        }
        for variant in self
            .expression_variants
            .values()
            .chain(self.pattern_variants.values())
        {
            variant.owner().append_normalized_types(&mut roots);
        }
        roots
    }

    /// Compiler-admitted identity and closed effects for one exact final-HIR Flow item.
    pub fn flow(&self, item: ItemId) -> Option<&RuntimeFlowFact> {
        self.flows.get(&item)
    }

    pub fn pattern_literal(&self, pattern: PatternId) -> Option<&RuntimeValue> {
        self.pattern_literals.get(&pattern)
    }

    pub fn pattern_entity(
        &self,
        pattern: PatternId,
    ) -> Option<&arcweft_lang_sema::final_analysis::CheckedEntityPatternProjection> {
        self.pattern_items.get(&pattern)
    }

    pub fn value(&self, expression: ExprId) -> Option<&RuntimeResolvedValue> {
        self.values.get(&expression)
    }

    pub fn checked_local_value_transfer(
        &self,
        site: arcweft_lang_sema::final_analysis::CheckedLocalUseSite,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer> {
        self.checked_local_uses.as_ref()?.value_transfer_at(site)
    }

    pub fn checked_local_place_access(
        &self,
        source: ExprId,
    ) -> Option<&arcweft_lang_sema::final_analysis::CheckedLocalPlaceAccess> {
        self.checked_local_uses
            .as_ref()?
            .access_at(arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Place(source))?
            .place_access()
    }

    pub fn checked_guard_copy_locals(&self, guard: ExprId) -> Vec<LocalId> {
        self.checked_local_uses
            .as_ref()
            .map(|catalog| catalog.guard_copy_locals(guard).collect())
            .unwrap_or_default()
    }

    pub fn checked_captures_at(
        &self,
        owner: ExprId,
    ) -> impl Iterator<Item = arcweft_lang_sema::final_analysis::CheckedLocalValueTransfer> + '_
    {
        self.checked_local_uses
            .iter()
            .flat_map(move |catalog| catalog.captures_at(owner))
    }

    pub fn checked_synthetic_use(
        &self,
        expression: ExprId,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedSyntheticUse> {
        self.checked_local_uses.as_ref()?.synthetic_at(expression)
    }

    pub fn checked_copy_requirement(
        &self,
        local: LocalId,
    ) -> Option<&arcweft_lang_sema::final_analysis::CheckedLocalCopyRequirement> {
        self.checked_local_uses.as_ref()?.copy_requirement(local)
    }

    pub fn checked_synthetic_copy_requirement(
        &self,
        callable: arcweft_lang_sema::final_analysis::CheckedImplicitCallableIdentity,
    ) -> Option<arcweft_lang_sema::final_analysis::CheckedSyntheticCopyRequirement> {
        self.checked_local_uses
            .as_ref()?
            .synthetic_copy_requirement(callable)
    }

    pub fn select(&self, expression: ExprId) -> Option<&RuntimeResolvedSelect> {
        self.selects.get(&expression)
    }

    pub fn nominal_record(&self, expression: ExprId) -> Option<&RuntimeRecordExpressionFact> {
        self.nominal_records.get(&expression)
    }

    pub fn pattern_nominal_record(&self, pattern: PatternId) -> Option<&RuntimeRecordPatternFact> {
        self.pattern_nominal_records.get(&pattern)
    }

    pub fn expression_variant(&self, expression: ExprId) -> Option<&RuntimeResolvedVariant> {
        self.expression_variants.get(&expression)
    }

    pub fn pattern_variant(&self, pattern: PatternId) -> Option<&RuntimeResolvedVariant> {
        self.pattern_variants.get(&pattern)
    }

    pub fn ty(&self, ty: TypeId) -> Option<&RuntimeNormalizedType> {
        self.type_projections
            .get(&HirValueTypeOwner::Type(ty))
            .and_then(RuntimeExecutableTypeProjection::ty)
    }

    pub fn semantic_value_type(
        &self,
        owner: HirValueTypeOwner,
    ) -> Option<&arcweft_lang_sema::types::CompileTimeCallableType> {
        self.type_projections
            .get(&owner)
            .and_then(RuntimeExecutableTypeProjection::semantic_value_type)
    }

    pub fn call(&self, expression: ExprId) -> Option<&RuntimeResolvedCall> {
        self.calls.get(&expression)
    }

    pub fn expression_specialization(
        &self,
        owner: ExprId,
    ) -> Option<&RuntimeCallableValueSpecialization> {
        self.expression_specializations.get(&owner)
    }
    pub fn callable_source(
        &self,
        key: &RuntimeProjectCallableSourceKey,
    ) -> Option<&RuntimeProjectCallableSourceFact> {
        self.callable_sources.get(key)
    }
    pub fn callable_sources(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeProjectCallableSourceFact> {
        self.callable_sources.values()
    }
    pub fn callable_specialization(
        &self,
        key: &RuntimeCallableSpecializationKey,
    ) -> Option<&RuntimeCallableSpecializationFact> {
        self.callable_specializations.get(key)
    }
    pub fn callable_specializations(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeCallableSpecializationFact> {
        self.callable_specializations.values()
    }

    /// Iterates accepted runtime call facts in canonical expression identity order.
    pub fn calls(&self) -> impl ExactSizeIterator<Item = (ExprId, &RuntimeResolvedCall)> {
        self.calls.iter().map(|(owner, call)| (*owner, call))
    }

    pub fn project_function_instance(
        &self,
        key: &RuntimeProjectFunctionInstanceKey,
    ) -> Option<&RuntimeProjectFunctionInstanceFact> {
        self.project_function_instances.get(key)
    }

    pub fn project_function_instances(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeProjectFunctionInstanceFact> {
        self.project_function_instances.values()
    }

    pub fn root_closure(&self, owner: ExprId) -> Option<&RuntimeClosureInstanceFact> {
        self.root_closures.get(&owner)
    }

    pub fn root_closures(&self) -> impl ExactSizeIterator<Item = &RuntimeClosureInstanceFact> {
        self.root_closures.values()
    }

    pub fn project_function_roots(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeProjectFunctionRootFact> {
        self.project_function_roots.values()
    }

    /// Returns the checked non-call ingress for one runtime callable. Multiple
    /// Entry declarations may share the same row, but admission guarantees
    /// that they all name the same closed instance key.
    pub fn project_function_root_for_callable(
        &self,
        callable: &RuntimeCallableId,
    ) -> Option<&RuntimeProjectFunctionRootFact> {
        self.project_function_roots
            .values()
            .find(|root| root.instance().callable() == callable)
    }

    /// Returns the sole checked candidate selected for one postfix root.
    pub fn postfix_candidate(&self, expression: ExprId) -> Option<ExprId> {
        self.postfix_candidates.get(&expression).copied()
    }

    /// Returns the accepted owning children retained for runtime lowering.
    pub fn expression_children(&self, expression: ExprId) -> &[ExprId] {
        self.expression_children
            .get(&expression)
            .map_or(&[], Box::as_ref)
    }

    pub fn iteration(&self, statement: StmtId) -> Option<&RuntimeIteratorFact> {
        self.iterations.get(&statement)
    }

    pub fn trait_methods(&self) -> impl ExactSizeIterator<Item = &RuntimeTraitMethodFact> {
        self.trait_methods.values()
    }

    /// The program's own sealed executable catalog, independent of ordinary call reachability.
    pub(crate) fn program_scope<'facts>(
        &'facts self,
        program: &RuntimePureProgramFact,
    ) -> Result<RuntimeScopedExecutableSemanticFactView<'facts>, RuntimeSemanticFactsError> {
        let semantics = self.pure_program_semantics.get(&program.program()).ok_or(
            RuntimeSemanticFactsError::InvalidPureProgram {
                program: program.program(),
            },
        )?;
        if semantics.partition().executable() != &program.reachability_owner()
            || semantics.local_uses() != program.admission().input_abi().environment().local_uses()
        {
            return Err(RuntimeSemanticFactsError::InvalidPureProgram {
                program: program.program(),
            });
        }
        Ok(RuntimeScopedExecutableSemanticFactView::program(
            program.program(),
            semantics,
        ))
    }

    pub(crate) fn pure_program_semantics(
        &self,
    ) -> impl ExactSizeIterator<
        Item = (
            &RuntimePureProgramId,
            &RuntimeProjectFunctionInstanceSemanticFacts,
        ),
    > {
        self.pure_program_semantics.iter()
    }

    pub fn trait_method(
        &self,
        key: &RuntimeTraitMethodInstanceKey,
    ) -> Option<&RuntimeTraitMethodFact> {
        self.trait_methods.get(key)
    }

    pub fn assertion(&self, statement: StmtId) -> Option<RuntimeAssertionAdmission> {
        self.assertions.get(&statement).copied()
    }

    pub(crate) fn trigger(&self, statement: StmtId) -> Option<&RuntimeTriggerAdmission> {
        self.triggers.get(&statement)
    }

    /// Returns the sole compiler-admitted writable place for an assignment.
    pub fn assignment(&self, statement: StmtId) -> Option<&RuntimeAssignmentFact> {
        self.assignments.get(&statement)
    }

    pub fn registry_write(&self, statement: StmtId) -> Option<&RuntimeRegistryWriteFact> {
        self.registry_writes.get(&statement)
    }

    pub fn evaluated_effect(&self, expression: ExprId) -> Option<&RuntimeEvaluatedEffectFact> {
        self.evaluated_effects.get(&expression)
    }

    pub fn defer(&self, statement: StmtId) -> Option<&RuntimeDeferFact> {
        self.defers.get(&statement)
    }

    pub fn defers(&self) -> impl ExactSizeIterator<Item = (StmtId, &RuntimeDeferFact)> {
        self.defers.iter().map(|(owner, fact)| (*owner, fact))
    }

    pub fn awaited(&self, expression: ExprId) -> Option<&RuntimeAwaitFact> {
        self.awaits.get(&expression)
    }

    pub fn choice(&self, expression: ExprId) -> Option<&RuntimeChoiceFact> {
        self.choices.get(&expression)
    }

    pub fn awaits(&self) -> impl ExactSizeIterator<Item = (&ExprId, &RuntimeAwaitFact)> {
        self.awaits.iter()
    }

    pub fn tried(&self, expression: ExprId) -> Option<&RuntimeTryFact> {
        self.tries.get(&expression)
    }

    pub fn tries(&self) -> impl ExactSizeIterator<Item = (&ExprId, &RuntimeTryFact)> {
        self.tries.iter()
    }

    pub fn implicit_callable(&self, expression: ExprId) -> Option<&RuntimeImplicitCallableFact> {
        self.implicit_callables.get(&expression)
    }

    pub fn implicit_callables(
        &self,
    ) -> impl ExactSizeIterator<Item = (&ExprId, &RuntimeImplicitCallableFact)> {
        self.implicit_callables.iter()
    }

    pub fn pipe(&self, expression: ExprId) -> Option<&RuntimePipeFact> {
        self.pipes.get(&expression)
    }

    pub fn pipes(&self) -> impl ExactSizeIterator<Item = (&ExprId, &RuntimePipeFact)> {
        self.pipes.iter()
    }

    pub fn capture(&self, capture: CaptureId) -> Option<&RuntimeCheckedCapture> {
        self.type_projections
            .get(&HirValueTypeOwner::Capture(capture))
            .and_then(RuntimeExecutableTypeProjection::capture)
    }

    pub fn pure_programs(
        &self,
    ) -> impl ExactSizeIterator<Item = (&RuntimePureProgramId, &RuntimePureProgramFact)> {
        self.pure_programs.iter()
    }

    pub fn is_pure_program_closure(&self, closure: ExprId) -> bool {
        self.pure_programs.values().any(|program| {
            program.reachability_owner() == HirRuntimeExecutableOwner::CallableBody(closure)
        })
    }

    pub const fn program_reachability(&self) -> Option<&HirRuntimeReachabilityIdentity> {
        self.program_reachability.as_ref()
    }

    pub fn dialogue_application(&self, expression: ExprId) -> Option<&RuntimeDialogueApplication> {
        self.dialogue_applications.get(&expression)
    }

    pub fn dialogue_applications(
        &self,
    ) -> impl ExactSizeIterator<Item = (&ExprId, &RuntimeDialogueApplication)> {
        self.dialogue_applications.iter()
    }

    /// Visits every global or closed-instance dialogue application together
    /// with its exact lexical semantic scope and catalog.
    pub fn visit_dialogue_applications<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(
            RuntimeScopedExecutableSemanticFactView<'facts>,
            ExprId,
            &'facts RuntimeDialogueApplication,
        ),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        for (owner, application) in &self.dialogue_applications {
            visitor(global, *owner, application);
        }
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_dialogue_applications(scope, visitor);
        }
    }

    /// Generation-global immutable template rows. Use
    /// [`Self::visit_dialogue_content_fragments`] for the complete plan-wide
    /// catalog, including closed project instances and nested closures.
    pub fn dialogue_content_fragments(&self) -> &[RuntimeContentFragmentFact] {
        &self.dialogue_content_fragments
    }

    pub fn format_template(
        &self,
        key: &RuntimeFormatTemplateKey,
    ) -> Option<&RuntimeFormatTemplateFact> {
        self.format_templates.get(key)
    }

    pub fn format_templates(&self) -> impl ExactSizeIterator<Item = &RuntimeFormatTemplateFact> {
        self.format_templates.values()
    }

    pub fn visit_dialogue_content_fragments<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(
            RuntimeScopedExecutableSemanticFactView<'facts>,
            &'facts RuntimeContentFragmentFact,
        ),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        for fragment in &self.dialogue_content_fragments {
            visitor(global, fragment);
        }
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_content_fragments(scope, visitor);
        }
    }

    pub(crate) fn visit_callable_values<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(
            ExprId,
            &'facts RuntimeResolvedValue,
            Option<&'facts RuntimeNormalizedType>,
        ),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        for (owner, value) in &self.values {
            visitor(*owner, value, global.expression_source_type(*owner));
        }
        for (_, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_callable_values(visitor);
        }
    }

    /// Visits selected expression owners under their exact closed catalog.
    /// Construction frame selection uses the same accepted child relation.
    pub(crate) fn visit_scoped_expression_owners<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(RuntimeScopedExecutableSemanticFactView<'facts>, ExprId),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        global
            .facts()
            .visit_expression_owners(&mut |owner| visitor(global, owner));
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            scope
                .facts()
                .visit_expression_owners(&mut |owner| visitor(scope, owner));
            semantics.visit_closure_instances(&mut |closure| {
                let nested = RuntimeScopedExecutableSemanticFactView::closure(
                    closure.key(),
                    closure.semantics(),
                );
                nested
                    .facts()
                    .visit_expression_owners(&mut |owner| visitor(nested, owner));
            });
        }
    }

    /// Visits each defer under its exact closed executable catalog.
    pub(crate) fn visit_scoped_defers<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(
            RuntimeScopedExecutableSemanticFactView<'facts>,
            StmtId,
            &'facts RuntimeDeferFact,
        ),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        for (statement, fact) in self.defers() {
            visitor(global, statement, fact);
        }
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_scoped_defers(scope, visitor);
        }
    }
    /// Visits each selected call with the exact global, closed project-
    /// function, or closure semantic catalog that owns it.
    ///
    /// Nested closures retain their own closure identity, and each selected
    /// call is visited once in its executable catalog.
    pub fn visit_scoped_calls<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(
            RuntimeScopedExecutableSemanticFactView<'facts>,
            ExprId,
            &'facts RuntimeResolvedCall,
        ),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        for (owner, call) in &self.calls {
            visitor(global, *owner, call);
        }
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_scoped_calls(scope, visitor);
        }
    }

    pub(crate) fn visit_includes<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(&'facts arcweft_lang_sema::final_analysis::CheckedIncludeFlowTarget),
    ) {
        for target in self.includes.values() {
            visitor(target);
        }
        for (_, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_includes(visitor);
        }
    }

    /// Visits implicit callables under the exact executable catalog that
    /// sealed each abstraction. The same HIR expression may occur in several
    /// closed generic instances and therefore is not a site identity alone.
    pub fn visit_scoped_implicit_callables<'facts>(
        &'facts self,
        visitor: &mut impl FnMut(
            RuntimeScopedExecutableSemanticFactView<'facts>,
            ExprId,
            &'facts RuntimeImplicitCallableFact,
        ),
    ) {
        let global = RuntimeScopedExecutableSemanticFactView::global(self);
        for (owner, callable) in &self.implicit_callables {
            visitor(global, *owner, callable);
        }
        for (scope, semantics) in instance_semantic_roots(
            self.project_function_instances.values(),
            self.root_closures.values(),
            self.trait_methods.values(),
            self.pure_program_semantics
                .iter()
                .map(|(program, semantics)| (*program, semantics)),
        ) {
            semantics.visit_scoped_implicit_callables(scope, visitor);
        }
    }

    pub fn dialogue_content_fragment(
        &self,
        template: arcweft_core::runtime_id::RuntimeDialogueContentTemplateId,
    ) -> Option<&RuntimeContentFragmentFact> {
        self.dialogue_content_fragments
            .iter()
            .find(|fragment| fragment.template().id() == template)
            .or_else(|| {
                instance_semantic_roots(
                    self.project_function_instances.values(),
                    self.root_closures.values(),
                    self.trait_methods.values(),
                    self.pure_program_semantics
                        .iter()
                        .map(|(program, semantics)| (*program, semantics)),
                )
                .find_map(|(_, semantics)| semantics.dialogue_content_fragment(template))
            })
    }

    pub fn dialogue_content_fragment_for_source(
        &self,
        source: ExprId,
    ) -> Option<&RuntimeContentFragmentFact> {
        self.dialogue_content_fragments
            .iter()
            .find(|fragment| fragment.source() == source)
    }

    /// Accepted line identities supplied by the final semantic analysis.
    pub fn dialogue_lines(&self) -> Option<&AcceptedDialogueLineInventory> {
        self.dialogue_lines.as_deref()
    }

    pub const fn character_presentation_catalog(
        &self,
    ) -> Option<&Arc<CharacterPresentationCatalogData>> {
        self.character_presentation_catalog.as_ref()
    }
}

fn validate_pure_programs(
    project: HirAnalysisProjectView<'_>,
    modules: &BTreeMap<HirModuleId, &HirModule>,
    owners: RuntimeSemanticOwnerSet<'_>,
    staged: Vec<RuntimePureProgramFact>,
) -> Result<BTreeMap<RuntimePureProgramId, RuntimePureProgramFact>, RuntimeSemanticFactsError> {
    let expected = owners
        .programs
        .into_iter()
        .flat_map(HirRuntimeSemanticReachability::roots)
        .filter(|root| root.kind() == HirRuntimeReachabilityRootKind::CheckedProgram)
        .map(|root| root.owner().clone())
        .collect::<BTreeSet<_>>();
    let mut programs = BTreeMap::new();
    let mut supplied = BTreeSet::new();
    let mut instances = BTreeSet::new();
    for fact in staged {
        let program = fact.program();
        let abi = fact.admission().input_abi();
        abi.validate_project(project)
            .map_err(|_| RuntimeSemanticFactsError::InvalidPureProgram { program })?;
        if abi.hir_topology().generation().symbol_world()
            != owners.runtime.identity().symbol_world()
            || abi.hir_topology().generation().symbol_revision()
                != owners.runtime.identity().symbol_revision()
        {
            return Err(RuntimeSemanticFactsError::InvalidPureProgram { program });
        }
        let owner = fact.reachability_owner();
        if !expected.contains(&owner)
            || !instances.insert((owner.clone(), abi.instance_identity().cloned()))
        {
            return Err(RuntimeSemanticFactsError::InvalidPureProgram { program });
        }
        supplied.insert(owner);
        validate_normalized_type(modules, fact.result())?;
        validate_normalized_type(modules, fact.function_type())?;
        for ty in fact.input_types() {
            validate_normalized_type(modules, ty)?;
        }
        if programs.insert(program, fact).is_some() {
            return Err(RuntimeSemanticFactsError::DuplicateFact {
                family: RuntimeSemanticFactFamily::PureProgram,
            });
        }
    }
    if let Some(owner) = expected.iter().find(|owner| !supplied.contains(*owner)) {
        return Err(RuntimeSemanticFactsError::MissingPureProgram {
            owner: Box::new(owner.clone()),
        });
    }
    Ok(programs)
}
#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum RuntimeSemanticFactsError {
    #[error("runtime type projection {owner:?} has no accepted executable owner or semantic proof")]
    InvalidTypeProjection { owner: HirValueTypeOwner },
    #[error("runtime traversal {identity:?} has an inconsistent collection or callback contract")]
    InvalidTraversalType { identity: RuntimeSemanticTypeId },
    #[error("runtime expression {expression:?} has no accepted origin")]
    MissingExpressionOrigin { expression: ExprId },
    #[error("scope {owner:?} origin belongs to another owner or HIR allocation")]
    InvalidScopeOrigin { owner: RuntimeScopeOwner },
    #[error("expression {expression:?} origin belongs to another owner or HIR allocation")]
    InvalidExpressionOrigin { expression: ExprId },
    #[error(
        "entity value for {expression:?} was issued for another accepted expression or generation"
    )]
    InvalidEntityValueOrigin { expression: ExprId },
    #[error("entity value for {expression:?} disagrees with its accepted canonical Ref type")]
    InvalidEntityValueType { expression: ExprId },
    #[error("environment callable value has a foreign or mismatched origin at {expression:?}")]
    InvalidExternalCallableValueOrigin { expression: ExprId },
    #[error("environment callable value has a mismatched normalized type at {expression:?}")]
    InvalidExternalCallableValueType { expression: ExprId },
    #[error("entity pattern {pattern:?} belongs to another accepted owner or generation")]
    InvalidEntityPatternOrigin { pattern: PatternId },
    #[error("entity pattern {pattern:?} disagrees with its accepted canonical Ref type")]
    InvalidEntityPatternType { pattern: PatternId },
    #[error("local {local:?} origin belongs to another owner or HIR allocation")]
    InvalidLocalOrigin { local: LocalId },
    #[error("Flow {item:?} definition does not belong to its exact accepted owner")]
    InvalidFlowDefinition { item: ItemId },
    #[error(
        "Include statement {statement:?} does not retain its original checked target authority"
    )]
    InvalidIncludeTarget { statement: StmtId },
    #[error("Include statement {statement:?} has no checked target fact")]
    MissingIncludeTarget { statement: StmtId },
    #[error("suspension statement {statement:?} has no exact checked Duration operand")]
    InvalidSuspension { statement: StmtId },
    #[error("producer definition does not belong to its exact expression and local-use authority")]
    InvalidProducerDefinition { expression: ExprId },
    #[error("checked local use at {site:?} does not belong to the accepted HIR generation")]
    InvalidLocalUse {
        site: arcweft_lang_sema::final_analysis::CheckedLocalUseSite,
    },
    #[error(
        "checked synthetic use at {expression:?} does not belong to the accepted HIR generation"
    )]
    InvalidSyntheticUse { expression: ExprId },
    #[error(transparent)]
    CallableSpecialization(#[from] RuntimeCallableSpecializationFactError),
    #[error("CharacterDialogue generation inputs are invalid: {reason}")]
    InvalidCharacterDialogueGeneration { reason: &'static str },
    #[error("scope expression {expression:?} has no exact accepted lexical identity")]
    InvalidExpressionScope { expression: ExprId },
    #[error("scope statement {statement:?} has no exact accepted lexical identity")]
    InvalidStatementScope { statement: StmtId },
    #[error("scope continuation differs from the accepted lexical Try inventory at {owner:?}")]
    InvalidScopeContinuation { owner: RuntimeScopeOwner },
    #[error("source nominal definition does not match requested type {identity:?}")]
    NominalDefinitionMismatch { identity: RuntimeSemanticTypeId },
    #[error("source nominal variant {identity:?} is invalid: {source}")]
    NominalVariantDefinition {
        identity: RuntimeSemanticTypeId,
        source: Box<RuntimeResolvedVariantError>,
    },
    #[error("source nominal definition closure exceeds the type work budget")]
    NominalDefinitionBudget,
    #[error("runtime capture {capture:?} differs from its selected lexical projection")]
    InvalidCaptureProjection { capture: CaptureId },
    #[error("runtime semantic facts and reachability belong to different generations")]
    ReachabilityMismatch,
    #[error("runtime semantic fact owner is outside the accepted reachability closure")]
    OwnerOutsideReachability { owner: HirRuntimeExecutableOwner },
    #[error("runtime semantic facts are bound to a different accepted HIR generation")]
    WrongProjectGeneration,
    #[error("runtime semantic facts contain more than one {family:?} fact for the same HIR ID")]
    DuplicateFact { family: RuntimeSemanticFactFamily },
    #[error("residual runtime value for {expression:?} is not a checked Color call result")]
    InvalidResidualValue { expression: ExprId },
    #[error("runtime pure program {program} does not match its admitted root and input ABI")]
    InvalidPureProgram { program: RuntimePureProgramId },
    #[error("checked program root {owner:?} has no exact runtime pure-program fact")]
    MissingPureProgram {
        owner: Box<HirRuntimeExecutableOwner>,
    },
    #[error("accepted runtime semantic facts omit expression type {expression:?}")]
    MissingExpressionType { expression: ExprId },
    #[error(
        "accepted runtime semantic facts contain a {family:?} fact for inactive expression {expression:?}"
    )]
    InactiveExpressionFact {
        expression: ExprId,
        family: RuntimeSemanticFactFamily,
    },
    #[error("accepted runtime semantic facts omit pattern type {pattern:?}")]
    MissingPatternType { pattern: PatternId },
    #[error(
        "accepted runtime semantic facts contain a {family:?} fact for inactive pattern {pattern:?}"
    )]
    InactivePatternFact {
        pattern: PatternId,
        family: RuntimeSemanticFactFamily,
    },
    #[error("accepted runtime semantic facts omit an assignment fact for {statement:?}")]
    MissingAssignmentFact { statement: StmtId },
    #[error("accepted runtime semantic facts omit a registry write for {statement:?}")]
    MissingRegistryWriteFact { statement: StmtId },
    #[error("registry write for {statement:?} disagrees with its checked address or value domain")]
    InvalidRegistryWriteFact { statement: StmtId },
    #[error("accepted runtime semantic facts omit a Trigger fact for {statement:?}")]
    MissingTriggerFact { statement: StmtId },
    #[error("Trigger fact for {statement:?} does not match its checked runtime authority")]
    InvalidTriggerFact { statement: StmtId },
    #[error("assignment fact for {statement:?} does not match its checked direct record field")]
    InvalidAssignmentFact { statement: StmtId },
    #[error("evaluated-effect fact for {expression:?} does not match its selected call")]
    InvalidEvaluatedEffectFact { expression: ExprId },
    #[error("defer fact for {statement:?} does not match its checked body and captures")]
    InvalidDeferFact { statement: StmtId },
    #[error("Await fact for {expression:?} does not match its checked expression")]
    InvalidAwaitFact { expression: ExprId },
    #[error("Choice fact for {expression:?} does not match its checked expression")]
    InvalidChoiceFact { expression: ExprId },
    #[error("Try fact for {expression:?} does not match its checked carrier boundary")]
    InvalidTryFact { expression: ExprId },
    #[error("implicit callable fact for {expression:?} does not match its checked abstraction")]
    InvalidImplicitCallableFact { expression: ExprId },
    #[error("pipe fact for {expression:?} does not match its checked once-only pipeline")]
    InvalidPipeFact { expression: ExprId },
    #[error("postfix expression {expression:?} has no accepted candidate fact")]
    MissingPostfixCandidate { expression: ExprId },
    #[error("runtime semantic fact references unknown HIR module {module:?}")]
    UnknownModule { module: HirModuleId },
    #[error("runtime semantic fact references unresolved item {item:?}")]
    UnresolvedItem { item: ItemId },
    #[error("runtime semantic fact references unresolved local {local:?}")]
    UnresolvedLocal { local: LocalId },
    #[error("runtime semantic fact references presentation-owned local {local:?}")]
    InactiveLocalReference { local: LocalId },
    #[error("accepted runtime semantic facts omit runtime-domain local declaration {local:?}")]
    MissingLocalDeclaration { local: LocalId },
    #[error("accepted runtime semantic facts contain extra local declaration {local:?}")]
    ExtraLocalDeclaration { local: LocalId },
    #[error(
        "runtime local declarations are not in canonical project order: expected {expected:?}, observed {actual:?}"
    )]
    NonCanonicalLocalDeclarationOrder { expected: LocalId, actual: LocalId },
    #[error("runtime semantic fact references unresolved expression {expression:?}")]
    UnresolvedExpression { expression: ExprId },
    #[error("accepted runtime semantic facts omit a complete closure instance for {expression:?}")]
    MissingClosureInstance { expression: ExprId },
    #[error("runtime semantic fact references unresolved statement {statement:?}")]
    UnresolvedStatement { statement: StmtId },
    #[error(
        "accepted runtime semantic facts contain a {family:?} fact for inactive statement {statement:?}"
    )]
    InactiveStatementFact {
        statement: StmtId,
        family: RuntimeSemanticFactFamily,
    },
    #[error("runtime semantic fact references unresolved pattern {pattern:?}")]
    UnresolvedPattern { pattern: PatternId },
    #[error("runtime semantic fact references unresolved type {ty:?}")]
    UnresolvedType { ty: TypeId },
    #[error("accepted runtime semantic facts contain a fact for inactive type {ty:?}")]
    InactiveTypeFact { ty: TypeId },
    #[error("runtime semantic fact references poisoned type {ty:?}")]
    PoisonedType { ty: TypeId },
    #[error("runtime semantic fact references unresolved capture {capture:?}")]
    UnresolvedCapture { capture: CaptureId },
    #[error("accepted runtime semantic facts contain a fact for inactive capture {capture:?}")]
    InactiveCaptureFact { capture: CaptureId },
    #[error(transparent)]
    RuntimeReachability(#[from] HirRuntimeReachabilityError),
    #[error("expression {expression:?} cannot own a {expected:?} runtime semantic fact")]
    WrongExpressionFamily {
        expression: ExprId,
        expected: RuntimeSemanticFactFamily,
    },
    #[error("statement {statement:?} cannot own a {expected:?} runtime semantic fact")]
    WrongStatementFamily {
        statement: StmtId,
        expected: RuntimeSemanticFactFamily,
    },
    #[error("pattern {pattern:?} cannot own a {expected:?} runtime semantic fact")]
    WrongPatternFamily {
        pattern: PatternId,
        expected: RuntimeSemanticFactFamily,
    },
    #[error("runtime semantic fact item {item:?} has incompatible HIR family {actual:?}")]
    WrongItemFamily { item: ItemId, actual: HirItemFamily },
    #[error("runtime project callable does not match its exact final-HIR source owner")]
    InvalidCallableSourceOwner,
    #[error("runtime project callable attached-content ABI does not match final HIR")]
    InvalidCallableAttachedContentAbi,
    #[error("runtime project-function instance does not match its exact final-HIR function body")]
    InvalidProjectFunctionInstance,
    #[error("runtime project-function call {expression:?} has no exact closed instance fact")]
    MissingProjectFunctionInstance { expression: ExprId },
    #[error(
        "runtime project-function instance is not referenced by any checked Invoke outcome or non-call root"
    )]
    UnreferencedProjectFunctionInstance,
    #[error("runtime project-function non-call root does not match its checked HIR ingress")]
    InvalidProjectFunctionRoot,
    #[error("ordinary project-function call is missing its checked continuation/instance plan")]
    MissingProjectFunctionCallPlan,
    #[error("closed project-function instance owner was also published in global {family:?} facts")]
    InstanceOwnedGlobalFact { family: RuntimeSemanticFactFamily },
    #[error("runtime nominal-record fact item {item:?} is not a struct")]
    WrongNominalRecordItemFamily { item: ItemId },
    #[error("runtime nominal-record layout catalog contains conflicting descriptors")]
    ConflictingNominalRecordLayout {
        nominal: RuntimeNominalTypeId,
        semantic_identity: RuntimeSemanticTypeId,
        layout: TypeLayoutHash,
    },
    #[error("runtime nominal layout for `{nominal:?}` on {item:?} is unresolved")]
    UnresolvedNominalLayout {
        item: ItemId,
        nominal: RuntimeNominalTypeId,
    },
    #[error("runtime variant fact does not match its typed owner and source-ordered ordinal")]
    WrongVariantIdentity,
    #[error("runtime project item does not match its typed owner and public ID")]
    WrongProjectItemIdentity,
    #[error(
        "runtime call fact references authored argument {ordinal}, but the call has {count} arguments"
    )]
    InvalidCallArgumentOrdinal { ordinal: u32, count: usize },
    #[error("runtime call fact repeats one argument projection")]
    DuplicateCallArgument,
    #[error("runtime function-value call fact is attached to a call without a value callee")]
    MissingFunctionValueCallee,
    #[error(
        "Reduction.unchanged runtime call requires exactly one authored argument and a value result"
    )]
    InvalidReductionConstructorCall,
    #[error("Agent runtime call arguments do not match the selected intrinsic family")]
    InvalidAgentCallArguments,
    #[error("postfix expression {expression:?} does not own selected candidate {candidate:?}")]
    WrongPostfixCandidate {
        expression: ExprId,
        candidate: ExprId,
    },
    #[error("expression {expression:?} has a runtime call disposition but is not a Call")]
    InvalidRuntimeCallDisposition { expression: ExprId },
    #[error(
        "call {expression:?} operand {operand:?} expects {expected:?}, expression has {actual:?}"
    )]
    CallOperandTypeMismatch {
        expression: ExprId,
        operand: ExprId,
        expected: RuntimeSemanticTypeId,
        actual: Option<RuntimeSemanticTypeId>,
    },
    #[error("Need producer fact for {expression:?} does not match its exact call result type")]
    InvalidNeedProducerFact { expression: ExprId },
    #[error("selected runtime call {expression:?} requires a runtime receiver but has none")]
    MissingRuntimeCallReceiver { expression: ExprId },
    #[error("runtime trait method fact does not match its final-HIR implementation member")]
    InvalidTraitMethodIdentity,
    #[error("iterator witness method edge does not match its checked statement role")]
    InvalidIteratorWitnessMethodEdge {
        statement: StmtId,
        role: HirRuntimeIteratorWitnessMethodRole,
    },
    #[error("dialogue projection and Character presentation catalog presence disagree")]
    DialogueCatalogPresenceMismatch,
    #[error("dialogue application {expression:?} does not match its accepted line identity")]
    DialogueLineMismatch { expression: ExprId },
    #[error("dialogue application {expression:?} has an invalid checked target {target:?}")]
    DialogueTargetMismatch { expression: ExprId, target: ExprId },
    #[error("dialogue application {expression:?} has no matching runtime content fragment")]
    DialogueTemplateMismatch { expression: ExprId },
    #[error("runtime content fragment source {expression:?} is duplicated")]
    DuplicateContentFragment { expression: ExprId },
    #[error("runtime content fragment source {expression:?} does not match its checked programs")]
    InvalidContentFragment { expression: ExprId },
    #[error("formatter template catalog does not match the selected scoped fmt calls")]
    InvalidFormatTemplateCatalog,
    #[error("dialogue application {expression:?} has too many value slots")]
    TooManyDialogueValueSlots { expression: ExprId },
    #[error(
        "dialogue application {expression:?} has non-canonical value slot {actual:?}, expected {expected:?}"
    )]
    NonCanonicalDialogueValueSlot {
        expression: ExprId,
        expected: RuntimeDialogueValueSlotId,
        actual: RuntimeDialogueValueSlotId,
    },
    #[error("dialogue {dialogue:?} value expression {value:?} has no accepted type")]
    MissingDialogueValueType { dialogue: ExprId, value: ExprId },
    #[error("dialogue {dialogue:?} effect site {site:?} does not match its checked operation")]
    InvalidDialogueEffectSite {
        dialogue: ExprId,
        site: arcweft_core::runtime_id::RuntimeDialogueEffectSiteId,
    },
    #[error("dialogue application {expression:?} carries stale or unknown Character evidence")]
    DialogueCharacterPlanMismatch { expression: ExprId },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuntimeSemanticFactFamily {
    LocalDeclaration,
    LocalUse,
    SyntheticUse,
    FlowIdentity,
    Include,
    Suspension,
    ExpressionScope,
    StatementScope,
    ThreadProducer,
    CallProducer,
    ExpressionType,
    ExpressionChildren,
    PatternType,
    ExpressionLiteral,
    ResidualValue,
    PatternLiteral,
    PatternItem,
    Value,
    Select,
    NominalRecord,
    PatternNominalRecord,
    ExpressionVariant,
    PatternVariant,
    Type,
    Call,
    PostfixCandidate,
    TraitMethod,
    Iteration,
    Assertion,
    Trigger,
    Assignment,
    RegistryWrite,
    EvaluatedEffect,
    Defer,
    Choice,
    Await,
    Try,
    ImplicitCallable,
    Pipe,
    Capture,
    PureProgram,
    ProjectFunctionInstance,
    ClosureInstance,
    ProjectFunctionRoot,
    DialogueApplication,
    FormatTemplate,
    CharacterDialogueGeneration,
}

fn validate_complete_expression_types(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    expression_types: &RuntimeExpressionTypeView<'_>,
    instance_owned: &BTreeSet<ExprId>,
) -> Result<(), RuntimeSemanticFactsError> {
    let mut accepted = runtime_owners.selected_expression_type_owners()?;
    accepted.retain(|owner| !instance_owned.contains(owner));

    if let Some(expression) = accepted
        .iter()
        .find(|owner| !expression_types.contains_key(owner))
    {
        return Err(RuntimeSemanticFactsError::MissingExpressionType {
            expression: *expression,
        });
    }
    if let Some(expression) = expression_types
        .keys()
        .find(|owner| !accepted.contains(owner))
    {
        return Err(RuntimeSemanticFactsError::InactiveExpressionFact {
            expression: *expression,
            family: RuntimeSemanticFactFamily::ExpressionType,
        });
    }
    Ok(())
}

/// Final semantic publication owns a fact for every runtime-domain final-HIR
/// pattern, including patterns retained inside bounded candidate HIR. If
/// candidate rollback leaves one without a type, semantic analysis fails
/// before this projection can be constructed. Presentation-owned patterns do
/// not enter this table.
fn validate_complete_pattern_types(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    type_projections: &BTreeMap<HirValueTypeOwner, RuntimeExecutableTypeProjection>,
    instance_owned: &BTreeSet<PatternId>,
) -> Result<(), RuntimeSemanticFactsError> {
    for pattern in runtime_owners
        .patterns()
        .into_iter()
        .filter(|pattern| !instance_owned.contains(pattern))
    {
        if !type_projections.contains_key(&HirValueTypeOwner::Pattern(pattern)) {
            return Err(RuntimeSemanticFactsError::MissingPatternType { pattern });
        }
    }
    if let Some(pattern) = type_projections
        .keys()
        .filter_map(|owner| match owner {
            HirValueTypeOwner::Pattern(pattern) => Some(pattern),
            _ => None,
        })
        .find(|owner| !runtime_owners.contains_pattern(**owner) || instance_owned.contains(*owner))
    {
        return Err(RuntimeSemanticFactsError::InactivePatternFact {
            pattern: *pattern,
            family: RuntimeSemanticFactFamily::PatternType,
        });
    }
    Ok(())
}

fn require_runtime_expression_owner(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    expression: ExprId,
    family: RuntimeSemanticFactFamily,
) -> Result<(), RuntimeSemanticFactsError> {
    if runtime_owners.contains_expression(expression) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::InactiveExpressionFact { expression, family })
    }
}

fn require_runtime_statement_owner(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    statement: StmtId,
    family: RuntimeSemanticFactFamily,
) -> Result<(), RuntimeSemanticFactsError> {
    if runtime_owners.contains_statement(statement) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::InactiveStatementFact { statement, family })
    }
}

fn require_runtime_pattern_owner(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    pattern: PatternId,
    family: RuntimeSemanticFactFamily,
) -> Result<(), RuntimeSemanticFactsError> {
    if runtime_owners.contains_pattern(pattern) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::InactivePatternFact { pattern, family })
    }
}

fn require_runtime_type_owner(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    ty: TypeId,
) -> Result<(), RuntimeSemanticFactsError> {
    if runtime_owners.contains_type(ty) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::InactiveTypeFact { ty })
    }
}

fn require_runtime_capture_owner(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    capture: CaptureId,
) -> Result<(), RuntimeSemanticFactsError> {
    if runtime_owners.contains_capture(capture) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::InactiveCaptureFact { capture })
    }
}

fn require_runtime_local_reference(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    local: LocalId,
) -> Result<(), RuntimeSemanticFactsError> {
    if runtime_owners.contains_local(local) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::InactiveLocalReference { local })
    }
}

fn collect_unique<K: Ord, V>(
    values: impl IntoIterator<Item = (K, V)>,
    family: RuntimeSemanticFactFamily,
) -> Result<BTreeMap<K, V>, RuntimeSemanticFactsError> {
    let mut result = BTreeMap::new();
    for (key, value) in values {
        if result.insert(key, value).is_some() {
            return Err(RuntimeSemanticFactsError::DuplicateFact { family });
        }
    }
    Ok(result)
}

fn all_unique<T: Copy + Ord>(values: &[T]) -> bool {
    values.iter().copied().collect::<BTreeSet<_>>().len() == values.len()
}

fn module_for<'project>(
    modules: &BTreeMap<HirModuleId, &'project HirModule>,
    id: HirModuleId,
) -> Result<&'project HirModule, RuntimeSemanticFactsError> {
    modules
        .get(&id)
        .copied()
        .ok_or(RuntimeSemanticFactsError::UnknownModule { module: id })
}

fn resolve_expr<'project>(
    modules: &BTreeMap<HirModuleId, &'project HirModule>,
    id: ExprId,
) -> Result<&'project HirExprKind, RuntimeSemanticFactsError> {
    module_for(modules, id.module())?
        .resolve_expr(id)
        .map(arcweft_lang_hir::expr::HirExpr::kind)
        .map_err(|_| RuntimeSemanticFactsError::UnresolvedExpression { expression: id })
}

fn resolve_stmt<'project>(
    modules: &BTreeMap<HirModuleId, &'project HirModule>,
    id: StmtId,
) -> Result<&'project HirStmtKind, RuntimeSemanticFactsError> {
    module_for(modules, id.module())?
        .resolve_stmt(id)
        .map(arcweft_lang_hir::stmt::HirStmt::kind)
        .map_err(|_| RuntimeSemanticFactsError::UnresolvedStatement { statement: id })
}

fn resolve_pattern<'project>(
    modules: &BTreeMap<HirModuleId, &'project HirModule>,
    id: PatternId,
) -> Result<&'project HirPatternKind, RuntimeSemanticFactsError> {
    module_for(modules, id.module())?
        .resolve_pattern(id)
        .map(arcweft_lang_hir::pattern::HirPattern::kind)
        .map_err(|_| RuntimeSemanticFactsError::UnresolvedPattern { pattern: id })
}

fn require_expr_family(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    expression: ExprId,
    expected: RuntimeSemanticFactFamily,
    predicate: impl FnOnce(&HirExprKind) -> bool,
) -> Result<(), RuntimeSemanticFactsError> {
    let kind = resolve_expr(modules, expression)?;
    require_runtime_expression_owner(runtime_owners, expression, expected)?;
    if predicate(kind) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::WrongExpressionFamily {
            expression,
            expected,
        })
    }
}

fn require_stmt_family(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    statement: StmtId,
    expected: RuntimeSemanticFactFamily,
    predicate: impl FnOnce(&HirStmtKind) -> bool,
) -> Result<(), RuntimeSemanticFactsError> {
    let kind = resolve_stmt(modules, statement)?;
    require_runtime_statement_owner(runtime_owners, statement, expected)?;
    if predicate(kind) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::WrongStatementFamily {
            statement,
            expected,
        })
    }
}

fn require_pattern_family(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    pattern: PatternId,
    expected: RuntimeSemanticFactFamily,
    predicate: impl FnOnce(&HirPatternKind) -> bool,
) -> Result<(), RuntimeSemanticFactsError> {
    let kind = resolve_pattern(modules, pattern)?;
    require_runtime_pattern_owner(runtime_owners, pattern, expected)?;
    if predicate(kind) {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::WrongPatternFamily { pattern, expected })
    }
}

fn validate_resolved_value(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    origin_context: RuntimeValueOriginContext<'_>,
    expression: ExprId,
    expression_type: Option<&RuntimeNormalizedType>,
    value: &RuntimeResolvedValue,
) -> Result<(), RuntimeSemanticFactsError> {
    match value {
        RuntimeResolvedValue::Local(local) => {
            module_for(modules, local.module())?
                .resolve_local(*local)
                .map_err(|_| RuntimeSemanticFactsError::UnresolvedLocal { local: *local })?;
            require_runtime_local_reference(runtime_owners, *local)
        }
        RuntimeResolvedValue::RegistryRead(read) => {
            let HirExprKind::LifetimePath(path) = resolve_expr(modules, expression)? else {
                return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                    expression,
                    expected: RuntimeSemanticFactFamily::Value,
                });
            };
            if path
                .as_resolved()
                .is_some_and(|path| read.matches_path(expression, path))
                && expression_type.is_some_and(|ty| match read.kind() {
                    arcweft_core::effect::RuntimeRegistryReadKind::Required => true,
                    arcweft_core::effect::RuntimeRegistryReadKind::Optional => {
                        matches!(ty.shape(), RuntimeTypeShape::Option { .. })
                    }
                })
            {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                    expression,
                    expected: RuntimeSemanticFactFamily::Value,
                })
            }
        }
        RuntimeResolvedValue::Place(place) => {
            let base = place.local();
            module_for(modules, base.module())?
                .resolve_local(base)
                .map_err(|_| RuntimeSemanticFactsError::UnresolvedLocal { local: base })?;
            require_runtime_local_reference(runtime_owners, base)
        }
        RuntimeResolvedValue::ProjectCallable { callable, target } => {
            validate_callable(modules, callable)?;
            if target.callable() != callable.runtime() {
                return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
            }
            Ok(())
        }
        RuntimeResolvedValue::Entity(entity) => {
            validate_entity_value(origin_context, expression, expression_type, entity)
        }
        RuntimeResolvedValue::ExternalCallable(callable) => {
            let accepted_origin = match origin_context {
                RuntimeValueOriginContext::Project(project) => {
                    callable.origin().validate_owner(project, expression)
                }
                RuntimeValueOriginContext::Closed(local_uses) => {
                    callable.origin().validate_authority(local_uses, expression)
                }
            };
            if !accepted_origin {
                return Err(
                    RuntimeSemanticFactsError::InvalidExternalCallableValueOrigin { expression },
                );
            }
            if expression_type.is_none_or(|ty| {
                ty.identity().as_bytes() != callable.type_identity().as_bytes()
                    || !matches!(ty.shape(), RuntimeTypeShape::Function { .. })
            }) {
                return Err(
                    RuntimeSemanticFactsError::InvalidExternalCallableValueType { expression },
                );
            }
            Ok(())
        }
        RuntimeResolvedValue::DialogueLine(_)
        | RuntimeResolvedValue::Intrinsic(_)
        | RuntimeResolvedValue::Registered(_)
        | RuntimeResolvedValue::Constant(_) => Ok(()),
    }
}

fn validate_project_item(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    item: &RuntimeProjectItem,
) -> Result<(), RuntimeSemanticFactsError> {
    item.family()
        .validate_public_id(item.public_id())
        .map_err(|_| RuntimeSemanticFactsError::WrongProjectItemIdentity)?;
    match item.owner() {
        RuntimeProjectItemOwner::ExternalCharacter => (item.family()
            == DeclarationIdentityFamily::Character)
            .then_some(())
            .ok_or(RuntimeSemanticFactsError::WrongProjectItemIdentity),
        RuntimeProjectItemOwner::StructuralFlow { owner, .. } => (item.family()
            == DeclarationIdentityFamily::Flow
            && matches!(resolve_item(modules, *owner)?.kind(), HirItemKind::Flow(_)))
        .then_some(())
        .ok_or(RuntimeSemanticFactsError::WrongProjectItemIdentity),
        RuntimeProjectItemOwner::Retained(owner) => {
            let actual = resolve_item(modules, *owner)?.kind().family();
            let expected = match item.family() {
                DeclarationIdentityFamily::Character => HirItemFamily::Character,
                DeclarationIdentityFamily::View => HirItemFamily::View,
                DeclarationIdentityFamily::Action => HirItemFamily::Action,
                DeclarationIdentityFamily::Activity => HirItemFamily::Activity,
                DeclarationIdentityFamily::Signal => HirItemFamily::Signal,
                DeclarationIdentityFamily::Metric => HirItemFamily::Metric,
                DeclarationIdentityFamily::Layer => HirItemFamily::Layer,
                DeclarationIdentityFamily::Asset
                | DeclarationIdentityFamily::Flow
                | DeclarationIdentityFamily::Proof
                | DeclarationIdentityFamily::Style => {
                    return Err(RuntimeSemanticFactsError::WrongProjectItemIdentity);
                }
            };
            if actual == expected {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongItemFamily {
                    item: *owner,
                    actual,
                })
            }
        }
    }
}

fn validate_assignment<'types>(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    local_type: impl Fn(&LocalId) -> Option<&'types RuntimeNormalizedType>,
    expression_types: &RuntimeExpressionTypeView<'_>,
    values: &BTreeMap<ExprId, RuntimeResolvedValue>,
    access: Option<&arcweft_lang_sema::final_analysis::CheckedLocalPlaceAccess>,
    statement: StmtId,
    assignment: &RuntimeAssignmentFact,
) -> Result<(), RuntimeSemanticFactsError> {
    let HirStmtKind::Assign { target, value } = resolve_stmt(modules, statement)? else {
        return Err(RuntimeSemanticFactsError::InvalidAssignmentFact { statement });
    };
    if expression_types.get(target) != Some(assignment.value_type())
        || expression_types.get(value) != Some(assignment.value_type())
        || access.is_none_or(|access| {
            access.mode() != arcweft_lang_sema::final_analysis::CheckedLocalPlaceMode::Assign
                || !assignment.place().matches_checked(access.place())
        })
        || local_type(&assignment.place().local()).is_none_or(|root| {
            !assignment
                .place()
                .accepts_types(root, assignment.value_type())
        })
    {
        return Err(RuntimeSemanticFactsError::InvalidAssignmentFact { statement });
    }
    if let RuntimeResolvedPlace::Local(local) = assignment.place() {
        if values.get(target) != Some(&RuntimeResolvedValue::Local(*local))
            || local_type(local) != Some(assignment.value_type())
            || !modules.get(&local.module()).is_some_and(|module| {
                module
                    .resolve_local(*local)
                    .is_ok_and(|local| local.is_mutable_binding())
            })
        {
            return Err(RuntimeSemanticFactsError::InvalidAssignmentFact { statement });
        }
    }
    validate_normalized_type(modules, assignment.value_type())?;
    Ok(())
}

fn validate_select(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    owner: ExprId,
    select: &RuntimeResolvedSelect,
) -> Result<(), RuntimeSemanticFactsError> {
    if let Some(arcweft_lang_sema::final_analysis::CheckedFieldReceiver::Expression(receiver)) =
        select.receiver()
    {
        if !matches!(resolve_expr(modules, owner)?, HirExprKind::Select(select) if select.target() == receiver)
        {
            return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                expression: owner,
                expected: RuntimeSemanticFactFamily::Select,
            });
        }
        resolve_expr(modules, receiver)?;
    }
    match select {
        RuntimeResolvedSelect::Method
        | RuntimeResolvedSelect::AgentField { .. }
        | RuntimeResolvedSelect::ProgressField { .. }
        | RuntimeResolvedSelect::Field { .. }
        | RuntimeResolvedSelect::OpaqueRecord { .. } => Ok(()),
    }
}

fn validate_variant(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    variant: &RuntimeResolvedVariant,
) -> Result<(), RuntimeSemanticFactsError> {
    variant
        .checked_selection()
        .map_err(|_| RuntimeSemanticFactsError::WrongVariantIdentity)?;
    let selected_name = variant
        .selected_name()
        .map_err(|_| RuntimeSemanticFactsError::WrongVariantIdentity)?;
    match variant.owner() {
        RuntimeVariantOwner::Nominal {
            nominal,
            arguments,
            cases,
        } => {
            validate_nominal(modules, nominal)?;
            for argument in arguments {
                validate_normalized_type(modules, argument)?;
            }
            validate_normalized_variant_payloads(modules, cases)?;
            let graph = nominal.source_graph();
            let definition = graph
                .definition(nominal.identity())
                .ok_or(RuntimeSemanticFactsError::WrongVariantIdentity)?;
            let arcweft_core::entry::RuntimeNominalSchemaBody::Variant { cases: source } =
                definition.body()
            else {
                return Err(RuntimeSemanticFactsError::WrongVariantIdentity);
            };
            if definition.identity().nominal() != &nominal.runtime_nominal_id()
                || graph.try_layout_hash(nominal.identity()).ok() != Some(nominal.layout())
                || definition.arguments().len() != arguments.len()
                || !definition
                    .arguments()
                    .iter()
                    .zip(arguments)
                    .all(|(schema, normalized)| {
                        normalized_type_matches_schema(normalized, schema, graph)
                    })
                || source.len() != cases.len()
                || source.iter().zip(cases.iter()).any(|(schema, normalized)| {
                    schema.name() != normalized.name()
                        || !normalized_payload_matches_schema(
                            normalized.payload(),
                            schema.payload(),
                            graph,
                        )
                })
            {
                return Err(RuntimeSemanticFactsError::WrongVariantIdentity);
            }
            let RuntimeResolvedNominalSource::Project { owner, .. } = nominal.source() else {
                return Ok(());
            };
            let HirItemKind::Enum(declaration) = resolve_item(modules, *owner)?.kind() else {
                return Err(RuntimeSemanticFactsError::WrongVariantIdentity);
            };
            if declaration.variants().len() != cases.len()
                || declaration.variants().iter().zip(cases.iter()).any(
                    |(declaration, normalized)| {
                        declaration.name().resolved().map(HirName::as_str)
                            != Some(normalized.name())
                            || !hir_variant_payload_matches_normalized(
                                declaration.payload(),
                                normalized.payload(),
                            )
                    },
                )
            {
                return Err(RuntimeSemanticFactsError::WrongVariantIdentity);
            }
            let selected = usize::try_from(variant.ordinal())
                .ok()
                .and_then(|ordinal| declaration.variants().get(ordinal))
                .and_then(|selected| selected.name().resolved())
                .ok_or(RuntimeSemanticFactsError::WrongVariantIdentity)?;
            if selected.as_str() == selected_name {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            }
        }
        RuntimeVariantOwner::CharacterNominal { nominal, cases, .. } => {
            if nominal.as_str().is_empty()
                || cases.is_empty()
                || cases.iter().enumerate().any(|(ordinal, case)| {
                    case.name().is_empty()
                        || case.payload().is_some()
                        || cases[..ordinal]
                            .iter()
                            .any(|previous| previous.name() == case.name())
                })
                || usize::try_from(variant.ordinal())
                    .ok()
                    .and_then(|ordinal| cases.get(ordinal))
                    .is_none_or(|case| case.name() != selected_name)
            {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            } else {
                Ok(())
            }
        }
        RuntimeVariantOwner::BuiltinClosed { nominal, cases, .. } => {
            validate_normalized_variant_payloads(modules, cases)?;
            if nominal.as_str().is_empty()
                || cases.is_empty()
                || cases.iter().enumerate().any(|(ordinal, case)| {
                    case.name().is_empty()
                        || cases[..ordinal]
                            .iter()
                            .any(|previous| previous.name() == case.name())
                })
                || usize::try_from(variant.ordinal())
                    .ok()
                    .and_then(|ordinal| cases.get(ordinal))
                    .is_none_or(|case| case.name() != selected_name)
            {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            } else {
                Ok(())
            }
        }
        RuntimeVariantOwner::RuntimeBuiltin { owner, cases, .. } => {
            validate_normalized_variant_payloads(modules, cases)?;
            if cases.len() != owner.cases().len()
                || cases.iter().zip(owner.cases()).any(|(case, schema)| {
                    case.name() != schema.name() || case.payload().is_some() != schema.has_payload()
                })
                || usize::try_from(variant.ordinal())
                    .ok()
                    .and_then(|ordinal| cases.get(ordinal))
                    .is_none_or(|case| case.name() != selected_name)
            {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            } else {
                Ok(())
            }
        }
        RuntimeVariantOwner::Option { item, cases, .. } => {
            validate_normalized_type(modules, item)?;
            validate_normalized_variant_payloads(modules, cases)?;
            if matches!(
                (variant.ordinal(), selected_name),
                (0, "Some") | (1, "None")
            ) {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            }
        }
        RuntimeVariantOwner::Result {
            ok, error, cases, ..
        } => {
            validate_normalized_type(modules, ok)?;
            validate_normalized_type(modules, error)?;
            validate_normalized_variant_payloads(modules, cases)?;
            if matches!((variant.ordinal(), selected_name), (0, "Ok") | (1, "Err")) {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            }
        }
    }
}

fn hir_variant_payload_matches_normalized(
    authored: &HirEnumVariantPayload,
    normalized: Option<&RuntimeNormalizedType>,
) -> bool {
    match (authored, normalized.map(RuntimeNormalizedType::shape)) {
        (HirEnumVariantPayload::Unit, None) => true,
        (HirEnumVariantPayload::Tuple(_), Some(RuntimeTypeShape::Tuple(fields))) => {
            fields.len() == 1
        }
        (HirEnumVariantPayload::Record(authored), Some(RuntimeTypeShape::Record(fields))) => {
            authored.len() == fields.len()
                && authored.iter().zip(fields).all(|(authored, normalized)| {
                    authored.name().resolved().map(HirName::as_str)
                        == Some(normalized.diagnostic_name())
                })
        }
        _ => false,
    }
}

fn normalized_payload_matches_schema(
    normalized: Option<&RuntimeNormalizedType>,
    schema: Option<&RuntimeTypeSchema>,
    graph: &RuntimeNominalSchemaGraph,
) -> bool {
    match (normalized, schema) {
        (None, None) => true,
        (Some(normalized), Some(schema)) => {
            normalized_type_matches_schema(normalized, schema, graph)
        }
        _ => false,
    }
}

/// Correlates the complete normalized payload with the sealed source graph.
/// Nominal references terminate recursive schemas at their exact instance ID.
fn normalized_type_matches_schema(
    normalized: &RuntimeNormalizedType,
    schema: &RuntimeTypeSchema,
    graph: &RuntimeNominalSchemaGraph,
) -> bool {
    let mut pending = vec![(normalized, schema)];
    while let Some((normalized, schema)) = pending.pop() {
        if let RuntimeTypeSchema::ExecutableRef(identity) = schema {
            if normalized.identity() != *identity {
                return false;
            }
            continue;
        }
        match (normalized.shape(), schema) {
            (RuntimeTypeShape::Unit, RuntimeTypeSchema::Unit)
            | (RuntimeTypeShape::Never, RuntimeTypeSchema::Never)
            | (RuntimeTypeShape::Bool, RuntimeTypeSchema::Bool)
            | (RuntimeTypeShape::Signed(RuntimeSignedIntWidth::I8), RuntimeTypeSchema::I8)
            | (RuntimeTypeShape::Signed(RuntimeSignedIntWidth::I16), RuntimeTypeSchema::I16)
            | (RuntimeTypeShape::Signed(RuntimeSignedIntWidth::I32), RuntimeTypeSchema::I32)
            | (RuntimeTypeShape::Signed(RuntimeSignedIntWidth::I64), RuntimeTypeSchema::I64)
            | (RuntimeTypeShape::Signed(RuntimeSignedIntWidth::I128), RuntimeTypeSchema::I128)
            | (RuntimeTypeShape::Signed(RuntimeSignedIntWidth::ISize), RuntimeTypeSchema::ISize)
            | (RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::U8), RuntimeTypeSchema::U8)
            | (RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::U16), RuntimeTypeSchema::U16)
            | (RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::U32), RuntimeTypeSchema::U32)
            | (RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::U64), RuntimeTypeSchema::U64)
            | (
                RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::U128),
                RuntimeTypeSchema::U128,
            )
            | (
                RuntimeTypeShape::Unsigned(RuntimeUnsignedIntWidth::USize),
                RuntimeTypeSchema::USize,
            )
            | (RuntimeTypeShape::F32, RuntimeTypeSchema::F32)
            | (RuntimeTypeShape::F64, RuntimeTypeSchema::F64)
            | (RuntimeTypeShape::String, RuntimeTypeSchema::String)
            | (RuntimeTypeShape::Color, RuntimeTypeSchema::Color)
            | (RuntimeTypeShape::Char, RuntimeTypeSchema::Char)
            | (RuntimeTypeShape::Duration, RuntimeTypeSchema::Duration)
            | (RuntimeTypeShape::Progress, RuntimeTypeSchema::Progress)
            | (RuntimeTypeShape::AgentValue, RuntimeTypeSchema::AgentValue)
            | (
                RuntimeTypeShape::Bytes,
                RuntimeTypeSchema::Bytes {
                    format: RuntimeBytesFormat::Binary,
                },
            ) => {}
            (
                RuntimeTypeShape::EntityReference(expected),
                RuntimeTypeSchema::EntityReference(actual),
            ) if expected.as_ref().map(|payload| payload.identity()) == *actual => {}
            (RuntimeTypeShape::DenseNumeric(expected), RuntimeTypeSchema::DenseNumeric(actual))
                if expected == actual => {}
            (RuntimeTypeShape::Sequence { kind, item }, RuntimeTypeSchema::Seq(schema))
                if !matches!(kind, RuntimeSequenceKind::Array) =>
            {
                pending.push((item, schema));
            }
            (
                RuntimeTypeShape::Array { item, length },
                RuntimeTypeSchema::Array {
                    item: schema,
                    length: expected,
                },
            ) if length.constant() == Some(*expected) => {
                pending.push((item, schema));
            }
            (
                RuntimeTypeShape::Map { kind, key, value },
                RuntimeTypeSchema::Map {
                    kind: expected,
                    key: schema_key,
                    value: schema_value,
                },
            ) if kind == expected => {
                pending.push((key, schema_key));
                pending.push((value, schema_value));
            }
            (
                RuntimeTypeShape::Option { item, some_payload },
                RuntimeTypeSchema::Builtin(schema),
            ) if schema.owner() == RuntimeBuiltinVariantIdentity::Option
                && matches!(some_payload.shape(), RuntimeTypeShape::Tuple(fields)
                    if matches!(fields.as_ref(), [wrapped] if wrapped == item.as_ref())) =>
            {
                let [expected] = schema.payloads() else {
                    return false;
                };
                pending.push((item, expected));
            }
            (
                RuntimeTypeShape::Result {
                    value,
                    error,
                    value_payload,
                    error_payload,
                },
                RuntimeTypeSchema::Builtin(schema),
            ) if schema.owner() == RuntimeBuiltinVariantIdentity::Result
                && matches!(value_payload.shape(), RuntimeTypeShape::Tuple(fields)
                    if matches!(fields.as_ref(), [wrapped] if wrapped == value.as_ref()))
                && matches!(error_payload.shape(), RuntimeTypeShape::Tuple(fields)
                    if matches!(fields.as_ref(), [wrapped] if wrapped == error.as_ref())) =>
            {
                let [expected_value, expected_error] = schema.payloads() else {
                    return false;
                };
                pending.push((value, expected_value));
                pending.push((error, expected_error));
            }
            (
                RuntimeTypeShape::BuiltinVariant { owner, cases },
                RuntimeTypeSchema::Builtin(schema),
            ) if *owner == schema.owner() && cases.len() == owner.cases().len() => {
                for (ordinal, case) in cases.iter().enumerate() {
                    let Some((_, expected)) = schema.case(ordinal) else {
                        return false;
                    };
                    match (case, expected) {
                        (None, None) => {}
                        (Some(payload), Some(expected)) => {
                            let RuntimeTypeShape::Tuple(fields) = payload.shape() else {
                                return false;
                            };
                            let [field] = fields.as_ref() else {
                                return false;
                            };
                            pending.push((field, expected));
                        }
                        _ => return false,
                    }
                }
            }
            (RuntimeTypeShape::Tuple(items), RuntimeTypeSchema::Tuple(expected))
            | (RuntimeTypeShape::Choice(items), RuntimeTypeSchema::Choice(expected))
                if items.len() == expected.len() =>
            {
                pending.extend(items.iter().zip(expected.iter()));
            }
            (
                RuntimeTypeShape::Record(fields),
                RuntimeTypeSchema::RecordValue { fields: expected },
            ) if fields.len() == expected.len() => {
                for (ordinal, (field, expected)) in fields.iter().zip(expected.iter()).enumerate() {
                    if u32::try_from(ordinal).ok() != Some(expected.field().zero_based())
                        || field.diagnostic_name() != expected.name()
                    {
                        return false;
                    }
                    pending.push((field.ty(), expected.schema()));
                }
            }
            (
                RuntimeTypeShape::Nominal { nominal, arguments },
                RuntimeTypeSchema::NominalRef(expected),
            ) if nominal.identity() == expected.semantic_identity()
                && nominal.runtime_nominal_id() == expected.nominal().clone() =>
            {
                let Some(definition) = graph.definition(expected.semantic_identity()) else {
                    return false;
                };
                if definition.identity() != expected
                    || definition.arguments().len() != arguments.len()
                {
                    return false;
                }
                pending.extend(arguments.iter().zip(definition.arguments()));
            }
            (
                RuntimeTypeShape::Opaque {
                    producer,
                    admission,
                    value_class,
                    persistence,
                    arguments,
                },
                RuntimeTypeSchema::ExactOpaque {
                    owner,
                    arguments: expected,
                },
            ) if owner
                == &RuntimeOpaqueTypeOwner::with_admission(
                    producer.clone(),
                    normalized.identity(),
                    *admission,
                    *value_class,
                    *persistence,
                )
                && arguments.len() == expected.len() =>
            {
                pending.extend(arguments.iter().zip(expected.iter()));
            }
            _ => return false,
        }
    }
    true
}

fn validate_normalized_variant_payloads(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    cases: &[RuntimeNormalizedVariantCase],
) -> Result<(), RuntimeSemanticFactsError> {
    for case in cases {
        if let Some(payload) = case.payload() {
            validate_normalized_type(modules, payload)?;
        }
    }
    Ok(())
}

fn validate_normalized_type(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    ty: &RuntimeNormalizedType,
) -> Result<(), RuntimeSemanticFactsError> {
    match ty.shape() {
        RuntimeTypeShape::EntityReference(reference) => {
            if let Some(payload) = reference.payload() {
                validate_normalized_type(modules, payload)?;
            }
            Ok(())
        }
        RuntimeTypeShape::Range(item)
        | RuntimeTypeShape::Iterator(item)
        | RuntimeTypeShape::Sequence { item, .. }
        | RuntimeTypeShape::Array { item, .. }
        | RuntimeTypeShape::ThreadHandle(item)
        | RuntimeTypeShape::Shared(item)
        | RuntimeTypeShape::Reference(item)
        | RuntimeTypeShape::Need(item) => validate_normalized_type(modules, item),
        RuntimeTypeShape::Agent(
            RuntimeAgentTypeShape::Probe(value) | RuntimeAgentTypeShape::DataShape(value),
        ) => validate_normalized_type(modules, value),
        RuntimeTypeShape::Traversal { source, mapping } => {
            validate_normalized_type(modules, source)?;
            validate_normalized_type(modules, mapping)?;
            let invalid = || RuntimeSemanticFactsError::InvalidTraversalType {
                identity: ty.identity(),
            };
            let input = match source.shape() {
                RuntimeTypeShape::Sequence { item, .. } | RuntimeTypeShape::Array { item, .. } => {
                    item
                }
                _ => return Err(invalid()),
            };
            let RuntimeTypeShape::Function {
                parameters, result, ..
            } = mapping.shape()
            else {
                return Err(invalid());
            };
            if parameters.len() != 1 || parameters[0].identity() != input.identity() {
                return Err(invalid());
            }
            let RuntimeTypeShape::Need(payload) = result.shape() else {
                return Err(invalid());
            };
            if !matches!(payload.shape(), RuntimeTypeShape::Result { .. }) {
                return Err(invalid());
            }
            Ok(())
        }
        RuntimeTypeShape::Map { key, value, .. }
        | RuntimeTypeShape::Stream {
            item: key,
            error: value,
        }
        | RuntimeTypeShape::Parser {
            item: key,
            error: value,
        } => {
            validate_normalized_type(modules, key)?;
            validate_normalized_type(modules, value)
        }
        RuntimeTypeShape::Option { item, some_payload } => {
            validate_normalized_type(modules, item)?;
            validate_normalized_type(modules, some_payload)?;
            if normalized_tuple_payload_matches(some_payload, std::slice::from_ref(&item.as_ref()))
            {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            }
        }
        RuntimeTypeShape::Result {
            value,
            error,
            value_payload,
            error_payload,
        } => {
            validate_normalized_type(modules, value)?;
            validate_normalized_type(modules, error)?;
            validate_normalized_type(modules, value_payload)?;
            validate_normalized_type(modules, error_payload)?;
            if normalized_tuple_payload_matches(
                value_payload,
                std::slice::from_ref(&value.as_ref()),
            ) && normalized_tuple_payload_matches(
                error_payload,
                std::slice::from_ref(&error.as_ref()),
            ) {
                Ok(())
            } else {
                Err(RuntimeSemanticFactsError::WrongVariantIdentity)
            }
        }
        RuntimeTypeShape::BuiltinVariant { cases, .. } => {
            for payload in cases.iter().flatten() {
                validate_normalized_type(modules, payload)?;
            }
            ty.checked_type()
                .map(|_| ())
                .map_err(|_| RuntimeSemanticFactsError::WrongVariantIdentity)
        }
        RuntimeTypeShape::Function {
            parameters, result, ..
        } => {
            for parameter in parameters {
                validate_normalized_type(modules, parameter)?;
            }
            validate_normalized_type(modules, result)
        }
        RuntimeTypeShape::Nominal { nominal, arguments } => {
            validate_nominal(modules, nominal)?;
            for argument in arguments {
                validate_normalized_type(modules, argument)?;
            }
            Ok(())
        }
        RuntimeTypeShape::Opaque { arguments, .. } => {
            for argument in arguments {
                validate_normalized_type(modules, argument)?;
            }
            Ok(())
        }
        RuntimeTypeShape::Tuple(items) | RuntimeTypeShape::Choice(items) => {
            for item in items {
                validate_normalized_type(modules, item)?;
            }
            Ok(())
        }
        RuntimeTypeShape::Record(fields) => {
            for field in fields {
                validate_normalized_type(modules, field.ty())?;
            }
            ty.checked_type()
                .map(|_| ())
                .map_err(|_| RuntimeSemanticFactsError::WrongVariantIdentity)
        }
        RuntimeTypeShape::BoundType(_)
        | RuntimeTypeShape::PresentationResource(_)
        | RuntimeTypeShape::Unit
        | RuntimeTypeShape::Never
        | RuntimeTypeShape::Bool
        | RuntimeTypeShape::Signed(_)
        | RuntimeTypeShape::Unsigned(_)
        | RuntimeTypeShape::F32
        | RuntimeTypeShape::F64
        | RuntimeTypeShape::String
        | RuntimeTypeShape::Color
        | RuntimeTypeShape::Char
        | RuntimeTypeShape::Bytes
        | RuntimeTypeShape::Duration
        | RuntimeTypeShape::Progress
        | RuntimeTypeShape::DenseNumeric(_)
        | RuntimeTypeShape::AgentValue
        | RuntimeTypeShape::Agent(
            RuntimeAgentTypeShape::DebugStatePath
            | RuntimeAgentTypeShape::ObservationFieldPath
            | RuntimeAgentTypeShape::Predicate
            | RuntimeAgentTypeShape::Observation
            | RuntimeAgentTypeShape::ObservedObject
            | RuntimeAgentTypeShape::BoundingBox
            | RuntimeAgentTypeShape::ActionName
            | RuntimeAgentTypeShape::ActionTarget
            | RuntimeAgentTypeShape::ActionResult
            | RuntimeAgentTypeShape::EntityMetadata
            | RuntimeAgentTypeShape::SourceAnchor
            | RuntimeAgentTypeShape::ProjectGraphNeighborhood
            | RuntimeAgentTypeShape::ProjectGraphSymbol
            | RuntimeAgentTypeShape::ProjectGraphEdge
            | RuntimeAgentTypeShape::CaptureTarget
            | RuntimeAgentTypeShape::CaptureReference
            | RuntimeAgentTypeShape::Resource
            | RuntimeAgentTypeShape::RagContextPack
            | RuntimeAgentTypeShape::ObservedObjectId
            | RuntimeAgentTypeShape::Diagnostics
            | RuntimeAgentTypeShape::WaitError
            | RuntimeAgentTypeShape::ViewportPoint
            | RuntimeAgentTypeShape::RagError
            | RuntimeAgentTypeShape::SourcePosition
            | RuntimeAgentTypeShape::ProjectFlowControlSummary
            | RuntimeAgentTypeShape::ProjectGraphSummary
            | RuntimeAgentTypeShape::BinaryResourceBody
            | RuntimeAgentTypeShape::BinaryData,
        ) => Ok(()),
    }
}

fn validate_call(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    expression_types: &RuntimeExpressionTypeView<'_>,
    expression: ExprId,
    expression_source_type: Option<&RuntimeNormalizedType>,
    hir_call: &HirCallInvocation,
    attached_body: Option<arcweft_lang_hir::dialogue_application::HirAttachedContentBodyPresence>,
    call: &RuntimeResolvedCall,
) -> Result<(), RuntimeSemanticFactsError> {
    use arcweft_lang_hir::dialogue_application::HirAttachedContentBodyPresence;

    let attached_matches = match call.attached_content() {
        Some(RuntimeResolvedAttachedContent::Required { source, ty }) => {
            *source == expression
                && expression_types.get(source) == Some(ty)
                && attached_body == Some(HirAttachedContentBodyPresence::Present)
        }
        Some(RuntimeResolvedAttachedContent::OptionalPresent { source, ty })
        | Some(RuntimeResolvedAttachedContent::DefaultedPresent { source, ty }) => {
            *source == expression
                && matches!(
                    (ty.shape(), expression_types.get(source)),
                    (RuntimeTypeShape::Option { item, .. }, Some(source_ty))
                        if item.as_ref() == source_ty
                )
                && attached_body == Some(HirAttachedContentBodyPresence::Present)
        }
        Some(RuntimeResolvedAttachedContent::OptionalOmitted { ty })
        | Some(RuntimeResolvedAttachedContent::DefaultedOmitted { ty }) => {
            validate_normalized_type(modules, ty).is_ok()
                && matches!(ty.shape(), RuntimeTypeShape::Option { .. })
                && attached_body != Some(HirAttachedContentBodyPresence::Present)
        }
        None => attached_body != Some(HirAttachedContentBodyPresence::Present),
    };
    if !attached_matches {
        return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression });
    }
    if let Some(producer) = call.need_producer() {
        let Some(result_type) = expression_source_type else {
            return Err(RuntimeSemanticFactsError::InvalidNeedProducerFact { expression });
        };
        if producer.need_type() != result_type
            || !matches!(result_type.shape(), RuntimeTypeShape::Need(_))
        {
            return Err(RuntimeSemanticFactsError::InvalidNeedProducerFact { expression });
        }
        validate_normalized_type(modules, producer.need_type())?;
    }
    if let Some(plan) = call.project_function() {
        validate_callable(modules, plan.callable())?;
        if let Some(function_type) = plan.input().function_type() {
            validate_normalized_type(modules, function_type)?;
            let Some(callee) = plan.input().callee() else {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            };
            if expression_types.get(&callee) != Some(function_type) {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
        if let Some(function_type) = plan.outcome().function_type() {
            validate_normalized_type(modules, function_type)?;
            if expression_source_type != Some(function_type) {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
    } else if matches!(
        call.dispatch(),
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Declaration(
            callable
        )) if callable.declaration().owner() == CallableDeclarationOwner::Function
    ) {
        return Err(RuntimeSemanticFactsError::MissingProjectFunctionCallPlan);
    }
    match call.dispatch() {
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::ProgramNeed(_)) => {
            if call.program_fanout().is_none() && call.action_receive().is_none() {
                return Err(RuntimeSemanticFactsError::InvalidNeedProducerFact { expression });
            }
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::PresentationHandleMethod { method, receiver },
        ) => {
            let invalid =
                || RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression };
            let [operand] = call.operands() else {
                return Err(invalid());
            };
            let resource = match operand.ty().shape() {
                RuntimeTypeShape::Opaque {
                    producer,
                    admission,
                    value_class,
                    persistence,
                    ..
                } => RuntimeOpaqueTypeOwner::with_admission(
                    producer.clone(),
                    operand.ty().identity(),
                    *admission,
                    *value_class,
                    *persistence,
                )
                .presentation_handle_resource(),
                _ => None,
            };
            if *operand.origin() != RuntimeResolvedCallOperandOrigin::Receiver
                || operand.source() != RuntimeResolvedCallOperandSource::Expression(*receiver)
                || operand.abi_position() != 0
                || resource.is_none()
                || !method.accepts_resource(resource)
                || !matches!(
                    expression_source_type.map(RuntimeNormalizedType::shape),
                    Some(RuntimeTypeShape::Unit)
                )
                || call.attached_content().is_some()
            {
                return Err(invalid());
            }
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Traverse) => {
            if !call.accepts_traversal_type(expression_source_type) {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Declaration(
            callable,
        )) => {
            validate_callable(modules, callable)?;
            if call.flow_transfer_target().is_some()
                && !module_for(modules, expression.module())?.statements().any(|(_, statement)| {
                    matches!(statement.kind(), HirStmtKind::Goto { target } if *target == expression)
                })
            {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression });
            }
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Host(host)) => {
            if let RuntimeResolvedHostCallOwner::ExternCapability { callable, .. } = host.owner() {
                validate_callable(modules, callable)?;
            }
        }
        RuntimeResolvedCallDispatch::Value { callee } => {
            if !matches!(
                hir_call.callee(),
                arcweft_lang_hir::expr::HirCallCallee::Value { value } if value == callee
            ) {
                return Err(RuntimeSemanticFactsError::MissingFunctionValueCallee);
            }
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Variant(variant)) => {
            validate_variant(modules, variant)?;
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::RecordConstructor { record, receiver },
        ) => {
            validate_nominal_record(modules, record)?;
            let invalid =
                || RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression };
            let RuntimeResolvedNominalSource::Project { declaration, .. } =
                record.nominal().source()
            else {
                return Err(invalid());
            };
            let arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Action {
                public_id,
            } = declaration.kind()
            else {
                return Err(invalid());
            };
            if hir_call.callee().value_expression() != Some(*receiver)
                || call.completed_group.get() != 0
                || call.result() != RuntimeCallResultShape::Value
                || call.attached_content().is_some()
                || call.project_function().is_some()
                || call.need_producer().is_some()
                || call.mutation().is_some()
                || expression_source_type.map(RuntimeNormalizedType::identity)
                    != Some(record.nominal().identity())
                || call.operands().len() != record.fields().len().saturating_add(1)
            {
                return Err(invalid());
            }
            let mut receivers = call.operands().iter().filter(|operand| {
                matches!(operand.origin(), RuntimeResolvedCallOperandOrigin::Receiver)
            });
            let channel = receivers.next().ok_or_else(invalid)?;
            if receivers.next().is_some()
                || channel.source() != RuntimeResolvedCallOperandSource::Expression(*receiver)
                || channel.abi_position() != 0
                || !matches!(channel.ty().shape(), RuntimeTypeShape::EntityReference(reference)
                    if reference.family() == Some(arcweft_id::ProjectEntityReferenceFamily::Action)
                    && reference.declaration() == Some(public_id)
                    && reference.payload().is_some_and(|payload| payload.identity() == record.nominal().identity()))
                || !matches!(
                    channel.projection(),
                    RuntimeResolvedCallOperandProjection::Scalar
                )
            {
                return Err(invalid());
            }
            for (ordinal, field) in record.fields().iter().enumerate() {
                let ordinal = u32::try_from(ordinal).map_err(|_| invalid())?;
                let mut fields = call.operands().iter().filter(|operand| {
                    operand.parameter() == Some(RuntimeCallParameterCoordinate::new(0, ordinal))
                });
                let operand = fields.next().ok_or_else(invalid)?;
                if fields.next().is_some()
                    || operand.abi_position() != ordinal.saturating_add(1)
                    || operand.ty() != field.ty()
                    || !matches!(
                        operand.origin(),
                        RuntimeResolvedCallOperandOrigin::Argument { .. }
                    )
                    || !matches!(
                        operand.projection(),
                        RuntimeResolvedCallOperandProjection::Scalar
                    )
                {
                    return Err(invalid());
                }
            }
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::CharacterDialogue(dialogue),
        ) => {
            if !dialogue.accepts_source_row(call.operands(), call.result())
                || !dialogue.accepts_types(call.operands(), expression_source_type)
            {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::PresentationView {
                call: view,
                resource_type,
                body_type,
            },
        ) => {
            let invalid =
                || RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression };
            if expression_source_type != Some(resource_type)
                || resource_type.identity() != view.resource_type()
                || body_type.identity() != view.body_type()
                || !matches!(
                    resource_type.shape(),
                    RuntimeTypeShape::PresentationResource(
                        arcweft_interaction_model::presentation::PresentationResourceKind::View
                    )
                )
            {
                return Err(invalid());
            }
            validate_normalized_type(modules, resource_type)?;
            validate_normalized_type(modules, body_type)?;
            let RuntimeTypeShape::Tuple(fields) = body_type.shape() else {
                return Err(invalid());
            };
            let identity =
                arcweft_core::presentation::RuntimePresentationViewCall::retained_body_identity(
                    view.view(),
                    view.definition(),
                    view.parameters(),
                    view.supplied(),
                    view.resource_type(),
                    body_type.scope(),
                    fields.len(),
                    |index| fields.get(index).map(RuntimeNormalizedType::identity),
                )
                .map_err(|_| invalid())?;
            if identity != body_type.identity()
                || fields.len() != view.supplied().len()
                || fields.len() != call.operands().len()
            {
                return Err(invalid());
            }
            let mut operands = call.operands().iter().collect::<Vec<_>>();
            operands.sort_unstable_by_key(|operand| operand.abi_position());
            if operands.iter().enumerate().any(|(index, operand)| {
                usize::try_from(operand.abi_position()).ok() != Some(index)
                    || operand.ty() != &fields[index]
            }) {
                return Err(invalid());
            }
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::PresentationFactory {
                call: factory,
                resource_type,
                body_type,
            },
        ) => {
            let invalid =
                || RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression };
            let result = expression_source_type.ok_or_else(invalid)?;
            let expected =
                RuntimeOpaqueTypeOwner::presentation_handle(factory.resource(), result.identity());
            if !matches!(result.shape(), RuntimeTypeShape::Opaque { producer, admission, value_class, persistence, arguments }
                if producer == expected.producer() && *admission == expected.admission() && *value_class == expected.value_class() && *persistence == expected.persistence() && arguments.is_empty())
            {
                return Err(invalid());
            }
            validate_normalized_type(modules, resource_type)?;
            validate_normalized_type(modules, body_type)?;
            if resource_type.identity() != factory.resource_type()
                || body_type.identity() != factory.body_type()
                || !matches!(resource_type.shape(), RuntimeTypeShape::PresentationResource(kind) if *kind == factory.resource())
            {
                return Err(invalid());
            }
            let RuntimeTypeShape::Tuple(fields) = body_type.shape() else {
                return Err(invalid());
            };
            let identity =
                arcweft_core::presentation::RuntimePresentationFactoryCall::retained_body_identity(
                    factory.callable(),
                    factory.inputs(),
                    resource_type.identity(),
                    body_type.scope(),
                    fields.len(),
                    |ordinal| fields.get(ordinal).map(RuntimeNormalizedType::identity),
                )
                .map_err(|_| invalid())?;
            if identity != body_type.identity()
                || fields.len() != factory.body_len()
                || call.operands().len() != factory.inputs().len()
            {
                return Err(invalid());
            }
            let mut operands = call.operands().iter().collect::<Vec<_>>();
            operands.sort_unstable_by_key(|operand| operand.abi_position());
            if operands.iter().enumerate().any(|(ordinal, operand)| {
                usize::try_from(operand.abi_position()).ok() != Some(ordinal)
            }) {
                return Err(invalid());
            }
            for (ordinal, field) in fields.iter().enumerate() {
                let input = factory.body_input_index(ordinal).ok_or_else(invalid)?;
                if operands[input].ty() != field {
                    return Err(invalid());
                }
            }
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::Agent(_)
            | RuntimeResolvedStaticCallTarget::AgentProbeComparison(_)
            | RuntimeResolvedStaticCallTarget::AgentDiagnosticsHasError
            | RuntimeResolvedStaticCallTarget::Reduction(_)
            | RuntimeResolvedStaticCallTarget::VecPopFront
            | RuntimeResolvedStaticCallTarget::VecPop
            | RuntimeResolvedStaticCallTarget::VecPush
            | RuntimeResolvedStaticCallTarget::Intrinsic(_)
            | RuntimeResolvedStaticCallTarget::PresentationSlot(_)
            | RuntimeResolvedStaticCallTarget::Format(_)
            | RuntimeResolvedStaticCallTarget::TraitMethod { .. }
            | RuntimeResolvedStaticCallTarget::Registered(_),
        ) => {}
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::StandardMapPrefix(map),
        ) => {
            if !runtime_standard_map_prefix_matches_operands(call, map, expression_source_type) {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::StandardMap(map)) => {
            if !runtime_standard_map_matches_operands(call, map, expression_source_type) {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Line(line)) => {
            if !runtime_line_callable_matches_operands(call, line) {
                return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                    expression,
                });
            }
        }
    }

    let module = modules
        .get(&expression.module())
        .copied()
        .ok_or(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression })?;
    let count = hir_call.arguments().len();
    let mut origins = BTreeSet::new();
    let expected_receiver = module
        .resolve_call_value_receiver(hir_call)
        .map_err(|_| RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression })?;
    for operand in call.operands() {
        if !origins.insert(operand.origin().clone()) {
            return Err(RuntimeSemanticFactsError::DuplicateCallArgument);
        }
        if !runtime_call_projection_matches_type(operand) {
            return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression });
        }
        match operand.origin() {
            RuntimeResolvedCallOperandOrigin::Callee => {
                let RuntimeResolvedCallOperandSource::Expression(source) = operand.source() else {
                    return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                        expression,
                    });
                };
                if hir_call.callee().value_expression() != Some(source)
                    || !matches!(
                        operand.binding(),
                        RuntimeResolvedCallOperandBinding::Positional
                    )
                    || operand.parameter().is_some()
                    || expression_types.get(&source) != Some(operand.ty())
                    || !matches!(
                        call.dispatch(),
                        RuntimeResolvedCallDispatch::Static(
                            RuntimeResolvedStaticCallTarget::CharacterDialogue(_)
                        )
                    )
                {
                    return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                        expression,
                    });
                }
            }
            RuntimeResolvedCallOperandOrigin::Receiver => {
                let RuntimeResolvedCallOperandSource::Expression(source) = operand.source() else {
                    return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                        expression,
                    });
                };
                if expected_receiver != Some(source)
                    || !matches!(
                        operand.binding(),
                        RuntimeResolvedCallOperandBinding::Positional
                    )
                    || !matches!(
                        operand.projection(),
                        RuntimeResolvedCallOperandProjection::Scalar
                    )
                    || operand.parameter().is_some()
                    || expression_types.get(&source) != Some(operand.ty())
                {
                    return Err(RuntimeSemanticFactsError::MissingRuntimeCallReceiver {
                        expression,
                    });
                }
            }
            RuntimeResolvedCallOperandOrigin::Argument { argument, slot } => {
                let ordinal = usize::try_from(*argument).map_err(|_| {
                    RuntimeSemanticFactsError::InvalidCallArgumentOrdinal {
                        ordinal: *argument,
                        count,
                    }
                })?;
                let authored = hir_call.arguments().get(ordinal).ok_or(
                    RuntimeSemanticFactsError::InvalidCallArgumentOrdinal {
                        ordinal: *argument,
                        count,
                    },
                )?;
                match operand.source() {
                    RuntimeResolvedCallOperandSource::Expression(source) => {
                        let expected_source = match (
                            authored,
                            operand.projection(),
                            module
                                .resolve_expr(authored.value())
                                .map(|value| value.kind()),
                        ) {
                            (
                                HirCallArgument::Spread { .. },
                                RuntimeResolvedCallOperandProjection::Scalar,
                                Ok(HirExprKind::BracketSequence(sequence)),
                            ) => usize::try_from(*slot)
                                .ok()
                                .and_then(|ordinal| sequence.elements().get(ordinal).copied()),
                            (
                                HirCallArgument::Spread { .. },
                                RuntimeResolvedCallOperandProjection::Scalar,
                                _,
                            ) => None,
                            _ => (*slot == 0).then_some(authored.value()),
                        };
                        if Some(source) != expected_source {
                            return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                                expression,
                            });
                        }
                        if expression_types.get(&source) != Some(operand.ty()) {
                            return Err(RuntimeSemanticFactsError::CallOperandTypeMismatch {
                                expression,
                                operand: source,
                                expected: operand.ty().identity(),
                                actual: expression_types
                                    .get(&source)
                                    .map(RuntimeNormalizedType::identity),
                            });
                        }
                    }
                    RuntimeResolvedCallOperandSource::CompactNumericElement {
                        sequence,
                        ordinal,
                    } => {
                        if sequence != authored.value()
                            || ordinal != *slot
                            || !matches!(authored, HirCallArgument::Spread { .. })
                            || !matches!(
                                operand.projection(),
                                RuntimeResolvedCallOperandProjection::Scalar
                            )
                            || !expression_types.contains_key(&sequence)
                        {
                            return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                                expression,
                            });
                        }
                        let sequence_expression = module.resolve_expr(sequence).map_err(|_| {
                            RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression }
                        })?;
                        let HirExprKind::NumericBracketSequence(sequence) =
                            sequence_expression.kind()
                        else {
                            return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                                expression,
                            });
                        };
                        if usize::try_from(ordinal)
                            .map_or(true, |ordinal| ordinal >= sequence.elements().len())
                        {
                            return Err(RuntimeSemanticFactsError::InvalidCallArgumentOrdinal {
                                ordinal,
                                count: sequence.elements().len(),
                            });
                        }
                    }
                }
                let binding_matches = match authored {
                    HirCallArgument::Positional { .. } => matches!(
                        operand.binding(),
                        RuntimeResolvedCallOperandBinding::Positional
                    ),
                    HirCallArgument::Named { .. } => matches!(
                        operand.binding(),
                        RuntimeResolvedCallOperandBinding::Named(name)
                            if authored.resolved_name() == Some(name)
                    ),
                    HirCallArgument::Spread { .. } => matches!(
                        operand.binding(),
                        RuntimeResolvedCallOperandBinding::Positional
                    ),
                };
                if !binding_matches {
                    return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                        expression,
                    });
                }
                if matches!(
                    operand.projection(),
                    RuntimeResolvedCallOperandProjection::SpreadContainer(_)
                ) && !matches!(authored, HirCallArgument::Spread { .. })
                {
                    return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition {
                        expression,
                    });
                }
            }
        }
    }
    if let Some(mutation) = call.mutation() {
        let (source, target, is_push) = match mutation {
            RuntimeResolvedCallMutation::VecPopFront { source, .. } => {
                (source, RuntimeResolvedStaticCallTarget::VecPopFront, false)
            }
            RuntimeResolvedCallMutation::VecPop { source, .. } => {
                (source, RuntimeResolvedStaticCallTarget::VecPop, false)
            }
            RuntimeResolvedCallMutation::VecPush { source, .. } => {
                (source, RuntimeResolvedStaticCallTarget::VecPush, true)
            }
        };
        let receiver_matches = call.operands().first().is_some_and(|receiver| {
            *receiver.origin() == RuntimeResolvedCallOperandOrigin::Receiver
                && receiver.source() == RuntimeResolvedCallOperandSource::Expression(*source)
                && matches!(
                    receiver.ty().shape(),
                    RuntimeTypeShape::Sequence {
                        kind: RuntimeSequenceKind::Vec,
                        item,
                    } if if is_push {
                        call.operands().get(1).is_some_and(|argument| {
                            argument.ty() == item.as_ref()
                                && matches!(
                                    argument.origin(),
                                    RuntimeResolvedCallOperandOrigin::Argument { argument: 0, slot: 0 }
                                )
                        }) && expression_source_type.is_some_and(|result| {
                            matches!(result.shape(), RuntimeTypeShape::Unit)
                        })
                    } else {
                        expression_source_type.is_some_and(|result| {
                            matches!(
                                result.shape(),
                                RuntimeTypeShape::Option { item: result_item, .. }
                                    if result_item.as_ref() == item.as_ref()
                            )
                        })
                    }
                )
        });
        if !receiver_matches
            || call.result() != RuntimeCallResultShape::Value
            || call.dispatch() != &RuntimeResolvedCallDispatch::Static(target)
        {
            return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression });
        }
    } else if matches!(
        call.dispatch(),
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::VecPopFront
                | RuntimeResolvedStaticCallTarget::VecPop
                | RuntimeResolvedStaticCallTarget::VecPush
        )
    ) {
        return Err(RuntimeSemanticFactsError::InvalidRuntimeCallDisposition { expression });
    }
    match call.dispatch() {
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Reduction(_))
            if (!matches!(
                call.operands(),
                [RuntimeResolvedCallOperand {
                    origin: RuntimeResolvedCallOperandOrigin::Argument {
                        argument: 0,
                        slot: 0
                    },
                    binding: RuntimeResolvedCallOperandBinding::Positional,
                    projection: RuntimeResolvedCallOperandProjection::Scalar,
                    ..
                }]
            ) || call.result() != RuntimeCallResultShape::Value) =>
        {
            return Err(RuntimeSemanticFactsError::InvalidReductionConstructorCall);
        }
        RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Agent(_))
            if call.operands().iter().any(|operand| {
                matches!(operand.origin(), RuntimeResolvedCallOperandOrigin::Receiver)
            }) =>
        {
            return Err(RuntimeSemanticFactsError::InvalidAgentCallArguments);
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::AgentProbeComparison(_),
        ) if !matches!(
            call.operands(),
            [
                RuntimeResolvedCallOperand {
                    origin: RuntimeResolvedCallOperandOrigin::Receiver,
                    ..
                },
                RuntimeResolvedCallOperand {
                    origin: RuntimeResolvedCallOperandOrigin::Argument { argument: 0, .. },
                    ..
                }
            ]
        ) || call.result() != RuntimeCallResultShape::Value =>
        {
            return Err(RuntimeSemanticFactsError::InvalidAgentCallArguments);
        }
        RuntimeResolvedCallDispatch::Static(
            RuntimeResolvedStaticCallTarget::AgentDiagnosticsHasError,
        ) if !matches!(
            call.operands(),
            [RuntimeResolvedCallOperand {
                origin: RuntimeResolvedCallOperandOrigin::Receiver,
                ..
            }]
        ) || call.result() != RuntimeCallResultShape::Value =>
        {
            return Err(RuntimeSemanticFactsError::InvalidAgentCallArguments);
        }
        _ => {}
    }
    Ok(())
}

fn runtime_standard_map_matches_operands(
    call: &RuntimeResolvedCall,
    map: &RuntimeStandardMapCall,
    result: Option<&RuntimeNormalizedType>,
) -> bool {
    if call.result() != RuntimeCallResultShape::Value {
        return false;
    }
    let mut mappings = call
        .operands()
        .iter()
        .filter(|operand| operand.parameter() == Some(RuntimeCallParameterCoordinate::new(0, 0)));
    let Some(mapping) = mappings.next() else {
        return false;
    };
    if mappings.next().is_some()
        || mapping.source() != RuntimeResolvedCallOperandSource::Expression(map.mapping())
        || !matches!(
            mapping.projection(),
            RuntimeResolvedCallOperandProjection::Scalar
        )
    {
        return false;
    }
    let mut receivers = call.operands().iter().filter(|operand| {
        matches!(operand.origin(), RuntimeResolvedCallOperandOrigin::Receiver)
            || operand.parameter() == Some(RuntimeCallParameterCoordinate::new(1, 0))
    });
    let Some(receiver) = receivers.next() else {
        return false;
    };
    if receivers.next().is_some()
        || receiver.source() != RuntimeResolvedCallOperandSource::Expression(map.receiver())
        || !matches!(
            receiver.projection(),
            RuntimeResolvedCallOperandProjection::Scalar
        )
    {
        return false;
    }
    match map.order() {
        RuntimeStandardMapOperandOrder::ReceiverThenMapping
            if !matches!(
                receiver.origin(),
                RuntimeResolvedCallOperandOrigin::Receiver
            ) =>
        {
            return false;
        }
        RuntimeStandardMapOperandOrder::MappingThenReceiver
            if matches!(
                receiver.origin(),
                RuntimeResolvedCallOperandOrigin::Receiver
            ) =>
        {
            return false;
        }
        RuntimeStandardMapOperandOrder::MappingThenReceiver
        | RuntimeStandardMapOperandOrder::ReceiverThenMapping => {}
    }
    let Some(result) = result else {
        return false;
    };
    runtime_standard_map_types_match(
        map.family(),
        map.collection(),
        mapping.ty(),
        receiver.ty(),
        result,
    )
}

fn runtime_standard_map_prefix_matches_operands(
    call: &RuntimeResolvedCall,
    map: &RuntimeStandardMapPrefix,
    function: Option<&RuntimeNormalizedType>,
) -> bool {
    if call.result() != RuntimeCallResultShape::PartialFunction {
        return false;
    }
    let [mapping] = call.operands() else {
        return false;
    };
    if mapping.parameter() != Some(RuntimeCallParameterCoordinate::new(0, 0))
        || mapping.source() != RuntimeResolvedCallOperandSource::Expression(map.mapping())
        || !matches!(
            mapping.projection(),
            RuntimeResolvedCallOperandProjection::Scalar
        )
    {
        return false;
    }
    let Some(RuntimeTypeShape::Function {
        parameters, result, ..
    }) = function.map(RuntimeNormalizedType::shape)
    else {
        return false;
    };
    let [receiver] = parameters.as_ref() else {
        return false;
    };
    runtime_standard_map_types_match(
        map.family(),
        map.collection(),
        mapping.ty(),
        receiver,
        result,
    )
}

fn runtime_standard_map_types_match(
    family: RuntimeStandardMapFamily,
    collection: Option<&RuntimeStandardMapCollection>,
    mapping: &RuntimeNormalizedType,
    receiver: &RuntimeNormalizedType,
    result: &RuntimeNormalizedType,
) -> bool {
    let RuntimeTypeShape::Function {
        parameters,
        result: mapping_result,
        ..
    } = mapping.shape()
    else {
        return false;
    };
    let [mapping_input] = parameters.as_ref() else {
        return false;
    };
    let Some((receiver_input, result_output)) = family.item_types(receiver, result) else {
        return false;
    };
    let iteration_matches = match family {
        RuntimeStandardMapFamily::Vec
        | RuntimeStandardMapFamily::Seq
        | RuntimeStandardMapFamily::Slice
        | RuntimeStandardMapFamily::Array => collection.is_some_and(|collection| {
            let iteration = collection.iteration();
            let accumulator_matches = match family {
                RuntimeStandardMapFamily::Array => matches!(collection.accumulator().shape(),
                    RuntimeTypeShape::Sequence { kind: RuntimeSequenceKind::Vec, item }
                        if item.as_ref() == result_output),
                _ => collection.accumulator() == result,
            };
            accumulator_matches
                && iteration.item() == receiver_input
                && matches!(
                    (family, iteration.family()),
                    (
                        RuntimeStandardMapFamily::Vec,
                        arcweft_core::plan::RuntimeBuiltinIteratorFamily::Vec
                    ) | (
                        RuntimeStandardMapFamily::Seq,
                        arcweft_core::plan::RuntimeBuiltinIteratorFamily::Seq
                    ) | (
                        RuntimeStandardMapFamily::Slice,
                        arcweft_core::plan::RuntimeBuiltinIteratorFamily::Slice
                    ) | (
                        RuntimeStandardMapFamily::Array,
                        arcweft_core::plan::RuntimeBuiltinIteratorFamily::Array
                    )
                )
        }),
        RuntimeStandardMapFamily::Option | RuntimeStandardMapFamily::Result => collection.is_none(),
    };
    mapping_input == receiver_input && mapping_result.as_ref() == result_output && iteration_matches
}

impl RuntimeStandardMapCall {
    pub(crate) fn item_types<'a>(
        &self,
        receiver: &'a RuntimeNormalizedType,
        result: &'a RuntimeNormalizedType,
    ) -> Option<(&'a RuntimeNormalizedType, &'a RuntimeNormalizedType)> {
        self.family().item_types(receiver, result)
    }
}

impl RuntimeStandardMapFamily {
    pub(crate) fn item_types<'a>(
        self,
        receiver: &'a RuntimeNormalizedType,
        result: &'a RuntimeNormalizedType,
    ) -> Option<(&'a RuntimeNormalizedType, &'a RuntimeNormalizedType)> {
        match (self, receiver.shape(), result.shape()) {
            (
                RuntimeStandardMapFamily::Vec,
                RuntimeTypeShape::Sequence {
                    kind: RuntimeSequenceKind::Vec,
                    item: input,
                },
                RuntimeTypeShape::Sequence {
                    kind: RuntimeSequenceKind::Vec,
                    item: output,
                },
            )
            | (
                RuntimeStandardMapFamily::Seq,
                RuntimeTypeShape::Sequence {
                    kind: RuntimeSequenceKind::Seq,
                    item: input,
                },
                RuntimeTypeShape::Sequence {
                    kind: RuntimeSequenceKind::Seq,
                    item: output,
                },
            )
            | (
                RuntimeStandardMapFamily::Slice,
                RuntimeTypeShape::Sequence {
                    kind: RuntimeSequenceKind::Slice,
                    item: input,
                },
                RuntimeTypeShape::Sequence {
                    kind: RuntimeSequenceKind::Vec,
                    item: output,
                },
            )
            | (
                RuntimeStandardMapFamily::Option,
                RuntimeTypeShape::Option { item: input, .. },
                RuntimeTypeShape::Option { item: output, .. },
            ) => Some((input, output)),
            (
                RuntimeStandardMapFamily::Array,
                RuntimeTypeShape::Array {
                    item: input,
                    length: input_length,
                },
                RuntimeTypeShape::Array {
                    item: output,
                    length: output_length,
                },
            ) if input_length == output_length => Some((input, output)),
            (
                RuntimeStandardMapFamily::Result,
                RuntimeTypeShape::Result {
                    value: input,
                    error: input_error,
                    ..
                },
                RuntimeTypeShape::Result {
                    value: output,
                    error: output_error,
                    ..
                },
            ) if input_error == output_error => Some((input, output)),
            _ => None,
        }
    }
}

fn runtime_line_callable_matches_operands(
    call: &RuntimeResolvedCall,
    line: &RuntimeLineCallable,
) -> bool {
    let exact_operand =
        |source: ExprId, parameter: Option<RuntimeCallParameterCoordinate>, receiver: bool| {
            let mut operands = call.operands().iter().filter(|operand| {
                matches!(
                    (receiver, operand.origin()),
                    (true, RuntimeResolvedCallOperandOrigin::Receiver)
                        | (false, RuntimeResolvedCallOperandOrigin::Argument { .. })
                ) && operand.parameter() == parameter
                    && operand.source() == RuntimeResolvedCallOperandSource::Expression(source)
                    && matches!(
                        operand.projection(),
                        RuntimeResolvedCallOperandProjection::Scalar
                    )
            });
            operands.next().is_some() && operands.next().is_none()
        };
    match line {
        RuntimeLineCallable::ActorLook {
            character: _,
            actor,
            look,
            crossfade,
        } => {
            exact_operand(*actor, None, true)
                && exact_operand(
                    *look,
                    Some(RuntimeCallParameterCoordinate::new(0, 0)),
                    false,
                )
                && match crossfade {
                    Some(crossfade) => exact_operand(
                        *crossfade,
                        Some(RuntimeCallParameterCoordinate::new(0, 1)),
                        false,
                    ),
                    None => !call.operands().iter().any(|operand| {
                        operand.parameter() == Some(RuntimeCallParameterCoordinate::new(0, 1))
                    }),
                }
        }
        RuntimeLineCallable::Schedule { callback, .. } => exact_operand(
            *callback,
            Some(RuntimeCallParameterCoordinate::new(1, 0)),
            false,
        ),
        RuntimeLineCallable::AcquireActor { .. } | RuntimeLineCallable::VoiceHandle => true,
    }
}

fn runtime_call_projection_matches_type(operand: &RuntimeResolvedCallOperand) -> bool {
    match operand.projection() {
        RuntimeResolvedCallOperandProjection::Scalar => true,
        RuntimeResolvedCallOperandProjection::SpreadContainer(container) => {
            match (container, operand.ty().shape()) {
                (
                    RuntimeResolvedSpreadContainer::Vec,
                    RuntimeTypeShape::Sequence {
                        kind: RuntimeSequenceKind::Vec,
                        ..
                    },
                )
                | (
                    RuntimeResolvedSpreadContainer::Seq,
                    RuntimeTypeShape::Sequence {
                        kind: RuntimeSequenceKind::Seq,
                        ..
                    },
                )
                | (
                    RuntimeResolvedSpreadContainer::Slice,
                    RuntimeTypeShape::Sequence {
                        kind: RuntimeSequenceKind::Slice,
                        ..
                    },
                ) => true,
                (
                    RuntimeResolvedSpreadContainer::Array { len },
                    RuntimeTypeShape::Array { length, .. },
                ) => u64::try_from(*len).ok() == length.constant(),
                (
                    RuntimeResolvedSpreadContainer::MapValue { key, .. },
                    RuntimeTypeShape::Map { key: actual, .. },
                ) => key == actual.as_ref(),
                _ => false,
            }
        }
    }
}

fn validate_callable(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    callable: &RuntimeProjectCallable,
) -> Result<(), RuntimeSemanticFactsError> {
    let item = resolve_item(modules, callable.owner())?;
    let valid_family = matches!(
        (
            callable.declaration().owner(),
            callable.source_owner(),
            item.kind()
        ),
        (
            CallableDeclarationOwner::Function,
            HirCallableSourceOwner::Item,
            HirItemKind::Function(_)
        ) | (
            CallableDeclarationOwner::Flow,
            HirCallableSourceOwner::Item,
            HirItemKind::Flow(_)
        ) | (
            CallableDeclarationOwner::ExternCapability,
            HirCallableSourceOwner::ExternCapabilityFunction { .. },
            HirItemKind::ExternCapability(_)
        ) | (
            CallableDeclarationOwner::View,
            HirCallableSourceOwner::ViewItem,
            HirItemKind::View(_)
        ) | (
            CallableDeclarationOwner::Predicate,
            HirCallableSourceOwner::Item,
            HirItemKind::Predicate(_)
        ) | (
            CallableDeclarationOwner::Proof,
            HirCallableSourceOwner::Item,
            HirItemKind::Proof(_)
        ) | (
            CallableDeclarationOwner::TraitRequirement,
            HirCallableSourceOwner::TraitFunction { .. },
            HirItemKind::Trait(_)
        ) | (
            CallableDeclarationOwner::TraitImplementation
                | CallableDeclarationOwner::InherentMethod,
            HirCallableSourceOwner::ImplFunction { .. },
            HirItemKind::Impl(_)
        )
    );
    if !valid_family {
        let valid_item_family = matches!(
            (callable.declaration().owner(), item.kind()),
            (CallableDeclarationOwner::Function, HirItemKind::Function(_))
                | (CallableDeclarationOwner::Flow, HirItemKind::Flow(_))
                | (
                    CallableDeclarationOwner::ExternCapability,
                    HirItemKind::ExternCapability(_)
                )
                | (CallableDeclarationOwner::View, HirItemKind::View(_))
                | (
                    CallableDeclarationOwner::Predicate,
                    HirItemKind::Predicate(_)
                )
                | (CallableDeclarationOwner::Proof, HirItemKind::Proof(_))
                | (
                    CallableDeclarationOwner::TraitRequirement,
                    HirItemKind::Trait(_)
                )
                | (
                    CallableDeclarationOwner::TraitImplementation
                        | CallableDeclarationOwner::InherentMethod,
                    HirItemKind::Impl(_)
                )
        );
        if valid_item_family {
            return Err(RuntimeSemanticFactsError::InvalidCallableSourceOwner);
        }
        return Err(RuntimeSemanticFactsError::WrongItemFamily {
            item: callable.owner(),
            actual: item.kind().family(),
        });
    }

    let hir_attached = item
        .kind()
        .callable_attached_content_interface(callable.source_owner());
    let attached_matches = match (callable.attached_content_abi(), hir_attached) {
        (None, None) => true,
        (Some(runtime), Some(hir_interface)) => {
            use arcweft_lang_hir::item::HirAttachedContentPresence;
            use arcweft_lang_sema::callable::CallableParameterPresence;

            let hir = hir_interface.parameter();
            runtime.binding() == hir.binding()
                && u32::try_from(runtime.group().get()).ok() == Some(hir_interface.group())
                && runtime.abi_position() == hir_interface.abi_position()
                && match (runtime.presence(), hir.presence(), runtime.default()) {
                    (
                        CallableParameterPresence::Required,
                        HirAttachedContentPresence::Required,
                        None,
                    )
                    | (
                        CallableParameterPresence::Optional,
                        HirAttachedContentPresence::Optional,
                        None,
                    ) => true,
                    (
                        CallableParameterPresence::Defaulted,
                        HirAttachedContentPresence::Defaulted { value },
                        Some(default),
                    ) => default.source() == value,
                    _ => false,
                }
        }
        (None, Some(_)) | (Some(_), None) => false,
    };
    if !attached_matches {
        return Err(RuntimeSemanticFactsError::InvalidCallableAttachedContentAbi);
    }
    Ok(())
}

fn validate_project_function_instance(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    instance: &RuntimeProjectFunctionInstanceFact,
) -> Result<(), RuntimeSemanticFactsError> {
    validate_callable(modules, instance.callable())?;
    if instance.key().callable() != instance.callable().runtime() {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let module = module_for(modules, instance.callable().owner().module())?;
    let item = module
        .resolve_item(instance.callable().owner())
        .map_err(|_| RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
    let HirItemKind::Function(function) = item.kind() else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    function
        .parameter_groups()
        .get(instance.key().group().get())
        .ok_or(RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
    let expected_parameters = function
        .parameter_groups()
        .iter()
        .enumerate()
        .take(instance.key().group().get() + 1)
        .flat_map(|(group, parameters)| {
            parameters
                .parameters()
                .iter()
                .enumerate()
                .map(move |(parameter, row)| (group, parameter, row))
        })
        .collect::<Vec<_>>();
    if expected_parameters.len() != instance.parameters().len()
        || expected_parameters.iter().zip(instance.parameters()).any(
            |((group, position, hir), runtime)| {
                arcweft_lang_sema::callable::CallableGroupIndex::try_from_usize(*group).ok()
                    != Some(runtime.group())
                    || u32::try_from(*position).ok() != Some(runtime.parameter())
                    || hir.pattern() != runtime.pattern()
                    || hir.ty() != runtime.source_type()
                    || hir.kind() != runtime.kind()
                    || hir.locals() != runtime.bindings()
            },
        )
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let arcweft_lang_hir::item::HirFunctionBody::Block {
        scope,
        statements,
        tail,
    } = function.body()
    else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    if instance.body().scope() != *scope
        || instance.body().statements() != statements.as_ref()
        || instance.body().tail() != *tail
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    validate_normalized_type(modules, instance.function_type())?;
    for parameter in instance.parameters() {
        validate_normalized_type(modules, parameter.abi_ty())?;
        validate_normalized_type(modules, parameter.binding_ty())?;
    }
    for projection in instance.type_projection() {
        if let Some(ty) = projection.ty() {
            validate_normalized_type(modules, ty)?;
        }
    }
    if let Some(default) = instance.attached_default() {
        validate_normalized_type(modules, default.result())?;
        if default.source().module() != instance.callable().owner().module()
            || !runtime_owners
                .executable_owners(&HirRuntimeExecutableOwner::Item(
                    instance.callable().owner(),
                ))
                .is_some_and(|owners| owners.expressions().any(|owner| owner == default.source()))
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
        for capture in default.captures() {
            validate_normalized_type(modules, capture.binding_ty())?;
            if !capture
                .used_locals()
                .iter()
                .all(|local| capture.bindings().contains(local))
            {
                return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
            }
        }
    }

    let exact_owners = runtime_owners
        .executable_owners(&HirRuntimeExecutableOwner::Item(
            instance.callable().owner(),
        ))
        .ok_or(RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
    if !runtime_owners.admits_reachability(instance.semantics().partition().reachability())
        || instance.semantics().partition().executable()
            != &HirRuntimeExecutableOwner::Item(instance.callable().owner())
        || instance.semantics().expressions().iter().any(|fact| {
            !exact_owners
                .expressions()
                .any(|owner| owner == fact.owner())
        })
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    if !exact_owners
        .expressions()
        .any(|owner| owner == instance.body().tail())
        || instance
            .body()
            .statements()
            .iter()
            .any(|statement| !exact_owners.statements().any(|owner| owner == *statement))
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let expected_type_owners = exact_owners
        .expressions()
        .map(HirValueTypeOwner::Expression)
        .chain(exact_owners.patterns().map(HirValueTypeOwner::Pattern))
        .chain(exact_owners.locals().map(HirValueTypeOwner::Local))
        .chain(exact_owners.types().map(HirValueTypeOwner::Type))
        .chain(exact_owners.captures().map(HirValueTypeOwner::Capture))
        .collect::<BTreeSet<_>>();
    let actual_type_owners = instance
        .type_projection()
        .iter()
        .map(RuntimeExecutableTypeProjection::owner)
        .collect::<BTreeSet<_>>();
    if expected_type_owners != actual_type_owners {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let projected_types = instance
        .type_projection()
        .iter()
        .filter_map(|projection| projection.ty().map(|ty| (projection.owner(), ty)))
        .collect::<BTreeMap<_, _>>();
    let instance_expression_types = instance
        .type_projection()
        .iter()
        .filter_map(|projection| match (projection.owner(), projection.ty()) {
            (HirValueTypeOwner::Expression(owner), Some(ty)) => Some((owner, ty)),
            (HirValueTypeOwner::Expression(_), None)
            | (HirValueTypeOwner::Pattern(_), _)
            | (HirValueTypeOwner::Local(_), _)
            | (HirValueTypeOwner::Capture(_), _)
            | (HirValueTypeOwner::Type(_), _) => None,
        })
        .collect::<RuntimeExpressionTypeView<'_>>();
    for projection in instance.semantics().expressions() {
        let RuntimeProjectFunctionExpressionPayload::Call(call) = projection.payload() else {
            continue;
        };
        let expression = projection.owner();
        let kind = resolve_expr(modules, expression)?;
        let (hir_call, attached_body) = match kind {
            HirExprKind::Call(hir_call) => (hir_call, None),
            HirExprKind::AttachedContentApplication(application) => {
                let Some(invocation) = application.family().invocation() else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                (invocation, Some(application.body_presence()))
            }
            _ => return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance),
        };
        validate_call(
            modules,
            &instance_expression_types,
            expression,
            instance.semantics().expression_source_type(expression),
            hir_call,
            attached_body,
            call,
        )?;
        validate_project_function_call_materialization(modules, call)?;
        let executable = match call.dispatch() {
            RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::Declaration(
                callable,
            )) => Some(HirRuntimeExecutableOwner::Item(callable.owner())),
            RuntimeResolvedCallDispatch::Static(RuntimeResolvedStaticCallTarget::TraitMethod {
                method,
                ..
            }) => Some(HirRuntimeExecutableOwner::ImplMethod(method.clone())),
            RuntimeResolvedCallDispatch::Static(
                RuntimeResolvedStaticCallTarget::Intrinsic(_)
                | RuntimeResolvedStaticCallTarget::PresentationSlot(_)
                | RuntimeResolvedStaticCallTarget::PresentationFactory { .. }
                | RuntimeResolvedStaticCallTarget::PresentationView { .. }
                | RuntimeResolvedStaticCallTarget::PresentationHandleMethod { .. }
                | RuntimeResolvedStaticCallTarget::Format(_)
                | RuntimeResolvedStaticCallTarget::VecPopFront
                | RuntimeResolvedStaticCallTarget::VecPop
                | RuntimeResolvedStaticCallTarget::VecPush
                | RuntimeResolvedStaticCallTarget::Agent(_)
                | RuntimeResolvedStaticCallTarget::AgentProbeComparison(_)
                | RuntimeResolvedStaticCallTarget::AgentDiagnosticsHasError
                | RuntimeResolvedStaticCallTarget::Variant(_)
                | RuntimeResolvedStaticCallTarget::RecordConstructor { .. }
                | RuntimeResolvedStaticCallTarget::Reduction(_)
                | RuntimeResolvedStaticCallTarget::StandardMap(_)
                | RuntimeResolvedStaticCallTarget::StandardMapPrefix(_)
                | RuntimeResolvedStaticCallTarget::Traverse
                | RuntimeResolvedStaticCallTarget::ProgramNeed(_)
                | RuntimeResolvedStaticCallTarget::CharacterDialogue(_)
                | RuntimeResolvedStaticCallTarget::Line(_)
                | RuntimeResolvedStaticCallTarget::Registered(_)
                | RuntimeResolvedStaticCallTarget::Host(_),
            )
            | RuntimeResolvedCallDispatch::Value { .. } => None,
        };
        if let Some(owner) = executable
            && !runtime_owners.contains_runtime_owner(&owner)
        {
            return Err(RuntimeSemanticFactsError::OwnerOutsideReachability { owner });
        }
    }
    // The authored TypeId remains a checked source projection, while the
    // selected instance's pattern binding owns the closed parameter ABI.
    // An inferred callback row can make those two normalized types differ.
    let tail_has_type = projected_types
        .contains_key(&HirValueTypeOwner::Expression(instance.body().tail()))
        || instance
            .semantics()
            .evaluated_effect(instance.body().tail())
            .is_some();
    if !tail_has_type
        || instance.parameters().iter().any(|parameter| {
            let binding_matches_abi = match parameter.kind() {
                arcweft_lang_hir::item::HirParameterKind::Fixed
                | arcweft_lang_hir::item::HirParameterKind::ExtensionReceiver => {
                    parameter.binding_ty() == parameter.abi_ty()
                }
                arcweft_lang_hir::item::HirParameterKind::RestPositional => {
                    matches!(
                        parameter.binding_ty().shape(),
                        RuntimeTypeShape::Sequence {
                            kind: RuntimeSequenceKind::Vec,
                            item,
                        } if item.as_ref() == parameter.abi_ty()
                    )
                }
            };
            projected_types.get(&HirValueTypeOwner::Pattern(parameter.pattern()))
                != Some(&parameter.binding_ty())
                || !projected_types.contains_key(&HirValueTypeOwner::Type(parameter.source_type()))
                || !binding_matches_abi
        })
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    if let Some(default) = instance.attached_default()
        && (projected_types.get(&HirValueTypeOwner::Expression(default.source()))
            != Some(&default.result())
            || default.captures().iter().any(|capture| {
                projected_types.get(&HirValueTypeOwner::Pattern(capture.pattern()))
                    != Some(&capture.binding_ty())
                    || capture.used_locals().iter().any(|local| {
                        !projected_types.contains_key(&HirValueTypeOwner::Local(*local))
                    })
            }))
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let lexical_owner = RuntimeClosureLexicalOwner::ProjectFunction(instance.key().clone());
    validate_project_function_semantic_catalog(
        modules,
        runtime_owners,
        Some(&lexical_owner),
        RuntimeExecutableLexicalAuthority::Callable(instance.callable().runtime()),
        instance.semantics(),
        None,
    )?;
    Ok(())
}

fn validate_project_function_root(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    instances: &BTreeMap<RuntimeProjectFunctionInstanceKey, RuntimeProjectFunctionInstanceFact>,
    root: &RuntimeProjectFunctionRootFact,
) -> Result<(), RuntimeSemanticFactsError> {
    if !runtime_owners.contains_runtime_owner(&HirRuntimeExecutableOwner::Item(root.entry())) {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionRoot);
    }
    let module = module_for(modules, root.entry().module())?;
    let item = module
        .resolve_item(root.entry())
        .map_err(|_| RuntimeSemanticFactsError::InvalidProjectFunctionRoot)?;
    let HirItemKind::Entry(entry) = item.kind() else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionRoot);
    };
    if entry.has_structural_recovery()
        || instances.get(root.instance()).is_none_or(|instance| {
            instance.key() != root.instance()
                || instance.callable().runtime() != root.instance().callable()
        })
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionRoot);
    }
    let matching_members = entry
        .members()
        .iter()
        .filter(|member| match (root.role(), member) {
            (
                RuntimeProjectFunctionRootRole::EntryInitializer,
                HirEntryMember::Initializer(binding),
            )
            | (RuntimeProjectFunctionRootRole::EntryReducer, HirEntryMember::Reducer(binding))
            | (
                RuntimeProjectFunctionRootRole::EntryController,
                HirEntryMember::Controller(binding),
            ) => !binding.has_recovery(),
            _ => false,
        })
        .count();
    if matching_members != 1 {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionRoot);
    }
    Ok(())
}

#[derive(Clone, Copy)]
enum RuntimeExecutableLexicalAuthority<'facts> {
    Callable(&'facts RuntimeCallableId),
    Program(&'facts RuntimePureProgramFact),
}

impl RuntimeExecutableLexicalAuthority<'_> {
    fn admits_closure_owner(self, closure: &RuntimeClosureInstanceFact) -> bool {
        let owner = closure.key().closure().owner();
        match self {
            Self::Callable(expected) => {
                RuntimeCallableId::from_checked_digest(owner.semantic_digest().into_bytes())
                    == *expected
            }
            Self::Program(program) => {
                let abi = program.admission().input_abi();
                abi.environment()
                    .validate_callable_owner(owner, abi.hir_topology())
                    .is_ok()
            }
        }
    }
}

fn validate_project_function_semantic_catalog(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    parent_key: Option<&RuntimeClosureLexicalOwner>,
    callable: RuntimeExecutableLexicalAuthority<'_>,
    semantics: &RuntimeProjectFunctionInstanceSemanticFacts,
    outer: Option<RuntimeExecutableSemanticFactView<'_>>,
) -> Result<(), RuntimeSemanticFactsError> {
    let partition = semantics.partition();
    if !runtime_owners.admits_reachability(partition.reachability()) {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let exact = runtime_owners.executable_owners(partition.executable());
    if exact.is_none()
        && (!matches!(parent_key, Some(RuntimeClosureLexicalOwner::TraitMethod(_)))
            || !matches!(
                partition.executable(),
                HirRuntimeExecutableOwner::ImplMethod(_)
                    | HirRuntimeExecutableOwner::CallableBody(_)
            ))
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    if exact.is_some_and(|exact| {
        partition
            .expressions()
            .iter()
            .map(|row| row.owner())
            .ne(exact.expressions())
            || partition
                .patterns()
                .iter()
                .map(|row| row.owner())
                .ne(exact.patterns())
            || partition
                .statements()
                .iter()
                .map(|row| row.owner())
                .ne(exact.statements())
            || partition.locals().iter().copied().ne(exact.locals())
            || partition
                .types()
                .iter()
                .map(|row| row.owner())
                .ne(exact.types())
            || partition.captures().iter().copied().ne(exact.captures())
            || partition
                .expressions()
                .iter()
                .any(|row| row.children() != exact.expression_children(row.owner()))
    }) {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }

    let expression_types = semantics
        .type_projection()
        .iter()
        .filter_map(|projection| match (projection.owner(), projection.ty()) {
            (HirValueTypeOwner::Expression(owner), Some(ty)) => Some((owner, ty)),
            _ => None,
        })
        .collect::<RuntimeExpressionTypeView<'_>>();
    let pattern_types = semantics
        .type_projection()
        .iter()
        .filter_map(|projection| match (projection.owner(), projection.ty()) {
            (HirValueTypeOwner::Pattern(owner), Some(ty)) => Some((owner, ty.clone())),
            _ => None,
        })
        .collect::<BTreeMap<_, _>>();
    let local_types = semantics
        .type_projection()
        .iter()
        .filter_map(|projection| match (projection.owner(), projection.ty()) {
            (HirValueTypeOwner::Local(owner), Some(ty)) => Some((owner, ty.clone())),
            _ => None,
        })
        .collect::<BTreeMap<_, _>>();
    let calls = semantics
        .expressions()
        .iter()
        .filter_map(|row| match row.payload() {
            RuntimeProjectFunctionExpressionPayload::Call(call) => {
                Some((row.owner(), call.clone()))
            }
            _ => None,
        })
        .collect::<BTreeMap<_, _>>();
    let values = semantics
        .expressions()
        .iter()
        .filter_map(|row| match row.payload() {
            RuntimeProjectFunctionExpressionPayload::Value(value) => {
                Some((row.owner(), value.clone()))
            }
            _ => None,
        })
        .collect::<BTreeMap<_, _>>();
    for projection in semantics.type_projection() {
        if let Some(ty) = projection.ty() {
            validate_normalized_type(modules, ty)?;
        }
    }
    for capture in semantics.captures() {
        if exact.is_some_and(|exact| !exact.capture_plan().contains(capture.projection())) {
            return Err(RuntimeSemanticFactsError::InvalidCaptureProjection {
                capture: capture.capture(),
            });
        }
        validate_normalized_type(modules, capture.ty())?;
    }

    for row in semantics.expressions() {
        let owner = row.owner();
        let hir = resolve_expr(modules, owner)?;
        match row.payload() {
            RuntimeProjectFunctionExpressionPayload::Thread => {
                if !matches!(hir, HirExprKind::Thread(authored)
                    if row.producer().and_then(|producer| producer.thread())
                        .is_some_and(|checked| checked.matches_source(authored)))
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::Structural
            | RuntimeProjectFunctionExpressionPayload::Consumed => {}
            RuntimeProjectFunctionExpressionPayload::Scope(identity) => {
                let scope_owner = RuntimeScopeOwner::Expression(owner);
                if !identity
                    .origin()
                    .validate_authority(semantics.local_uses(), scope_owner)
                {
                    return Err(RuntimeSemanticFactsError::InvalidScopeOrigin {
                        owner: scope_owner,
                    });
                }
                lexical_scope::validate_expression_scope(hir, owner, identity.identity())?;
                lexical_scope::validate_continuation(
                    modules,
                    RuntimeScopeOwner::Expression(owner),
                    identity,
                    semantics.expression_type(owner),
                    semantics
                        .expressions()
                        .iter()
                        .filter_map(|row| match row.payload() {
                            RuntimeProjectFunctionExpressionPayload::Try(tried) => {
                                Some((row.owner(), tried))
                            }
                            _ => None,
                        }),
                )?;
            }
            RuntimeProjectFunctionExpressionPayload::Literal(_) => {
                if !matches!(
                    hir,
                    HirExprKind::Literal(_) | HirExprKind::NumericBracketSequence(_)
                ) || !expression_types.contains_key(&owner)
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::ResidualValue(value) => {
                if !matches!(hir, HirExprKind::Call(_))
                    || !matches!(value.value(), RuntimeValue::Color(_))
                    || !expression_types
                        .get(&owner)
                        .is_some_and(|ty| matches!(ty.shape(), RuntimeTypeShape::Color))
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::Value(value) => {
                if !matches!(
                    hir,
                    HirExprKind::Path(_)
                        | HirExprKind::EntityReference(_)
                        | HirExprKind::ShortVariant(_)
                ) && !matches!(
                    (hir, value),
                    (HirExprKind::Select(_), value) if value.has_static_qualifier()
                ) && !matches!(
                    (hir, value),
                    (
                        HirExprKind::LifetimePath(_),
                        RuntimeResolvedValue::RegistryRead(_)
                    )
                ) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                let selected_local = match value {
                    RuntimeResolvedValue::Local(local) if exact.is_none() => Some(*local),
                    RuntimeResolvedValue::Place(place) if exact.is_none() => {
                        let sites = [
                            arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Expression(
                                row.owner(),
                            ),
                            arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Place(
                                row.owner(),
                            ),
                        ];
                        let rows = sites
                            .into_iter()
                            .filter_map(|site| semantics.local_uses().access_at(site))
                            .collect::<Vec<_>>();
                        if rows.is_empty()
                            || rows.iter().any(|access| !place.matches_access(access))
                            || local_types
                                .get(&place.local())
                                .zip(expression_types.get(&row.owner()))
                                .is_none_or(|(root, value)| !place.accepts_types(root, value))
                        {
                            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                        }
                        Some(place.local())
                    }
                    _ => None,
                };
                if let Some(local) = selected_local {
                    module_for(modules, local.module())?
                        .resolve_local(local)
                        .map_err(|_| RuntimeSemanticFactsError::UnresolvedLocal { local })?;
                    if semantics.local_type(local).is_none() {
                        return Err(RuntimeSemanticFactsError::InactiveLocalReference { local });
                    }
                } else {
                    validate_resolved_value(
                        modules,
                        runtime_owners,
                        RuntimeValueOriginContext::Closed(semantics.local_uses()),
                        owner,
                        expression_types.get(&owner),
                        value,
                    )?;
                }
            }
            RuntimeProjectFunctionExpressionPayload::Select(select) => {
                if !matches!(hir, HirExprKind::Select(_)) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_select(modules, owner, select)?;
            }
            RuntimeProjectFunctionExpressionPayload::NominalRecord(record) => {
                if !matches!(hir, HirExprKind::Record(_) | HirExprKind::RecordLiteral(_)) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_record_expression_fact(modules, owner, record)?;
            }
            RuntimeProjectFunctionExpressionPayload::Variant(variant) => {
                if !RuntimeResolvedVariant::accepts_expression_kind(hir) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_variant(modules, variant)?;
            }
            RuntimeProjectFunctionExpressionPayload::Call(call) => {
                let (hir_call, attached_body) = match hir {
                    HirExprKind::Call(hir_call) => (hir_call, None),
                    HirExprKind::AttachedContentApplication(application) => {
                        let Some(invocation) = application.family().invocation() else {
                            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                        };
                        (invocation, Some(application.body_presence()))
                    }
                    _ => return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance),
                };
                validate_call(
                    modules,
                    &expression_types,
                    owner,
                    semantics.expression_source_type(owner),
                    hir_call,
                    attached_body,
                    call,
                )?;
                validate_project_function_call_materialization(modules, call)?;
            }
            RuntimeProjectFunctionExpressionPayload::EvaluatedEffect { operation, pipe } => {
                let valid_site = match (hir, pipe) {
                    (HirExprKind::Call(_), None) => true,
                    (HirExprKind::Pipe(_), None) => operation.effect().uses_pipe_address(),
                    (HirExprKind::Pipe(hir), Some(pipe)) => {
                        !operation.effect().uses_pipe_address()
                            && hir.left() == pipe.left()
                            && hir.right() == pipe.right()
                            && !pipe.placeholders().is_empty()
                    }
                    _ => false,
                };
                if !valid_site
                    || expression_types
                        .get(&owner)
                        .is_some_and(|ty| ty != operation.result())
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                evaluated_effect::validate_evaluated_effect(
                    modules,
                    &expression_types,
                    &calls,
                    owner,
                    operation,
                )?;
            }
            RuntimeProjectFunctionExpressionPayload::PostfixCandidate(candidate) => {
                let HirExprKind::PostfixBracket(postfix) = hir else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                let arcweft_lang_hir::dialogue_application::HirPostfixBracketCandidates::Ambiguous {
                    index,
                    dialogue,
                } = postfix.candidates()
                else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                if candidate != index && candidate != dialogue {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::Await(fact) => {
                let HirExprKind::Await(awaited) = hir else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                if awaited.operand() != fact.operand()
                    || fact.observers().len() != awaited.branches().len()
                    || !matches!(
                        expression_types
                            .get(&fact.operand())
                            .map(RuntimeNormalizedType::shape),
                        Some(RuntimeTypeShape::Need(_))
                    )
                    || awaited
                        .branches()
                        .iter()
                        .zip(fact.observers())
                        .any(|(authored, checked)| {
                            authored.pattern() != Some(checked.pattern())
                                || !matches!(
                                    pattern_types
                                        .get(&checked.pattern())
                                        .map(RuntimeNormalizedType::shape),
                                    Some(RuntimeTypeShape::Progress)
                                )
                        })
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::Choice(fact) => {
                let HirExprKind::Choice(choice) = hir else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                if fact.option_ids().len() != choice.body().items().len() {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                for goto in fact.gotos() {
                    validate_project_item(modules, goto.target())?;
                }
            }
            RuntimeProjectFunctionExpressionPayload::Try(fact) => {
                let HirExprKind::Try(tried) = hir else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                if tried.operand() != fact.operand()
                    || expression_types.get(&fact.operand()) != Some(fact.carrier_type())
                    || !try_boundary_type_matches(fact)
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::ImplicitCallable {
                callable: fact,
                tried,
                pipe,
            } => {
                let Some(RuntimeTypeShape::Function {
                    parameters, result, ..
                }) = expression_types
                    .get(&owner)
                    .map(RuntimeNormalizedType::shape)
                else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                if parameters.len() != 1
                    || parameters.first() != Some(fact.parameter())
                    || result.as_ref() != fact.result()
                    || fact.placeholders().is_empty()
                    || fact
                        .captures()
                        .iter()
                        .any(|capture| !local_types.contains_key(&capture.local()))
                    || tried
                        .as_ref()
                        .is_some_and(|tried| !try_boundary_type_matches(tried))
                    || pipe.as_ref().is_some_and(|pipe| {
                        pipe.placeholders().is_empty()
                            || !row.children().contains(&pipe.left())
                            || !row.children().contains(&pipe.right())
                    })
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::Pipe(pipe) => {
                let HirExprKind::Pipe(hir) = hir else {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                };
                if hir.left() != pipe.left()
                    || hir.right() != pipe.right()
                    || pipe.placeholders().is_empty()
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionExpressionPayload::DialogueApplication {
                application,
                fragments,
            } => {
                let root = fragments.iter().find(|fragment| fragment.source() == owner);
                if !matches!(hir, HirExprKind::AttachedContentApplication(_))
                    || root.is_none_or(|fragment| {
                        fragment.template().id() != application.content().template_id()
                            || fragment.template().digest()
                                != application.content().template_digest()
                    })
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                application.validate_target(
                    modules,
                    owner,
                    semantics.expression_type(application.target().expression()),
                )?;
                validate_normalized_type(modules, application.line_result())?;
                validate_project_instance_fragments(modules, semantics, fragments)?;
            }
            RuntimeProjectFunctionExpressionPayload::ContentApplication { fragments } => {
                if !matches!(hir, HirExprKind::AttachedContentApplication(_))
                    || fragments.iter().any(|fragment| fragment.source() != owner)
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_project_instance_fragments(modules, semantics, fragments)?;
            }
            RuntimeProjectFunctionExpressionPayload::Closure(closure) => {
                validate_closure_instance(
                    modules,
                    runtime_owners,
                    parent_key,
                    callable,
                    RuntimeExecutableSemanticFactView::ProjectInstance(semantics),
                    owner,
                    closure,
                )?;
            }
        }
    }

    for row in semantics.patterns() {
        let hir = resolve_pattern(modules, row.owner())?;
        match row.payload() {
            RuntimeProjectFunctionPatternPayload::Structural => {}
            RuntimeProjectFunctionPatternPayload::Literal(_) => {
                if !matches!(hir, HirPatternKind::Literal(_)) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionPatternPayload::Entity(item) => {
                if !matches!(hir, HirPatternKind::EntityReference(_)) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                if !item.validate_authority(semantics.local_uses(), row.owner()) {
                    return Err(RuntimeSemanticFactsError::InvalidEntityPatternOrigin {
                        pattern: row.owner(),
                    });
                }
                validate_entity_pattern_type(row.owner(), pattern_types.get(&row.owner()), item)?;
            }
            RuntimeProjectFunctionPatternPayload::NominalRecord(record) => {
                if !matches!(hir, HirPatternKind::Record { .. }) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_record_pattern_fact(modules, row.owner(), record)?;
            }
            RuntimeProjectFunctionPatternPayload::Variant(variant) => {
                if !matches!(hir, HirPatternKind::Variant(_)) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_variant(modules, variant)?;
            }
            RuntimeProjectFunctionPatternPayload::TypedBinding => {
                if !matches!(hir, HirPatternKind::TypedBinding { .. }) {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
        }
    }

    let mark_facts = semantics
        .expressions()
        .iter()
        .flat_map(|row| match row.payload() {
            RuntimeProjectFunctionExpressionPayload::DialogueApplication { fragments, .. }
            | RuntimeProjectFunctionExpressionPayload::ContentApplication { fragments } => {
                fragments.as_ref()
            }
            _ => &[],
        })
        .flat_map(RuntimeContentFragmentFact::marks)
        .map(|mark| (mark.coordinate().clone(), mark.key()))
        .collect::<BTreeMap<_, _>>();
    for row in semantics.statements() {
        match row.payload() {
            RuntimeProjectFunctionStatementPayload::Scope(identity) => {
                let scope_owner = RuntimeScopeOwner::Statement(row.owner());
                if !identity
                    .origin()
                    .validate_authority(semantics.local_uses(), scope_owner)
                {
                    return Err(RuntimeSemanticFactsError::InvalidScopeOrigin {
                        owner: scope_owner,
                    });
                }
                lexical_scope::validate_statement_scope(
                    resolve_stmt(modules, row.owner())?,
                    row.owner(),
                    identity.identity(),
                )?;
                lexical_scope::validate_continuation(
                    modules,
                    RuntimeScopeOwner::Statement(row.owner()),
                    identity,
                    None,
                    semantics
                        .expressions()
                        .iter()
                        .filter_map(|row| match row.payload() {
                            RuntimeProjectFunctionExpressionPayload::Try(tried) => {
                                Some((row.owner(), tried))
                            }
                            _ => None,
                        }),
                )?;
            }
            RuntimeProjectFunctionStatementPayload::Assignment(fact) => {
                validate_assignment(
                    modules,
                    |local| local_types.get(local),
                    &expression_types,
                    &values,
                    semantics.local_uses().place_access_at(
                        match resolve_stmt(modules, row.owner())? {
                            HirStmtKind::Assign { target, .. } => *target,
                            _ => {
                                return Err(RuntimeSemanticFactsError::InvalidAssignmentFact {
                                    statement: row.owner(),
                                });
                            }
                        },
                    ),
                    row.owner(),
                    fact,
                )?;
            }
            RuntimeProjectFunctionStatementPayload::RegistryWrite(fact) => {
                fact.validate(modules, &expression_types, row.owner())?;
            }
            RuntimeProjectFunctionStatementPayload::EvaluatedEffect(site) => {
                if !matches!(
                    resolve_stmt(modules, row.owner())?,
                    HirStmtKind::Expression { expression } if expression == site
                ) || semantics.evaluated_effect(*site).is_none()
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
            }
            RuntimeProjectFunctionStatementPayload::Defer(fact) => {
                defer::validate_defer_payload(
                    modules,
                    |local| local_types.get(local),
                    &expression_types,
                    Some(semantics.local_uses()),
                    row.owner(),
                    fact,
                )?;
            }
            RuntimeProjectFunctionStatementPayload::Iteration(fact) => match fact {
                RuntimeIteratorFact::Builtin(fact) => {
                    for ty in [fact.item(), fact.iterator(), fact.next_value(), fact.step()] {
                        validate_normalized_type(modules, ty)?;
                    }
                }
                RuntimeIteratorFact::Witness(fact) => {
                    validate_normalized_type(modules, fact.item())?;
                    validate_normalized_type(modules, fact.iterator())?;
                }
            },
            RuntimeProjectFunctionStatementPayload::Trigger(admission) => {
                let hir = resolve_stmt(modules, row.owner())?;
                if let HirStmtKind::CancelRule {
                    trigger: HirCancelTrigger::InputAction(action),
                    ..
                } = hir
                {
                    if admission.input_action_id().map(|id| id.as_str()) != Some(action.as_str()) {
                        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                    }
                }
                match (hir, admission.dialogue_mark()) {
                    (
                        HirStmtKind::On {
                            trigger: HirTrigger::Mark(source),
                            ..
                        },
                        Some(mark),
                    ) if source.ordinal() == mark.coordinate().ordinal()
                        && mark_facts.get(mark.coordinate()) == Some(&mark.key()) => {}
                    (
                        HirStmtKind::On {
                            trigger: HirTrigger::Mark(_),
                            ..
                        },
                        _,
                    )
                    | (_, Some(_)) => {
                        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                    }
                    (_, None) => {}
                }
            }
            RuntimeProjectFunctionStatementPayload::Include(target) => {
                flow_include::validate_instance(
                    modules,
                    semantics.local_uses(),
                    row.owner(),
                    target,
                )?;
            }
            RuntimeProjectFunctionStatementPayload::Suspension(suspension) => {
                suspension::validate(&modules, &expression_types, row.owner(), suspension)?;
            }
            RuntimeProjectFunctionStatementPayload::Structural
            | RuntimeProjectFunctionStatementPayload::Assertion(_)
            | RuntimeProjectFunctionStatementPayload::ControlTransfer
            | RuntimeProjectFunctionStatementPayload::UnsafeAudit
            | RuntimeProjectFunctionStatementPayload::Select
            | RuntimeProjectFunctionStatementPayload::SourceLocale
            | RuntimeProjectFunctionStatementPayload::Yield => {}
        }
    }
    if outer.is_some_and(|outer| {
        semantics
            .captures()
            .any(|capture| outer.capture(capture.capture()).is_some())
    }) {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    Ok(())
}

fn validate_project_instance_fragments(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    semantics: &RuntimeProjectFunctionInstanceSemanticFacts,
    fragments: &[RuntimeContentFragmentFact],
) -> Result<(), RuntimeSemanticFactsError> {
    let mut sources = BTreeSet::new();
    let mut ids = BTreeSet::new();
    let expression_types = semantics
        .expressions()
        .iter()
        .filter_map(|row| {
            semantics
                .expression_type(row.owner())
                .map(|ty| (row.owner(), ty))
        })
        .collect::<RuntimeExpressionTypeView<'_>>();
    let calls = semantics
        .expressions()
        .iter()
        .filter_map(|row| {
            semantics
                .call(row.owner())
                .cloned()
                .map(|call| (row.owner(), call))
        })
        .collect::<BTreeMap<_, _>>();
    for fragment in fragments {
        if !sources.insert(fragment.source())
            || !ids.insert(fragment.id())
            || semantics.expression(fragment.source()).is_none()
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
        for value in fragment.values() {
            if semantics.expression_type(value.expression()) != Some(value.source_type()) {
                return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
            }
            validate_normalized_type(modules, value.ty())?;
            validate_normalized_type(modules, value.source_type())?;
        }
        for effect in fragment.effects() {
            let trigger_valid = match effect.trigger() {
                RuntimeDialogueEffectTrigger::Content => true,
                RuntimeDialogueEffectTrigger::Delay {
                    duration_type,
                    schedule_handle_type,
                    ..
                } => {
                    matches!(duration_type.shape(), RuntimeTypeShape::Duration)
                        && validate_normalized_type(modules, duration_type).is_ok()
                        && validate_normalized_type(modules, schedule_handle_type).is_ok()
                }
            };
            let application_is_call = semantics.call(effect.operation().application()).is_some();
            let application_is_evaluated_effect = semantics
                .expression(effect.operation().application())
                .is_some_and(|expression| {
                    matches!(
                        expression.payload(),
                        RuntimeProjectFunctionExpressionPayload::EvaluatedEffect { .. }
                    )
                });
            if !trigger_valid
                || semantics.expression(effect.operation().root()).is_none()
                || !(effect.operation().root() == effect.operation().application()
                    || project_instance_expression_reaches(
                        semantics,
                        effect.operation().root(),
                        effect.operation().application(),
                    ))
                || !validate_dialogue_effect_operation(
                    modules,
                    &expression_types,
                    &calls,
                    effect.operation(),
                )
                || effect.operation().evaluated_effect_operation().is_none()
                    && (!application_is_call || application_is_evaluated_effect)
            {
                return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
            }
            for capture in effect.captures() {
                if semantics.local_type(capture.local()) != Some(capture.ty())
                    || !capture.matches_authority(
                        arcweft_lang_sema::final_analysis::CheckedLocalUseSite::Capture {
                            owner: effect.operation().root(),
                            local: capture.local(),
                        },
                        semantics.local_uses(),
                    )
                {
                    return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
                }
                validate_normalized_type(modules, capture.ty())?;
            }
        }
    }
    Ok(())
}

fn validate_dialogue_effect_operation(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    expression_types: &RuntimeExpressionTypeView<'_>,
    calls: &BTreeMap<ExprId, RuntimeResolvedCall>,
    operation: &RuntimeDialogueEffectOperationFact,
) -> bool {
    match operation {
        RuntimeDialogueEffectOperationFact::EvaluatedEffect(effect) => {
            matches!(effect.result().shape(), RuntimeTypeShape::Unit)
                && evaluated_effect::validate_evaluated_effect_site(modules, effect)
                && evaluated_effect::validate_evaluated_effect_operation(
                    modules,
                    expression_types,
                    calls,
                    effect,
                )
        }
        RuntimeDialogueEffectOperationFact::OrdinaryCall {
            root,
            application,
            result,
        } => {
            matches!(result.shape(), RuntimeTypeShape::Unit)
                && validate_normalized_type(modules, result).is_ok()
                && expression_types.get(root) == Some(result)
                && expression_types.get(application) == Some(result)
                && calls
                    .get(application)
                    .is_some_and(|call| call.result() == RuntimeCallResultShape::Value)
        }
    }
}

fn project_instance_expression_reaches(
    semantics: &RuntimeProjectFunctionInstanceSemanticFacts,
    owner: ExprId,
    target: ExprId,
) -> bool {
    let mut pending = semantics
        .expression_children(owner)
        .unwrap_or_default()
        .to_vec();
    let mut visited = BTreeSet::new();
    while let Some(expression) = pending.pop() {
        if expression == target {
            return true;
        }
        if visited.insert(expression) {
            pending.extend(
                semantics
                    .expression_children(expression)
                    .unwrap_or_default()
                    .iter()
                    .copied(),
            );
        }
    }
    false
}

fn validate_project_instance_dialogue_applications(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    catalog: &CharacterPresentationCatalogData,
    lines: &AcceptedDialogueLineInventory,
    generation: Option<
        &arcweft_dialogue::CharacterDialogueGenerationDeclaration<RuntimeNormalizedType>,
    >,
    semantics: &RuntimeProjectFunctionInstanceSemanticFacts,
) -> Result<(), RuntimeSemanticFactsError> {
    for row in semantics.expressions() {
        match row.payload() {
            RuntimeProjectFunctionExpressionPayload::DialogueApplication {
                application,
                fragments,
            } => {
                let owner = row.owner();
                let fragment = fragments
                    .iter()
                    .find(|fragment| fragment.source() == owner)
                    .ok_or(RuntimeSemanticFactsError::DialogueTemplateMismatch {
                        expression: owner,
                    })?;
                let accepted = lines
                    .for_semantic_expr(owner)
                    .ok_or(RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner })?;
                let runtime_line = RuntimeLineId::from_source_entity_body(accepted.id().as_str())
                    .map_err(|_| {
                    RuntimeSemanticFactsError::DialogueLineMismatch { expression: owner }
                })?;
                if fragment.template().id() != application.content().template_id()
                    || fragment.template().digest() != application.content().template_digest()
                    || &runtime_line != application.content().line()
                    || accepted.text_key().as_str() != application.content().text_key().as_str()
                    || application.content().character().semantic_digest()
                        != catalog.semantic_digest()
                {
                    return Err(RuntimeSemanticFactsError::DialogueTemplateMismatch {
                        expression: owner,
                    });
                }
                character_dialogue_generation::validate_application(
                    owner,
                    application,
                    catalog,
                    generation,
                )?;
                validate_normalized_type(modules, application.line_result())?;
            }
            RuntimeProjectFunctionExpressionPayload::Closure(closure) => {
                validate_project_instance_dialogue_applications(
                    modules,
                    catalog,
                    lines,
                    generation,
                    closure.semantics(),
                )?;
            }
            RuntimeProjectFunctionExpressionPayload::Structural
            | RuntimeProjectFunctionExpressionPayload::Consumed
            | RuntimeProjectFunctionExpressionPayload::Literal(_)
            | RuntimeProjectFunctionExpressionPayload::ResidualValue(_)
            | RuntimeProjectFunctionExpressionPayload::Scope(_)
            | RuntimeProjectFunctionExpressionPayload::Value(_)
            | RuntimeProjectFunctionExpressionPayload::Select(_)
            | RuntimeProjectFunctionExpressionPayload::NominalRecord(_)
            | RuntimeProjectFunctionExpressionPayload::Variant(_)
            | RuntimeProjectFunctionExpressionPayload::Call(_)
            | RuntimeProjectFunctionExpressionPayload::EvaluatedEffect { .. }
            | RuntimeProjectFunctionExpressionPayload::PostfixCandidate(_)
            | RuntimeProjectFunctionExpressionPayload::Await(_)
            | RuntimeProjectFunctionExpressionPayload::Thread
            | RuntimeProjectFunctionExpressionPayload::Choice(_)
            | RuntimeProjectFunctionExpressionPayload::Try(_)
            | RuntimeProjectFunctionExpressionPayload::ImplicitCallable { .. }
            | RuntimeProjectFunctionExpressionPayload::Pipe(_)
            | RuntimeProjectFunctionExpressionPayload::ContentApplication { .. } => {}
        }
    }
    Ok(())
}

fn validate_closure_instance(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    parent_key: Option<&RuntimeClosureLexicalOwner>,
    callable: RuntimeExecutableLexicalAuthority<'_>,
    outer: RuntimeExecutableSemanticFactView<'_>,
    owner: ExprId,
    closure: &RuntimeClosureInstanceFact,
) -> Result<(), RuntimeSemanticFactsError> {
    let arcweft_lang_sema::callable::CheckedCallableContext::Project {
        world, revision, ..
    } = closure.key().closure().owner().context()
    else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    if world != runtime_owners.runtime.identity().symbol_world()
        || *revision != runtime_owners.runtime.identity().symbol_revision()
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let same_local_use_authority = match outer {
        RuntimeExecutableSemanticFactView::Global(facts) => {
            matches!(
                closure.semantics().local_uses(),
                CheckedLocalUseAuthority::Global(catalog)
                    if facts.checked_local_uses.as_ref() == Some(catalog)
            )
        }
        RuntimeExecutableSemanticFactView::ProjectInstance(facts) => {
            facts.local_uses() == closure.semantics().local_uses()
        }
    };
    if !same_local_use_authority {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let HirExprKind::Closure(hir) = resolve_expr(modules, owner)? else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    let module = module_for(modules, owner.module())?;
    let expected_captures = if let Some(owners) =
        runtime_owners.executable_owners(&HirRuntimeExecutableOwner::CallableBody(owner))
    {
        owners
            .capture_plan()
            .iter()
            .map(|capture| (capture.capture(), capture.local()))
            .collect::<Vec<_>>()
    } else if matches!(parent_key, Some(RuntimeClosureLexicalOwner::TraitMethod(_))) {
        hir.captures()
            .iter()
            .map(|capture| {
                module
                    .resolve_capture(*capture)
                    .map(|resolved| (*capture, resolved.local()))
                    .map_err(|_| RuntimeSemanticFactsError::InvalidProjectFunctionInstance)
            })
            .collect::<Result<Vec<_>, _>>()?
    } else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    let expected_captures = expected_captures
        .into_iter()
        .filter(|(capture, _)| {
            closure
                .semantics()
                .partition()
                .semantic_value_type(HirValueTypeOwner::Capture(*capture))
                .is_none()
        })
        .collect::<Vec<_>>();
    let source = module
        .source_site(
            module.provenance().source_identity(),
            HirSourceQuery::Expr {
                owner,
                role: HirExprSourceRole::Whole,
            },
        )
        .ok()
        .and_then(|lookup| match lookup.presence() {
            HirSourcePresence::Present(HirSourceSite::Span(span)) => Some(span),
            HirSourcePresence::Present(HirSourceSite::Insertion(_))
            | HirSourcePresence::AbsentOptional => None,
        })
        .ok_or(RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
    if closure.owner() != owner
        || closure.key().enclosing_owner() != parent_key
        || closure.key().closure().expression() != source
        || !callable.admits_closure_owner(closure)
        || closure.scope() != hir.scope()
        || closure.body() != hir.body()
        || closure.parameters().len() != hir.parameters().len()
        || closure.captures().len() != expected_captures.len()
        || outer.expression_type(owner) != Some(closure.function_type())
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    for (position, (runtime, hir)) in closure
        .parameters()
        .iter()
        .zip(hir.parameters())
        .enumerate()
    {
        if u32::try_from(position).ok() != Some(runtime.position())
            || runtime.pattern() != hir.pattern()
            || closure.semantics().pattern_type(hir.pattern()) != Some(runtime.ty())
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
    }
    for (position, (runtime, (capture, captured_local))) in
        closure.captures().iter().zip(expected_captures).enumerate()
    {
        let checked = module
            .resolve_capture(capture)
            .map_err(|_| RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
        if u32::try_from(position).ok() != Some(runtime.position())
            || runtime.capture() != capture
            || runtime.source() != checked.local()
            || runtime.source() != captured_local
            || outer.local_type(runtime.source()) != Some(runtime.ty())
            || closure
                .semantics()
                .capture(runtime.capture())
                .is_none_or(|capture| capture.ty() != runtime.ty())
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
    }
    validate_project_function_semantic_catalog(
        modules,
        runtime_owners,
        parent_key,
        callable,
        closure.semantics(),
        Some(outer),
    )
}

fn validate_project_function_call_materialization(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    call: &RuntimeResolvedCall,
) -> Result<(), RuntimeSemanticFactsError> {
    let Some(plan) = call.project_function() else {
        return Ok(());
    };
    let module = module_for(modules, plan.callable().owner().module())?;
    let item = module
        .resolve_item(plan.callable().owner())
        .map_err(|_| RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
    let HirItemKind::Function(function) = item.kind() else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    let group = function
        .parameter_groups()
        .get(call.completed_group().get())
        .ok_or(RuntimeSemanticFactsError::InvalidProjectFunctionInstance)?;
    if group.parameters().len() != plan.current_group_materialization().len() {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    for (parameter_index, (hir, runtime)) in group
        .parameters()
        .iter()
        .zip(plan.current_group_materialization())
        .enumerate()
    {
        if runtime.group() != call.completed_group()
            || u32::try_from(parameter_index).ok() != Some(runtime.parameter())
            || runtime.kind() != hir.kind()
            || hir.default().is_some()
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
        if runtime
            .operand_indices()
            .windows(2)
            .any(|pair| pair[0] >= pair[1])
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
        validate_normalized_type(modules, runtime.abi_ty())?;
        validate_normalized_type(modules, runtime.binding_ty())?;
    }
    Ok(())
}

fn validate_project_function_instance_reference(
    expression: ExprId,
    call: &RuntimeResolvedCall,
    expression_type: Option<&RuntimeNormalizedType>,
    instances: &BTreeMap<RuntimeProjectFunctionInstanceKey, RuntimeProjectFunctionInstanceFact>,
    sources: &BTreeMap<RuntimeProjectCallableSourceKey, RuntimeProjectCallableSourceFact>,
    specializations: &BTreeMap<RuntimeCallableSpecializationKey, RuntimeCallableSpecializationFact>,
) -> Result<Option<RuntimeProjectFunctionInstanceKey>, RuntimeSemanticFactsError> {
    let Some(plan) = call.project_function() else {
        return Ok(None);
    };
    if let Some(spec) = plan.input_specialization()
        && specializations.get(spec.key()).is_none_or(|definition| {
            definition.source() != spec.source() || definition.target() != plan.application_type()
        })
    {
        return Err(RuntimeCallableSpecializationFactError::Inventory.into());
    }
    let Some(instance) = plan.outcome().callable_instance() else {
        let RuntimeProjectFunctionCallOutcome::Continue {
            abi,
            target: RuntimeProjectCallableValueTarget::Source(key),
            ..
        } = plan.outcome()
        else {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        };
        let source = sources
            .get(key)
            .ok_or(RuntimeCallableSpecializationFactError::Inventory)?;
        let RuntimeTypeShape::Function { result, .. } = plan.application_type().shape() else {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        };
        if source.callable() != plan.callable()
            || source.function_type() != abi.function_type()
            || result.as_ref() != abi.function_type()
            || expression_type != Some(result.as_ref())
            || source.retained().len() != abi.prefix_types().len()
            || source
                .retained()
                .iter()
                .zip(abi.prefix_types())
                .any(|(row, ty)| &row.ty != ty)
        {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        }
        return Ok(None);
    };
    let Some(fact) = instances.get(instance) else {
        return Err(RuntimeSemanticFactsError::MissingProjectFunctionInstance { expression });
    };
    let mut function_type = fact.callable_type();
    for _ in 0..call.completed_group().get() {
        let RuntimeTypeShape::Function { result, .. } = function_type.shape() else {
            return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
        };
        function_type = result;
    }
    if fact.callable() != plan.callable()
        || function_type != plan.application_type()
        || (plan.input_specialization().is_none()
            && plan
                .input()
                .function_type()
                .is_some_and(|input_type| input_type != function_type))
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let input_prefix_types = plan
        .input()
        .continuation_abi()
        .map_or(&[][..], RuntimeProjectContinuationAbi::prefix_types);
    let instance_prefix_types = fact
        .parameters()
        .iter()
        .filter_map(|parameter| {
            (parameter.group().get() < call.completed_group().get())
                .then_some(parameter.binding_ty())
        })
        .collect::<Vec<_>>();
    let instance_current_group_parameters = fact
        .parameters()
        .iter()
        .filter_map(|parameter| (parameter.group() == call.completed_group()).then_some(parameter))
        .collect::<Vec<_>>();
    if input_prefix_types.len() != instance_prefix_types.len()
        || input_prefix_types
            .iter()
            .zip(instance_prefix_types)
            .any(|(actual, expected)| actual != expected)
        || plan.current_group_materialization().len() != instance_current_group_parameters.len()
        || plan
            .current_group_materialization()
            .iter()
            .zip(instance_current_group_parameters)
            .any(|(actual, expected)| {
                actual.group() != expected.group()
                    || actual.parameter() != expected.parameter()
                    || actual.kind() != expected.kind()
                    || actual.abi_ty() != expected.abi_ty()
                    || actual.binding_ty() != expected.binding_ty()
            })
    {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    let RuntimeTypeShape::Function { result, .. } = function_type.shape() else {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    };
    if expression_type != Some(result.as_ref()) {
        return Err(RuntimeSemanticFactsError::InvalidProjectFunctionInstance);
    }
    Ok(Some(instance.clone()))
}

fn normalized_tuple_payload_matches(
    payload: &RuntimeNormalizedType,
    expected_fields: &[&RuntimeNormalizedType],
) -> bool {
    let RuntimeTypeShape::Tuple(fields) = payload.shape() else {
        return false;
    };
    fields.len() == expected_fields.len()
        && fields
            .iter()
            .zip(expected_fields)
            .all(|(field, expected)| field == *expected)
}

fn validate_nominal(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    nominal: &RuntimeResolvedNominal,
) -> Result<(), RuntimeSemanticFactsError> {
    let RuntimeResolvedNominalSource::Project { declaration, owner } = nominal.source() else {
        // The Rust constructor consumes an unforgeable accepted source lease.
        // No HIR item exists for a published Rust declaration.
        return Ok(());
    };
    let item = resolve_item(modules, *owner)?;
    if let arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Action { public_id } =
        declaration.kind()
    {
        return match item.kind() {
            HirItemKind::Action(action)
                if action.header().public_id().resolved() == Some(public_id) =>
            {
                Ok(())
            }
            _ => Err(RuntimeSemanticFactsError::WrongItemFamily {
                item: *owner,
                actual: item.kind().family(),
            }),
        };
    }
    let valid = matches!(
        (declaration.kind(), item.kind()),
        (
            arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Struct,
            HirItemKind::Struct(_)
        ) | (
            arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Enum,
            HirItemKind::Enum(_)
        ) | (
            arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::TypeAlias,
            HirItemKind::TypeAlias(_)
        )
    );
    if valid {
        Ok(())
    } else {
        Err(RuntimeSemanticFactsError::WrongItemFamily {
            item: *owner,
            actual: item.kind().family(),
        })
    }
}

fn validate_nominal_record(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    record: &RuntimeResolvedNominalRecord,
) -> Result<(), RuntimeSemanticFactsError> {
    let nominal = record.nominal();
    if let RuntimeResolvedNominalSource::Project { declaration, owner } = nominal.source()
        && !matches!(
            declaration.kind(),
            arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Struct
                | arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Action { .. }
        )
    {
        return Err(RuntimeSemanticFactsError::WrongNominalRecordItemFamily { item: *owner });
    }
    validate_nominal(modules, nominal)
}

fn validate_record_expression_fact(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    owner: ExprId,
    fact: &RuntimeRecordExpressionFact,
) -> Result<(), RuntimeSemanticFactsError> {
    validate_nominal_record(modules, fact.nominal())?;
    let expression = resolve_expr(modules, owner)?;
    let authored = match expression {
        HirExprKind::Record(record) => record.fields(),
        HirExprKind::RecordLiteral(record) => record.fields(),
        _ => {
            return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
                expression: owner,
                expected: RuntimeSemanticFactFamily::NominalRecord,
            });
        }
    };
    if authored.len() != fact.fields().len() {
        return Err(RuntimeSemanticFactsError::WrongExpressionFamily {
            expression: owner,
            expected: RuntimeSemanticFactFamily::NominalRecord,
        });
    }
    let sources_match = authored
        .iter()
        .zip(fact.fields())
        .all(|(authored, checked)| {
            matches!(
                (authored, checked.source()),
                (
                    HirRecordField::Explicit { value, .. },
                    RuntimeRecordExpressionSource::Expression(checked)
                ) if *value == checked
            ) || matches!(
                (authored, checked.source()),
                (
                    HirRecordField::Shorthand { local, .. },
                    RuntimeRecordExpressionSource::Binding(checked)
                ) if *local == checked
            )
        });
    sources_match
        .then_some(())
        .ok_or(RuntimeSemanticFactsError::WrongExpressionFamily {
            expression: owner,
            expected: RuntimeSemanticFactFamily::NominalRecord,
        })
}

fn validate_record_pattern_fact(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    owner: PatternId,
    fact: &RuntimeRecordPatternFact,
) -> Result<(), RuntimeSemanticFactsError> {
    match (fact.nominal(), fact.structural()) {
        (Some(nominal), None) => validate_nominal_record(modules, nominal)?,
        (None, Some(structural)) => validate_normalized_type(modules, structural)?,
        _ => {
            return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                pattern: owner,
                expected: RuntimeSemanticFactFamily::PatternNominalRecord,
            });
        }
    }
    let HirPatternKind::Record { fields, .. } = resolve_pattern(modules, owner)? else {
        return Err(RuntimeSemanticFactsError::WrongPatternFamily {
            pattern: owner,
            expected: RuntimeSemanticFactFamily::PatternNominalRecord,
        });
    };
    let mut checked = fact.fields().iter();
    let mut rest = None;
    for authored in fields {
        match authored {
            HirPatternField::Explicit { pattern, .. } => {
                let Some(projected) = checked.next() else {
                    return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                        pattern: owner,
                        expected: RuntimeSemanticFactFamily::PatternNominalRecord,
                    });
                };
                if projected.source() != RuntimeRecordPatternSource::Pattern(*pattern) {
                    return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                        pattern: owner,
                        expected: RuntimeSemanticFactFamily::PatternNominalRecord,
                    });
                }
            }
            HirPatternField::Shorthand { local, .. } => {
                let Some(projected) = checked.next() else {
                    return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                        pattern: owner,
                        expected: RuntimeSemanticFactFamily::PatternNominalRecord,
                    });
                };
                if projected.source() != RuntimeRecordPatternSource::Binding(*local) {
                    return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                        pattern: owner,
                        expected: RuntimeSemanticFactFamily::PatternNominalRecord,
                    });
                }
            }
            HirPatternField::Rest { binding } if rest.is_none() => {
                rest = Some(match binding {
                    Some(local) => RuntimeRecordPatternRest::Binding(*local),
                    None => RuntimeRecordPatternRest::Ignore,
                });
            }
            HirPatternField::Rest { .. } | HirPatternField::Invalid { .. } => {
                return Err(RuntimeSemanticFactsError::WrongPatternFamily {
                    pattern: owner,
                    expected: RuntimeSemanticFactFamily::PatternNominalRecord,
                });
            }
        }
    }
    if checked.next().is_some() || fact.rest() != rest.unwrap_or(RuntimeRecordPatternRest::Absent) {
        return Err(RuntimeSemanticFactsError::WrongPatternFamily {
            pattern: owner,
            expected: RuntimeSemanticFactFamily::PatternNominalRecord,
        });
    }
    Ok(())
}

fn intern_nominal_record_layout(
    record: &mut RuntimeResolvedNominalRecord,
    layouts: &mut BTreeMap<
        (RuntimeNominalTypeId, RuntimeSemanticTypeId, TypeLayoutHash),
        Arc<RuntimeNominalRecordLayout>,
    >,
) -> Result<(), RuntimeSemanticFactsError> {
    let layout = Arc::clone(record.layout());
    let key = (
        layout.nominal().clone(),
        layout.semantic_identity(),
        layout.layout(),
    );
    match layouts.get(&key) {
        Some(previous) if previous.as_ref() != layout.as_ref() => {
            return Err(RuntimeSemanticFactsError::ConflictingNominalRecordLayout {
                nominal: key.0,
                semantic_identity: key.1,
                layout: key.2,
            });
        }
        Some(previous) => record.layout = Arc::clone(previous),
        None => {
            layouts.insert(key, layout);
        }
    }
    Ok(())
}

fn resolve_item<'project>(
    modules: &BTreeMap<HirModuleId, &'project HirModule>,
    id: ItemId,
) -> Result<&'project arcweft_lang_hir::item::HirItem, RuntimeSemanticFactsError> {
    module_for(modules, id.module())?
        .resolve_item(id)
        .map_err(|_| RuntimeSemanticFactsError::UnresolvedItem { item: id })
}

fn validate_iterator_witness_method_edges(
    runtime_owners: RuntimeSemanticOwnerSet<'_>,
    statement: StmtId,
    source_type: RuntimeSemanticTypeId,
    iteration: &RuntimeIteratorFact,
    methods: &BTreeMap<RuntimeTraitMethodInstanceKey, RuntimeTraitMethodFact>,
) -> Result<(), RuntimeSemanticFactsError> {
    let expected = match iteration {
        RuntimeIteratorFact::Builtin(_) => BTreeMap::new(),
        RuntimeIteratorFact::Witness(witness) => match witness.executable() {
            RuntimeIteratorWitnessExecutableFact::TraitCalls { into_iter, next } => {
                BTreeMap::from([
                    (
                        HirRuntimeIteratorWitnessMethodRole::IntoIterator,
                        into_iter.clone(),
                    ),
                    (
                        HirRuntimeIteratorWitnessMethodRole::IteratorNext,
                        next.clone(),
                    ),
                ])
            }
            RuntimeIteratorWitnessExecutableFact::IdentityIntoIterator { next } => {
                BTreeMap::from([(
                    HirRuntimeIteratorWitnessMethodRole::IteratorNext,
                    next.clone(),
                )])
            }
        },
    };
    let source = HirRuntimeReachabilitySite::Statement(statement);
    let mut actual = BTreeMap::new();
    for edge in runtime_owners.edges_from(source) {
        let HirRuntimeReachabilityEdgeKind::CheckedIteratorWitnessMethod {
            role,
            implementation,
            member,
            method,
        } = edge.kind()
        else {
            continue;
        };
        let row = (*implementation, *member, method.clone());
        if actual
            .insert(*role, row.clone())
            .is_some_and(|existing| existing != row)
        {
            return Err(
                RuntimeSemanticFactsError::InvalidIteratorWitnessMethodEdge {
                    statement,
                    role: *role,
                },
            );
        }
    }
    if let Some(role) = expected.iter().find_map(|(role, expected_method)| {
        actual
            .get(role)
            .is_none_or(|(_, _, actual_method)| actual_method != expected_method)
            .then_some(*role)
    }) {
        return Err(
            RuntimeSemanticFactsError::InvalidIteratorWitnessMethodEdge { statement, role },
        );
    }
    if let Some(role) = actual
        .keys()
        .copied()
        .find(|role| !expected.contains_key(role))
    {
        return Err(
            RuntimeSemanticFactsError::InvalidIteratorWitnessMethodEdge { statement, role },
        );
    }
    for (role, method) in expected {
        let Some((implementation, member, actual_method)) = actual.get(&role) else {
            return Err(
                RuntimeSemanticFactsError::InvalidIteratorWitnessMethodEdge { statement, role },
            );
        };
        let expected_trait = match role {
            HirRuntimeIteratorWitnessMethodRole::IntoIterator => {
                RuntimeTraitIdentity::StandardIntoIterator
            }
            HirRuntimeIteratorWitnessMethodRole::IteratorNext => {
                RuntimeTraitIdentity::StandardIterator
            }
        };
        let self_type = match (role, iteration) {
            (HirRuntimeIteratorWitnessMethodRole::IntoIterator, _) => source_type,
            (
                HirRuntimeIteratorWitnessMethodRole::IteratorNext,
                RuntimeIteratorFact::Witness(witness),
            ) => witness.iterator().identity(),
            (
                HirRuntimeIteratorWitnessMethodRole::IteratorNext,
                RuntimeIteratorFact::Builtin(_),
            ) => {
                return Err(
                    RuntimeSemanticFactsError::InvalidIteratorWitnessMethodEdge { statement, role },
                );
            }
        };
        let key = RuntimeTraitMethodInstanceKey::new(method.clone(), self_type);
        if actual_method != &method
            || methods.get(&key).is_none_or(|fact| {
                !(fact.declaration() == &method
                    && fact.implementation() == *implementation
                    && fact.member() == *member
                    && fact.trait_identity() == &expected_trait)
            })
        {
            return Err(
                RuntimeSemanticFactsError::InvalidIteratorWitnessMethodEdge { statement, role },
            );
        }
    }
    Ok(())
}

fn validate_trait_method(
    modules: &BTreeMap<HirModuleId, &HirModule>,
    method: &RuntimeTraitMethodFact,
) -> Result<(), RuntimeSemanticFactsError> {
    let item = resolve_item(modules, method.implementation())?;
    let HirItemKind::Impl(implementation) = item.kind() else {
        return Err(RuntimeSemanticFactsError::WrongItemFamily {
            item: method.implementation(),
            actual: item.kind().family(),
        });
    };
    let Some(HirImplMember::Function(function)) =
        implementation.members().get(usize::from(method.member()))
    else {
        return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
    };
    let name = function
        .name()
        .resolved()
        .ok_or(RuntimeSemanticFactsError::InvalidTraitMethodIdentity)?;
    if method.declaration().method().as_str() != name.as_str() || function.body().is_none() {
        return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
    }
    if let Some(semantics) = method.closed_semantics() {
        let receiver = function
            .parameter_groups()
            .iter()
            .flat_map(arcweft_lang_hir::item::HirMethodParameterGroup::parameters)
            .find_map(|parameter| parameter.receiver())
            .ok_or(RuntimeSemanticFactsError::InvalidTraitMethodIdentity)?;
        let [local] = receiver.locals() else {
            return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
        };
        if semantics.local_type(*local) != Some(method.self_type()) {
            return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
        }
    }
    match method.trait_identity() {
        RuntimeTraitIdentity::Project(trait_item) => {
            let trait_owner = *trait_item;
            let trait_item = resolve_item(modules, trait_owner)?;
            if !matches!(trait_item.kind(), HirItemKind::Trait(_)) {
                return Err(RuntimeSemanticFactsError::WrongItemFamily {
                    item: trait_owner,
                    actual: trait_item.kind().family(),
                });
            }
        }
        RuntimeTraitIdentity::StandardIterator | RuntimeTraitIdentity::StandardIntoIterator => {}
        RuntimeTraitIdentity::StandardDisplayText if name.as_str() == "display_text" => {}
        RuntimeTraitIdentity::StandardDisplayText => {
            return Err(RuntimeSemanticFactsError::InvalidTraitMethodIdentity);
        }
    }
    Ok(())
}

#[cfg(test)]
#[path = "semantic_facts/tests.rs"]
pub(crate) mod tests;

#[cfg(test)]
#[path = "semantic_facts/variant_selection_tests.rs"]
mod variant_selection_tests;

/// Borrows the existing owning source authority at each admission boundary.
/// It does not duplicate generation/module validation or issue new evidence.
enum RuntimeValueOriginContext<'a> {
    Project(HirAnalysisProjectView<'a>),
    Closed(&'a CheckedLocalUseAuthority),
}

fn validate_entity_value(
    origin_context: RuntimeValueOriginContext<'_>,
    expression: ExprId,
    expression_type: Option<&RuntimeNormalizedType>,
    entity: &arcweft_lang_sema::final_analysis::CheckedEntityValueProjection,
) -> Result<(), RuntimeSemanticFactsError> {
    let accepted_origin = match origin_context {
        RuntimeValueOriginContext::Project(project) => {
            entity.origin().validate_owner(project, expression)
        }
        RuntimeValueOriginContext::Closed(local_uses) => {
            entity.origin().validate_authority(local_uses, expression)
        }
    };
    if !accepted_origin {
        return Err(RuntimeSemanticFactsError::InvalidEntityValueOrigin { expression });
    }
    if expression_type.is_none_or(|ty| {
        ty.identity().as_bytes() != entity.type_identity().as_bytes()
            || !ty.matches_entity_type(entity.ty())
    }) {
        return Err(RuntimeSemanticFactsError::InvalidEntityValueType { expression });
    }
    Ok(())
}

fn validate_entity_pattern_type(
    pattern: PatternId,
    ty: Option<&RuntimeNormalizedType>,
    projection: &arcweft_lang_sema::final_analysis::CheckedEntityPatternProjection,
) -> Result<(), RuntimeSemanticFactsError> {
    if ty.is_none_or(|ty| {
        ty.identity().as_bytes() != projection.type_identity().as_bytes()
            || !ty.matches_entity_type(projection.ty())
    }) {
        return Err(RuntimeSemanticFactsError::InvalidEntityPatternType { pattern });
    }
    Ok(())
}
