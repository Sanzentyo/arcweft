$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
function Read-Failures([string]$Prefix) {
    $log=Get-Content -LiteralPath (Join-Path $d "$Prefix-sema.log") -Raw
    $blocks=[regex]::Matches($log,'(?ms)^\s+FAIL\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+arcweft-lang-sema (\S+)\r?\n(.*?)(?=^\s+(?:PASS|FAIL|SKIP) \[|^\s*Summary \[|\z)')
    $failures=[ordered]@{}
    foreach($block in $blocks) {
        $matched=[regex]::Match($block.Groups[2].Value,'(?ms)^\s*thread .*? panicked at [^\r\n]+\r?\n(.*?)(?=^\s*note:|^\s*thread |\z)')
        if($matched.Success) {
            $failure=$matched.Groups[1].Value.Trim()
            $failures[$block.Groups[1].Value]=($failure -replace '\r\n',"`n")
        }
    }
    $failures
}
$before=Read-Failures 'effect-free-expected-types.dev02'
$after=Read-Failures 'effect-request-journal.dev01'
if(!$before.Count -or !$after.Count){throw 'No extracted failures.'}
$changes=@(foreach($id in $before.Keys){if($before[$id] -cne $after[$id]){[ordered]@{id=$id;before=$before[$id];after=$after[$id]}}})
$additional=@(foreach($id in $after.Keys){if(!$before.Contains($id)){[ordered]@{id=$id;after=$after[$id]}}})
[ordered]@{version=1;baseline=$before.Count;current=$after.Count;changed=$changes;additional=$additional} |
    ConvertTo-Json -Depth 5 | Tee-Object -FilePath (Join-Path $d 'effect-request-journal.dev01-compare-diagnostics.json')




