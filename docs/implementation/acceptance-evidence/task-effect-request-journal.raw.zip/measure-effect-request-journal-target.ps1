$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$target=(Resolve-Path -LiteralPath 'target').Path
if($target -ne 'D:\git\arcweft\target'){throw 'Unexpected target path.'}
$bytes=([IO.DirectoryInfo]::new($target).EnumerateFiles('*',[IO.SearchOption]::AllDirectories) | Measure-Object Length -Sum).Sum
$free=[IO.DriveInfo]::new('D').AvailableFreeSpace
[ordered]@{
    path=$target;bytes=[long]$bytes;gigabytes=[Math]::Round($bytes/1e9,2);
    free_gb=[Math]::Round($free/1e9,2);observed_at=(Get-Date -Format o)
} | ConvertTo-Json | Tee-Object -FilePath (Join-Path $d 'effect-request-journal.dev01-target.json')







