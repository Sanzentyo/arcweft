$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '0d01daecd52cb26d7875b514a1628794df03532a'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'prepared-lexical-phase.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='The real calculation phase owns graph capability and completion authority together. Admission remains read-only and permission-only; preparation borrows the actual mutable graph; completion borrows a graph read view and the exact closed-effects owner. The old ConstraintOperandEffects selector and invalid prepared-to-canonical transport implementation are deleted. Prepared lexical transport uses the shared scoped type grammar and real lexical frame identities across every type/const/effect port, preserving Named/Future applications without solving or preparing their bodies. One graph term edit spans the whole type; error or cancellation drops the edit and rolls back new terms while retaining spent work. Bindings, alias resolution, sealing, solution restoration and producer projections thread their actual graph. Source scopes and provenance remain retained. Completed binding relocation first canonicalizes the already header-projected value through the same principal, transports canonical algebra and wraps its representation back into the prepared domain without minting terms after the immutable principal snapshot. Final original binding validation and equation comparison likewise use canonical transport into their actual owner/calculation scopes; original prepared equations are not rewritten. Three new fixtures cover live Named/Future functions under real frame permutation and nested type/const/effect binders, late failure/cancellation rollback and equal-shape foreign frame refusal, and completed type-only binding relocation through a real Named body with graph term count unchanged. The changed admission fixtures use their actual path C receipt for closure; they contain no effect unknowns or headers, so empty query/input arrays there do not synthesize a missing Future. Four fmt checks succeed; required full Sema target compilation fails, and no fixture execution is claimed. Intermediate error conversion/type-parameter errors and two new fixture typing errors are repaired with all failed logs retained. Old frontend/fixture callers and final transaction completion still require migration. No broad allocation/copy preflight, performance, Fn-local quantified/guarded contract, or public acceptance claim is made. Accepted Generic Match and runtime cuts remain accepted. Lexical transport and projection phase are coherent internal owners rather than arbitrary LOC splits; test files and physical LOC/bytes/growth are measured below. Cargo dependency/features, facade, layer direction, I/O, unsafe, codec/version, production budgets, jobs and profile are unchanged. Existing resolved graph/reverse dependency evidence remains applicable; scanner and workspace acceptance were not rerun.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'prepared-lexical-phase.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03','dev04')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'prepared-lexical-phase.'+$iteration+$suffix}})
$names+=@('prepared-lexical-phase.source-publication.json','prepared-lexical-phase.ownership-review.json','prepared-lexical-phase.staged-review.json','prepared-lexical-phase.dev04-diagnostic-review.json')
$names+=@('run-prepared-lexical-phase-check.ps1','archive-prepared-lexical-phase.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-prepared-lexical-phase-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-prepared-lexical-phase-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'prepared-lexical-phase.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
