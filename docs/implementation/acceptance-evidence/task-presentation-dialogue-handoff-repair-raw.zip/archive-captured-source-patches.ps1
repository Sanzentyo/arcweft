param([Parameter(Mandatory)][string[]]$Stems)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskTemp/convergence-image-git-bytes.ps1"
$ordinaryTree=(& git write-tree).Trim()
foreach($stem in $Stems) {
    $patchPath="$taskTemp/$stem.source-capture.patch"
    if(Test-Path -LiteralPath $patchPath){throw "Patch already exists: $stem"}
    $freeze=Get-Content -LiteralPath "$taskTemp/$stem.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
    $captures=@(Get-Content -LiteralPath "$taskTemp/$stem.sources.json" -Raw|ConvertFrom-Json)
    if(-not $captures.Count){throw "Missing original source captures: $stem"}
    $priorIndex=$env:GIT_INDEX_FILE
    $captureIndex="$taskTemp/$stem.source-capture.index"
    if(Test-Path -LiteralPath $captureIndex){throw 'Capture index already exists'}
    try {
        $env:GIT_INDEX_FILE=$captureIndex
        & git read-tree $freeze.base
        if($LASTEXITCODE -ne 0){throw 'Cannot read original base'}
        foreach($row in $captures) {
            if($row.path -notmatch '^crates/arcweft-(core|compiler)/'){throw 'Capture outside task source owners'}
            $pin=@($freeze.paths|Where-Object path -eq $row.path)
            $sha=(Get-FileHash -LiteralPath $row.capture).Hash.ToLowerInvariant()
            if($pin.Count -ne 1 -or $pin[0].sha256 -ne $sha -or $row.sha256 -ne $sha){throw 'Captured source drift'}
            $blob=(& git hash-object -w -- $row.capture).Trim()
            if($LASTEXITCODE -ne 0){throw 'Cannot retain source blob'}
            & git update-index --add --cacheinfo ('100644,'+$blob+','+$row.path)
            if($LASTEXITCODE -ne 0){throw 'Cannot bind captured source'}
        }
        $patch=Read-GitBytes @('diff','--cached','--binary','--full-index',$freeze.base,'--')
        [IO.File]::WriteAllBytes($patchPath,$patch)
        [ordered]@{version=1;epoch=$stem;base=$freeze.base;paths=@($captures|ForEach-Object {[ordered]@{path=$_.path;sha256=$_.sha256}});patchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant();provenance='original captured source bytes verified against each frozen input; task Core/Compiler changes only; no Cargo artifacts or held WIP copied'}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$taskTemp/$stem.source-capture-patch.json" -Encoding utf8
    } finally {
        $env:GIT_INDEX_FILE=$priorIndex
    }
    if((& git write-tree).Trim() -ne $ordinaryTree){throw 'Ordinary index changed'}
    Write-Output "$stem : $($captures.Count) captured sources"
}
