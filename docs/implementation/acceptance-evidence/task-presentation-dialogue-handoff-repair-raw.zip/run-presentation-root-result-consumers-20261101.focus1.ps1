$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$graph=Get-Content -LiteralPath "$taskTemp/presentation-dialogue-receipt-reverse-20261101.graph.json" -Raw|ConvertFrom-Json
$selection=@('--lib','--tests')+@($graph.reversePackages|Where-Object {$_ -ne 'arcweft-cli'}|ForEach-Object {'-p';$_})+@('--all-features','--locked','-E','test(control_results::labelled_loop_) | test(awfb_session_save_restores_the_generic_prefix_into_its_pinned_program)')
& "$taskTemp/run-source-frozen-nextest.ps1" -Stem 'presentation-root-result-consumers-20261101.focus1' -Selection $selection -ExpectedMatches 10
