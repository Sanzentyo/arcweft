param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
if(Test-Path -LiteralPath "$taskTemp/$Stem.sources.json"){throw 'Source capture already exists'}
$freeze=Get-Content -LiteralPath "$taskTemp/$Stem.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$paths=@(@(git diff HEAD --name-only -- crates/arcweft-core crates/arcweft-compiler)+@(git ls-files --others --exclude-standard -- crates/arcweft-core crates/arcweft-compiler)|Sort-Object -Unique)
$captures=@(foreach($path in $paths){
    $row=@($freeze.paths|Where-Object path -eq $path)
    if($row.Count -ne 1 -or $row[0].sha256 -ne (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()){throw ('Frozen source changed: '+$path)}
    $capture="$taskTemp/$Stem.sources/$path"
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($capture))
    [IO.File]::Copy((Join-Path 'D:/git/arcweft' $path),$capture,$false)
    [ordered]@{path=$path;capture=$capture;sha256=$row[0].sha256}
})
$captures|ConvertTo-Json -Depth 8 -AsArray|Set-Content -LiteralPath "$taskTemp/$Stem.sources.json" -Encoding utf8
[ordered]@{epoch=$Stem;capturedSources=$captures.Count}|ConvertTo-Json -Compress
