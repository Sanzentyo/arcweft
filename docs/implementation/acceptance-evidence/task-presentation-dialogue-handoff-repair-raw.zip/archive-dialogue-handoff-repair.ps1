$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$outDir='D:/git/arcweft/docs/implementation/acceptance-evidence'
$zipPath="$outDir/task-presentation-dialogue-handoff-repair-raw.zip"
$manifestPath="$outDir/task-presentation-dialogue-handoff-repair-raw.json"
$stage="$taskTemp/dialogue-handoff-repair-archive"
if((Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $manifestPath) -or (Test-Path -LiteralPath $stage)){throw 'Archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    ($_.Name -match '^presentation-dialogue-(frame-20261101\.debug|handoff-20261101\.)' -or
     $_.Name -match '^presentation-(dialogue-handoff|root-result-consumers)-source-20261101\.' -or
     $_.Name -match '^presentation-root-result-consumers-20261101\.focus1\.') -and
    $_.Extension -in @('.json','.log','.txt','.patch')
})
$stems=@($files|Where-Object Name -like '*.source-freeze.json'|ForEach-Object {$_.Name.Replace('.source-freeze.json','')})
$helpers=@('run-source-frozen-nextest.ps1','audit-nextest-final-result.ps1','capture-frozen-changes.ps1','archive-captured-source-patches.ps1','archive-dialogue-handoff-repair.ps1','run-presentation-root-result-consumers-20261101.focus1.ps1')+@($stems|ForEach-Object {"run-$_.ps1"})
$files+=@(foreach($name in $helpers){$path=Join-Path $taskTemp $name;if(Test-Path -LiteralPath $path){Get-Item -LiteralPath $path}})
$files=@($files|Sort-Object Name -Unique)
[void][IO.Directory]::CreateDirectory($stage)
$rows=@(foreach($file in $files){
    $destination=Join-Path $stage $file.Name
    [IO.File]::Copy($file.FullName,$destination,$false)
    $sha=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()
    if((Get-FileHash -LiteralPath $destination).Hash.ToLowerInvariant() -ne $sha){throw 'Raw copy drift'}
    [ordered]@{entry=$file.Name;bytes=$file.Length;sha256=$sha}
})
[IO.Compression.ZipFile]::CreateFromDirectory($stage,$zipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    if($archive.Entries.Count -ne $rows.Count){throw 'Archive inventory differs'}
    foreach($row in $rows){
        $entry=$archive.GetEntry($row.entry)
        if($null -eq $entry -or $entry.Length -ne $row.bytes){throw 'Archive entry differs'}
        $stream=$entry.Open()
        try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($sha -ne $row.sha256){throw 'Archive byte drift'}
    }
}finally{$archive.Dispose()}
$terminal=@(foreach($file in $files|Where-Object Name -like '*.runtime.terminal-audit.json'){
    $result=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json -Depth 30
    [ordered]@{entry=$file.Name;diagnosticOnly=($file.Name -match '^presentation-dialogue-frame-20261101\.debug');base=$result.base;summary=$result.summary;actualExitCode=$result.actualExitCode;sourceInputs=$result.sourceInputs;sourceDrift=$result.sourceDrift;failureSet=$result.failureSet}
})
[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');sourceCommit='390304bc5308b8a2cb4eb2672a8f51e8fe59fa1e';rootResultConsumerCommit='97092efcc46bb1ee53c93b39400941d992328464';
    scope='Historical diagnostic and repair evidence only. This archive is not a current specification or a claim of final reverse/workspace acceptance.';
    archive=[ordered]@{path=[IO.Path]::GetFileName($zipPath);bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$rows.Count;entryByteDrift=0};
    reconstruction='Each source-capture.patch applies to the full base SHA in its source-capture-patch.json. Captured task Core/Compiler bytes were checked against the frozen input hashes. No Cargo binaries, caches, or held user WIP were copied.';
    clarifications=@(
        'debug1 through debug7 intentionally instrumented failures; their diagnostic source is retained only as historical patches and is absent from the published source.',
        'owner1 and owner3 failed compilation. owner4 completed a library-only catalog but its expected count incorrectly included 53 integration cases; its wrapper rejected the count before runtime.',
        'owner11 ran all 2218 Core tests: 2217 passed and the old queue fixture failed. Only that test body changed afterwards; all other 4033-input hashes and other Core test bodies were checked unchanged. focus17 passed its completed real-parent migration. These are separate runs, not one all-2218 passing epoch.',
        'source1 passed four actual Source regressions and the forged child save test before the subsequent extra parent-instance alias check. It is not relabeled as a run on the final source input.',
        'The first owner11 capture helper inspected unstaged paths after staging and found zero paths; it wrote no manifest. Its 13 original source captures were recovered from the still-pinned reviewed Git index and matched every frozen hash before that index was refreshed.'
    );
    terminalResults=$terminal;files=$rows
}|ConvertTo-Json -Depth 35|Set-Content -LiteralPath $manifestPath -Encoding utf8
[ordered]@{entries=$rows.Count;uncompressedBytes=($rows|Measure-Object bytes -Sum).Sum;archiveBytes=(Get-Item -LiteralPath $zipPath).Length;terminalResults=$terminal.Count;entryByteDrift=0}|ConvertTo-Json -Compress
