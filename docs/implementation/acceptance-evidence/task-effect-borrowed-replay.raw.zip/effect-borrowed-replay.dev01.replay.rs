#![allow(dead_code, unused_imports)]
#[path = "effect-borrowed-replay.dev01.baseline/effect_row.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/declaration.rs"]
mod declaration;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/membership.rs"]
mod membership;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/set.rs"]
mod set;

use std::collections::BTreeMap;

use decision::{DecisionControl, DecisionEncoding, DecisionWork, EffectDecision};
use declaration::EffectDeclarationError;
use membership::{EffectFormula, EffectPredicate, MembershipEncoding};
use set::EffectSet;

macro_rules! meter {
    ($kind:ident, $meter:ident, $work:ty, $control:path, $error:ty) => {
        #[derive(Default)]
        struct $meter { visits: usize, nodes: usize }
        impl $control for $meter {
            type Error = $error;
            fn charge(&mut self, work: $work) -> Result<(), Self::Error> {
                match work {
                    $kind::Visit => self.visits += 1,
                    $kind::Node => self.nodes += 1,
                }
                Ok(())
            }
        }
    };
}
use baseline::DecisionWork as PriorWork;
meter!(PriorWork, Prior, baseline::DecisionWork, baseline::DecisionControl, baseline::EffectDeclarationError);
meter!(DecisionWork, Current, DecisionWork, DecisionControl, EffectDeclarationError);

fn main() {
    use arcweft_id::EffectId;
    let mut comparisons = 0;
    for width in [16u16, 256u16] {
        for used in [0u16, 1u16, 4u16, 16u16] {
            let mut prior_source = baseline::EffectFormula::empty();
            let mut current_source = EffectFormula::empty();
            for index in 0..used {
                prior_source = prior_source.union(
                    &baseline::EffectFormula::variable(index, &mut Prior::default()).unwrap(),
                    &mut Prior::default(),
                ).unwrap();
                current_source = current_source.union(
                    &EffectFormula::variable(index, &mut Current::default()).unwrap(),
                    &mut Current::default(),
                ).unwrap();
            }
            let mut prior_bindings = BTreeMap::new();
            let mut current_bindings = BTreeMap::new();
            for index in 0..width {
                let label = EffectId::parse(&format!("bench.label{index:04}")).unwrap();
                let old = baseline::EffectFormula::literal(
                    baseline::EffectSet::from_labels([label.as_str()]).unwrap(),
                    Some(width + index),
                );
                let new = EffectFormula::literal(
                    EffectSet::from_labels([label.as_str()]).unwrap(),
                    Some(width + index),
                );
                prior_bindings.insert(index, old);
                current_bindings.insert(index, new);
            }
            let borrowed: BTreeMap<_,_> = current_bindings.iter().map(|(&key, row)| (key, row)).collect();
            let mut before = Prior::default();
            let mut after = Current::default();
            let old = prior_source.substitute(&prior_bindings, &mut before).unwrap();
            let new = current_source.substitute(&borrowed, &mut after).unwrap();
            assert_eq!(format!("{old:?}"), format!("{new:?}"));
            comparisons += 1;
            println!("row bound={width} referenced={used} visits={}->{} nodes={}->{}",
                before.visits, after.visits, before.nodes, after.nodes);

            let old_expected = prior_source.subset(&baseline::EffectFormula::empty(), &mut Prior::default()).unwrap();
            let new_expected = current_source.subset(&EffectFormula::empty(), &mut Current::default()).unwrap();
            before = Prior::default();
            after = Current::default();
            let old = old_expected.substitute(&prior_bindings, &mut before).unwrap();
            let new = new_expected.substitute(&borrowed, &mut after).unwrap();
            assert_eq!(format!("{old:?}"), format!("{new:?}"));
            comparisons += 1;
            println!("predicate bound={width} referenced={used} visits={}->{} nodes={}->{}",
                before.visits, after.visits, before.nodes, after.nodes);
        }
    }
    println!("canonical_comparisons={comparisons}");
}
