$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = 'fce9f5623e265a13905bd976d7ca5735233142f7'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'correlated-effect-prerequisites.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\n(?:pub(?:\([^)]*\))?\s+)?mod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='The pending constraint owns composed read scopes for each alternative. Callable continuation validates the original graph delta. Analyzer candidate and fact-ledger owners retain the matching publication permits and consume only the chosen projections; the existing batch applies the selected graph and facts.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'correlated-effect-prerequisites.ownership-review.json') -Encoding utf8NoBOM
$names = @('correlated-effect-prerequisites.dev02-input.json','correlated-effect-prerequisites.dev02-staged.patch','correlated-effect-prerequisites.dev02-fmt-apply.log','correlated-effect-prerequisites.dev02-fmt-check.log','correlated-effect-prerequisites.dev02-fmt-result.json','correlated-effect-prerequisites.dev02-nextest.log','correlated-effect-prerequisites.dev02-nextest-result.json','correlated-effect-prerequisites.dev02-structure.log','correlated-effect-prerequisites.dev02-structure-result.json','correlated-effect-prerequisites.source-publication.json','correlated-effect-prerequisites.ownership-review.json','correlated-effect-prerequisites.nextest-comparison.json','correlated-effect-prerequisites.reverse-dependencies.log','correlated-effect-prerequisites.target-size.json')
$names += @('correlated-effect-prerequisites.dev01-input.json','correlated-effect-prerequisites.dev01-input.patch','correlated-effect-prerequisites.dev01-check.log','correlated-effect-prerequisites.dev01-result.json','correlated-effect-prerequisites.diagnostic-comparison.json','correlated-effect-prerequisites.dev01-nextest.log','correlated-effect-prerequisites.dev01-nextest-result.json','correlated-effect-prerequisites.dev01-nextest-retry01.log','correlated-effect-prerequisites.dev01-nextest-retry01-result.json')
$names += @('runtime-effect-delta.debugger.log','runtime-effect-scheme.debugger.log','runtime-effect-diagnostic.dev01-nextest.log','runtime-map-typed-error.debugger.log')
$names += @('archive-correlated-effect-prerequisites.ps1','run-correlated-effect-prerequisites-validation.ps1','compare-correlated-effect-prerequisites-nextest.ps1','compare-correlated-effect-prerequisites-diagnostics.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-correlated-effect-prerequisites.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-correlated-effect-prerequisites.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'correlated-effect-prerequisites.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json












