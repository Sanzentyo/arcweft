param([Parameter(Mandatory)][string]$Iteration,[Parameter(Mandatory)][ValidateSet('nextest','structure')][string]$Kind,[string]$Attempt = '')
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$prefix = Join-Path (Split-Path -Parent $PSCommandPath) ('correlated-effect-prerequisites.' + $Iteration)
$manifest = Get-Content -Raw -LiteralPath ($prefix + '-input.json') | ConvertFrom-Json
$report = $prefix + '-' + $Kind + $Attempt
$log = $report + '.log'
$result = $report + '-result.json'
if ((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $result)) { throw 'Evidence already exists' }
function Verify-Inputs {
    if ((git rev-parse HEAD) -ne $manifest.base) { throw 'Base changed during verification' }
    foreach ($file in $manifest.paths) {
        if ((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256) {
            throw ('Input changed: ' + $file.path)
        }
    }
}
Verify-Inputs
$started = Get-Date -Format o
$env:CARGO_INCREMENTAL = '0'
switch ($Kind) {
    'nextest' {
        $command = 'cargo nextest run --locked -p arcweft-compiler --test evaluated_effects --test generic_continuation_snapshot --no-fail-fast'
        cargo nextest run --locked -p arcweft-compiler --test evaluated_effects --test generic_continuation_snapshot --no-fail-fast *> $log
        $checkExit = $LASTEXITCODE
    }
    'structure' {
        $command = 'just structure-audit-gate'
        just structure-audit-gate *> $log
        $checkExit = $LASTEXITCODE
    }
}
Verify-Inputs
$summary = @(Get-Content -LiteralPath $log | Where-Object { $_ -match '^\s*(Summary \[|FAIL \[|error:)' })
@{command=$command; exit=$checkExit; started=$started; finished=(Get-Date -Format o); summary=$summary; input=$manifest; terminal=@(Get-Content -LiteralPath $log -Tail 5)} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $result -Encoding utf8NoBOM
@{command=$command; exit=$checkExit; summary=$summary} | ConvertTo-Json

