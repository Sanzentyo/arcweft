$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$n){Get-Content -LiteralPath (Join-Path $t ($n+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('viewStaticProperties')){throw 'Preserve existing integration evidence'}
$source=Read-Record 'checkpoint-view-static-properties-20261105.verified'
$correction=Read-Record 'view-member-diagnostic-owner.verified'
$owner=Read-Record 'view-static-properties-owner-final1-20261105.runtime.terminal-audit'
$graph=Read-Record 'view-static-properties.graph'
if((git rev-parse HEAD).Trim() -ne $source.commit -or $owner.passed -ne 12 -or $owner.failed -ne 0 -or $graph.selectedPackages -ne 44 -or $graph.metadataTreeDrift){throw 'Unexpected published input or result'}
[IO.File]::WriteAllBytes((Join-Path $t 'view-static-properties-record-before.json'),[IO.File]::ReadAllBytes((Join-Path $PWD $recordPath)))
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$attempts=@(foreach($stem in @((1..10 | ForEach-Object {'view-style-identity-owner'+$_+'-20261105'}),'view-static-properties-branch1-20261105','view-static-properties-branch2-20261105','view-static-properties-owner-final1-20261105','view-static-properties-cli-rag1-20261105') | ForEach-Object {$_}) {
 if(Test-Path -LiteralPath (Join-Path $t ($stem+'.runtime.terminal-audit.json'))){[ordered]@{run=$stem;runtime=Read-Record ($stem+'.runtime.terminal-audit')}}
 elseif(Test-Path -LiteralPath (Join-Path $t ($stem+'.catalog.json'))){[ordered]@{run=$stem;catalog=Read-Record ($stem+'.catalog');runtime='not run: catalog failed'}}
 else{throw ('Missing attempted run: '+$stem)}
})
$packages=Import-Csv -LiteralPath (Join-Path $t 'view-static-properties-quality1-20261105.structure-report/package_metrics.csv')
$measurements=Read-Record 'view-static-properties-owner-measurements'
$measurements.packageCoupling=@($packages | Where-Object package -in $graph.roots)
$measurements.ownershipDisposition=@(
 'HIR owns the shared retained declaration header, derived/explicit identity, authored lexical binding and Source freeze. IdentityOnly is valid only for explicit Style declarations; no public ID is reconstructed into a fake lexical name. The semantic index uses that catalog once and deletes its old independent Style producer.',
 'Sema owns the closed modifier registry and contextual static name grammar, sharing candidate transaction and call-frame authority. It publishes one bounded ViewPartLocalName fact, its PublicId scalar projection and transcript payload; it does not parse Source text or run another runtime evaluator.',
 'Compiler view.rs remains a cohesive3083-LOC producer owning its existing local/capture/output state. Its124-LOC growth tracks only nodes returned by an expression, applies modifiers there, and composes a complete Style catalog before product validation. No side node catalog, unrelated I/O state, fallback resolver or public API for physical splitting was introduced.',
 'Bundle model.rs1968LOC adds legitimate compiler mutation access to existing node-owned fields before validated publication. View owns the name bounds, property roles and selector/state registries; no dependency direction or Cargo edge changed.',
 'The367-LOC new compiler test owner follows the static-property boundary: original IDs and aliases, explicit identities, rejected families/units, inclusive UTF8/segment limits, root/child isolation, If/Match returned nodes, canonical product composition and actual runtime cascade. Existing large compiler/sema owners receive only their exhaustive projection cases; their broader responsibilities and I/O boundaries are unchanged.'
)
$measurements | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $t 'view-static-properties-owner-measurements.json') -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object { $_.Name -match '^(view-style-identity-|view-static-properties-|view-member-diagnostic-owner\.|checkpoint-view-static-properties-)' -and $_.Extension -in @('.json','.log','.ps1','.txt','.pathspec','.patch') })
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'view-static-properties-quality1-20261105.structure-report') -File)
$files+=@(Get-Item -LiteralPath (Join-Path $t 'run-presentation-projection-owner.ps1'),(Join-Path $t 'run-action-payload-quality.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'record-view-static-properties.ps1'))
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-view-static-properties.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$prior=$record.viewNodeProperties
$prior.historicalScope='Historical checkpoint recorded2026-11-05T13:49:25Z. Its original validation and full SHAs are retained. Current status is maintained only in docs/implementation/current-status.md.'
$prior.Remove('state')
$prior.historicalFailureObservations=@($prior.concreteRemainingEvidence[0..3])+@('showcase6 actually ran4 cases with2PASS2FAIL. The inference that Syntax must issue a new missing-member diagnostic was wrong: owner2 subsequently exposed four existing HIR recovery/budget failures. The HIR already owns that diagnostic.')
$prior.Remove('concreteRemainingEvidence')
$prior.historicalCheckpointPatch=[ordered]@{paths=$prior.pending.paths;patchSha256=$prior.pending.patchSha256;scope='Unaccepted working-tree patch at that historical input; replaced by the subsequently published integration.'}
$prior.Remove('pending')
$prior.validationScopeAtRecord=$prior.notClaimed
$prior.Remove('notClaimed')
$prior.supersessionReason='Delete the superseded residual-work/current-state enumeration because Style identity, modifiers and showcase compilation have since been implemented and validated at the owner boundary. Correct the extra Syntax diagnostic inference using four concrete HIR E13 failures; do not change earlier actual Syntax743PASS, command receipts, commit SHAs or raw archives.'
$record.viewStaticProperties=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');scope='Published static View-property integration checkpoint; full consumer execution is not claimed by this record. Current status has one list in current-status.md.'
 source=$source;diagnosticOwnershipCorrection=$correction;owner=$owner
 implementation=@('Style uses the shared retained declaration identity and one semantic-index producer; explicit ID-only Style has no fabricated lexical binding. Bare dotted names, visibility and aliases retain original identity.','Geometry/part/Style modifiers consume typed checked facts and attach to expression-returned nodes. Constructor geometry uses the same property roles. Part names preflight255UTF8 bytes and32segments, inclusive.','Compile the complete named-sheet/inline-patch catalog before validating program references. Source selectors map part/interaction/element state through shared registries. Runtime cascade retains authored application order.','Transparent grouping preserves View grammar context; If/Match branches retain container bodies and returned-node modifiers. Sample applies its sheet at Panel scope and its RichText part explicitly; all6 bodies/IDs/Fx/numbers remain.')
 attempts=$attempts
 evidenceLimits=[ordered]@{owner6='Diagnostic iteration8PASS1FAIL only: AdditionalPaths was incorrectly given a JSON path, so its4031 frozen inputs excluded the two new Rust files. Retain actual result without treating it as full frozen acceptance. Owner7 and later cover4112 inputs including both new Rust files.';mainCheck='Actual CLI main-profile check exit0 at the earlier frozen RAG input. Later transparent-group/registry cleanup has owner and workspace evidence; this is not relabeled as a fresh CLI run.';rag='Actual1run0PASS1FAIL487skip2.318s. Compilation/indexing and multi-source graph assertions passed; persisted summary failed the existing kind-count assertion. The briefly inferred program-hash cause was wrong. AgentProjectGraphSummary currently carries totals without kind-count maps; preserve coverage while connecting those facts through the owning typed summary.'}
 quality=[ordered]@{check=Read-Record 'view-static-properties-quality1-20261105-check';clippy=Read-Record 'view-static-properties-quality1-20261105-clippy';structure=Read-Record 'view-static-properties-quality1-20261105-structure';warnings='Warnings remain; exit0 does not mean warning-free.'}
 mainProfile=Read-Record 'view-static-properties-main-check1-20261105';graph=$graph;ownership=$measurements
 correction=[ordered]@{reason='The e555 Syntax-only743PASS did not prove cross-layer diagnostic ownership. Owner2 ran971 cases:966PASS5FAIL, including four HIR E13 diagnostic/budget regressions and one separate Style failure. Remove the newly added Syntax diagnostic; keep existing HIR diagnostics, limits and fixtures unchanged. Owner5 subsequently passed all selected E13 and continuation cases; its separate two Style failures were then repaired.';scope='This reopens only the change-caused duplicate diagnostic boundary. Generic Match remains accepted/public; overall goal incompleteness is not evidence against completed features.'}
 workingTree='Published45 owned paths with original12 tracked patchSHA25646402a98f9f04b9dab8bed33913b6ea35f9e0467ccc46f4b9f04d7b025da39ac and6 untracked files preserved; empty index.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")) {
 if($line.StartsWith('| member chainの改行継続・不正memberの診断 |')) {
 '| member継続・静的View property・Style参照 | **実装・owner検証を公開済み。全consumer検証は継続** | Source '+$source.commit+'。Styleを共有宣言identityへ統合し、重複index producerを除去。geometry／part／Style modifierは式が返すnodeへ適用し、完全なcatalogを結合してから検査する。part名255UTF8 bytes／32segmentsの境界・alias／明示ID・子への誤適用拒否・If／Match・実runtime cascadeを含む12／12 PASS、179 skipped、0.565秒。workspace98の全target／feature／locked check・Clippy、構造gate終了0、4112 source／case／EXE drift0。実showcase main-profile check終了0（別の先行入力）。改行継続e555の追加Syntax診断はHIR E13の4失敗を根拠に'+$correction.commit+'で撤回し、既存HIR ownerを維持した。以前の743PASS／SHAは履歴へ保持。Cargo metadata／tree一致の逆依存44 packageを確定、実行は未完了。RAGの後段summary失敗はCLI行へ集約。[実測・訂正・公開SHA・raw](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 } elseif($line.StartsWith('| CLI全target照合 |')) { $line.Replace('RAG1件、','RAG1件（新inputはcompile／index成功後、保存summaryのkind別件数で失敗）、') }
 else {$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-05 — Static View properties, shared Style identity, diagnostic correction

- Published Source $($source.commit) (45paths) and diagnostic correction $($correction.commit). Style uses the shared retained header/symbol authority; explicit-ID-only declarations have no invented lexical name. Remove its duplicate semantic-index producer. Static properties consume checked facts, modify returned roots, preserve application order and compose the complete Style catalog before product admission. Transparent groups preserve View context. The maintained showcase retains all6 content records and presentation values.
- Final owner12/12PASS179skip0.565s; separate branch Syntax/compiler2/2PASS. Workspace98 all-target/all-feature/locked check/Clippy and structure gate exit0 with warnings; owned formatting exit0. The actual earlier main-profile CLI check exits0 with0warnings/0obligations. The resolved normal/build/dev, all-target/all-feature reverse graph is44packages with metadata/tree drift0; full consumer execution is still pending at this checkpoint.
- Correction of the previous insertion-diagnostic claim: adding a Syntax diagnostic duplicated existing HIR ownership. Owner2 actually ran971cases/966PASS5FAIL: four HIR E13 recovery/budget failures and one separate Style failure. Remove only the new Syntax diagnostic, retain HIR diagnostics/limits/fixtures, and confirm selected E13 cases pass in owner5. Original743PASS and e555 full SHA remain genuine historical results for their original input; they did not establish cross-layer correctness. Superseded current-state/residual lists were removed from the task JSON, with the pre-edit record in verified raw.
- Preserve every catalog/runtime attempt, including owner6's incomplete input freeze (4031inputs, excludes two new Rust files; diagnostic use only), owner7-and-later4112-input pins, the wrong constructor-scope expectation, duplicate Style producer, complete-catalog order, bad test use-declaration order and transparent-group failure. Do not turn a retry into an uninterrupted pass.
- RAG multi-source actually ran1case/0PASS1FAIL487skip2.318s. Source compilation/indexing and multi-source graph assertions now pass, but the persisted summary lacks the required kind-count data. The initial program-hash diagnosis was mistaken; connect the data through the typed project summary without deleting the assertions. No passing RAG run or full consumer/parity acceptance is claimed here. Existing Generic Match acceptance/publication and all unrelated accepted boundaries remain accepted.
- [Published identities, exact measurements, commands, failed/passed cases and verified raw](acceptance-evidence/task-rich-text-property-identity.json). [The only current-status list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys | Where-Object {$_ -ne 'viewNodeProperties'}) {if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Prior evidence changed: '+$key)}}
foreach($key in @('sampleCheckpoint','syntaxSource','runtime','command','quality','attempts','raw')){if(($before.viewNodeProperties[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after.viewNodeProperties[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Historical proof changed: '+$key)}}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'Historical prefix changed'}
[ordered]@{version=1;source=$source.commit;rawPath=$rawPath;rawEntries=$raw.entries.Count;rawBytes=$raw.bytes;rawSha256=$raw.sha256;historicalProofDrift=0;historyPrefixDrift=0;supersededEnumerationRemoved=$true} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'view-static-properties-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'view-static-properties-documentation-audit.json')
