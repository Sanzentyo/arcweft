$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='view-static-properties-main-check1-20261105'
$freeze=Get-Content -LiteralPath (Join-Path $e 'view-static-properties-cli-rag1-20261105.source-freeze.json') -Raw | ConvertFrom-Json
function Assert-Inputs { foreach($row in $freeze.paths) {if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}} }
if(Test-Path -LiteralPath (Join-Path $e ($stem+'.json'))){throw 'Preserve existing receipt'}
& (Join-Path $e 'assert-no-arcweft-build.ps1')
Assert-Inputs
$exe='D:/git/arcweft/target/debug/arcw.exe'
$hash=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
$started=[DateTime]::UtcNow.ToString('o')
$arguments=@('check','--manifest-path','samples/rich-text-showcase/arcw.toml','--profile','main')
& $exe @arguments 1> (Join-Path $e ($stem+'.stdout.log')) 2> (Join-Path $e ($stem+'.stderr.log'))
$code=$LASTEXITCODE
Assert-Inputs
if((Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant() -ne $hash){throw 'Executable drift'}
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=@($exe)+$arguments;exitCode=$code;binarySha256=$hash;sourceInputs=$freeze.paths.Count;sourceDrift=0;binaryDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $e ($stem+'.json')) -Encoding utf8
Get-Content -LiteralPath (Join-Path $e ($stem+'.json'))
Get-Content -LiteralPath (Join-Path $e ($stem+'.stdout.log')) -TotalCount 10
Get-Content -LiteralPath (Join-Path $e ($stem+'.stderr.log')) -TotalCount 10
exit $code
