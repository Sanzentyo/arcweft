$ErrorActionPreference='Stop'
$taskTemp=$PSScriptRoot
$prefix='awbc-flow-transfer-custody-20261107'
function Read-FailureDiagnostics([string]$path){
 $raw=Get-Content -LiteralPath $path -Raw
 $pattern='(?ms)^\s*FAIL\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+(?<binary>\S+)\s+(?<test>[^\r\n]+)\r?\n(?<details>.*?)(?=^\s*(?:PASS|FAIL|SLOW|SKIP)\s+\[|\z)'
 $rows=@{}
 foreach($match in [regex]::Matches($raw,$pattern)){
  $name=$match.Groups['test'].Value.Trim()
  $details=$match.Groups['details'].Value
  $messages=@($details -split '\r?\n'|Where-Object {$_ -match '^\s*"message":' -or $_ -match '^\s*authored Scroll live observe should succeed, stderr:' -or $_ -match 'active dialogue has no voice'}|ForEach-Object {$_.Trim()}|Sort-Object -Unique)
  if(!$messages.Count){if($rows.ContainsKey($name)){continue};throw "No actual diagnostic extracted for $name"}
  $rows[$name]=[pscustomobject]@{binary=$match.Groups['binary'].Value;messages=$messages}
 }
 return $rows
}
$old=Read-FailureDiagnostics "$taskTemp/awbc-goto-unwind-hardening-20261107.reverse.log"
$current=Read-FailureDiagnostics "$taskTemp/$prefix.reverse.log"
if($old.Count -ne 4 -or $current.Count -ne 4 -or @(Compare-Object @($old.Keys|Sort-Object) @($current.Keys|Sort-Object)).Count){throw 'Failure identity changed'}
$rows=@(foreach($name in ($old.Keys|Sort-Object)){
 if(@(Compare-Object @($old[$name].messages) @($current[$name].messages)).Count){throw "Failure diagnostics changed: $name"}
 [ordered]@{test=$name;binary=$current[$name].binary;baselineDiagnostics=$old[$name].messages;currentDiagnostics=$current[$name].messages;equal=$true}
})
[ordered]@{version=1;baselineSource='82f4a37865361752d01a20a189e37dda7f716123';currentSource='b6df0c825805b9ac77cad6a9760761a861007679';failureKeys=4;rows=$rows}|ConvertTo-Json -Depth 7|Set-Content "$taskTemp/$prefix.cli-failure-comparison.json" -Encoding utf8
Write-Output 'All four failure keys and extracted diagnostic messages match the prior frozen run'
