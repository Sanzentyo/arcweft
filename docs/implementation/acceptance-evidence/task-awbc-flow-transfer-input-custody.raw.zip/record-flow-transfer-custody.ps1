$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-flow-transfer-custody-20261107'
$source=Get-Content "$taskTemp/$prefix.source.verified.json" -Raw|ConvertFrom-Json
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
$matrix=Get-Content "$taskTemp/$prefix.reverse.receipt.json" -Raw|ConvertFrom-Json
if((&git rev-parse HEAD).Trim() -ne $source.commit -or $matrix.sourceBase -ne $source.parent -or $matrix.listExitCode -ne 0 -or $matrix.sourceDrift -ne 0){throw 'Source or matrix identity mismatch'}
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Frozen source changed'}
$quality=[ordered]@{}
foreach($name in @('owner-fixed-type','compiler-owner','fmt','workspace-check','workspace-clippy','structure','doctest')){
 $r=Get-Content "$taskTemp/$prefix.$name.receipt.json" -Raw|ConvertFrom-Json
 if($r.exitCode -ne 0){throw "Unfinished quality: $name"}
 $quality[$name]=$r
}
$selected=Get-Content "$taskTemp/$prefix.reverse.selection.json" -Raw|ConvertFrom-Json
$log=[IO.File]::ReadAllText("$taskTemp/$prefix.reverse.log")
$failed=@([regex]::Matches($log,'(?m)^\s*FAIL\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+([^\r\n]+)')|ForEach-Object {[pscustomobject]@{binary=$_.Groups[1].Value;test=$_.Groups[2].Value}}|Sort-Object test -Unique)
$expected=@('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering','spec_valid_run_edge_fixture_now_executes','verify_json_records_required_solver_checks','verify_json_reports_missing_promotion_proof')
if(@(Compare-Object @($failed.test|Sort-Object) @($expected|Sort-Object)).Count){throw 'New reverse failures require investigation'}
if(($matrix.summary -join "`n") -notmatch '(\d+) tests run: (\d+) passed.*?(\d+) failed.*?(\d+) skipped'){throw 'Unknown matrix summary'}
$counts=[ordered]@{run=[int]$Matches[1];passed=[int]$Matches[2];failed=[int]$Matches[3];skipped=[int]$Matches[4]}
if($counts.run -ne $selected.Count -or $counts.failed -ne $failed.Count){throw 'Matrix count mismatch'}
foreach($name in @('pending_flow_transfer_line_handle_has_one_real_slot_in_live_and_saved_storage','pending_flow_transfer_preserves_its_shared_copy_proof_work_failure')){
 if($log -notmatch ('(?m)^\s*PASS\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+\S+\s+[^\r\n]*'+[regex]::Escape($name)+'\s*$')){throw "Missing broad regression: $name"}
}
$untracked=Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json
if(@($untracked.files|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Original untracked WIP changed'}
$names=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*"|ForEach-Object {$_.Name})
$names+=@('run-flow-transfer-custody-validation.ps1','retry-flow-transfer-custody-matrix.ps1','run-flow-transfer-custody-doctest.ps1','compare-flow-transfer-custody-cli-failures.ps1','record-flow-transfer-custody.ps1','function-scope-20261107.metadata-all.json')
$names=@($names|Sort-Object -Unique)
$zipPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-awbc-flow-transfer-input-custody.raw.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Archive already exists'}
Compress-Archive -LiteralPath @($names|ForEach-Object {"$taskTemp/$_"}) -DestinationPath $zipPath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{foreach($entry in $archive.Entries){$row=$entries|Where-Object entry -eq $entry.FullName;$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($row.bytes -ne $entry.Length -or $row.sha256 -ne $hash){throw 'Archive content mismatch'}};if($archive.Entries.Count -ne $entries.Count){throw 'Archive entry count mismatch'}}finally{$archive.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-07';source=$source
 scope='Pending Flow input custody and shared Copy-proof resource failure; preserve the already accepted bounded goto/Choice behavior.'
 reproduction=(Get-Content "$taskTemp/$prefix.repro-fixed-harness.receipt.json" -Raw|ConvertFrom-Json)
 corrections=@('Two actual regressions reproduce on the preceding published source: the pending destination is absent from the Line-handle slot graph, and a shared work refusal is replaced by a deep-Copy message. Both fail before the fix and pass afterwards.';'The first new test build used unwrap on a non-fallible site-ID constructor (E0599); the first fix build named a private save-result alias (E0603). These are development build errors, not runtime failures; both attempts remain in raw evidence.';'Use the same retained real-frame inventory for live and inert physical ownership. Preserve the enclosing work bank first failure in the ABI admission helper, rather than reconstructing an error downstream.';'The two old public frame-replacement methods have zero repository consumers after the prior migration and are deleted. No released or persisted compatibility contract is known; the active transfer authority remains the prepared real destination and exit state.';'The Cue lease is issued by the real ledger and moves from its original register to the actual destination register. The case checks live, public JSON save, restored storage, duplicate-owner rejection and an explicit ledger transfer. This validates pending-input custody, not all Line-affine defer capture behavior.')
 quality=$quality
 reverse=[ordered]@{initialBuild=(Get-Content "$taskTemp/$prefix.reverse.list.receipt.json" -Raw|ConvertFrom-Json);successfulBuild=(Get-Content "$taskTemp/$prefix.reverse.retry1.list.receipt.json" -Raw|ConvertFrom-Json);receipt=$matrix;diagnosticComparison=(Get-Content "$taskTemp/$prefix.cli-failure-comparison.json" -Raw|ConvertFrom-Json);counts=$counts;resolvedPackages=53;actualTestPackages=@($selected.package|Sort-Object -Unique).Count;cliRun=@($selected|Where-Object package -eq 'arcweft-cli').Count;failures=$failed}
 limits='Four existing CLI failures remain. Earlier 7960-case source evidence, owner 8, compiler owner 30 and doc 80 are separate runs and must not be added to this matrix. Preserve Native, Line/init and Generic Match acceptance. The broader pending conditions remain in the sole current-status table.'
 raw=[ordered]@{path='task-awbc-flow-transfer-input-custody.raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$entries}
}
$jsonPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($jsonPath)
if($before.Contains('"flowTransferInputCustody"')){throw 'Duplicate evidence section'}
$fragment=([ordered]@{flowTransferInputCustody=$record}|ConvertTo-Json -Depth 80).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($jsonPath,$after,[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-07 — 移譲待ち引数の Line 所有と共有 work 拒否

Source **$($source.commit)** を既存 main に通常 commit/push。元 12 tracked / 6 untracked WIP を保持し、全差分・tree・blob・親 SHA を照合した。移譲先の実フレームを live / inert 共通の物理スロット収集へ含め、Line handle の消失と二重所有を防ぐ。共有 Copy 検証の work 枯渇は、Copy 不可の別メッセージにせず元の Resource 拒否として保持する。利用箇所がゼロになった旧フレーム置換 API 2 本を削除し、移譲 authority を一本化した。
変更前の2回帰は、所有者が空 map となるケースと work 拒否が Message となるケースで FAIL。修復後の affected 8 件と Source/保存付き AWBC の既存 30 件は PASS。実 ledger が発行した Cue を、元 register から移譲先 register へ一度だけ移し、公開 JSON 保存・復元で同じ所有者を確認する。改変した二重所有は拒否し、正しい ledger transfer は元 token を保持する。初回 E0599 と修正時の E0603 はテスト実行前の開発 build エラーとして原本に保持する。
Core 全53逆依存は $($counts.run)件中 $($counts.passed) PASS / $($counts.failed) FAIL / $($counts.skipped) SKIP。新規失敗はなく、残る4件は既知の CLI。修正前 Source82f の全4失敗キーと、実際に出力された診断行の一致も照合した。全 target / 全 feature check・Clippy、7 path fmt、構造 gate、Core doc テストは終了0。実行入力 $($freeze.paths.Count)件と Cargo100入力は drift0。前 cut の7960件を後続の件数に書き換えず、ownerとの合算もしない。初回 list は arcweft_bundle の rlib が見つからず、Compiler dialogue_profile_admission のテスト前 build が終了101。同じ固定入力・同じコマンドの cached retry で build を再試行し、追加 clean／artifact 操作はしていない。両 build の原本を保持する。
現状一覧はこの cut と同じ入力の終端結果へ更新した。Line affine の検証済み範囲は移譲待ち引数の物理スロット所有であり、defer捕捉全体を受入済みとはしない。既受入の Native / Line-init / Generic Match は維持する。[全実測・訂正・SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIP は $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::AppendAllText('D:/git/arcweft/docs/implementation/convergence-evidence-history.md',$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$lines=[IO.File]::ReadAllLines($statusPath)
$updated=foreach($line in $lines){
 if($line.StartsWith('| 通常 Flow の scoped defer |')){$line.Replace('82f4a37865361752d01a20a189e37dda7f716123',$source.commit).Replace('改変保存の拒否と共通 quota を確認。','改変保存の拒否と共通 quota を確認。移譲待ち引数の Line handle も実フレームの一つのスロットで保持し、保存復元・重複拒否と共有 work エラーを検証した。')}
 elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){'| 共有契約／推移的逆依存matrix | **Core逆依存53パッケージ：'+$counts.passed+' PASS／'+$counts.failed+' FAIL／'+$counts.skipped+' SKIP** | Source `'+$source.commit+'` と同一の固定入力を Windows の workspace 既定 feature・lib／integration で実行。'+$counts.run+'件、実テスト package '+@($selected.package|Sort-Object -Unique).Count+'。非 CLI の失敗0件。owner 8件／Compiler 30件や前 cut の7960件と合算せず、古い件数と修復も履歴に保持する。[全選択・入力・結果・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 elseif($line.StartsWith('| CLIの規定対象／全 check 照合 |')){$line.Replace('82f4a37865361752d01a20a189e37dda7f716123',$source.commit)}
 elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){$line.Replace('82f4a37865361752d01a20a189e37dda7f716123',$source.commit).Replace('fmt は両 Source cut の18 Rust path','fmt は当該 cut の7 Rust path')}
 else{$line}
}
[IO.File]::WriteAllText($statusPath,($updated -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;counts=$counts;entries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json -Depth 5
