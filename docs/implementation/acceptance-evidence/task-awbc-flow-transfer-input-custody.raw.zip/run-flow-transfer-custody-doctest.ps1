$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-flow-transfer-custody-20261107'
$listReceipt="$taskTemp/$prefix.reverse.retry1.list.receipt.json"
while(!(Test-Path -LiteralPath $listReceipt)){Start-Sleep -Seconds 5}
Start-Sleep -Seconds 1
$list=Get-Content -LiteralPath $listReceipt -Raw|ConvertFrom-Json
if($list.exitCode -ne 0){throw 'No successful reverse build; doctest has not run'}
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Frozen input changed before doctest'}
$source=(&git rev-parse HEAD).Trim()
$arguments=@('test','--locked','-p','arcweft-core','--doc')
$started=[DateTime]::UtcNow
& cargo @arguments *> "$taskTemp/$prefix.doctest.log"
$code=$LASTEXITCODE
$drift=@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
$summary=@(Select-String -LiteralPath "$taskTemp/$prefix.doctest.log" -Pattern '^test result:'|ForEach-Object {$_.Line})
[ordered]@{version=1;source=$source;arguments=$arguments;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o');exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=$drift;summary=$summary}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.doctest.receipt.json" -Encoding utf8
$summary|Write-Output
if($drift){throw 'Source changed during doctest'}
exit $code
