$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$quality=[IO.File]::ReadAllText("$taskTemp/product-execution-quality.active.txt")
$reverse='presentation-dialogue-handoff-reverse-20261101'
$extra='presentation-dialogue-handoff-full-cli-20261101'
$normal=Get-Content "$taskTemp/$reverse.matrix.json" -Raw|ConvertFrom-Json -Depth 45
$full=Get-Content "$taskTemp/$extra.matrix.json" -Raw|ConvertFrom-Json -Depth 45
if($normal.status -ne 'terminal' -or $normal.rows.Count -ne 3 -or $full.status -ne 'terminal' -or $full.rows.Count -ne 1){throw 'Required runtime groups are not terminal'}
foreach($group in @($normal.rows)+@($full.rows)){if($group.catalogExit -ne 0 -or $group.runtimeExit -notin @(0,100) -or $null -eq $group.terminal){throw 'Unexecuted or unaudited runtime group'}}
$freeze=Get-Content "$taskTemp/$reverse.source-freeze.json" -Raw|ConvertFrom-Json -Depth 35
$hashes=@{};foreach($row in $freeze.paths){$hashes[$row.path]=$row.sha256;if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Current source drift'}}
foreach($name in @($quality,$extra)){$other=Get-Content "$taskTemp/$name.source-freeze.json" -Raw|ConvertFrom-Json -Depth 35;if($other.paths.Count -ne $freeze.paths.Count){throw 'Input inventory differs'};foreach($row in $other.paths){if($hashes[$row.path] -ne $row.sha256){throw 'Input epoch differs'}}}
$gates=@(foreach($suffix in @('workspace-check','clippy','default-check','doctest','structure','fmt','wasm-check2')){$gate=Get-Content "$taskTemp/$quality.$suffix.json" -Raw|ConvertFrom-Json -Depth 25;if($gate.exitCode -ne 0 -or $gate.sourceDrift -ne 0){throw 'Quality gate did not pass'};[ordered]@{name=$suffix;result=$gate}})
& "$taskTemp/audit-dialogue-handoff-generic-coverage.ps1"
& "$taskTemp/audit-dialogue-handoff-cli-failures.ps1"
$generic=Get-Content "$taskTemp/$reverse.generic-coverage.json" -Raw|ConvertFrom-Json -Depth 25
$comparison=Get-Content "$taskTemp/$extra.cli-comparison.json" -Raw|ConvertFrom-Json -Depth 25
$ownership=Get-Content "$taskTemp/presentation-dialogue-handoff-quality-ownership.json" -Raw|ConvertFrom-Json -Depth 25
$repair=Get-Content 'docs/implementation/acceptance-evidence/task-presentation-dialogue-handoff-repair-raw.json' -Raw|ConvertFrom-Json -Depth 45
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {($_.Name.StartsWith($quality+'.') -or $_.Name.StartsWith($reverse+'.') -or $_.Name.StartsWith($extra+'.')) -and $_.Extension -in @('.log','.json','.txt')})
$files+=@(Get-ChildItem -LiteralPath "$taskTemp/$quality.structure-report" -File)
$files+=@(foreach($name in @('run-presentation-scope-workspace-quality.ps1','run-presentation-frame-wasm-check2.ps1',"run-$reverse.ps1","run-$extra.ps1",'audit-dialogue-handoff-generic-coverage.ps1','audit-dialogue-handoff-cli-failures.ps1','archive-dialogue-handoff-validation.ps1','audit-nextest-final-result.ps1','presentation-dialogue-handoff-quality-ownership.json')){Get-Item -LiteralPath "$taskTemp/$name"})
$files=@($files|Sort-Object FullName -Unique)
$out='D:/git/arcweft/docs/implementation/acceptance-evidence'
$zip="$out/task-presentation-dialogue-handoff-validation-raw.zip"
$record="$out/task-presentation-dialogue-handoff-validation.json"
if((Test-Path -LiteralPath $zip) -or (Test-Path -LiteralPath $record)){throw 'Validation archive already exists'}
$archive=[IO.Compression.ZipFile]::Open($zip,[IO.Compression.ZipArchiveMode]::Create)
try{$rows=@(foreach($file in $files){
    $entry=$file.FullName.Substring(([IO.Path]::GetFullPath($taskTemp)).Length+1).Replace('\','/')
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entry,[IO.Compression.CompressionLevel]::Optimal)
    [ordered]@{entry=$entry;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
})}finally{$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($zip)
try{if($archive.Entries.Count -ne $rows.Count){throw 'Raw inventory differs'};foreach($row in $rows){$entry=$archive.GetEntry($row.entry);if($null -eq $entry -or $entry.Length -ne $row.bytes){throw 'Raw entry differs'};$stream=$entry.Open();try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($sha -ne $row.sha256){throw 'Raw archive byte drift'}}}finally{$archive.Dispose()}
[long]$bytes=0;foreach($row in $rows){$bytes += $row.bytes}
$groups=@($normal.rows)+@($full.rows)
[ordered]@{
    version=1;date='2026-11-01';recordedAt=[DateTime]::UtcNow.ToString('o');source='390304bc5308b8a2cb4eb2672a8f51e8fe59fa1e';sourceParent='97092efcc46bb1ee53c93b39400941d992328464';inspectedMain=(git rev-parse HEAD).Trim();sourceInputs=$freeze.paths.Count;sourceDrift=0;
    scope='Actual 53-package Core reverse closure over the repository normal test-workspace library, CLI unit/bin and six CLI integration surfaces, plus a separate extended nonignored CLI check run. Distinct feature unions and commands remain separate groups. This is not final acceptance of the overall goal or of unexecuted platform/driver boundaries.';
    normalMatrix=$normal;extendedCli=$full;quality=$gates;ownership=$ownership;genericCoverage=$generic;cliComparison=$comparison;
    historicalRepair=[ordered]@{manifest='task-presentation-dialogue-handoff-repair-raw.json';archive=$repair.archive;initialFailedReverse='task-presentation-dialogue-receipt-reverse-validation.json';rootConsumerPublication='97092efcc46bb1ee53c93b39400941d992328464';meaning='Old failures, diagnostic source, initial compiler regressions, owner11 2217/1 and the final focus17 fixture repair remain separate historical runs. The current matrix is a new execution and is not their sum.'};
    raw=[ordered]@{path=[IO.Path]::GetFileName($zip);bytes=(Get-Item -LiteralPath $zip).Length;uncompressedBytes=$bytes;sha256=(Get-FileHash -LiteralPath $zip).Hash.ToLowerInvariant();entries=$rows.Count;entryByteDrift=0;files=$rows};
    allRequiredGroupsTerminal=$true;isCompleteNormalReverseRuntime=$true;isExtendedCliCheckTerminal=$true;isPassingCombinedRuntime=(@($groups|Where-Object {$_.terminal.failed -ne 0}).Count -eq 0);currentStatusAuthority='../current-status.md'
}|ConvertTo-Json -Depth 55|Set-Content -LiteralPath $record -Encoding utf8
[ordered]@{source='390304bc5308b8a2cb4eb2672a8f51e8fe59fa1e';runtimeGroups=$groups.Count;genericPassed=$generic.passed;cliFailures=$comparison.currentFailureCount;newCliFailureIds=$comparison.newFailureIds.Count;rawEntries=$rows.Count;rawBytes=(Get-Item -LiteralPath $zip).Length;rawByteDrift=0}|ConvertTo-Json -Compress
