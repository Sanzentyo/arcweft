$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:\git\arcweft'
$publication=Get-Content -Raw "$root/original-context-retention-fixed.publication.json" | ConvertFrom-Json
& pwsh -NoProfile -File "$root/run-original-context-retention-fixed-validation.ps1"
$validationExit=$LASTEXITCODE
$validation=Get-Content -Raw "$root/original-context-retention-fixed.validation.json" | ConvertFrom-Json
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Steps=@($validation.Steps | Where-Object Name -notin @('owner-list','owner-run'))} | ConvertTo-Json -Depth 9 | Set-Content -Encoding utf8 "$root/original-context-retention-fixed.quality.json"
& pwsh -NoProfile -File "$root/audit-original-context-retention-fixed.ps1"
if ($LASTEXITCODE -ne 0) { throw 'Owner audit failed; do not start dependent consumer validation' }
& pwsh -NoProfile -File "$root/original-context-retention-fixed-reverse/run.ps1" -SourceCommit $publication.Source -SourceTree $publication.Tree
$groupedExit=$LASTEXITCODE
& pwsh -NoProfile -File "$root/original-context-retention-fixed-compiler/run.ps1" -SourceCommit $publication.Source -SourceTree $publication.Tree
$compilerExit=$LASTEXITCODE
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;ValidationDriverExit=$validationExit;GroupedExit=$groupedExit;CompilerExit=$compilerExit;Finished=(Get-Date -Format o)} | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$root/original-context-retention-fixed.consumer-driver.json"
& pwsh -NoProfile -File "$root/audit-original-context-retention-fixed-consumers.ps1"
if ($LASTEXITCODE -ne 0) { throw 'Consumer audit failed' }
if ($groupedExit -ne 0 -or $compilerExit -ne 100) { throw 'Unexpected consumer exit codes' }
Write-Output 'Validation terminal: owner known 6 failures; consumers known 2 failures; audits complete.'
exit 100
