$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$source=Read-Record 'checkpoint-callable-result-join-20261106.verified'
$owner=Read-Record 'callable-result-join-owner2-20261106.runtime.terminal-audit'
$branches=Read-Record 'callable-result-join-branches1-20261106.runtime.terminal-audit'
$cli=Read-Record 'callable-result-join-cli2-20261106.runtime.terminal-audit'
$quality=[ordered]@{check=Read-Record 'callable-result-join-quality2-20261106-check';clippy=Read-Record 'callable-result-join-quality2-20261106-clippy';structure=Read-Record 'callable-result-join-quality2-20261106-structure'}
if((git rev-parse HEAD).Trim() -ne $source.commit -or $owner.passed -ne 19 -or $owner.failed -or $branches.passed -ne 1 -or $branches.failed -or $cli.passed -ne 1 -or $cli.failed -or $quality.check.exitCode -or $quality.clippy.exitCode -or $quality.structure.exitCode){throw 'Unexpected published input or owner result'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$historyPath='docs/implementation/convergence-evidence-history.md'
$statusPath='docs/implementation/current-status.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('callableResultJoinOwner')){throw 'Preserve existing owner proof'}
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 ($_.Name -match '^callable-result-join[-.]' -and -not $_.Name.StartsWith('callable-result-join-reverse22-')) -or $_.Name.StartsWith('checkpoint-callable-result-join-20261106.')
} | Where-Object Extension -in @('.json','.log','.arcw','.patch','.pathspec','.txt'))
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'callable-result-join-quality2-20261106.structure-report') -File)
$files+=@(Get-Item -LiteralPath (Join-Path $t 'record-callable-result-join-owner.ps1'),(Join-Path $t 'run-presentation-projection-owner.ps1'),(Join-Path $t 'run-action-payload-quality.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'),(Join-Path $t 'rag-project-summary-graph.ps1'),(Join-Path $t 'rag-project-summary.metadata.json'),(Join-Path $t 'rag-project-summary.metadata.log'),(Join-Path $t 'rag-project-summary-arcweft-lang-sema.tree.txt'),(Join-Path $t 'rag-project-summary-arcweft-lang-sema.tree.log'))
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-callable-result-join-owner.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$record.callableResultJoinOwner=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source;scope='Published typed diagnostic owner checkpoint. Current status is maintained only in current-status.md; the complete22-package reverse run is ongoing.'
 owner=$owner;branches=$branches;cli=$cli;quality=$quality;fmt=Read-Record 'callable-result-join-fmt';graph=Read-Record 'callable-result-join.graph';ownership=Read-Record 'callable-result-join-owner-measurements'
 implementation=@('Keep an incompatible callable result join as AnalyzerExpressionRejection::ResultJoin, not Fatal, carrying only original typed source spans. Project it once into FinalSemanticAnalysisError::IncompatibleCallableResults and sema.callable.result_type. The existing completion authority selects the reachable returns and normal continuation; nested callable returns stay separate. No value/source reconstruction, type-graph cloning or alternative result resolver is introduced.','Branch synthesis rolls candidate facts back. If a type hint is available, retain the original contextual final check; if every branch lacks a hint, preserve the first concrete result-join rejection instead of replacing it with generic unavailable. If, IfLet and Match share this owner.','The CLI fixture formerly used two sequential out statements in a dialogue child, which do not denote Thread returns under the adopted contract. Replace the fixture with actual child return branches and an outer-If variant. Require denied/type-check, exact code/message/two original value spans, a primary span and no accepted verifier obligations. Do not weaken the assertion to any denial.')
 coverage='Owner2:19PASS1354skip0.590s. Later branch case:1PASS1372skip0.167s, one Rust test with five Source inputs (nested Thread, closure, If, IfLet, Match). Normal Unit completion is a separate test in owner2. CLI2:1PASS487skip1.760s, one Rust test with two Source inputs. Do not report five/two Source inputs as five/two Rust tests or fabricate one combined run.'
 earlierAttempts=[ordered]@{owner1=Read-Record 'callable-result-join-owner1-20261106.runtime.terminal-audit';cli1=Read-Record 'callable-result-join-cli1-20261106.runtime.terminal-audit';quality1check=Read-Record 'callable-result-join-quality1-20261106-check';quality1clippy=Read-Record 'callable-result-join-quality1-20261106-clippy';quality1structure=Read-Record 'callable-result-join-quality1-20261106-structure';bothBranchesProbe=Read-Record 'callable-result-join-both-branches-probe.receipt';reason='Direct owner/CLI inputs passed, but a separate two-failed-branch probe still returned generic sema.final_analysis with no source span. Preserve that observation and initial input; the final deferred-rejection change and additional Source cases address it. Earlier quality passes are not relabeled as final-code passes.'}
 validationScope='Final workspace98 all-target/all-feature/locked check/Clippy and structure gate exit0, warnings remain. Source4113/case/EXE drift0 in the recorded runs. The complete22 reverse run, dedicated doctest/wasm, Tier2 and final Native-Web parity are not established by this checkpoint. Diagnostic-only sema/CLI work adds no runtime scheduling, device, capture or protocol path requiring a new Tier2 family.'
 correctionReason='The Thread-result CLI owner condition now has passing exact diagnostic evidence and is removed from the current residual list. Keep the earlier actual full55 CLI700/688PASS12FAIL and9579/26FAIL unchanged. Eleven other old CLI IDs remain current conditions; do not invent a700/11FAIL result before the new full run. Generic Match remains accepted/public.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| CLI全target照合 |')){
 '| CLI全target照合 | **Thread戻り値診断をowner修復・公開済み。旧全700実測は688 PASS／12 FAILのまま保持** | Source '+$source.commit+'。子Threadの実returnと外側Ifの2入力を、CLI JSONのdenied／type-check／専用code／元の値位置2件／accepted verifier generationを作らないことで検証し、1 Rust testがPASS。Source56b565f900fb59d0cb9521b89d0348dca0e5a630の全CLI700は688 PASS／12 FAILの実測として保持し、700／11 FAILへ再計算しない。残る11 IDはfull-grammar現在line選択3件、Scroll解決1件、旧plan／unsafe fixture2件、run-edge1件、負例診断1件、verifier fixture3件。RAGとz-indexの修復済み状態を維持する。[旧全run・修復理由・新owner原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){
 '| 共有契約／推移的逆依存matrix | **戻り値診断の全22 packageを検証中。以前の全runと修復は履歴として保持** | Source '+$source.commit+'。元の実Cargo metadataとSema invert treeは22 packageで一致し、101 Cargo／toolchain入力のhashが不変なためgraphを再利用、drift0。全consumerの終端件数はまだ主張しない。以前の静的View／Agent summary全55（Source56b565f900fb59d0cb9521b89d0348dca0e5a630）は9579実行9553 PASS／26 FAIL／48 skipped、1260.752秒の実測。追加14条件は後続Sourceb505d4f45f7958fa5b0b898784a8327a23db3749で対象15 PASSと他のhost呼出側5 PASSを別runで確認した。旧件数へ修復を合算しない。[graph・終端・各入力と原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 '| workspace check／Clippy・fmt・構造gate | **戻り値診断Sourceの全98 check／Clippy・構造gateは終了0。警告は残る** | Source '+$source.commit+'の4113入力で、最終コードの全98 all-target／all-feature／locked check・Clippyと構造gateが終了0。変更Rustをedition2024でformatし、候補rollback・文脈再検査・元source spanを保持するownerを検証。前段のquality成功を最終コードへ付け替えず、各epochを記録した。既存12 tracked／6 untrackedを保持。専用doctest／wasm・Tier2・最終Native-Web parityは別境界。[所有測定・入力・全実測](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{
 $line
 if($line.StartsWith('| Threadのインデント形式／元source保持 |')){
 '| Callableの戻り値合流診断／元Source | **当該型付き診断は実装・owner検証・公開済み** | Source '+$source.commit+'。Thread／closureの到達可能returnと通常完了が合流できない場合、sema.callable.result_typeに元のbody・値位置を保持する。候補不適合をFatalへ変えず、If／IfLet／Matchのprobeをrollbackし、文脈型を得られない場合も具体的な理由を失わない。対象19 PASS、別の5入力case1 PASS、CLIの2入力case1 PASS。入れ子の子return分離、Unit完了とaccepted verifier generationの非公開を検証した。全22 consumerは下表で継続し、既存Thread実行・保存の受入を変更しない。[現行契約](../01-language/control-transfer-return-out-yield.md)、[各実測・初期probe・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }
 }
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-06 — Source-backed callable result-join diagnostics

- Source $($source.commit) publishes7paths. Incompatible inferred returns/normal completion retain a typed candidate rejection and the original source spans, projected once as sema.callable.result_type. Reuse the existing completion owner; exclude nested child returns. Candidate facts still roll back and contextual final checks remain mandatory. When If/IfLet/Match probes yield no type hint, retain the first concrete join rejection rather than generic unavailable.
- Owner2: $($owner.summary). The later branch case ($($branches.summary)) covers five Source inputs, not five Rust tests. CLI2 ($($cli.summary)) covers two Source inputs, exact denied/type-check/code/value spans and no accepted verifier generation. Replace sequential line out with real Thread return branches under the adopted contract. Normal Unit completion and existing positive return/control cases remain checked. The separate both-failed-branches probe still had generic/no-span output in the first input; retain that actual observation and all earlier successful-but-narrower inputs.
- Final workspace98 all-target/all-feature/locked check/Clippy and structure exit0, warnings remain;4113Source/case/EXE drift0. The unchanged101Cargo/toolchain inputs permit reuse of actual metadata/Sema invert tree for the complete22-package closure. Its run remains ongoing; no terminal consumer or final platform/parity result is claimed. Original12tracked/6untracked remain, with the original held patch hash unchanged.
- Supersedes only the outstanding Thread-result CLI owner condition. Preserve actual full55 CLI700/688PASS12FAIL and9579/26FAIL; do not reconstruct a700/11FAIL run. The other11CLI conditions stay in the single current list. Generic Match and other accepted/public boundaries remain accepted. [Exact epochs, probe, Source SHA, ownership, graph and verified raw](acceptance-evidence/task-rich-text-property-identity.json); [only current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw ('Prior evidence changed: '+$key)}}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{version=1;source=$source.commit;rawPath=$rawPath;rawBytes=$raw.bytes;rawSha256=$raw.sha256;rawEntries=$raw.entries.Count;priorEvidenceDrift=0;historyPrefixDrift=0;live22TerminalClaim=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'callable-result-join-owner-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'callable-result-join-owner-documentation-audit.json')
