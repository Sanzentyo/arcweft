$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$freeze=Get-Content -LiteralPath "$taskTemp/rag-project-summary-source2-20261106.source-freeze.json" -Raw|ConvertFrom-Json
function Assert-Inputs {
    foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
}
Assert-Inputs
$base=(git rev-parse HEAD).Trim()
$roots=@('arcweft-lang-syntax','arcweft-lang-hir','arcweft-lang-sema','arcweft-compiler','arcweft-view','arcweft-bundle','arcweft-core','arcweft-agent-protocol','arcweft-agent-runner','arcweft-cli')
& cargo metadata --format-version 1 --all-features --locked 1> "$taskTemp/rag-project-summary.metadata.json" 2> "$taskTemp/rag-project-summary.metadata.log"
if($LASTEXITCODE){throw 'metadata failed'}
$metadata=Get-Content -LiteralPath "$taskTemp/rag-project-summary.metadata.json" -Raw|ConvertFrom-Json -Depth 100
$workspace=@($metadata.packages|Where-Object id -in $metadata.workspace_members)
$selected=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($p in $workspace){if($p.name -in $roots){[void]$selected.Add($p.id)}}
do {
    $changed=$false
    foreach($node in $metadata.resolve.nodes){
        if($selected.Contains($node.id)){continue}
        foreach($dependency in $node.deps){if($selected.Contains($dependency.pkg)){[void]$selected.Add($node.id);$changed=$true;break}}
    }
} while($changed)
$packages=@($workspace|Where-Object {$selected.Contains($_.id)}|Sort-Object name)
$treeSet=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($root in $roots){
    & cargo tree --invert $root --workspace --all-features --target all --edges normal,build,dev --prefix none --format '{p}' --locked 1> "$taskTemp/rag-project-summary-$root.tree.txt" 2> "$taskTemp/rag-project-summary-$root.tree.log"
    if($LASTEXITCODE){throw "tree failed: $root"}
    foreach($line in [IO.File]::ReadLines("$taskTemp/rag-project-summary-$root.tree.txt")){
        if($line -match '^(\S+) v' -and $Matches[1] -in $workspace.name){[void]$treeSet.Add($Matches[1])}
    }
}
if(@(Compare-Object @($packages.name) @($treeSet|Sort-Object)).Count){throw 'metadata/tree closure differs'}
$graph=[ordered]@{version=1;base=$base;roots=$roots;workspacePackages=$workspace.Count;selection=@($packages.name);selectedPackages=$packages.Count;target='all';features='all';dependencyKinds=@('normal','build','dev');metadataTreeDrift=0;runtimeAcceptance='Pending. Component owner runs are not the complete reverse closure.'}
$graph|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/rag-project-summary.graph.json" -Encoding utf8
Assert-Inputs
$graph | ConvertTo-Json -Depth 8
