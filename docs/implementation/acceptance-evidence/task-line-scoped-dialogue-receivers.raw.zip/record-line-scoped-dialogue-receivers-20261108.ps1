$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='line-scoped-dialogue-20261108'
$source=(Get-Content "$taskTemp/$stem.source.verified.json" -Raw|ConvertFrom-Json).commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Unexpected published source'}
foreach($gate in @('check','clippy','structure','fmt')){
 $receipt=Get-Content "$taskTemp/$stem.workspace-quality-r1.$gate.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw "Gate unavailable: $gate"}
}
$terminal=Get-Content "$taskTemp/$stem.owners-r3.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$unit=Get-Content "$taskTemp/$stem.receiver-auth.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($terminal.executed -ne 164 -or $terminal.passed -ne 163 -or $terminal.failed -ne 1 -or $unit.passed -ne 3 -or $unit.failed -ne 0){throw 'Owner terminal differs'}
$epoch=(Get-Content "$taskTemp/$stem.owners-r3.source-freeze.json" -Raw|ConvertFrom-Json).paths
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$untracked=(Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json).files
foreach($row in $untracked){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked drift'}}
. "$taskTemp/convergence-image-git-bytes.ps1"
$metrics=Import-Csv "$taskTemp/$stem.structure-report/file_metrics.csv"
$rows=@(foreach($path in (Get-Content "$taskTemp/$stem.source.owned.txt")){
 $metric=@($metrics|Where-Object path -eq $path)
 if($metric.Count -ne 1){throw "Missing metrics: $path"}
 $old=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('a477f60f2d07f0704bda1db6b1b574245274b94c:'+$path))))
 $oldLines=($old -split "`n").Count-[int]$old.EndsWith("`n")
 [ordered]@{path=$path;owner=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLines=[int]$metric[0].physical_lines;embeddedTestLines=[int]$metric[0].embedded_test_lines;growth=[int]$metric[0].physical_lines-$oldLines}
})
[ordered]@{version=1;source=$source;files=$rows;cargoChanges=0;graph='Cargo graph unchanged: workspace 98 / resolved 846 / Core reverse 53. Fresh workspace compile gates do not constitute a fresh Core53 runtime matrix.';ownership='The existing borrowed ProductDialogueReceivers is the single topology authority for live dispatch and inert admission. Typed receiver coordinates derive from actual child presentation ownership, distinguishing activation frames and Line children while retaining independent detached roles. No persistent side table, value clone, fallback walker, I/O, unsafe or contract version change.';cohesion='Product handoff and publication retain the exact physical receiver. The graph prioritizes actual nested child suspension before the parent cleanup joins; the same graph authenticates active edges and saved owners. All 8 path byte/LOC/test-line growth is recorded. The 5-forgery integration test continues the untouched original after refusal.'}|ConvertTo-Json -Depth 12|Set-Content "$taskTemp/$stem.ownership-review.json"
$archive='docs/implementation/acceptance-evidence/task-line-scoped-dialogue-receivers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name.StartsWith($stem+'.') -or $_.Name -in @('record-line-scoped-dialogue-receivers-20261108.ps1','run-line-scoped-dialogue-workspace-quality-20261108.ps1','run-line-root-frozen-nextest-20261108.ps1')}|Sort-Object Name)
$items=@(foreach($file in $files){[ordered]@{path=$file.FullName;entry=$file.Name}})+@(Get-ChildItem "$taskTemp/$stem.structure-report" -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.FullName;entry=('structure-report/'+$_.Name)}})
$entries=@(foreach($item in $items){[ordered]@{entry=$item.entry;bytes=(Get-Item -LiteralPath $item.path).Length;sha256=(Get-FileHash -LiteralPath $item.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($item in $items){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$item.path,$item.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Archive shape differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive content differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$source;priorSource='5f3e6deedf4dca6d9251b72530f5edb354655e4c';probeBase='a477f60f2d07f0704bda1db6b1b574245274b94c'
 accepted='Saved AWBC initial-input scoped defer child can start and receive an inner dialogue, wait normally and cancel the explicitly targeted inner dialogue. The original 1-op/512-step, ordered logs, 3 reveals and one Actor acquisition/release are maintained with public JSON save/cold restore at every step.'
 implementation='Product derives Fiber, Activation or LineChild receiver from the actual frame owner. Existing borrowed receiver topology drives live dispatch and saved admission, authenticates parent activation and physical receiver, and dispatches nested Line child dialogue before its waiting parent. Handoff withdraws/restores the exact child suspension inside the existing rollback transaction; result publication resumes that physical receiver.'
 validation=[ordered]@{owners=$terminal;coreReceiverTopology=$unit;forgeries='Missing child suspension, forged inner activation occurrence, forged parent activation occurrence, wrong parent fiber, duplicate child: all rejected; original executor snapshot unchanged and original execution completes.';gates='Fresh all-target/all-feature workspace check/Clippy, canonical structure gate and 8-path rustfmt exit 0; warnings retained';sourceInputs=3416;sourceDrift=0;scope='The Core 3-case topology run and Compiler 164-case owner run are separate package/feature selections. This cut does not claim the earlier full Core53 runtime matrix for its changed source.'}
 history='First Core check failed E0425 for a missing type import and was repaired. First 163-case owner run passed 162 with only Native explicit scope failing. A preparation invocation misspelled scoped_defer as scoped_unwind and failed before compilation/runtime; its catalog log and exit 101 are retained. Corrected final catalog ran 164 cases after adding the 5-forgery case, passing 163 with the same one Native failure. No runtime rerun is invented for the preparation failure.'
 remaining='Only Native explicit init scope result binding remains failing in this owner selection. Native public Save, final all-Core53 runtime consumers, other platforms/Tier2 and full Native-Web parity are not accepted by this bounded cut.'
 preserved='121 older ledger records preserved. Original WIP remains 12 tracked / 6 actual untracked. Historical wrapper held=14 labels are not the actual WIP count. Generic Match, root defer and other accepted boundaries stay accepted.'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'scopedLineChildDialogueReceivers'){throw 'Record already exists'}
$fragment=([ordered]@{scopedLineChildDialogueReceivers=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($prop in $old.PSObject.Properties){if(($prop.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($prop.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Historical evidence changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| Line の初期所有入力 |')){
 "| Line の初期所有入力 | **返却Actor／Copy・root deferの既受入を保持。追加init/scoped待機・内側取消しを両backendで通過、Native明示scope 1条件を継続中** | root defer Source 5ba67c20a9aacafe3d1dd25939be42c92cddf52a と初期packet／activation保存監査は受入済み。Nativeの入力identity保持 Source 5f3e6deedf4dca6d9251b72530f5edb354655e4c に続き、Source $source は保存AWBCのscoped子対話の起動・待機・実際の内側対話の取消しを各step公開save／cold restoreで通過。受取先の欠落・親子identity改変・重複5種を元executor不変で拒否。Core topology 3件PASS、Compiler owner 164件中163 PASS／1 FAIL。残る具体条件はNativeの明示init scope結果受取り。旧2失敗からの更新理由と全SHAを履歴に残し、既受入境界を戻さない。[実測・残条件・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 "| workspace check／Clippy・fmt・構造gate | **AWBC scoped子対話receiver cutの全workspace gateは終了0** | Source $source の全target／全feature workspace check／Clippy、canonical構造gate、8 Rust path fmtが3416 Rust／Cargo／config／toolchain入力drift0で終了0。先行Sourceの全Core unit／Core53 matrixは履歴へ保持し、新Sourceの全件結果へ合成しない。Cargo依存変更0。全14 family・他platform／Tier2・全表示parityの最終受入へ拡張しない。[実測・構造責任・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — 保存AWBCのscoped子対話receiver

Source **$source** は、初期Actorを捕捉したscoped defer子の対話を実際のchild frameへ接続した。既存の借用receiver graphをlive dispatchと保存admissionで共有し、親activation／実fiber／元対話packetを認証する。子対話を親cleanupのjoinより先に進め、結果を同じphysical receiverへ返す。永続side table・値clone・旧walker・version変更は足さない。

通常と2番目の実内側対話の取消しは、元の1-op／512-step、3 reveal、Actor取得・解放各1回、log順を維持し、AWBCの各step公開JSON save／cold restoreでPASS。受取先欠落・inner occurrence・parent occurrence・parent fiber・child重複の5改変は拒否され、元snapshot不変で継続完了する。Core topology 3／3 PASS。Compiler最終owner選択は **164件中163 PASS／1 FAIL・除外0** で、唯一の失敗はNative明示init scopeの結果受取り。既受入root deferとGeneric Matchは維持する。

初回Core compileのE0425、追加forgery前の163件中162 PASS／1 FAIL、scoped_defer targetの指定誤りでruntime前に終了したcatalog失敗も保持する。誤指定をruntime失敗や別runの合計に含めない。全workspace all-target／all-feature check／Clippy、canonical構造gate、8 path fmtは終了0、3416 Rust／Cargo／config／toolchain入力drift0。Cargo graphは不変で、旧Core53 runtime結果を新Sourceの全件合格にはしない。8ファイルのbyte／LOC／embedded tests／増分・構造責任、実exe path／SHA256と全full SHAを[台帳・原本](acceptance-evidence/task-flow-registry-execution.json)へ保持。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;historicalRecordsPreserved=$old.PSObject.Properties.Name.Count;archiveEntries=$entries.Count;archiveSha256=$record.raw.sha256;compilerPassed=$terminal.passed;compilerFailed=$terminal.failed}|ConvertTo-Json -Compress
