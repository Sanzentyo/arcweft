$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$prefix='checkpoint-rag-project-summary-20261106'
$base=(git rev-parse HEAD).Trim()
$b=Get-Content -LiteralPath (Join-Path $e 'checkpoint-task-view.source-freeze.json') -Raw | ConvertFrom-Json
if($base -ne '203b0972aa96956bdca23c722e09142fc44f410f' -or $base -ne $b.base -or (git branch --show-current).Trim() -ne 'main'){throw 'Unexpected base/branch'}
if(@(git diff --cached --name-only).Count){throw 'Index not empty'}
foreach($kind in @('check','clippy','structure')){$r=Get-Content -LiteralPath (Join-Path $e ('rag-project-summary-quality2-20261106-'+$kind+'.json')) -Raw | ConvertFrom-Json;if($r.exitCode -ne 0){throw ('Quality failed: '+$kind)}}
$cli=Get-Content -LiteralPath (Join-Path $e 'rag-project-summary-cli4-20261106.runtime.terminal-audit.json') -Raw | ConvertFrom-Json
if($cli.passed -ne 2 -or $cli.failed -ne 0){throw 'CLI owner not accepted'}
$partial='crates/arcweft-cli/tests/check/agent_script_debug.rs'
$m=Get-Content -LiteralPath (Join-Path $e 'rag-project-summary-identity-test-migration.json') -Raw | ConvertFrom-Json
if((git rev-parse ('HEAD:'+$partial)).Trim() -ne $m.oldHeadBlob){throw 'Partial-path base moved'}
$before=Get-Content -LiteralPath (Join-Path $e 'rag-project-summary-owner3-20261106.source-freeze.json') -Raw | ConvertFrom-Json
foreach($path in $b.held | Where-Object {$_ -ne $partial}){
 $row=$before.paths | Where-Object path -eq $path
 if(-not $row -or (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Other original WIP changed: '+$path)}
}
$old=[string]::Join([char]10,@('                    hit["source_kind"] == "symbol"','                        && hit["chunk_id"]','                            .as_str()','                            .is_some_and(|id| id.contains(query))'))
$working=[IO.File]::ReadAllText((Join-Path $PWD $partial))
$start=$working.IndexOf('                    let Some(body) = hit["body"]',[StringComparison]::Ordinal)
$last='                        && chunk_id.starts_with(&format!("cli:{source_key}:"))'
$end=$working.IndexOf($last,$start,[StringComparison]::Ordinal)
if($start -lt 0 -or $end -lt 0){throw 'Partial hunk region missing'}
$new=$working.Substring($start,$end+$last.Length-$start).Replace("`r`n","`n")
function Replace-Block([string]$text,[string]$from,[string]$to){
 $ending=if($text.Contains("`r`n")){"`r`n"}else{"`n"}
 $needle=$from.Replace("`n",$ending);$replacement=$to.Replace("`n",$ending)
 if(([regex]::Matches($text,[regex]::Escape($needle))).Count -ne 1){throw 'Expected one exact partial hunk'}
 return $text.Replace($needle,$replacement)
}
$head=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$partial))))
$candidate=Replace-Block $head $old $new
if($candidate -cne [IO.File]::ReadAllText((Join-Path $e 'rag-project-summary-identity-test.index.rs'))){throw 'Candidate contains other changes'}
$restored=Replace-Block $working $new $old
if($restored -cne [IO.File]::ReadAllText((Join-Path $e 'rag-project-summary-held-before-identity-test.rs'))){throw 'Pre-existing user text changed'}
$nonHeld=@(@(git diff HEAD --name-only | Where-Object {$_ -notin $b.held})+@('crates/arcweft-compiler/tests/agent_project_summary.rs') | Sort-Object -Unique)
$owned=@($nonHeld+@($partial) | Sort-Object -Unique)
$owned | Set-Content -LiteralPath (Join-Path $e ($prefix+'.owned.txt')) -Encoding utf8
$pathspec=Join-Path $e ($prefix+'.non-held.pathspec')
[IO.File]::WriteAllText($pathspec,($nonHeld -join "`0")+"`0",[Text.UTF8Encoding]::new($false))
& git --literal-pathspecs add ('--pathspec-from-file='+$pathspec) --pathspec-file-nul
if($LASTEXITCODE){throw 'Owned staging failed'}
$blob=(git hash-object -w --no-filters -- (Join-Path $e 'rag-project-summary-identity-test.index.rs')).Trim()
if($LASTEXITCODE -ne 0 -or $blob -notmatch '^[0-9a-f]{40}$'){throw 'Partial candidate hashing failed'}
& git update-index --cacheinfo ('100644,'+$blob+','+$partial)
if($LASTEXITCODE){throw 'Partial staging failed'}
if(@(Compare-Object $owned @(git diff --cached --name-only)).Count){throw 'Unexpected staged paths'}
if([Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',(':'+$partial)))) -cne $candidate){throw 'Staged partial blob differs'}
& git -c core.whitespace=trailing-space,space-before-tab,cr-at-eol diff --cached --check
if($LASTEXITCODE){throw 'Whitespace failed'}
$patch=Read-GitBytes @('diff','--cached','--binary','--full-index')
[IO.File]::WriteAllBytes((Join-Path $e ($prefix+'.reviewed.patch')),$patch)
$held=Read-GitBytes (@('diff','--binary','--full-index','--')+$b.held)
$heldHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($held)).ToLowerInvariant()
$rows=@(foreach($line in (git ls-files --stage)){if($line -notmatch '^[0-9]+ ([0-9a-f]{40}) 0\t(.+)$'){throw 'Bad stage entry'};if($Matches[2] -in $owned){[ordered]@{path=$Matches[2];blob=$Matches[1]}}})
$p=[ordered]@{version=1;base=$base;tree=(git write-tree).Trim();paths=$rows;other=@();held=$b.held;heldPatchSha256=$heldHash;patchSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant();preparedAt=[DateTime]::UtcNow.ToString('o')}
$p | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.prepared.json')) -Encoding utf8
$priorHash=$b.heldPatchSha256
$b.heldPatchSha256=$heldHash
$b | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $e 'checkpoint-task-view.source-freeze.json') -Encoding utf8
[ordered]@{version=1;base=$base;partialPath=$partial;partialBlob=$blob;stagedCandidateDerivedFromHead=$true;ownedRagHunks=1;userHunksStaged=0;reverseOwnedReplacementDrift=0;otherOriginalWipDrift=0;priorHeldPatchSha256=$priorHash;remainingHeldPatchSha256=$heldHash;reason='Rebase only the held patch coordinates over one staged RAG assertion hunk. Preserve both borrowed-summary reads within user WIP and all other user text; no user-authored hunk is staged.'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $e 'rag-project-summary-partial-staging-audit.json') -Encoding utf8
[ordered]@{base=$base;ownedPaths=$owned.Count;partialHunks=1;userHunksStaged=0;otherWipDrift=0;tree=$p.tree;patchSha256=$p.patchSha256} | ConvertTo-Json -Compress
git diff --cached --stat
git diff --cached -- $partial
