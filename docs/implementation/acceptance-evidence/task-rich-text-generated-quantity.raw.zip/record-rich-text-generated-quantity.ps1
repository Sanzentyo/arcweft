$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Json([string]$name){Get-Content -LiteralPath "$t/$name.json" -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$publication=Read-Json 'rich-text-generated-quantity-checkpoint.verified'
if((git rev-parse HEAD).Trim() -ne $publication.commit){throw 'Unexpected source'}
$compiler=Read-Json 'rich-text-source-factory-owner7-20261105.runtime.terminal-audit'
$library=Read-Json 'rich-text-source-factory-owner8-20261105.runtime.terminal-audit'
if($compiler.executed -ne 19 -or $compiler.passed -ne 16 -or $compiler.failed -ne 3 -or $library.executed -ne 6 -or $library.passed -ne 6 -or $compiler.sourceDrift -ne 0 -or $library.sourceDrift -ne 0){throw 'Results differ'}
foreach($row in (Read-Json 'rich-text-source-factory-owner8-20261105.source-freeze').paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$before=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($before.Contains('factoryInstances')){throw 'Preserve existing instance evidence'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$oldRows=@($status -split "`n" | Where-Object {$_ -match '^\| (RichTextの部分layout指定／source factory|共有契約／推移的逆依存matrix|CLI全target照合|workspace check／Clippy・fmt・構造gate) \|'})
[ordered]@{version=1;source=$publication.commit;rows=$oldRows;historyPrefix=$historyPrefix;reason='Generated quantity instances now execute; point-only input independently reproduces lost alias order. Keep original px failures and all old results.'} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$t/rich-text-generated-quantity-status-before.json" -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {$_.Name -like 'rich-text-generated-quantity*' -or $_.Name -like 'rich-text-source-factory-owner6*' -or $_.Name -like 'rich-text-source-factory-owner7*' -or $_.Name -like 'rich-text-source-factory-owner8*'})
foreach($name in @('record-rich-text-generated-quantity.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')){$files+=Get-Item -LiteralPath "$t/$name"}
$root=[IO.Path]::GetFullPath($t)
$index=@(foreach($file in @($files|Sort-Object FullName -Unique)){[ordered]@{entry=$file.FullName.Substring($root.Length+1).Replace([IO.Path]::DirectorySeparatorChar,[char]'/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$index | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$t/rich-text-generated-quantity-archive-inputs.json" -Encoding utf8
$files+=Get-Item -LiteralPath "$t/rich-text-generated-quantity-archive-inputs.json"
. "$t/write-verified-evidence-archive.ps1"
$archive='docs/implementation/acceptance-evidence/task-rich-text-generated-quantity.raw.zip'
$raw=Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record=$before
$record.factoryInstances=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$publication
    state='Intermediate checkpoint: generated function/closure quantity projection executes. Factory unit and alias composition conditions still fail; no complete factory/goal acceptance.'
    implementation=@('Reduced runtime quantities enter the same Literal family in the generated executable partition, and Compiler materializes them using the instantiated semantic type. This complements the earlier root-expression projection.','One RuntimeSchemas method selects the exact retained generation for both factory calls and CharacterDialogue production. The constructor context also rejects a foreign executable with identical fixture type IDs.','The original px cases remain. A new independent pt case reaches the composition assertion; a new generic-function/closure case executes each quantity constant through Native and decoded AWBC with public JSON save/restore at every AWBC OneOp.')
    validation=[ordered]@{compilerTarget=$compiler;libraryTargets=$library;compilerCommand=(Read-Json 'rich-text-source-factory-owner7-20261105.runtime').command;libraryCommand=(Read-Json 'rich-text-source-factory-owner8-20261105.runtime').command;scope='Separate runs with separate target/package selections. Do not merge into one25-case/all-target/all-feature run. Compiler selects one integration target; Dialogue and RichTextSchema select libraries.';sourceRelation='Both runs pin the same4104 source inputs on base b11e9efdc3c831a334a49a8614bd5bbe6bbc409b plus the five source paths published as187fb586261ac6ba381546532143fa20854dba8b. Source/case/executable drift0.';positive='All14 existing Compiler quantity cases, empty3factories and the new generic-function/closure quantity case PASS. Separate library6/6 includes original-result/quota/unbound/foreign-owner rejection.';quality='Five changed Rust paths pass fmt and applicable staged whitespace. Full workspace check/Clippy/structure, complete48-package runtime closure, CLI probes and display/unit acceptance remain pending.'}
    failedConditions=[ordered]@{px='The two original px cases still reject the pt-only Size property schema at runtime. They were not rewritten to pt or removed.';aliasOrder='rich_text_style(ruby=text_style(size=11pt),text=text_style(size=24pt)) gives24pt directly. The same arguments through let compose=rich_text_style; compose(...) give11pt in Native and decoded AWBC. The test helper executes both backends and asserts their observed properties equal before the expected24pt assertion fails. Current generated wrapper forwards declaration formal order; actual ownership/provenance must preserve caller order.';genericFont='Bare serif remains unimplemented; named String fonts do not establish generic-font support.'}
    environment=[ordered]@{failedCatalog=(Read-Json 'rich-text-source-factory-owner6-20261105.catalog');reason='OS error1455: rustc could not mmap the Core rlib because paging capacity was exhausted, followed by invalid-metadata/import ICE diagnostics. No owner6 runtime executed.';recovery='After the failed build reached a terminal state, prepare/select the Compiler callable target and the two owner libraries separately. Keep original cases, features, assertions, OneOp limits and full closure pending; no jobs/profile/OS setting change or artifact move/copy/clean.'}
    correctionReason='Add executable generated-instance evidence and a separate point-only reproduction of alias order. Preserve prior failures/source SHAs and all accepted boundaries. Old19/6 commands are explicit, with no combined-run claim.'
    supersededCurrentRows=$oldRows;historyPrefix=$historyPrefix
    raw=[ordered]@{path=$archive;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0;indexEntry='rich-text-generated-quantity-archive-inputs.json'}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$sha=$publication.commit
$rows=@(foreach($line in ($status -split "`n")){
    if($line.StartsWith('| RichTextの部分layout指定／source factory |')){"| RichTextの部分layout指定／source factory | **既受入を維持。factory・生成instanceを中間公開、単位とalias合成は未達** | Source ${sha}で、元contextの型・上限を使う3 factoryに加え、quantityを含むgeneric関数／closureのNative・decoded AWBC実行と各AWBC OneOp公開save／restoreを確認した。Compiler対象19件は16 PASS／3 FAIL、別runのDialogue／RichTextSchema libraryは6／6 PASS。元のpx2条件はpt限定schemaで拒否する。独立したpt条件では直接合成が最後の24ptを保持する一方、aliasはNative／AWBCとも11ptとなり、元の引数順が失われる。typed provenance、単位のconsumer接続、bare serifの型付きfont、static inline_stylesと全体検証を継続する。部分layout・共通property・生成API・省略alias等の既受入は維持する。[別runの範囲・全失敗・中間公開SHA・raw](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |') -or $line.StartsWith('| CLI全target照合 |')){$line.Replace('中間Source c310c7eeab2bce80d127f19eb9ebbea4306e41cd',"中間Source $sha").Replace('対象23件を全48実行とは扱わない。','対象別の19件／6件を全48実行や一つのrunとは扱わない。')}
    elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){$line.Replace('中間Source c310c7eeab2bce80d127f19eb9ebbea4306e41cdでは変更Rust15件',"中間Source ${sha}では変更Rust5件")}
    else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-05 — Generated quantity instances and actual alias-order reproduction

- Intermediate Source $sha (parent $($publication.parent)) publishes the generated generic-function/closure quantity projection and shared exact-generation selection. Original program/result/quota/unbound/foreign-owner rejection remains enforced.
- Compiler callable target:19 run/16 PASS/3 FAIL. All14 prior quantity cases, empty factory direct/aliases and new generated quantities PASS, with Native/decoded-AWBC execution and each AWBC OneOp public JSON save/restore. Separate Dialogue/RichTextSchema libraries:6/6 PASS. These different target/package commands are not combined into a single25-case/all-target run; all4104 source inputs/cases/executables have zero drift.
- Preserve the original2 px property-schema failures. The added pt case independently reaches the actual order assertion: direct incoming ruby11pt then text24pt gives24pt; alias gives11pt on both backends. The generated wrapper's formal-order forwarding must be repaired through owned callable/invocation/frame provenance. Bare generic fonts, full unit consumption, inline-style provenance and full48/full98 acceptance remain unfinished; accepted Generic Match and earlier typed boundaries remain accepted.
- Owner6 never executed tests: OS1455 prevented mmap of the Core rlib and produced invalid-metadata/import ICE diagnostics. The build was observed terminal before narrower target preparation. No Cargo jobs/profile, runtime budgets, OS settings or build-artifact locations changed. Every failure, command, intermediate publication identity and raw hash is retained in [the existing task evidence](acceptance-evidence/task-rich-text-property-identity.json); [current-status.md](current-status.md) is the sole current list.
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in @($before.Keys|Where-Object {$_ -ne 'factoryInstances'})){if(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw "Prior field changed: $key"}}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$retained=[byte[]]::new($history.Length);[Array]::Copy($now,$retained,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($retained)).ToLowerInvariant() -ne $historyPrefix.sha256){throw 'History prefix changed'}
[ordered]@{source=$sha;priorFieldDrift=0;historyPrefixDrift=0;rawEntries=$raw.entries.Count;rawBytes=$raw.bytes;rawSha256=$raw.sha256} | ConvertTo-Json -Compress
