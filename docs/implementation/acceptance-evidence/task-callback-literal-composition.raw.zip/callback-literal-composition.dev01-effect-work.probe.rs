#![allow(dead_code)]
#[path = "MODULE_PATH"]
mod decision;

use decision::{DecisionControl, DecisionWork, EffectDecision, EffectDecisionReplacement};

#[derive(Default)]
struct Meter(usize);

impl DecisionControl for Meter {
    type Error = std::convert::Infallible;
    fn charge(&mut self, _: DecisionWork) -> Result<(), Self::Error> {
        self.0 += 1;
        Ok(())
    }
}

fn atom(variable: u8) -> EffectDecision<u8> {
    EffectDecision::variable(variable, &mut Meter::default()).unwrap()
}

fn conjunction(variables: std::ops::RangeInclusive<u8>) -> EffectDecision<u8> {
    let terms = variables.map(atom).collect::<Vec<_>>();
    EffectDecision::all(&terms, &mut Meter::default()).unwrap()
}

fn record(name: &str, result: EffectDecision<u8>, work: Meter) {
    println!("{name} work={} nodes={} canonical={result:?}", work.0, result.node_count());
}

fn main() {
    let mut meter = Meter::default();
    let replacement = conjunction(1..=32);
    let result = atom(0).substitute_references(&mut meter, |_, _| {
        Ok(EffectDecisionReplacement::Decision(&replacement))
    }).unwrap();
    assert_eq!(result, replacement);
    record("single-reference", result, meter);

    let mut meter = Meter::default();
    let result = atom(0).conditional(
        &conjunction(1..=16),
        &conjunction(17..=32),
        &mut meter,
    ).unwrap();
    record("ordered-conditional", result, meter);

    let mut setup = Meter::default();
    let yes = atom(1).not(&mut setup).unwrap().or(&atom(2), &mut setup).unwrap();
    let no = atom(1).and(&atom(3), &mut setup).unwrap();
    let source = atom(0).conditional(&yes, &no, &mut setup).unwrap();
    let mut meter = Meter::default();
    let result = source.substitute_references(&mut meter, |variable, _| match variable {
        0 | 2 => Ok(EffectDecisionReplacement::Variable(2)),
        1 => Ok(EffectDecisionReplacement::Variable(0)),
        3 => Ok(EffectDecisionReplacement::Constant(false)),
        _ => unreachable!(),
    }).unwrap();
    assert_eq!(result, atom(2));
    record("reordered-and-merged", result, meter);
}
