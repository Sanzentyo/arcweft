$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/effect-residual-program.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/effect-residual-program.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$root/effect-residual-program.impact.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/effect-residual-program.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/effect-residual-program.structure.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/effect-residual-program.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean'}
if($owner.Passed -ne 1710 -or $owner.Failed -ne 6 -or $impact.ReverseConsumersRerun -or !$archive.AllEntriesVerified -or $structure.ExitCode){throw 'Evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'History prefix changed'}
$rows=@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。量化付き残余表現の検査とFuture入力の部分代入を検証・公開。本体内推論は継続** | 最新Source `SOURCE`。Native／AWBCの42・各step公開保存復元、実Source Γ・import lease・frame移送の既受入を維持する。guard付き子の取り込み、条件付きsupport、derived値を親の最小化から除く境界を保持する。元のR、局所関数の∃、有限行の局所∀、全行共通choice、satisfiable／principalと下限comprehensionを型付きgraphへ保持し、有限基底solverも同じRを読む。検査cursorから実依存順・domain・operand・固定／自由Future・論理label probe・一括下限代入を辿れる。Futureを一部だけ固定して元graph／programを共有し、残る入力だけを親へ結合する新5件はPASS。入力の部分代入と、残余条件の論理的な簡約・真偽判定は区別し、後者は未実装。点ごとに独立なnullary条件のBoolean消去、FutureだけのCoverage保持、uniqueな点ごとの解だけを他条件へ代入する正規化、一般MGU／rank・Fn型ownerの局所∀を続ける。reify入力の元operand導出、checked primitive effect ownerと行seal、全portのΓ統合、frontend prepared value／effect・body一回準備・一括sealも未完了。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[Γとowner](convergence-evidence-history.md#inference-references-and-application-leases)・[今回の残余表現](convergence-evidence-history.md#quantified-effect-residuals-and-partial-future-inputs)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,710 PASS／6 FAIL。後続21 packageは以前の公開Sourceの実測を再利用** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,716件を114.197秒で実行。直前1,711 IDを維持し新5件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。対象の残余表現5件＋既存import 10件の先行runも15 PASS。現在の全feature Cargo graphは22 packageで不変。crate-privateのR生成・検査・部分代入の変更であり、既存prepared producer・cross-crate API・codec・fixture・Cargo入力は不変のため、後続21 package／107 targetはSource `0691efa11175cadc7c0850278cd1a7ef4be45f62` の2,507 PASS／2 FAIL／1 SKIPを再利用する。Compiler既知2失敗のExpressionCycle slot 17／19を今回の再実行とは扱わない。[現在のowner・graph・再利用根拠](acceptance-evidence/task-effect-residual-program.raw.zip)・[consumer実測](acceptance-evidence/task-conditional-component.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **以前の公開Sourceの規定226件PASSを維持。全 check は未再実行** | 実行Source `0691efa11175cadc7c0850278cd1a7ef4be45f62`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS。binはcompile済み・runnable test 0件。今回のprivate準備効果ownerの変更ではこの結果を再利用し、新Sourceの再実行へ読み替えない。以前の入力・件数・失敗も履歴と原本に保持する。[CLI実行原本](acceptance-evidence/task-conditional-component.raw.zip)・[今回の再利用根拠](acceptance-evidence/task-effect-residual-program.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新owner Clippy・fmt・doctest・構造gateは終了0。workspace記録は以前のSourceを再利用** | Source `SOURCE` と同一のRust bytesでlocked owner全target／全feature Clippy、workspace fmt、Sema doctest 2件を実行。checkはClippyに包含。構造gateは98 package・3,501 files・3,370 Rust files・1,899,918 Rust LOC・396 review・blocking 0。7 Rust path・1,510物理LOC増を対象に、残余programがRを所有し、有限基底backendがそれを読み、元graphを使うcanonical replayが独立に検証する責務を確認した。検査はborrowed cursorで行い、部分代入は元graph／programの共有と固定値だけを保持する。Cargo graphは22 packageで不変。private cutとしてworkspace全target／全feature check／ClippyはSource `0691efa11175cadc7c0850278cd1a7ef4be45f62` の終了0を再利用し、今回の実行へ付け替えない。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告は原本へ保持。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を維持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・graph](acceptance-evidence/task-effect-residual-program.raw.zip)・[workspace実測](acceptance-evidence/task-conditional-component.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$status=[IO.File]::ReadAllText($statusPath)
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'}
    $replacement=$rows[$key].Replace('SOURCE',$pub.Source)
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `c6baf6d4b75acbed2c3c0d5168f153e555a7686a`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Quantified effect residuals and partial Future inputs

2026-11-13。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの7 Rust pathを通常commit／非force pushし、ownerが検証したdirty bytesと公開全blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- 残余programへ元のR、局所関数とchoiceの存在量化、有限行の局所∀、satisfiable、下限comprehension、下限を一括代入したwitnessとprincipalを明示した。Source predicateとbodyは元のtyped定義を参照し、コピーした別catalogを作らない。有限基底backendの手書きR構築を削除し、同じprogramを読むiterative compilerへ置換した。scopeごとにbodyとadmissionを共有し、元graphによるcanonical replayは独立に維持する。
- borrowed cursorは実依存引数・scope・whole domain⇒consequence・実operand・一様choice・固定／自由Future・元の関数・下限代入を露出する。下限のlabel probeはEffectIdと別の論理変数である。部分Future代入は元graphとprogramのArcを共有し、実signatureに含まれる参照だけを許して、新label supportと既固定値を保持する。未固定FutureだけをParentへ結合し、独立replayにも固定値を渡す。
- 新5件は量化順とscope、下限のglobal satisfiable gateとlabel binder、部分固定＋残る自由入力、全入力固定、identity／依存範囲／重複／予算0／再固定拒否と失敗原子性、固定identityへ新labelを渡す投影、残余Rを改変しても元の式の独立replayが拒否する条件を検証する。先行対象15件は15 PASS。最終全feature ownerは1,716件／1,710 PASS／6 FAIL／0 SKIP、114.197秒、5 suite。直前1,711 ID保持・新5件PASS・選択／終端ID一致・重複0、既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。
- 今回のowner全target／全feature Clippy、workspace fmt、Sema doctest 2件と構造gateは終了0。full metadata／全target treeで逆依存22 packageを再確認した。private owner内のR生成・検査・部分代入で、既存producer、cross-crate API、codec、syntax、fixture、Cargo入力と生成物は不変。後続21 package／107 targetの2,507 PASS／2 FAIL／1 SKIP、workspace check／ClippyはSource ``0691efa11175cadc7c0850278cd1a7ef4be45f62`` の記録を再利用し、現在Sourceの実行へ付け替えない。
- 7 pathで1,510物理LOC増。residual.rs 317 LOCが量化program、view.rs 607 LOCがborrowed inspection、独立test owner 428 LOCが契約と改変拒否を所有する。既存componentは379 LOCで、同じRを読むbackendとscope cacheを持つ。fan-in 12／fan-out 19で不変。新solver、Source再構築、別Γ表、依存、unsafe、公開互換readerは追加しない。
- Supersedes: 現状一覧の残余表現全体を未実装とした途中説明を、実装済みの量化表現・検査・Futureの部分代入と、未実装の論理簡約・真偽判定へ分けた。部分入力の代入だけで一般の論理簡約やfrontend接続が完了したとはしない。過去の全SHA・実測・原本とGeneric Match・caller-bound recursion・共有prefixの受入を維持し、現在の残作業は[current-status.md](current-status.md)へ集約する。

原本 [task-effect-residual-program.raw.zip](acceptance-evidence/task-effect-residual-program.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended quantified residual evidence'
