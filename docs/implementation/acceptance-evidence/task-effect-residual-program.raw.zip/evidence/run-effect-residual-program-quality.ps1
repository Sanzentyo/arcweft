$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$env:CARGO_INCREMENTAL='0'
$pub=Get-Content -Raw "$root/effect-residual-program.publication.json"|ConvertFrom-Json
$steps=[Collections.Generic.List[object]]::new()
function Assert-Source {
    if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse 'HEAD^{tree}') -ne $pub.Tree -or @(git diff --name-only HEAD).Count){throw 'Quality source changed'}
}
function Step($name,$arguments,$output,$log){
    Assert-Source
    $start=Get-Date
    Write-Output "START $name"
    & cargo @arguments > "$root/$output" 2> "$root/$log"
    $code=$LASTEXITCODE
    Assert-Source
    $steps.Add([ordered]@{Name=$name;Arguments=$arguments;Started=$start.ToString('o');Finished=(Get-Date).ToString('o');ExitCode=$code;SourcePinsVerified=$true;Output=$output;Log=$log})
    [ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;CARGO_INCREMENTAL='0';JobsOverride=$false;ProfileOverride=$false;Steps=@($steps.ToArray())}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/effect-residual-program.quality.json"
    Write-Output "END $name exit=$code"
    Get-Content "$root/$log" -Tail 5
    if($code){throw "$name failed"}
}
rustc -vV > "$root/effect-residual-program.rustc-vV.txt"
cargo -V > "$root/effect-residual-program.cargo-V.txt"
Step 'owner-clippy' @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features') 'effect-residual-program.clippy.stdout' 'effect-residual-program.clippy.log'
Step 'owner-doctest' @('test','--locked','-p','arcweft-lang-sema','--all-features','--doc') 'effect-residual-program.doctest.stdout' 'effect-residual-program.doctest.log'

