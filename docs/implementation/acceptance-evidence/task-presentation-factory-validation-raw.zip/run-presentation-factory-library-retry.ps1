$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$previous=Get-Content -LiteralPath "$taskTemp/presentation-factory-input-guard-reverse-20261101.source-freeze.json" -Raw | ConvertFrom-Json -Depth 30
$graph=Get-Content -LiteralPath "$taskTemp/presentation-factory-execution.reverse-closure.json" -Raw | ConvertFrom-Json -Depth 20
$selection=@('--lib','--tests')+@($graph.packages.name | Where-Object {$_ -ne 'arcweft-cli'} | Sort-Object | ForEach-Object {'-p';$_})+@('--all-features','--locked','-E','rdeps(=arcweft-interaction-model)')
& "$taskTemp/run-shared-identity-owner.ps1" -Stem 'presentation-factory-input-guard-library-retry1-20261101' -Selection $selection -ExpectedMatches 8814 -AdditionalPaths @($previous.paths.path)
exit $LASTEXITCODE