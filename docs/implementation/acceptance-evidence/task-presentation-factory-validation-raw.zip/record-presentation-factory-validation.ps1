$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -Depth 40 }
$library=Read-Record 'presentation-factory-input-guard-library-retry1-20261101.runtime.terminal-audit'
$repair=Read-Record 'presentation-body-path-golden-focus1-20261101.runtime.terminal-audit'
if($library.passed -ne 8813 -or $library.failed -ne 1 -or $repair.passed -ne 3 -or $repair.failed -ne 0){throw 'Unexpected runtime/repair outcomes'}
$owner=Read-Record 'presentation-factory-input-guard-focus1-20261101.runtime.terminal-audit'
$cli=Read-Record 'presentation-factory-input-guard.cli-target-coverage'
$comparison=Read-Record 'presentation-factory-input-guard.cli-failure-comparison'
$generic=Read-Record 'presentation-factory-input-guard.generic-coverage'
if($owner.passed -ne 148 -or $generic.passed -ne 151 -or $cli.executedUnique -ne 692 -or $comparison.newFailureIds.Count){throw 'Coverage differs'}
$quality=@(foreach($suffix in @('workspace-check','clippy','structure','fmt')) {
    $record=Read-Record "presentation-factory-input-guard-quality-20261101.$suffix"
    if($record.exitCode -ne 0){throw "Quality failed: $suffix"}
    [ordered]@{gate=$suffix;record=$record}
})
$repairQuality=@(Read-Record 'presentation-body-path-golden.clippy'; Read-Record 'presentation-body-path-golden.fmt')
if(@($repairQuality | Where-Object exitCode -ne 0).Count){throw 'Repair quality failed'}
$original=Get-Content -LiteralPath 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json' -Raw | ConvertFrom-Json
$changed=@($original.held | Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($changed.Count -ne 1 -or $changed[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or (git hash-object -- $changed[0].path).Trim() -ne '4df23c4afc860ca51ff3255befe87b69a16de39b'){throw 'Original WIP differs'}
$untracked=@(git ls-files --others --exclude-standard)
if($untracked.Count -ne 6 -or @($untracked | Where-Object {$_ -notin @($original.held.path)}).Count){throw 'Original untracked set differs'}
$head=(git rev-parse HEAD).Trim()
if($head -ne 'adf0413bd40be9eb29b50e25fb45295f1ec8ade7'){throw 'Unexpected final source publication'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath=Join-Path $evidence 'task-presentation-factory-validation-raw.zip'
$receiptPath=Join-Path $evidence 'task-presentation-factory-validation.json'
if((Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $receiptPath)){throw 'Immutable evidence exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
    $_.Name -like 'presentation-factory-input-guard-*' -or $_.Name -like 'presentation-factory-input-guard.*' -or
    $_.Name -like 'presentation-body-path-golden*' -or $_.Name -like 'checkpoint-presentation-factory-input-guard.*' -or
    $_.Name -like 'checkpoint-presentation-body-path-golden.*' -or $_.Name -in @('run-presentation-factory-input-guard-reverse.ps1','run-presentation-factory-input-guard-quality.ps1','run-presentation-factory-library-retry.ps1','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','record-presentation-factory-validation.ps1')
})+@(Get-ChildItem -LiteralPath "$taskTemp/presentation-factory-input-guard-quality-20261101.structure-report" -File)
$files=@($files | Sort-Object FullName -Unique)
$raw=@(foreach($file in $files){[ordered]@{name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try { for($index=0;$index -lt $files.Count;$index++) {
    $entry=$archive.CreateEntry($raw[$index].name,[IO.Compression.CompressionLevel]::Optimal)
    $stream=$entry.Open(); try {$bytes=[IO.File]::ReadAllBytes($files[$index].FullName);$stream.Write($bytes,0,$bytes.Length)} finally {$stream.Dispose()}
}} finally {$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {
    if($archive.Entries.Count -ne $raw.Count){throw 'Raw entry count differs'}
    foreach($row in $raw){$entry=$archive.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw "Raw entry differs: $($row.name)"}}
} finally {$archive.Dispose()}
$result=[ordered]@{
    version=1;date='2026-11-01';source=$head;productionSource='7f506204759703e3d7baaee79832f5c697a6188c'
    status='Factory owner and reverse-consumer slice verified with explicit test-only repair; CLI integration remains incomplete'
    publications=@(Read-Record 'checkpoint-presentation-factory-input-guard.verified'; Read-Record 'checkpoint-presentation-body-path-golden.verified')
    owner=$owner;quality=$quality;repairQuality=$repairQuality
    initialMatrix=(Read-Record 'presentation-factory-input-guard-reverse-20261101.matrix')
    libraryRetry=$library;testOnlyRepair=$repair;inputBridge=(Read-Record 'presentation-body-path-golden.input-bridge')
    ordinaryMatrix=[ordered]@{source=$library.base;passed=9033;failed=1;ignored=24;interpretation='8813 library PASS/1 stale fixture FAIL plus 191 CLI unit PASS and 29 ordinary CLI integration PASS; followed by separate 3/3 codec repair. These are not a new single 9034 PASS run.'}
    cli=$cli;cliFailureComparison=$comparison;genericCoverage=$generic
    graph=(Read-Record 'presentation-factory-input-guard-reverse-20261101.graph')
    compileRecovery='Initial all-package catalog failed with Windows mmap OS error 1455 (paging/commit capacity) and a Bundle generic assertion type diagnostic. The exact same package/features/source selection rebuilt successfully without source changes; both diagnostics did not recur. Preserve the failed catalog rather than treating it as a runtime pass.'
    fixtureCorrection='PresentationBody path tag 17 was added by the resource-value implementation. An old malformed-input test still expected it to be unknown. The test-only repair adds exact golden 0100000011 and round trip, keeps unknown rejection using u8::MAX, and retains zero/truncation/trailing and reserved-tag rejections. Production behavior is unchanged.'
    limits=@('CLI retains 43 failed identities, same as the previous 12180810c10ced738a2ad94f98dbb3b1cec831a1 input; same identities do not prove the same cause','Four library packages have no matching executed cases and are compilation selections only','Default/Wasm, doctest, Tier 2 and final Native/Web image parity are not rerun for this input','Explicit scope capabilities, View producers, command/method/driver integration and complete construction/decoding preflight remain in progress')
    priorEvidence='task-presentation-factory-progress.json'
    originalWip=[ordered]@{tracked=14;actualUntracked=6;unchangedOldHashes=19;benchWorkingBlob='4df23c4afc860ca51ff3255befe87b69a16de39b';heldPatchSha256='53b95c4ff3fb9ef6080f215b97cf7442033a1ff81f83da3ebe7db441b9d363b6'}
    raw=[ordered]@{path='task-presentation-factory-validation-raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entryCount=$raw.Count;entryDrift=0;entries=$raw}
    recordedAt=[DateTime]::UtcNow.ToString('o')
}
$result | ConvertTo-Json -Depth 50 | Set-Content -LiteralPath $receiptPath -Encoding utf8
[pscustomobject]@{source=$head;libraryPassed=$library.passed;libraryFailed=$library.failed;repairPassed=$repair.passed;genericPassed=$generic.passed;cliPassed=$cli.passed;cliFailed=$cli.failed;rawEntries=$raw.Count;rawSha256=$result.raw.sha256;rawBytes=(Get-Item -LiteralPath $zipPath).Length} | ConvertTo-Json
