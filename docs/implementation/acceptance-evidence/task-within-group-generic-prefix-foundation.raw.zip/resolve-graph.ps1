$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$d=Join-Path $env:TEMP 'arcweft-coordinate-continuation-20261111'
$hostTarget='x86_64-pc-windows-msvc'
$metadataRaw = cargo metadata --locked --format-version 1 --filter-platform $hostTarget 2> (Join-Path $d 'metadata.stderr')
if($LASTEXITCODE){throw 'Cargo metadata failed'}
$metadataRaw | Set-Content -LiteralPath (Join-Path $d 'cargo-metadata.json') -Encoding utf8NoBOM
$m=$metadataRaw | ConvertFrom-Json
$workspace=@($m.packages | Where-Object {$_.id -in $m.workspace_members})
$names=@($workspace.name)
$owners=@('arcweft-core','arcweft-lang-sema','arcweft-runtime-plan','arcweft-compiler')
$found=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$queue=[Collections.Generic.Queue[string]]::new()
foreach($p in $workspace | Where-Object {$_.name -in $owners}){[void]$found.Add($p.id);$queue.Enqueue($p.id)}
while($queue.Count){
    $dependency=$queue.Dequeue()
    foreach($node in $m.resolve.nodes){
        if($dependency -in @($node.deps.pkg) -and $found.Add($node.id)){$queue.Enqueue($node.id)}
    }
}
$closure=[ordered]@{'host-metadata'=@($workspace | Where-Object {$_.id -in $found} | ForEach-Object name | Sort-Object -Unique)}
foreach($mode in @('host-default','host-all-features','all-targets')){
    $all=[Collections.Generic.List[string]]::new()
    foreach($owner in $owners){
        $argv=@('tree','--locked','--prefix','none','--format','{p}','--invert',$owner)
        if($mode -ceq 'host-all-features'){$argv+='--all-features'}
        if($mode -ceq 'all-targets'){$argv+=@('--target','all')}else{$argv+=@('--target',$hostTarget)}
        $lines=cargo @argv 2> (Join-Path $d ("tree-$mode-$owner.stderr"))
        if($LASTEXITCODE){throw "Cargo tree failed: $mode $owner"}
        $lines | Set-Content -LiteralPath (Join-Path $d ("tree-$mode-$owner.txt")) -Encoding utf8NoBOM
        foreach($line in $lines){$n=($line -split '\s+')[0];if($n -in $names){$all.Add($n)}}
    }
    $closure[$mode]=@($all | Sort-Object -Unique)
}
foreach($mode in @('host-default','host-all-features')){
    if(Compare-Object $closure.'host-metadata' $closure[$mode]){throw "Host closure disagrees: $mode"}
}
[ordered]@{version=1;source=(git rev-parse HEAD);owners=$owners;target=$hostTarget;closure=$closure} |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $d 'cargo-closure.json') -Encoding utf8NoBOM
Write-Output ("Reverse packages: host {0}; all targets {1}" -f $closure.'host-metadata'.Count,$closure.'all-targets'.Count)




