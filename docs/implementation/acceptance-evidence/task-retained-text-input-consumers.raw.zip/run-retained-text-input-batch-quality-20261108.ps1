$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$stem=Join-Path $PSScriptRoot 'retained-text-input-batch-20261108.quality'
if(Test-Path -LiteralPath ($stem+'.source.json')){throw 'Quality epoch exists'}
$paths=@((git ls-files -- '*.rs' '*.toml' '*.lock' '*.json' '*.stderr' '*.arcw' '*.awfagent' 'rust-toolchain*' '.cargo/*') | Where-Object {$_ -notlike 'docs/*'} | Sort-Object -Unique)
$source=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();inputs=@(foreach($path in $paths){[ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})}
$source|ConvertTo-Json -Depth 8|Set-Content -LiteralPath ($stem+'.source.json') -Encoding utf8
function Assert-Source {foreach($row in $source.inputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}}
function Invoke-Quality([string]$name,[string[]]$arguments){
    Assert-Source
    $started=[DateTime]::UtcNow
    & cargo @arguments *> ($stem+".$name.log")
    $code=$LASTEXITCODE
    Assert-Source
    [ordered]@{version=1;base=$source.base;command=$arguments;exitCode=$code;sourceInputs=$source.inputs.Count;sourceDrift=0;startedAt=$started.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath ($stem+".$name.receipt.json") -Encoding utf8
    if($code -ne 0){throw "Quality failed: $name"}
}
Invoke-Quality 'check' @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Quality 'clippy' @('clippy','--locked','--workspace','--all-targets','--all-features')
Invoke-Quality 'structure' @('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking','--write',"$PSScriptRoot/retained-text-input-batch-20261108.structure-report")
$formatPaths=@((git diff --name-only 32445ffc35c7a4c49da00d94faf651c0f61ac3c1 -- '*.rs') | Sort-Object -Unique)
Assert-Source
& rustfmt --check --edition 2024 --config skip_children=true $formatPaths *> ($stem+'.fmt.log')
$code=$LASTEXITCODE
Assert-Source
[ordered]@{base=$source.base;paths=$formatPaths;exitCode=$code;sourceDrift=0}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath ($stem+'.fmt.receipt.json') -Encoding utf8
exit $code