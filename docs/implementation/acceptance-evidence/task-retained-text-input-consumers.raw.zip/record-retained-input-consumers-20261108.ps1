$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$runDir=$PSScriptRoot
. "$runDir/convergence-image-git-bytes.ps1"
function Read-Record([string]$name) { Get-Content -LiteralPath "$runDir/$name" -Raw | ConvertFrom-Json -Depth 100 -DateKind String }
$source=Read-Record 'retained-text-input-batch-20261108.source.verified.json'
if((git rev-parse HEAD).Trim() -ne $source.commit){throw 'Unexpected source'}
$original=Read-Record 'retained-text-input-integrated-20261108.noncli-r3.runtime.terminal-audit.json'
$current=Read-Record 'retained-text-input-batch-20261108.noncli.runtime.terminal-audit.json'
$cli=Read-Record 'retained-text-input-batch-20261108.cli.runtime.terminal-audit.json'
if($original.passed -ne 7351 -or $original.failed -ne 0 -or $current.passed -ne 1713 -or $current.failed -ne 0 -or $cli.executed -ne 711){throw 'Actual terminal differs'}
$selected=Read-Record 'retained-text-input-batch-20261108.graph-review.json'
$oldCases=(Read-Record 'retained-text-input-integrated-20261108.noncli-r3.catalog.inventory.json').rows
$newCases=(Read-Record 'retained-text-input-batch-20261108.noncli.catalog.inventory.json').rows
$closure=@($newCases | Where-Object status -eq 'matches' | Select-Object -ExpandProperty package -Unique)
$reused=@($oldCases | Where-Object { $_.status -eq 'matches' -and $_.package -notin $closure })
$replaced=@($oldCases | Where-Object { $_.status -eq 'matches' -and $_.package -in $closure })
if($reused.Count -ne 5641 -or $replaced.Count -ne 1710 -or $closure.Count -ne 11){throw 'Consumer partition differs'}
$epochs=@(foreach($attempt in 7..11){Read-Record "retained-text-input-20261108.owner-r$attempt.runtime.terminal-audit.json"})
$quality=@(foreach($kind in @('check','clippy','structure','fmt')){Read-Record "retained-text-input-batch-20261108.quality.$kind.receipt.json"})
if(@($quality | Where-Object exitCode -ne 0).Count){throw 'Quality failure'}
$files=Import-Csv -LiteralPath "$runDir/retained-text-input-batch-20261108.structure-report/file_metrics.csv"
$packages=Import-Csv -LiteralPath "$runDir/retained-text-input-batch-20261108.structure-report/package_metrics.csv"
$review=[ordered]@{version=1;source=$source.commit;baseline='7af6e561ffa90716501e1ee0f15a397b666bffde';files=@($files|Where-Object path -in @('crates/arcweft-runtime-driver/src/session.rs','crates/arcweft-compiler/tests/view_product/text_input.rs'));packages=@($packages|Where-Object package -in @('arcweft-runtime-driver','arcweft-compiler'));growth=@{session='45 added / 8 removed';textInputTests='170 added / 20 removed'};disposition='Session owns ordering of accepted player events and same-clock presentation refresh; no new scheduler, value authority, dependency, feature or unsafe. Existing state/executor ownership is preserved. Nine actual codec/player tests remain with the text-input owner. Prior 33-path structural review remains applicable to unchanged owners.'}
$review|ConvertTo-Json -Depth 12|Set-Content -LiteralPath "$runDir/retained-text-input-batch-20261108.structure-review.json" -Encoding utf8
$raw=@(foreach($pattern in @('retained-text-input-integrated-20261108*','retained-text-input-batch-20261108*','retained-text-input-20261108.owner-r7.*','retained-text-input-20261108.owner-r8.*','retained-text-input-20261108.owner-r9.*','retained-text-input-20261108.owner-r10.*','retained-text-input-20261108.owner-r11.*','run-retained-input-frozen-matrix-20261108.ps1','run-retained-input-cli-main-20261108.ps1','run-retained-text-input-batch-quality-20261108.ps1')){Get-ChildItem -LiteralPath $runDir -File -Filter $pattern})|Sort-Object FullName -Unique
$archive='docs/implementation/acceptance-evidence/task-retained-text-input-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive already exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($file in $raw){if($file.Extension -notin @('.log','.json','.patch','.txt','.ps1','.pathspec')){throw 'Unexpected raw entry'};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    foreach($file in Get-ChildItem -LiteralPath "$runDir/retained-text-input-batch-20261108.structure-report" -File){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,('structure/'+$file.Name),[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$PSCommandPath,(Split-Path $PSCommandPath -Leaf),[IO.Compression.CompressionLevel]::Optimal)|Out-Null
} finally {$zip.Dispose()}
$opened=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$entryCount=$opened.Entries.Count}finally{$opened.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$entryCount;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$record=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($record.PSObject.Properties.Name -contains 'retainedTextInputConsumers'){throw 'Consumer evidence exists'}
$entry=[ordered]@{version=1;date='2026-11-08';sourcePublication=$source;originalProduction='7af6e561ffa90716501e1ee0f15a397b666bffde';originalCoreConsumers=$original;completeOriginalInputGuard=(Read-Record 'retained-text-input-integrated-20261108.complete-source-guard-after.json');currentDriverConsumers=$current;cli=$cli;cliMain=(Read-Record 'retained-text-input-batch-20261108.cli.main-audit.json');newOwnerEpochs=$epochs;workspaceQuality=$quality;graph=$selected;partition=[ordered]@{reusedUnchangedOutsideDriverClosure=$reused.Count;replacedOriginalDriverCases=$replaced.Count;newDriverCases=$current.executed;logicalNonCli=($reused.Count+$current.executed);logicalIncludingCli=($reused.Count+$current.executed+$cli.executed);note='Logical unique coverage combines reused unaffected original input with current driver/CLI runs; it is not one fresh all-Core run. Focused owner cases are not added again.'};preservedPreparationFailures=@('noncli preparation 101, OS1455; no runtime','noncli-r2 preparation 101, OS1455; no runtime');nativeBinPreparation=(Read-Record 'retained-text-input-integrated-20261108.native-bin-preparation.receipt.json');structuralReview=$review;archive=$archiveInfo;scope='Owner/codec/player-batch boundary validated. Old source factory samples, named Action UI bridge, Scroll fixture and actual Native/Web capture remain independent unmet boundaries. Generic Match and other accepted cuts stay accepted.';preservedPriorRecords=@($record.PSObject.Properties).Count}
$wrapper=(ConvertTo-Json -InputObject ([ordered]@{retainedTextInputConsumers=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd()
$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $record.PSObject.Properties){if((ConvertTo-Json -InputObject $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress)){throw ('Historical record changed: '+$property.Name)}}
[ordered]@{priorRecords=@($record.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$archiveInfo;partition=$entry.partition}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$runDir/retained-text-input-consumers-record-audit.json" -Encoding utf8
Get-Content -LiteralPath "$runDir/retained-text-input-consumers-record-audit.json" -Raw
