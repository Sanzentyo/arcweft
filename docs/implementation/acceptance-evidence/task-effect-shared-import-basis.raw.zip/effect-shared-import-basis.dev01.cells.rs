#![allow(dead_code, unused_imports)]
#[path = "effect-shared-import-basis.dev01.baseline/effect_row.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/declaration.rs"]
mod declaration;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/membership.rs"]
mod membership;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/set.rs"]
mod set;

use std::collections::BTreeMap;

use decision::{DecisionControl, DecisionEncoding, DecisionWork, EffectDecision};
use declaration::EffectDeclarationError;
use membership::{EffectFormula, EffectPredicate, MembershipEncoding};
use set::EffectSet;

macro_rules! meter {
    ($kind:ident, $meter:ident, $work:ty, $control:path, $error:ty) => {
        #[derive(Default)]
        struct $meter { visits: usize, nodes: usize }
        impl $control for $meter {
            type Error = $error;
            fn charge(&mut self, work: $work) -> Result<(), Self::Error> {
                match work {
                    $kind::Visit => self.visits += 1,
                    $kind::Node => self.nodes += 1,
                }
                Ok(())
            }
        }
    };
}
use baseline::DecisionWork as PriorWork;
meter!(PriorWork, Prior, baseline::DecisionWork, baseline::DecisionControl, baseline::EffectDeclarationError);
meter!(DecisionWork, Current, DecisionWork, DecisionControl, EffectDeclarationError);

fn variable(index: u16, bits: u32) -> bool {
    (bits.rotate_left(u32::from(index % 31)) & 1) != 0
}

fn main() {
    let mut checked = 0;
    for width in [16u16, 256u16] {
        for referenced in [0u16, 1u16, 4u16, 16u16] {
            let source_refs: Vec<_> = (0..referenced)
                .map(|index| index * width / referenced)
                .collect();
            let former_source = source_refs.iter().fold(baseline::EffectDecision::constant(true), |prior, &index| {
                prior.and(
                    &baseline::EffectDecision::variable(index, &mut Prior::default()).unwrap(),
                    &mut Prior::default(),
                ).unwrap()
            });
            let source = source_refs.iter().fold(EffectDecision::constant(true), |current, &index| {
                current.and(
                    &EffectDecision::variable(index, &mut Current::default()).unwrap(),
                    &mut Current::default(),
                ).unwrap()
            });

            let mut before_bind = Prior::default();
            let mut after_bind = Current::default();
            let mut replacements = BTreeMap::new();
            for index in 0..width {
                baseline::DecisionControl::charge(&mut before_bind, PriorWork::Node).unwrap();
                replacements.insert(index, baseline::EffectDecision::variable(width + index, &mut before_bind).unwrap());
            }
            let old_bound = former_source.substitute(&replacements, &mut before_bind).unwrap();
            let new_bound = source.map_references(&mut after_bind, &mut |&index, _| Ok(width + index)).unwrap();
            assert_eq!(format!("{old_bound:?}"), format!("{new_bound:?}"));
            assert!(before_bind.nodes > after_bind.nodes);
            let mut before_eval = Prior::default();
            let mut after_eval = Current::default();
            for bits in [0, 1, u32::MAX, 0xaaaaaaaa, 0x55555555].into_iter().chain(0..512) {
                let transported = old_bound.map_references(&mut before_eval, &mut |&index, _| Ok(index)).unwrap();
                let zero = baseline::EffectDecision::constant(false);
                let one = baseline::EffectDecision::constant(true);
                let former_value = if transported.node_count() == 0 {
                    transported.copy_with_control(&mut before_eval).unwrap()
                } else {
                    transported.substitute_references(&mut before_eval, |&index, _| {
                        Ok(baseline::EffectDecisionReplacement::Decision(if variable(index, bits) { &one } else { &zero }))
                    }).unwrap()
                };
                let new_value = new_bound.try_evaluate_with_control(|&index| Ok(variable(index, bits)), &mut after_eval).unwrap();
                assert!(former_value.is_constant(new_value));
                assert_eq!(new_value, source_refs.iter().all(|&index| variable(width + index, bits)));
                checked += 1;
            }

            println!("width={width} referenced={referenced} attach_visits={}->{} attach_nodes={}->{} eval_visits={}->{} eval_nodes={}->{}",
                before_bind.visits, after_bind.visits, before_bind.nodes, after_bind.nodes,
                before_eval.visits, after_eval.visits, before_eval.nodes, after_eval.nodes);
        }
    }
    println!("valuations_checked={checked}");
}
