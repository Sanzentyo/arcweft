$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.unified-library-prewarm'
if (Test-Path "$prefix.receipt.json") { throw 'Unified library prewarm already exists' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.compiler-expectation-r2.source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" } }
}
Assert-Inputs
$arguments = @('nextest', 'list', '--locked', '--workspace', '--exclude', 'arcweft-cli', '--all-features', '--lib', '-E', 'rdeps(=arcweft-core)', '--message-format', 'json')
$started = [DateTime]::UtcNow
& cargo @arguments 1> "$prefix.selection.json" 2> "$prefix.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o'); purpose = 'Compile/list the unified workspace library test targets before the complete integration selection. This is cache preparation, not test execution; dependency feature composition is checked separately from the isolated package slices. Default jobs/features/profiles are unchanged.' } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.receipt.json"
Get-Content "$prefix.log" -Tail 5
exit $code
