$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$name = 'line-initial-inputs-20261108'
$audit = Get-Content (Join-Path $taskTemp "$name.integrated-consumers.audit.json") -Raw | ConvertFrom-Json -Depth 60
if ($audit.run -ne 8030 -or $audit.passed -ne 8026 -or $audit.failed -ne 4 -or $audit.duplicates -ne 0 -or $audit.reusedBinaryChecks.Count -ne 5) { throw 'Integrated audit unavailable' }
$archivePath = 'docs/implementation/acceptance-evidence/task-line-input-integrated-consumers.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Integrated archive exists' }
$files = @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
    $fileName = $_.Name
    if ($fileName -match '^line-initial-inputs-20261108\.consumer-split-r3\.(?<index>\d{3})\.') { return [int]$Matches['index'] -ge 54 }
    $fileName -like "$name.global-*" -or $fileName -like "$name.cli-full-check-parallel.*" -or $fileName -like "$name.cli-default-rest.*" -or $fileName -like "$name.parallel-intent-*" -or $fileName -like "$name.integrated-consumers.*" -or $fileName -like "$name.unified-library-prewarm.*" -or $fileName -match '^line-initial-inputs-20261108\.consumer-split-r3\.(source|plan|results|interrupted)\.(json|jsonl)$' -or $fileName -in @(
        "$name.metadata-all.json", "$name.reverse-tree.log", "$name.ownership-review-r2.json", "$name.completed-owner-evidence.verified.json",
        'record-line-input-integrated-consumers-20261108.ps1', 'audit-line-input-integrated-consumers-20261108.ps1', 'audit-line-input-integrated-consumers-r2-20261108.ps1', 'debug-line-input-integrated-case-partitions-20261108.ps1',
        'run-line-input-global-core-parallel-20261108.ps1', 'run-line-input-global-pure-owners-parallel-20261108.ps1', 'run-line-input-global-rest-20261108.ps1', 'run-line-input-cli-full-check-parallel-20261108.ps1', 'run-line-input-cli-default-rest-20261108.ps1', 'prewarm-line-input-unified-libraries-20261108.ps1'
    )
} | Sort-Object Name)
$entries = @(foreach ($file in $files) { [ordered]@{ entry = $file.Name; bytes = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant() } })
$archive = [IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archivePath), [IO.Compression.ZipArchiveMode]::Create)
try { foreach ($file in $files) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, $file.Name) } } finally { $archive.Dispose() }
$archive = [IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try {
    if ($archive.Entries.Count -ne $entries.Count) { throw 'Archive count differs' }
    foreach ($row in $entries) {
        $entry = $archive.GetEntry($row.entry)
        if (-not $entry -or $entry.Length -ne $row.bytes) { throw 'Archive shape differs' }
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($hash -ne $row.sha256) { throw "Archive entry differs: $($row.entry)" }
    }
} finally { $archive.Dispose() }
$record = [ordered]@{
    version = 1; date = '2026-11-08'; inspectedSource = $audit.source
    productionSource = '85021db282dcb038e0041a23ea41a354706b85bf'; compilerTestSource = 'db3b5e7655a78394c1fafd951fdd735a6571dfef'; completedOwnerEvidence = 'f267dc30d20a25092c64d08bb42b596b14ad3400'
    primaryMatrix = $audit
    totals = [ordered]@{ nonCli = [ordered]@{run=7319;passed=7319;failed=0;skipped=18}; cliDefault = [ordered]@{run=711;passed=707;failed=4;skipped=23}; total=[ordered]@{run=8030;passed=8026;failed=4;skipped=41} }
    composition = 'Non-CLI binaries use one full-workspace all-feature package/target composition, partitioned into Core unit, RuntimePlan/Sema/Compiler units, and their exact complement. CLI default targets are partitioned into check and its complement; five excluded binary paths and SHA256 identities match. The two feature points and five commands are not represented as one invocation.'
    parallelCoordination = 'Pure Sans-I/O unit runtime and independent public CLI check ran concurrently. Each command used four Cargo build jobs under the crates/AGENTS.md parallel-test resource-coordination exception; observed Cargo child arguments are retained. No test-thread/profile/assertion/budget/ignored-policy change. The later complement commands used default Cargo jobs.'
    supplemental = [ordered]@{packageSlices='Interrupted after 80 complete targets, 5273 PASS / 0 FAIL, preserving every completed receipt. Four completed owners remain in initialInputCompletedOwners. These different dependency-feature contexts are not added to primary totals.'; standardCliAllFeatures='228 PASS across library/bin and the standard six integration targets. This feature point is retained as supplemental, not added to the default CLI total.'; libraryPrewarm='Library-only target selection changes dependency feature composition; preparation was interrupted before any test execution and is not acceptance evidence.'}
    baseline = 'The earlier default-workspace 7962-run 7958 PASS / 4 FAIL / 41 SKIP result retains its original SHA/input. The current 8030-run matrix has different dated inputs and explicit feature partitions. All four failure IDs are exactly the same; counts are not merged or relabeled.'
    remaining = 'Authored Scroll shared-callable semantic resolution, a required VoiceHandle without real audio in fixture011, and two obsolete receiverless promotion inputs remain failed. Full promotion receiver admission remains a separate concrete implementation condition. Generic Match, Native, Line/init and bounded ordinary-defer/initial-input acceptance remain accepted. Other platform/Tier2/full Native-Web parity and broader goal acceptance are not inferred.'
    auditCorrection = 'The first case-partition audit used Group-Object property lookup on ordered dictionaries, which grouped all keys as empty. Converting audit rows to PSCustomObject established zero duplicate cases. No tests were rerun or modified by this audit preparation correction.'
    raw = [ordered]@{ path = Split-Path $archivePath -Leaf; sha256 = (Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant(); entries = $entries }
}
$ledgerPath = 'docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger = [IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if ($ledger.Contains('"initialInputIntegratedConsumers"')) { throw 'Integrated record exists' }
$fragment = ([ordered]@{ initialInputIntegratedConsumers = $record } | ConvertTo-Json -Depth 80).Trim().Replace("`r`n", "`n")
$last = $ledger.LastIndexOf('}')
$after = $ledger.Substring(0, $last).TrimEnd() + ",`n  " + $fragment.Substring(1, $fragment.Length - 2).Trim() + "`n}`n"
$null = $after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath), $after, [Text.UTF8Encoding]::new($false))
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$history = [IO.File]::ReadAllText((Join-Path (Get-Location) $historyPath))
$addition = @"

## 2026-11-08 — 初期 Line 入力のCore53統合consumer終端

検証基点 **f267dc30d20a25092c64d08bb42b596b14ad3400**。production Source **85021db282dcb038e0041a23ea41a354706b85bf**、Compiler cfg(test)訂正 Source **db3b5e7655a78394c1fafd951fdd735a6571dfef**。非CLIは同一のworkspace・全feature・lib／tests構成でCore単体2327、RuntimePlan／Sema／Compiler単体1714、残る逆依存3278の相補filterを実行し、**7319 PASS／18 SKIP**。CLI既定featureは全check471件の **467 PASS／4 FAIL／23 SKIP** と、その相補全target240 PASSで、**711 run／707 PASS／4 FAIL／23 SKIP**。計 **8030 run／8026 PASS／4 FAIL／41 SKIP**。単一コマンドや同一feature構成の全件runにはしない。全8030件の選択重複0、5境界の実binary path／SHA256同一、3416入力drift0を照合した。Core逆依存53 packageの実テストは50、compile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-webの3で、除外による未実行をPASSとは数えない。

旧workspace全feature catalogのOS1455失敗2回は前記録のまま保持する。個別packageのfeature差による再buildが続いたため80 target／5273 PASSで中断し、lib-only準備もfeature構成が異なるため中断した。両中断は実行済みテストの失敗や全件合格に置き換えない。独立する純粋なowner単体と全CLI checkを並行実行し、規約の資源配分例外に従って各Cargo buildを4 jobsとした。実子process引数を保存し、test threads・profile・assertion・原budget・ignored条件は維持した。後続の相補runはCargo既定jobs。CLI標準対象の全feature228 PASSと先行owner各件は補完証拠であり、今回の総数へ二重計上しない。

4失敗は旧Source b6df0c825805b9ac77cad6a9760761a861007679のIDと一致した。Scrollはshared callableの意味解析、fixture011は実音声なしの必須VoiceHandle、promotionの2件はreceiverなし旧入力がtype-checkで停止する。Generic Match／Native／Line-init／初期入力の既受入を戻す根拠とはしない。旧7962件の数値・SHAを保持した上で、現状の4 ownerのみの進捗表示とCLI710件表示を今回の終端へ置換した。初回監査のordered dictionary key参照ミスも残し、修正後の重複0を確認した。[全選択・feature分割・実binary・失敗・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText((Join-Path (Get-Location) $historyPath), $history.TrimEnd() + "`n" + $addition.Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$statusPath = 'docs/implementation/current-status.md'
$status = [IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$lines = @($status -split '\r?\n' | ForEach-Object {
    if ($_.StartsWith('| 共有契約／推移的逆依存matrix |')) {
        '| 共有契約／推移的逆依存matrix | **Core53の対象照合完了：8026 PASS／4 FAIL／41 SKIP** | 検証Source f267dc30d20a25092c64d08bb42b596b14ad3400。非CLIは同一workspace全feature構成の相補3 runで7319 PASS／18 SKIP、CLI既定feature全targetは相補2 runで711件中707 PASS／4 FAIL／23 SKIP。8030件に選択重複0、5境界のbinary path／SHA256同一、3416入力drift0。実テスト50 package、compile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-webの3。単一runや同一feature全件にはしない。先行4 owner4881 PASS・標準CLI全feature228 PASS・中断した個別5273 PASSは総数へ加えない。4失敗は次のCLI行で追跡し、旧件数・全SHA・初回OS1455は履歴へ保持する。[全選択・分割・実binary・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
    } elseif ($_.StartsWith('| CLIの規定対象／全 check 照合 |')) {
        '| CLIの規定対象／全 check 照合 | **CLI既定全711件：707 PASS／4 FAIL／23 SKIP** | 検証Source f267dc30d20a25092c64d08bb42b596b14ad3400。全check471件とその相補全target240件を実行し、標準対象外のbracket_numeric_batch／environment_callable_tensor／native_host_contractsも含む。失敗IDは旧b6df0c825805b9ac77cad6a9760761a861007679の4件と一致。authored Scrollのshared callable意味解析、fixture011の実音声なし必須VoiceHandle、receiverなし旧promotion入力2件が停止する。promotion本体は該当行で継続する。完了した監査・取消しcleanup・scalar修復を戻さない。[入力別結果・失敗ID・診断・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
    } elseif ($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')) {
        $_.Replace('最終統合・他platform／Tier2の受入へ拡張しない。', '全14 family・他platform／Tier2・全表示parityの最終受入へ拡張しない。')
    } else { $_ }
})
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath), ($lines -join "`n"), [Text.UTF8Encoding]::new($false))
[ordered]@{ source = $audit.source; run = $audit.run; passed = $audit.passed; failed = $audit.failed; skipped = $audit.skipped; entries = $entries.Count; sha256 = $record.raw.sha256 } | ConvertTo-Json -Compress
