$ErrorActionPreference='Stop'
$root=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
$source='e4d736ac55693fb2fae402e079fd465391cb62c7'
function Confirm-Source {
    if ((git rev-parse HEAD).Trim() -ne $source -or @(git diff HEAD --name-only).Count) { throw 'Source changed' }
}
Confirm-Source
$checks=@(
    @{name='wasm'; args=@('check','--locked','--target','wasm32-unknown-unknown','--all-features','--lib','-p','arcweft-player-web','-p','arcweft-render-web')},
    @{name='structure'; args=@('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')}
)
$results=@(foreach ($check in $checks) {
    $log='flow-static-type-'+$check.name+'.log'
    $cargoArgs=$check.args
    $watch=[Diagnostics.Stopwatch]::StartNew()
    & cargo @cargoArgs *> (Join-Path $root $log)
    $code=$LASTEXITCODE
    $watch.Stop()
    Confirm-Source
    [ordered]@{name=$check.name; arguments=$cargoArgs; elapsedSeconds=$watch.Elapsed.TotalSeconds; exitCode=$code; log=$log}
})
[ordered]@{version=1;source=$source;checks=$results} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $root 'flow-static-type-platform-quality.json') -Encoding utf8
$results | ConvertTo-Json -Depth 4 -Compress
if (@($results | Where-Object {$_.exitCode -ne 0}).Count) { exit 1 }