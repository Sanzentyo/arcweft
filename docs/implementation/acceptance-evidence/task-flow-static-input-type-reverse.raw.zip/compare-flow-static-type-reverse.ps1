$ErrorActionPreference='Stop'
$root=Join-Path $env:TEMP 'arcweft-1011-convergence-resume-cb798c1d'
$before='flow-transfer-convergence-reverse-run-reference-r2'
$after='flow-transfer-convergence-reverse-run-static-type-r2'
function Read-Result([string]$prefix) {
    Get-Content -LiteralPath (Join-Path $root ($prefix+'.results.json')) -Raw | ConvertFrom-Json
}
function Read-Tests([string]$prefix) {
    $statuses=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
    foreach ($line in [IO.File]::ReadLines((Join-Path $root ($prefix+'.log')))) {
        if ($line -match '^\s+(PASS|FAIL|SKIP|TIMEOUT|LEAK)\s+\[[^\]]+\]\s+\([^)]+\)\s+(\S+)\s+(.+?)\s*$') {
            $id=$Matches[2]+' '+$Matches[3]
            if (!$statuses.TryAdd($id,$Matches[1]) -and $statuses[$id] -cne $Matches[1]) { throw ('Conflicting status '+$id) }
        }
    }
    return ,$statuses
}
$beforeResult=Read-Result $before
$afterResult=Read-Result $after
$beforeTests=Read-Tests $before
$afterTests=Read-Tests $after
$added=@($afterTests.Keys | Where-Object {!$beforeTests.ContainsKey($_)} | Sort-Object)
$removed=@($beforeTests.Keys | Where-Object {!$afterTests.ContainsKey($_)} | Sort-Object)
$changed=@($afterTests.Keys | Where-Object {$beforeTests.ContainsKey($_) -and $beforeTests[$_] -cne $afterTests[$_]} | Sort-Object | ForEach-Object {[ordered]@{id=$_;before=$beforeTests[$_];after=$afterTests[$_]}})
$cli=@($afterTests.Keys | Where-Object {$_ -match '^arcweft-cli(?:::| )'})
$notCli=@($afterTests.Keys | Where-Object {$_ -notmatch '^arcweft-cli(?:::| )'})
$actualLog=Join-Path $root ($after+'.log')
$priorDiagnostics=Get-Content -LiteralPath (Join-Path $root 'flow-reference-cli-diagnostics.json') -Raw | ConvertFrom-Json
$diagnostics=@(foreach ($item in $priorDiagnostics.diagnostics) {
    $actual=@([IO.File]::ReadLines($actualLog) | Where-Object {$_ -match $item.pattern} | Sort-Object -Unique)
    [ordered]@{pattern=$item.pattern;before=$item.common;after=$actual;matches=(@(Compare-Object -ReferenceObject @($item.common) -DifferenceObject $actual -CaseSensitive).Count -eq 0)}
})
$result=[ordered]@{
    version=1;beforeSource=$beforeResult.source;afterSource=$afterResult.source;
    beforeTests=$beforeTests.Count;afterTests=$afterTests.Count;added=$added;removed=$removed;statusChanged=$changed;
    beforeFailures=$beforeResult.nonPassing;afterFailures=$afterResult.nonPassing;
    cli=@($cli | ForEach-Object {$afterTests[$_]} | Group-Object | Select-Object Name,Count);
    nonCli=@($notCli | ForEach-Object {$afterTests[$_]} | Group-Object | Select-Object Name,Count);
    cliDiagnostics=$diagnostics
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $root 'flow-static-type-reverse-delta.json') -Encoding utf8
$result | ConvertTo-Json -Depth 8 -Compress