param([Parameter(Mandatory)][string]$Attempt)
$ErrorActionPreference = 'Stop'
$e = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
$inputRecord = Get-Content -Raw -LiteralPath (Join-Path $e "flow-transfer-convergence-reverse-$Attempt.inputs.json") | ConvertFrom-Json
$prefix = 'flow-transfer-convergence-reverse-run-' + $Attempt
$log = Join-Path $e ($prefix + '.log')
if (Test-Path -LiteralPath $log) { throw 'Run log already exists' }
function Assert-Frozen {
    if ((& git rev-parse HEAD).Trim() -ne $inputRecord.source -or (& git rev-parse 'HEAD^{tree}').Trim() -ne $inputRecord.tree -or @(git diff HEAD --name-only).Count -or @(git diff --cached --name-only).Count) { throw 'Source/index changed' }
}
Assert-Frozen
$rawCatalog = [IO.File]::ReadLines((Join-Path $e "flow-transfer-convergence-reverse-list-$Attempt.log")) | Where-Object {$_.StartsWith('{')} | Select-Object -Last 1
if (!$rawCatalog) { throw 'No list catalog' }
$catalog = $rawCatalog | ConvertFrom-Json -AsHashtable
$catalogPath = Join-Path $e ($prefix + '.catalog.json')
[IO.File]::WriteAllText($catalogPath, $rawCatalog, [Text.UTF8Encoding]::new($false))
$selected = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$binaries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$suitePackages = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($suite in $catalog.'rust-suites'.Values) {
    if ($suite.'package-name' -notin $inputRecord.packages) { throw ('Unexpected package: ' + $suite.'package-name') }
    foreach ($test in $suite.testcases.Keys) {
        if ($suite.testcases[$test].'filter-match'.status -ne 'matches') { continue }
        if (!$selected.Add($suite.'binary-id' + ' ' + $test)) { throw ('Duplicate selected test: ' + $test) }
        [void]$binaries.Add($suite.'binary-path')
        [void]$suitePackages.Add($suite.'package-name')
    }
}
if (!$selected.Count) { throw 'No tests selected' }
foreach ($p in @('arcweft-core','arcweft-lang-sema','arcweft-runtime-plan','arcweft-compiler','arcweft-cli')) {
    if (!$suitePackages.Contains($p)) { throw ('No tests selected for owner ' + $p) }
}
$generic = Get-Content -Raw -LiteralPath (Join-Path $e 'flow-transfer-convergence-generic-reference.json') | ConvertFrom-Json
if ($generic.count -ne 151 -or @($generic.rows).Count -ne 151) { throw 'Incomplete Generic Match reference' }
$styleOriginal = 'final_analysis::tests::semantic_transcript_acceptance::expression_corpus::contextual_expressions::style_length_values_use_registered_roots_and_shared_scalar_reduction'
$styleSuccessor = 'final_analysis::tests::semantic_transcript_acceptance::expression_corpus::contextual_expressions::style_length_values_use_specified_values_and_exact_decimal_scaling'
$caseMap = @($generic.rows | ForEach-Object {
    $test = $_.test
    $migrations = @()
    if ($_.binary -ceq 'arcweft-lang-sema' -and $test -ceq $styleOriginal -and !$selected.Contains($_.binary+' '+$test)) {
        $test = $styleSuccessor
        $migrations = @('c4824f38ebce38305adb7f8ac757e13edb4b8e4e','300162fe9b638be752b4661e1daf5bae85151081')
    }
    [ordered]@{group=$_.group;binary=$_.binary;originalTest=$_.test;test=$test;migrations=$migrations;selected=$selected.Contains($_.binary+' '+$test)}
})
$missing = @($caseMap | Where-Object { !$_.selected })
if ($missing.Count) { $missing | ConvertTo-Json -Depth 4; throw 'Missing Generic Match coverage before run' }
$mapped = @($caseMap | Where-Object {$_.migrations.Count}).Count
$uniqueCases = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($row in $caseMap) { [void]$uniqueCases.Add($row.binary + ' ' + $row.test) }
if ($mapped -ne 1 -or $uniqueCases.Count -ne 151) { throw ("Unexpected Generic Match mapping: mapped=$mapped unique=" + $uniqueCases.Count) }
$transferIds = @(
    'arcweft-compiler::flow_transfer explicit_flow_inputs_reach_the_native_receiving_root'
    'arcweft-compiler::flow_transfer explicit_flow_inputs_reach_the_decoded_awbc_receiving_root'
    'arcweft-lang-sema final_analysis::tests::execution_inputs::borrowed_formal_receivers_keep_their_original_execution_input_access'
    'arcweft-cli::check bench_json_measures_runtime_match_to_pure_jit_characteristics'
    'arcweft-compiler::scoped_defer rejected_dynamic_goto_runs_failure_cleanup_without_completing_its_scope'
    'arcweft-core awbc::tests::dynamic_goto_verification_rejects_a_text_label_for_an_existing_flow'
    'arcweft-core tests::flow::invocation::static_flow_transfer_rejects_incompatible_local_at_its_formal_coordinate'
    'arcweft-core engine::defer::tests::native_goto_finishes_inner_and_caller_cleanup_before_transferring'
)
foreach ($id in $transferIds) { if (!$selected.Contains($id)) { throw ('Missing Flow transfer test: '+$id) } }
foreach ($packageBins in $catalog.'rust-build-meta'.'non-test-binaries'.Values) {
    foreach ($binary in $packageBins) {
        if ($binary.kind -ne 'bin-exe') { continue }
        [void]$binaries.Add((Join-Path $catalog.'rust-build-meta'.'target-directory' $binary.path))
    }
}
if (!$binaries.Contains('D:\git\arcweft\target\debug\arcw.exe')) { throw 'Cargo list has no original arcw.exe' }
function Read-BinaryPins {
    @(foreach ($path in ($binaries | Sort-Object)) {
        $file = Get-Item -LiteralPath $path
        [ordered]@{path=$path;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
    })
}
$args = @('nextest','run','--no-fail-fast','--no-tests','fail') + @($inputRecord.cargoArgs[2..($inputRecord.cargoArgs.Count - 1)] | Where-Object {$_ -notin @('--message-format','json')})
$runInput = [ordered]@{version=1;source=$inputRecord.source;tree=$inputRecord.tree;packageCount=$inputRecord.packageCount;packages=$inputRecord.packages;selectedCount=$selected.Count;testPackages=@($suitePackages | Sort-Object);packagesWithNoSelectedTests=@($inputRecord.packages | Where-Object {!$suitePackages.Contains($_)});catalogSha256=(Get-FileHash -LiteralPath $catalogPath).Hash.ToLowerInvariant();binaryCount=$binaries.Count;genericExactMatches=150;genericMapped=$mapped;transferMatches=$transferIds.Count;cargoArgs=$args}
$runInput | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.inputs.json')) -Encoding utf8
Write-Output ('Selected '+$selected.Count+' test IDs across '+$suitePackages.Count+' test packages; pinned 150 exact Generic Match IDs, one audited Style test successor, and 8 Flow transfer and CLI IDs.')
$before = Read-BinaryPins
$before | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-before.json')) -Encoding utf8
Assert-Frozen
$watch = [Diagnostics.Stopwatch]::StartNew()
& cargo @args *> $log
$code = $LASTEXITCODE
$watch.Stop()
$after = Read-BinaryPins
$after | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-after.json')) -Encoding utf8
$drift = @()
for ($i = 0; $i -lt $before.Count; $i++) {
    if ($before[$i].path -ne $after[$i].path -or $before[$i].bytes -ne $after[$i].bytes -or $before[$i].sha256 -ne $after[$i].sha256) { $drift += $after[$i].path }
}
Assert-Frozen
$statuses = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
foreach ($line in [IO.File]::ReadLines($log)) {
    if ($line -match '^\s+(PASS|FAIL|SKIP|TIMEOUT|LEAK)\s+\[[^\]]+\]\s+\([^)]+\)\s+(\S+)\s+(.+?)\s*$') {
        $statuses[$Matches[2] + ' ' + $Matches[3]] = $Matches[1]
    }
}
$genericRows = @($caseMap | ForEach-Object { [ordered]@{group=$_.group;binary=$_.binary;originalTest=$_.originalTest;test=$_.test;migrations=$_.migrations;status=$statuses[$_.binary+' '+$_.test]} })
$transferRows = @($transferIds | ForEach-Object { [ordered]@{id=$_;status=$statuses[$_]} })
$result = [ordered]@{version=1;source=$inputRecord.source;tree=$inputRecord.tree;exitCode=$code;elapsedSeconds=$watch.Elapsed.TotalSeconds;sourceDrift=0;binaryDrift=$drift;summary=@([IO.File]::ReadLines($log) | Where-Object {$_ -match 'Summary \['});testStatuses=@($statuses.Values | Group-Object | Select-Object Name,Count);nonPassing=@($statuses.Keys | Where-Object {$statuses[$_] -ne 'PASS'} | Sort-Object);genericMatch=$genericRows;flowTransfer=$transferRows}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $e ($prefix+'.results.json')) -Encoding utf8
[ordered]@{exitCode=$code;seconds=$watch.Elapsed.TotalSeconds;binaryDrift=$drift.Count;summary=$result.summary;genericPassed=@($genericRows | Where-Object {$_.status -eq 'PASS'}).Count;flowTransfer=$transferRows} | ConvertTo-Json -Depth 6 -Compress
exit $code
