param([Parameter(Mandatory)][string]$Binary)
$ErrorActionPreference='Stop'
$d=Split-Path -Parent $PSCommandPath
$owner=Get-Content -LiteralPath (Join-Path $d 'probe-expression-edit.dev02-sema.result.json') -Raw | ConvertFrom-Json -AsHashtable
if((git rev-parse HEAD) -ne $owner.base){throw 'Unexpected measurement base.'}
foreach($path in $owner.blobs.Keys){
    if((git hash-object --path=$path -- $path) -ne $owner.blobs[$path]){throw "Changed validated blob $path."}
}
$env:PATH=(Split-Path -Parent (uv python find 3.11 --no-project --offline).Trim())+';'+$env:PATH
$test='final_analysis::tests::t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once'
$recipe=Join-Path $d 'application-edit.current-budget-edges.lldb'
$exe=(Resolve-Path -LiteralPath $Binary).Path
$sha=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
$name='probe-expression-edit.current-budget-edges.lldb.log'
$log=Join-Path $d $name
& lldb --batch -s $recipe -- $exe --exact $test --nocapture *> $log
$code=$LASTEXITCODE
$after=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant()
if($sha -ne $after){throw 'Measurement binary changed.'}
[ordered]@{
    version=1; base=$owner.base; blobs=$owner.blobs; binary=$exe; binary_sha256=$sha;
    test=$test; lldb_exit=$code; log=$name; log_sha256=(Get-FileHash -LiteralPath $log).Hash.ToLowerInvariant();
    observed_at=(Get-Date).ToString('o')
} | ConvertTo-Json -Depth 6 | Tee-Object -FilePath (Join-Path $d 'probe-expression-edit.current-budget-edges.json')
Select-String -LiteralPath $log -Pattern 'stop reason|frame #[0-9]+:|test result:' | Select-Object -First 22 -ExpandProperty Line

