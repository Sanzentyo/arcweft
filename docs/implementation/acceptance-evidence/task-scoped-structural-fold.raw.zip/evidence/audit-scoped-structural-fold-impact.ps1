$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/scoped-structural-fold.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/scoped-structural-fold.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {$changed=$false;foreach($node in $metadata.resolve.nodes){if(!$closure.Contains($node.id)){foreach($dependency in $node.deps){if($closure.Contains($dependency.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/free-port-admission.impact.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count){throw 'Reverse graph changed'}
$consumers=Get-Content -Raw "$root/scoped-structural-fold.consumer-summary.json"|ConvertFrom-Json
if($consumers.Source -ne $pub.Source -or $consumers.Targets -ne 107 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$consumers.IdsEqual -or $consumers.Duplicates){throw 'Fresh consumer coverage differs'}
$inputs=@(git diff --name-only $previous.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml')
if($inputs.Count){throw 'Cargo graph inputs changed'}
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='scoped-structural-fold.reverse-tree.txt';CargoInputsUnchanged=$true;ReverseConsumersRerun=$true;FreshTargets=$consumers.Targets;FreshPassed=$consumers.Passed;FreshFailed=$consumers.Failed;FreshSkipped=$consumers.Skipped;Reason='Both production scoped type transport and phase effect-domain projection now use one structural fold. Canonical type/const/effect/predicate transport and nested binder accounting affect every semantic consumer, so the fresh resolved reverse closure and all prescribed targets are rerun. Prior case inventories and failure diagnoses are comparison inputs only.'}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/scoped-structural-fold.impact.json"
Write-Output "Verified fresh reverse closure: $($packages.Count) packages, 107 consumer targets"

$tree=[IO.File]::ReadAllText("$root/scoped-structural-fold.reverse-tree.txt")
$workspace=@($metadata.packages|Where-Object {$metadata.workspace_members -ccontains $_.id}|ForEach-Object name)
$treePackages=@([regex]::Matches($tree,'(?m)([a-z][a-z0-9-]+) v[0-9][^\s]*')|ForEach-Object {$_.Groups[1].Value}|Where-Object {$workspace -ccontains $_}|Sort-Object -Unique)
if(@(Compare-Object -CaseSensitive @($packages.name|Sort-Object) $treePackages).Count){throw 'Resolved closure differs from all-target reverse tree'}
Write-Output "Verified tree/metadata package identities: $($treePackages.Count)"