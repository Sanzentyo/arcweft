$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/scoped-structural-fold.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/scoped-structural-fold.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$scratch/scoped-structural-fold.consumer-summary.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/scoped-structural-fold.broad-quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/scoped-structural-fold.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/scoped-structural-fold.archive.json"|ConvertFrom-Json
$checkpoint=Get-Content -Raw "$scratch/scoped-structural-fold.checkpoint-publication.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Documentation base changed'}
if($owner.Selected -ne 1762 -or $owner.Passed -ne 1756 -or $owner.Failed -ne 6 -or !$owner.IdsEqual -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or $consumers.Targets -ne 107 -or !$consumers.IdsEqual -or $quality.Steps.Count -ne 3 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.ExitCode -ne 0 -or !$archive.AllEntriesVerified){throw 'Final validation differs'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previousStatus=[IO.File]::ReadAllText((Join-Path $PWD $status))
$previousHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previousStatus,'(?m)^\| Generic Match[^\r\n]+').Value
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$rows['再帰関数値の終端効果']="| 再帰関数値の終端効果 | **既受入と本体効果closureの接続を維持。型の移送処理を統合・検証・公開。本体内の関数値推論は継続** | 最新Source ``$($pub.Source)``。canonicalな型・const・効果・predicateの置換とprepared／canonical効果domain変換を一つの反復foldへ統合した。source／targetの字句scopeを入れ子のbinderまで保持し、置換値をsource環境で再解釈しない。借用rootと共有scopeで不要な複製を除き、実際のbinder複製前には既存controlで課金する。Source ``898b007aa9e43187d4cb5b9fa52f3bed59750f4a`` の型検査済み本体closureは、元のformal・D・実call置換を共有scheme graphへ渡して原子的に公開する。caller-bound recursion・共有prefix・Free許可／reify・実owner replayと予算接続の受入を維持する。型検査前の宣言scheme登録、prepared型を含む全関数値port／Γ統合、body一回準備・一括sealとeager経路の置換、一般量化消去・MGU／rank・Fn局所∀は継続する。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[本体closure](convergence-evidence-history.md#callable-body-declaration-scheme-closure)・[型移送の統合](convergence-evidence-history.md#shared-scoped-type-projection)。 |"
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,756 PASS／6 FAIL。後続21 packageも今回再実行** | Source ``$($pub.Source)`` のlocked・全feature Sema lib／tests 1,762件を$($owner.ExecutionSeconds)秒で実行。直前1,760 ID保持・新2件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeの22 packageから後続21 package／107 targetを再実行し、全2,510件／2,507 PASS／2 FAIL／1 SKIP。選択／終端ID一致・重複0、Compiler既知2失敗とcompile-only 3 targetも照合した。共通foldの統合と再帰本体の関数値推論の修復を区別する。[owner・consumer・全SHA原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$rows['CLIの規定対象／全 check 照合']="| CLIの規定対象／全 check 照合 | **最新の規定226件PASS。全 check は未再実行** | Source ``$($pub.Source)`` のlocked・既定feature／filterでlibrary 196件と規定の統合6 target 30件を今回実行し、226 PASS。binはcompile済み・runnable test 0件。選択／終端ID一致・重複0。以前の入力・失敗・公開SHAは履歴へ保持する。[今回のCLI原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace品質・doctest・fmt・構造gateを再実行し終了0** | Source ``$($pub.Source)`` のlocked workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateを実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。6 Rust path・$($owner.PhysicalGrowth)物理LOC増。共有型grammarのownerとscalar projectionの責任を分け、二重の走査を削除した。公開API・Cargo依存・I/O・codec・version・予算は変更せず、fan-in／out $($owner.FanIn)／$($owner.FanOut)も不変。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。Tier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入は今回未実行。[品質・構造・原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$current=$previousStatus
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
    if([regex]::Matches($current,$pattern).Count -ne 1){throw "Missing/duplicate row $key"}
    $replacement=$rows[$key]
    $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-14。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
$entry=@"

## Shared scoped type projection

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの6 Rust pathを通常commit／非force pushし、検証dirty bytes・commit・公開blobを照合した。Source push時点の完了consumer group数 $($checkpoint.CompletedGroups)／20もcheckpointに保持した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- TypeKindのshared grammarであるTypeConstraintShapeを用い、canonical templateの型・const・効果・predicate移送と、prepared／canonical effect-domain変換を一つの反復structural foldへ移した。二つの旧反復walkと独自frameを削除し、新たな第三の走査は残さない。scalar portの解釈と従来のdepth計測はそれぞれのphase adapterへ保持する。依存方向・公開API・I/O・codec・契約version・既定予算は変更しない。
- source／targetは別の字句scopeを保持し、各nested function binderで双方を拡張する。rootは借用し、子frameはimmutable scopeのleaseだけを共有する。非empty binderの実複製は、複製する既存bindingと新bindingを元のTypeProjectionControlで事前に課金する。同じscopeのstorage共有判定は最適化だけであり、意味的な型・効果の等値やowner認証には使わない。
- GenericParamの置換値はscalar portが返した時点のtarget環境に属する。foldはその内部をsource環境で再訪しない。新2件は、異なるsource／targetとnested binder、実prepared効果domainへの全4 port移送、置換値のopacity、scopeコピー前の全予算点、取消し時の入力保全を確認した。既存の9件も含む開発subset 11 PASS。その前の開発checkは既存テストの親import依存で失敗し、テスト側の直接importへ修復した。開発logも保持し、完全snapshotのない開発runを最終Sourceの証拠にしない。
- 最終ownerは1,762件／1,756 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,760 ID保持・新2件PASS、選択／終端ID一致・重複0。既知6件の5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh full metadata／全target reverse treeの22 packageから後続21 package／107 targetを今回実行し、2,510件／2,507 PASS／2 FAIL／1 SKIP。CLI規定226 PASS、Compiler既知2失敗、compile-only 3 targetと全終端IDを照合した。
- workspace全target／全feature check・Clippy、Sema doctest 2件、workspace fmt、構造gateは今回Sourceで終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。6 path・$($owner.PhysicalGrowth)物理LOC増。共通foldは既存の型ownerの構造とscopeを所有し、phase固有の置換・algebraをadapterへ残す。状態の二重authorityや公開範囲の拡大はない。実LOC・byte size・test分類とfan-in $($owner.FanIn)／fan-out $($owner.FanOut)を原本へ保持した。CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- Supersedes: 型の構造移送をcanonical用とeffect-domain用の別walkで維持していた状態を、共通foldへの統合済みへ訂正する。このcutの受入境界は移送処理の統合であり、上記の失敗6件を解消した判定ではない。残作業の列挙は履歴に重ねず、現状一覧の該当行へ集約する。Generic Match、本体効果closure、caller-bound recursion、共有prefix、Free許可／reifyと各既受入は維持する。過去の全SHA・実測・失敗・原本は変更せず、現状一覧は[current-status.md](current-status.md)だけに置く。

原本 [task-scoped-structural-fold.raw.zip](acceptance-evidence/task-scoped-structural-fold.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
foreach($document in @($rows.Values)+@($entry)){
    foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
        $target=$match.Groups[1].Value
        if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
        if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link $target"}
    }
}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText((Join-Path $PWD $history),"`n"+$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($previousHistory.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if($after.Length -le $previousHistory.Length -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($previousHistory)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical archive index changed'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$previousHistory.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true;FinalWhitespaceExit=0}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/scoped-structural-fold.docs-validation.json"
git diff --stat
