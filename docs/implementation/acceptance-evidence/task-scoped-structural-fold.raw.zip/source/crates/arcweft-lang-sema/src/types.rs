use crate::effect_row::{EffectPredicate, EffectRow};
use arcweft_character::id::{CharacterId, CharacterPartId};
use arcweft_id::DeclarationIdentityFamily;
use arcweft_id::closed_enum::ClosedEnumDomainId;
use arcweft_lang_syntax::{
    ast::module_path::ModulePathRoot, literal::IntSuffix, reference::BorrowKind, types::TypePath,
};
use core::fmt;

use crate::registration::StandardStatementIngressTypeId;

mod agent_fields;
mod compatibility;
pub(crate) mod constraints;
mod digest;
mod effect_domain;
mod generic_use;
mod generics;
mod match_domain;
mod mismatch;
mod nominal;
mod openness;
mod order;
mod project_nominal_visit;
mod projection_control;
mod structural_projection;
mod style;
mod substitution;
mod variant_payload;

pub use arcweft_core::character_nominal::{CharacterNominalFamily, CharacterNominalType};
pub use arcweft_dialogue::{CharacterDialogueCharacterType, CharacterDialogueType};
pub(crate) use compatibility::{
    NoopTypeCompatibilityControl, TypeCompatibilityControl, TypeCompatibilityFailure,
    TypeCompatibilityForbidden, TypeCompatibilityPolicy,
};
pub(crate) use constraints::ConstraintAcceptance;
#[cfg(test)]
pub(crate) use constraints::NoConstraintClient;
pub use constraints::TypeInstantiationError;
pub use constraints::{CheckedConstraintContainerConstructor, CheckedConstraintSourceProjection};
pub use digest::SemanticTypeDigest;
pub use effect_domain::{CanonicalEffects, TypeEffectDomain};
pub(crate) use effect_domain::{
    PreparedEffects, PreparedTypeEffectProjectionFailure, PreparedTypeRetentionFailure,
};
pub(crate) use generic_use::TypeGenericUseCollector;
pub use generic_use::TypeGenericUseError;
pub(crate) use generic_use::{
    StableGenericReferenceUseCollector, TypeGenericReferenceUseCollector,
};
pub use generics::{
    BoundConstParameter, BoundEffectParameter, BoundTypeParameter, GenericBinder,
    GenericConstReference, GenericEffectReference, GenericParameterKind, GenericScope,
    GenericScopeError, GenericTypeReference, InferenceConstParameter, InferenceEffectParameter,
    InferenceTypeParameter, ScopedArrayLengthView, ScopedConstReferenceView,
    ScopedEffectPredicateView, ScopedEffectReferenceView, ScopedEffectRowView,
    ScopedTypeReferenceView, ScopedTypeView, ScopedView,
};
pub(crate) use generics::{GenericDeclarationBinder, ScopedType};
pub(crate) use match_domain::{MatchDomainFamily, MatchDomainInvalidity};
pub use mismatch::{TypeMismatch, TypeMismatchPathSegment, TypeMismatchReason};
pub use nominal::{
    AcceptedNominalType, DetachedGenericOwnerId, GenericConstParameterId, GenericEffectParameterId,
    GenericParameterOwnerId, GenericTypeParameterId, LanguageIntrinsicGenericOwner,
    OpenNominalType, ProjectNominalType, TypePoisonId,
};
pub(crate) use project_nominal_visit::visit_project_nominals;
pub(crate) use projection_control::UnmeteredTypeProjection;
pub use projection_control::{TypeProjectionControl, TypeProjectionError, TypeProjectionNodeKind};
pub(crate) use projection_control::{visit_effect_predicate, visit_effect_row};
pub use style::{CompileTimeStyleType, StyleNumericType};
pub(crate) use substitution::TypeParameterSubstitutions;
pub(crate) use substitution::contains_generic_parameter;
pub(crate) use variant_payload::{
    AcceptedVariantCaseSemanticId, AcceptedVariantPayloadFieldSemanticId,
    VariantPayloadTypeChildren,
};
pub use variant_payload::{
    CheckedVariantPayload, VariantPayloadOwnerFamily, VariantPayloadRecordField,
    VariantPayloadRecordTypeField, VariantPayloadSealError, VariantPayloadShape,
    VariantPayloadTupleField, VariantPayloadType, VariantPayloadTypeShape,
};

/// Shared semantic selector retained by checked types and executable keys.
pub use arcweft_id::LifetimeScopeKind;

/// Statically known or deliberately unresolved length of an array type.
///
/// Array lengths are semantic values, not source spellings. In particular,
/// generic array lengths retain the declaration-owned parameter identity that
/// introduced them; they are never represented by a convention such as
/// `"N"`. `Inferred` is reserved for checker-local inference where no authored
/// length was supplied, while authored resolution failures retain their
/// diagnostic identity through `Error`.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ArrayLength {
    /// A concrete compile-time length.
    Const(usize),
    /// A declaration-owned generic constant length.
    Generic(GenericConstReference),
    /// A resolver-owned error already reported for this length.
    Error(TypePoisonId),
    /// A checker-local length that remains to be inferred.
    Inferred,
}

impl ArrayLength {
    #[must_use]
    pub fn generic_parameter(parameter: GenericConstParameterId) -> Self {
        Self::Generic(GenericConstReference::Free(parameter))
    }

    /// Returns the diagnostic and tooling spelling for this semantic length.
    #[must_use]
    pub(crate) fn source_label(&self) -> String {
        match self {
            Self::Const(value) => value.to_string(),
            Self::Generic(parameter) => parameter.source_label(),
            Self::Error(poison) => format!("<array-length-error:{}>", poison.index()),
            Self::Inferred => "_".to_owned(),
        }
    }
}

impl fmt::Display for ArrayLength {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(&self.source_label())
    }
}

/// Entity family used by semantic references and ID checks.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum EntityKind {
    Agent,
    Entry,
    Flow,
    Choice,
    ChoiceOption,
    Character,
    View,
    Action,
    Activity,
    DialogueLine,
    Text,
    Content,
    Input,
    Button,
    Style,
    Asset,
    Image,
    Animation,
    Capture,
    Hook,
    Signal,
    Metric,
    Scene,
    Test,
    Bench,
    Layer,
    Voice,
    Se,
    Bgm,
    AudioBus,
    MixerSnapshot,
    Ducking,
    Motion,
    Rig,
    Slot,
    Target,
    Other(String),
}

impl EntityKind {
    pub fn reference_family(&self) -> Option<arcweft_id::ProjectEntityReferenceFamily> {
        use arcweft_id::ProjectEntityReferenceFamily as Family;
        Some(match self {
            EntityKind::Agent => Family::Agent,
            EntityKind::Entry => Family::Entry,
            EntityKind::Flow => Family::Flow,
            EntityKind::Choice => Family::Choice,
            EntityKind::ChoiceOption => Family::ChoiceOption,
            EntityKind::Character => Family::Character,
            EntityKind::View => Family::View,
            EntityKind::Action => Family::Action,
            EntityKind::Activity => Family::Activity,
            EntityKind::DialogueLine => Family::DialogueLine,
            EntityKind::Text => Family::Text,
            EntityKind::Content => Family::Content,
            EntityKind::Input => Family::Input,
            EntityKind::Button => Family::Button,
            EntityKind::Style => Family::Style,
            EntityKind::Asset => Family::Asset,
            EntityKind::Image => Family::Image,
            EntityKind::Animation => Family::Animation,
            EntityKind::Capture => Family::Capture,
            EntityKind::Hook => Family::Hook,
            EntityKind::Signal => Family::Signal,
            EntityKind::Metric => Family::Metric,
            EntityKind::Scene => Family::Scene,
            EntityKind::Test => Family::Test,
            EntityKind::Bench => Family::Bench,
            EntityKind::Layer => Family::Layer,
            EntityKind::Voice => Family::Voice,
            EntityKind::Se => Family::Se,
            EntityKind::Bgm => Family::Bgm,
            EntityKind::AudioBus => Family::AudioBus,
            EntityKind::MixerSnapshot => Family::MixerSnapshot,
            EntityKind::Ducking => Family::Ducking,
            EntityKind::Motion => Family::Motion,
            EntityKind::Rig => Family::Rig,
            EntityKind::Slot => Family::Slot,
            EntityKind::Target => Family::Target,
            EntityKind::Other(_) => return None,
        })
    }

    /// Fixed entity families that may appear as contextual authored type atoms.
    pub const AUTHORED_FAMILIES: &'static [Self] = &[
        Self::Agent,
        Self::Entry,
        Self::Flow,
        Self::Choice,
        Self::ChoiceOption,
        Self::Character,
        Self::View,
        Self::Action,
        Self::Activity,
        Self::DialogueLine,
        Self::Text,
        Self::Content,
        Self::Input,
        Self::Button,
        Self::Style,
        Self::Asset,
        Self::Image,
        Self::Animation,
        Self::Capture,
        Self::Hook,
        Self::Signal,
        Self::Metric,
        Self::Scene,
        Self::Test,
        Self::Bench,
        Self::Layer,
        Self::Voice,
        Self::Se,
        Self::Bgm,
        Self::AudioBus,
        Self::MixerSnapshot,
        Self::Ducking,
        Self::Motion,
        Self::Rig,
        Self::Slot,
        Self::Target,
    ];

    /// Canonical source spelling for a fixed authored entity family.
    #[must_use]
    pub const fn authored_type_name(&self) -> Option<&'static str> {
        Some(match self {
            Self::Agent => "Agent",
            Self::Entry => "Entry",
            Self::Flow => "Flow",
            Self::Choice => "Choice",
            Self::ChoiceOption => "ChoiceOption",
            Self::Character => "Character",
            Self::View => "View",
            Self::Action => "Action",
            Self::Activity => "Activity",
            Self::DialogueLine => "DialogueLine",
            Self::Text => "Text",
            Self::Content => "Content",
            Self::Input => "Input",
            Self::Button => "Button",
            Self::Style => "Style",
            Self::Asset => "Asset",
            Self::Image => "Image",
            Self::Animation => "Animation",
            Self::Capture => "Capture",
            Self::Hook => "Hook",
            Self::Signal => "Signal",
            Self::Metric => "Metric",
            Self::Scene => "Scene",
            Self::Test => "Test",
            Self::Bench => "Bench",
            Self::Layer => "Layer",
            Self::Voice => "Voice",
            Self::Se => "Se",
            Self::Bgm => "Bgm",
            Self::AudioBus => "AudioBus",
            Self::MixerSnapshot => "MixerSnapshot",
            Self::Ducking => "Ducking",
            Self::Motion => "Motion",
            Self::Rig => "Rig",
            Self::Slot => "Slot",
            Self::Target => "Target",
            Self::Other(_) => return None,
        })
    }

    /// Canonical semantic label for this entity family.
    #[must_use]
    pub fn as_str(&self) -> &str {
        match self {
            Self::Agent => "agent",
            Self::Entry => "entry",
            Self::Flow => "flow",
            Self::Choice => "choice",
            Self::ChoiceOption => "choice_option",
            Self::Character => "character",
            Self::View => "view",
            Self::Action => "action",
            Self::Activity => "activity",
            Self::DialogueLine => "dialogue_line",
            Self::Text => "text",
            Self::Content => "content",
            Self::Input => "input",
            Self::Button => "button",
            Self::Style => "style",
            Self::Asset => "asset",
            Self::Image => "image",
            Self::Animation => "animation",
            Self::Capture => "capture",
            Self::Hook => "hook",
            Self::Signal => "signal",
            Self::Metric => "metric",
            Self::Scene => "scene",
            Self::Test => "test",
            Self::Bench => "bench",
            Self::Layer => "layer",
            Self::Voice => "voice",
            Self::Se => "se",
            Self::Bgm => "bgm",
            Self::AudioBus => "audio_bus",
            Self::MixerSnapshot => "mixer_snapshot",
            Self::Ducking => "ducking",
            Self::Motion => "motion",
            Self::Rig => "rig",
            Self::Slot => "slot",
            Self::Target => "target",
            Self::Other(value) => value.as_str(),
        }
    }

    /// Resolves the canonical Arcweft type name for an entity family.
    #[must_use]
    pub fn from_type_name(name: &str) -> Option<Self> {
        Self::AUTHORED_FAMILIES
            .iter()
            .find(|family| family.authored_type_name() == Some(name))
            .cloned()
    }

    /// Maps a typed retained-declaration family to its value-level entity
    /// reference family. Proofs are callable declarations rather than entity
    /// references and therefore have no mapping here.
    #[must_use]
    pub const fn from_declaration_identity_family(
        family: DeclarationIdentityFamily,
    ) -> Option<Self> {
        match family {
            DeclarationIdentityFamily::Asset => Some(Self::Asset),
            DeclarationIdentityFamily::Character => Some(Self::Character),
            DeclarationIdentityFamily::View => Some(Self::View),
            DeclarationIdentityFamily::Action => Some(Self::Action),
            DeclarationIdentityFamily::Activity => Some(Self::Activity),
            DeclarationIdentityFamily::Signal => Some(Self::Signal),
            DeclarationIdentityFamily::Metric => Some(Self::Metric),
            DeclarationIdentityFamily::Layer => Some(Self::Layer),
            DeclarationIdentityFamily::Flow => Some(Self::Flow),
            DeclarationIdentityFamily::Style => Some(Self::Style),
            DeclarationIdentityFamily::Proof => None,
        }
    }
}

/// Entity reference type with optional payload type.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct EntityType<E: TypeEffectDomain = CanonicalEffects> {
    kind: EntityKind,
    value: Option<Box<TypeKind<E>>>,
}

/// Closed semantic types owned by the Agent Prelude.
///
/// These identities are intentionally distinct from [`TypeKind::Named`].
/// Agent callable schemas and runtime projection select them through this
/// typed vocabulary rather than reconstructing authority from a source
/// spelling.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum AgentBuiltinType {
    ObservedObjectId,
    CaptureFormat,
    CaptureKind,
    Diagnostics,
    WaitError,
    ViewportPoint,
    PointerButton,
    RagError,
    AgentSourcePosition,
    AgentProjectFlowControlSummary,
    AgentProjectGraphSummary,
    AgentBinaryBody,
    AgentBinaryEncoding,
    AgentBinaryData,
}

impl AgentBuiltinType {
    /// Agent Prelude atoms represented by payload-free runtime variants.
    pub const UNIT_VARIANTS: [Self; 4] = [
        Self::CaptureFormat,
        Self::CaptureKind,
        Self::PointerButton,
        Self::AgentBinaryEncoding,
    ];

    /// Canonical case authority for an Agent Prelude enum.
    #[must_use]
    pub const fn runtime_variant(
        self,
    ) -> Option<arcweft_core::pattern::RuntimeBuiltinVariantIdentity> {
        use arcweft_core::pattern::RuntimeBuiltinVariantIdentity as Variant;
        match self {
            Self::CaptureFormat => Some(Variant::CaptureFormat),
            Self::CaptureKind => Some(Variant::CaptureKind),
            Self::PointerButton => Some(Variant::PointerButton),
            Self::AgentBinaryEncoding => Some(Variant::AgentBinaryEncoding),
            Self::ObservedObjectId
            | Self::Diagnostics
            | Self::WaitError
            | Self::ViewportPoint
            | Self::RagError
            | Self::AgentSourcePosition
            | Self::AgentProjectFlowControlSummary
            | Self::AgentProjectGraphSummary
            | Self::AgentBinaryBody
            | Self::AgentBinaryData => None,
        }
    }

    /// Resolves an Agent enum owner without interpreting its source label.
    #[must_use]
    pub fn from_runtime_variant(
        owner: arcweft_core::pattern::RuntimeBuiltinVariantIdentity,
    ) -> Option<Self> {
        Self::UNIT_VARIANTS
            .into_iter()
            .find(|builtin| builtin.runtime_variant() == Some(owner))
    }

    /// Canonical Agent Prelude spelling retained for diagnostics and tooling.
    #[must_use]
    pub const fn source_label(self) -> &'static str {
        match self {
            Self::ObservedObjectId => "ObservedObjectId",
            Self::CaptureFormat => "CaptureFormat",
            Self::CaptureKind => "CaptureKind",
            Self::Diagnostics => "Diagnostics",
            Self::WaitError => "WaitError",
            Self::ViewportPoint => "ViewportPoint",
            Self::PointerButton => "PointerButton",
            Self::RagError => "RagError",
            Self::AgentSourcePosition => "AgentSourcePosition",
            Self::AgentProjectFlowControlSummary => "AgentProjectFlowControlSummary",
            Self::AgentProjectGraphSummary => "AgentProjectGraphSummary",
            Self::AgentBinaryBody => "AgentBinaryBody",
            Self::AgentBinaryEncoding => "AgentBinaryEncoding",
            Self::AgentBinaryData => "AgentBinaryData",
        }
    }

    /// Resolves one canonical Agent Prelude type spelling.
    #[must_use]
    pub fn from_source_label(label: &str) -> Option<Self> {
        Some(match label {
            "ObservedObjectId" => Self::ObservedObjectId,
            "CaptureFormat" => Self::CaptureFormat,
            "CaptureKind" => Self::CaptureKind,
            "Diagnostics" => Self::Diagnostics,
            "WaitError" => Self::WaitError,
            "ViewportPoint" => Self::ViewportPoint,
            "PointerButton" => Self::PointerButton,
            "RagError" => Self::RagError,
            "AgentSourcePosition" => Self::AgentSourcePosition,
            "AgentProjectFlowControlSummary" => Self::AgentProjectFlowControlSummary,
            "AgentProjectGraphSummary" => Self::AgentProjectGraphSummary,
            "AgentBinaryBody" => Self::AgentBinaryBody,
            "AgentBinaryEncoding" => Self::AgentBinaryEncoding,
            "AgentBinaryData" => Self::AgentBinaryData,
            _ => return None,
        })
    }
}

/// Closed source-ordered field coordinates of the standard `Progress` value.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ProgressField {
    Ratio,
    Label,
}

/// Closed field coordinates owned by a Character reference value.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CharacterField {
    Stage,
}

impl CharacterField {
    pub const ALL: &'static [Self] = &[Self::Stage];

    /// Stable semantic tag in declaration order.
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Stage => 0,
        }
    }

    #[must_use]
    pub fn from_name(name: &str) -> Option<Self> {
        match name {
            "stage" => Some(Self::Stage),
            _ => None,
        }
    }

    #[must_use]
    pub fn ty(self, character: CharacterId) -> TypeKind {
        match self {
            Self::Stage => TypeKind::StageApi(character),
        }
    }
}

impl ProgressField {
    pub const ALL: &'static [Self] = &[Self::Ratio, Self::Label];

    /// Stable semantic tag in declaration order.
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Ratio => 0,
            Self::Label => 1,
        }
    }

    #[must_use]
    pub fn from_name(name: &str) -> Option<Self> {
        match name {
            "ratio" => Some(Self::Ratio),
            "label" => Some(Self::Label),
            _ => None,
        }
    }

    #[must_use]
    pub fn ty(self) -> TypeKind {
        match self {
            Self::Ratio => TypeKind::F32,
            Self::Label => TypeKind::Option(Box::new(TypeKind::String)),
        }
    }
}

/// Minimal semantic type used by parser/HIR contract tests.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum StageActorHandleType {
    Exact(CharacterId),
    Any,
}

/// Closed receiver/result constructor family of the standard `map` callable.
///
/// This type-level owner is shared by generic issuance, callable schemas and
/// runtime projection so those layers cannot maintain parallel family tables.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum StandardMapFamily {
    Vec,
    Seq,
    Array,
    Slice,
    Option,
    Result,
    Need,
    Parser,
    Stream,
}

/// Closed semantic identity of one compile-time View callable.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ViewCallableId {
    Element(arcweft_view::ViewElementKind),
    Text,
    RichText,
}

impl ViewCallableId {
    /// Stable semantic tag in declaration order.
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Element(_) => 0,
            Self::Text => 1,
            Self::RichText => 2,
        }
    }

    /// Canonical diagnostic/tooling label for this callable identity.
    pub fn source_label(self) -> String {
        match self {
            Self::Element(element) => element.source_name().to_owned(),
            Self::Text => "Text".to_owned(),
            Self::RichText => "RichText".to_owned(),
        }
    }
}

/// Closed semantic identity of one compile-time Style callable.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum StyleCallableId {
    Rgba,
    Token,
    SystemColor,
    SystemFont,
    Radii,
    Shadow,
    InsetShadow,
    Blur,
    Brightness,
    Contrast,
    Opacity,
    RoundedRect,
    Mask,
    Transition,
    Resource,
}

impl StyleCallableId {
    pub(crate) const ALL: [Self; 15] = [
        Self::Rgba,
        Self::Token,
        Self::SystemColor,
        Self::SystemFont,
        Self::Radii,
        Self::Shadow,
        Self::InsetShadow,
        Self::Blur,
        Self::Brightness,
        Self::Contrast,
        Self::Opacity,
        Self::RoundedRect,
        Self::Mask,
        Self::Transition,
        Self::Resource,
    ];

    /// Stable semantic tag in declaration order.
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Rgba => 0,
            Self::Token => 1,
            Self::SystemColor => 2,
            Self::SystemFont => 3,
            Self::Radii => 4,
            Self::Shadow => 5,
            Self::InsetShadow => 6,
            Self::Blur => 7,
            Self::Brightness => 8,
            Self::Contrast => 9,
            Self::Opacity => 10,
            Self::RoundedRect => 11,
            Self::Mask => 12,
            Self::Transition => 13,
            Self::Resource => 14,
        }
    }

    /// Canonical diagnostic/tooling label for this callable identity.
    pub const fn source_label(self) -> &'static str {
        match self {
            Self::Rgba => "rgba",
            Self::Token => "token",
            Self::SystemColor => "system_color",
            Self::SystemFont => "system_font",
            Self::Radii => "radii",
            Self::Shadow => "shadow",
            Self::InsetShadow => "inset_shadow",
            Self::Blur => "blur",
            Self::Brightness => "brightness",
            Self::Contrast => "contrast",
            Self::Opacity => "opacity",
            Self::RoundedRect => "rounded_rect",
            Self::Mask => "mask",
            Self::Transition => "transition",
            Self::Resource => "resource",
        }
    }
}

/// Closed semantic identity of one compile-time callable value.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CompileTimeCallableType {
    View(ViewCallableId),
    Style(StyleCallableId),
    /// Exact retained View declaration; this token never allocates a Core function value.
    ProjectView(arcweft_lang_hir::symbol::CallableDeclarationKey),
}

impl CompileTimeCallableType {
    /// Selects the semantic-only callable role of an accepted project declaration.
    pub fn for_project(
        declaration: &arcweft_lang_hir::symbol::CallableDeclarationKey,
    ) -> Option<Self> {
        (declaration.owner() == arcweft_lang_hir::symbol::CallableDeclarationOwner::View)
            .then(|| Self::ProjectView(declaration.clone()))
    }
    /// Stable semantic tag in declaration order.
    pub const fn semantic_tag(&self) -> u8 {
        match self {
            Self::View(_) => 0,
            Self::Style(_) => 1,
            Self::ProjectView(_) => 2,
        }
    }

    /// Canonical diagnostic/tooling label for this callable identity.
    pub fn source_label(&self) -> String {
        match self {
            Self::View(id) => format!("View::{}", id.source_label()),
            Self::Style(id) => format!("Style::{}", id.source_label()),
            Self::ProjectView(declaration) => {
                format!("View::{}::{}", declaration.module(), declaration.name())
            }
        }
    }
}

/// Closed semantic kind of one compile-time scalar value.
///
/// These values are checked scalar leaves. Their accepted nominal declaration
/// remains part of the identity because the same scalar kind may be supplied
/// by more than one accepted environment owner.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CompileTimeScalarKind {
    Milli,
    Ratio,
    Length,
    Angle,
    PublicId,
    Color,
    FontFamily,
}

impl CompileTimeScalarKind {
    /// Core representation for fixed-point values that can cross an ordinary call.
    pub const fn runtime_quantity_kind(self) -> Option<arcweft_core::value::RuntimeQuantityKind> {
        use arcweft_core::value::RuntimeQuantityKind;
        match self {
            Self::Milli => Some(RuntimeQuantityKind::Milli),
            Self::Ratio => Some(RuntimeQuantityKind::Ratio),
            Self::Length => Some(RuntimeQuantityKind::Length),
            Self::Angle => Some(RuntimeQuantityKind::Angle),
            Self::PublicId | Self::Color | Self::FontFamily => None,
        }
    }
    /// All closed scalar kinds in their canonical declaration order.
    pub const ALL: [Self; 7] = [
        Self::Milli,
        Self::Ratio,
        Self::Length,
        Self::Angle,
        Self::PublicId,
        Self::Color,
        Self::FontFamily,
    ];

    /// Stable semantic tag in declaration order.
    pub const fn semantic_tag(self) -> u8 {
        match self {
            Self::Milli => 0,
            Self::Ratio => 1,
            Self::Length => 2,
            Self::Angle => 3,
            Self::PublicId => 4,
            Self::Color => 5,
            Self::FontFamily => 6,
        }
    }

    /// Canonical diagnostic/tooling label for this scalar kind.
    pub const fn source_label(self) -> &'static str {
        match self {
            Self::Milli => "Milli",
            Self::Ratio => "Ratio",
            Self::Length => "Length",
            Self::Angle => "Angle",
            Self::PublicId => "PublicId",
            Self::Color => "Color",
            Self::FontFamily => "FontFamily",
        }
    }
}

/// Exact identity of one accepted compile-time scalar declaration.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CompileTimeScalarType {
    declaration: crate::env::nominal::AcceptedNominalId,
    kind: CompileTimeScalarKind,
}

/// Closed compile-time enum type used by typed Content callable selectors and
/// enum-valued parameters. `exact_variant` is populated only by a selector
/// branch row; `None` admits any member of the domain.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CompileTimeEnumType {
    domain: ClosedEnumDomainId,
    exact_variant: Option<u16>,
    allowed_variants: Option<&'static [u16]>,
}

impl CompileTimeEnumType {
    pub const fn any(domain: ClosedEnumDomainId) -> Self {
        Self {
            domain,
            exact_variant: None,
            allowed_variants: None,
        }
    }

    pub const fn exact(domain: ClosedEnumDomainId, variant: u16) -> Self {
        Self {
            domain,
            exact_variant: Some(variant),
            allowed_variants: None,
        }
    }

    pub const fn allowed(domain: ClosedEnumDomainId, variants: &'static [u16]) -> Self {
        Self {
            domain,
            exact_variant: None,
            allowed_variants: Some(variants),
        }
    }

    pub const fn domain(self) -> ClosedEnumDomainId {
        self.domain
    }

    pub const fn exact_variant(self) -> Option<u16> {
        self.exact_variant
    }

    pub const fn allowed_variants(self) -> Option<&'static [u16]> {
        self.allowed_variants
    }

    pub fn accepts(self, actual: Self) -> bool {
        if self.domain != actual.domain {
            return false;
        }
        match (
            self.exact_variant,
            self.allowed_variants,
            actual.exact_variant,
            actual.allowed_variants,
        ) {
            (Some(expected), None, Some(actual), _) => expected == actual,
            (Some(_), None, None, _) => false,
            (None, Some(allowed), Some(actual), _) => allowed.contains(&actual),
            (None, Some(allowed), None, Some(actual)) => {
                actual.iter().all(|value| allowed.contains(value))
            }
            (None, Some(_), None, None) => false,
            (None, None, _, _) => true,
            (Some(_), Some(_), _, _) => false,
        }
    }

    pub fn source_label(self) -> String {
        match (self.exact_variant, self.allowed_variants) {
            (Some(variant), _) => format!("closed_enum:{:?}::{variant}", self.domain),
            (None, Some(allowed)) => {
                format!("closed_enum:{:?}[{}]", self.domain, allowed.len())
            }
            (None, None) => format!("closed_enum:{:?}", self.domain),
        }
    }
}

/// Exact or expected-only abstract compile-time Fx type.
///
/// `Abstract` is the source `Fx` supertype used by consumer schemas. It may
/// accept an exact producer type, but is never itself a producible application
/// identity and never authorizes fallback resolution.
#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum CompileTimeFxType {
    Abstract,
    /// One Arcweft-owned graph constructor used inside an Fx definition.
    Constructor(arcweft_presentation::fx::FxSourceConstructor),
    /// One exact Arcweft-owned standard Fx callable row.
    Builtin(arcweft_presentation::fx::BuiltinFxCallableRowId),
    /// One exact project `#[fx]` declaration.
    Registered(arcweft_presentation::fx::FxId),
}

impl CompileTimeFxType {
    pub fn accepts(&self, actual: &Self) -> bool {
        matches!(self, Self::Abstract) || self == actual
    }

    pub fn source_label(&self) -> String {
        match self {
            Self::Abstract => "Fx".to_owned(),
            Self::Constructor(id) => format!("Fx::{id:?}"),
            Self::Builtin(id) => format!(
                "{}[phase={}]",
                id.callable().source_name(),
                id.phase().source_name()
            ),
            Self::Registered(id) => id.to_string(),
        }
    }
}

/// Fixed-dimensional compile-time vector type. The component type is kept in
/// the type identity so a vector cannot silently become a nominal `Vec2` name.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct FixedVectorType<E: TypeEffectDomain = CanonicalEffects> {
    dimensions: crate::callable::VectorDimensions,
    component: Box<TypeKind<E>>,
}

impl<E: TypeEffectDomain> FixedVectorType<E> {
    pub fn new(dimensions: crate::callable::VectorDimensions, component: TypeKind<E>) -> Self {
        Self {
            dimensions,
            component: Box::new(component),
        }
    }

    pub const fn dimensions(&self) -> crate::callable::VectorDimensions {
        self.dimensions
    }

    pub const fn component(&self) -> &TypeKind<E> {
        &self.component
    }
}

impl CompileTimeScalarType {
    pub(crate) const fn new(
        declaration: crate::env::nominal::AcceptedNominalId,
        kind: CompileTimeScalarKind,
    ) -> Self {
        Self { declaration, kind }
    }

    /// Exact accepted declaration that supplies this scalar.
    pub const fn declaration(&self) -> &crate::env::nominal::AcceptedNominalId {
        &self.declaration
    }

    /// Closed semantic scalar kind selected by the accepted declaration.
    pub const fn kind(&self) -> CompileTimeScalarKind {
        self.kind
    }

    /// Canonical diagnostic/tooling label; never parse this back into identity.
    pub fn source_label(&self) -> String {
        format!(
            "{}<{}>",
            self.kind.source_label(),
            self.declaration.canonical_path().canonical_string()
        )
    }
}

impl StandardMapFamily {
    /// Collection and variant Map applications invoke their callback in this
    /// frame. Producer/parser transforms retain a latent callback instead.
    pub(crate) const fn callback_is_immediate(self) -> bool {
        matches!(
            self,
            Self::Vec | Self::Seq | Self::Array | Self::Slice | Self::Option | Self::Result
        )
    }

    pub const ALL: [Self; 9] = [
        Self::Vec,
        Self::Seq,
        Self::Array,
        Self::Slice,
        Self::Option,
        Self::Result,
        Self::Need,
        Self::Parser,
        Self::Stream,
    ];

    /// Families whose current runtime value algebra can execute a pure map.
    /// Temporal/producer and parser families remain typed schema authorities,
    /// but are not published until their owning transform substrate exists.
    pub(crate) const PUBLISHED: [Self; 6] = [
        Self::Vec,
        Self::Seq,
        Self::Array,
        Self::Slice,
        Self::Option,
        Self::Result,
    ];

    pub(crate) const fn generic_arity(self) -> (u16, u16) {
        match self {
            Self::Vec | Self::Seq | Self::Slice | Self::Option | Self::Need => (2, 0),
            Self::Array => (2, 1),
            Self::Result | Self::Parser | Self::Stream => (3, 0),
        }
    }

    pub(crate) const fn ordinal(self) -> u8 {
        match self {
            Self::Vec => 0,
            Self::Seq => 1,
            Self::Array => 2,
            Self::Slice => 3,
            Self::Option => 4,
            Self::Result => 5,
            Self::Need => 6,
            Self::Parser => 7,
            Self::Stream => 8,
        }
    }

    pub(crate) const fn intrinsic_owner_tag(self) -> u8 {
        self.ordinal() + 2
    }

    pub(crate) const fn intrinsic_owner_label(self) -> &'static str {
        match self {
            Self::Vec => "language.standard-map.vec",
            Self::Seq => "language.standard-map.seq",
            Self::Array => "language.standard-map.array",
            Self::Slice => "language.standard-map.slice",
            Self::Option => "language.standard-map.option",
            Self::Result => "language.standard-map.result",
            Self::Need => "language.standard-map.need",
            Self::Parser => "language.standard-map.parser",
            Self::Stream => "language.standard-map.stream",
        }
    }
}

/// One semantic type grammar with phase-specific effect evidence.
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub enum TypeKind<E: TypeEffectDomain = CanonicalEffects> {
    Bool,
    I8,
    I16,
    I32,
    I64,
    I128,
    ISize,
    U8,
    U16,
    U32,
    U64,
    U128,
    USize,
    F32,
    F64,
    String,
    Char,
    Bytes,
    TextCluster,
    Duration,
    Progress,
    DenseNumeric(arcweft_core::math::RuntimeDenseNumericType),
    /// Compile-time capability projected from one exact Character.
    StageApi(CharacterId),
    /// Compile-time capability available only inside one line activation.
    LineContext,
    /// Affine stage-actor handle retaining exact Character precision when known.
    StageActorHandle(StageActorHandleType),
    /// Affine handle for a scheduled or stage-transition cue.
    CueHandle,
    /// Affine handle for the active dialogue voice lease.
    VoiceHandle,
    /// Closed standard atom used only by contextual statement ingress.
    StatementIngress(StandardStatementIngressTypeId),
    Range(Box<TypeKind<E>>),
    IteratorState {
        family: IteratorStateKind,
        item: Box<TypeKind<E>>,
    },
    /// Formatter-owned, source-visible context passed to `DisplayText` methods.
    DisplayContext,
    /// Recoverable error returned by `DisplayText` methods.
    DisplayError,
    DebugStatePath,
    ObservationFieldPath,
    Ref(EntityType<E>),
    Probe(Box<TypeKind<E>>),
    Predicate,
    Observation,
    ObservedObject,
    AgentBBox,
    ActionName,
    ActionTarget,
    ActionResult,
    AgentValue,
    DataFormat,
    /// Opaque data codec shape witness carrying the exact encoded value type.
    DataShape(Box<TypeKind<E>>),
    DataValue,
    DataError,
    DataErrorKind,
    DataPath,
    DataPathSegment,
    DataMapKind,
    AgentEntityMetadata,
    AgentSourceAnchor,
    AgentProjectGraphNeighborhood,
    AgentProjectGraphSymbol,
    AgentProjectGraphEdge,
    CaptureTarget,
    CaptureRef,
    AgentResource,
    AgentResourceBody,
    RagContextPack,
    AgentBuiltin(AgentBuiltinType),
    Vec(Box<TypeKind<E>>),
    Array {
        item: Box<TypeKind<E>>,
        len: ArrayLength,
    },
    Slice(Box<TypeKind<E>>),
    Seq(Box<TypeKind<E>>),
    Map {
        kind: MapKind,
        key: Box<TypeKind<E>>,
        value: Box<TypeKind<E>>,
    },
    BorrowRef {
        kind: BorrowKind,
        lifetime: Option<LifetimeScopeKind>,
        inner: Box<TypeKind<E>>,
    },
    Need(Box<TypeKind<E>>),
    /// An unstarted traversal retaining the complete source and callback type.
    /// Scheduling produces a unary Need; constructing this value invokes no callback.
    Traversal {
        source: Box<TypeKind<E>>,
        mapping: Box<TypeKind<E>>,
    },
    Stream {
        item: Box<TypeKind<E>>,
        error: Box<TypeKind<E>>,
    },
    Parser {
        item: Box<TypeKind<E>>,
        error: Box<TypeKind<E>>,
    },
    Result {
        ok: Box<TypeKind<E>>,
        error: Box<TypeKind<E>>,
    },
    Option(Box<TypeKind<E>>),
    PresentationResource(arcweft_interaction_model::presentation::PresentationResourceKind),
    SlotRef(Box<TypeKind<E>>),
    Handle {
        item: Box<TypeKind<E>>,
        lifetime: LifetimeScopeKind,
        state: HandleState,
        must_drop: bool,
    },
    ThreadHandle(Box<TypeKind<E>>),
    Shared(Box<TypeKind<E>>),
    Function {
        binder: GenericBinder,
        predicate: E::Predicate,
        params: Vec<TypeKind<E>>,
        return_type: Box<TypeKind<E>>,
        effects: E::Row,
    },
    /// Compile-time callable family selected by the semantic checker.
    CompileTimeCallable(CompileTimeCallableType),
    /// Identity-bearing compile-time scalar selected by the accepted catalog.
    CompileTimeScalar(CompileTimeScalarType),
    /// A specified Style value or construction operand; never a Core runtime value.
    CompileTimeStyle(CompileTimeStyleType),
    /// Closed compile-time enum domain (optionally narrowed to one variant).
    CompileTimeEnum(CompileTimeEnumType),
    /// Exact or contextually open compile-time Fx value.
    CompileTimeFx(CompileTimeFxType),
    /// Fixed-dimensional vector with an exact component type.
    FixedVector(FixedVectorType<E>),
    /// Compile-time value describing one semantic type.
    MetaType(Box<TypeKind<E>>),
    /// Generic parameter selected by a declaration-owned typed identity.
    GenericParam(GenericTypeReference),
    /// Source-backed project struct or enum selected through the project table.
    ProjectNominal(ProjectNominalType<E>),
    /// Exact opaque type selected through the accepted environment catalog.
    AcceptedNominal(AcceptedNominalType<E>),
    /// Type admitted by one explicit open-nominal environment rule.
    OpenNominal(OpenNominalType<E>),
    /// Recovery carrier for a previously recorded authoritative type failure.
    Error(TypePoisonId),
    Projection {
        subject: Box<TypeKind<E>>,
        trait_name: Option<String>,
        assoc: String,
    },
    CharacterPatch(EntityKind),
    FocusPatch,
    /// Immutable first-class dialogue presentation value.
    CharacterDialogue(CharacterDialogueType),
    /// Non-escaping dialogue suspension operation and its line-plan result.
    DialogueLine(Box<TypeKind<E>>),
    /// Retained View expression value owned by the checked View projection.
    ViewValue,
    /// Manifest-backed character enum with structural nominal identity.
    CharacterNominal(CharacterNominalType),
    /// Internal or host-produced semantic value without an authored `TypeRef` origin.
    ///
    /// Authored type resolution must use `crate::nominal::resolve_type_ref` and
    /// never constructs this variant as a path fallback.
    Named(String),
    Tuple(Vec<TypeKind<E>>),
    Choice(Vec<TypeKind<E>>),
    /// Exact anonymous tuple/record payload of one accepted variant case.
    /// Authored type resolution never constructs this internal family.
    VariantPayload(Box<VariantPayloadType<E>>),
    Unit,
    Never,
}

impl From<IntSuffix> for TypeKind {
    fn from(suffix: IntSuffix) -> Self {
        match suffix {
            IntSuffix::I8 => Self::I8,
            IntSuffix::I16 => Self::I16,
            IntSuffix::I32 => Self::I32,
            IntSuffix::I64 => Self::I64,
            IntSuffix::I128 => Self::I128,
            IntSuffix::ISize => Self::ISize,
            IntSuffix::U8 => Self::U8,
            IntSuffix::U16 => Self::U16,
            IntSuffix::U32 => Self::U32,
            IntSuffix::U64 => Self::U64,
            IntSuffix::U128 => Self::U128,
            IntSuffix::USize => Self::USize,
        }
    }
}

pub(crate) fn direct_type_name(path: &TypePath) -> Option<&str> {
    (path.root() == ModulePathRoot::ImplicitCrate && path.segments().len() == 1)
        .then(|| path.path().last_segment().as_str())
}

impl EntityType {
    /// Runtime type metadata, retaining the original Action declaration rather
    /// than equating channels with structurally identical payload records.
    pub fn runtime_reference_type(
        &self,
    ) -> Option<arcweft_core::value::RuntimeEntityReferenceType<&TypeKind>> {
        let family = self.kind.reference_family()?;
        let declaration = match (&self.kind, self.value()) {
            (EntityKind::Action, Some(TypeKind::ProjectNominal(nominal))) => {
                match nominal.declaration().kind() {
                    arcweft_lang_hir::symbol::nominal::ProjectNominalDeclarationKind::Action {
                        public_id,
                    } => Some(public_id.clone()),
                    _ => return None,
                }
            }
            _ => None,
        };
        Some(
            arcweft_core::value::RuntimeEntityReferenceType::try_new(
                family,
                self.value(),
                declaration,
            )
            .expect("the HIR Action identity has the Action public-ID family"),
        )
    }
}

impl<E: TypeEffectDomain> EntityType<E> {
    pub fn new(kind: EntityKind, value: Option<TypeKind<E>>) -> Self {
        Self {
            kind,
            value: value.map(Box::new),
        }
    }

    pub const fn kind(&self) -> &EntityKind {
        &self.kind
    }

    pub fn value(&self) -> Option<&TypeKind<E>> {
        self.value.as_deref()
    }
}

impl EntityType {
    /// Observable element from the exact accepted Signal/Metric carrier.
    /// A same-spelled foreign nominal cannot impersonate a standard carrier.
    pub fn observable_payload(&self) -> Option<&TypeKind> {
        match self.kind() {
            EntityKind::Signal => Some(self.value()?.signal_observable()?.payload()),
            EntityKind::Metric => self.value(),
            _ => None,
        }
    }

    pub fn watch_payload(&self) -> Option<&TypeKind> {
        if self.kind() != &EntityKind::Signal {
            return None;
        }
        match self.value()?.signal_observable()? {
            SignalObservableType::Watch(payload) => Some(payload),
            SignalObservableType::Stream { .. } | SignalObservableType::Sample(_) => None,
        }
    }
}

impl TypeKind {
    pub fn presentation_address_reference(
        kind: arcweft_interaction_model::presentation::PresentationAddressIdentityKind,
    ) -> Self {
        Self::entity_ref(match kind {
            arcweft_interaction_model::presentation::PresentationAddressIdentityKind::Target => {
                EntityKind::Target
            }
            arcweft_interaction_model::presentation::PresentationAddressIdentityKind::Slot(_) => {
                EntityKind::Slot
            }
        })
    }
    /// Refers to a declaration-owned parameter without opening an inference
    /// variable or changing its lexical meaning.
    #[must_use]
    pub fn generic_parameter(parameter: GenericTypeParameterId) -> Self {
        Self::GenericParam(GenericTypeReference::Free(parameter))
    }

    /// Resolves a field only when this type is the standard Progress owner.
    #[must_use]
    pub fn progress_field(&self, name: &str) -> Option<(ProgressField, TypeKind)> {
        if !matches!(self, Self::Progress) {
            return None;
        }
        ProgressField::from_name(name).map(|field| (field, field.ty()))
    }

    pub const ACTION_EVENT_TYPE_NAME: &'static str = "ActionEvent";

    /// Returns the canonical Arcweft surface spelling for this semantic type.
    ///
    /// This is intended for diagnostics and tooling displays, not for stable
    /// serialization. Function labels use the documented right-associative
    /// `A -> B` spelling and tuple call groups for multi-parameter functions.
    #[must_use]
    pub fn source_label(&self) -> String {
        if let Some(label) = self.atomic_source_label() {
            return label.to_owned();
        }

        match self {
            Self::Ref(entity) => entity.source_label(),
            Self::Probe(inner) => format!("Probe<{}>", inner.source_label()),
            Self::Range(inner) => format!("Range<{}>", inner.source_label()),
            Self::StageApi(character) => format!("StageApi<{character}>"),
            Self::StageActorHandle(StageActorHandleType::Exact(character)) => {
                format!("StageActorHandle<{character}>")
            }
            Self::StageActorHandle(StageActorHandleType::Any) => "StageActorHandle".to_owned(),
            Self::IteratorState { family, item } => {
                format!("{family:?}IteratorState<{}>", item.source_label())
            }
            Self::Vec(inner) => format!("Vec<{}>", inner.source_label()),
            Self::DataShape(inner) => format!("DataShape<{}>", inner.source_label()),
            Self::Array { item, len } => format!("Array<{}, {len}>", item.source_label()),
            Self::Slice(inner) => format!("[{}]", inner.source_label()),
            Self::Seq(inner) => format!("Seq<{}>", inner.source_label()),
            Self::Map { kind, key, value } => {
                format!("{kind:?}<{}, {}>", key.source_label(), value.source_label())
            }
            Self::BorrowRef {
                kind,
                lifetime,
                inner,
            } => {
                let lifetime = lifetime
                    .as_ref()
                    .map(|lifetime| format!("'{} ", lifetime.as_str()))
                    .unwrap_or_default();
                format!(
                    "&{lifetime}{}{}",
                    kind.source_qualifier(),
                    inner.source_label()
                )
            }
            Self::Need(value) => format!("Need<{}>", value.source_label()),
            Self::Traversal { source, mapping } => {
                format!(
                    "Traversal<{}, {}>",
                    source.source_label(),
                    mapping.source_label()
                )
            }
            Self::Stream { item, error } => {
                format!("Stream<{}, {}>", item.source_label(), error.source_label())
            }
            Self::Parser { item, error } => {
                format!("Parser<{}, {}>", item.source_label(), error.source_label())
            }
            Self::Result { ok, error } => {
                format!("Result<{}, {}>", ok.source_label(), error.source_label())
            }
            Self::Option(inner) => format!("Option<{}>", inner.source_label()),
            Self::PresentationResource(kind) => kind.type_name().to_owned(),
            Self::SlotRef(inner) => format!("SlotRef<{}>", inner.source_label()),
            Self::Handle {
                item,
                lifetime,
                state,
                must_drop,
            } => format!(
                "Handle<{}, {}, {state:?}, {must_drop}>",
                item.source_label(),
                lifetime.as_str()
            ),
            Self::ThreadHandle(inner) => format!("ThreadHandle<{}>", inner.source_label()),
            Self::Shared(inner) => format!("Shared<{}>", inner.source_label()),
            Self::Function {
                binder,
                params,
                return_type,
                effects,
                ..
            } => {
                let function = Self::function_source_label(params, return_type, effects);
                if binder.is_empty() {
                    function
                } else {
                    format!(
                        "for<type:{}, const:{}, effect:{}> {function}",
                        binder.types(),
                        binder.const_lengths(),
                        binder.effects()
                    )
                }
            }
            Self::CompileTimeCallable(callable) => {
                format!("CompileTimeCallable<{}>", callable.source_label())
            }
            Self::CompileTimeScalar(scalar) => {
                format!("CompileTimeScalar<{}>", scalar.source_label())
            }
            Self::CompileTimeStyle(style) => style.source_label(),
            Self::CompileTimeEnum(enum_type) => {
                format!("CompileTimeEnum<{}>", enum_type.source_label())
            }
            Self::CompileTimeFx(fx) => format!("CompileTimeFx<{}>", fx.source_label()),
            Self::FixedVector(vector) => format!(
                "Vec{}<{}>",
                match vector.dimensions() {
                    crate::callable::VectorDimensions::Two => 2,
                    crate::callable::VectorDimensions::Three => 3,
                    crate::callable::VectorDimensions::Four => 4,
                },
                vector.component().source_label()
            ),
            Self::MetaType(inner) => format!("MetaType<{}>", inner.source_label()),
            Self::GenericParam(parameter) => parameter.source_label(),
            Self::ProjectNominal(nominal) => nominal.source_label(),
            Self::AcceptedNominal(nominal) => nominal.source_label(),
            Self::OpenNominal(nominal) => nominal.source_label(),
            Self::Error(poison) => format!("<type-error:{}>", poison.index()),
            Self::Named(name) => name.clone(),
            Self::Projection {
                subject,
                trait_name,
                assoc,
            } => trait_name.as_ref().map_or_else(
                || format!("{}::{assoc}", subject.source_label()),
                |trait_name| format!("<{} as {trait_name}>::{assoc}", subject.source_label()),
            ),
            Self::CharacterPatch(kind) => format!("CharacterPatch<{kind:?}>"),
            Self::CharacterDialogue(dialogue) => dialogue.source_label(),
            Self::DialogueLine(result) => format!("DialogueLine<{}>", result.source_label()),
            Self::CharacterNominal(nominal) => nominal.source_label(),
            Self::Tuple(items) => format!(
                "({})",
                items
                    .iter()
                    .map(Self::source_label)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            Self::Choice(alternatives) => alternatives
                .iter()
                .map(Self::source_label)
                .collect::<Vec<_>>()
                .join(" | "),
            _ => unreachable!("atomic type labels are handled before structured labels"),
        }
    }

    fn atomic_source_label(&self) -> Option<&'static str> {
        Some(match self {
            Self::Bool => "bool",
            Self::I8 => "i8",
            Self::I16 => "i16",
            Self::I32 => "i32",
            Self::I64 => "i64",
            Self::I128 => "i128",
            Self::ISize => "isize",
            Self::U8 => "u8",
            Self::U16 => "u16",
            Self::U32 => "u32",
            Self::U64 => "u64",
            Self::U128 => "u128",
            Self::USize => "usize",
            Self::F32 => "f32",
            Self::F64 => "f64",
            Self::String => "String",
            Self::Char => "char",
            Self::Bytes => "Bytes",
            Self::TextCluster => "TextCluster",
            Self::Duration => "Duration",
            Self::Progress => "Progress",
            Self::DenseNumeric(dense) => dense.source_label(),
            Self::LineContext => "LineContext",
            Self::CueHandle => "CueHandle",
            Self::VoiceHandle => "VoiceHandle",
            Self::StatementIngress(StandardStatementIngressTypeId::TaskEvent) => "TaskEvent",
            Self::StatementIngress(StandardStatementIngressTypeId::ScopeExit) => "ScopeExit",
            Self::StatementIngress(StandardStatementIngressTypeId::FrameBoundary) => {
                "FrameBoundary"
            }
            Self::DisplayContext => "DisplayContext",
            Self::DisplayError => "DisplayError",
            Self::DebugStatePath => "DebugStatePath",
            Self::ObservationFieldPath => "ObservationFieldPath",
            Self::Predicate => "Predicate",
            Self::Observation => "Observation",
            Self::ObservedObject => "ObservedObject",
            Self::AgentBBox => "AgentBBox",
            Self::ActionName => "ActionName",
            Self::ActionTarget => "ActionTarget",
            Self::ActionResult => "ActionResult",
            Self::AgentValue => "AgentValue",
            Self::DataFormat => "DataFormat",
            Self::DataValue => "DataValue",
            Self::DataError => "DataError",
            Self::DataErrorKind => "DataErrorKind",
            Self::DataPath => "DataPath",
            Self::DataPathSegment => "DataPathSegment",
            Self::DataMapKind => "DataMapKind",
            Self::AgentEntityMetadata => "AgentEntityMetadata",
            Self::AgentSourceAnchor => "AgentSourceAnchor",
            Self::AgentProjectGraphNeighborhood => "AgentProjectGraphNeighborhood",
            Self::AgentProjectGraphSymbol => "AgentProjectGraphSymbol",
            Self::AgentProjectGraphEdge => "AgentProjectGraphEdge",
            Self::CaptureTarget => "CaptureTarget",
            Self::CaptureRef => "CaptureRef",
            Self::AgentResource => "AgentResource",
            Self::AgentResourceBody => "AgentResourceBody",
            Self::RagContextPack => "RagContextPack",
            Self::AgentBuiltin(builtin) => builtin.source_label(),
            Self::FocusPatch => "FocusPatch",
            Self::ViewValue => "ViewValue",
            Self::Unit => "Unit",
            Self::Never => "Never",
            _ => return None,
        })
    }

    fn function_source_label(params: &[Self], return_type: &Self, effects: &EffectRow) -> String {
        let params = if params.len() == 1 {
            params[0].source_label()
        } else {
            format!(
                "({})",
                params
                    .iter()
                    .map(Self::source_label)
                    .collect::<Vec<_>>()
                    .join(", ")
            )
        };
        let label = format!("{params} -> {}", return_type.source_label());
        function_effect_row_label(effects).map_or(label.clone(), |effects| {
            format!("{label} effects {effects}")
        })
    }

    #[must_use]
    pub fn entity_ref(kind: EntityKind) -> Self {
        Self::Ref(EntityType::new(kind, None))
    }

    #[must_use]
    pub fn entity_ref_with_value(kind: EntityKind, value: TypeKind) -> Self {
        Self::Ref(EntityType::new(kind, Some(value)))
    }

    #[must_use]
    pub fn action_event() -> Self {
        Self::Named(Self::ACTION_EVENT_TYPE_NAME.to_owned())
    }

    #[must_use]
    pub fn function_arity(&self) -> Option<usize> {
        match self {
            Self::Function { params, .. } => Some(params.len()),
            _ => None,
        }
    }

    #[must_use]
    pub fn function(params: impl IntoIterator<Item = TypeKind>, return_type: TypeKind) -> Self {
        Self::function_with_effects(params, return_type, EffectRow::unknown())
    }

    #[must_use]
    pub fn function_with_effects(
        params: impl IntoIterator<Item = TypeKind>,
        return_type: TypeKind,
        effects: EffectRow,
    ) -> Self {
        Self::function_with_binder(GenericBinder::EMPTY, params, return_type, effects)
    }

    pub(crate) fn function_with_binder(
        binder: GenericBinder,
        params: impl IntoIterator<Item = TypeKind>,
        return_type: TypeKind,
        effects: EffectRow,
    ) -> Self {
        Self::function_with_contract(
            binder,
            EffectPredicate::unconstrained(),
            params,
            return_type,
            effects,
        )
    }

    pub(crate) fn function_with_contract(
        binder: GenericBinder,
        predicate: EffectPredicate,
        params: impl IntoIterator<Item = TypeKind>,
        return_type: TypeKind,
        effects: EffectRow,
    ) -> Self {
        Self::Function {
            binder,
            predicate,
            params: params.into_iter().collect(),
            return_type: Box::new(return_type),
            effects,
        }
    }

    #[must_use]
    pub fn action_event_field(field: &str) -> Option<Self> {
        Some(match field {
            "action" => Self::entity_ref(EntityKind::Action),
            "value" => Self::String,
            _ => return None,
        })
    }

    #[must_use]
    pub fn presentation_handle(item: Self) -> Self {
        Self::Handle {
            item: Box::new(item),
            lifetime: LifetimeScopeKind::Flow,
            state: HandleState::Live,
            must_drop: true,
        }
    }

    /// Selects the exact standard carrier without granting executable custody.
    pub fn presentation_opaque_owner(
        &self,
        semantic: arcweft_core::pattern::RuntimeSemanticTypeId,
    ) -> Option<arcweft_core::pattern::RuntimeOpaqueTypeOwner> {
        use arcweft_core::pattern::RuntimeOpaqueTypeOwner;
        match self {
            Self::Handle {
                item,
                state: HandleState::Live | HandleState::Detached,
                ..
            } => {
                let Self::PresentationResource(resource) = item.as_ref() else {
                    return None;
                };
                Some(RuntimeOpaqueTypeOwner::presentation_handle(
                    *resource, semantic,
                ))
            }
            Self::SlotRef(item) => {
                let Self::PresentationResource(resource) = item.as_ref() else {
                    return None;
                };
                Some(RuntimeOpaqueTypeOwner::presentation_slot_ref(
                    *resource, semantic,
                ))
            }
            _ => None,
        }
    }

    #[must_use]
    pub fn is_entity_ref_kind(&self, kind: &EntityKind) -> bool {
        matches!(self, Self::Ref(entity) if entity.kind() == kind)
    }

    #[must_use]
    pub const fn is_integer(&self) -> bool {
        matches!(
            self,
            Self::I8
                | Self::I16
                | Self::I32
                | Self::I64
                | Self::I128
                | Self::ISize
                | Self::U8
                | Self::U16
                | Self::U32
                | Self::U64
                | Self::U128
                | Self::USize
        )
    }

    #[must_use]
    pub const fn is_signed_integer(&self) -> bool {
        matches!(
            self,
            Self::I8 | Self::I16 | Self::I32 | Self::I64 | Self::I128 | Self::ISize
        )
    }

    #[must_use]
    pub const fn is_float(&self) -> bool {
        matches!(self, Self::F32 | Self::F64)
    }

    /// Joins two control-flow branch result types using Arcweft expression
    /// branch rules.
    #[must_use]
    pub fn join_branch(left: Self, right: Self) -> Self {
        match (left, right) {
            (left, right) if left == right => left,
            (Self::Never, right) => right,
            (left, Self::Never) => left,
            (Self::CharacterDialogue(left), Self::CharacterDialogue(right)) => {
                Self::CharacterDialogue(CharacterDialogueType::join(left, &right))
            }
            (left, right) => Self::normalized_choice([left, right]),
        }
    }

    fn normalized_choice(alternatives: impl IntoIterator<Item = Self>) -> Self {
        let mut flattened = alternatives
            .into_iter()
            .flat_map(|ty| match ty {
                Self::Choice(alternatives) => alternatives,
                ty => vec![ty],
            })
            .collect::<Vec<_>>();
        flattened.sort_by(Self::stable_ordering);
        flattened.dedup();
        match flattened.as_slice() {
            [single] => single.clone(),
            _ => Self::Choice(flattened),
        }
    }

    /// Per-character enum type used for manifest-declared look values.
    #[must_use]
    pub fn character_look(character: CharacterId) -> Self {
        Self::CharacterNominal(CharacterNominalType::Look { character })
    }

    /// Per-character enum type used for manifest-declared part ids.
    #[must_use]
    pub fn character_part(character: CharacterId) -> Self {
        Self::CharacterNominal(CharacterNominalType::Part { character })
    }

    /// Per-character, per-part enum type used for manifest-declared variants.
    #[must_use]
    pub fn character_variant(character: CharacterId, part: CharacterPartId) -> Self {
        Self::CharacterNominal(CharacterNominalType::Variant { character, part })
    }

    /// Manifest-backed character nominal identity, when this is one.
    #[must_use]
    pub const fn character_nominal(&self) -> Option<&CharacterNominalType> {
        match self {
            Self::CharacterNominal(nominal) => Some(nominal),
            _ => None,
        }
    }

    #[must_use]
    pub fn primitive_name(name: &str) -> Option<Self> {
        if let Some(dense) = arcweft_core::math::RuntimeDenseNumericType::from_source_label(name) {
            return Some(Self::DenseNumeric(dense));
        }
        if let Some(builtin) = AgentBuiltinType::from_source_label(name) {
            return Some(Self::AgentBuiltin(builtin));
        }
        Some(match name {
            "bool" => Self::Bool,
            "i8" => Self::I8,
            "i16" => Self::I16,
            "i32" => Self::I32,
            "i64" => Self::I64,
            "i128" => Self::I128,
            "isize" => Self::ISize,
            "u8" => Self::U8,
            "u16" => Self::U16,
            "u32" => Self::U32,
            "u64" => Self::U64,
            "u128" => Self::U128,
            "usize" => Self::USize,
            "f32" => Self::F32,
            "f64" => Self::F64,
            "String" => Self::String,
            "char" => Self::Char,
            "Bytes" => Self::Bytes,
            "DataFormat" => Self::DataFormat,
            "DataValue" => Self::DataValue,
            "DataError" => Self::DataError,
            "DisplayContext" => Self::DisplayContext,
            "DisplayError" => Self::DisplayError,
            "DataErrorKind" => Self::DataErrorKind,
            "DataPath" => Self::DataPath,
            "DataPathSegment" => Self::DataPathSegment,
            "DataMapKind" => Self::DataMapKind,
            "AgentValue" => Self::AgentValue,
            "AgentResourceBody" => Self::AgentResourceBody,
            "TextCluster" => Self::TextCluster,
            "Duration" => Self::Duration,
            "Progress" => Self::Progress,
            "StageActorHandle" => Self::StageActorHandle(StageActorHandleType::Any),
            "CueHandle" => Self::CueHandle,
            "VoiceHandle" => Self::VoiceHandle,
            "DebugStatePath" => Self::DebugStatePath,
            "ObservationFieldPath" => Self::ObservationFieldPath,
            "Unit" => Self::Unit,
            "Never" => Self::Never,
            _ => return None,
        })
    }
}

impl fmt::Display for TypeKind {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(&self.source_label())
    }
}

#[cfg(test)]
#[path = "types/semantic_tests.rs"]
mod semantic_tests;

#[cfg(test)]
mod entity_kind_tests {
    use super::{AgentBuiltinType, EntityKind, TypeKind};

    #[test]
    fn authored_entity_families_round_trip_without_other() {
        assert!(!EntityKind::AUTHORED_FAMILIES.is_empty());
        for family in EntityKind::AUTHORED_FAMILIES {
            let name = family
                .authored_type_name()
                .expect("the authored inventory contains only fixed families");
            assert_eq!(EntityKind::from_type_name(name).as_ref(), Some(family));
        }
        assert_eq!(
            EntityKind::Other("Plugin".to_owned()).authored_type_name(),
            None
        );
        assert_eq!(EntityKind::from_type_name("Plugin"), None);
    }

    #[test]
    fn entity_family_labels_are_owned_by_the_semantic_kind() {
        assert_eq!(
            EntityKind::AUTHORED_FAMILIES
                .iter()
                .map(EntityKind::as_str)
                .collect::<Vec<_>>(),
            [
                "agent",
                "entry",
                "flow",
                "choice",
                "choice_option",
                "character",
                "view",
                "action",
                "activity",
                "dialogue_line",
                "text",
                "content",
                "input",
                "button",
                "style",
                "asset",
                "image",
                "animation",
                "capture",
                "hook",
                "signal",
                "metric",
                "scene",
                "test",
                "bench",
                "layer",
                "voice",
                "se",
                "bgm",
                "audio_bus",
                "mixer_snapshot",
                "ducking",
                "motion",
                "rig",
                "slot",
                "target",
            ]
        );
        assert_eq!(EntityKind::Other("plugin".to_owned()).as_str(), "plugin");
    }

    #[test]
    fn agent_builtin_identity_is_typed_even_when_its_source_label_matches_named() {
        let builtins = [
            AgentBuiltinType::ObservedObjectId,
            AgentBuiltinType::CaptureFormat,
            AgentBuiltinType::CaptureKind,
            AgentBuiltinType::Diagnostics,
            AgentBuiltinType::WaitError,
            AgentBuiltinType::ViewportPoint,
            AgentBuiltinType::PointerButton,
            AgentBuiltinType::RagError,
            AgentBuiltinType::AgentSourcePosition,
            AgentBuiltinType::AgentProjectFlowControlSummary,
            AgentBuiltinType::AgentProjectGraphSummary,
            AgentBuiltinType::AgentBinaryBody,
            AgentBuiltinType::AgentBinaryEncoding,
            AgentBuiltinType::AgentBinaryData,
        ];

        for builtin in builtins {
            let typed = TypeKind::AgentBuiltin(builtin);
            let named = TypeKind::Named(builtin.source_label().to_owned());
            assert_eq!(typed.source_label(), named.source_label());
            assert_ne!(typed, named);
            assert_ne!(
                typed.semantic_identity_digest(),
                named.semantic_identity_digest()
            );
            assert_eq!(
                TypeKind::primitive_name(builtin.source_label()),
                Some(typed)
            );
        }
    }
}

fn function_effect_row_label(effects: &EffectRow) -> Option<String> {
    (effects.is_known() && !effects.is_empty()).then(|| effects.display_label())
}

impl EntityType {
    fn source_label(&self) -> String {
        self.value().map_or_else(
            || format!("Ref<{:?}>", self.kind()),
            |value| format!("Ref<{:?}, {}>", self.kind(), value.source_label()),
        )
    }
}

/// Standard iterator state family used by semantic trait witnesses.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum IteratorStateKind {
    Range,
    Seq,
    Stream,
    Vec,
    Array,
    Slice,
}

/// Deterministic map family preserved by semantic type checking.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum MapKind {
    Ordered,
    Sorted,
    BTree,
}

/// Minimal typestate for scoped handles tracked by the syntax checker.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum HandleState {
    Live,
    Dropped,
    Detached,
    MovedOut,
}

/// Borrowed interpretation of the finite Signal declaration carrier domain.
/// The original accepted type remains the stored entity type.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SignalObservableType<'a> {
    Watch(&'a TypeKind),
    Stream {
        item: &'a TypeKind,
        error: &'a TypeKind,
    },
    Sample(&'a TypeKind),
}

impl<'a> SignalObservableType<'a> {
    pub const fn payload(self) -> &'a TypeKind {
        match self {
            Self::Watch(payload) | Self::Sample(payload) => payload,
            Self::Stream { item, .. } => item,
        }
    }
}

impl TypeKind {
    pub fn signal_observable(&self) -> Option<SignalObservableType<'_>> {
        match self {
            Self::Stream { item, error } => Some(SignalObservableType::Stream { item, error }),
            Self::AcceptedNominal(carrier) => {
                let [payload] = carrier.arguments() else {
                    return None;
                };
                if carrier.declaration() == &crate::env::nominal::standard_nominal_id("Watch") {
                    Some(SignalObservableType::Watch(payload))
                } else if carrier.declaration()
                    == &crate::env::nominal::standard_nominal_id("Sample")
                {
                    Some(SignalObservableType::Sample(payload))
                } else {
                    None
                }
            }
            _ => None,
        }
    }
}
