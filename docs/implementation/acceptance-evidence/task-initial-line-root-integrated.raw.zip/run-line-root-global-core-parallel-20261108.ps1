$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-root-defer-20261108.global-core-parallel'
if (Test-Path "$prefix.source.json") { throw 'Global Core epoch exists' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-root-defer-20261108.validation-source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" } }
}
Assert-Inputs
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch; parallelGroup = 'line-root-defer-global-core-and-cli-check'; coordination = 'Run pure Sans-I/O Core unit cases in the full non-CLI workspace feature composition alongside the independent full CLI check. Each test command uses four Cargo build jobs for resource coordination; test threads, profiles, assertions and budgets remain unchanged. Core src has no fs/process test users; compile-fail integration targets are excluded from this parallel runtime slice.' } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.source.json"
$common = @('--locked', '--workspace', '--exclude', 'arcweft-cli', '--all-features', '--lib', '--tests', '--build-jobs', '4', '-E', 'package(=arcweft-core) & binary(=arcweft_core)')
$arguments = @('nextest', 'list') + $common + @('--message-format', 'json')
$started = [DateTime]::UtcNow
& cargo @arguments 1> "$prefix.selection.json" 2> "$prefix.selection.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.selection.receipt.json"
if ($code -ne 0) { throw 'Global Core selection failed' }
$list = Get-Content "$prefix.selection.json" -Raw | ConvertFrom-Json -Depth 60
$selected = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) { $suite = $property.Value; $matched = @($suite.testcases.PSObject.Properties | Where-Object { $_.Value.'filter-match'.status -eq 'matches' }); if ($matched.Count) { [ordered]@{ binary = $property.Name; package = $suite.'package-name'; name = $suite.'binary-name'; matched = $matched.Count } } })
if ($selected.Count -ne 1 -or $selected[0].package -ne 'arcweft-core' -or $selected[0].name -ne 'arcweft_core') { throw 'Parallel Core runtime slice is not isolated' }
$selected | ConvertTo-Json -Depth 5 | Set-Content "$prefix.selection-review.json"
$arguments = @('nextest', 'run') + $common + @('--no-tests', 'fail', '--no-fail-fast')
$started = [DateTime]::UtcNow
& cargo @arguments *> "$prefix.run.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; parallelGroup = 'line-root-defer-global-core-and-cli-check'; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.run.receipt.json"
Get-Content "$prefix.run.log" -Tail 10
exit $code
