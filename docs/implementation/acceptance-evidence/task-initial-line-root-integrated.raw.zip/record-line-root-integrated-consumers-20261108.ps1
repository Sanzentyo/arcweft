$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$name='line-root-defer-20261108'
$audit=Get-Content "$taskTemp/$name.integrated-consumers.audit.json" -Raw|ConvertFrom-Json -Depth 60
if($audit.run -ne 8035 -or $audit.passed -ne 8031 -or $audit.failed -ne 4 -or $audit.skipped -ne 41 -or $audit.duplicates -ne 0 -or $audit.reusedBinaryChecks.Count -ne 5 -or $audit.requiredRootCases.Count -ne 5){throw 'Final integrated evidence differs'}
$source=(git rev-parse HEAD).Trim()
if($source -ne '245fe74354733f1ee57a25ac43f60b2fbaca5947' -or $source -ne $audit.source){throw 'Integrated source differs'}
$archivePath='docs/implementation/acceptance-evidence/task-initial-line-root-integrated.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Integrated root archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
 $_.Name -match '^line-root-defer-20261108\.(global-|cli-full-check-parallel\.|cli-default-rest\.|parallel-intent|primary-before-complements\.|integrated-consumers\.|validation-source\.)' -or $_.Name -in @(
  'run-line-root-global-core-parallel-20261108.ps1','run-line-root-cli-full-check-parallel-20261108.ps1','run-line-root-global-pure-owners-parallel-20261108.ps1','run-line-root-global-rest-20261108.ps1','run-line-root-global-rest-r2-20261108.ps1','run-line-root-cli-default-rest-20261108.ps1','audit-line-root-integrated-consumers-20261108.ps1','audit-line-root-integrated-consumers-r1-20261108.ps1','record-line-root-integrated-consumers-20261108.ps1'
 )
}|Sort-Object Name)
$entries=@(foreach($file in $files){[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archivePath),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Integrated archive shape differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Integrated archive bytes differ'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$source;productionSource='5ba67c20a9aacafe3d1dd25939be42c92cddf52a';boundedEvidence='245fe74354733f1ee57a25ac43f60b2fbaca5947';primaryMatrix=$audit
 totals=[ordered]@{nonCli=[ordered]@{run=7324;passed=7324;failed=0;skipped=18};cliDefault=[ordered]@{run=711;passed=707;failed=4;skipped=23};combined=[ordered]@{run=8035;passed=8031;failed=4;skipped=41}}
 composition='The full non-CLI workspace all-feature lib/tests composition is partitioned into Core unit, RuntimePlan/Sema/Compiler units, and their exact complement. CLI default lib/bin/integration tests are partitioned into check and its complement. These are five invocations and two feature points, never one run. Actual 8035 case keys have zero overlap. All five excluded binary paths and SHA256 identities match pins recorded after the completed pure-unit commands and before complementary Cargo commands; CLI check was still running at pin time.'
 parallelCoordination='Pure Sans-I/O units ran alongside independent full CLI check. Each intentionally parallel test command used four Cargo build jobs under crates/AGENTS.md, with actual process arguments and overlap receipts retained. All other integration/compile-fixture/host/render runtime groups were serial, using default Cargo jobs. Test threads, profiles, execution budgets, assertion quantities and ignored/default-filter policy were unchanged.'
 acceptance='All five new root-defer regressions are included exactly once in the primary matrix. This supports the bounded initial-input/root-defer acceptance already published, while preserving Generic Match, Native and Line/init acceptance. It is not final acceptance of every producer/platform, Native public save, Tier2, or all Native/Web display parity.'
 baseline='The earlier f267dc30d20a25092c64d08bb42b596b14ad3400 matrix remains 8030 run / 8026 PASS / 4 FAIL / 41 SKIP. The new five root-defer test cases explain the new total, and all four failure IDs exactly match that retained baseline. Earlier standalone 2327 Core and 152 Compiler owner runs are supplemental and are not added to these primary totals.'
 failures='Fresh diagnostics are unchanged: authored Scroll shared callable semantic resolution at ExprId slot15; fixture011 active dialogue without required voice; and two obsolete receiverless promote inputs rejected at ExprId slot8 before verifier proof checks. Promotion receiver admission is still a separate concrete implementation condition, not declared fixed by changing old test text.'
 preparationCorrection='The first complementary non-CLI wrapper completed its catalog but referenced the obsolete ownership-review-r2.json suffix before starting any tests. Its original catalog and refusal are retained. The corrected global-rest-r2 wrapper uses the current typed dependency graph. This is not a product-test failure or a passed runtime. The first final-audit script also stopped before its terminal report because a foreach variable shadowed the evidence stem; the corrected audit and original script are retained, without rerunning or modifying product tests. A commentary claim of runtime start was corrected immediately after observing this refusal.'
 raw=[ordered]@{path=(Split-Path $archivePath -Leaf);sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if($ledger.Contains('"initialInputLineRootIntegratedConsumers"')){throw 'Integrated root record exists'}
$fragment=([ordered]@{initialInputLineRootIntegratedConsumers=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$ledger.LastIndexOf('}')
$after=$ledger.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| 共有契約／推移的逆依存matrix |')){
 '| 共有契約／推移的逆依存matrix | **root defer修復後のCore53照合：8031 PASS／4 FAIL／41 SKIP** | 検証Source 245fe74354733f1ee57a25ac43f60b2fbaca5947、production 5ba67c20a9aacafe3d1dd25939be42c92cddf52a。非CLIは同一workspace全feature構成の相補3 runで7324 PASS／18 SKIP。CLIは既定featureの相補2 runで次のCLI行の結果。全8035件の選択重複0、5境界の実binary path／SHA256を相補実行前後で照合し、3416入力drift0。実テスト50 package、compile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-webの3。新root defer回帰5件を各1回含む。単一runや同一feature全件へ合成せず、先行owner選択runは総数へ加えない。旧Sourceの8030件、全SHAと準備wrapper訂正は履歴へ保持する。[全選択・feature分割・実binary・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }elseif($_.StartsWith('| CLIの規定対象／全 check 照合 |')){
 '| CLIの規定対象／全 check 照合 | **CLI既定全711件：707 PASS／4 FAIL／23 SKIP** | 検証Source 245fe74354733f1ee57a25ac43f60b2fbaca5947。全check471件の467 PASS／4 FAILと、相補全target240 PASSを実行。標準対象外のbracket_numeric_batch／environment_callable_tensor／native_host_contractsも含む。失敗IDは前Sourceおよびb6df0c825805b9ac77cad6a9760761a861007679の4件と一致し、診断もshared callable意味解析、実音声なしの必須VoiceHandle、receiverなし旧promotion入力2件の型判定で同じ。promotion本体は該当行で追跡し、完了した各cutを戻さない。[各入力・失敗ID・診断・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
 }else{$_}
})
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath),($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — root defer修復後のCore53／CLI統合終端

検証Source **245fe74354733f1ee57a25ac43f60b2fbaca5947**、production **5ba67c20a9aacafe3d1dd25939be42c92cddf52a**。非CLIの同一workspace全feature構成を、Core2327、RuntimePlan／Sema／Compiler1714、残る3283の相補3 runに分け、**7324 PASS／18 SKIP**。CLI既定featureは全check471件の467 PASS／4 FAIL／23 SKIPと相補240 PASSで、**711 run／707 PASS／4 FAIL／23 SKIP**。計 **8035 run／8031 PASS／4 FAIL／41 SKIP**。二つのfeature点と五つのコマンドを単一runにしない。8035件の選択重複0、5本の実binary path／SHA256を相補実行前後で照合、3416入力drift0。Core逆依存53 packageの実テストは50、compile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-webの3。新root defer回帰5件を一度ずつ含む。

純粋なCore単体と独立する全CLI check、続いて純粋なRuntimePlan／Sema／Compiler単体とCLI checkを並行した。規約の資源配分例外に従い各Cargo buildは4 jobsとし、実process引数を保存した。残るcompile fixture／host／renderの統合runとCLI相補は直列・Cargo既定jobs。元のthread数、profile、assertion、実行量、budgetとignored条件は維持した。Core53のcold build、slowなfanout・IME generator・公開API fixtureの実所要時間も原本に保持する。

4失敗のIDと診断は前Sourceと一致した。ScrollはExprId slot15のshared callable解決、fixture011は必須voiceなし、promotion2件は旧receiverなし入力がslot8の型判定で停止する。以前の8030件はそのSourceの実測として保持し、追加した5 testによる増分だけを今回の選択へ対応付けた。先行Core2327／Compiler152選択runは二重計上しない。最初の非CLI相補wrapperは、成功したcatalogの後に古い監査ファイル名を参照し、runtime前で停止した。元一覧と拒否を残し、別prefixのglobal-rest-r2で正しいgraphを照合して全件実行した。開始したとのcommentaryは、この拒否を観測した時点で訂正した。

現状一覧の統合終端未確認という記載を、今回の実終端を根拠に置換した。受入済みGeneric Match／Native／Line-init／初期入力／root deferを全体goalの未達で戻さず、他platform／Tier2／Native公開save／全画像parityの最終受入は推定しない。[全選択・実binary・公開SHA・失敗・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;run=$audit.run;passed=$audit.passed;failed=$audit.failed;skipped=$audit.skipped;rawEntries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json -Compress
