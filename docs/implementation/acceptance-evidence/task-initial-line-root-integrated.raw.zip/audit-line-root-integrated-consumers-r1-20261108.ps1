$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$name = 'line-root-defer-20261108'
$suffixes = @('global-core-parallel', 'global-pure-owners-parallel', 'global-rest-r2', 'cli-full-check-parallel', 'cli-default-rest')
$allCases = @()
$allIgnored = @()
$runs = @()
$lists = @{}
$epoch = (Get-Content (Join-Path $taskTemp "$name.validation-source.json") -Raw | ConvertFrom-Json).inputs
foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Final source drift' } }
foreach ($suffix in $suffixes) {
    $prefix = Join-Path $taskTemp "$name.$suffix"
    $source = Get-Content "$prefix.source.json" -Raw | ConvertFrom-Json -Depth 10
    if (($source.inputs | ConvertTo-Json -Compress -Depth 5) -cne ($epoch | ConvertTo-Json -Compress -Depth 5)) { throw "Input epoch differs: $suffix" }
    $receipt = Get-Content "$prefix.run.receipt.json" -Raw | ConvertFrom-Json
    if ($receipt.sourceDrift -ne 0) { throw 'Recorded drift' }
    $list = Get-Content "$prefix.selection.json" -Raw | ConvertFrom-Json -Depth 60
    $lists[$suffix] = $list
    $selected = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) {
        $suite = $property.Value
        foreach ($case in $suite.testcases.PSObject.Properties) {
            if ($case.Value.'filter-match'.status -eq 'matches') {
                [pscustomobject][ordered]@{ slice = $suffix; package = $suite.'package-name'; binary = $property.Name; test = $case.Name; key = $property.Name + '|' + $case.Name }
            } elseif ($case.Value.ignored -and $suite.status -eq 'listed') {
                $allIgnored += [pscustomobject][ordered]@{ slice = $suffix; binary = $property.Name; test = $case.Name; key = $property.Name + '|' + $case.Name }
            }
        }
    })
    $log = Get-Content "$prefix.run.log" -Raw
    $match = [regex]::Matches($log, 'Summary \[[^\]]+\]\s+(?<run>\d+) tests? run:\s+(?<passed>\d+) passed(?<rest>[^\r\n]*)') | Select-Object -Last 1
    if (-not $match) { throw "No terminal summary: $suffix" }
    $rest = $match.Groups['rest'].Value
    $summary = [pscustomobject][ordered]@{ run = [int]$match.Groups['run'].Value; passed = [int]$match.Groups['passed'].Value; failed = if ($rest -match '(\d+) failed') { [int]$Matches[1] } else { 0 }; skipped = if ($rest -match '(\d+) skipped') { [int]$Matches[1] } else { 0 }; terminal = $match.Value }
    if ($selected.Count -ne $summary.run -or $summary.run -ne $summary.passed + $summary.failed) { throw "Run/selection count differs: $suffix" }
    if ($suffix -ne 'cli-full-check-parallel' -and $receipt.exitCode -ne 0) { throw "Unexpected failed slice: $suffix" }
    $failures = @([regex]::Matches($log, '(?m)^\s+FAIL \[[^\]]+\] \([^\r\n]+\)\s+(?<binary>\S+)\s+(?<test>[^\r\n]+)') | ForEach-Object { [pscustomobject][ordered]@{ binary = $_.Groups['binary'].Value; test = $_.Groups['test'].Value.Trim() } } | Sort-Object { $_.binary + '|' + $_.test } -Unique)
    $runs += [pscustomobject][ordered]@{ slice = $suffix; receipt = $receipt; selected = $selected.Count; summary = $summary; failures = $failures }
    $allCases += $selected
}
$requiredRootCases = @('native_initial_owned_line_input_moves_into_the_line_root_defer', 'saved_awbc_initial_owned_line_input_moves_into_the_line_root_defer', 'native_initial_owned_line_root_defer_preserves_outcome_filters', 'saved_awbc_initial_owned_line_root_defer_preserves_outcome_filters', 'saved_awbc_initial_line_root_defer_rejects_forged_capture_custody')
foreach ($name in $requiredRootCases) {
    if (@($allCases | Where-Object { $_.binary -eq 'arcweft-compiler::evaluated_effects' -and $_.test.EndsWith('::' + $name) }).Count -ne 1) { throw "Root defer regression absent or duplicated: $name" }
}
$duplicates = @($allCases | Group-Object key | Where-Object Count -gt 1)
if ($duplicates.Count) { throw 'A test was counted in multiple primary slices' }
$duplicateIgnored = @($allIgnored | Group-Object key | Where-Object Count -gt 1)
if ($duplicateIgnored.Count) { throw 'An ignored test was counted twice' }
$expected = (Get-Content (Join-Path $taskTemp "$name.ownership-review.json") -Raw | ConvertFrom-Json -Depth 30).coreReversePackages
$packages = @($allCases.package | Sort-Object -Unique)
if (@($packages | Where-Object { $_ -notin $expected }).Count) { throw 'Unexpected reverse package' }
$binaryChecks = @()
foreach ($pair in @(
    @{ slice = 'global-core-parallel'; binaries = @('arcweft-core') },
    @{ slice = 'global-pure-owners-parallel'; binaries = @('arcweft-runtime-plan', 'arcweft-lang-sema', 'arcweft-compiler') },
    @{ slice = 'cli-full-check-parallel'; binaries = @('arcweft-cli::check') }
)) {
    $other = if ($pair.slice -eq 'cli-full-check-parallel') { 'cli-default-rest' } else { 'global-rest-r2' }
    foreach ($binary in $pair.binaries) {
        $first = $lists[$pair.slice].'rust-suites'.$binary
        $second = $lists[$other].'rust-suites'.$binary
        if (-not $first -or -not $second -or $first.'binary-path' -cne $second.'binary-path') { throw "Reused binary identity differs: $binary" }
        $binaryChecks += [pscustomobject][ordered]@{ binary = $binary; selectedBy = $pair.slice; excludedFrom = $other; path = $first.'binary-path'; sha256 = (Get-FileHash -LiteralPath $first.'binary-path').Hash.ToLowerInvariant() }
    }
}
$pins = Get-Content (Join-Path $taskTemp "$name.primary-before-complements.binaries.json") -Raw | ConvertFrom-Json
foreach ($row in $binaryChecks) {
    $pin = @($pins.binaries | Where-Object binary -eq $row.binary)
    if ($pin.Count -ne 1 -or $pin[0].path -cne $row.path -or $pin[0].sha256 -cne $row.sha256) { throw "Actual executable changed across complementary commands: $($row.binary)" }
}
$ledger = Get-Content 'docs/implementation/acceptance-evidence/task-flow-registry-execution.json' -Raw | ConvertFrom-Json -Depth 100
$baselineFailures = @($ledger.unsafeAuditBodyAndTypedCliFixtures.cli.remaining | ForEach-Object { $_.binary + '|' + $_.test } | Sort-Object)
$currentFailures = @($runs.failures | ForEach-Object { $_.binary + '|' + $_.test } | Sort-Object -Unique)
if (@(Compare-Object $baselineFailures $currentFailures).Count) { throw 'Failure set differs from the retained baseline' }
$receipt = [pscustomobject][ordered]@{
    source = (& git rev-parse HEAD).Trim(); sourceInputs = $epoch.Count; sourceDrift = 0
    graphPackages = $expected; matchedPackages = $packages; compileOnlyPackages = @($expected | Where-Object { $_ -notin $packages })
    runs = $runs; requiredRootCases = $requiredRootCases; selectedCases = $allCases.Count; duplicates = 0; ignoredCases = $allIgnored; ignoredDuplicates = 0
    run = [int](($runs.summary.run | Measure-Object -Sum).Sum); passed = [int](($runs.summary.passed | Measure-Object -Sum).Sum); failed = [int](($runs.summary.failed | Measure-Object -Sum).Sum); skipped = [int](($runs.summary.skipped | Measure-Object -Sum).Sum)
    reusedBinaryChecks = $binaryChecks; pinsBeforeComplements = $pins; baselineFailureSetPreserved = $true
    scope = 'Non-CLI full-workspace all-feature composition, partitioned into four pure unit binaries and their complement; CLI default-feature all targets, partitioned into check and its complement. Separate invocations/feature points, not one global run. Supplemental package slices are not added to this primary total.'
    at = [DateTime]::UtcNow.ToString('o')
}
$receipt | ConvertTo-Json -Depth 20 | Set-Content (Join-Path $taskTemp "$name.integrated-consumers.audit.json")
[pscustomobject][ordered]@{ source = $receipt.source; graph = $expected.Count; matched = $packages.Count; compileOnly = $receipt.compileOnlyPackages; run = $receipt.run; passed = $receipt.passed; failed = $receipt.failed; skipped = $receipt.skipped; duplicateCases = 0; binaryIdentityChecks = $binaryChecks.Count; baselineFailureSetPreserved = $true } | ConvertTo-Json -Depth 5 -Compress
