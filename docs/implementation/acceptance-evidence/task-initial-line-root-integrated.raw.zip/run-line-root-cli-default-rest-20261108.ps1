$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-root-defer-20261108.cli-default-rest'
if (Test-Path "$prefix.source.json") { throw 'CLI default remainder epoch exists' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-root-defer-20261108.validation-source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" } }
}
Assert-Inputs
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch; features = 'CLI default; all library/bin/integration targets except the already completed check binary. Includes bracket_numeric_batch, environment_callable_tensor and native_host_contracts outside the standard recipe.'; checkReuse = 'line-root-defer-20261108.cli-full-check-parallel.run.receipt.json'; defaultCargoJobs = $true } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.source.json"
$common = @('--locked', '-p', 'arcweft-cli', '--lib', '--tests', '-E', '!binary(=check)')
$arguments = @('nextest', 'list') + $common + @('--message-format', 'json')
$started = [DateTime]::UtcNow
& cargo @arguments 1> "$prefix.selection.json" 2> "$prefix.selection.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.selection.receipt.json"
if ($code -ne 0) { throw 'CLI default remainder selection failed' }
$list = Get-Content "$prefix.selection.json" -Raw | ConvertFrom-Json -Depth 60
$selected = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) { $suite = $property.Value; $matched = @($suite.testcases.PSObject.Properties | Where-Object { $_.Value.'filter-match'.status -eq 'matches' }); if ($matched.Count) { [ordered]@{ binary = $property.Name; name = $suite.'binary-name'; matched = $matched.Count } } })
if (@($selected | Where-Object name -eq 'check').Count) { throw 'Completed check binary was selected again' }
foreach ($name in @('bracket_numeric_batch', 'environment_callable_tensor', 'native_host_contracts', 'check_core_cli')) { if (@($selected | Where-Object name -eq $name).Count -ne 1) { throw "CLI remainder consumer excluded: $name" } }
[ordered]@{ catalog = $list.'test-count'; selected = $selected } | ConvertTo-Json -Depth 7 | Set-Content "$prefix.selection-review.json"
$arguments = @('nextest', 'run') + $common + @('--no-tests', 'fail', '--no-fail-fast')
$started = [DateTime]::UtcNow
& cargo @arguments *> "$prefix.run.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.run.receipt.json"
Get-Content "$prefix.run.log" -Tail 15
exit $code
