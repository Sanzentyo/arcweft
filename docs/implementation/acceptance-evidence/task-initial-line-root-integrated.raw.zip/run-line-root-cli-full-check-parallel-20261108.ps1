$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-root-defer-20261108.cli-full-check-parallel'
if (Test-Path "$prefix.source.json") { throw 'CLI full-check epoch already exists' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-root-defer-20261108.validation-source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" } }
}
Assert-Inputs
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch; features = 'CLI default features, matching the retained four-failure baseline. Parallel group line-root-defer-global-core-and-cli-check uses four Cargo build jobs per independent test command for resource coordination; no test-thread/profile/budget/assertion or ignored/default-filter change.' } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.source.json"
$arguments = @('nextest', 'list', '--locked', '-p', 'arcweft-cli', '--test', 'check', '--build-jobs', '4', '--message-format', 'json')
$started = [DateTime]::UtcNow
& cargo @arguments 1> "$prefix.selection.json" 2> "$prefix.selection.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.selection.receipt.json"
if ($code -ne 0) { throw 'CLI check selection failed' }
$list = Get-Content "$prefix.selection.json" -Raw | ConvertFrom-Json -Depth 60
$cases = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) { foreach ($case in $property.Value.testcases.PSObject.Properties) { if ($case.Value.'filter-match'.status -eq 'matches') { $case.Name } } })
$baseline = @('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering', 'spec_valid_run_edge_fixture_now_executes', 'verify_json_records_required_solver_checks', 'verify_json_reports_missing_promotion_proof')
foreach ($name in $baseline) { if ($name -notin $cases) { throw "Retained CLI failure case excluded: $name" } }
[ordered]@{ catalog = $list.'test-count'; matched = $cases.Count; baselineFailuresIncluded = $baseline; tests = $cases } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.selection-review.json"
$arguments = @('nextest', 'run', '--locked', '-p', 'arcweft-cli', '--test', 'check', '--build-jobs', '4', '--no-tests', 'fail', '--no-fail-fast')
$started = [DateTime]::UtcNow
& cargo @arguments *> "$prefix.run.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.run.receipt.json"
Get-Content "$prefix.run.log" -Tail 20
exit $code
