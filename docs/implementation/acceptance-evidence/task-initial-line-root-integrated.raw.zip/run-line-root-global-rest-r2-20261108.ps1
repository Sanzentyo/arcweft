$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-root-defer-20261108.global-rest-r2'
if (Test-Path "$prefix.source.json") { throw 'Global rest epoch exists' }
$coreReceiptPath = Join-Path $PSScriptRoot 'line-root-defer-20261108.global-core-parallel.run.receipt.json'
$coreReceipt = Get-Content $coreReceiptPath -Raw | ConvertFrom-Json
if ($coreReceipt.exitCode -ne 0 -or $coreReceipt.sourceDrift -ne 0) { throw 'Unified Core pass unavailable' }
$ownerReceiptPath = Join-Path $PSScriptRoot 'line-root-defer-20261108.global-pure-owners-parallel.run.receipt.json'
$ownerReceipt = Get-Content $ownerReceiptPath -Raw | ConvertFrom-Json
if ($ownerReceipt.exitCode -ne 0 -or $ownerReceipt.sourceDrift -ne 0) { throw 'Unified pure-owner pass unavailable' }
if (-not (Test-Path (Join-Path $PSScriptRoot 'line-root-defer-20261108.cli-full-check-parallel.run.receipt.json'))) { throw 'Parallel CLI command still running; serialize remaining runtime groups' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-root-defer-20261108.validation-source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" } }
}
Assert-Inputs
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch; reuse = 'Only the completed Core/RuntimePlan/Sema/Compiler unit binaries are excluded; they ran in the identical full non-CLI workspace all-feature package/target composition. Cargo build-job coordination changes scheduling, not features, profiles or test inputs. All other matching Core reverse binaries remain selected.'; coreReceipt = $coreReceiptPath; ownerReceipt = $ownerReceiptPath; defaultCargoJobs = $true } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.source.json"
$common = @('--locked', '--workspace', '--exclude', 'arcweft-cli', '--all-features', '--lib', '--tests', '-E', 'rdeps(=arcweft-core) & !((package(=arcweft-core) & binary(=arcweft_core)) | (package(=arcweft-runtime-plan) & binary(=arcweft_runtime_plan)) | (package(=arcweft-lang-sema) & binary(=arcweft_lang_sema)) | (package(=arcweft-compiler) & binary(=arcweft_compiler)))')
$arguments = @('nextest', 'list') + $common + @('--message-format', 'json')
$started = [DateTime]::UtcNow
& cargo @arguments 1> "$prefix.selection.json" 2> "$prefix.selection.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.selection.receipt.json"
if ($code -ne 0) { throw 'Global rest selection failed' }
$list = Get-Content "$prefix.selection.json" -Raw | ConvertFrom-Json -Depth 60
$cases = @()
$selected = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) {
    $suite = $property.Value
    $matched = @($suite.testcases.PSObject.Properties | Where-Object { $_.Value.'filter-match'.status -eq 'matches' })
    if ($matched.Count) {
        foreach ($case in $matched) { $cases += [ordered]@{ package = $suite.'package-name'; binary = $property.Name; test = $case.Name } }
        [ordered]@{ package = $suite.'package-name'; binary = $property.Name; name = $suite.'binary-name'; matched = $matched.Count }
    }
})
$excludedNames = @('arcweft_core', 'arcweft_runtime_plan', 'arcweft_lang_sema', 'arcweft_compiler')
if (-not $selected.Count -or @($selected | Where-Object { $_.name -in $excludedNames }).Count) { throw 'Unexpected rest selection' }
$required = @('native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line', 'saved_awbc_ordinary_flow_defer_reexports_an_actor_through_its_nested_line', 'native_initial_copy_line_input_remains_available_in_its_caller', 'saved_awbc_initial_copy_line_input_remains_available_in_its_caller', 'saved_awbc_initial_line_input_rejects_forged_packet_and_activation_slots')
foreach ($name in $required) { if (@($cases | Where-Object { $_.test -eq $name -or $_.test.EndsWith('::' + $name) }).Count -ne 1) { throw "Required runtime regression excluded: $name" } }
$expected = (Get-Content (Join-Path $PSScriptRoot 'line-root-defer-20261108.ownership-review.json') -Raw | ConvertFrom-Json -Depth 30).coreReversePackages
$packages = @($selected.package | Sort-Object -Unique)
if (@($packages | Where-Object { $_ -notin $expected -or $_ -eq 'arcweft-cli' }).Count) { throw 'Unexpected package outside the non-CLI Core closure' }
[ordered]@{ graphPackages = $expected; packages = $packages; packagesWithoutMatchedCases = @($expected | Where-Object { $_ -notin $packages }); selected = $selected; requiredRegressions = $required; cases = $cases } | ConvertTo-Json -Depth 8 | Set-Content "$prefix.selection-review.json"
$arguments = @('nextest', 'run') + $common + @('--no-tests', 'fail', '--no-fail-fast')
$started = [DateTime]::UtcNow
& cargo @arguments *> "$prefix.run.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; coreReuse = $coreReceiptPath; ownerReuse = $ownerReceiptPath; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.run.receipt.json"
Get-Content "$prefix.run.log" -Tail 20
exit $code
