$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '7bc0469968b57aa758b8c513779766e105244b83'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'canonical-materialization-owner.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod [A-Za-z0-9_]+ \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='ConstraintMaterialization is the single owner of callback ticket issuer, active identity, correlation and ticket ordinals, queued canonical components, sealed or rejected results and retained failure. The previous transaction state and result comparison implementations are removed and delegated to that owner. CompletedOriginalMember now owns this queue directly rather than a parallel canonical component. The real closed-original forest stages each queue only after canonical construction against its exact joint branch and completion owner; late failure still returns the same affine forest without publishing earlier staged queues. A graph-owner identity lease is retained, not a graph borrow, allowing the callback consumer to validate its actual prepared graph before callbacks while moving ready tickets without a graph loan. Queue construction bills before issuer and lease clones, checks ordinal arithmetic, and accepts only already canonical components; no template opening, body preparation, inference or effect minimum occurs in this owner. Consuming finish preserves source and fatal precedence, semantic and opaque result comparisons and actual open-path cycle diagnostics. Invalid consumed submissions retain a failure before returning, preventing a caller from ignoring the error and publishing an earlier sealed alternative. Two new fixtures use actual original forest inference and completion to check foreign graph and ticket issuers, binding identities, unchanged graph terms, and persistent invalid-submission refusal after an earlier seal. Existing canonical member, late failure retry and joint source-empty fixtures now drive this owner. Suspension issuer identity assertions remain, through a test-only read accessor; obsolete queue field readers are migrated. All tests are unrun because the required locked Sema test-target check fails. Original old fixtures and the eager transaction adapter still need real graph and BoundScoped/Future phase migration. The callable callback owner, actual canonical consumer driver, frontend public switch, Fn-local quantified and guarded contracts and broad body-once acceptance remain unfinished. No comprehensive allocation/copy preflight, single-pass, performance or workspace success claim is made. Dependencies, features, facade, layer direction, I/O, unsafe, codecs, versions, budgets, jobs and profiles are unchanged. Resolved Cargo graph and reverse-dependency evidence are reused; no scanner or broad acceptance rerun is claimed. Accepted Generic Match and runtime results remain accepted. LOC, bytes, growth and test classification are review evidence and this cohesive queue and lifecycle is its real owner boundary.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'canonical-materialization-owner.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02','dev03','dev04','dev05')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'canonical-materialization-owner.'+$iteration+$suffix}})
$names+=@('canonical-materialization-owner.source-publication.json','canonical-materialization-owner.ownership-review.json','canonical-materialization-owner.staged-review.json','canonical-materialization-owner.dev05-diagnostic-review.json')
$names+=@('run-canonical-materialization-owner-check.ps1','archive-canonical-materialization-owner.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-canonical-materialization-owner-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-canonical-materialization-owner-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'canonical-materialization-owner.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
