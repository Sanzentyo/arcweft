$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw | ConvertFrom-Json -AsHashtable -Depth 100 }
$publication = Read-Record 'rich-text-length-checkpoint.verified'
$owner = Read-Record 'rich-text-length-owner2-20261105.runtime.terminal-audit'
$compiler = Read-Record 'rich-text-length-compiler1-20261105.runtime.terminal-audit'
$graph = Read-Record 'rich-text-length.graph'
$structure = Read-Record 'rich-text-length.structure'
if ((git rev-parse HEAD).Trim() -ne $publication.commit -or $owner.executed -ne 309 -or $owner.passed -ne 309 -or $compiler.executed -ne 318 -or $compiler.passed -ne 318 -or $structure.exitCode -ne 0 -or $graph.selectedPackages -ne 59 -or $graph.metadataTreeDrift -ne 0) { throw 'Inspect unexpected source/results before recording' }
$freeze = Read-Record 'rich-text-length-compiler1-20261105.source-freeze'
foreach ($row in $freeze.paths) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Source drift' } }
$recordPath = 'docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath = 'docs/implementation/current-status.md'
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$before = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if ($record.Contains('typedTextLengths')) { throw 'Preserve previous evidence' }
$history = [IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix = [ordered]@{ bytes = $history.Length; sha256 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant() }
$status = [IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n", "`n")
$oldRows = @($status -split "`n" | Where-Object { $_ -match '^\| (RichTextの部分layout指定／source factory|共有契約／推移的逆依存matrix|CLI全target照合|workspace check／Clippy・fmt・構造gate) \|' })
$genericRow = @($status -split "`n" | Where-Object { $_ -match '^\| Generic Match' })
$metrics = @(Import-Csv -LiteralPath "$taskTemp/rich-text-length-structure-report/file_metrics.csv" | Where-Object path -in $publication.paths.path)
if ($metrics.Count -ne 20) { throw 'Missing current Rust owner measurements' }
$metrics | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/rich-text-length.owner-metrics.json" -Encoding utf8
$files = @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object { $_.Name -like 'rich-text-length*' })
$files += @(Get-ChildItem -LiteralPath "$taskTemp/rich-text-length-structure-report" -File -Recurse)
foreach ($name in @('record-rich-text-length.ps1', 'run-presentation-projection-owner.ps1', 'audit-nextest-final-result.ps1', 'write-verified-evidence-archive.ps1')) { $files += Get-Item -LiteralPath "$taskTemp/$name" }
$root = [IO.Path]::GetFullPath($taskTemp)
$index = @(foreach ($file in @($files | Sort-Object FullName -Unique)) { [ordered]@{ entry = $file.FullName.Substring($root.Length + 1).Replace([IO.Path]::DirectorySeparatorChar, [char]'/'); bytes = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant() } })
$index | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskTemp/rich-text-length.archive-inputs.json" -Encoding utf8
$files += Get-Item -LiteralPath "$taskTemp/rich-text-length.archive-inputs.json"
. "$taskTemp/write-verified-evidence-archive.ps1"
$archive = 'docs/implementation/acceptance-evidence/task-rich-text-length.raw.zip'
$raw = Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record.typedTextLengths = [ordered]@{
    version = 1; recordedAt = [DateTime]::UtcNow.ToString('o'); source = $publication
    state = 'Authored px/pt transport and shared text geometry resolution are implemented and owner/source-integration validated. Full59 reverse, full98 quality, final CLI/render parity and the remaining typed font/static provenance contracts are still separate.'
    implementation = @('Keep the existing CheckedLength as the authored length authority in RichTextStyle::Size and all sparse/resolved layout length fields. Compiler Content lowering and CharacterDialogue projection retain the actual unit; JSON has no legacy numeric/unit-dropping reader.', 'Presentation authoring_schema owns one FONT_SIZE_LIMITS for both direct styles and Content callable values. Accept Px and Pt as required by the maintained source examples; numeric bounds, precision and byte allowances remain unchanged. Ruby policy retains its existing accepted units and bounds.', 'RenderText owns the private-field ResolvedTextLength admission into nonnegative logical milli-pixels. Px is identity and Pt uses the CSS absolute ratio4/3, rounded once with checked integer arithmetic. Relative units without context, negatives and signed-domain overflow return typed errors. TextStyleCascade, vertical column spacing and ruby size/gap/overhang/collision consumers share this resolution; absent values alone choose defaults. Device scaling remains downstream.', 'Delete the old milli_points-only Size field, tuple projections that dropped layout units, duplicate font-size policy and invalid-value fallback paths. Keep Arcweft-owned contracts at version1. No Cargo dependency changes.')
    contract = [ordered]@{ path = 'docs/03-presentation/text-typesetting.md'; primarySource = 'https://www.w3.org/TR/css-values-4/#absolute-lengths'; rationale = 'Text geometry uses one logical-pixel basis shared by Native and Web. The fixed CSS ratio determines logical points; device DPI is not inferred. This is a maintained consuming-boundary contract, not an early conversion at factory/call ingress.' }
    validation = [ordered]@{
        initialOwners = (Read-Record 'rich-text-length-owner1-20261105.runtime.terminal-audit'); initialReason = '309 run,308 PASS/1 FAIL: direct-style schema test still expected only[Pt]. Update its exact inventory to[Px,Pt], preserving all other assertions and numeric limits; consolidate both schema consumers onto one policy. No runtime implementation failure in this attempt.'
        owners = $owner; ownerCommand = (Read-Record 'rich-text-length-owner2-20261105.runtime').command
        ownerScope = 'Separate complete six-package run,309/309 PASS,0 skipped. Includes existing presentation/editor/text suites plus mixed-unit TextModel JSON,18pt/24px body metrics,9pt/12px ruby geometry in horizontal/vertical-rl/vertical-lr, rounding and typed invalid-unit/negative/overflow rejection.'
        compiler = $compiler; compilerCommand = (Read-Record 'rich-text-length-compiler1-20261105.runtime').command
        compilerScope = 'One318-case run: all316 callable_execution integration cases plus2 selected Compiler library source-layout cases. The unchanged original2 px factory cases now pass; direct/alias source order and quantity properties run in Native and decoded AWBC with public JSON save at each OneOp. Static materialized templates preserve both font/ruby units. This is not all Compiler library tests, public Native session-save or final Native/Web image parity.'
        sourceRelation = 'Owner/graph/structure froze4107 actual repository inputs on848d782dcbafe834f02a082e8d0a82b2c73daf54 plus21 published paths; Compiler froze the same inputs on d693a3fcc4b4716ac9d608e9c075d8f1ff96bcdf. Each source/case/executable drift0. Relevant original user WIP is observed, not pristine HEAD.'
        formatting = 'All20 changed Rust paths rustfmt and staged whitespace exit0.'; structure = $structure
    }
    graph = $graph
    ownershipReview = 'CheckedLength remains the single authored quantity value. Presentation owns one font-size acceptance policy; RenderText owns absolute logical-pixel admission; TextLayout consumes it without implementing a second unit conversion. Authored cascade/save data retain units. All20 Rust file/owner/embedded-test measurements and98-package structure results are archived:3337 files,3206 Rust,1807432 physical Rust LOC,385 review triggers,0 blocking. The actual7-root closure has59 packages; metadata/tree all-target/all-feature normal/build/dev difference0. The additional package over the previous58 is the newly touched root arcweft-primitives.'
    correctionReason = 'Supersedes only the old2 px factory failures and unit-dropping current statement for this new source, supported by the unchanged cases now passing and new unit/geometry evidence. Keep every earlier failed run and full SHA unchanged. Do not reopen Generic Match or unrelated accepted boundaries because the overall goal is incomplete.'
    supersededCurrentRows = $oldRows; historyPrefix = $historyPrefix
    raw = [ordered]@{ path = $archive; bytes = $raw.bytes; sha256 = $raw.sha256; entries = $raw.entries.Count; entryDrift = 0; indexEntry = 'rich-text-length.archive-inputs.json' }
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$sha = $publication.commit
$rows = @(foreach ($line in ($status -split "`n")) {
    if ($line.StartsWith('| RichTextの部分layout指定／source factory |')) { "| RichTextの部分layout指定／source factory | **既受入を維持。呼出し順序とpx／pt保持・geometry解決を検証／公開済み、総合受入は継続** | Source ${sha}はCheckedLengthを本文・ruby・layoutに保持し、単一のfont-size policyと共有の論理px解決へ接続する。6 ownerの独立runは309／309 PASS、Compilerの別runは全316 callable integration＋source-layout 2件の318／318 PASS。元のpx2失敗は同じ条件でPASSとなり、このSourceの残作業から除く。直接／aliasの順序、Native／decoded AWBCと各OneOp公開JSON保存、本文18pt／24pxとruby9pt／12pxのgeometryをそれぞれの検証範囲で確認した。typed bare serif、static inline_stylesの出典、全体逆依存・CLI・最終画像parityを継続する。部分layout・共通property等の既受入は維持する。[旧失敗・訂正理由・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |" }
    elseif ($line.StartsWith('| 共有契約／推移的逆依存matrix |')) { "| 共有契約／推移的逆依存matrix | **直近の全53実測を保持。今回の全59逆依存は未実行** | Source2aaa0480b171d15274737d7bd49a3c391ce19096の全53実runは7808件中7793 PASS／15 CLI FAIL、40 skipped。50 packageに実テストがあり、3 packageはbuildのみ。source／case／EXE drift0。中間Source${sha}の変更7 ownerは実graphで59 package、normal／build／dev・all target／all featureのmetadata／tree差分0。6 owner309件とCompiler318件の独立したPASSを、全59の実行へ合算しない。[全実測・新graph・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |" }
    elseif ($line.StartsWith('| CLI全target照合 |')) { $line.Replace('中間Source 083baa5e4596a9f4d36c32bb1124adc9683d2db3', "中間Source $sha") }
    elseif ($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')) { $line.Replace('Source083baa5e4596a9f4d36c32bb1124adc9683d2db3は変更Rust19件', "Source${sha}は変更Rust20件") }
    else { $line }
})
if (@(Compare-Object $genericRow @($rows | Where-Object { $_ -match '^\| Generic Match' })).Count) { throw 'Generic Match row changed' }
[IO.File]::WriteAllText((Join-Path $PWD $statusPath), ($rows -join "`n"), [Text.UTF8Encoding]::new($false))
$append = @"

## 2026-11-05 — Preserve typography length units through text geometry

- Source $sha (parent $($publication.parent)) publishes20 Rust paths and the maintained typography contract. CheckedLength retains actual units in text/layout/save data, one Presentation policy accepts px/pt, and shared RenderText resolution establishes logical geometry using the CSS4/3 point ratio without device-DPI inference. Invalid/relative/overflowing inputs reject with typed errors; only omission selects a default.
- Keep the first six-owner run309 executed/308 PASS/1 FAIL (old exact[Pt] expectation), the corrected independent full309/309 PASS, and a separate Compiler318/318 PASS run. Compiler covers all316 callable integration cases plus2 source-layout cases; the original2 px factory failures now pass unchanged. Mixed-unit JSON,18pt/24px body metrics and9pt/12px ruby geometry in all3 writing directions pass. No numeric bounds, budgets, source-order, copy or OneOp assertions were weakened.
- Each4107-input run has0 source/case/executable drift. All20 Rust fmt/whitespace and98-package structure gate exit0,385 review triggers/0 blocking. Actual7-root reverse closure59 packages, metadata/tree0 difference; full reverse runtime and full98 check/Clippy remain pending. Supersede the obsolete px/unit current statements only for this source; retain all historical failures/full SHAs and accepted Generic Match. [Raw, source relation and scope](acceptance-evidence/task-rich-text-property-identity.json); [one current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath), $append + "`n", [Text.UTF8Encoding]::new($false))
$after = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
foreach ($key in $before.Keys) { if (($before[$key] | ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key] | ConvertTo-Json -Depth 100 -Compress)) { throw 'Previous field changed' } }
$now = [IO.File]::ReadAllBytes((Join-Path $PWD $historyPath)); $prefix = [byte[]]::new($history.Length); [Array]::Copy($now, $prefix, $history.Length)
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $historyPrefix.sha256) { throw 'History prefix changed' }
[ordered]@{ source = $sha; priorFieldDrift = 0; historyPrefixDrift = 0; rawEntries = $raw.entries.Count; rawBytes = $raw.bytes; rawSha256 = $raw.sha256; reversePackages = $graph.selectedPackages } | ConvertTo-Json -Compress
