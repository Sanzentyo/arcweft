$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.compiler-expectation-r2'
if (Test-Path "$prefix.source.json") { throw 'Compiler expectation epoch exists' }
$path = 'crates/arcweft-compiler/src/project/tests.rs'
$before = (Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.consumer.source.json') -Raw | ConvertFrom-Json).inputs
$epoch = @(foreach ($row in $before) { [ordered]@{ path = $row.path; sha256 = (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() } })
$beforeHashes = @{}
foreach ($row in $before) { $beforeHashes[$row.path] = $row.sha256 }
$changed = @($epoch | Where-Object { $beforeHashes[$_.path] -ne $_.sha256 })
if ($changed.Count -ne 1 -or $changed[0].path.Replace('\', '/') -ne $path) { throw 'Repair changed more than the cfg(test) fixture helper' }
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch; changed = $changed; impact = 'Only compiler project/tests.rs, included by the project cfg(test) module. Production, Core, RuntimePlan and Sema inputs are unchanged; their earlier passed slices remain evidence.' } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.source.json"
function Assert-Inputs {
    foreach ($row in $epoch) { if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" } }
}
function Invoke-Check([string]$name, [string[]]$arguments) {
    $started = [DateTime]::UtcNow
    & cargo @arguments *> "$prefix.$name.log"
    $code = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.$name.receipt.json"
    Get-Content "$prefix.$name.log" -Tail 5
    if ($code -ne 0) { throw "Compiler expectation repair check failed: $name" }
}
Invoke-Check 'test' @('nextest', 'run', '--locked', '-p', 'arcweft-compiler', '--all-features', '--lib', '-E', 'rdeps(=arcweft-core)', '--no-tests', 'fail', '--no-fail-fast')
Invoke-Check 'clippy' @('clippy', '--locked', '-p', 'arcweft-compiler', '--all-targets', '--all-features')
$started = [DateTime]::UtcNow
& rustfmt --edition 2024 --config skip_children=true --check $path *> "$prefix.fmt.log"
$code = $LASTEXITCODE
Assert-Inputs
[ordered]@{ paths = @($path); exitCode = $code; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 4 | Set-Content "$prefix.fmt.receipt.json"
if ($code -ne 0) { throw 'Compiler expectation fmt failed' }
