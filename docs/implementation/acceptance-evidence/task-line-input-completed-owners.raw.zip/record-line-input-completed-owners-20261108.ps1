$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$name = 'line-initial-inputs-20261108'
$rows = @(Get-Content (Join-Path $taskTemp "$name.consumer-split-r3.results.jsonl") | ForEach-Object { $_ | ConvertFrom-Json -Depth 30 } | Where-Object index -le 53)
if ($rows.Count -ne 53 -or @($rows | Where-Object { -not $_.actual -or $_.actual.failed -ne 0 }).Count) { throw 'Completed owner set is not available' }
$stats = @($rows | Group-Object { $_.target.package } | Sort-Object Name | ForEach-Object { [ordered]@{ package = $_.Name; targets = $_.Count; run = [int](($_.Group.actual.run | Measure-Object -Sum).Sum); passed = [int](($_.Group.actual.passed | Measure-Object -Sum).Sum); failed = [int](($_.Group.actual.failed | Measure-Object -Sum).Sum); skipped = [int](($_.Group.actual.skipped | Measure-Object -Sum).Sum) } })
if ($stats.Count -ne 4 -or [int](($stats.passed | Measure-Object -Sum).Sum) -ne 4881) { throw 'Unexpected owner totals' }
$snapshotPath = Join-Path $taskTemp "$name.completed-owners.results.json"
if (Test-Path $snapshotPath) { throw 'Completed owner snapshot exists' }
$rows | ConvertTo-Json -Depth 30 | Set-Content $snapshotPath
$archivePath = 'docs/implementation/acceptance-evidence/task-line-input-completed-owners.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Completed owner archive exists' }
$files = @(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
    $fileName = $_.Name
    if ($fileName -match '^line-initial-inputs-20261108\.consumer-split(?:-r[23])?\.(?<index>\d{3})\.') { return [int]$Matches['index'] -le 53 }
    $fileName -like "$name.cli-summary.*" -or $fileName -like "$name.cli-source.*" -or $fileName -like "$name.compiler-expectation*" -or $fileName -like "$name.workspace.*" -or $fileName -like "$name.workspace-r2.*" -or $fileName -like "$name.consumer.*" -or $fileName -like "$name.consumer-r2.*" -or $fileName -like "$name.consumer-recovery.*" -or $fileName -eq "$name.completed-owners.results.json" -or $fileName -match '^line-initial-inputs-20261108\.consumer-split(?:-r[23])?\.(source|plan)\.json$' -or $fileName -in @('record-line-input-completed-owners-20261108.ps1', 'repair-defer-transfer-expectation-20261108.ps1', 'repair-defer-transfer-expectation-r2-20261108.ps1', 'run-line-input-consumer-split-20261108.ps1', 'run-line-input-consumer-split-r2-20261108.ps1', 'run-line-input-consumer-split-r3-20261108.ps1', 'run-line-input-consumer-tests-20261108.ps1', 'run-line-input-consumer-tests-r2-20261108.ps1', 'recover-line-input-consumer-build-20261108.ps1', 'run-line-input-workspace-quality-20261108.ps1', 'run-line-input-workspace-quality-r2-20261108.ps1')
} | Sort-Object Name)
$entries = @(foreach ($file in $files) { [ordered]@{ entry = $file.Name; bytes = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant() } })
$archive = [IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archivePath), [IO.Compression.ZipArchiveMode]::Create)
try { foreach ($file in $files) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, $file.Name) } } finally { $archive.Dispose() }
$archive = [IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try {
    if ($archive.Entries.Count -ne $entries.Count) { throw 'Archive count mismatch' }
    foreach ($row in $entries) {
        $entry = $archive.GetEntry($row.entry)
        if (-not $entry -or $entry.Length -ne $row.bytes) { throw 'Archive shape mismatch' }
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($hash -ne $row.sha256) { throw "Archive entry mismatch: $($row.entry)" }
    }
} finally { $archive.Dispose() }
function Read-Receipt([string]$suffix) { Get-Content (Join-Path $taskTemp "$name.$suffix") -Raw | ConvertFrom-Json -Depth 30 }
$record = [ordered]@{
    version = 1; date = '2026-11-08'
    productionSource = Read-Receipt 'cli-source.verified.json'
    expectationSource = Read-Receipt 'compiler-expectation-source.verified.json'
    completedOwners = $stats
    scope = 'Four owner packages, 53 targets: package/target all-feature slices. Not the complete 53-package Core reverse closure or a successful unified workspace execution.'
    sourceEpochs = @("$name.consumer.source.json", "$name.consumer-split.source.json", "$name.consumer-split-r2.source.json", "$name.compiler-expectation-r2.source.json", "$name.consumer-split-r3.source.json")
    reuse = 'Core 2380, RuntimePlan 165 and Sema 1413 passes retain their original epochs. Only compiler project/tests.rs changed under cfg(test); compiler unit uses the corrected full 191 PASS run. No reused test is counted twice. Compiler integration evaluated_effects117 and scoped_defer30 are included in its new 923-case owner total.'
    workspace = [ordered]@{ check = Read-Receipt 'workspace-r2.check.receipt.json'; clippy = Read-Receipt 'workspace-r2.clippy.receipt.json'; compilerRepairClippy = Read-Receipt 'compiler-expectation-r2.clippy.receipt.json'; compilerRepairFmt = Read-Receipt 'compiler-expectation-r2.fmt.receipt.json'; warnings = 'Retained; zero exit does not mean warning-free.' }
    corrections = @(
        'The CLI still called the removed captures API. Source 85021db282dcb038e0041a23ea41a354706b85bf exposes initial_inputs and shared_inputs, with actual CLI 1 PASS / 10 SKIP. The first E0599 check failure is retained.'
        'Compiler first ran 191:190 PASS/1 FAIL because a stale affine-Line rejection expectation received successful lowering. Source db3b5e7655a78394c1fafd951fdd735a6571dfef deletes that branch and checks selected transfer, origin and definition identity through verified canonical AWBC. The corrected full 191 run passed; production is unchanged.'
        'Both unified all-feature catalog builds stopped before test execution with OS 1455/allocation exhaustion and compiler abort/ICE. Eight isolated target list/build probes exited zero; they are not test passes. Workspace feature composition remains a separate required check.'
        'The first split wrapper joined the test selector into one argument after Core2327 PASS; it was fixed without rerunning that unchanged pass. A subsequent cfg(test) repair guard initially rejected Windows separator spelling before Cargo; its retry normalized the path. No source assertions/budgets/default Cargo jobs/profiles or ignored-test policy were weakened.'
    )
    remaining = 'The rest of the Core53 closure is running. The unified workspace feature composition, full CLI check baseline and broader goal acceptance remain separate. No accepted Generic Match, Native, Line/init or bounded ordinary-defer condition is reopened.'
    raw = [ordered]@{ path = Split-Path $archivePath -Leaf; sha256 = (Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant(); entries = $entries }
}
$ledgerPath = 'docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger = [IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if ($ledger.Contains('"initialInputCompletedOwners"')) { throw 'Completed owner evidence exists' }
$fragment = ([ordered]@{ initialInputCompletedOwners = $record } | ConvertTo-Json -Depth 60).Trim().Replace("`r`n", "`n")
$last = $ledger.LastIndexOf('}')
$after = $ledger.Substring(0, $last).TrimEnd() + ",`n  " + $fragment.Substring(1, $fragment.Length - 2).Trim() + "`n}`n"
$null = $after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath), $after, [Text.UTF8Encoding]::new($false))
$historyPath = 'docs/implementation/convergence-evidence-history.md'
$history = [IO.File]::ReadAllText((Join-Path (Get-Location) $historyPath))
$addition = @"

## 2026-11-08 — 初期 Line 入力の4 owner終端と旧期待の訂正

CLI Source **85021db282dcb038e0041a23ea41a354706b85bf** は残存していた captures API 利用を initial_inputs／shared_inputs へ移行し、公開CLIで2初期／1共有を確認した（1 PASS／10 SKIP）。全workspace・全target／全feature check／Clippyは終了0。旧E0599の初回失敗も保持する。テスト修正 Source **db3b5e7655a78394c1fafd951fdd735a6571dfef** は、既に正常loweringされるaffine初期入力を拒否するとした旧分岐を削除した。Copy／Moveの実ABI・元出自・定義identityをcanonical AWBC往復で照合し、初回Compiler unit190 PASS／1 FAILから修正後の全191 PASSを確認した。productionの巻戻しやassertion削減ではない。

4 ownerのpackage／target別・各package全feature検証は、Core13 target **2380 PASS**、RuntimePlan5 target **165 PASS／既存generator1 SKIP**、Sema5 target **1413 PASS**、Compiler30 target **923 PASS**。計53 target／4881 PASS／1 SKIPであり、Core逆依存53 package全体とは別である。Core／RuntimePlan／Semaの入力はcfg(test)内のCompiler helper訂正で変わらず、その通過記録を再利用した。Compilerの新117 evaluated_effectsと30 scoped_deferは923件の内数。初期4条件のNative／保存AWBCと保存slot改変拒否もこの117件でPASSした。新旧runを合成した再実行とはしない。

workspace一体の全feature catalogは2回ともOS1455／メモリ確保不足でテスト開始前に停止した。続く8 targetの個別list／build終了0をテストPASSには数えない。分割wrapperの引数結合ミスとWindows separator照合ミスも原本へ保持する。分割結果だけでworkspace feature統合の受入へ拡張せず、残るCore53／全CLI checkと合わせて継続する。旧7958 PASS／4 FAIL／41 SKIPと全SHAは変更せず履歴へ保持し、現状の古いCore2323・Copy専用拒否の重複説明をこの実測で置換した。Generic Match等の既受入は維持する。[各入力・終端・訂正・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText((Join-Path (Get-Location) $historyPath), $history.TrimEnd() + "`n" + $addition.Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$statusPath = 'docs/implementation/current-status.md'
$status = [IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$lines = @($status -split '\r?\n' | ForEach-Object {
    if ($_.StartsWith('| 共有契約／推移的逆依存matrix |')) {
        '| 共有契約／推移的逆依存matrix | **Core逆依存53 packageを再検証中。4 owner・53 targetは4881 PASS／1 SKIP** | Source db3b5e7655a78394c1fafd951fdd735a6571dfef。package／target別の各package全featureでCore2380、RuntimePlan165、Sema1413、Compiler923がPASS。既存generator1件はSKIP。Core／RuntimePlan／Semaの通過後に変更したのはCompilerのcfg(test) helperだけで、その3 ownerの入力を再利用した。全53 packageの終端やworkspace feature統合とは合算しない。一体catalogの2回はOS1455／メモリ不足でテスト前に停止し、分割結果を一体実行の合格にはしない。以前の全件数・失敗・SHAは履歴へ保持する。[全選択・入力・結果・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
    } elseif ($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')) {
        '| workspace check／Clippy・fmt・構造gate | **Source8502の全workspace check／Clippyは終了0。後続テスト修正のowner gateも終了0** | Source 85021db282dcb038e0041a23ea41a354706b85bf の全target／全feature check／Clippyは3416入力drift0。Source db3b5e7655a78394c1fafd951fdd735a6571dfef はCompilerのcfg(test)だけを修正し、Compiler全target／全feature Clippy・1 path fmtが終了0。CLIの2 pathと先行56 pathのfmt終了0、Core doctest80 PASSと構造gateの原入力も保持する。警告は原本に残し、単一の再実行へ合成しない。Cargo変更0、Core逆依存は53 package。最終統合・他platform／Tier2の受入へ拡張しない。[全実測・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
    } else { $_ }
})
$status = $lines -join "`n"
$old = 'Sourceの往復・実行identity・欠落／重複／foreign／不正mode拒否を含む11件、RuntimePlan165件、Compiler対象146件がPASS。'
if (-not $status.Contains($old)) { throw 'Initial-input row differs' }
$status = $status.Replace($old, 'Source往復・実行identity・欠落／重複／foreign／不正mode拒否を含む各ownerの最新全件検証は下表へ集約した。')
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath), $status, [Text.UTF8Encoding]::new($false))
[ordered]@{ source = $record.expectationSource.commit; owners = $stats; entries = $entries.Count; sha256 = $record.raw.sha256 } | ConvertTo-Json -Depth 5 -Compress
