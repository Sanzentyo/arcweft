$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.consumer-recovery'
if (Test-Path "$prefix.receipt.json") { throw 'Recovery receipt already exists' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.consumer.source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
$targets = @('project_function_instances', 'view_runtime', 'generic_continuation_snapshot', 'patch_schema', 'assertions', 'dialogue_view_store', 'repl_cell', 'windowed_live_patch_smoke')
$results = @()
foreach ($target in $targets) {
    Assert-Inputs
    $arguments = @('nextest', 'list', '--locked', '--workspace', '--exclude', 'arcweft-cli', '--all-features', '--test', $target, '-E', 'rdeps(=arcweft-core)', '--message-format', 'json')
    $started = [DateTime]::UtcNow
    & cargo @arguments 1> "$prefix.$target.selection.json" 2> "$prefix.$target.log"
    $code = $LASTEXITCODE
    Assert-Inputs
    $receipt = [ordered]@{ target = $target; arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o'); purpose = 'Sequential target compilation after OS 1455; default Cargo jobs and original workspace all-feature package selection retained. List only, no test pass claim.' }
    $receipt | ConvertTo-Json -Depth 5 | Set-Content "$prefix.$target.receipt.json"
    $results += $receipt
    [ordered]@{ target = $target; exitCode = $code } | ConvertTo-Json -Compress
    if ($code -ne 0) { Get-Content "$prefix.$target.log" -Tail 15; throw "Recovery target failed: $target" }
}
$results | ConvertTo-Json -Depth 6 | Set-Content "$prefix.receipt.json"
