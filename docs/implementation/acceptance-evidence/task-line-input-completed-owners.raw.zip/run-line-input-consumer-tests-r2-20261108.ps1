$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.consumer-r2'
if (Test-Path "$prefix.source.json") { throw 'Consumer source epoch already exists' }
$paths = @(rg --files --hidden -g '*.rs' -g 'Cargo.toml' -g 'Cargo.lock' -g 'rust-toolchain*' -g '.cargo/config*' -g '!target' -g '!.git' | Sort-Object -Unique)
$epoch = @(foreach ($path in $paths) { [ordered]@{ path = $path; sha256 = (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() } })
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.source.json"
function Assert-Inputs {
    foreach ($row in $epoch) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
# Match the maintained just test-affected target surface. All-features is a
# separate shared-contract slice; prior default-feature results stay historical.
$slices = @(
    @{ name = 'non-cli'; args = @('--workspace', '--lib', '--tests', '--exclude', 'arcweft-cli') },
    @{ name = 'cli-unit'; args = @('-p', 'arcweft-cli', '--lib', '--bins') },
    @{ name = 'cli-contract'; args = @('-p', 'arcweft-cli', '--test', 'runtime_native_options', '--test', 'check_core_cli', '--test', 'native_style_parity_sample', '--test', 'release_trust_json', '--test', 'arcw_fixtures_check_run', '--test', 'seq04_8_4_persistent_cache_build_cli_goldens') }
)
$allSelected = @()
$allCases = @()
foreach ($slice in $slices) {
    $selectionArgs = @('nextest', 'list', '--locked', '--all-features') + $slice.args + @('-E', 'rdeps(=arcweft-core)', '--message-format', 'json')
    $started = [DateTime]::UtcNow
    & cargo @selectionArgs 1> "$prefix.$($slice.name).selection.json" 2> "$prefix.$($slice.name).selection.log"
    $code = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ arguments = $selectionArgs; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.$($slice.name).selection.receipt.json"
    if ($code -ne 0) { throw "Consumer selection failed: $($slice.name)" }
    $list = Get-Content "$prefix.$($slice.name).selection.json" -Raw | ConvertFrom-Json -Depth 60
    $selected = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) {
        $suite = $property.Value
        $matched = @($suite.testcases.PSObject.Properties | Where-Object { $_.Value.'filter-match'.status -eq 'matches' })
        if ($matched.Count) {
            foreach ($case in $matched) {
                $allCases += [ordered]@{ package = $suite.'package-name'; binary = $property.Name; test = $case.Name; ignored = $case.Value.ignored }
            }
            [ordered]@{ slice = $slice.name; binary = $property.Name; package = $suite.'package-name'; matched = $matched.Count; ignored = @($matched | Where-Object { $_.Value.ignored }).Count }
        }
    })
    [ordered]@{ catalogTests = $list.'test-count'; selectedBinaries = $selected; packages = @($selected.package | Sort-Object -Unique) } | ConvertTo-Json -Depth 8 | Set-Content "$prefix.$($slice.name).selection-review.json"
    if (-not $selected.Count) { throw "Empty consumer selection: $($slice.name)" }
    $allSelected += $selected
}
[ordered]@{ targetSurface = 'just test-affected; all-features'; selectedBinaries = $allSelected; packages = @($allSelected.package | Sort-Object -Unique) } | ConvertTo-Json -Depth 8 | Set-Content "$prefix.selection-review.json"
$required = @(
    'native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line',
    'saved_awbc_ordinary_flow_defer_reexports_an_actor_through_its_nested_line',
    'native_initial_copy_line_input_remains_available_in_its_caller',
    'saved_awbc_initial_copy_line_input_remains_available_in_its_caller',
    'saved_awbc_initial_line_input_rejects_forged_packet_and_activation_slots',
    'plan_reports_initial_line_inputs_separately_from_shared_work_inputs'
)
foreach ($test in $required) {
    $cases = @($allCases | Where-Object { $_.test -eq $test -or $_.test.EndsWith('::' + $test) })
    if ($cases.Count -ne 1 -or $cases[0].ignored) { throw "Required regression not selected once for execution: $test" }
}
$expected = (Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.ownership-review-r2.json') -Raw | ConvertFrom-Json -Depth 30).coreReversePackages
$selectedPackages = @($allSelected.package | Sort-Object -Unique)
if (@($selectedPackages | Where-Object { $_ -notin $expected }).Count) { throw 'Unexpected package outside actual Core reverse closure' }
[ordered]@{ graphClosure = $expected; selectedPackages = $selectedPackages; packagesWithoutMatchedCases = @($expected | Where-Object { $_ -notin $selectedPackages }); requiredRegressions = $required; matchedCases = $allCases } | ConvertTo-Json -Depth 8 | Set-Content "$prefix.scope-review.json"
$exitCode = 0
foreach ($slice in $slices) {
    $arguments = @('nextest', 'run', '--locked', '--all-features') + $slice.args + @('-E', 'rdeps(=arcweft-core)', '--no-tests', 'fail', '--no-fail-fast')
    $started = [DateTime]::UtcNow
    & cargo @arguments *> "$prefix.$($slice.name).run.log"
    $code = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.$($slice.name).run.receipt.json"
    Get-Content "$prefix.$($slice.name).run.log" -Tail 20
    if ($code -ne 0) { $exitCode = $code }
}
exit $exitCode
