$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.consumer-split-r3'
if (Test-Path "$prefix.source.json") { throw 'Split source epoch already exists' }
$epoch = (Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.compiler-expectation-r2.source.json') -Raw | ConvertFrom-Json).inputs
function Assert-Inputs {
    foreach ($row in $epoch) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
Assert-Inputs
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch; featureScope = 'All features of each selected package; separate package/target slices, not one unified workspace execution.' } | ConvertTo-Json -Depth 6 | Set-Content "$prefix.source.json"
$review = Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.ownership-review-r2.json') -Raw | ConvertFrom-Json -Depth 40
$metadata = Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.metadata-all.json') -Raw | ConvertFrom-Json -Depth 100
$priority = @('arcweft-core', 'arcweft-runtime-plan', 'arcweft-lang-sema', 'arcweft-compiler', 'arcweft-cli')
$packages = @($review.coreReversePackages | Sort-Object @{e={ $index = $priority.IndexOf($_); if ($index -lt 0) { 100 } else { $index } }}, @{e={$_}})
$cliTests = @('runtime_native_options', 'check_core_cli', 'native_style_parity_sample', 'release_trust_json', 'arcw_fixtures_check_run', 'seq04_8_4_persistent_cache_build_cli_goldens')
$targets = @(foreach ($packageName in $packages) {
    $package = @($metadata.packages | Where-Object name -eq $packageName)
    if ($package.Count -ne 1) { throw "Package not unique in resolved graph: $packageName" }
    foreach ($target in $package[0].targets) {
        if (-not $target.test) { continue }
        $kind = if ('test' -in $target.kind) { 'test' } elseif ('bin' -in $target.kind) { 'bin' } elseif (@($target.kind | Where-Object { $_ -in @('lib', 'rlib', 'proc-macro') }).Count) { 'lib' } else { continue }
        if ($packageName -eq 'arcweft-cli' -and $kind -eq 'test' -and $target.name -notin $cliTests) { continue }
        [ordered]@{ package = $packageName; packageId = $package[0].id; kind = $kind; target = $target.name; requiredFeatures = $target.'required-features' }
    }
})
if ($packages.Count -ne 53 -or @($targets.package | Sort-Object -Unique).Count -ne 53) { throw 'Split target plan lost a Core reverse package' }
[ordered]@{ packages = $packages; targets = $targets; targetSurface = 'just test-affected; package/target all-feature slices'; defaultCargoJobs = $true; assertionsAndIgnoredPolicyUnchanged = $true; cause = 'Two unified workspace test builds exhausted Windows commit/pagefile space; workspace check and Clippy remain their separate successful unified all-feature receipts.' } | ConvertTo-Json -Depth 8 | Set-Content "$prefix.plan.json"
$rows = @()
$required = @('native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line', 'saved_awbc_ordinary_flow_defer_reexports_an_actor_through_its_nested_line', 'native_initial_copy_line_input_remains_available_in_its_caller', 'saved_awbc_initial_copy_line_input_remains_available_in_its_caller', 'saved_awbc_initial_line_input_rejects_forged_packet_and_activation_slots', 'plan_reports_initial_line_inputs_separately_from_shared_work_inputs')
$requiredFound = @()
$index = 0
$exitCode = 0
$previousRows = @(Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.consumer-split-r2.results.jsonl') | ForEach-Object { $_ | ConvertFrom-Json -Depth 30 })
$impact = Get-Content (Join-Path $PSScriptRoot 'line-initial-inputs-20261108.compiler-expectation-r2.source.json') -Raw | ConvertFrom-Json -Depth 10
if ($impact.changed.Count -ne 1 -or $impact.changed[0].path.Replace('\', '/') -ne 'crates/arcweft-compiler/src/project/tests.rs') { throw 'Unexpected reuse impact' }
foreach ($target in $targets) {
    $index++
    $stem = '{0}.{1:D3}.{2}.{3}.{4}' -f $prefix,$index,$target.package,$target.kind,$target.target
    $selector = if ($target.kind -eq 'lib') { @('--lib') } else { @(('--' + $target.kind), $target.target) }
    $common = @('--locked', '-p', $target.package, '--all-features') + $selector + @('-E', 'rdeps(=arcweft-core)')
    $arguments = @('nextest', 'list') + $common + @('--message-format', 'json')
    if ($index -le 24) {
        $prior = @($previousRows | Where-Object index -eq $index)[0]
        if (-not $prior -or $prior.target.package -ne $target.package -or $prior.target.kind -ne $target.kind -or $prior.target.target -ne $target.target -or $prior.sourceDrift -ne 0) { throw 'Prior target identity differs' }
        if ([string]::Join([char]0, $arguments) -cne [string]::Join([char]0, $prior.list.arguments)) { throw 'Prior selection arguments differ' }
        if ($index -eq 24) {
            if ($target.package -ne 'arcweft-compiler' -or $target.kind -ne 'lib') { throw 'Repair target differs' }
            $repairPrefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.compiler-expectation-r2'
            $repairReceipt = Get-Content "$repairPrefix.test.receipt.json" -Raw | ConvertFrom-Json
            if ($repairReceipt.exitCode -ne 0 -or $repairReceipt.sourceDrift -ne 0) { throw 'Repaired compiler pass unavailable' }
            $repairLog = Get-Content "$repairPrefix.test.log" -Raw
            $match = [regex]::Matches($repairLog, 'Summary \[[^\]]+\]\s+(?<run>\d+) tests? run:\s+(?<passed>\d+) passed(?<rest>[^\r\n]*)') | Select-Object -Last 1
            if (-not $match -or $match.Groups['run'].Value -ne $match.Groups['passed'].Value -or $match.Groups['rest'].Value -match '[1-9]\d* failed') { throw 'Repaired compiler result differs' }
            $expectedRun = @('nextest', 'run') + $common + @('--no-tests', 'fail', '--no-fail-fast')
            if ([string]::Join([char]0, $expectedRun) -cne [string]::Join([char]0, $repairReceipt.arguments)) { throw 'Repair execution arguments differ' }
            $prior.run = $repairReceipt
            $prior.actual = [pscustomobject]@{ run = [int]$match.Groups['run'].Value; passed = [int]$match.Groups['passed'].Value; failed = 0; skipped = 0; terminal = $match.Value }
            $prior | Add-Member -Force -NotePropertyName reusedFrom -NotePropertyValue "$repairPrefix.test.log"
        } elseif ($prior.list.exitCode -ne 0 -or $prior.run.exitCode -ne 0 -or $prior.actual.failed -ne 0) { throw 'Prior target did not pass' }
        $prior | Add-Member -Force -NotePropertyName reuseBasis -NotePropertyValue 'Only compiler project/tests.rs changed in a cfg(test) module. Prior Core, RuntimePlan and Sema target inputs remain unchanged. Compiler unit uses the separate corrected full 191-case run. Selection names and arguments are unchanged; earlier source epochs are retained.'
        $rows += $prior
        $prior | ConvertTo-Json -Depth 10 -Compress | Add-Content "$prefix.results.jsonl"
        [ordered]@{ index = $index; reuse = $true; package = $target.package; target = $target.target; actual = $prior.actual } | ConvertTo-Json -Depth 4 -Compress
        continue
    }
    $started = [DateTime]::UtcNow
    & cargo @arguments 1> "$stem.selection.json" 2> "$stem.selection.log"
    $code = $LASTEXITCODE
    $listReceipt = [ordered]@{ arguments = $arguments; exitCode = $code; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') }
    $listReceipt | ConvertTo-Json -Depth 5 | Set-Content "$stem.selection.receipt.json"
    if ($code -ne 0) { Assert-Inputs; throw "Split selection/build failed: $($target.package) $($target.target)" }
    $list = Get-Content "$stem.selection.json" -Raw | ConvertFrom-Json -Depth 60
    $cases = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) { foreach ($case in $property.Value.testcases.PSObject.Properties) { if ($case.Value.'filter-match'.status -eq 'matches') { [ordered]@{ binary = $property.Name; name = $case.Name; ignored = $case.Value.ignored } } } })
    $catalogCases = @(foreach ($property in $list.'rust-suites'.PSObject.Properties) { $property.Value.testcases.PSObject.Properties })
    if ($list.'test-count' -gt 0 -and -not $cases.Count -and @($catalogCases | Where-Object { -not $_.Value.ignored }).Count) { throw 'Nonempty runnable catalog unexpectedly excluded by the Core reverse filter' }
    foreach ($name in $required) {
        $matched = @($cases | Where-Object { $_.name -eq $name -or $_.name.EndsWith('::' + $name) })
        if ($matched.Count) {
            if ($matched.Count -ne 1 -or $matched[0].ignored -or $name -in $requiredFound) { throw "Required regression duplicated/ignored: $name" }
            $requiredFound += $name
        }
    }
    $ignored = @($catalogCases | Where-Object { $_.Value.ignored }).Count
    $runnable = @($cases | Where-Object { -not $_.ignored }).Count
    $runReceipt = $null
    $summary = $null
    if ($runnable -gt 0) {
        $arguments = @('nextest', 'run') + $common + @('--no-tests', 'fail', '--no-fail-fast')
        $started = [DateTime]::UtcNow
        & cargo @arguments *> "$stem.run.log"
        $code = $LASTEXITCODE
        $runReceipt = [ordered]@{ arguments = $arguments; exitCode = $code; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') }
        $runReceipt | ConvertTo-Json -Depth 5 | Set-Content "$stem.run.receipt.json"
        $log = Get-Content "$stem.run.log" -Raw
        $match = [regex]::Matches($log, 'Summary \[[^\]]+\]\s+(?<run>\d+) tests? run:\s+(?<passed>\d+) passed(?<rest>[^\r\n]*)') | Select-Object -Last 1
        if (-not $match) { Assert-Inputs; throw 'Missing terminal nextest summary' }
        $rest = $match.Groups['rest'].Value
        $summary = [ordered]@{ run = [int]$match.Groups['run'].Value; passed = [int]$match.Groups['passed'].Value; failed = if ($rest -match '(\d+) failed') { [int]$Matches[1] } else { 0 }; skipped = if ($rest -match '(\d+) skipped') { [int]$Matches[1] } else { 0 }; terminal = $match.Value }
        if ($code -ne 0) { $exitCode = $code }
    }
    Assert-Inputs
    $row = [ordered]@{ index = $index; target = $target; selected = $cases.Count; ignored = $ignored; runnable = $runnable; list = $listReceipt; run = $runReceipt; actual = $summary; sourceInputs = $epoch.Count; sourceDrift = 0 }
    $rows += $row
    $row | ConvertTo-Json -Depth 10 | Set-Content "$stem.result.json"
    $row | ConvertTo-Json -Depth 10 -Compress | Add-Content "$prefix.results.jsonl"
    [ordered]@{ index = $index; total = $targets.Count; package = $target.package; target = $target.target; selected = $cases.Count; actual = $summary } | ConvertTo-Json -Depth 4 -Compress
    if ($runReceipt -and $runReceipt.exitCode -ne 0 -and $target.package -ne 'arcweft-cli') { throw 'Non-CLI regression requires diagnosis before proceeding' }
}
if (@(Compare-Object $required $requiredFound).Count) { throw 'Split closure omitted a required regression' }
[ordered]@{ sourceInputs = $epoch.Count; sourceDrift = 0; packages = $packages; targets = $targets.Count; requiredRegressions = $requiredFound; results = $rows; exitCode = $exitCode; at = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 14 | Set-Content "$prefix.receipt.json"
exit $exitCode
