$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$prefix = Join-Path $PSScriptRoot 'line-initial-inputs-20261108.workspace-r2'
if (Test-Path "$prefix.source.json") { throw 'Workspace source epoch already exists' }
$paths = @(rg --files --hidden -g '*.rs' -g 'Cargo.toml' -g 'Cargo.lock' -g 'rust-toolchain*' -g '.cargo/config*' -g '!target' -g '!.git' | Sort-Object -Unique)
$epoch = @(foreach ($path in $paths) { [ordered]@{ path = $path; sha256 = (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() } })
[ordered]@{ base = (& git rev-parse HEAD).Trim(); inputs = $epoch } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.source.json"
function Assert-Inputs {
    foreach ($row in $epoch) {
        if ((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
function Run-Cargo([string]$name, [string[]]$arguments) {
    Assert-Inputs
    $started = [DateTime]::UtcNow
    & cargo @arguments *> "$prefix.$name.log"
    $code = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ arguments = $arguments; exitCode = $code; sourceInputs = $epoch.Count; sourceDrift = 0; startedAt = $started.ToString('o'); endedAt = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json -Depth 5 | Set-Content "$prefix.$name.receipt.json"
    Get-Content "$prefix.$name.log" -Tail 10
    if ($code -ne 0) { throw "Required workspace check failed: $name ($code)" }
}
Run-Cargo 'check' @('check', '--locked', '--workspace', '--all-targets', '--all-features')
Run-Cargo 'clippy' @('clippy', '--locked', '--workspace', '--all-targets', '--all-features')
