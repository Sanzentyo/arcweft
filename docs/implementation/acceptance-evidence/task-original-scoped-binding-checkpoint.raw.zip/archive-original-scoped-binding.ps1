$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = 'f820ae9183455a262218bab105eb5b0d9e43d3cf'
$source = '64881509ec1c073810f818d158dfe212b5ad6bb1'
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='PreparedEffectScopedBinding is an affine conditional bridge from a fresh original scoped completion to the same live inference identities. It owns one exact ImportedEffectRelation and every principal/extensional agreement receipt together; freeze consumes the bundle and retains original query ports by issued identity. Each local unknown equals its conditional least output over the entire original declared function signature, including unused and captured inference formal arguments. These signatures are extensionality scopes, not reconstructed source Gamma; ambient source scope admission still rejects raw inference row parameters. Future inputs are the same actual live functions, Named inputs retain the original issuer/header, and partially specialized/foreign/stale snapshots are refused. Arc identity authenticates immutable definition provenance; it does not prove semantic equality. Construction is checkpointed and rolls back all partial terms/functions on every failure while retaining spent work. Receipts never append global obligations or mix sibling candidate facts. The original forest now freezes this bound conditional relation before its still-unmigrated canonical-only final validator. The existing conditional solver, dependency/support grammar, import compilation and independent replay are reused without a second reader or pure/true fallback. Nine new fixtures remain unrun because library/test targets fail: no-output principal conditions, least-vs-merely-satisfying functions, unused declared arguments, late actual Future values, foreign/stale/specialized provenance, every measured exhaustion prefix, retained query ports/sibling isolation, freeze refusal/exhaustion and actual captured inference function signatures. The new completion/binding module owns exactly this mathematical attachment and its affine freeze; functions retains operational unknown-handle issuance, original forest retains candidate ownership, and application tests use real issued source/capture identities. Exact base/current physical LOC, bytes, growth and embedded-test measurements follow. Cargo graph, layer direction, I/O, unsafe, codec/version markers, production budgets, jobs and profiles are unchanged. Existing resolved Cargo graph and reverse dependency evidence is reused; no new structural scanner run. Compilation is not acceptance, and the new fixtures have not run.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'original-scoped-binding.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev01','dev02')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'original-scoped-binding.'+$iteration+$suffix}})
$names+=@('original-scoped-binding.source-publication.json','original-scoped-binding.ownership-review.json','original-scoped-binding.staged-review.json','original-scoped-binding.dev02-diagnostic-review.json')
$names+=@('run-original-scoped-binding-check.ps1','archive-original-scoped-binding.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-original-scoped-binding-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-original-scoped-binding-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'original-scoped-binding.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
