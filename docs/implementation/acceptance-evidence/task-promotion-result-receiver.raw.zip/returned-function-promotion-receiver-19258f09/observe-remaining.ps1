$ErrorActionPreference='Stop'
$r=Join-Path $env:TEMP 'arcweft-promotion-result-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$qa=Get-Content -Raw -LiteralPath (Join-Path $r 'quality.receipt.json')|ConvertFrom-Json -AsHashtable
$stage=@($qa.results|Where-Object name -eq 'cli-build')
if($stage.Count -ne 1 -or $stage[0].exitCode -or (ArcSha $cli) -ne $qa.cliSha256){throw 'Expected the validated CLI binary'}
foreach($row in $qa.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
$rows=@(foreach($name in 'remaining-higher-order-return','remaining-recursive-generic-rotation'){
    $src=Join-Path $r "$name.arcw"
    $out=Join-Path $r "$name.observed.json"
    $err=Join-Path $r "$name.observed.stderr.log"
    & $cli check $src --json > $out 2> $err
    $code=$LASTEXITCODE
    $q=Get-Content -Raw -LiteralPath $out|ConvertFrom-Json -AsHashtable
    [ordered]@{name=$name;stage=$q.stage;exit=$code;codes=@($q.diagnostics|ForEach-Object {$_.diagnostic.code});messages=@($q.diagnostics|ForEach-Object {$_.diagnostic.message});inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
if((ArcSha $cli) -ne $qa.cliSha256){throw 'CLI binary changed during observed cases'}
[ordered]@{version=1;base=$qa.base;cliSha256=$qa.cliSha256;cases=$rows}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $r 'remaining.receipt.json') -Encoding utf8
$rows|ForEach-Object {[pscustomobject]$_}|Format-Table name,stage,exit,codes,messages
