$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-result-20261110'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$qa=ArcJson (Join-Path $d 'quality.receipt.json')
$before=ArcJson (Join-Path $d 'baseline.receipt.json')
$chain=ArcJson (Join-Path $d 'chain-baseline.receipt.json')
if($chain.source -ne $before.source -or $chain.cliSha256 -ne $before.cliSha256){throw 'Additional baseline differs'}
$inputs=@($before.cases)+@($chain.cases)
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($sha -ne $qa.cliSha256 -or $sha -eq $before.cliSha256){throw 'Baseline or changed artifact differs'}
git diff --quiet $before.source $qa.base -- 'crates/**' Cargo.toml Cargo.lock
if($LASTEXITCODE){throw 'Reviewed base differs from baseline'}
foreach($row in $qa.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
$borrowed=@('factory-borrowed','factory-forward','factory-conditional-return','factory-generic','loop-borrowed','factory-generic-chain','factory-completed-groups')
function ReadArcResult($name,$command,$source,$expected,$expectedSpan){
    $out=Join-Path $d "$name.$command.after.json"
    $err=Join-Path $d "$name.$command.after.stderr.log"
    if($command -eq 'verify'){
        & $cli verify $source --mode test --backend emit --json > $out 2> $err
    }else{
        & $cli check $source --json > $out 2> $err
    }
    $code=$LASTEXITCODE
    $report=ArcJson $out
    $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
    if($code -ne 1 -or $report.status -ne 'denied' -or $report.stage -ne 'type-check' -or $diagnostics.Count -ne 1 -or $diagnostics[0].code -ne $expected -or $report.obligations -or $report.solver_checks){
        throw "Unexpected $name $command result $($diagnostics.code -join ',')"
    }
    $span=$diagnostics[0].span
    $spelling=(Get-Content -LiteralPath $source -Raw).Substring($span.start,$span.end-$span.start)
    if($spelling -cne $expectedSpan){throw "Unexpected $name $command span $spelling"}
    [ordered]@{name=$name;command=$command;exit=$code;stage=$report.stage;code=$diagnostics[0].code;span=$spelling;start=$span.start;end=$span.end;inputSha256=ArcSha $source;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
}
$results=@(foreach($row in $inputs){
    $source=Join-Path $d "$($row.name).arcw"
    if($row.stage -ne 'type-check' -or (ArcSha $source) -ne $row.inputSha256){throw "Baseline input drift $($row.name)"}
    $expected,$spelling=if($row.name -in $borrowed){'sema.lifetime.promotion_receiver','callback'}else{'sema.lifetime.promotion_execution',"callback.promote('flow)"}
    ReadArcResult $row.name 'check' $source $expected $spelling
    if($row.name -in 'factory-forward','loop-dead-break'){
        ReadArcResult $row.name 'verify' $source $expected $spelling
    }
})
if($results.Count -ne $inputs.Count+2 -or (ArcSha $cli) -ne $sha){throw 'CLI receipt differs'}
[ordered]@{version=1;base=$qa.base;cliSha256=$sha;cases=$results}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $d 'changed.receipt.json') -Encoding utf8
$results|ForEach-Object {[pscustomobject]$_}|Format-Table name,command,code,span
