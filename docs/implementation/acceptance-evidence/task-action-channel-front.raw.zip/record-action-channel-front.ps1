$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$pub=Receipt 'checkpoint-action-channel-front.verified'
if((git rev-parse HEAD).Trim() -ne $pub.commit){throw 'Checkpoint HEAD differs'}
$final=Receipt 'action-channel-execution-syntax-sema1-20261103.runtime.terminal-audit'
if(-not $final.isPassingRun -or $final.executed -ne 739 -or $final.sourceDrift){throw 'Front-end terminal differs'}
$freeze=Receipt 'action-channel-execution-syntax-sema1-20261103.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source input drift'}}
$raw='docs/implementation/acceptance-evidence/task-action-channel-front.raw.zip'
$record='docs/implementation/acceptance-evidence/task-action-channel-front.json'
if((Test-Path -LiteralPath $raw) -or (Test-Path -LiteralPath $record)){throw 'Preserve existing records'}
$files=@(Get-ChildItem -LiteralPath $e -File|Where-Object {$_.Name -match '^(action-channel-execution-(owner1|sema1|syntax-sema1)-20261103[.]|checkpoint-action-channel-front[.])'})
$files+=@(Get-Item -LiteralPath "$e/record-action-channel-front.ps1","$e/run-presentation-projection-owner.ps1","$e/audit-nextest-final-result.ps1")
$files=@($files|Sort-Object FullName -Unique)
$manifest=@();$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal);$manifest+=[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($archive.Entries.Count -ne $manifest.Count){throw 'Archive count drift'};foreach($row in $manifest){$stream=$archive.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive entry drift'}}}finally{$archive.Dispose()}
$evidence=[ordered]@{version=1;recordedAt=[DateTime]::UtcNow.ToString('o');status='intermediate-source-checkpoint';source=$pub.commit;publication=$pub;scope='Common Action callable identities, schemas, exact emission operand admission, typed Need result, and ordinary receive call grammar. Core delivery, waiting, Native/AWBC execution and save/restore remain unimplemented; RuntimePlan consumers still require migration. This is not full-workspace or runtime acceptance.';preliminaryCheck=(Receipt 'action-channel-execution-owner1-20261103.check');initialThreeCases=(Receipt 'action-channel-execution-sema1-20261103.runtime.terminal-audit');finalFrontEnd=$final;selectionMeaning='736 Syntax library cases and the same three new Sema cases execute. The 1366 other Sema cases are out of the filter, not ignored tests. Complete reverse-consumer and workspace gates have not been rerun for this intermediate checkpoint.';repair='The first receive test failed in HIR staging with InvalidArenaCommit. Parser classified every let initializer beginning receive as obsolete LetActionReceiveStatement. That kind, AST marker and classifier/choice branches were removed; ordinary calls, await and nested calls now share the let/call grammar. No legacy success route or fallback remains.';sourceInputs=$freeze.paths.Count;sourceDrift=0;heldTracked=12;originalUntracked=6;priorCompleteConsumerSource='7104b200150b9b85b31cd686c48573b92b2028d3';genericMatch='Accepted and published; this unfinished feature does not reopen its completed boundary.';raw=[ordered]@{path=$raw;bytes=(Get-Item -LiteralPath $raw).Length;sha256=(Get-FileHash -LiteralPath $raw).Hash.ToLowerInvariant();entryDrift=0;entries=$manifest}}
$json=($evidence|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n"
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),$json,[Text.UTF8Encoding]::new($false))
$statusPath=[IO.Path]::GetFullPath('docs/implementation/current-status.md')
$text=[IO.File]::ReadAllText($statusPath)
$header="確認日: 2026-11-03。最新公開Sourceは$($pub.commit)（送受信の前段checkpoint、runtime側は未移行）。直近の全consumer検証はSource 7104b200150b9b85b31cd686c48573b92b2028d3の通常9194件PASSで、CLI・全workspace gateの入力も下表で区別する。前段の739件PASSを全体の受入とはしない。既存12 tracked／6 actual untracked WIPを保持している。"
$text=[regex]::Replace($text,'(?m)^確認日:[^\r\n]*',[Text.RegularExpressions.MatchEvaluator]{param($m)$header})
$pattern='(?m)^\| Action宣言・payload record／型付きチャンネル値 \|[^\r\n]*'
if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Action current row differs'}
$text=[regex]::Replace($text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m)
    $row=$m.Value.Replace('**修飾付き宣言・call構築と元宣言identity保持は検証・公開済み。送受信・channelの停止復元は別境界**','**宣言・payload identityの受入を維持。送受信前段を実装中**')
    $row.Substring(0,$row.Length-2)+" 前段checkpoint $($pub.commit)ではemit／receiveを共通callableへ接続し、旧let-receive専用構文を削除した。Syntax 736＋新Sema3の739件PASS。Core配送・待機・Native／AWBC・保存復元と利用側の移行は未完で、全workspace compileは未検証。[初回HIR失敗・修復・実測](acceptance-evidence/task-action-channel-front.json)。 |"
})
[IO.File]::WriteAllText($statusPath,$text,[Text.UTF8Encoding]::new($false))
$history=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md')
$before=[IO.File]::ReadAllBytes($history);$prefixHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant()
$append=@"


## Action送受信の前段checkpoint — 2026-11-03

Source $($pub.commit)、parent $($pub.parent)、tree $($pub.tree)。19 path／277 insertions／33 deletionsを、ユーザーの途中commit／push指示に従う中間checkpointとして公開した。emit／receiveの共通callable・generic payload・engine effect・checked emissionを追加した。実際のCore配送／待機、Native／AWBC、保存復元とRuntimePlan利用側は未移行で、全workspace compileや実送受信の受入は主張しない。

前段Sema library checkは終了0。初回新規3件は2 PASS／1 FAILで、receiveはSemaより前のHIR stagingでInvalidArenaCommitとなった。parserがletのreceive初期値を旧LetActionReceiveStatementへ分類していたため、専用kind・AST marker・分類分岐を削除した。元の失敗を保持したまま、通常call／await／nested call grammarへ移行し、Syntax全736件と同じ新Sema3件の739／739 PASSを確認した。1366件はfilter外のSema caseでありignoredとはしない。4083入力・case／Source／test EXE差分0。Sourceと公開blob／full patch、既存12 tracked WIPの保持を照合し、元6 untracked WIPも保持している。

raw $($manifest.Count) entries／$($evidence.raw.bytes) bytes、SHA256 $($evidence.raw.sha256)、全entry hash差分0。直近の全consumer検証Source7104の実測は前節・旧原本へ保持する。現状一覧の最新Sourceだけをこの前段checkpointへ更新し、既受入機能を未完了には戻していない。[入力・初回失敗・修復・公開照合](acceptance-evidence/task-action-channel-front.json)。
"@
$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream=[IO.File]::Open($history,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$stream.Write($bytes)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($history);$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixHash){throw 'Historical prefix changed'}
[ordered]@{source=$pub.commit;rawEntries=$manifest.Count;rawSha=$evidence.raw.sha256;preservedHistoryBytes=$before.Length;preservedHistorySha256=$prefixHash;historyPrefixDrift=0}|ConvertTo-Json
