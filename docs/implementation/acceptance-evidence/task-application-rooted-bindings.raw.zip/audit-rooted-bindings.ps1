$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$log=[IO.File]::ReadAllText("$root/rooted-bindings.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1589 tests run: 1583 passed, 6 failed, 0 skipped')
if (!$summary.Success) { throw 'Unexpected owner summary' }
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1589\) (\S+) (.+)\r?$') | ForEach-Object {
    [pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}
})
$listing=Get-Content -Raw "$root/rooted-bindings.owner-list.json" | ConvertFrom-Json
$selected=@(foreach ($property in $listing.'rust-suites'.PSObject.Properties) {
    foreach ($case in $property.Value.testcases.PSObject.Properties) {
        if ($case.Value.'filter-match'.status -eq 'matches') { $property.Name+'$'+$case.Name }
    }
})
if ($terminal.Count -ne 1589 -or $selected.Count -ne 1589) { throw 'Owner selection/terminal count mismatch' }
if (@($terminal | Group-Object Id | Where-Object Count -gt 1).Count -ne 0 -or @($selected | Group-Object | Where-Object Count -gt 1).Count -ne 0) { throw 'Duplicate owner case' }
if (@(Compare-Object -CaseSensitive @($selected | Sort-Object) @($terminal.Id | Sort-Object)).Count -ne 0) { throw 'Owner execution does not match selection' }
$baseline=Get-Content -Raw "$root/joint-original.owner-summary.json" | ConvertFrom-Json
$failed=@($terminal | Where-Object Result -eq 'FAIL' | ForEach-Object Name | Sort-Object)
if (@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -ne 0) { throw 'Owner failure IDs changed' }
$new=@($terminal | Where-Object Name -Match '::rooted_bindings::')
if ($new.Count -ne 6 -or @($new | Where-Object Result -ne 'PASS').Count -ne 0) { throw 'New owner regressions missing/failed' }
if (@($terminal | Where-Object { $_.Name.Contains('t_lim_12_007_candidate_boundary_probes_each_of_256_candidates_once') -and $_.Result -eq 'PASS' }).Count -ne 1) { throw '256-candidate budget regression missing/failed' }
if ([regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1) { throw 'Owner failure diagnostics changed' }
$pin=Get-Content -Raw "$root/rooted-bindings.owner-input.json" | ConvertFrom-Json
foreach ($entry in $pin.Paths) {
    if ((Get-FileHash -LiteralPath $entry.Path -Algorithm SHA256).Hash -ne $entry.SHA256) { throw "Changed owner input: $($entry.Path)" }
}
$quality=Get-Content -Raw "$root/rooted-bindings.quality.json" | ConvertFrom-Json
if ($quality.Steps.Count -ne 5 -or @($quality.Steps | Where-Object ExitCode -ne 0).Count -ne 0) { throw 'Required quality checks did not all pass' }
$terminal | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/rooted-bindings.owner-terminal.json"
[ordered]@{Version=1;TestedBase=$pin.Base;InputManifestSHA256=(Get-FileHash "$root/rooted-bindings.owner-input.json" -Algorithm SHA256).Hash;Selected=1589;Passed=1583;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);IdsEqual=$true;Duplicates=0;Failures=$failed;FailureBaseline='377206557e9e41a95da3b3cc1f77bfd46a0974ab';ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new;Candidate256Passed=$true;PinnedPaths=$pin.Paths.Count;QualityChecks=5;QualityExitCodes=@($quality.Steps.ExitCode)} | ConvertTo-Json -Depth 7 | Set-Content -Encoding utf8 "$root/rooted-bindings.owner-summary.json"
Get-Content "$root/rooted-bindings.owner-summary.json" -TotalCount 18
