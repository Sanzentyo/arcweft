# Static continuation review, 2026-11-12

The consulted agent observed HEAD f9cab148c7e28aebeb5adf1f676f8b74934ef610 with the in-progress owner-scope patch. Those source bytes were subsequently published as ae0915c787da9c5d2637b62e542bfa132db24556; the publication record verifies all 19 pinned paths. The consultation changed no files, ran no Cargo commands, and is not executable acceptance evidence.

The published change roots active type/const bindings and retained equations in their real lexical scopes. It does not complete the downstream generic-context contract.

`solution/residual.rs::for_application` still derives the completed value scope from an empty GenericScope plus residual slots. Reify appends a residual binder to the current context but returns ordinary Bound references without lifting them past that binder. With ambient A and residual U at the same slot, A can be reinterpreted as U. With no residual binder, an ambient reference is stored while its inspection view reports an empty scope. Reopening uses numeric depth in the new context, and templates/localization cannot recover lost ambient frame identity.

Free declaration references retain stable identity. The existing child-capture regression intentionally permits genuine external rigid references introduced to a path through a child. Branch-wide visibility alone does not prove that a dependency is permitted by an outer meta's introduction context. A complete solution must retain legitimate source/import capture authority without granting mutation of imported inference variables. No actual frontend path introducing an illegal Free capture was established by this static review.

The next implementation owner is one completed generic context: retained ambient frames and read-only capture authority, separately identified residual binder/origins, and a derived combined value scope. Reify lifts ambient references while creating only authorized residual slots; reopening preserves ambient authority and freshens only residuals. Templates quantify only the residual portion. Final flat instantiation requires authenticated values for the retained ambient context and residual arguments and proves root closure. Reuse the existing shared type fold and declaration binder mapping; do not reconstruct ownership from source, invent free-reference fallbacks, or quantify captured ambient parameters.

Falsifiers: ambient A versus same-position residual U; no-residual ambient retention; unrelated equally shaped frames; two fresh residual openings sharing one capture; legitimate child-supplied Free captures surviving completion; inner quantifier capture through aliases; residual-only result quantification; final closure of both ambient and residual dependencies.

This is a remaining boundary of the already unaccepted recursive-body implementation. It does not revoke Generic Match, caller-bound recursion, or other accepted features.
