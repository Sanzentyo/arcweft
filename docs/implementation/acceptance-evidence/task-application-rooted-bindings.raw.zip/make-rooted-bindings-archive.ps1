$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo='D:\git\arcweft'
$archivePath=Join-Path $repo 'docs/implementation/acceptance-evidence/task-application-rooted-bindings.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Frozen archive already exists; never overwrite' }
$publication=Get-Content -Raw "$root/rooted-bindings.publication.json" | ConvertFrom-Json
$owner=Get-Content -Raw "$root/rooted-bindings.owner-summary.json" | ConvertFrom-Json
$consumer=Get-Content -Raw "$root/rooted-bindings.consumer-summary.json" | ConvertFrom-Json
if ($consumer.Source -ne $publication.Source -or $consumer.Targets -ne 107 -or !$consumer.IdsEqual -or !$owner.IdsEqual) { throw 'Acceptance receipts are incomplete' }
$files=@(Get-ChildItem -LiteralPath $root -File | Where-Object Name -Like 'rooted-bindings.*')
$files += @(Get-Item "$root/audit-rooted-bindings.ps1","$root/audit-rooted-consumers.ps1","$root/make-rooted-bindings-archive.ps1")
$files += @(Get-ChildItem -LiteralPath "$root/rooted-bindings-reverse" -Recurse -File)
$files += @(Get-ChildItem -LiteralPath "$root/rooted-compiler-repair" -Recurse -File)
$files=@($files | Sort-Object FullName -Unique)
$allowed=@('.json','.jsonl','.log','.stderr','.patch','.rs','.ps1','.md')
$entries=@(foreach ($file in $files) {
    if ($file.Extension -notin $allowed) { throw "Non-evidence file: $($file.FullName)" }
    $relative=[IO.Path]::GetRelativePath($root,$file.FullName).Replace('\','/')
    [pscustomobject]@{Path=$relative;Bytes=$file.Length;SHA256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
})
if (@($entries | Group-Object Path | Where-Object Count -ne 1).Count -ne 0) { throw 'Duplicate archive entry' }
$manifest=[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Parent=$publication.Parent;Owner=@{Passed=1583;Failed=6;Skipped=0};Consumers=@{Passed=2507;Failed=2;Skipped=1;Targets=107};Entries=$entries}
$manifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($manifest | ConvertTo-Json -Depth 10))
Add-Type -AssemblyName System.IO.Compression
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite)
try {
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
    try {
        foreach ($record in $entries) {
            $entry=$zip.CreateEntry($record.Path,[IO.Compression.CompressionLevel]::Optimal)
            $target=$entry.Open()
            try {
                $bytes=[IO.File]::ReadAllBytes((Join-Path $root $record.Path))
                if ($bytes.Length -ne $record.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $record.SHA256) { throw 'Evidence changed while archiving' }
                $target.Write($bytes,0,$bytes.Length)
            } finally { $target.Dispose() }
        }
        $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal)
        $target=$entry.Open()
        try { $target.Write($manifestBytes,0,$manifestBytes.Length) } finally { $target.Dispose() }
    } finally { $zip.Dispose() }
} finally { $stream.Dispose() }
$verified=0
$rawBytes=0L
$read=[IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($read.Entries.Count -ne ($entries.Count+1)) { throw 'Archive entry count differs' }
    foreach ($entry in $read.Entries) {
        $inputStream=$entry.Open()
        $memory=[IO.MemoryStream]::new()
        try { $inputStream.CopyTo($memory); $bytes=$memory.ToArray() } finally { $inputStream.Dispose(); $memory.Dispose() }
        $expected=if ($entry.FullName -eq 'manifest.json') {
            [pscustomobject]@{Bytes=$manifestBytes.Length;SHA256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($manifestBytes)).ToLowerInvariant()}
        } else { @($entries | Where-Object Path -CEQ $entry.FullName)[0] }
        if ($bytes.Length -ne $expected.Bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant() -ne $expected.SHA256) { throw "Archive readback mismatch: $($entry.FullName)" }
        $rawBytes+=$bytes.Length
        $verified++
    }
} finally { $read.Dispose() }
[ordered]@{Version=1;Source=$publication.Source;Path=$archivePath;Entries=$verified;RawBytes=$rawBytes;Bytes=(Get-Item -LiteralPath $archivePath).Length;SHA256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant();AllEntriesReadbackVerified=$true;ManifestVerified=$true} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/rooted-bindings.archive.json"
Get-Content "$root/rooted-bindings.archive.json"
