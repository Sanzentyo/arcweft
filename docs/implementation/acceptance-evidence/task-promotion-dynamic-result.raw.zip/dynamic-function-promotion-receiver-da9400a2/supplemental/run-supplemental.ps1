$ErrorActionPreference='Stop'
$d=Join-Path $env:TEMP 'arcweft-promotion-dynamic-20261110'
$s=Join-Path $d 'supplemental'
function ArcSha($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ArcJson($p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -AsHashtable}
$q=ArcJson (Join-Path $d 'quality.receipt.json')
$cli=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$sha=ArcSha $cli
if($sha -ne $q.cliSha256){throw 'Expected exact CLI build'}
foreach($row in $q.inputs){if((ArcSha $row.path) -ne $row.sha256){throw "Source drift $($row.path)"}}
$checks=@(foreach($name in 'dynamic-recursive-parameter','dynamic-creator-owned-control','dynamic-specialized-named'){
    $src=Join-Path $s "$name.arcw"
    $out=Join-Path $s "$name.check.json"
    $err=Join-Path $s "$name.check.stderr.log"
    & $cli check $src --json > $out 2> $err
    $exit=$LASTEXITCODE
    $report=ArcJson $out
    $diagnostics=@($report.diagnostics|ForEach-Object {$_.diagnostic})
    $code=$diagnostics[0].code
    $span=$diagnostics[0].span
    $spelling=if($span){(Get-Content -Raw -LiteralPath $src).Substring($span.start,$span.end-$span.start)}else{$null}
    [ordered]@{name=$name;exit=$exit;stage=$report.stage;code=$code;span=$spelling;inputSha256=ArcSha $src;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
$src=Join-Path $s 'dynamic-callable-execution.arcw'
@'
fn make(creator: i64) -> ((i64) -> ((Unit) -> i64 effects {}) effects {}) {
    |caller: i64| -> ((Unit) -> i64 effects {}) {
        |_unit: Unit| -> i64 { creator + caller }
    }
}
flow main() -> i64 {
    let factory = make(40i64)
    let callback = factory(2i64)
    return callback(())
}
'@ | Set-Content -LiteralPath $src -Encoding utf8
$execution=@(foreach($tier in 'bytecode-vm','aot','awbc-product'){
    $out=Join-Path $s "$tier.run.json"
    $err=Join-Path $s "$tier.run.stderr.log"
    & $cli run $src --runner headless --flow main --executor $tier --mode one-op --max-ops 1 --steps 256 --json > $out 2> $err
    $exit=$LASTEXITCODE
    $report=ArcJson $out
    $metrics=@($report.steps|ForEach-Object {$_.stats.executed_ops})|Measure-Object -Maximum -Sum
    $returnEvents=@($report.steps|ForEach-Object {$_.flow_events}|Where-Object {$_ -eq 'return 42'})
    $accepted=!$exit -and $report.executor -eq $tier.Replace('-','_') -and $report.final_status -ceq 'done Return("42")' -and $report.steps.Count -le 256 -and $report.steps[-1].stop_reason -eq 'Done' -and $metrics.Maximum -le 1 -and $returnEvents.Count -eq 1 -and !@($report.steps|Where-Object {$_.diagnostics -or $_.assertion_failures -or $_.task_requests}).Count
    [ordered]@{tier=$tier;exit=$exit;executor=$report.executor;steps=$report.steps.Count;maxOps=$metrics.Maximum;executedOps=$metrics.Sum;finalStatus=$report.final_status;accepted=$accepted;reportSha256=ArcSha $out;stderrSha256=ArcSha $err}
})
if((ArcSha $cli) -ne $sha){throw 'CLI changed during smoke'}
[ordered]@{version=1;base=$q.base;validatedInputs=$q.inputs;cliSha256=$sha;checks=$checks;execution=[ordered]@{inputSha256=ArcSha $src;runner='headless';mode='one-op';operationLimit=1;stepLimit=256;cases=$execution}}|ConvertTo-Json -Depth 13|Set-Content -LiteralPath (Join-Path $s 'supplemental.receipt.json') -Encoding utf8
$checks|ForEach-Object {[pscustomobject]$_}|Format-Table name,exit,stage,code,span
$execution|ForEach-Object {[pscustomobject]$_}|Format-Table tier,exit,accepted,steps,maxOps,finalStatus
exit 0
