param([Parameter(Mandatory)][string]$Attempt,[switch]$RegressionOnly)
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
. (Join-Path $e 'convergence-image-git-bytes.ps1')
$base=(& git rev-parse HEAD).Trim()
if ($base -ne 'b69d21870167a84bdfbc7cd0e0073a47bb3d4d8c' -or @(git diff --cached --name-only).Count) { throw 'Unexpected base/index' }
$prefix='flow-transfer-awbc-admission-'+$Attempt
$listLog=Join-Path $e ($prefix+'.list.log')
$runLog=Join-Path $e ($prefix+'.run.log')
if (Test-Path -LiteralPath $listLog) { throw 'Attempt already exists' }
$patch=Read-GitBytes @('diff','--binary','--full-index','HEAD')
$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($patch)).ToLowerInvariant()
[IO.File]::WriteAllBytes((Join-Path $e ($prefix+'.patch')),$patch)
$pins=@(foreach($p in @(git diff HEAD --name-only)){[ordered]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})
$test='rejected_dynamic_goto_runs_failure_cleanup_without_completing_its_scope'
$filter=if($RegressionOnly){'test(='+$test+')'}else{'binary(=scoped_defer) or binary(=flow_transfer) or (package(=arcweft-core) and (test(/flow_transfer/) or test(/goto/)))'}
$selection=@('--locked','--all-features','-p','arcweft-core','-p','arcweft-compiler','--lib','--test','flow_transfer','--test','scoped_defer','-E',$filter)
$listArgs=@('nextest','list','--message-format','json')+$selection
$runArgs=@('nextest','run','--no-fail-fast','--no-tests','fail')+$selection
[ordered]@{version=1;base=$base;patchSha256=$hash;sourceFiles=$pins;listArgs=$listArgs;runArgs=$runArgs}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $e ($prefix+'.inputs.json')) -Encoding utf8
& cargo @listArgs *> $listLog
$listCode=$LASTEXITCODE
if ($listCode -ne 0) { Write-Output ('List exit='+$listCode); exit $listCode }
$raw=[IO.File]::ReadLines($listLog)|Where-Object {$_.StartsWith('{')}|Select-Object -Last 1
if (!$raw) { throw 'Missing catalog' }
$catalog=$raw|ConvertFrom-Json -AsHashtable
$selected=@(foreach($suite in $catalog.'rust-suites'.Values){foreach($name in $suite.testcases.Keys){if($suite.testcases[$name].'filter-match'.status -eq 'matches'){[ordered]@{id=$suite.'binary-id'+' '+$name;package=$suite.'package-name';path=$suite.'binary-path'}}}})
if (@($selected|Where-Object {$_.id -ceq ('arcweft-compiler::scoped_defer '+$test)}).Count -ne 1 -or ($RegressionOnly -and $selected.Count -ne 1)) { throw 'Regression is missing or duplicated' }
$paths=@($selected.path|Sort-Object -Unique)
function Read-Pins {@(foreach($p in $paths){[ordered]@{path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}})}
$before=Read-Pins
$before|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-before.json')) -Encoding utf8
Write-Output ('Selected '+$selected.Count+' tests.')
& cargo @runArgs *> $runLog
$code=$LASTEXITCODE
$after=Read-Pins
$after|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $e ($prefix+'.binaries-after.json')) -Encoding utf8
$actual=Read-GitBytes @('diff','--binary','--full-index','HEAD')
if ((& git rev-parse HEAD).Trim() -ne $base -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($actual)).ToLowerInvariant() -ne $hash) { throw 'Source changed during run' }
$drift=@(for($i=0;$i -lt $before.Count;$i++){if($before[$i].path -ne $after[$i].path -or $before[$i].sha256 -ne $after[$i].sha256){$after[$i].path}})
$terminal=@([IO.File]::ReadLines($runLog)|Where-Object {$_ -match '^\s+(Summary|FAIL|TIMEOUT)\s+\['})
[ordered]@{version=1;base=$base;patchSha256=$hash;exitCode=$code;sourceDrift=0;binaryDrift=$drift;selected=$selected;terminal=$terminal}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $e ($prefix+'.results.json')) -Encoding utf8
[ordered]@{exitCode=$code;selected=$selected.Count;binaryDrift=$drift.Count;terminal=$terminal}|ConvertTo-Json -Depth 5 -Compress
exit $code
