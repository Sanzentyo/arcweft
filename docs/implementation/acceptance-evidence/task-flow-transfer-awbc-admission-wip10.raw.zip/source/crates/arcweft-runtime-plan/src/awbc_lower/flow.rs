mod program_task;

use crate::awbc_lower::AwbcAudioLowerer;
use crate::awbc_lower::AwbcTraitMethodLowerer;
use crate::awbc_lower::expr::AwbcExprLowerer;
use crate::awbc_lower::frame::FrameBuilder;
use crate::awbc_lower::inventory::{
    AwbcInventory, AwbcLowerDiagnostic, PendingAwbcClosure, line_cleanup,
};
use crate::awbc_lower::line::AwbcLineLowerer;
use crate::awbc_lower::pattern::{
    admitted_local_type, admitted_plan_type, function_input_ownership, lower_pattern,
};
use crate::awbc_lower::{table_index, table_range_len};
use arcweft_core::awbc::schema::{
    AwbcAwaitObserverResume, AwbcBindMode, AwbcBlockId, AwbcChoiceId, AwbcChoiceOption,
    AwbcDialogueContentEffectBinding, AwbcDialogueResultTarget, AwbcDialogueValueBinding,
    AwbcDialogueValueRole, AwbcDropPolicy, AwbcEffectPlanId, AwbcEffectSetId, AwbcFrameLayoutId,
    AwbcFrameSlotRole, AwbcFunction, AwbcFunctionFlag, AwbcFunctionFlags, AwbcFunctionId,
    AwbcFunctionInputOwnership, AwbcFunctionKind, AwbcInstruction, AwbcIntrinsic, AwbcIntrinsicId,
    AwbcLineCancelHandler, AwbcLineHandleSite, AwbcLineHandleSiteId, AwbcLineOperation,
    AwbcLineOperationId, AwbcLineSharedInput, AwbcLineTaskGroup, AwbcLineTaskGroupId,
    AwbcLineTaskNode, AwbcLineTaskNodeId, AwbcLineTaskTrigger, AwbcParallelPolicy, AwbcPattern,
    AwbcPatternId, AwbcProjectCall, AwbcProjectCallAttachedMaterialization,
    AwbcProjectCallAttachedPresence, AwbcProjectCallOperand, AwbcProjectCallOperandMode,
    AwbcProjectCallOrdinaryMaterialization, AwbcPureHelper, AwbcPureHelperOrigin, AwbcRegisterId,
    AwbcResumePoint, AwbcResumePointId, AwbcRuntimeType, AwbcRuntimeTypeShape, AwbcSafePointKind,
    AwbcScopeId, AwbcTableRange, AwbcTerminator, AwbcTraitMethodId, AwbcTrapCode,
    AwbcVariantIdentity,
};
use arcweft_core::effect::{LineEffectRequest, RuntimeDropPolicyExpr, RuntimeEffectExpr};
use arcweft_core::entry::RuntimeEntryRoles;
use arcweft_core::line_task::{
    ChildCancelPolicy, ChildJoinPolicy, LineTaskGroup, LineTaskNode, LineTaskTrigger,
    ParallelPolicy,
};
use arcweft_core::pattern::{
    RuntimeBuiltinVariantCaseIdentity, RuntimeBuiltinVariantIdentity, RuntimePattern,
    RuntimePatternKind,
};
use arcweft_core::plan::{
    ChoiceRuntimeOption, EntryRuntimeId, FlowOp, FlowRuntimeId, RuntimeDeferOwner,
    RuntimeDialogueValueRole, RuntimeEffectSet, RuntimeEntrySpec, RuntimeEntryTarget, RuntimeFlow,
    RuntimeIteratorEvidence, RuntimeIteratorWitnessExecutable, RuntimeLineOperation,
    RuntimeMatchArm, RuntimePlan,
    RuntimeProjectCallAttachedPresence as RuntimeProjectCallAttachedPresenceCore,
    RuntimeProjectCallOrdinaryMaterialization as RuntimeProjectCallOrdinaryMaterializationCore,
    RuntimeProjectCallPlan, RuntimePureHelper, RuntimePureHelperOrigin, RuntimeTraitMethodId,
};
use arcweft_core::value::{RuntimeCallTarget, RuntimeExpr, RuntimeValue};
use std::collections::{BTreeMap, BTreeSet};

/// Builds one contiguous flow body while allowing host-visible suspension
/// terminators to split the instruction stream into verified resume blocks.
struct FlowBodyBuilder {
    owner: AwbcFunctionId,
    block_start: u32,
    resume_points: Vec<AwbcResumePointId>,
    terminated: bool,
    returns_value: bool,
    has_dynamic_target: bool,
}

#[derive(Clone, Copy)]
struct ForLoweringInput<'a> {
    pattern: &'a RuntimePattern,
    source: &'a RuntimeExpr,
    evidence: &'a RuntimeIteratorEvidence,
    ops: &'a [FlowOp],
    path: &'a str,
}

#[derive(Clone, Copy)]
struct WhileLetLoweringInput<'a> {
    pattern: &'a RuntimePattern,
    expr: &'a RuntimeExpr,
    guard: Option<&'a RuntimeExpr>,
    ops: &'a [FlowOp],
    path: &'a str,
}

struct WhileLetBodyInput<'a> {
    header: AwbcBlockId,
    pattern: AwbcPatternId,
    value: AwbcRegisterId,
    guard: Option<&'a RuntimeExpr>,
    ops: &'a [FlowOp],
    path: &'a str,
    outer_scope_depth: u32,
    outer_scopes: &'a [AwbcScopeId],
}

struct BranchJoin {
    fallthroughs: Vec<(AwbcBlockId, Vec<AwbcScopeId>)>,
}

struct GuardedCandidate {
    guard_false_jump: Option<AwbcBlockId>,
    fallthrough: Option<(AwbcBlockId, Vec<AwbcScopeId>)>,
}

struct LoopLoweringTarget {
    header: AwbcBlockId,
    exit_jumps: Vec<AwbcBlockId>,
    outer_scope_depth: u32,
    outer_scopes: Vec<AwbcScopeId>,
    format_attempt_depth: usize,
    result: Option<AwbcRegisterId>,
}

#[derive(Clone)]
struct LineGroupLoweringContext {
    id: AwbcLineTaskGroupId,
    group: LineTaskGroup,
    node_ids: Vec<AwbcLineTaskNodeId>,
}

impl BranchJoin {
    const fn new() -> Self {
        Self {
            fallthroughs: Vec::new(),
        }
    }

    fn push(&mut self, block: AwbcBlockId, scopes: Vec<AwbcScopeId>) {
        self.fallthroughs.push((block, scopes));
    }
}

impl FlowBodyBuilder {
    fn new(
        inventory: &mut AwbcInventory,
        owner: AwbcFunctionId,
        entry_safe_point: AwbcSafePointKind,
    ) -> Self {
        Self {
            owner,
            block_start: inventory.begin_function_blocks(owner, entry_safe_point).0,
            resume_points: Vec::new(),
            terminated: false,
            returns_value: false,
            has_dynamic_target: false,
        }
    }

    fn suspend(
        &mut self,
        inventory: &mut AwbcInventory,
        kind: AwbcSafePointKind,
        terminator: impl FnOnce(AwbcResumePointId) -> AwbcTerminator,
    ) {
        if self.terminated {
            return;
        }
        let current_block = AwbcBlockId(table_index(inventory.program.blocks.len()));
        let next_block = AwbcBlockId(current_block.0.saturating_add(1));
        let resume = inventory.push_resume_point(AwbcResumePoint {
            function: self.owner,
            block: next_block,
            frame_layout: AwbcFrameLayoutId::default(),
            kind,
        });
        inventory.close_function_block(terminator(resume), kind);
        self.resume_points.push(resume);
    }

    fn close_block(
        &mut self,
        inventory: &mut AwbcInventory,
        terminator: AwbcTerminator,
        safe_point: AwbcSafePointKind,
    ) -> AwbcBlockId {
        inventory.close_function_block(terminator, safe_point)
    }

    fn reopen_after_terminated_branch(&mut self, inventory: &mut AwbcInventory) -> AwbcBlockId {
        self.terminated = false;
        inventory.reopen_function_block()
    }

    fn terminate(
        &mut self,
        inventory: &mut AwbcInventory,
        terminator: AwbcTerminator,
        safe_point: AwbcSafePointKind,
    ) {
        if self.terminated {
            return;
        }
        self.returns_value |= matches!(terminator, AwbcTerminator::Return { value: Some(_) });
        self.has_dynamic_target |= matches!(terminator, AwbcTerminator::GotoDynamic { .. });
        inventory.close_function_block(terminator, safe_point);
        self.terminated = true;
    }

    fn finish(mut self, inventory: &mut AwbcInventory) -> FlowBody {
        if !self.terminated {
            self.terminate(
                inventory,
                AwbcTerminator::Return { value: None },
                AwbcSafePointKind::Return,
            );
        }
        let block_len = table_range_len(self.block_start, inventory.program.blocks.len());
        FlowBody {
            entry_block: AwbcBlockId(self.block_start),
            blocks: AwbcTableRange::new(self.block_start, block_len),
            resume_points: self.resume_points,
            returns_value: self.returns_value,
            has_dynamic_target: self.has_dynamic_target,
        }
    }

    const fn needs_value_fallthrough(&self) -> bool {
        self.returns_value && !self.terminated
    }
}

struct FlowBody {
    entry_block: AwbcBlockId,
    blocks: AwbcTableRange,
    resume_points: Vec<AwbcResumePointId>,
    returns_value: bool,
    has_dynamic_target: bool,
}

/// Lowers all flow entry functions and public entries.
pub struct AwbcFlowLowerer<'inventory, 'plan> {
    inventory: &'inventory mut AwbcInventory,
    plan: &'plan RuntimePlan,
    diagnostics: Vec<AwbcLowerDiagnostic>,
    loop_targets: Vec<LoopLoweringTarget>,
    active_format_attempts: Vec<arcweft_core::runtime_id::RuntimeFormatAttemptId>,
    line_group: Option<LineGroupLoweringContext>,
    cancellation_handler_result: Option<(
        arcweft_core::runtime_id::RuntimePlanTypeId,
        arcweft_core::awbc::schema::AwbcTypeId,
    )>,
    line_result_selector: Option<(
        arcweft_core::runtime_id::RuntimePlanTypeId,
        arcweft_core::awbc::schema::AwbcTypeId,
    )>,
    active_effect_set: Option<RuntimeEffectSet>,
}

impl<'inventory, 'plan> AwbcFlowLowerer<'inventory, 'plan> {
    pub fn new(inventory: &'inventory mut AwbcInventory, plan: &'plan RuntimePlan) -> Self {
        Self {
            inventory,
            plan,
            diagnostics: Vec::new(),
            loop_targets: Vec::new(),
            active_format_attempts: Vec::new(),
            line_group: None,
            cancellation_handler_result: None,
            line_result_selector: None,
            active_effect_set: None,
        }
    }

    pub fn lower_plan(&mut self) {
        let flows = self
            .plan
            .flows()
            .iter()
            .map(|flow| flow.id.clone())
            .collect::<BTreeSet<_>>();
        let entries = self.plan.entries().iter().collect::<Vec<_>>();
        self.lower_plan_selection(&flows, &entries);
    }

    /// Lowers one selected entry directly from its complete owning plan.
    pub fn lower_entry_plan(&mut self, selected: &EntryRuntimeId) {
        let entries = self
            .plan
            .entries()
            .iter()
            .filter(|entry| &entry.id == selected)
            .collect::<Vec<_>>();
        let [entry] = entries.as_slice() else {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                selected.canonical_label(),
                if entries.is_empty() {
                    "selected entry is missing from the accepted RuntimePlan"
                } else {
                    "selected entry is duplicated in the accepted RuntimePlan"
                },
            ));
            return;
        };
        let flows = entry_target_flows([*entry]);
        self.lower_plan_selection(&flows, &entries);
    }

    fn lower_plan_selection(
        &mut self,
        selected_flows: &BTreeSet<FlowRuntimeId>,
        entries: &[&RuntimeEntrySpec],
    ) {
        for flow in self
            .plan
            .flows()
            .iter()
            .filter(|flow| selected_flows.contains(&flow.id))
        {
            let function = self
                .inventory
                .reserve_function_site_slot(flow.function_site(), flow.definition());
            self.inventory.bind_flow_function(&flow.id, function);
        }
        for helper in self.plan.pure_helpers() {
            self.lower_pure_helper(helper);
        }
        AwbcTraitMethodLowerer::new(self.inventory, self.plan).lower_plan();
        for group in self.plan.line_task_groups() {
            if self.lower_line_task_group(group).is_none() {
                return;
            }
        }
        self.lower_defer_sites();
        for flow in self
            .plan
            .flows()
            .iter()
            .filter(|flow| selected_flows.contains(&flow.id))
        {
            self.lower_flow(flow);
        }
        for executable in self.plan.callable_executables() {
            let selected = entries.iter().any(|entry| match &entry.roles {
                RuntimeEntryRoles::Stateful(roles) => {
                    (roles.initializer.callable == executable.callable
                        && roles.initializer.contract == executable.contract)
                        || (roles.reducer.callable == executable.callable
                            && roles.reducer.contract == executable.contract)
                }
                RuntimeEntryRoles::Agent(roles) => {
                    roles.controller.callable == executable.callable
                        && roles.controller.contract == executable.contract
                }
                RuntimeEntryRoles::None => false,
            });
            if !selected {
                continue;
            }
            if let arcweft_core::entry::RuntimeCallableExecutableCode::FunctionSite(site) =
                &executable.code
            {
                let _ = self.prepare_function_site(
                    *site,
                    &format!("callable.{}", executable.callable.as_str()),
                );
            }
        }
        self.inventory.lower_selected_entries(self.plan, entries);
    }

    fn lower_defer_sites(&mut self) {
        let sites = self.plan.defer_sites().to_vec();
        let mut functions = Vec::with_capacity(sites.len());
        for (index, site) in sites.into_iter().enumerate() {
            let path = format!("defer.{index}");
            let Some(function) = self.prepare_function_site(site, &path) else {
                continue;
            };
            functions.push(function);
        }
        self.inventory.program.defer_sites = functions;
    }

    fn lower_pure_helper(&mut self, helper: &RuntimePureHelper) {
        let expected_index = self.inventory.program.pure_helpers.len();
        if helper.id.0 != expected_index {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                format!("pure.{}", helper.name),
                format!(
                    "pure helper `{}` has id {}, expected contiguous id {}",
                    helper.name, helper.id.0, expected_index
                ),
            ));
            return;
        }

        let owner = self.inventory.reserve_function_slot(helper.definition);
        let mut frame = FrameBuilder::new();
        let mut parameter_types = Vec::with_capacity(helper.inputs.len());
        for input in &helper.inputs {
            let ty = admitted_local_type(self.inventory, self.plan, input.local());
            frame.parameter(input.local(), ty);
            parameter_types.push(ty);
        }
        let block_start = self
            .inventory
            .begin_function_blocks(owner, AwbcSafePointKind::CallableBoundary);
        let value = AwbcExprLowerer::new(
            self.inventory,
            &mut frame,
            format!("pure.{}", helper.name),
            self.plan,
        )
        .lower(&helper.expr);
        let layout = self.inventory.intern_frame_layout(owner, frame.finish());
        self.inventory.close_function_block(
            AwbcTerminator::Return { value: Some(value) },
            AwbcSafePointKind::Return,
        );
        let block_len = table_range_len(block_start.0, self.inventory.program.blocks.len());
        let public_id = self.inventory.intern_string(&helper.name);
        let result_type = crate::awbc_lower::pattern::admitted_plan_type(
            self.inventory,
            self.plan,
            helper.result,
        );
        let signature = self.inventory.intern_signature(
            parameter_types,
            Some(result_type),
            arcweft_core::awbc::schema::AwbcEffectSetId(0),
        );
        let function = self.inventory.replace_function(
            owner,
            AwbcFunction {
                definition: helper.definition,
                semantic_role: arcweft_core::plan::RuntimeFunctionSemanticRole::Ordinary,
                public_id: Some(public_id),
                kind: AwbcFunctionKind::PureHelper,
                signature,
                type_context: None,
                input_ownership: helper
                    .inputs
                    .iter()
                    .enumerate()
                    .map(|(position, input)| {
                        AwbcFunctionInputOwnership::parameter(
                            input.identity(),
                            table_index(position),
                            input.passing(),
                        )
                    })
                    .collect(),
                frame_layout: layout,
                blocks: AwbcTableRange::new(block_start.0, block_len),
                entry_block: block_start,
                flags: AwbcFunctionFlags::empty().with(AwbcFunctionFlag::Deterministic),
            },
        );
        self.inventory.program.pure_helpers.push(AwbcPureHelper {
            public_id,
            signature,
            function,
            scalar_eval_supported: helper.scalar_eval_supported,
            origin: match helper.origin {
                RuntimePureHelperOrigin::Annotated => AwbcPureHelperOrigin::Annotated,
                RuntimePureHelperOrigin::Inferred => AwbcPureHelperOrigin::Inferred,
            },
        });
    }

    fn local_type(
        &mut self,
        local: arcweft_core::runtime_id::RuntimeLocalDeclarationId,
    ) -> arcweft_core::awbc::schema::AwbcTypeId {
        admitted_local_type(self.inventory, self.plan, local)
    }

    pub fn into_diagnostics(mut self) -> Vec<AwbcLowerDiagnostic> {
        self.diagnostics.extend(self.inventory.take_diagnostics());
        self.diagnostics
    }

    fn lower_line_task_group(&mut self, group: &LineTaskGroup) -> Option<AwbcLineTaskGroupId> {
        let id = AwbcLineTaskGroupId(table_index(self.inventory.program.line_task_groups.len()));
        let node_start = table_index(self.inventory.program.line_task_nodes.len());
        let node_ids = match checked_line_task_node_ids(group, node_start) {
            Ok(node_ids) => node_ids,
            Err(diagnostic) => {
                self.inventory.diagnostic(diagnostic);
                return None;
            }
        };
        let node_id = |id: arcweft_core::runtime_id::RuntimeLineTaskNodeId| node_ids[id.index()];
        let previous = self.line_group.replace(LineGroupLoweringContext {
            id,
            group: group.clone(),
            node_ids: node_ids.clone(),
        });
        debug_assert!(previous.is_none());
        let Some((activation, shared_inputs)) = self.lower_line_task_activation(
            group.initial_inputs(),
            group.shared_inputs(),
            group.activation_ops(),
            "line_task.activation",
        ) else {
            self.line_group = previous;
            return None;
        };
        let task_inputs = group.shared_inputs().to_vec();
        let Some(scheduled_action_inputs) =
            self.line_task_scheduled_action_inputs(group, &node_ids, id)
        else {
            self.line_group = previous;
            return None;
        };
        self.lower_line_task_nodes(group, &node_ids, &task_inputs, &scheduled_action_inputs);
        let result_type = admitted_plan_type(self.inventory, self.plan, group.result_type());
        let cancel_handlers = group
            .cancel_rules()
            .iter()
            .enumerate()
            .map(|(index, rule)| AwbcLineCancelHandler {
                trigger: rule.trigger().clone(),
                function: self.lower_line_task_cancel_handler(
                    table_index(index),
                    &task_inputs,
                    rule.action(),
                    &format!("line_task.cancel.{index}"),
                    group.result_type(),
                ),
            })
            .collect();
        let completed = group
            .cleanup()
            .actions(arcweft_core::line_task::ScopeExit::Completed);
        let cleanup_completed = (!completed.is_empty()).then(|| {
            self.lower_line_function(
                arcweft_core::plan::RuntimeGeneratedFunctionRole::LineCleanup {
                    exit: arcweft_core::line_task::ScopeExit::Completed,
                },
                &task_inputs,
                completed,
                "line_task.cleanup.completed",
                AwbcFunctionKind::LineTask,
                arcweft_core::plan::RuntimeFunctionCaptureMode::SnapshotClone,
            )
        });
        let cancelled = group
            .cleanup()
            .actions(arcweft_core::line_task::ScopeExit::Cancelled);
        let cleanup_cancelled = (!cancelled.is_empty()).then(|| {
            self.lower_line_function(
                arcweft_core::plan::RuntimeGeneratedFunctionRole::LineCleanup {
                    exit: arcweft_core::line_task::ScopeExit::Cancelled,
                },
                &task_inputs,
                cancelled,
                "line_task.cleanup.cancelled",
                AwbcFunctionKind::LineTask,
                arcweft_core::plan::RuntimeFunctionCaptureMode::SnapshotClone,
            )
        });
        let failed = group
            .cleanup()
            .actions(arcweft_core::line_task::ScopeExit::Failed);
        let cleanup_failed = (!failed.is_empty()).then(|| {
            self.lower_line_function(
                arcweft_core::plan::RuntimeGeneratedFunctionRole::LineCleanup {
                    exit: arcweft_core::line_task::ScopeExit::Failed,
                },
                &task_inputs,
                failed,
                "line_task.cleanup.failed",
                AwbcFunctionKind::LineTask,
                arcweft_core::plan::RuntimeFunctionCaptureMode::SnapshotClone,
            )
        });
        let handle_sites = group
            .handle_sites()
            .iter()
            .map(|site| AwbcLineHandleSite {
                source_ordinal: site.source_ordinal(),
                kind: site.kind(),
                result_type: admitted_plan_type(self.inventory, self.plan, site.result_type()),
                character: site.character().cloned(),
                scheduled_child: site.scheduled_child().map(node_id),
            })
            .collect();
        self.inventory
            .program
            .line_task_groups
            .push(AwbcLineTaskGroup {
                shared_inputs,
                activation,
                result_type,
                handle_sites,
                root: node_id(group.root()),
                nodes: AwbcTableRange::new(
                    node_start,
                    table_range_len(node_start, self.inventory.program.line_task_nodes.len()),
                ),
                cancel_handlers,
                cleanup_completed,
                cleanup_cancelled,
                cleanup_failed,
                cleanup: line_cleanup(group.cleanup().policy()),
            });
        self.line_group = previous;
        Some(id)
    }

    fn line_task_scheduled_action_inputs(
        &mut self,
        group: &LineTaskGroup,
        node_ids: &[AwbcLineTaskNodeId],
        owner: AwbcLineTaskGroupId,
    ) -> Option<
        BTreeMap<AwbcLineTaskNodeId, Vec<arcweft_core::runtime_id::RuntimeLocalDeclarationId>>,
    > {
        let scheduled_inputs = self
            .inventory
            .program
            .line_operations
            .iter()
            .filter_map(|operation| match operation {
                AwbcLineOperation::Schedule {
                    group,
                    child,
                    captures,
                    ..
                } if *group == owner => Some((
                    *child,
                    captures
                        .iter()
                        .map(|capture| capture.local)
                        .collect::<Vec<_>>(),
                )),
                _ => None,
            })
            .collect::<BTreeMap<_, _>>();
        let action_inputs = group
            .nodes()
            .iter()
            .enumerate()
            .filter_map(|(index, node)| match node {
                LineTaskNode::Child {
                    trigger: LineTaskTrigger::Scheduled(_),
                    scope,
                    ..
                } => Some((node_ids[index], node_ids[scope.index()])),
                _ => None,
            })
            .map(|(child, scope)| {
                scheduled_inputs
                    .get(&child)
                    .cloned()
                    .map(|inputs| (scope, inputs))
            })
            .collect::<Option<BTreeMap<_, _>>>();
        if action_inputs.is_none() {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                "line_task.activation",
                "scheduled child has no checked capture packet",
            ));
        }
        action_inputs
    }

    fn lower_line_task_activation(
        &mut self,
        captures: &[arcweft_core::value::RuntimeLocalRead],
        exports: &[arcweft_core::runtime_id::RuntimeLocalDeclarationId],
        ops: &[FlowOp],
        path: &str,
    ) -> Option<(AwbcFunctionId, Vec<AwbcLineSharedInput>)> {
        let (function, slots) = self.lower_line_function_with_capture_slots(
            arcweft_core::plan::RuntimeGeneratedFunctionRole::LineActivation,
            captures.iter().map(|input| {
                (
                    input.local(),
                    match input.mode() {
                        arcweft_core::value::RuntimeLocalReadMode::Copy => {
                            arcweft_core::plan::RuntimeFunctionCaptureMode::SnapshotClone
                        }
                        arcweft_core::value::RuntimeLocalReadMode::Move => {
                            arcweft_core::plan::RuntimeFunctionCaptureMode::Move
                        }
                    },
                )
            }),
            ops,
            path,
            AwbcFunctionKind::LineActivation,
        );
        let layout = self
            .inventory
            .program
            .functions
            .get(function.index())
            .and_then(|function| {
                self.inventory
                    .program
                    .frame_layouts
                    .get(function.frame_layout.index())
            })?;
        let exports = exports
            .iter()
            .map(|local| {
                let register = slots.iter().find(|slot| slot.local == *local)?.register;
                let slot = layout.slots.get(register.index())?;
                (slot.scope_depth == 0
                    && matches!(
                        slot.role,
                        AwbcFrameSlotRole::Local | AwbcFrameSlotRole::Parameter
                    ))
                .then_some(AwbcLineSharedInput {
                    register,
                    ty: slot.ty,
                })
            })
            .collect::<Option<Vec<_>>>();
        let Some(exports) = exports else {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                path,
                "activation export has no root-owned AWBC local register",
            ));
            return None;
        };
        Some((function, exports))
    }

    fn lower_line_task_nodes(
        &mut self,
        group: &LineTaskGroup,
        node_ids: &[AwbcLineTaskNodeId],
        task_inputs: &[arcweft_core::runtime_id::RuntimeLocalDeclarationId],
        scheduled_action_inputs: &BTreeMap<
            AwbcLineTaskNodeId,
            Vec<arcweft_core::runtime_id::RuntimeLocalDeclarationId>,
        >,
    ) {
        let node_id = |id: arcweft_core::runtime_id::RuntimeLineTaskNodeId| node_ids[id.index()];
        for (index, node) in group.nodes().iter().enumerate() {
            let path = format!("line_task.{index}");
            let lowered = match node {
                LineTaskNode::Sequence(nodes) => {
                    AwbcLineTaskNode::Sequence(nodes.iter().copied().map(node_id).collect())
                }
                LineTaskNode::Start(nodes) => {
                    AwbcLineTaskNode::Start(nodes.iter().copied().map(node_id).collect())
                }
                LineTaskNode::Parallel { policy, children } => AwbcLineTaskNode::Parallel {
                    policy: match policy {
                        ParallelPolicy::JoinAll => AwbcParallelPolicy::JoinAll,
                    },
                    children: children.iter().copied().map(node_id).collect(),
                },
                LineTaskNode::Child {
                    trigger,
                    join_policy,
                    cancel_policy,
                    scope,
                } => AwbcLineTaskNode::Child {
                    trigger: match trigger {
                        LineTaskTrigger::Immediate => AwbcLineTaskTrigger::Immediate,
                        LineTaskTrigger::Mark(mark) => AwbcLineTaskTrigger::Mark(*mark),
                        LineTaskTrigger::Scheduled(site) => AwbcLineTaskTrigger::Scheduled(
                            arcweft_core::awbc::schema::AwbcLineHandleSiteId(site.get()),
                        ),
                    },
                    join: match join_policy {
                        ChildJoinPolicy::Join => {
                            arcweft_core::awbc::schema::AwbcChildJoinPolicy::Join
                        }
                        ChildJoinPolicy::Detached => {
                            arcweft_core::awbc::schema::AwbcChildJoinPolicy::Detached
                        }
                    },
                    cancel: match cancel_policy {
                        ChildCancelPolicy::CancelAndJoin => {
                            arcweft_core::awbc::schema::AwbcChildCancelPolicy::CancelAndJoin
                        }
                        ChildCancelPolicy::Finish => {
                            arcweft_core::awbc::schema::AwbcChildCancelPolicy::Finish
                        }
                        ChildCancelPolicy::Detach => {
                            arcweft_core::awbc::schema::AwbcChildCancelPolicy::Detach
                        }
                    },
                    scope: node_id(*scope),
                },
                LineTaskNode::Action(ops) => AwbcLineTaskNode::Action(
                    self.lower_line_task_action(
                        table_index(index),
                        scheduled_action_inputs
                            .get(&node_ids[index])
                            .map_or(task_inputs, Vec::as_slice),
                        ops,
                        &path,
                        group.result_type(),
                        if scheduled_action_inputs.contains_key(&node_ids[index]) {
                            arcweft_core::plan::RuntimeFunctionCaptureMode::Move
                        } else {
                            arcweft_core::plan::RuntimeFunctionCaptureMode::SnapshotClone
                        },
                    ),
                ),
            };
            self.inventory.program.line_task_nodes.push(lowered);
        }
    }

    fn lower_line_task_action(
        &mut self,
        source_node: u32,
        captures: &[arcweft_core::runtime_id::RuntimeLocalDeclarationId],
        ops: &[FlowOp],
        path: &str,
        result_type: arcweft_core::runtime_id::RuntimePlanTypeId,
        capture_mode: arcweft_core::plan::RuntimeFunctionCaptureMode,
    ) -> AwbcFunctionId {
        let result_type_awbc = admitted_plan_type(self.inventory, self.plan, result_type);
        let previous = self
            .line_result_selector
            .replace((result_type, result_type_awbc));
        let function = self.lower_line_function(
            arcweft_core::plan::RuntimeGeneratedFunctionRole::LineAction { source_node },
            captures,
            ops,
            path,
            AwbcFunctionKind::LineTask,
            capture_mode,
        );
        self.line_result_selector = previous;
        function
    }

    fn lower_line_task_cancel_handler(
        &mut self,
        source_rule: u32,
        captures: &[arcweft_core::runtime_id::RuntimeLocalDeclarationId],
        ops: &[FlowOp],
        path: &str,
        result_type: arcweft_core::runtime_id::RuntimePlanTypeId,
    ) -> AwbcFunctionId {
        let result_type_awbc = admitted_plan_type(self.inventory, self.plan, result_type);
        let previous = self
            .cancellation_handler_result
            .replace((result_type, result_type_awbc));
        let previous_selector = self
            .line_result_selector
            .replace((result_type, result_type_awbc));
        let function = self.lower_line_function(
            arcweft_core::plan::RuntimeGeneratedFunctionRole::LineCancellation { source_rule },
            captures,
            ops,
            path,
            AwbcFunctionKind::LineCancellationHandler,
            arcweft_core::plan::RuntimeFunctionCaptureMode::SnapshotClone,
        );
        self.cancellation_handler_result = previous;
        self.line_result_selector = previous_selector;
        function
    }

    fn lower_line_function(
        &mut self,
        role: arcweft_core::plan::RuntimeGeneratedFunctionRole,
        captures: &[arcweft_core::runtime_id::RuntimeLocalDeclarationId],
        ops: &[FlowOp],
        path: &str,
        kind: AwbcFunctionKind,
        capture_mode: arcweft_core::plan::RuntimeFunctionCaptureMode,
    ) -> AwbcFunctionId {
        self.lower_line_function_with_capture_slots(
            role,
            captures.iter().map(|local| (*local, capture_mode)),
            ops,
            path,
            kind,
        )
        .0
    }

    fn lower_line_function_with_capture_slots(
        &mut self,
        role: arcweft_core::plan::RuntimeGeneratedFunctionRole,
        inputs: impl Clone
        + ExactSizeIterator<
            Item = (
                arcweft_core::runtime_id::RuntimeLocalDeclarationId,
                arcweft_core::plan::RuntimeFunctionCaptureMode,
            ),
        >,
        ops: &[FlowOp],
        path: &str,
        kind: AwbcFunctionKind,
    ) -> (
        AwbcFunctionId,
        Vec<crate::awbc_lower::frame::FrameCaptureSlot>,
    ) {
        let group = &self
            .line_group
            .as_ref()
            .expect("Line function has its accepted group owner")
            .group;
        let definition = group.definition().generated_child(role);
        let effects = group.effects().clone();
        let effect_set = self.inventory.intern_effect_set(&effects);
        let owner = self.inventory.reserve_function_slot(definition);
        let mut frame = FrameBuilder::new();
        for (local, _) in inputs.clone() {
            let ty = self.local_type(local);
            frame.parameter(local, ty);
        }
        let mut body =
            FlowBodyBuilder::new(self.inventory, owner, AwbcSafePointKind::CallableBoundary);
        let previous_effects = self.active_effect_set.replace(effects);
        self.lower_ops(&mut frame, &mut body, ops, path);
        self.active_effect_set = previous_effects;
        if body.needs_value_fallthrough() && kind != AwbcFunctionKind::LineCancellationHandler {
            self.terminate_value_fallthrough(&mut frame, &mut body);
        }
        let capture_slots = frame.capture_slots();
        let body = body.finish(self.inventory);
        let layout = self.inventory.intern_frame_layout(owner, frame.finish());
        for resume in body.resume_points {
            if let Some(point) = self.inventory.program.resume_points.get_mut(resume.index()) {
                point.frame_layout = layout;
            }
        }
        let params = inputs
            .clone()
            .map(|(local, _)| self.local_type(local))
            .collect();
        let result = body.returns_value.then(|| self.inventory.dynamic_ty());
        let signature = self.inventory.intern_signature(params, result, effect_set);
        let public_id = Some(self.inventory.intern_string(path));
        let function = self.inventory.replace_function(
            owner,
            AwbcFunction {
                definition,
                semantic_role: arcweft_core::plan::RuntimeFunctionSemanticRole::Line,
                public_id,
                kind,
                signature,
                type_context: None,
                input_ownership: inputs
                    .enumerate()
                    .map(|(position, (local, mode))| {
                        let mut input = AwbcFunctionInputOwnership::capture(
                            self.plan
                                .local_declarations()
                                .get(local)
                                .expect("admitted Line capture declaration")
                                .origin(),
                            table_index(position),
                            mode,
                        );
                        if mode != arcweft_core::plan::RuntimeFunctionCaptureMode::Move {
                            input.requirement = arcweft_core::value::ownership::RuntimeValueOwnershipRequirement::Unrestricted;
                        }
                        input
                    })
                    .collect(),
                frame_layout: layout,
                blocks: body.blocks,
                entry_block: body.entry_block,
                flags: AwbcFunctionFlags::empty()
                    .with(AwbcFunctionFlag::Deterministic)
                    .with(AwbcFunctionFlag::MaySuspend),
            },
        );
        (function, capture_slots)
    }

    /// Lowers an executable structured function-site body through the normal
    /// flow lowerer.  Content callbacks use an ordinary AWBC function so an
    /// `EvaluatedEffect` becomes the same `EmitEffect` instruction used by
    /// every other flow body; no content-specific interpreter is introduced.
    pub(crate) fn lower_executable_function_site(
        &mut self,
        owner: AwbcFunctionId,
        site: &arcweft_core::plan::RuntimeFunctionSite,
        path: &str,
    ) -> AwbcFunctionId {
        let definition = site.definition();
        let role = site.role();
        let function_type = site.function_type();
        let inputs = site.inputs();
        let result = site.result();
        let executable = site
            .body()
            .executable()
            .expect("executable function site lowering");
        let mut frame = FrameBuilder::new();
        let mut abi_parameters = Vec::with_capacity(inputs.len());
        for (position, input) in inputs.iter().enumerate() {
            let input_local = input.input_local();
            let ty = self.local_type(input_local);
            let name = self.inventory.local_name(input_local);
            abi_parameters.push(frame.abi_parameter(position, ty, name));
        }
        let boundary = if role == arcweft_core::plan::RuntimeFunctionSemanticRole::Flow {
            AwbcSafePointKind::FlowEntry
        } else {
            AwbcSafePointKind::CallableBoundary
        };
        let mut body = FlowBodyBuilder::new(self.inventory, owner, boundary);
        let mut input_ownership = Vec::with_capacity(inputs.len());
        for (input, value) in inputs.iter().zip(abi_parameters) {
            let pattern = lower_pattern(self.inventory, self.plan, &mut frame, input.pattern());
            input_ownership.push(function_input_ownership(
                self.inventory,
                &frame,
                input,
                pattern,
                path,
            ));
            self.inventory
                .push_instruction(AwbcInstruction::BindPattern {
                    pattern,
                    value,
                    mode: AwbcBindMode::Declare,
                });
        }
        let previous_effect_set = self.active_effect_set.replace(executable.effects().clone());
        self.lower_ops(&mut frame, &mut body, executable.ops(), path);
        self.active_effect_set = previous_effect_set;
        let result_type = self.close_executable_body(
            &mut frame,
            &mut body,
            result,
            role.allows_implicit_unit_completion(),
        );
        let body = body.finish(self.inventory);
        let layout = self.inventory.intern_frame_layout(owner, frame.finish());
        for resume in &body.resume_points {
            if let Some(point) = self.inventory.program.resume_points.get_mut(resume.index()) {
                point.frame_layout = layout;
            }
        }
        let params = inputs
            .iter()
            .map(|input| self.local_type(input.input_local()))
            .collect();
        let effects = self.inventory.intern_effect_set(site.invocation_effects());
        let signature = self
            .inventory
            .intern_signature(params, Some(result_type), effects);
        let type_context = function_type.map(|ty| {
            arcweft_core::awbc::schema::AwbcFunctionTypeContext::Signature(admitted_plan_type(
                self.inventory,
                self.plan,
                ty,
            ))
        });
        let mut flags = AwbcFunctionFlags::empty()
            .with(AwbcFunctionFlag::Deterministic)
            .with(AwbcFunctionFlag::MaySuspend);
        if body.has_dynamic_target {
            flags = flags.with(AwbcFunctionFlag::HasDynamicTarget);
        }
        self.inventory.replace_function(
            owner,
            AwbcFunction {
                definition,
                semantic_role: role,
                public_id: None,
                kind: AwbcFunctionKind::Ordinary,
                signature,
                type_context,
                input_ownership,
                frame_layout: layout,
                blocks: body.blocks,
                entry_block: body.entry_block,
                flags,
            },
        )
    }

    fn close_executable_body(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        result: arcweft_core::runtime_id::RuntimePlanTypeId,
        allow_implicit_unit_completion: bool,
    ) -> arcweft_core::awbc::schema::AwbcTypeId {
        let result_type = admitted_plan_type(self.inventory, self.plan, result);
        let unit_result = matches!(
            self.plan.checked_type(result),
            Ok(Some(arcweft_core::pattern::RuntimeCheckedType::Unit))
        );
        let never_result = matches!(
            self.plan.checked_type(result),
            Ok(Some(arcweft_core::pattern::RuntimeCheckedType::Never))
        );
        if allow_implicit_unit_completion && unit_result && !body.terminated {
            self.close_active_scopes_for_terminator(frame);
            body.terminate(
                self.inventory,
                AwbcTerminator::Complete,
                AwbcSafePointKind::Return,
            );
        } else if never_result && !body.terminated {
            self.close_active_scopes_for_terminator(frame);
            body.terminate(
                self.inventory,
                AwbcTerminator::Unreachable,
                AwbcSafePointKind::Return,
            );
        } else if unit_result && !body.terminated {
            // Ordinary callable transitions always carry their declared result,
            // including Unit. Effect-only bodies synthesize that final value.
            let value = frame.return_value(result_type);
            let constant = self.inventory.constant_runtime_value(&RuntimeValue::Unit);
            self.inventory.push_instruction(AwbcInstruction::LoadConst {
                dst: value,
                constant,
            });
            self.close_active_scopes_for_terminator(frame);
            body.terminate(
                self.inventory,
                AwbcTerminator::Return { value: Some(value) },
                AwbcSafePointKind::Return,
            );
        } else if !body.terminated {
            // A non-Unit signature has no implicit result value. Any residual
            // continuation is unreachable; an invalid manual body traps.
            self.close_active_scopes_for_terminator(frame);
            body.terminate(
                self.inventory,
                AwbcTerminator::Unreachable,
                AwbcSafePointKind::Return,
            );
        }
        result_type
    }

    pub(crate) fn lower_flow(&mut self, flow: &RuntimeFlow) -> AwbcFunctionId {
        let function = flow.function();
        let owner = self
            .inventory
            .reserve_function_site_slot(flow.function_site(), function.definition());
        self.inventory.bind_flow_function(&flow.id, owner);
        if self.inventory.program.functions[owner.index()].blocks.len != 0 {
            return owner;
        }
        let public_name = flow_public_id(&flow.id);
        let emitted = self.lower_executable_function_site(owner, function, &public_name);
        let public_id = self.inventory.intern_string(&public_name);
        let row = &mut self.inventory.program.functions[emitted.index()];
        row.kind = AwbcFunctionKind::Flow;
        row.public_id = Some(public_id);
        emitted
    }

    fn terminate_value_fallthrough(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
    ) {
        let unit = self.inventory.constant_runtime_value(&RuntimeValue::Unit);
        let fallback = frame.return_value(self.inventory.dynamic_ty());
        self.inventory.push_instruction(AwbcInstruction::LoadConst {
            dst: fallback,
            constant: unit,
        });
        body.terminate(
            self.inventory,
            AwbcTerminator::Return {
                value: Some(fallback),
            },
            AwbcSafePointKind::Return,
        );
    }

    fn lower_ops(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        ops: &[FlowOp],
        path: &str,
    ) {
        for (index, op) in ops.iter().enumerate() {
            if body.terminated {
                break;
            }
            self.lower_op(frame, body, op, &format!("{path}.{index}"));
        }
    }

    #[allow(clippy::too_many_lines)]
    fn lower_op(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        op: &FlowOp,
        path: &str,
    ) {
        match op {
            FlowOp::ReceiveAction { channel, result } => {
                let channel = frame.local(*channel, self.local_type(*channel));
                let dst = frame.local(*result, self.local_type(*result));
                self.inventory
                    .push_instruction(AwbcInstruction::ReceiveAction { dst, channel });
            }
            FlowOp::StandardMap(control) => {
                let mapping = frame.local(control.mapping(), self.local_type(control.mapping()));
                self.inventory
                    .push_instruction(AwbcInstruction::RequireUnrestricted { value: mapping });
                self.lower_ops(frame, body, control.body(), path);
            }
            FlowOp::Let { pattern, expr } => {
                let value =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(expr);
                let pattern = lower_pattern(self.inventory, self.plan, frame, pattern);
                self.inventory
                    .push_instruction(AwbcInstruction::BindPattern {
                        pattern,
                        value,
                        mode: AwbcBindMode::Declare,
                    });
            }
            FlowOp::FormatOperandAttempt {
                attempt,
                parameter,
                body: ops,
                value,
            } => {
                let outer_scopes = frame.scope_checkpoint();
                let scope = frame.enter_scope();
                self.inventory
                    .push_instruction(AwbcInstruction::EnterScope { scope });
                self.inventory
                    .push_instruction(AwbcInstruction::FormatOperandAttempt {
                        attempt: *attempt,
                        parameter: *parameter,
                    });
                self.active_format_attempts.push(*attempt);
                self.lower_ops(frame, body, ops, &format!("{path}.operand"));
                if !body.terminated {
                    let value = AwbcExprLowerer::new(
                        self.inventory,
                        frame,
                        format!("{path}.value"),
                        self.plan,
                    )
                    .lower(value);
                    self.inventory
                        .push_instruction(AwbcInstruction::CompleteFormatOperand {
                            attempt: *attempt,
                            parameter: *parameter,
                            value,
                        });
                    self.inventory
                        .push_instruction(AwbcInstruction::ExitScope { scope });
                    frame.exit_scope();
                }
                self.active_format_attempts.pop();
                frame.restore_scopes_after_branch(outer_scopes);
            }
            FlowOp::ExitScopeBind { pattern, expr } => {
                let scoped_value =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(expr);
                let ty = admitted_plan_type(self.inventory, self.plan, expr.ty());
                let value = frame.emitted_scope_parent_temp(ty);
                self.inventory.push_instruction(AwbcInstruction::Move {
                    dst: value,
                    src: scoped_value,
                });
                let exit = frame
                    .emitted_scope_exit()
                    .expect("admitted result exits its emitted lexical scope");
                for scope in exit.targets() {
                    self.inventory
                        .push_instruction(AwbcInstruction::ExitScope { scope: *scope });
                    frame.exit_scope()
                }
                let pattern = lower_pattern(self.inventory, self.plan, frame, pattern);
                self.inventory
                    .push_instruction(AwbcInstruction::BindPattern {
                        pattern,
                        value,
                        mode: AwbcBindMode::Declare,
                    });
            }
            FlowOp::LetElse {
                pattern,
                expr,
                else_ops,
            } => {
                self.lower_let_else(frame, body, pattern, expr, else_ops, path);
            }
            FlowOp::Assign { place, value } => {
                AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                    .lower_assignment(place, value);
            }
            FlowOp::LineOperation { binding, operation } => {
                self.lower_line_operation(frame, binding.as_ref(), operation, path);
            }
            FlowOp::CommitDialogueResult { value } => {
                let source =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(value);
                self.inventory
                    .push_instruction(AwbcInstruction::CommitDialogueResult { source });
            }
            FlowOp::SelectDialogueResult { value } => {
                let Some((result_type, result_type_awbc)) = self.line_result_selector else {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        "dialogue result selection is outside a line-task action or cancellation handler",
                    ));
                    return;
                };
                if value.ty() != result_type {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        "dialogue result selection type disagrees with its line task group",
                    ));
                    return;
                }
                let source =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(value);
                let selected = frame.root_temp(result_type_awbc);
                self.inventory.push_instruction(AwbcInstruction::Move {
                    dst: selected,
                    src: source,
                });
                self.emit_format_attempt_abandons(0);
                self.close_active_scopes_for_terminator(frame);
                body.terminate(
                    self.inventory,
                    AwbcTerminator::SelectDialogueResult { value: selected },
                    AwbcSafePointKind::None,
                );
            }
            FlowOp::Dialogue {
                target,
                content,
                result,
            } => {
                let Some(content_plan) = self.plan.dialogue_content().get(*content) else {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        format!("dialogue content plan {content} is absent from the RuntimePlan"),
                    ));
                    return;
                };
                if let Some(missing) = content_plan
                    .values()
                    .iter()
                    .map(|site| site.function())
                    .find(|function| self.plan.function_sites().get(*function).is_none())
                {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        format!(
                            "dialogue value function site {missing} is absent from the RuntimePlan"
                        ),
                    ));
                    return;
                }
                if let Some(missing) = content_plan
                    .effect_sites()
                    .iter()
                    .map(|site| site.state())
                    .find(|state| self.plan.callable_states().get(*state).is_none())
                {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        format!(
                            "dialogue effect callback state {missing} is absent from the RuntimePlan"
                        ),
                    ));
                    return;
                }
                let (content, group_captures) = match AwbcLineLowerer::new(self.inventory)
                    .content_for_line(content_plan, self.plan)
                {
                    Ok(content) => content,
                    Err(error) => {
                        self.inventory.diagnostic(error);
                        return;
                    }
                };
                let result_ty = admitted_plan_type(self.inventory, self.plan, result.ty());
                let result_target = AwbcDialogueResultTarget {
                    ty: result_ty,
                    pattern: lower_pattern(self.inventory, self.plan, frame, result.pattern()),
                    destination: frame.root_temp(result_ty),
                };
                let target = AwbcExprLowerer::new(
                    self.inventory,
                    frame,
                    format!("{path}.dialogue.target"),
                    self.plan,
                )
                .lower(target);
                let mut values_by_function = BTreeMap::new();
                let mut values = Vec::with_capacity(content_plan.values().len());
                for site in content_plan.values() {
                    let function = site.function();
                    let value = if let Some(value) = values_by_function.get(&function) {
                        *value
                    } else if let Some(function_site) = self.plan.function_sites().get(function) {
                        let result_type =
                            admitted_plan_type(self.inventory, self.plan, function_site.result());
                        let Some(callback) = self.prepare_function_site(function, path) else {
                            return;
                        };
                        let args = site
                            .captures()
                            .iter()
                            .map(|capture| {
                                AwbcExprLowerer::new(
                                    self.inventory,
                                    frame,
                                    format!("{path}.dialogue.{function}.capture"),
                                    self.plan,
                                )
                                .lower(capture)
                            })
                            .collect();
                        let value = frame.root_temp(result_type);
                        body.suspend(
                            self.inventory,
                            AwbcSafePointKind::CallableBoundary,
                            |resume| AwbcTerminator::CallFunction {
                                function: callback,
                                args,
                                dst: Some(value),
                                resume,
                            },
                        );
                        values_by_function.insert(function, value);
                        value
                    } else {
                        unreachable!("dialogue value sites were preflighted above");
                    };
                    values.push(AwbcDialogueValueBinding {
                        slot: site.slot(),
                        role: awbc_dialogue_value_role(site.role()),
                        value,
                    });
                }
                let mut effects = Vec::with_capacity(content_plan.effect_sites().len());
                for site in content_plan.effect_sites() {
                    let mut lowerer = AwbcExprLowerer::new(
                        self.inventory,
                        frame,
                        format!("{path}.dialogue.effect.{}", site.site()),
                        self.plan,
                    );
                    let state = site.state();
                    let captures = site
                        .captures()
                        .iter()
                        .map(|capture| lowerer.lower(capture))
                        .collect();
                    effects.push(AwbcDialogueContentEffectBinding {
                        site: site.site(),
                        state,
                        captures,
                    });
                }
                let line_task_captures = group_captures
                    .iter()
                    .map(|input| {
                        frame
                            .register_for_local(input.local())
                            .expect("the admitted Line input has its actual caller slot")
                    })
                    .collect();
                body.suspend(self.inventory, AwbcSafePointKind::Dialogue, |resume| {
                    AwbcTerminator::Dialogue {
                        target,
                        content,
                        values,
                        effects,
                        line_task_captures,
                        result: result_target,
                        resume,
                    }
                });
            }
            FlowOp::Choice { id, options } => {
                let choice = self.lower_choice(id.as_deref(), options, path);
                let dst = frame.temp(self.inventory.string_ty());
                body.suspend(self.inventory, AwbcSafePointKind::Choice, |resume| {
                    AwbcTerminator::Choice {
                        choice,
                        dst,
                        resume,
                    }
                });
            }
            FlowOp::Await {
                binding,
                target,
                observers,
            } => {
                let handle = AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                    .lower(target.source());
                let binding = binding
                    .as_ref()
                    .map(|binding| lower_pattern(self.inventory, self.plan, frame, binding));
                if observers.is_empty() {
                    body.suspend(self.inventory, AwbcSafePointKind::Await, |resume| {
                        AwbcTerminator::Await {
                            handle,
                            binding,
                            observer: None,
                            resume,
                        }
                    });
                } else {
                    self.lower_await_observers(frame, body, handle, binding, observers, path);
                }
            }
            FlowOp::StartNeedProducer { binding, target } => {
                let Some(plan) = self.inventory.intern_need_producer_task(self.plan, target) else {
                    return;
                };
                let arguments = target
                    .arguments()
                    .iter()
                    .map(|argument| {
                        AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                            .lower(argument.value())
                    })
                    .collect::<Vec<_>>();
                let Some(destination_type) = self.inventory.plan_type(binding.ty()) else {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        "need_producer.binding",
                        "Need producer binding type was not admitted by AWBC type preflight",
                    ));
                    return;
                };
                let destination = match binding.kind() {
                    RuntimePatternKind::Bind { binding, .. }
                    | RuntimePatternKind::Typed { binding } => {
                        frame.local(binding.local(), destination_type)
                    }
                    _ => {
                        self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                            "need_producer.binding",
                            "Need producer result must bind one Need<T> local",
                        ));
                        return;
                    }
                };
                let item_type = self.inventory.semantic_type(target.plan().payload_type());
                if !self
                    .inventory
                    .program
                    .runtime_types
                    .get(destination_type.index())
                    .is_some_and(|runtime_type| {
                        matches!(
                            runtime_type.shape(),
                            AwbcRuntimeTypeShape::Need(item) if Some(*item) == item_type
                        )
                    })
                {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        "need_producer.binding",
                        "Need producer binding must have the exact selected Need<T> type",
                    ));
                    return;
                }
                self.inventory.push_instruction(AwbcInstruction::StartNeed {
                    dst: destination,
                    plan,
                    args: arguments,
                });
            }
            FlowOp::AwaitMany {
                binding,
                target,
                pending,
            } => {
                self.lower_pending_effects(pending);
                let source = AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                    .lower(&target.source);
                let item_binding =
                    frame.local(target.item_binding, self.local_type(target.item_binding));
                let captures = target
                    .captures()
                    .map(|local| frame.local(local, self.local_type(local)))
                    .collect();
                let Some(task) = self.inventory.intern_await_many_task(
                    self.plan,
                    target,
                    captures,
                    item_binding,
                ) else {
                    return;
                };
                let binding = binding
                    .as_ref()
                    .map(|binding| lower_pattern(self.inventory, self.plan, frame, binding));
                body.suspend(self.inventory, AwbcSafePointKind::AwaitMany, |resume| {
                    AwbcTerminator::AwaitMany {
                        plan: task,
                        source,
                        binding,
                        resume,
                    }
                });
            }
            FlowOp::HostCall { binding, target } => {
                let Some((call, result_type)) = self.inventory.intern_host_call(self.plan, target)
                else {
                    return;
                };
                let args = target
                    .args
                    .iter()
                    .map(|arg| {
                        AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                            .lower(arg.value())
                    })
                    .collect::<Vec<_>>();
                // Host calls always have a value result in the admitted runtime
                // signature. Keep that result shape even when the source flow
                // deliberately discards the value; only the pattern binding is
                // optional.
                let dst = frame.temp(result_type);
                let pattern = binding
                    .as_ref()
                    .map(|binding| lower_pattern(self.inventory, self.plan, frame, binding));
                body.suspend(self.inventory, AwbcSafePointKind::HostCall, |resume| {
                    AwbcTerminator::HostCall {
                        call,
                        args,
                        dst: Some(dst),
                        resume,
                    }
                });
                if let Some(pattern) = pattern {
                    self.inventory
                        .push_instruction(AwbcInstruction::BindPattern {
                            pattern,
                            value: dst,
                            mode: AwbcBindMode::Declare,
                        });
                }
            }
            FlowOp::ApplyGroup {
                callee,
                args,
                result,
            } => {
                let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                    .lower_function_application(callee, args, result.ty());
                let pattern = lower_pattern(self.inventory, self.plan, frame, result);
                self.inventory
                    .push_instruction(AwbcInstruction::BindPattern {
                        pattern,
                        value,
                        mode: AwbcBindMode::Declare,
                    });
            }
            FlowOp::ProjectCall { site } => {
                let Some(site) = self.plan.project_call_sites().get(*site) else {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        format!(
                            "runtime ProjectCall site {site} is absent from the RuntimePlan catalog"
                        ),
                    ));
                    return;
                };
                self.lower_project_call(frame, body, site.plan(), site.result(), path);
            }
            FlowOp::If {
                condition,
                then_ops,
                else_ops,
            } => {
                self.lower_if(frame, body, condition, then_ops, else_ops, path);
            }
            FlowOp::IfLet {
                pattern,
                expr,
                guard,
                then_ops,
                else_ops,
            } => {
                self.lower_if_let(
                    frame,
                    body,
                    pattern,
                    expr,
                    guard.as_ref(),
                    then_ops,
                    else_ops,
                    path,
                );
            }
            FlowOp::Match { scrutinee, arms } => {
                self.lower_match(frame, body, scrutinee, arms, path);
            }
            FlowOp::Loop { result, body: ops } => {
                self.lower_loop(frame, body, result.as_ref(), ops, path);
            }
            FlowOp::ProgramTask {
                template:
                    arcweft_core::plan::RuntimeProgramTaskTemplate {
                        producer, captures, ..
                    },
                binding,
                ..
            } => {
                if let Some(plan) =
                    self.inventory
                        .intern_program_task(self.plan, &producer.plan, path)
                {
                    let args = captures
                        .iter()
                        .map(|capture| {
                            frame
                                .register_for_local(capture.local)
                                .expect("checked Program capture is bound in its enclosing frame")
                        })
                        .collect();
                    let ty = admitted_plan_type(self.inventory, self.plan, binding.ty());
                    let dst = frame.temp(ty);
                    let pattern = lower_pattern(self.inventory, self.plan, frame, binding);
                    self.inventory
                        .push_instruction(AwbcInstruction::StartProgram { dst, plan, args });
                    self.inventory
                        .push_instruction(AwbcInstruction::BindPattern {
                            pattern,
                            value: dst,
                            mode: AwbcBindMode::Declare,
                        });
                }
            }
            FlowOp::While {
                condition,
                body: ops,
            } => {
                self.lower_while(frame, body, condition, ops, path);
            }
            FlowOp::WhileLet {
                pattern,
                expr,
                guard,
                body: ops,
            } => self.lower_while_let(
                frame,
                body,
                &WhileLetLoweringInput {
                    pattern,
                    expr,
                    guard: guard.as_ref(),
                    ops,
                    path,
                },
            ),
            FlowOp::For {
                pattern,
                source,
                evidence,
                body: ops,
            } => {
                self.lower_for(
                    frame,
                    body,
                    ForLoweringInput {
                        pattern,
                        source,
                        evidence,
                        ops,
                        path,
                    },
                );
            }
            FlowOp::Scope {
                identity,
                body: ops,
            } => {
                let outer_scopes = frame.scope_checkpoint();
                let scope = frame.enter_scope_with_identity(identity.clone());
                self.inventory
                    .push_instruction(AwbcInstruction::EnterScope { scope });
                self.lower_ops(frame, body, ops, &format!("{path}.scope"));
                if !body.terminated && frame.contains_scope(scope) {
                    self.inventory
                        .push_instruction(AwbcInstruction::ExitScope { scope });
                    frame.exit_scope();
                }
                if body.terminated {
                    frame.restore_scopes_after_branch(outer_scopes);
                }
            }
            FlowOp::Break { depth, value } => {
                self.lower_break(frame, body, *depth, value.as_ref(), path);
            }
            FlowOp::ReturnExpr(value) => {
                if self.cancellation_handler_result.is_some() {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        "flow return inside a cancellation handler has no parent control-transfer projection",
                    ));
                    return;
                }
                self.emit_format_attempt_abandons(0);
                let value =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(value);
                let result = frame.return_value(self.inventory.dynamic_ty());
                self.inventory.push_instruction(AwbcInstruction::Move {
                    dst: result,
                    src: value,
                });
                self.close_active_scopes_for_terminator(frame);
                body.terminate(
                    self.inventory,
                    AwbcTerminator::Return {
                        value: Some(result),
                    },
                    AwbcSafePointKind::Return,
                );
            }
            FlowOp::Continue { depth } => {
                self.lower_continue(frame, body, *depth, path);
            }
            FlowOp::Goto(transfer) => {
                let order = transfer
                    .input_order()
                    .expect("the sealed Plan admits the complete original Flow input permutation");
                let stable_target = match &transfer.target {
                    arcweft_core::plan::RuntimeFlowTransferTarget::Static(_) => None,
                    arcweft_core::plan::RuntimeFlowTransferTarget::Dynamic(expr) => {
                        for flow in self.plan.flows() {
                            let _ = self.prepare_flow_target(&flow.id, path);
                        }
                        let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                            .lower(expr);
                        let target = frame.root_temp(self.inventory.dynamic_ty());
                        self.inventory.push_instruction(AwbcInstruction::Move {
                            dst: target,
                            src: value,
                        });
                        Some(target)
                    }
                };
                let mut arguments = vec![None; order.slots().len()];
                for argument in &transfer.arguments {
                    let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                        .lower(&argument.value);
                    let ty = admitted_plan_type(self.inventory, self.plan, argument.value.ty());
                    let retained = frame.root_temp(ty);
                    self.inventory.push_instruction(AwbcInstruction::Move {
                        dst: retained,
                        src: value,
                    });
                    arguments[argument.parameter.position() as usize] = Some(retained);
                }
                let arguments = arguments
                    .into_iter()
                    .map(|argument| {
                        argument.expect("the admitted transfer order covers every formal parameter")
                    })
                    .collect();
                self.emit_format_attempt_abandons(0);
                let terminator = match &transfer.target {
                    arcweft_core::plan::RuntimeFlowTransferTarget::Static(target) => {
                        let function = self.prepare_flow_target(target, path).expect(
                            "the sealed static Flow retains its original executable function site",
                        );
                        AwbcTerminator::GotoStatic {
                            function,
                            args: arguments,
                        }
                    }
                    arcweft_core::plan::RuntimeFlowTransferTarget::Dynamic(_) => {
                        AwbcTerminator::GotoDynamic {
                            target: stable_target
                                .expect("dynamic target is retained before operands"),
                            args: arguments,
                        }
                    }
                };
                // The terminator admits the receiver before it starts
                // the source scopes' successful exit.
                frame.exit_all_scopes();
                body.terminate(
                    self.inventory,
                    terminator,
                    AwbcSafePointKind::CallableBoundary,
                );
            }
            FlowOp::Return(value) => {
                if self.cancellation_handler_result.is_some() {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        "flow return inside a cancellation handler has no parent control-transfer projection",
                    ));
                    return;
                }
                self.emit_format_attempt_abandons(0);
                let value = self.inventory.constant_string(value);
                let dst = frame.return_value(self.inventory.string_ty());
                self.inventory.push_instruction(AwbcInstruction::LoadConst {
                    dst,
                    constant: value,
                });
                self.close_active_scopes_for_terminator(frame);
                body.terminate(
                    self.inventory,
                    AwbcTerminator::Return { value: Some(dst) },
                    AwbcSafePointKind::Return,
                );
            }
            FlowOp::Effect(effect) => {
                let (effect, args) = self.lower_effect_plan(frame, path, effect);
                self.inventory
                    .push_instruction(AwbcInstruction::EmitEffect { effect, args });
            }
            FlowOp::EvaluatedEffect(RuntimeEffectExpr::Drop { target, policy }) => {
                let register =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(target);
                let policy = match policy {
                    RuntimeDropPolicyExpr::Default => AwbcDropPolicy::Default,
                    RuntimeDropPolicyExpr::Cancel => AwbcDropPolicy::Cancel,
                    RuntimeDropPolicyExpr::Stop { fade } => AwbcDropPolicy::Stop {
                        fade: AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                            .lower(fade),
                    },
                    RuntimeDropPolicyExpr::Finish => AwbcDropPolicy::Finish,
                    RuntimeDropPolicyExpr::Release => AwbcDropPolicy::Release,
                    RuntimeDropPolicyExpr::Detach => AwbcDropPolicy::Detach,
                };
                self.inventory
                    .push_instruction(AwbcInstruction::Drop { register, policy });
            }
            FlowOp::EvaluatedEffect(effect) => {
                let args = effect
                    .argument_exprs()
                    .into_iter()
                    .map(|expr| {
                        AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(expr)
                    })
                    .collect();
                let empty_effects = RuntimeEffectSet::empty();
                let declared_effects = self.active_effect_set.as_ref().unwrap_or(&empty_effects);
                let Some(effect) = self
                    .inventory
                    .intern_evaluated_effect(effect, declared_effects)
                else {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        "evaluated effect has no host descriptor",
                    ));
                    return;
                };
                self.inventory
                    .push_instruction(AwbcInstruction::EmitEffect { effect, args });
            }
            FlowOp::RegisterCleanup { key, effect } => {
                let key = self.inventory.intern_string(key);
                let (effect, args) = self.lower_effect_plan(frame, path, effect);
                self.inventory
                    .push_instruction(AwbcInstruction::RegisterCleanup { key, effect, args });
            }
            FlowOp::RegisterDefer {
                site,
                outcome,
                captures,
                owner,
            } => {
                let captures = captures
                    .iter()
                    .map(|capture| {
                        AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(capture)
                    })
                    .collect();
                self.inventory
                    .push_instruction(AwbcInstruction::RegisterDefer {
                        site: *site,
                        outcome: *outcome,
                        owner: match owner {
                            RuntimeDeferOwner::CurrentScope => {
                                arcweft_core::awbc::schema::AwbcDeferOwner::CurrentScope
                            }
                            RuntimeDeferOwner::LineRoot => {
                                arcweft_core::awbc::schema::AwbcDeferOwner::LineRoot
                            }
                        },
                        captures,
                    });
            }
            FlowOp::CancelCleanup { key } => {
                let key = self.inventory.intern_string(key);
                self.inventory
                    .push_instruction(AwbcInstruction::CancelCleanup { key });
            }
            FlowOp::EnterScope { identity } => {
                let scope = frame.enter_scope_with_identity(identity.clone());
                self.inventory
                    .push_instruction(AwbcInstruction::EnterScope { scope });
            }
            FlowOp::ExitScope => {
                let exit = frame
                    .emitted_scope_exit()
                    .expect("admitted exit has an emitted lexical scope");
                for scope in exit.targets() {
                    self.inventory
                        .push_instruction(AwbcInstruction::ExitScope { scope: *scope });
                    frame.exit_scope()
                }
            }
            FlowOp::Noop => {
                self.inventory.push_instruction(AwbcInstruction::Nop);
            }
        }
    }

    fn lower_project_call(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        plan: &RuntimeProjectCallPlan,
        result: &RuntimePattern,
        path: &str,
    ) {
        // The callee expression is evaluated before the source-ordered
        // operands. The program-owned state authenticates the closed origin.
        let callee =
            AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(plan.callee());
        let operands = plan
            .operands()
            .iter()
            .map(|operand| {
                let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                    .lower(operand.value());
                let mode = match operand.mode() {
                    arcweft_core::value::RuntimeCallArgumentMode::Value => {
                        AwbcProjectCallOperandMode::Value
                    }
                    arcweft_core::value::RuntimeCallArgumentMode::Spread => {
                        AwbcProjectCallOperandMode::Spread
                    }
                };
                AwbcProjectCallOperand { value, mode }
            })
            .collect();
        let ordinary = plan
            .ordinary()
            .iter()
            .map(|row| match row {
                RuntimeProjectCallOrdinaryMaterializationCore::Fixed(row) => {
                    AwbcProjectCallOrdinaryMaterialization::Fixed {
                        parameter: row.parameter(),
                        source_index: row.source_index(),
                    }
                }
                RuntimeProjectCallOrdinaryMaterializationCore::Rest(row) => {
                    AwbcProjectCallOrdinaryMaterialization::Rest {
                        parameter: row.parameter(),
                        source_indices: row.source_indices().to_vec(),
                    }
                }
            })
            .collect();
        let attached = match plan.attached() {
            None => None,
            Some(row) => {
                let presence = match row.presence() {
                    RuntimeProjectCallAttachedPresenceCore::RequiredPresent => {
                        AwbcProjectCallAttachedPresence::RequiredPresent
                    }
                    RuntimeProjectCallAttachedPresenceCore::OptionalPresent => {
                        AwbcProjectCallAttachedPresence::OptionalPresent
                    }
                    RuntimeProjectCallAttachedPresenceCore::OptionalOmitted => {
                        AwbcProjectCallAttachedPresence::OptionalOmitted
                    }
                    RuntimeProjectCallAttachedPresenceCore::DefaultedPresent => {
                        AwbcProjectCallAttachedPresence::DefaultedPresent
                    }
                    RuntimeProjectCallAttachedPresenceCore::DefaultedOmitted => {
                        AwbcProjectCallAttachedPresence::DefaultedOmitted
                    }
                };
                Some(AwbcProjectCallAttachedMaterialization {
                    source_index: row.source_index(),
                    presence,
                })
            }
        };
        let result_pattern = lower_pattern(self.inventory, self.plan, frame, result);
        body.suspend(
            self.inventory,
            AwbcSafePointKind::CallableBoundary,
            |resume| AwbcTerminator::ProjectCall {
                call: AwbcProjectCall {
                    binding: plan.binding(),
                    callee,
                    state: plan.state(),
                    completed_group: plan.completed_group(),
                    operands,
                    ordinary,
                    attached,
                    result_pattern,
                    resume,
                },
            },
        );
    }

    /// Reserves the original target before its caller is emitted. The ordinary
    /// function-site queue lowers its body once, including any further Flow
    /// transfers discovered inside calls, closures, or line-task functions.
    fn prepare_flow_target(
        &mut self,
        target: &FlowRuntimeId,
        path: &str,
    ) -> Option<AwbcFunctionId> {
        if let Some(function) = self.inventory.flow_function(target) {
            return Some(function);
        }
        let flow = self.plan.flows().iter().find(|flow| &flow.id == target)?;
        let function = self.prepare_function_site(flow.function_site(), path)?;
        self.inventory.bind_flow_function(target, function);
        Some(function)
    }

    fn prepare_function_site(
        &mut self,
        site: arcweft_core::runtime_id::RuntimeFunctionSiteId,
        path: &str,
    ) -> Option<AwbcFunctionId> {
        let Some(declaration) = self.plan.function_sites().get(site) else {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                path,
                format!("runtime function site {site} is absent from the RuntimePlan"),
            ));
            return None;
        };
        let already_reserved = self.inventory.function_site_function(site).is_some();
        let function = self
            .inventory
            .reserve_function_site_slot(site, declaration.definition());
        if !already_reserved {
            self.inventory
                .push_pending_closure(PendingAwbcClosure::FunctionSite {
                    site,
                    function,
                    path: format!("{path}.function.{site}"),
                });
        }
        Some(function)
    }

    fn lower_line_operation(
        &mut self,
        frame: &mut FrameBuilder,
        binding: Option<&RuntimePattern>,
        operation: &RuntimeLineOperation,
        path: &str,
    ) {
        let Some(context) = self.line_group.clone() else {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                path,
                "typed line operation is outside a sealed line-task group",
            ));
            return;
        };
        let Some(site) = context.group.handle_site(operation.site()).cloned() else {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                path,
                "typed line operation references an absent handle site",
            ));
            return;
        };
        let site_id = AwbcLineHandleSiteId(site.id().get());
        let result_type = admitted_plan_type(self.inventory, self.plan, site.result_type());
        let dst = frame.temp(result_type);
        let (operation_record, args) = match operation {
            RuntimeLineOperation::AcquireActor {
                character, scope, ..
            } => (
                AwbcLineOperation::AcquireActor {
                    group: context.id,
                    site: site_id,
                    character: character.clone(),
                    scope: *scope,
                    result_type,
                },
                Vec::new(),
            ),
            RuntimeLineOperation::Schedule {
                delay,
                child,
                captures,
                ..
            } => {
                let Some(child) = context.node_ids.get(child.index()).copied() else {
                    self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                        path,
                        "schedule operation references a node outside its sealed group",
                    ));
                    return;
                };
                let mut args = Vec::with_capacity(captures.len() + 1);
                args.push(
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(delay),
                );
                let mut capture_schema = Vec::with_capacity(captures.len());
                for capture in captures {
                    capture_schema.push(arcweft_core::awbc::schema::AwbcLineScheduledCapture {
                        local: capture.local(),
                        ty: admitted_plan_type(self.inventory, self.plan, capture.value().ty()),
                    });
                    args.push(
                        AwbcExprLowerer::new(self.inventory, frame, path, self.plan)
                            .lower(capture.value()),
                    );
                }
                (
                    AwbcLineOperation::Schedule {
                        group: context.id,
                        site: site_id,
                        child,
                        captures: capture_schema,
                        result_type,
                    },
                    args,
                )
            }
            RuntimeLineOperation::ActorLook {
                character,
                actor,
                look,
                crossfade,
                ..
            } => {
                let actor_type = self.local_type(actor.local());
                let look_type = admitted_plan_type(self.inventory, self.plan, look.ty());
                let actor_register = frame.register_for_local(actor.local()).unwrap_or_else(|| {
                    panic!(
                        "admitted actor.look borrowed local `{}` is outside the AWBC frame at {path}",
                        actor.local()
                    )
                });
                let args = vec![
                    actor_register,
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(look),
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(crossfade),
                ];
                (
                    AwbcLineOperation::ActorLook {
                        group: context.id,
                        site: site_id,
                        character: character.clone(),
                        actor_type,
                        look_type,
                        result_type,
                    },
                    args,
                )
            }
            RuntimeLineOperation::VoiceHandle { .. } => (
                AwbcLineOperation::VoiceHandle {
                    group: context.id,
                    site: site_id,
                    result_type,
                },
                Vec::new(),
            ),
        };
        let operation =
            AwbcLineOperationId(table_index(self.inventory.program.line_operations.len()));
        self.inventory
            .program
            .line_operations
            .push(operation_record);
        self.inventory
            .push_instruction(AwbcInstruction::ExecuteLineOperation {
                dst,
                operation,
                args,
            });
        if let Some(binding) = binding {
            let pattern = lower_pattern(self.inventory, self.plan, frame, binding);
            self.inventory
                .push_instruction(AwbcInstruction::BindPattern {
                    pattern,
                    value: dst,
                    mode: AwbcBindMode::Declare,
                });
        } else {
            self.inventory.push_instruction(AwbcInstruction::Drop {
                register: dst,
                policy: AwbcDropPolicy::Default,
            });
        }
    }

    fn lower_await_observers(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        handle: AwbcRegisterId,
        binding: Option<AwbcPatternId>,
        observers: &[arcweft_core::plan::RuntimeAwaitPendingObserver],
        path: &str,
    ) {
        let progress_ty = self.inventory.intern_type(AwbcRuntimeTypeShape::Progress);
        let progress = frame.temp(progress_ty);
        let await_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: await_block,
            },
            AwbcSafePointKind::None,
        );
        let dispatcher_block = AwbcBlockId(await_block.0.saturating_add(1));
        let ready = self.inventory.push_resume_point(AwbcResumePoint {
            function: body.owner,
            block: AwbcBlockId::default(),
            frame_layout: AwbcFrameLayoutId::default(),
            kind: AwbcSafePointKind::Await,
        });
        let observer_resume = self.inventory.push_resume_point(AwbcResumePoint {
            function: body.owner,
            block: dispatcher_block,
            frame_layout: AwbcFrameLayoutId::default(),
            kind: AwbcSafePointKind::Await,
        });
        body.resume_points.extend([ready, observer_resume]);
        body.close_block(
            self.inventory,
            AwbcTerminator::Await {
                handle,
                binding,
                observer: Some(AwbcAwaitObserverResume {
                    destination: progress,
                    resume: observer_resume,
                }),
                resume: ready,
            },
            AwbcSafePointKind::LoopBackedge,
        );

        let mut rewait = Vec::with_capacity(observers.len().saturating_add(1));
        for (index, observer) in observers.iter().enumerate() {
            let pattern = self.lower_branch_pattern(frame, &observer.pattern);
            let matched = frame.temp(self.inventory.bool_ty());
            self.inventory
                .push_instruction(AwbcInstruction::TestPattern {
                    dst: matched,
                    pattern,
                    value: progress,
                });
            let candidate_block = AwbcBlockId(table_index(
                self.inventory.program.blocks.len().saturating_add(1),
            ));
            let branch_block = body.close_block(
                self.inventory,
                AwbcTerminator::Branch {
                    condition: matched,
                    then_block: candidate_block,
                    else_block: candidate_block,
                },
                AwbcSafePointKind::None,
            );
            let _ = self.lower_scoped_branch_ops(
                frame,
                body,
                Some((pattern, progress)),
                &observer.ops,
                &format!("{path}.pending.{index}"),
            );
            let next_observer = if body.terminated {
                body.reopen_after_terminated_branch(self.inventory)
            } else {
                rewait.push(self.close_jump_to_join(body));
                AwbcBlockId(table_index(self.inventory.program.blocks.len()))
            };
            patch_branch_else_block(self.inventory, branch_block, next_observer);
        }
        rewait.push(body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: await_block,
            },
            AwbcSafePointKind::None,
        ));
        for block in rewait {
            patch_jump_target(self.inventory, block, await_block);
        }
        let ready_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
        patch_resume_block(self.inventory, ready, ready_block);
    }

    fn lower_effect_plan(
        &mut self,
        frame: &mut FrameBuilder,
        path: &str,
        effect: &LineEffectRequest,
    ) -> (AwbcEffectPlanId, Vec<AwbcRegisterId>) {
        match effect {
            LineEffectRequest::Audio(command) => {
                let (command, args) =
                    AwbcAudioLowerer::new(self.inventory, frame, path, self.plan).lower(command);
                let effect = self.inventory.intern_audio_effect(command, args.len());
                (effect, args)
            }
            _ => (self.inventory.intern_effect(effect), Vec::new()),
        }
    }

    fn lower_pending_effects(&mut self, pending: &[arcweft_core::effect::LineEffectRequest]) {
        for effect in pending {
            let effect = self.inventory.intern_effect(effect);
            self.inventory
                .push_instruction(AwbcInstruction::EmitEffect {
                    effect,
                    args: Vec::new(),
                });
        }
    }

    fn lower_choice(
        &mut self,
        id: Option<&str>,
        options: &[ChoiceRuntimeOption],
        path: &str,
    ) -> AwbcChoiceId {
        let public_id = id.map(|id| self.inventory.intern_string(id));
        let lowered = options
            .iter()
            .map(|option| AwbcChoiceOption {
                public_id: option
                    .id
                    .as_ref()
                    .map(|id| self.inventory.intern_string(id)),
                label: self.inventory.intern_string(&option.label),
                condition: None,
                target: option
                    .target
                    .as_ref()
                    .and_then(|target| self.prepare_flow_target(target, path)),
                out_effect: option.out.as_ref().map(|out| {
                    self.inventory
                        .intern_effect(&arcweft_core::effect::LineEffectRequest::Out(out.clone()))
                }),
                effects: option
                    .effects
                    .iter()
                    .map(|effect| self.inventory.intern_effect(effect))
                    .collect(),
            })
            .collect::<Vec<_>>();
        self.inventory
            .intern_choice(format!("choice:{id:?}:{options:?}"), public_id, lowered)
    }

    fn lower_let_else(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        pattern: &RuntimePattern,
        expr: &RuntimeExpr,
        else_ops: &[FlowOp],
        path: &str,
    ) {
        let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(expr);
        let pattern = lower_pattern(self.inventory, self.plan, frame, pattern);
        let matched = frame.temp(self.inventory.bool_ty());
        self.inventory
            .push_instruction(AwbcInstruction::TestPattern {
                dst: matched,
                pattern,
                value,
            });

        let matched_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        let branch_block = body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition: matched,
                then_block: matched_block,
                else_block: matched_block,
            },
            AwbcSafePointKind::None,
        );

        self.inventory
            .push_instruction(AwbcInstruction::BindPattern {
                pattern,
                value,
                mode: AwbcBindMode::Declare,
            });
        let mut join = BranchJoin::new();
        join.push(self.close_jump_to_join(body), frame.scope_checkpoint());

        let else_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
        patch_branch_else_block(self.inventory, branch_block, else_block);
        self.lower_ops(frame, body, else_ops, &format!("{path}.else"));
        if !body.terminated {
            join.push(self.close_jump_to_join(body), frame.scope_checkpoint());
        }
        self.finish_join(frame, body, join);
    }

    fn lower_if(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        condition: &RuntimeExpr,
        then_ops: &[FlowOp],
        else_ops: &[FlowOp],
        path: &str,
    ) {
        let condition =
            AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(condition);
        let then_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        let branch_block = body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition,
                then_block,
                else_block: then_block,
            },
            AwbcSafePointKind::None,
        );

        let mut join = BranchJoin::new();
        let then_scopes =
            self.lower_scoped_branch_ops(frame, body, None, then_ops, &format!("{path}.then"));
        if body.terminated {
            let else_block = body.reopen_after_terminated_branch(self.inventory);
            patch_branch_else_block(self.inventory, branch_block, else_block);
        } else {
            join.push(
                self.close_jump_to_join(body),
                then_scopes.expect("a continuing arm retains its actual lexical scope stack"),
            );
            let else_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
            patch_branch_else_block(self.inventory, branch_block, else_block);
        }

        let else_scopes =
            self.lower_scoped_branch_ops(frame, body, None, else_ops, &format!("{path}.else"));
        if !body.terminated {
            join.push(
                self.close_jump_to_join(body),
                else_scopes.expect("a continuing arm retains its actual lexical scope stack"),
            );
        }
        self.finish_join(frame, body, join);
    }

    #[allow(clippy::too_many_arguments)]
    fn lower_if_let(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        pattern: &RuntimePattern,
        expr: &RuntimeExpr,
        guard: Option<&RuntimeExpr>,
        then_ops: &[FlowOp],
        else_ops: &[FlowOp],
        path: &str,
    ) {
        let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(expr);
        let pattern = self.lower_branch_pattern(frame, pattern);
        let matched = frame.temp(self.inventory.bool_ty());
        self.inventory
            .push_instruction(AwbcInstruction::TestPattern {
                dst: matched,
                pattern,
                value,
            });
        let candidate_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        let branch_block = body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition: matched,
                then_block: candidate_block,
                else_block: candidate_block,
            },
            AwbcSafePointKind::None,
        );

        let mut join = BranchJoin::new();
        if let Some(guard) = guard {
            let guarded = self.lower_guarded_candidate(
                frame,
                body,
                pattern,
                value,
                Some(guard),
                guard.guard_copy_locals(),
                &[],
                then_ops,
                path,
            );
            if let Some((fallthrough, scopes)) = guarded.fallthrough {
                join.push(fallthrough, scopes);
            }
            let else_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
            patch_branch_else_block(self.inventory, branch_block, else_block);
            if let Some(jump) = guarded.guard_false_jump {
                patch_jump_target(self.inventory, jump, else_block);
            }
        } else {
            let then_scopes = self.lower_scoped_branch_ops(
                frame,
                body,
                Some((pattern, value)),
                then_ops,
                &format!("{path}.then"),
            );
            if body.terminated {
                let else_block = body.reopen_after_terminated_branch(self.inventory);
                patch_branch_else_block(self.inventory, branch_block, else_block);
            } else {
                join.push(
                    self.close_jump_to_join(body),
                    then_scopes
                        .expect("a continuing pattern arm retains its actual lexical scope stack"),
                );
                let else_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
                patch_branch_else_block(self.inventory, branch_block, else_block);
            }
        }

        let else_scopes =
            self.lower_scoped_branch_ops(frame, body, None, else_ops, &format!("{path}.else"));
        if !body.terminated {
            join.push(
                self.close_jump_to_join(body),
                else_scopes.expect("a continuing arm retains its actual lexical scope stack"),
            );
        }
        self.finish_join(frame, body, join);
    }

    fn lower_match(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        scrutinee: &arcweft_core::value::RuntimeExpr,
        arms: &[RuntimeMatchArm],
        path: &str,
    ) {
        let scrutinee =
            AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(scrutinee);
        let mut join = BranchJoin::new();
        for (index, arm) in arms.iter().enumerate() {
            let pattern = self.lower_branch_pattern(frame, &arm.pattern);
            let matched = frame.temp(self.inventory.bool_ty());
            self.inventory
                .push_instruction(AwbcInstruction::TestPattern {
                    dst: matched,
                    pattern,
                    value: scrutinee,
                });
            let candidate_block = AwbcBlockId(table_index(
                self.inventory.program.blocks.len().saturating_add(1),
            ));
            let branch_block = body.close_block(
                self.inventory,
                AwbcTerminator::Branch {
                    condition: matched,
                    then_block: candidate_block,
                    else_block: candidate_block,
                },
                AwbcSafePointKind::None,
            );

            if let Some(guard) = arm.guard.as_ref() {
                let guarded = self.lower_guarded_candidate(
                    frame,
                    body,
                    pattern,
                    scrutinee,
                    guard.condition.as_ref(),
                    &guard.copy_locals,
                    &guard.ops,
                    &arm.ops,
                    &format!("{path}.arm.{index}"),
                );
                if let Some((fallthrough, scopes)) = guarded.fallthrough {
                    join.push(fallthrough, scopes);
                }
                let next_arm_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
                patch_branch_else_block(self.inventory, branch_block, next_arm_block);
                if let Some(jump) = guarded.guard_false_jump {
                    patch_jump_target(self.inventory, jump, next_arm_block);
                }
            } else {
                let arm_scopes = self.lower_scoped_branch_ops(
                    frame,
                    body,
                    Some((pattern, scrutinee)),
                    &arm.ops,
                    &format!("{path}.arm.{index}"),
                );
                if body.terminated {
                    let next_arm_block = body.reopen_after_terminated_branch(self.inventory);
                    patch_branch_else_block(self.inventory, branch_block, next_arm_block);
                } else {
                    join.push(
                        self.close_jump_to_join(body),
                        arm_scopes.expect(
                            "a continuing Match arm retains its actual lexical scope stack",
                        ),
                    );
                    let next_arm_block =
                        AwbcBlockId(table_index(self.inventory.program.blocks.len()));
                    patch_branch_else_block(self.inventory, branch_block, next_arm_block);
                }
            }
        }
        self.terminate_pattern_mismatch(body, "match pattern did not match");
        self.finish_join(frame, body, join);
    }

    fn lower_scoped_branch_ops(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        binding: Option<(AwbcPatternId, AwbcRegisterId)>,
        ops: &[FlowOp],
        path: &str,
    ) -> Option<Vec<AwbcScopeId>> {
        let restored_scopes = frame.scope_checkpoint();
        let scope = frame.enter_scope();
        self.inventory
            .push_instruction(AwbcInstruction::EnterScope { scope });
        if let Some((pattern, value)) = binding {
            self.inventory
                .push_instruction(AwbcInstruction::BindPattern {
                    pattern,
                    value,
                    mode: AwbcBindMode::Declare,
                });
        }
        self.lower_ops(frame, body, ops, path);
        if !body.terminated && frame.contains_scope(scope) {
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
            frame.exit_scope();
        }
        let fallthrough = (!body.terminated).then(|| frame.scope_checkpoint());
        frame.restore_scopes_after_branch(restored_scopes);
        fallthrough
    }

    fn lower_loop(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        result: Option<&RuntimePattern>,
        ops: &[FlowOp],
        path: &str,
    ) {
        let result_register = result.map(|pattern| {
            let ty = crate::awbc_lower::pattern::admitted_plan_type(
                self.inventory,
                self.plan,
                pattern.ty(),
            );
            frame.temp(ty)
        });
        let header = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump { target: header },
            AwbcSafePointKind::None,
        );

        // Backedges always target this dedicated header so an arbitrary first
        // body operation (including a suspension) cannot replace the required
        // loop-backedge safe point.
        let loop_body = AwbcBlockId(header.0.saturating_add(1));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump { target: loop_body },
            AwbcSafePointKind::LoopBackedge,
        );

        let outer_scope_depth = frame.scope_depth();
        let outer_scopes = frame.scope_checkpoint();
        let scope = frame.enter_scope();
        self.inventory
            .push_instruction(AwbcInstruction::EnterScope { scope });
        self.loop_targets.push(LoopLoweringTarget {
            header,
            exit_jumps: Vec::new(),
            outer_scope_depth,
            outer_scopes,
            format_attempt_depth: self.active_format_attempts.len(),
            result: result_register,
        });
        self.lower_ops(frame, body, ops, &format!("{path}.body"));

        if !body.terminated {
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
            body.close_block(
                self.inventory,
                AwbcTerminator::Jump { target: header },
                AwbcSafePointKind::LoopBackedge,
            );
            body.terminated = true;
        }

        let target = self
            .loop_targets
            .pop()
            .expect("loop lowering target is balanced with its loop body");
        frame.restore_scopes_after_branch(target.outer_scopes);
        if target.exit_jumps.is_empty() {
            return;
        }

        let exit = body.reopen_after_terminated_branch(self.inventory);
        for jump in target.exit_jumps {
            patch_jump_target(self.inventory, jump, exit);
        }
        if let (Some(pattern), Some(value)) = (result, target.result) {
            let pattern = lower_pattern(self.inventory, self.plan, frame, pattern);
            self.inventory
                .push_instruction(AwbcInstruction::BindPattern {
                    pattern,
                    value,
                    mode: AwbcBindMode::Declare,
                });
        }
    }

    fn lower_while(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        condition: &RuntimeExpr,
        ops: &[FlowOp],
        path: &str,
    ) {
        let header = self.begin_condition_loop_header(body);
        let condition =
            AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(condition);
        let body_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        let condition_branch = body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition,
                then_block: body_block,
                else_block: body_block,
            },
            AwbcSafePointKind::None,
        );

        let outer_scope_depth = frame.scope_depth();
        let outer_scopes = frame.scope_checkpoint();
        let scope = frame.enter_scope();
        self.inventory
            .push_instruction(AwbcInstruction::EnterScope { scope });
        self.loop_targets.push(LoopLoweringTarget {
            header,
            exit_jumps: Vec::new(),
            outer_scope_depth,
            outer_scopes,
            format_attempt_depth: self.active_format_attempts.len(),
            result: None,
        });
        self.lower_ops(frame, body, ops, &format!("{path}.body"));
        if !body.terminated {
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
            frame.exit_scope();
            body.close_block(
                self.inventory,
                AwbcTerminator::Jump { target: header },
                AwbcSafePointKind::LoopBackedge,
            );
            body.terminated = true;
        }

        let target = self
            .loop_targets
            .pop()
            .expect("while lowering target is balanced with its loop body");
        frame.restore_scopes_after_branch(target.outer_scopes);
        let exit = body.reopen_after_terminated_branch(self.inventory);
        patch_branch_else_block(self.inventory, condition_branch, exit);
        for jump in target.exit_jumps {
            patch_jump_target(self.inventory, jump, exit);
        }
    }

    fn lower_while_let(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: &WhileLetLoweringInput<'_>,
    ) {
        let WhileLetLoweringInput {
            pattern,
            expr,
            guard,
            ops,
            path,
        } = *input;
        let header = self.begin_condition_loop_header(body);
        let value = AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(expr);
        let pattern = self.lower_branch_pattern(frame, pattern);
        let matched = frame.temp(self.inventory.bool_ty());
        self.inventory
            .push_instruction(AwbcInstruction::TestPattern {
                dst: matched,
                pattern,
                value,
            });
        let candidate_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        let condition_branch = body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition: matched,
                then_block: candidate_block,
                else_block: candidate_block,
            },
            AwbcSafePointKind::None,
        );

        let outer_scope_depth = frame.scope_depth();
        let outer_scopes = frame.scope_checkpoint();
        let guard_false_jump = self.lower_while_let_body(
            frame,
            body,
            &WhileLetBodyInput {
                header,
                pattern,
                value,
                guard,
                ops,
                path,
                outer_scope_depth,
                outer_scopes: &outer_scopes,
            },
        );

        let target = self
            .loop_targets
            .pop()
            .expect("while-let lowering target is balanced with its loop body");
        frame.restore_scopes_after_branch(target.outer_scopes);
        let exit = body.reopen_after_terminated_branch(self.inventory);
        patch_branch_else_block(self.inventory, condition_branch, exit);
        if let Some(jump) = guard_false_jump {
            patch_jump_target(self.inventory, jump, exit);
        }
        for jump in target.exit_jumps {
            patch_jump_target(self.inventory, jump, exit);
        }
    }

    fn lower_while_let_body(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: &WhileLetBodyInput<'_>,
    ) -> Option<AwbcBlockId> {
        let WhileLetBodyInput {
            header,
            pattern,
            value,
            guard,
            ops,
            path,
            outer_scope_depth,
            outer_scopes,
        } = input;
        let scope = if let Some(guard) = *guard {
            crate::awbc_lower::expr::enter_guard_pattern_scope(
                self.inventory,
                self.plan,
                frame,
                *pattern,
                *value,
                guard,
            )
        } else {
            let scope = frame.enter_scope();
            self.inventory
                .push_instruction(AwbcInstruction::EnterScope { scope });
            self.inventory
                .push_instruction(AwbcInstruction::BindPattern {
                    pattern: *pattern,
                    value: *value,
                    mode: AwbcBindMode::Declare,
                });
            scope
        };
        self.loop_targets.push(LoopLoweringTarget {
            header: *header,
            exit_jumps: Vec::new(),
            outer_scope_depth: *outer_scope_depth,
            outer_scopes: outer_scopes.to_vec(),
            format_attempt_depth: self.active_format_attempts.len(),
            result: None,
        });

        if let Some(guard) = *guard {
            let guard =
                AwbcExprLowerer::new(self.inventory, frame, format!("{path}.guard"), self.plan)
                    .lower(guard);
            let body_block = AwbcBlockId(table_index(
                self.inventory.program.blocks.len().saturating_add(1),
            ));
            let guard_branch = body.close_block(
                self.inventory,
                AwbcTerminator::Branch {
                    condition: guard,
                    then_block: body_block,
                    else_block: body_block,
                },
                AwbcSafePointKind::None,
            );

            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
            frame.exit_scope();
            let body_scope = frame.enter_scope();
            self.inventory
                .push_instruction(AwbcInstruction::EnterScope { scope: body_scope });
            self.inventory
                .push_instruction(AwbcInstruction::BindPattern {
                    pattern: *pattern,
                    value: *value,
                    mode: AwbcBindMode::Declare,
                });
            self.lower_ops(frame, body, ops, &format!("{path}.body"));
            if !body.terminated {
                self.inventory
                    .push_instruction(AwbcInstruction::ExitScope { scope: body_scope });
                frame.exit_scope();
                body.close_block(
                    self.inventory,
                    AwbcTerminator::Jump { target: *header },
                    AwbcSafePointKind::LoopBackedge,
                );
                body.terminated = true;
            }
            frame.restore_scopes_after_branch(outer_scopes.to_vec());

            let guard_false_block = body.reopen_after_terminated_branch(self.inventory);
            patch_branch_else_block(self.inventory, guard_branch, guard_false_block);
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
            let jump = body.close_block(
                self.inventory,
                AwbcTerminator::Jump {
                    target: AwbcBlockId::default(),
                },
                AwbcSafePointKind::None,
            );
            body.terminated = true;
            Some(jump)
        } else {
            self.lower_ops(frame, body, ops, &format!("{path}.body"));
            if !body.terminated {
                self.inventory
                    .push_instruction(AwbcInstruction::ExitScope { scope });
                frame.exit_scope();
                body.close_block(
                    self.inventory,
                    AwbcTerminator::Jump { target: *header },
                    AwbcSafePointKind::LoopBackedge,
                );
                body.terminated = true;
            }
            None
        }
    }

    fn begin_condition_loop_header(&mut self, body: &mut FlowBodyBuilder) -> AwbcBlockId {
        let header = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump { target: header },
            AwbcSafePointKind::None,
        );
        let condition = AwbcBlockId(header.0.saturating_add(1));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump { target: condition },
            AwbcSafePointKind::LoopBackedge,
        );
        header
    }

    fn lower_break(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        depth: u32,
        value: Option<&RuntimeExpr>,
        path: &str,
    ) {
        let Some((outer_scope_depth, result, format_attempt_depth)) = self
            .loop_targets
            .iter()
            .rev()
            .nth(depth as usize)
            .map(|target| {
                (
                    target.outer_scope_depth,
                    target.result,
                    target.format_attempt_depth,
                )
            })
        else {
            self.terminate_missing_loop_transfer(frame, body, path, "break");
            return;
        };

        match (result, value) {
            (Some(result), Some(value)) => {
                let value =
                    AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(value);
                self.inventory.push_instruction(AwbcInstruction::Move {
                    dst: result,
                    src: value,
                });
            }
            (Some(result), None) => {
                let unit = self.inventory.constant_runtime_value(&RuntimeValue::Unit);
                self.inventory.push_instruction(AwbcInstruction::LoadConst {
                    dst: result,
                    constant: unit,
                });
            }
            (None, Some(value)) => {
                let _ = AwbcExprLowerer::new(self.inventory, frame, path, self.plan).lower(value);
            }
            (None, None) => {}
        }
        self.emit_format_attempt_abandons(format_attempt_depth);
        self.close_scopes_to_depth(frame, outer_scope_depth);
        let jump = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
        body.terminate(
            self.inventory,
            AwbcTerminator::Jump {
                target: AwbcBlockId::default(),
            },
            AwbcSafePointKind::None,
        );
        self.loop_targets
            .iter_mut()
            .rev()
            .nth(depth as usize)
            .expect("break target remains active while its body lowers")
            .exit_jumps
            .push(jump);
    }

    fn lower_continue(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        depth: u32,
        path: &str,
    ) {
        let Some((header, outer_scope_depth, format_attempt_depth)) = self
            .loop_targets
            .iter()
            .rev()
            .nth(depth as usize)
            .map(|target| {
                (
                    target.header,
                    target.outer_scope_depth,
                    target.format_attempt_depth,
                )
            })
        else {
            self.terminate_missing_loop_transfer(frame, body, path, "continue");
            return;
        };
        self.emit_format_attempt_abandons(format_attempt_depth);
        self.close_scopes_to_depth(frame, outer_scope_depth);
        body.terminate(
            self.inventory,
            AwbcTerminator::Jump { target: header },
            AwbcSafePointKind::LoopBackedge,
        );
    }

    fn close_scopes_to_depth(&mut self, frame: &FrameBuilder, target_depth: u32) {
        for scope in frame.scope_ids_for_exit_to_depth(target_depth) {
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
        }
    }

    fn emit_format_attempt_abandons(&mut self, keep_depth: usize) {
        for attempt in self.active_format_attempts[keep_depth..].iter().rev() {
            self.inventory
                .push_instruction(AwbcInstruction::AbandonFormatAttempt { attempt: *attempt });
        }
    }

    fn terminate_missing_loop_transfer(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        path: &str,
        transfer: &str,
    ) {
        let message = format!("{transfer} has no active typed loop target");
        self.inventory
            .diagnostic(AwbcLowerDiagnostic::error(path, &message));
        let message = self.inventory.intern_string(&message);
        self.close_active_scopes_for_terminator(frame);
        body.terminate(
            self.inventory,
            AwbcTerminator::Trap {
                code: AwbcTrapCode::InternalInvariant,
                message: Some(message),
            },
            AwbcSafePointKind::Trap,
        );
    }

    fn lower_branch_pattern(
        &mut self,
        frame: &mut FrameBuilder,
        pattern: &RuntimePattern,
    ) -> AwbcPatternId {
        let restored_scopes = frame.scope_checkpoint();
        let _ = frame.enter_scope();
        let pattern = lower_pattern(self.inventory, self.plan, frame, pattern);
        frame.restore_scopes_after_branch(restored_scopes);
        pattern
    }

    #[allow(
        clippy::too_many_arguments,
        reason = "Guarded pattern candidates need the active frame, body, pattern, value, guard, branch ops, and diagnostic path together."
    )]
    fn lower_guarded_candidate(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        pattern: AwbcPatternId,
        value: AwbcRegisterId,
        guard: Option<&RuntimeExpr>,
        copy_locals: &[arcweft_core::runtime_id::RuntimeLocalDeclarationId],
        guard_ops: &[FlowOp],
        ops: &[FlowOp],
        path: &str,
    ) -> GuardedCandidate {
        let restored_scopes = frame.scope_checkpoint();
        let scope = crate::awbc_lower::expr::enter_guard_pattern_scope_for_locals(
            self.inventory,
            frame,
            pattern,
            value,
            copy_locals,
        );
        self.lower_ops(frame, body, guard_ops, &format!("{path}.guard.ops"));
        if body.terminated {
            // Return/Break/Goto exits the enclosing control owner. There is no
            // guard condition or false edge on this path.
            frame.restore_scopes_after_branch(restored_scopes);
            body.reopen_after_terminated_branch(self.inventory);
            return GuardedCandidate {
                guard_false_jump: None,
                fallthrough: None,
            };
        }
        let Some(guard) = guard else {
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                path,
                "non-returning guard has a normal fallthrough",
            ));
            self.terminate_pattern_mismatch(body, "non-returning guard fell through");
            frame.restore_scopes_after_branch(restored_scopes);
            body.reopen_after_terminated_branch(self.inventory);
            return GuardedCandidate {
                guard_false_jump: None,
                fallthrough: None,
            };
        };
        let guard = AwbcExprLowerer::new(self.inventory, frame, format!("{path}.guard"), self.plan)
            .lower(guard);
        let body_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        let guard_branch_block = body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition: guard,
                then_block: body_block,
                else_block: body_block,
            },
            AwbcSafePointKind::None,
        );

        self.inventory
            .push_instruction(AwbcInstruction::ExitScope { scope });
        frame.exit_scope();
        let body_scope = frame.enter_scope();
        self.inventory
            .push_instruction(AwbcInstruction::EnterScope { scope: body_scope });
        self.inventory
            .push_instruction(AwbcInstruction::BindPattern {
                pattern,
                value,
                mode: AwbcBindMode::Declare,
            });
        self.lower_ops(frame, body, ops, &format!("{path}.then"));
        if !body.terminated && frame.contains_scope(body_scope) {
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope: body_scope });
            frame.exit_scope();
        }
        let fallthrough = if body.terminated {
            None
        } else {
            Some((self.close_jump_to_join(body), frame.scope_checkpoint()))
        };
        frame.restore_scopes_after_branch(restored_scopes);
        let guard_false_block = if body.terminated {
            body.reopen_after_terminated_branch(self.inventory)
        } else {
            AwbcBlockId(table_index(self.inventory.program.blocks.len()))
        };
        patch_branch_else_block(self.inventory, guard_branch_block, guard_false_block);
        self.inventory
            .push_instruction(AwbcInstruction::ExitScope { scope });
        let guard_false_jump = body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: AwbcBlockId::default(),
            },
            AwbcSafePointKind::None,
        );
        GuardedCandidate {
            guard_false_jump: Some(guard_false_jump),
            fallthrough,
        }
    }

    fn close_jump_to_join(&mut self, body: &mut FlowBodyBuilder) -> AwbcBlockId {
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: AwbcBlockId::default(),
            },
            AwbcSafePointKind::None,
        )
    }

    fn finish_join(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        join: BranchJoin,
    ) {
        let Some((_, scopes)) = join.fallthroughs.first() else {
            return;
        };
        if join
            .fallthroughs
            .iter()
            .any(|(_, candidate)| candidate != scopes)
        {
            let message =
                "fallthrough branches do not retain the same active lexical scope targets";
            self.inventory.diagnostic(AwbcLowerDiagnostic::error(
                format!("function.{}", body.owner.0),
                message,
            ));
            let block = if body.terminated {
                body.reopen_after_terminated_branch(self.inventory)
            } else {
                AwbcBlockId(table_index(self.inventory.program.blocks.len()))
            };
            for (source, _) in join.fallthroughs {
                patch_jump_target(self.inventory, source, block);
            }
            let message = self.inventory.intern_string(message);
            body.terminate(
                self.inventory,
                AwbcTerminator::Trap {
                    code: AwbcTrapCode::InternalInvariant,
                    message: Some(message),
                },
                AwbcSafePointKind::Trap,
            );
            return;
        }
        // This is an actual compile-time continuation stack produced by this
        // FrameBuilder, not the sibling entry checkpoint or source namespace.
        frame.restore_scopes_after_branch(scopes.clone());
        let join_block = if body.terminated {
            body.reopen_after_terminated_branch(self.inventory)
        } else {
            AwbcBlockId(table_index(self.inventory.program.blocks.len()))
        };
        for (block, _) in join.fallthroughs {
            patch_jump_target(self.inventory, block, join_block);
        }
    }

    fn terminate_pattern_mismatch(&mut self, body: &mut FlowBodyBuilder, message: &str) {
        let message = self.inventory.intern_string(message);
        body.terminate(
            self.inventory,
            AwbcTerminator::Trap {
                code: AwbcTrapCode::PatternMismatch,
                message: Some(message),
            },
            AwbcSafePointKind::None,
        );
    }

    fn lower_for(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: ForLoweringInput<'_>,
    ) {
        if let RuntimeIteratorEvidence::Witness(witness) = input.evidence {
            match &witness.executable {
                RuntimeIteratorWitnessExecutable::TraitCalls { into_iter, next } => {
                    self.lower_trait_call_for(frame, body, input, *into_iter, *next);
                }
                RuntimeIteratorWitnessExecutable::IdentityIntoIterator { next } => {
                    self.lower_identity_trait_call_for(frame, body, input, *next);
                }
            }
            return;
        }
        self.lower_intrinsic_iterator_for(frame, body, input);
    }

    #[allow(
        clippy::too_many_lines,
        reason = "The owned iterator step, Option branch, lexical scope, and loop backedge form one lowering transaction."
    )]
    fn lower_intrinsic_iterator_for(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: ForLoweringInput<'_>,
    ) {
        let RuntimeIteratorEvidence::Builtin(evidence) = input.evidence else {
            panic!(
                "witness-backed iterator reached built-in AWBC lowering at {}",
                input.path
            );
        };
        let source =
            AwbcExprLowerer::new(self.inventory, frame, input.path, self.plan).lower(input.source);
        let source_ty = admitted_plan_type(self.inventory, self.plan, input.source.ty());
        let iterator_ty = admitted_plan_type(self.inventory, self.plan, evidence.iterator);
        let iterator = frame.runtime_state(iterator_ty);
        let into_iter = self.intrinsic(
            RuntimeCallTarget::intrinsic(
                arcweft_core::value::RuntimeIntrinsic::builtin_iterator_into_iter(evidence.family),
            ),
            &[source_ty],
            Some(iterator_ty),
        );
        self.inventory
            .push_instruction(AwbcInstruction::CallIntrinsic {
                dst: Some(iterator),
                intrinsic: into_iter,
                args: vec![source],
            });

        let condition_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: condition_block,
            },
            AwbcSafePointKind::None,
        );

        let next_pair_ty = admitted_plan_type(self.inventory, self.plan, evidence.step);
        let next_pair = frame.temp(next_pair_ty);
        let next = self.intrinsic(
            RuntimeCallTarget::intrinsic(arcweft_core::value::RuntimeIntrinsic::CoreIterNext),
            &[iterator_ty],
            Some(next_pair_ty),
        );
        self.inventory
            .push_instruction(AwbcInstruction::CallIntrinsic {
                dst: Some(next_pair),
                intrinsic: next,
                args: vec![iterator],
            });
        let next_value_ty = admitted_plan_type(self.inventory, self.plan, evidence.next_value);
        let next_value = frame.temp(next_value_ty);
        let iterator_pattern = self.inventory.intern_pattern(AwbcPattern::Bind {
            target: iterator,
            mutable: false,
            expected: Some(iterator_ty),
        });
        let next_value_pattern = self.inventory.intern_pattern(AwbcPattern::Bind {
            target: next_value,
            mutable: false,
            expected: Some(next_value_ty),
        });
        let pair_pattern = self.inventory.intern_pattern(AwbcPattern::Tuple(vec![
            iterator_pattern,
            next_value_pattern,
        ]));
        self.inventory
            .push_instruction(AwbcInstruction::BindPattern {
                pattern: pair_pattern,
                value: next_pair,
                mode: AwbcBindMode::Declare,
            });
        let condition = self.test_option_some(frame, next_value, next_value_ty);
        let condition_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
        let body_block = AwbcBlockId(condition_block.0.saturating_add(1));
        body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition,
                then_block: body_block,
                else_block: body_block,
            },
            AwbcSafePointKind::LoopBackedge,
        );

        let scope = self.enter_iterator_for_scope(frame, condition_block);
        let value_ty = admitted_plan_type(self.inventory, self.plan, evidence.item);
        assert_eq!(
            value_ty,
            admitted_plan_type(self.inventory, self.plan, input.pattern.ty()),
            "admitted built-in iterator item must match its For pattern type"
        );
        let value = frame.temp(value_ty);
        let unwrap = self.intrinsic(
            RuntimeCallTarget::intrinsic(arcweft_core::value::RuntimeIntrinsic::CoreOptionUnwrap),
            &[next_value_ty],
            Some(value_ty),
        );
        self.inventory
            .push_instruction(AwbcInstruction::CallIntrinsic {
                dst: Some(value),
                intrinsic: unwrap,
                args: vec![next_value],
            });
        let pattern = lower_pattern(self.inventory, self.plan, frame, input.pattern);
        self.inventory
            .push_instruction(AwbcInstruction::BindPattern {
                pattern,
                value,
                mode: AwbcBindMode::Declare,
            });
        self.lower_ops(frame, body, input.ops, &format!("{}.body", input.path));
        self.finish_iterator_for_body(frame, body, scope, condition_block);
    }

    fn lower_trait_call_for(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: ForLoweringInput<'_>,
        into_iter: RuntimeTraitMethodId,
        next: RuntimeTraitMethodId,
    ) {
        let Some(into_iter) = self.inventory.trait_method(into_iter) else {
            panic!(
                "admitted iterator witness refers to an unlowered IntoIterator method at {}",
                input.path
            );
        };
        let source_ty = admitted_plan_type(self.inventory, self.plan, input.source.ty());
        let source =
            AwbcExprLowerer::new(self.inventory, frame, input.path, self.plan).lower(input.source);
        let iterator_ty =
            self.trait_method_result_type(into_iter, "IntoIterator::into_iter", source_ty);
        let iterator = frame.runtime_state(iterator_ty);
        self.inventory
            .push_instruction(AwbcInstruction::CallTraitMethod {
                dst: iterator,
                method: into_iter,
                receiver: source,
                args: Vec::new(),
                receiver_out: None,
            });
        self.lower_trait_iterator_loop(frame, body, input, iterator, iterator_ty, next);
    }

    fn lower_identity_trait_call_for(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: ForLoweringInput<'_>,
        next: RuntimeTraitMethodId,
    ) {
        let source =
            AwbcExprLowerer::new(self.inventory, frame, input.path, self.plan).lower(input.source);
        let iterator_ty = admitted_plan_type(self.inventory, self.plan, input.source.ty());
        let iterator = frame.runtime_state(iterator_ty);
        self.inventory.push_instruction(AwbcInstruction::Move {
            dst: iterator,
            src: source,
        });
        self.lower_trait_iterator_loop(frame, body, input, iterator, iterator_ty, next);
    }

    fn lower_trait_iterator_loop(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        input: ForLoweringInput<'_>,
        iterator: AwbcRegisterId,
        iterator_ty: arcweft_core::awbc::schema::AwbcTypeId,
        next: RuntimeTraitMethodId,
    ) {
        let Some(next) = self.inventory.trait_method(next) else {
            panic!(
                "admitted iterator witness refers to an unlowered Iterator::next method at {}",
                input.path
            );
        };
        let condition_block = AwbcBlockId(table_index(
            self.inventory.program.blocks.len().saturating_add(1),
        ));
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: condition_block,
            },
            AwbcSafePointKind::None,
        );

        let next_value_ty = self.trait_method_result_type(next, "Iterator::next", iterator_ty);
        let next_value = frame.temp(next_value_ty);
        self.inventory
            .push_instruction(AwbcInstruction::CallTraitMethod {
                dst: next_value,
                method: next,
                receiver: iterator,
                args: Vec::new(),
                receiver_out: Some(iterator),
            });
        let condition = self.test_option_some(frame, next_value, next_value_ty);
        let condition_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
        let body_block = AwbcBlockId(condition_block.0.saturating_add(1));
        body.close_block(
            self.inventory,
            AwbcTerminator::Branch {
                condition,
                then_block: body_block,
                else_block: body_block,
            },
            AwbcSafePointKind::LoopBackedge,
        );

        let scope = self.enter_iterator_for_scope(frame, condition_block);
        let value_ty = admitted_plan_type(self.inventory, self.plan, input.pattern.ty());
        let value = frame.temp(value_ty);
        let unwrap = self.intrinsic(
            RuntimeCallTarget::intrinsic(arcweft_core::value::RuntimeIntrinsic::CoreOptionUnwrap),
            &[next_value_ty],
            Some(value_ty),
        );
        self.inventory
            .push_instruction(AwbcInstruction::CallIntrinsic {
                dst: Some(value),
                intrinsic: unwrap,
                args: vec![next_value],
            });
        let pattern = lower_pattern(self.inventory, self.plan, frame, input.pattern);
        self.inventory
            .push_instruction(AwbcInstruction::BindPattern {
                pattern,
                value,
                mode: AwbcBindMode::Declare,
            });
        self.lower_ops(frame, body, input.ops, &format!("{}.body", input.path));
        self.finish_iterator_for_body(frame, body, scope, condition_block);
    }

    fn trait_method_result_type(
        &self,
        method: AwbcTraitMethodId,
        role: &str,
        expected_receiver: arcweft_core::awbc::schema::AwbcTypeId,
    ) -> arcweft_core::awbc::schema::AwbcTypeId {
        let method = self
            .inventory
            .program
            .trait_methods
            .get(method.index())
            .unwrap_or_else(|| panic!("admitted {role} AWBC method row is absent"));
        let signature = self
            .inventory
            .program
            .signatures
            .get(method.signature.index())
            .unwrap_or_else(|| panic!("admitted {role} AWBC signature row is absent"));
        let receiver = signature
            .params
            .first()
            .copied()
            .unwrap_or_else(|| panic!("admitted {role} signature has no receiver type"));
        assert_eq!(
            receiver, expected_receiver,
            "admitted iterator trait receiver must match its execution row"
        );
        signature
            .result
            .unwrap_or_else(|| panic!("admitted {role} signature has no result type"))
    }

    fn test_option_some(
        &mut self,
        frame: &mut FrameBuilder,
        option: AwbcRegisterId,
        option_ty: arcweft_core::awbc::schema::AwbcTypeId,
    ) -> AwbcRegisterId {
        let case_identity = RuntimeBuiltinVariantCaseIdentity::OptionSome;
        let (case, _) = case_identity
            .owner()
            .resolve_case(case_identity)
            .expect("Option::Some belongs to its builtin variant owner");
        let Some(AwbcRuntimeTypeShape::Variant {
            owner: AwbcVariantIdentity::Builtin(RuntimeBuiltinVariantIdentity::Option),
            cases,
            ..
        }) = self
            .inventory
            .program
            .runtime_types
            .get(option_ty.index())
            .map(AwbcRuntimeType::shape)
        else {
            panic!("admitted iterator next value must be Option");
        };
        let case_name = cases
            .get(case as usize)
            .expect("admitted Option::Some case exists")
            .name;
        let payload = self.inventory.intern_pattern(AwbcPattern::Discard);
        let pattern = self.inventory.intern_pattern(AwbcPattern::Variant {
            ty: option_ty,
            case,
            case_name,
            payload: Some(payload),
        });
        let condition = frame.temp(self.inventory.bool_ty());
        self.inventory
            .push_instruction(AwbcInstruction::TestPattern {
                dst: condition,
                pattern,
                value: option,
            });
        condition
    }

    fn enter_iterator_for_scope(
        &mut self,
        frame: &mut FrameBuilder,
        header: AwbcBlockId,
    ) -> AwbcScopeId {
        self.loop_targets.push(LoopLoweringTarget {
            header,
            exit_jumps: Vec::new(),
            outer_scope_depth: frame.scope_depth(),
            outer_scopes: frame.scope_checkpoint(),
            format_attempt_depth: self.active_format_attempts.len(),
            result: None,
        });
        let scope = frame.enter_scope();
        self.inventory
            .push_instruction(AwbcInstruction::EnterScope { scope });
        scope
    }

    fn finish_iterator_for_body(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        scope: AwbcScopeId,
        condition_block: AwbcBlockId,
    ) {
        let target = self
            .loop_targets
            .pop()
            .expect("For target balances its original body");
        let exit = if body.terminated {
            let exit = body.reopen_after_terminated_branch(self.inventory);
            patch_branch_else_block(self.inventory, condition_block, exit);
            exit
        } else {
            self.close_iterator_for_iteration(frame, body, scope, condition_block);
            AwbcBlockId(table_index(self.inventory.program.blocks.len()))
        };
        frame.restore_scopes_after_branch(target.outer_scopes);
        for jump in target.exit_jumps {
            patch_jump_target(self.inventory, jump, exit);
        }
    }

    fn close_active_scopes_for_terminator(&mut self, frame: &mut FrameBuilder) {
        for scope in frame.active_scope_ids_for_exit() {
            self.inventory
                .push_instruction(AwbcInstruction::ExitScope { scope });
        }
        frame.exit_all_scopes();
    }

    fn close_iterator_for_iteration(
        &mut self,
        frame: &mut FrameBuilder,
        body: &mut FlowBodyBuilder,
        scope: AwbcScopeId,
        condition_block: AwbcBlockId,
    ) {
        self.inventory
            .push_instruction(AwbcInstruction::ExitScope { scope });
        frame.exit_scope();
        body.close_block(
            self.inventory,
            AwbcTerminator::Jump {
                target: condition_block,
            },
            AwbcSafePointKind::LoopBackedge,
        );
        let after_block = AwbcBlockId(table_index(self.inventory.program.blocks.len()));
        patch_branch_else_block(self.inventory, condition_block, after_block);
    }

    fn intrinsic(
        &mut self,
        identity: RuntimeCallTarget,
        parameters: &[arcweft_core::awbc::schema::AwbcTypeId],
        result: Option<arcweft_core::awbc::schema::AwbcTypeId>,
    ) -> AwbcIntrinsicId {
        let signature =
            self.inventory
                .intern_signature(parameters.to_vec(), result, AwbcEffectSetId(0));
        if let Some((index, _)) =
            self.inventory
                .program
                .intrinsics
                .iter()
                .enumerate()
                .find(|(_, candidate)| {
                    candidate.identity == identity && candidate.signature == signature
                })
        {
            return AwbcIntrinsicId(table_index(index));
        }
        let id = AwbcIntrinsicId(table_index(self.inventory.program.intrinsics.len()));
        self.inventory.program.intrinsics.push(AwbcIntrinsic {
            identity,
            signature,
            revision: 1,
        });
        id
    }
}

fn awbc_dialogue_value_role(role: RuntimeDialogueValueRole) -> AwbcDialogueValueRole {
    match role {
        RuntimeDialogueValueRole::Interpolation => AwbcDialogueValueRole::Interpolation,
        RuntimeDialogueValueRole::Content => AwbcDialogueValueRole::Content,
        RuntimeDialogueValueRole::Formatted => AwbcDialogueValueRole::Formatted,
    }
}

fn patch_branch_else_block(
    inventory: &mut AwbcInventory,
    branch_block: AwbcBlockId,
    else_block: AwbcBlockId,
) {
    let Some(block) = inventory.program.blocks.get_mut(branch_block.index()) else {
        return;
    };
    let AwbcTerminator::Branch {
        else_block: target, ..
    } = &mut block.terminator
    else {
        return;
    };
    *target = else_block;
}

fn patch_resume_block(
    inventory: &mut AwbcInventory,
    resume: AwbcResumePointId,
    block: AwbcBlockId,
) {
    if let Some(point) = inventory.program.resume_points.get_mut(resume.index()) {
        point.block = block;
    }
}

fn patch_jump_target(
    inventory: &mut AwbcInventory,
    jump_block: AwbcBlockId,
    target_block: AwbcBlockId,
) {
    let Some(block) = inventory.program.blocks.get_mut(jump_block.index()) else {
        return;
    };
    let AwbcTerminator::Jump { target } = &mut block.terminator else {
        return;
    };
    *target = target_block;
}

fn checked_line_task_node_ids(
    group: &LineTaskGroup,
    node_start: u32,
) -> Result<Vec<AwbcLineTaskNodeId>, AwbcLowerDiagnostic> {
    let mut node_ids = Vec::with_capacity(group.nodes().len());
    for index in 0..group.nodes().len() {
        let offset = u32::try_from(index).map_err(|_| {
            AwbcLowerDiagnostic::error(
                "line_task.nodes",
                format!("line-task node offset {index} exceeds the u32 AWBC domain"),
            )
        })?;
        let absolute = node_start.checked_add(offset).ok_or_else(|| {
            AwbcLowerDiagnostic::error(
                "line_task.nodes",
                format!(
                    "line-task node table range starting at {node_start} exceeds the u32 AWBC domain"
                ),
            )
        })?;
        node_ids.push(AwbcLineTaskNodeId(absolute));
    }

    let validates =
        |id: arcweft_core::runtime_id::RuntimeLineTaskNodeId| node_ids.get(id.index()).is_some();
    if !validates(group.root()) {
        return Err(AwbcLowerDiagnostic::error(
            "line_task.root",
            "line-task root is outside its sealed node table",
        ));
    }
    for (index, node) in group.nodes().iter().enumerate() {
        let valid = match node {
            LineTaskNode::Sequence(children) | LineTaskNode::Start(children) => {
                children.iter().copied().all(&validates)
            }
            LineTaskNode::Parallel { children, .. } => children.iter().copied().all(&validates),
            LineTaskNode::Child { scope, .. } => validates(*scope),
            LineTaskNode::Action(_) => true,
        };
        if !valid {
            return Err(AwbcLowerDiagnostic::error(
                format!("line_task.node.{index}"),
                "line-task node references an ID outside its sealed node table",
            ));
        }
    }
    Ok(node_ids)
}

fn entry_target_flows<'a>(
    entries: impl IntoIterator<Item = &'a RuntimeEntrySpec>,
) -> BTreeSet<FlowRuntimeId> {
    let mut targets = BTreeSet::new();
    for entry in entries {
        match &entry.target {
            RuntimeEntryTarget::Flow(flow) | RuntimeEntryTarget::Controller(flow) => {
                targets.insert(flow.clone());
            }
            RuntimeEntryTarget::Routes(routes) => {
                targets.extend(routes.iter().map(|route| route.target.clone()));
            }
        }
    }
    targets
}

fn flow_public_id(flow: &FlowRuntimeId) -> String {
    flow.public_label().into_string()
}
