$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$runDir=$PSScriptRoot
. "$runDir/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$runDir/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$noncli=Read-Record 'view-action-ingress-integrated-20261108.noncli-r2.runtime.terminal-audit.json'
$cli=Read-Record 'view-action-ingress-integrated-20261108.cli.runtime.terminal-audit.json'
if($noncli.executed -ne 7361 -or $cli.executed -ne 711){throw 'Catalog count differs'}
$main=Read-Record 'view-action-ingress-integrated-20261108.cli.main-audit.json'
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$record=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($record.PSObject.Properties.Name -contains 'viewNamedActionConsumers'){throw 'Consumer evidence exists'}
$oldFailures=@($record.retainedTextInputConsumers.cli.failureSet|ForEach-Object { $_.binary+'::'+$_.test }|Sort-Object)
$newFailures=@($cli.failureSet|ForEach-Object { $_.binary+'::'+$_.test }|Sort-Object)
$failureDiff=@(Compare-Object $oldFailures $newFailures)
$raw=@(Get-ChildItem -LiteralPath $runDir -File -Filter 'view-action-ingress-integrated-20261108*')+@((Get-Item -LiteralPath "$runDir/view-action-ingress-20261108.owner-evidence.verified.json"),(Get-Item -LiteralPath "$runDir/view-action-ingress-20261108.graph-review.json"),(Get-Item -LiteralPath $PSCommandPath))
$archive='docs/implementation/acceptance-evidence/task-view-action-ingress-consumers.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in ($raw|Sort-Object FullName -Unique)){if($file.Extension -notin @('.log','.json','.patch','.txt','.ps1')){throw 'Unexpected raw entry'};[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|dll|rlib|rmeta|pdb)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$archiveInfo=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();containsExecutables=$false}
$entry=[ordered]@{version=1;date='2026-11-08';productionSource='8c123e75092eedb0aa1893a4c5847ca93f422e74';additionalTestPublication=(Read-Record 'view-action-ingress-20261108.owner-evidence.verified.json');nonCli=$noncli;cli=$cli;mainExecutable=$main;freshUniqueExecuted=($noncli.executed+$cli.executed);passed=($noncli.passed+$cli.passed);failed=($noncli.failed+$cli.failed);skipped=($noncli.skipped+$cli.skipped);featurePoints=@('workspace except CLI, all-features, lib/tests, rdeps(Core)','CLI default, lib/tests');priorCliFailureIds=$oldFailures;cliFailureIdChanges=$failureDiff;failureComparison='IDs only; read actual diagnostics before inferring cause equivalence or repair.';failedPreparation=(Read-Record 'view-action-ingress-integrated-20261108.noncli.catalog.json');preparationCause='E0786 mmap Core rlib failed with Windows OS1455 (paging file); delayed ICE/import/rlib errors followed. No runtime in that attempt. Retry reused completed build products without changing source/features/profile/jobs/budgets.';graph=(Read-Record 'view-action-ingress-20261108.graph-review.json');cliSourceProbe=$(if(Test-Path -LiteralPath "$runDir/view-action-ingress-integrated-20261108.cli-source-probe.json"){Read-Record 'view-action-ingress-integrated-20261108.cli-source-probe.json'}else{$null});archive=$archiveInfo;preservedPriorRecords=@($record.PSObject.Properties).Count;scope='Fresh reverse consumers; do not add focused owner repetitions or prior matrices. Source sample migration and actual Native/Web capture remain distinct acceptance boundaries.'}
$entry['coverageReview']=Read-Record 'view-action-ingress-integrated-20261108.coverage-review.json'
$entry['observedDiagnostics']=@('Scroll: sema.final_analysis shared callable resolution, original expression slot 15','Voice: active dialogue has no voice','Both promotion fixtures: sema.final_analysis, no solver/promotion proof result')
$wrapper=(ConvertTo-Json -InputObject ([ordered]@{viewNamedActionConsumers=$entry}) -Depth 100).Replace("`r`n","`n").TrimEnd()
$inner=$wrapper.Substring(1,$wrapper.Length-2).Trim("`r","`n")
$trim=$base.TrimEnd();$result=$trim.Substring(0,$trim.Length-1).TrimEnd()+","+"`n"+$inner+"`n}"+"`n"
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$result,[Text.UTF8Encoding]::new($false))
$after=$result|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $record.PSObject.Properties){if((ConvertTo-Json -InputObject $after.($property.Name) -Depth 100 -Compress) -cne (ConvertTo-Json -InputObject $property.Value -Depth 100 -Compress)){throw ('History changed: '+$property.Name)}}
[ordered]@{priorRecords=@($record.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;executed=$entry.freshUniqueExecuted;passed=$entry.passed;failed=$entry.failed;skipped=$entry.skipped;failureIdChanges=$failureDiff;archive=$archiveInfo}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$runDir/view-action-ingress-consumers-record-audit.json" -Encoding utf8
Get-Content -LiteralPath "$runDir/view-action-ingress-consumers-record-audit.json" -Raw
