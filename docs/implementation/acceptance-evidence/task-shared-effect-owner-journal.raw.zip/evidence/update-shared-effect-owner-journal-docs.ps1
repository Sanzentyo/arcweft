$ErrorActionPreference='Stop'
$scratch=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$scratch/shared-effect-owner-journal.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$scratch/shared-effect-owner-journal.owner-summary.json"|ConvertFrom-Json
$impact=Get-Content -Raw "$scratch/shared-effect-owner-journal.impact.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$scratch/shared-effect-owner-journal.quality.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$scratch/shared-effect-owner-journal.structure.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$scratch/shared-effect-owner-journal.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Documentation base changed'}
if($owner.Selected -ne 1765 -or $owner.Passed -ne 1759 -or $owner.Failed -ne 6 -or !$owner.IdsEqual -or $quality.Steps.Count -ne 2 -or @($quality.Steps|Where-Object ExitCode -ne 0).Count -or $structure.ExitCode -ne 0 -or !$archive.AllEntriesVerified -or $impact.ReverseConsumersRerun){throw 'Final validation differs'}
$status='docs/implementation/current-status.md'
$history='docs/implementation/convergence-evidence-history.md'
$previousStatus=[IO.File]::ReadAllText((Join-Path $PWD $status))
$previousHistory=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$generic=[regex]::Match($previousStatus,'(?m)^\| Generic Match[^\r\n]+').Value
$oldIndex=@(git ls-files -- docs/implementation/acceptance-evidence)
$rows=[ordered]@{}
$feature=[regex]::Match($previousStatus,'(?m)^\| 再帰関数値の終端効果 \|[^\r\n]+').Value
$feature=$feature.Replace('既受入と本体効果closureの接続を維持。型の移送処理を統合・検証・公開。本体内の関数値推論は継続','既受入と型移送の統合を維持。prepared値のgraph所有・候補転送を修復・検証・公開。本体内の関数値推論は継続')
$replacement="最新Source ``$($pub.Source)``。prepared値componentは自身の効果graphを作らず、元graphのread-only owner leaseを保持し、同じgraphを借りて値・guardを保持する。checkpointの全宣言map複製は変更journalへ置換し、転送・入れ子rollback・replayの元ownerを保持する。componentのAnalyzer全portへの接続は継続中であり、本体内の推論修復とは区別する。"
$feature=[regex]::Replace($feature,'最新Source `[0-9a-f]{40}`。',[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
$feature=$feature.Replace('・[型移送の統合](convergence-evidence-history.md#shared-scoped-type-projection)。 |','・[型移送の統合](convergence-evidence-history.md#shared-scoped-type-projection)・[graph所有と転送](convergence-evidence-history.md#shared-prepared-effect-owner-and-mutation-journal)。 |')
$rows['再帰関数値の終端効果']=$feature
$rows['再帰本体の型表現／Semaの推移的逆依存']="| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,759 PASS／6 FAIL。後続matrixは前cutの実測を保持** | Source ``$($pub.Source)`` のlocked・全feature Sema lib／tests 1,765件を$($owner.ExecutionSeconds)秒で実行。直前1,762 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。fresh metadata／全target reverse treeは22 packageで不変。変更はSema privateなcheckpoint／delta／replayと値componentの所有・借用APIに限り、当該consumerを全owner runで検証した。後続21 package／107 targetは今回未再実行で、Source ``$($impact.BaselineConsumerSource)`` の2,510件／2,507 PASS／2 FAIL／1 SKIPを元入力の実測として保持する。公開型・checked出力・codec・Cargo／feature・I/Oは変更しない。[owner・選定理由・原本](acceptance-evidence/task-shared-effect-owner-journal.raw.zip)・[前cutのconsumer原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$rows['workspace check／Clippy・fmt・構造gate']="| workspace check／Clippy・fmt・構造gate | **所有Semaの品質・fmt・構造は今回終了0。workspace品質は前cutの実測を保持** | Source ``$($pub.Source)`` のlocked Sema全target／全feature check・Clippy、workspace fmt、構造gateを実行。構造は$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。9 Rust path・$($owner.PhysicalGrowth)物理LOC増。元のgraph ownerとprivateな値componentの責務を分け、graphの複製所有と全基点mapの複製を除去した。公開API・依存・I/O・codec・version・既定予算は不変、fan-in／out $($owner.FanIn)／$($owner.FanOut)。CARGO_INCREMENTAL=0、jobs／profile上書きなし、警告を保持。workspace全target／全feature check・ClippyとSema doctest 2件はSource ``$($impact.BaselineConsumerSource)`` の実測を保持し、今回の再実行としない。後続nextest・Tier 2・再帰本体の新しいNative／AWBC・Native／Web最終受入も今回未実行。[今回の品質・構造](acceptance-evidence/task-shared-effect-owner-journal.raw.zip)・[前cutのworkspace原本](acceptance-evidence/task-scoped-structural-fold.raw.zip)。 |"
$current=$previousStatus
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]+'
    if([regex]::Matches($current,$pattern).Count -ne 1){throw "Missing/duplicate row $key"}
    $replacement=$rows[$key]
    $current=[regex]::Replace($current,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$header="確認日 2026-11-14。この更新の基点の ``main`` と ``origin/main`` は ``$($pub.Source)`` で一致し、その時点のtracked差分は0件。本資料・履歴・検証原本を後から更新し、既存の未追跡 ``%SystemDrive%/`` を保持した。検証入力と再利用の範囲は履歴・原本に区別して記録する。"
$current=[regex]::Replace($current,'(?m)^確認日 [^\r\n]+',[Text.RegularExpressions.MatchEvaluator]{param($m) $header})
if([regex]::Match($current,'(?m)^\| Generic Match[^\r\n]+').Value -cne $generic){throw 'Generic Match acceptance changed'}
$entry=@"

## Shared prepared-effect owner and mutation journal

2026-11-14。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの9 Rust pathを通常commit／非force pushし、検証dirty bytes・commit・公開blobを照合した。既存の未追跡 ``%SystemDrive%/`` は保持した。

- PreparedEffectCheckpointは元の全function mapを複製せず、候補のmutation frontierを保持する。immutable functionの新規追加と置換前定義、row／predicate／choiceを一つのaffine journalに記録し、逆順のrollbackで元の定義へ戻す。extractは変更した定義だけを元のcontrolで事前に課金して共有し、失敗ならlive checkpointを保持する。restoreも書込みをjournalへ記録するため、checkpointより古いordinalの復元と内側commitを含めて外側rollbackが戻す。allocatorは巻き戻さない。
- replayは同じ実issuer・実base stampを検証し、そのlive baseで変更前から存在した宣言を認証する。全baseline ID集合の複製・走査を削除したが、元宣言identity、全predicate／obligation、新しい関数の対応と相関を捨てない。ordinal順や一つの効果観測からownerを推定しない。
- OpenConstraintComponentから独立したPreparedEffectGraphの生成・所有・effects_mutを削除した。元graphのread-only owner leaseを保持し、admission・guard・conditional useの公開は、そのgraphを借りて行う。leaseは定義やcheckpoint／deltaを複製せず、公開権限にもならない。値／useのissuer、元Source Γ、元producerの制約と相関は別の既存authorityとして保持する。このcomponentはまだAnalyzerの関数値portへ接続されておらず、今回のprivate境界の修復をfrontendの完了に読み替えない。
- 新3件は、数学graphの4,096個の未変更headerを増やしてもcheckpoint／extract／replayの仕事量と元functionのArc参照数が増えないこと、入れ子commit後の転送／rollback、独立した値componentが同じ未完了宣言を保持し、元の本体を一度設定した後に同じ効果を読めることを検証する。foreign graphはcanonical値でも拒否し、同じgraphを使うcomponent間でも別の値issuerを拒否する。開発subset 21 PASS、移行途中のテストでの変数shadow／引数不足によるcheck失敗、修正後の55 PASSも原本に保持し、完全入力snapshotのない開発runを最終Sourceの証拠にしない。
- 最終ownerは1,765件／1,759 PASS／6 FAIL／0 SKIP、$($owner.ExecutionSeconds)秒、5 suite。直前1,762 ID保持・新3件PASS、選択／終端ID一致・重複0。既知6件と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。Sema全target／全feature check・Clippy、workspace fmt、構造gateは終了0。$($structure.Packages) package・$($structure.Files) files・$($structure.RustFiles) Rust files・$($structure.RustPhysicalLOC) Rust LOC・$($structure.ReviewTriggers) review・blocking $($structure.Blocking)。9 path・$($owner.PhysicalGrowth)物理LOC増。元graphが数学的な状態と転送を所有し、private componentは値・元制約・useだけを所有する。実LOC・byte size・test分類、fan-in $($owner.FanIn)／fan-out $($owner.FanOut)を保持した。公開API・依存・I/O・codec・version・既定予算は変更しない。CARGO_INCREMENTAL=0、jobs／profile上書きなし。
- fresh full metadata／全target reverse treeの22 packageとCargo入力が不変であることを照合した。変更されたAPIとそのconsumerはSema内のprivateな所有・転送機構に限り、full ownerで確認した。後続21 package／107 targetのSource ``$($impact.BaselineConsumerSource)`` の実測は2,510件／2,507 PASS／2 FAIL／1 SKIPとして保持し、今回の再実行へ合算しない。workspace全target／全feature品質とdoctest 2件も同じ前cutの実測であり、今回のfresh runはowner品質・fmt・構造である。Tier 2と新しい実機受入は未実行。
- Supersedes: componentの別graph所有とcheckpointでの全基点map複製を、元graphの借用と変更journalへ訂正する。元issuer／exact base／原子的転送という受入条件は維持する。今回の失敗6件を解消した判定ではない。Generic Match、本体効果closure、型移送、caller-bound recursion、共有prefix、Free許可／reifyの各既受入を保持し、残作業は[current-status.md](current-status.md)の該当行だけへ集約する。過去の全SHA・実測・失敗・原本を変更しない。

原本 [task-shared-effect-owner-journal.raw.zip](acceptance-evidence/task-shared-effect-owner-journal.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
foreach($document in @($rows.Values)+@($entry)){
    foreach($match in [regex]::Matches($document,'\]\(([^)#]+)(?:#[^)]*)?\)')){
        $target=$match.Groups[1].Value
        if($target -match '^[a-z]+:' -or $target.StartsWith('/')){continue}
        if(!(Test-Path -LiteralPath (Join-Path 'docs/implementation' $target))){throw "Missing documentation link $target"}
    }
}
[IO.File]::WriteAllText((Join-Path $PWD $status),$current,[Text.UTF8Encoding]::new($false))
[IO.File]::AppendAllText((Join-Path $PWD $history),"`n"+$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes((Join-Path $PWD $history))
$prefix=[byte[]]::new($previousHistory.Length)
[Array]::Copy($after,$prefix,$prefix.Length)
if($after.Length -le $previousHistory.Length -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($previousHistory)) -cne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix))){throw 'Historical prefix changed'}
if(@(Compare-Object -CaseSensitive $oldIndex @(git ls-files -- docs/implementation/acceptance-evidence)).Count){throw 'Historical archive index changed'}
git diff --check
if($LASTEXITCODE){throw 'Documentation whitespace failed'}
[ordered]@{Version=1;Source=$pub.Source;HistoryPrefixBytesPreserved=$previousHistory.Length;GenericMatchRowUnchanged=$true;OldArchiveIndexUnchanged=$true;ChangedLinksResolve=$true;RowsUpdated=$rows.Count;HistoryAppended=$true;FinalWhitespaceExit=0}|ConvertTo-Json|Set-Content -Encoding utf8 "$scratch/shared-effect-owner-journal.docs-validation.json"
git diff --stat
