$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/shared-effect-owner-journal.publication.json"|ConvertFrom-Json
$metadata=Get-Content -Raw "$root/shared-effect-owner-journal.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')[0]
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner.id)
do {$changed=$false;foreach($node in $metadata.resolve.nodes){if(!$closure.Contains($node.id)){foreach($dependency in $node.deps){if($closure.Contains($dependency.pkg)){$changed=$closure.Add($node.id) -or $changed;break}}}}}while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$previous=Get-Content -Raw "$root/scoped-structural-fold.impact.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/scoped-structural-fold.consumer-summary.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($previous.Packages|Sort-Object) @($packages.name)).Count -or @(Compare-Object -CaseSensitive @($previous.PackageIds|Sort-Object) @($packages.id)).Count){throw 'Resolved reverse graph changed'}
if(@(git diff --name-only $previous.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml').Count){throw 'Cargo graph inputs changed'}
$tree=[IO.File]::ReadAllText("$root/shared-effect-owner-journal.reverse-tree.txt")
$workspace=@($metadata.packages|Where-Object {$metadata.workspace_members -ccontains $_.id}|ForEach-Object name)
$treePackages=@([regex]::Matches($tree,'(?m)([a-z][a-z0-9-]+) v[0-9][^\s]*')|ForEach-Object {$_.Groups[1].Value}|Where-Object {$workspace -ccontains $_}|Sort-Object -Unique)
if(@(Compare-Object -CaseSensitive @($packages.name|Sort-Object) $treePackages).Count){throw 'Reverse tree differs from resolved metadata'}
if($consumers.Source -ne $previous.Source -or $consumers.Targets -ne 107 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or $consumers.Skipped -ne 1){throw 'Baseline consumer evidence differs'}
[ordered]@{
    Version=1;Source=$pub.Source;Tree=$pub.Tree;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;FullResolvedGraph=$true;AllTargetReverseTree='shared-effect-owner-journal.reverse-tree.txt';CargoInputsUnchanged=$true
    ReverseConsumersRerun=$false;BaselineConsumerSource=$previous.Source;BaselineConsumerTargets=$consumers.Targets;BaselineConsumerPassed=$consumers.Passed;BaselineConsumerFailed=$consumers.Failed;BaselineConsumerSkipped=$consumers.Skipped
    Scope='Private ownership and transfer implementation. PreparedEffectGraph and its checkpoint/delta/replay APIs are crate-private; OpenConstraintComponent is private lower preparation infrastructure, not yet connected to analyzer value ports. All changed consumers are inside sema and covered by its complete five-suite owner run. Declaration insertion outside a checkpoint still publishes the same immutable definition. Canonical type/effect grammar, public checked outputs, exports, source-language behavior, Cargo/features, generated/serialized artifacts and I/O adapters are unchanged. The previous public consumer matrix is retained as evidence for its original source, not relabeled as a fresh run. Owner all-target/all-feature check and Clippy, full owner nextest, fmt and a fresh structure gate are selected. No fresh workspace quality, downstream nextest, doctest or Tier 2 claim is made.'
}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/shared-effect-owner-journal.impact.json"
Write-Output "Verified unchanged reverse closure: $($packages.Count) packages; owner-only scope recorded"
