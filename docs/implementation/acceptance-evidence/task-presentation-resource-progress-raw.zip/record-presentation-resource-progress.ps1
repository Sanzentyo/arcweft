$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$source='0c65eb15235f16ff96232e4926e5bbd563e5a90c'
$published=Get-Content -Raw "$taskTemp/checkpoint-presentation-resource-consumers.verified.json"|ConvertFrom-Json -Depth 20
$check=Get-Content -Raw "$taskTemp/presentation-resource-value-check11-20261101.json"|ConvertFrom-Json
$quality=@(foreach($kind in @('clippy','structure','fmt')) {Get-Content -Raw "$taskTemp/presentation-resource-value-quality-20261101.$kind.json"|ConvertFrom-Json -Depth 20})
if($check.exitCode -ne 0 -or @($quality|Where-Object exitCode -ne 0).Count){throw 'Required checkpoint checks are not successful'}
$freeze=Get-Content -Raw "$taskTemp/presentation-resource-value-check11-20261101.source-freeze.json"|ConvertFrom-Json -Depth 30
$drift=@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($drift.Count){throw 'Source drift'}
$held=Get-Content -Raw 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json'|ConvertFrom-Json -Depth 20
$cliProof=Get-Content -Raw "$taskTemp/presentation-handle-contract.cli-preservation-proof.json"|ConvertFrom-Json -Depth 20
if((git hash-object -- $cliProof.path).Trim() -ne $cliProof.workingBlob -or $published.heldPatchSha256 -ne $cliProof.expectedResidualWipPatchSha256){throw 'Reconciled CLI WIP differs from its retained preservation proof'}
if(@($held.held|Where-Object {$_.path -ne $cliProof.path -and (Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Held WIP drift'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath="$evidence/task-presentation-resource-progress-raw.zip"
if(Test-Path -LiteralPath $zipPath){throw 'Raw evidence already exists'}
$rawFiles=@(Get-ChildItem -LiteralPath $taskTemp -File | Where-Object {
    $_.Name -like 'presentation-resource-value-*' -or
    $_.Name -like 'checkpoint-presentation-resource-values.*' -or
    $_.Name -like 'checkpoint-presentation-resource-consumers.*' -or
    $_.Name -in @('record-presentation-resource-progress.ps1','presentation-resource-owned.txt','run-shared-identity-owner.ps1','audit-nextest-final-result.ps1','presentation-handle-contract.cli-preservation-proof.json')
} | Sort-Object Name)
$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try {foreach($file in $rawFiles){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}} finally {$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {
    if($zip.Entries.Count -ne $rawFiles.Count){throw 'Raw entry count mismatch'}
    foreach($file in $rawFiles){$stream=$zip.GetEntry($file.Name).Open();try {$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()){throw 'Raw entry drift'}}
}finally{$zip.Dispose()}
$record=[ordered]@{
    version=1;date='2026-11-01';status='implementation checkpoint; Source staging is not accepted';source=$source;consumerPublication=$published
    workingTree='main; original 14 tracked and 6 actual untracked WIP retained; checkpoint paths published separately'
    change='First-class affine presentation resource values retain complete original Source, the actual executable lease, exact argument keys, resource/tuple semantic types and the original invocation binding. Native/AWBC type, save and ownership grammars share their existing typed authorities. Metadata keys serialize by borrow. Static literal/data/Agent/scalar consumers refuse the owning resource carrier.'
    focused=[ordered]@{initial='focus1 catalogue failed to compile: private module import and use of the raw view rather than its live Copy capability';firstRuntime='focus2: 4 PASS / 1 FAIL; the positive snapshot case incorrectly requested unrestricted rather than owned admission';correction='Use owned admission and assert the concrete Source/type failure in each forged snapshot case; no production ownership guard weakened';final='focus3: 5 PASS / 0 FAIL / 2181 filtered; 4050 inputs, case/source/executable drift 0';scope='Core value construction and typed private snapshots under Native and canonical-decoded AWBC; not factory execution or public Native save'}
    workspaceCheck=$check;quality=$quality;sourceInputs=$freeze.paths.Count;sourceDrift=0;heldFiles=20;heldDrift=0
    heldBaseline=[ordered]@{ordinaryHashes=19;originalBaseline='arcweft-docs-reconcile-20261027/before.json';reconciledCliProof=$cliProof;proofSha256=(Get-FileHash -LiteralPath "$taskTemp/presentation-handle-contract.cli-preservation-proof.json").Hash.ToLowerInvariant();reason='The previously published canonical CLI change was already reconciled with the original user 8-to-32 patch; compare its retained working blob rather than the obsolete pre-migration whole-file hash.'}
    ownerReview=@(foreach($path in @('crates/arcweft-core/src/presentation/factory.rs','crates/arcweft-core/src/presentation/resource_value.rs','crates/arcweft-core/src/presentation/resource_value/tests.rs')){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;physicalLOC=[IO.File]::ReadAllLines([IO.Path]::GetFullPath($path)).Length;classification=$(if($path -like '*/tests.rs'){'test'}else{'production'})}})
    ownership='The factory layout owns exact destinations and derived scope/body positions. The resource owns original Source and captures; the existing ledger owns custody. Original/AWBC type comparison reuses one metered relation. Value traversal, Copy rejection and inert projection remain in Core; no I/O, unsafe, Cargo edge, fake Task family or ordinary-function View execution introduced.'
    pending=@('Source factory/removal/method execution and layout sealing against the executable call ABI','execution-owned explicit staging scope producer','typed command and actual Native/Web driver integration','whole-live-contour construction admission','full reverse-dependency/CLI acceptance for these new inputs; current 43 CLI failures remain from prior inputs','public Native save, final default/Wasm/doctest/Tier 2/capture parity as required by the complete milestone')
    acceptedFeatures='Generic Match acceptance 850534b9e9bc8c8872f6528dd00050a5e6e7699e / publication f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2 and all independently accepted boundaries remain accepted. No fresh 151-case run is claimed for this checkpoint.'
    raw=[ordered]@{path=$zipPath;entries=$rawFiles.Count;bytes=(Get-Item -LiteralPath $zipPath).Length;sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entryDrift=0}
}
$record|ConvertTo-Json -Depth 30|Set-Content -LiteralPath "$evidence/task-presentation-resource-progress.json" -Encoding utf8
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText([IO.Path]::GetFullPath($statusPath))
$eol=$(if($status.Contains("`r`n")){"`r`n"}else{"`n"})
$lines=$status -split '\r?\n'
$lines[2]="確認日: 2026-11-01。最新の公開checkpointは$($published.commit)（resource本体$source とconsumer移行）。新しい4,050入力のworkspace check／Clippy／構造検査／59 path fmtは終了0。Core値・private snapshotの対象5件は$source でPASSしたが、Source stagingの実行接続と新入力の全逆依存受入は未達。直前の検証済みSource 12180810c10ced738a2ad94f98dbb3b1cec831a1 の通常62逆依存9024 PASS／0 FAIL／24 ignored、全CLI 649 PASS／43 FAIL／23 ignoredはその入力の証拠として保持する。元14 tracked／6 actual untracked WIPを保持し、各行の境界と検証範囲で判定する。"
$status=$lines -join $eol
$row="| Presentation resource本体の値／保存owner | **移行checkpointを公開。Source staging全体の受入前** | Source $source、consumer $($published.commit)。affineな本体が元Source・実executable・引数key・tuple型・元の効果instantiationを保持し、Handleのcustodyと分離する。Native／canonical decoded AWBCのprivate値snapshot、Copy拒否、別lease・Source／capture型の偽造拒否、資源上限、全8 familyのtype codecを対象5件で確認した。新入力のworkspace check／Clippy／構造検査／59 path fmtは終了0。factory ABIへのlayout結合、Source生成・scope・command／method・driver、全体のlive資源検査と広域受入は未達。個別の既受入を未完了へ戻す判定ではない。[初回失敗・修正・入力・公開原本](acceptance-evidence/task-presentation-resource-progress.json)。 |"
$anchor='| Native Presentationの置換body返却 |'
$index=$status.IndexOf($anchor,[StringComparison]::Ordinal)
if($index -lt 0 -or $status.Contains('| Presentation resource本体の値／保存owner |')){throw 'Current status anchor differs'}
$status=$status.Insert($index,$row+$eol)
[IO.File]::WriteAllText([IO.Path]::GetFullPath($statusPath),$status,[Text.UTF8Encoding]::new($false))
$historyPath=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md')
$before=[IO.File]::ReadAllBytes($historyPath)
[IO.File]::WriteAllBytes("$taskTemp/presentation-resource-history-prefix.before",$before)
$append=@"

## 2026-11-01 — Presentation resource本体の実装checkpoint

Source $source（親534742896a9450e8bff54ce4376730e27f086a00、54 path）、consumer修正 $($published.commit) を通常commit／non-forced pushし、全blob・patch・remoteを照合した。元14 tracked／6 actual untracked WIPの20 hashを保持した。新しいaffine resource値は、元のcomplete Source・実executable lease・引数key・retained tuple型・元invocationを保持する。共通型・保存・Copy／資源走査へ接続し、static literal／data／Agent JSON／scalarからの誤用を拒否する。

初回catalogはテストのprivate importとCopy view APIの誤り2件でcompile失敗。修復後は4 PASS／1 FAILで、正のsnapshotテストがCopy用の受入APIを使ってAffineValueになった。Owned受入へ直し、偽造拒否も具体的なSource／型エラーへ強めた。同じ5 IDの最終focus3は5／5 PASS、4,050入力・catalog／case／EXE／入力差分0。これをSource factory実行・公開Native saveの受入へ広げない。

段階的workspace checkで判明した共有enumの利用側を移行した。最終check11はworkspace全target／全feature／lockedで終了0。Clippy／構造gate／変更59 Rust path fmtも終了0。初回失敗・全診断・元入力はrawへ保持し、警告なしとはしない。新入力の全逆依存／全CLI・default／Wasm・doctest・Tier 2・画像parityは未再実行。完了したGeneric Matchや個別ownerの受入は維持し、以前の9024 PASS・CLI 43 FAIL・151／151 PASSを新入力の再実行へ読み替えない。Source factory ABIのlayout結合、生成・明示scope・command／method・driver・全live contour admissionは残る。

現状の唯一の一覧はcurrent-status.mdに集約し、旧現在形から未達を重複転記しない。詳細とraw hashは[checkpoint原本](acceptance-evidence/task-presentation-resource-progress.json)。全体cargo cleanは既に実行済み（198,113 files／244.6 GiB・終了0）で、この実装中には繰り返していない。生成物の移動・コピー・退避も行っていない。
"@
[IO.File]::AppendAllText($historyPath,$append,[Text.UTF8Encoding]::new($false))
$after=[IO.File]::ReadAllBytes($historyPath)
$hasher=[Security.Cryptography.SHA256]::Create()
try {$oldHash=[Convert]::ToHexString($hasher.ComputeHash($before));$prefixHash=[Convert]::ToHexString($hasher.ComputeHash($after,0,$before.Length))}finally{$hasher.Dispose()}
if($oldHash -ne $prefixHash){throw 'History prefix changed'}
[ordered]@{version=1;source=$source;consumer=$published.commit;raw=$record.raw;historyPrefixUnchanged=$true;sourceDrift=0;heldDrift=0}|ConvertTo-Json -Depth 8|Set-Content "$taskTemp/presentation-resource-doc-proof.json"
$record.raw|ConvertTo-Json
