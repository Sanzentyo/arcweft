$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -AsHashtable -Depth 100}
$publication=Read-Record 'callable-input-order-native-checkpoint.verified'
$runtime=Read-Record 'callable-input-order-native-owner4-20261105.runtime.terminal-audit'
$structure=Read-Record 'callable-input-order-native.structure'
if((git rev-parse HEAD).Trim() -ne $publication.commit -or $runtime.executed -ne 2273 -or $runtime.passed -ne 2273 -or $structure.exitCode -ne 0){throw 'Unexpected source/result'}
$freeze=Read-Record 'callable-input-order-native-owner4-20261105.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$oldFreeze=Read-Record 'callable-input-order-owner2-20261105.source-freeze'
$oldPaths=@{};foreach($row in $oldFreeze.paths){$oldPaths[$row.path]=$row.sha256}
$manifests=@($freeze.paths|Where-Object {$_.path -match '(^|/)Cargo\.(toml|lock)$'})
foreach($row in $manifests){if($row.sha256 -ne $oldPaths[$row.path]){throw 'Graph input changed'}}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$statusPath='docs/implementation/current-status.md'
$historyPath='docs/implementation/convergence-evidence-history.md'
$record=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
$before=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
if($record.callableInputOrder.Contains('nativeFrames')){throw 'Preserve existing native evidence'}
$history=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$historyPrefix=[ordered]@{bytes=$history.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($history)).ToLowerInvariant()}
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$oldRows=@($status -split "`n"|Where-Object {$_ -match '^\| (RichTextの部分layout指定／source factory|共有契約／推移的逆依存matrix|CLI全target照合|workspace check／Clippy・fmt・構造gate) \|'})
$metrics=@(Import-Csv -LiteralPath "$taskTemp/callable-input-order-native.structure-report/file_metrics.csv"|Where-Object path -in $publication.paths.path)
if($metrics.Count -ne 23){throw 'Missing current measurements'}
$metrics|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/callable-input-order-native.owner-metrics.json" -Encoding utf8
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like 'callable-input-order-native*'})
$files+=@(Get-ChildItem -LiteralPath "$taskTemp/callable-input-order-native.structure-report" -File -Recurse)
foreach($name in @('record-native-input-order.ps1','run-native-input-order-structure.ps1','run-presentation-projection-owner.ps1','audit-nextest-final-result.ps1','write-verified-evidence-archive.ps1')){$files+=Get-Item -LiteralPath "$taskTemp/$name"}
$root=[IO.Path]::GetFullPath($taskTemp)
$index=@(foreach($file in @($files|Sort-Object FullName -Unique)){[ordered]@{entry=$file.FullName.Substring($root.Length+1).Replace([IO.Path]::DirectorySeparatorChar,[char]'/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
$index|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$taskTemp/callable-input-order-native.archive-inputs.json" -Encoding utf8
$files+=Get-Item -LiteralPath "$taskTemp/callable-input-order-native.archive-inputs.json"
. "$taskTemp/write-verified-evidence-archive.ps1"
$archive='docs/implementation/acceptance-evidence/task-callable-input-order-native.raw.zip'
$raw=Write-VerifiedEvidenceArchive $root ([IO.Path]::GetFullPath((Join-Path $PWD $archive))) $files
$record.callableInputOrder.nativeFrames=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$publication
    state='Intermediate Native/PureEvaluator scope transport. AWBC frames, explicit external forwarding and final alias/full-goal acceptance remain pending.'
    implementation=@('Pass the complete RuntimeCallableInvocation to synchronous and suspended Native function ingress. RuntimeFunctionInputAdmission projects its order through actual Capture/CapturedParameter/Parameter coordinates and shares its owned pattern binder with PureEvaluator; delete the duplicate pure binder.','RuntimeScopeFunctionContext replaces the narrower type-only name and owns site, original effect/type instantiation and immutable Arc<RuntimeInputOrder>. Root/program/reducer/callback/deferred activation, suspended await/fanout and environment rollback preserve the scope context. Original-site/arity/resource admission precedes retained snapshots.','RuntimeProgramExecutionContext leases the current scope order through Native and pure external-call bridges. Arc cloning does not duplicate the permutation payload. New direct host/program ingress constructs positional order explicitly; applied invocations retain their actual order. No legacy alias, provider-name special case or version increase.')
    validation=[ordered]@{owner=$runtime;command=(Read-Record 'callable-input-order-native-owner4-20261105.runtime').command;scope='One full Core library/all-features/locked run:2273/2273 PASS,0 skipped. New noncanonical Native activation scope survives authenticated environment rollback and the original-program external execution context. This does not establish public Native session-save or alias composition acceptance.';sourceRelation='4105 frozen repository inputs on53defec18dcc581789b22ac40f61d2079cf24955 plus23 paths published asbfb7e39cb26299185cf498e1ad8ec16e33b02e10. Source/case/executable drift0; observed working tree/relevant original WIP, not pristineHEAD.';initialCatalog=(Read-Record 'callable-input-order-native-owner1-20261105.catalog');initialReason='Compile101 from two fixture-relative imports and a private error constructor; corrected without widening visibility.';earlierFull=(Read-Record 'callable-input-order-native-owner2-20261105.runtime.terminal-audit');earlierReason='2269 PASS/3 FAIL: existing fixtures declared0 input slots for an original function with1 input. The new arity check rejected them before projection. Correct fixtures to canonical1; keep budgets/cases/affine checks unchanged.';repairSubset=(Read-Record 'callable-input-order-native-owner3-20261105.runtime.terminal-audit');repairScope='Separate3/3 run,2269 skipped. It is not merged with the earlier full run. Owner4 later provides its own full2273 result.';fmt='All23 changed Rust paths fmt/whitespace0.';structure=$structure}
    graphReuse=[ordered]@{record='callableInputOrder.validation.graph';source='466c2d7bf8245d1f7dd0c3560db27d0d2f53f893';roots=@('arcweft-core','arcweft-rich-text-schema','arcweft-dialogue','arcweft-lang-sema','arcweft-runtime-plan');reversePackages=58;checkedManifestInputs=$manifests.Count;manifestDrift=0;reason='No Cargo input changed from the recorded metadata/tree0-difference graph. Full58 runtime and98 check/Clippy remain pending.'}
    ownershipReview='Current23-path exact owner/physical/code/embedded-test LOC and full structure metrics are archived. Function scope now owns its complete original execution context. Invocation/input projection and pattern binding stay in the admitted plan boundary; synchronous/suspended evaluators consume it. Existing callback/deferred ownership and Sans-I/O direction remain intact. No crate/dependency/API widening for file splitting. Scanner98 packages,385 review triggers,0 blocking.'
    correctionReason='Supersedes only the Native/PureEvaluator portion of source466 remaining text, which is historical for that source. AWBC frame/provider forwarding is still open. Current status lists this implemented Native boundary without claiming the actual alias regression is fixed or reopening accepted Generic Match.'
    supersededCurrentRows=$oldRows;historyPrefix=$historyPrefix
    raw=[ordered]@{path=$archive;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0;indexEntry='callable-input-order-native.archive-inputs.json'}
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
$sha=$publication.commit
$rows=@(foreach($line in ($status -split "`n")){
    if($line.StartsWith('| RichTextの部分layout指定／source factory |')){"| RichTextの部分layout指定／source factory | **既受入を維持。Nativeの順序contextを中間公開、AWBC・provider・単位は継続** | Source ${sha}でcallableの順序をNative／PureEvaluatorの関数scope・認証付きrollback・元programの外部呼出しcontextへ接続した。Core library2273／2273 PASS、非標準順序の保持を確認。AWBC frameと外部宣言wrapperの順序転送は未接続で、alias合成の受入とはしない。直近のfactory実測Source187fb586261ac6ba381546532143fa20854dba8bはpt合成が直接24pt／alias11pt、px2条件もpt限定schemaでFAIL。単位consumer・typed bare serif・static inline_stylesと全体受入を継続する。部分layout・共通property等の既受入は維持する。[Nativeの実測・旧失敗・公開SHA・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |"}
    elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){$line.Replace('中間Source466c2d7bf8245d1f7dd0c3560db27d0d2f53f893',"中間Source$sha").Replace('Core library2272件','Core library2273件')}
    elseif($line.StartsWith('| CLI全target照合 |')){$line.Replace('中間Source 466c2d7bf8245d1f7dd0c3560db27d0d2f53f893',"中間Source $sha")}
    elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){$line.Replace('Source466c2d7bf8245d1f7dd0c3560db27d0d2f53f893は変更Rust28件',"Source${sha}は変更Rust23件")}
    else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@"

## 2026-11-05 — Native invocation scope provenance

- Source $sha (parent $($publication.parent)) publishes23 Rust paths: complete invocation ingress, one admitted Native/PureEvaluator pattern binder, and RuntimeScopeFunctionContext with original site/type instantiation plus immutable order lease. Native external execution context and authenticated environment rollback retain the actual order.
- Keep catalog101 (fixture imports/private constructor), full2272 run2269 PASS/3 FAIL (0-slot fixture vs original1-input function), separate repair3/3 and final independent full2273/2273 PASS/0 skipped. All4105 repository inputs/cases/executables have0 drift. New noncanonical scope/rollback/context case passes; no public Native session-save or alias acceptance claim. Budget/copy/affine/OneOp conditions are unchanged.
- Changed23 Rust fmt/whitespace and98-package structure gate exit0,385 review triggers/0 blocking. The58-package graph remains valid with all Cargo inputs unchanged; full58 runtime/98 check/Clippy remain pending. This supersedes only the older Native-unconnected current statement. AWBC frame and provider forwarding, actual alias/px failures and other concrete RichText conditions remain open; accepted Generic Match remains accepted. [All raw attempts, measurements and SHAs](acceptance-evidence/task-rich-text-property-identity.json); [one current list](current-status.md).
"@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw|ConvertFrom-Json -AsHashtable -Depth 100
foreach($key in $before.Keys){if($key -eq 'callableInputOrder'){foreach($child in $before[$key].Keys){if(($before[$key][$child]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key][$child]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous child changed'}}}elseif(($before[$key]|ConvertTo-Json -Depth 100 -Compress) -ne ($after[$key]|ConvertTo-Json -Depth 100 -Compress)){throw 'Previous field changed'}}
$now=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($history.Length);[Array]::Copy($now,$prefix,$history.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $historyPrefix.sha256){throw 'History prefix changed'}
[ordered]@{source=$sha;priorFieldDrift=0;historyPrefixDrift=0;rawEntries=$raw.entries.Count;rawBytes=$raw.bytes;rawSha256=$raw.sha256;manifestInputs=$manifests.Count;manifestDrift=0}|ConvertTo-Json -Compress
