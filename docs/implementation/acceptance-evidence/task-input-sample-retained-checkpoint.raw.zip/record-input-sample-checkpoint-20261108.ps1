$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$publication=Read-Record 'input-sample-migration-20261108.source-checkpoint.verified.json'
if((git rev-parse HEAD).Trim() -ne $publication.commit){throw 'Checkpoint head changed'}
$archive='docs/implementation/acceptance-evidence/task-input-sample-retained-checkpoint.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$raw=@(Get-ChildItem -LiteralPath $r -File -Filter 'input-sample-migration-20261108*'|Where-Object Extension -ne '.pathspec')+@((Get-Item "$r/inspect-input-sample-hir.rs"),(Get-Item $PSCommandPath))
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in ($raw|Sort-Object FullName -Unique)){
    if($file.Extension -notin @('.json','.log','.txt','.patch','.rs','.ps1')){throw 'Unexpected raw artifact'}
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$count=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact in archive'}}finally{$zip.Dispose()}
$entry=[ordered]@{
    version=1;date='2026-11-08';publication=$publication;acceptance='Checkpoint only; the complete Source samples are not accepted.'
    baseline=@(foreach($sample in @('native-text-input','text-submit-flow','modern-feedback-view','focus-navigation-controller-dsl')){[ordered]@{sample=$sample;receipt=(Read-Record "input-sample-migration-20261108.$sample.baseline.json");rawDiagnostic=(Get-Content "$r/input-sample-migration-20261108.$sample.baseline.log" -Raw)}})
    baselineWrapperCorrection='All four CLI checks emitted text diagnostics before JSON reporting. The initial wrapper incorrectly attempted ConvertFrom-Json; status is null in those receipts. Exit code 1, exact original Source/manifest/main hashes and the actual text diagnostics remain authoritative. These are Source-check denials, not executed Rust/runtime test failures.'
    finalNative=(Read-Record 'input-sample-migration-20261108.native-text-input.check-r2.json');finalNativeDiagnostic=(Get-Content "$r/input-sample-migration-20261108.native-text-input.check-r2.log" -Raw)
    finalSubmit=(Read-Record 'input-sample-migration-20261108.text-submit-flow.check-r1.json');finalSubmitDiagnostic=(Get-Content "$r/input-sample-migration-20261108.text-submit-flow.check-r1.log" -Raw)
    diagnosis=@('Native multiline embedded expression was a required HIR recovery. The same function call is now written in one inline expression; both authored iterations and narrative content remain. Final HIR is admitted and the next refusal is nominal type slot 41, mapped by the genuine HIR type/source API to FontFamilyList.','String.len is intentionally unavailable in the current collection signature schema. The text-submit sample must keep its empty/short/long branches and use an explicitly defined text-counting unit, not drop or literal-stub the counter.','Style tokens are retained in HIR but compiler/style.rs rejects nonempty token inventories. The current Style expression checker handles Length and Color; FontFamilyList, font/system palette values and typed token dependency resolution need completion. Do not inline away the authored font stacks or remove Style to make the sample pass.')
    migrations=@('Native three controls and feedback form use owned local state mut String fields with original input PublicIds, labels, placeholders, purpose and Enter-key hints. SecureField remains secure.','Both views use actual mount handles. Submit and click return the original feedback.submit Action with the retained field, and the flow awaits the original typed channel.','The Send button retains enabled=true. The removed focusable(true) spelling is represented by the existing enabled action-control keyboard focus behavior; no disabled/false focus setting was removed. Existing Style and every response branch remain.')
    next='Complete canonical read-only String operations/counting, typed Style values and token resolution; then finish the four samples and actual runtime/display verification. Scroll/Panel products and focus-navigation Source grammar remain independent necessary boundaries.'
    preservedAcceptance='Generic Match, retained String input, public target, IME hint, placeholder/label separation and all other accepted cuts remain accepted. Their previous test runs retain their original Source scope.'
    raw=[ordered]@{path=$archive;entries=$count;bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();containsExecutables=$false}
}
$path='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$base=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$path))))
$prior=$base|ConvertFrom-Json -Depth 100 -DateKind String
if($prior.PSObject.Properties.Name -contains 'retainedInputSampleCheckpoint'){throw 'Checkpoint entry exists'}
$wrapper=[ordered]@{retainedInputSampleCheckpoint=$entry}|ConvertTo-Json -Depth 100
$inner=$wrapper.Substring($wrapper.IndexOf('{')+1).TrimEnd();$inner=$inner.Substring(0,$inner.LastIndexOf('}')).TrimEnd()
$new=$base.TrimEnd();$new=$new.Substring(0,$new.LastIndexOf('}')).TrimEnd()+','+"`n"+$inner+"`n}`n"
$after=$new|ConvertFrom-Json -Depth 100 -DateKind String
foreach($p in $prior.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($p.Name)|ConvertTo-Json -Depth 100 -Compress)){throw 'Historical record drift'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $path),$new,[Text.UTF8Encoding]::new($false))
$currentPath='D:/git/arcweft/docs/implementation/current-status.md'
$lines=@([IO.File]::ReadAllLines($currentPath))
for($i=0;$i -lt $lines.Count;$i++){
    if($lines[$i].StartsWith('確認日 ')){$lines[$i]='確認日 2026-11-08、観察Source `'+$publication.commit+'`。項目ごとの受入・公開Sourceと検証範囲を下表で独立して追跡する。入力sample 2件の保持入力／実mount移行は中間公開で、sample全体は未受入。tracked実装WIPは0、4 actual untrackedのローカルcacheは保持している。'}
    if($lines[$i].StartsWith('| View の保持 String 入力／公開target・IME hint・placeholder |')){$lines[$i]=$lines[$i].Replace('旧sample移行・Scroll fixture・実Native／Web表示は別の継続条件。','旧sample 2件は保持String・実mount・元Actionへ中間移行（Source `'+$publication.commit+'`）。NativeはFontFamilyList型、text-submitはString.lenで拒否され、sample全体の受入は未了。Style token・残るsample・Scroll・実Native／Web表示を継続する。')}
}
[IO.File]::WriteAllText($currentPath,($lines -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
$history=''+"`n"+'## 2026-11-08 — 入力sampleの保持値／mount移行checkpoint'+"`n`n"+'Source `'+$publication.commit+'` はNative Text InputとText Submitの2 Sourceだけの中間移行で、sample全体の受入ではない。元の入力ID・3種のcontrol・hint・Style・Action・送信後の分岐を保ち、保持Stringと実mount／await receiveへ揃えた。'+"`n`n"+'元の4 sampleはいずれもsyntax／HIR段階で拒否されていた。移行後はNativeがFontFamilyList型の解決拒否、text-submitがString.lenのunknown methodへ進んだ。Nativeの複数行埋込みは同じ関数呼出しをinlineで保持し、HIRの型／元Source APIで次の拒否のslot 41を特定した。文字数分岐やfont tokenを除去する回避は行わない。現行compilerは非空Style tokenを明示拒否するため、その正規の型付き経路を完成させる。'+"`n`n"+'初回wrapperがJSON前のテキスト診断を誤ってJSON parseした事実と、調査toolの初回compile失敗もrawに保持する。Source checkの拒否をruntime test失敗や受入へ読み替えない。既存139 recordと既受入Generic Match／View cutを変更せず、現状のsample継続条件だけを具体化した。'+"`n`n"+'原本 `'+$entry.raw.path+'` は'+$entry.raw.entries+' entry／'+$entry.raw.bytes+' bytes、SHA256 `'+$entry.raw.sha256+'`。実行ファイル・生成AWFBは含まない。詳細はregistryの `retainedInputSampleCheckpoint`。'+"`n"
Add-Content docs/implementation/convergence-evidence-history.md $history -Encoding utf8
[ordered]@{source=$publication.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;raw=$entry.raw}|ConvertTo-Json -Depth 8|Set-Content "$r/input-sample-migration-20261108.checkpoint-record.json" -Encoding utf8
Get-Content "$r/input-sample-migration-20261108.checkpoint-record.json" -Raw
