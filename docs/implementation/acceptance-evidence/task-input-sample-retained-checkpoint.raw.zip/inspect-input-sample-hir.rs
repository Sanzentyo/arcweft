#!/usr/bin/env cargo +nightly -Zscript
---cargo
[dependencies]
arcweft-lang-hir = { path = "D:/git/arcweft/crates/arcweft-lang-hir" }
arcweft-lang-syntax = { path = "D:/git/arcweft/crates/arcweft-lang-syntax" }
arcweft-source = { path = "D:/git/arcweft/crates/arcweft-source" }
---
use std::sync::Arc;
use arcweft_lang_hir::{database::HirDatabase, lowering::{HirModuleKey, LoweringRequest, HirLoweringControl}, proof_return::HirProofReturnSemanticFactSet, symbol::{CallablePackageId, ProjectSymbolWorldId, ProjectSymbolRevision}};
use arcweft_lang_syntax::{ast::module_path::CanonicalModulePath, incremental::SyntaxDatabase, parser::ParseOptions};
use arcweft_source::{SourceDocument, SourceDocumentId, SourceName, identity::SourceSnapshotId};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    for path in std::env::args().skip(1) {
        let text = std::fs::read_to_string(&path)?;
        let name = SourceName::path(&path);
        let document = Arc::new(SourceDocument::try_new(SourceDocumentId::try_new("arcweft-diagnostic://input-sample")?, name.clone(), text.as_str())?);
        let mut syntax = SyntaxDatabase::try_new()?;
        let parsed = syntax.parse_initial(SourceSnapshotId::initial(name), document, ParseOptions::default())?;
        let package = CallablePackageId::try_new("arcweft-diagnostic.input-sample")?;
        let key = HirModuleKey::new(package.clone(), CanonicalModulePath::crate_root(), parsed.document().identity().clone());
        let world = ProjectSymbolWorldId::try_new(package, parsed.document().identity().id().clone(), "hir-inspect")?;
        let revision = ProjectSymbolRevision::try_for_documents([parsed.document().identity()])?;
        let mut database = HirDatabase::try_new()?;
        let transaction = database.stage_proof_return_project([LoweringRequest::try_new(key, &parsed)?], world, revision, [parsed.document().identity()], HirLoweringControl::new())?;
        let facts = HirProofReturnSemanticFactSet::try_new(Arc::clone(transaction.generation()), transaction.headers().cloned(), [])?;
        let outputs = transaction.publish_with_semantic_facts(&mut database, facts)?;
        println!("{path}");
        for output in outputs {
            let module = output.into_module();
            println!("{:#?}", module.diagnostics());
            for (id, ty) in module.types() {
                let span = module.source_anchor(arcweft_lang_hir::source_index::HirSourceQuery::Type { owner: id, role: arcweft_lang_hir::source_index::HirTypeSourceRole::Whole })?;
                if let Some(span) = span { println!("{id:?} {ty:?}: {:?}", text.get(span.range().start()..span.range().end())); }
            }
        }
    }
    Ok(())
}
