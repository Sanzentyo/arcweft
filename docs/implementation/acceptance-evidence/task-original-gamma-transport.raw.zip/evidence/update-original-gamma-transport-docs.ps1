$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/original-gamma-transport.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/original-gamma-transport.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/original-gamma-transport.consumer-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/original-gamma-transport.archive.json"|ConvertFrom-Json
if((git rev-parse HEAD) -cne $pub.Source -or @(git diff --name-only HEAD).Count -or $owner.Passed -ne 1685 -or $consumers.Passed -ne 2507){throw 'Final source or evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$status=[IO.File]::ReadAllText($statusPath)
$historyBytes=[IO.File]::ReadAllBytes($historyPath)
$accepted=[regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value
if(!$accepted){throw 'Accepted Generic Match row missing'}
[ordered]@{Version=1;Source=$pub.Source;StatusSHA256=(Get-FileHash $statusPath).Hash;HistorySHA256=(Get-FileHash $historyPath).Hash;HistoryBytes=$historyBytes.Length;AcceptedGenericMatch=$accepted;FrozenArchives=@(git ls-files 'docs/implementation/acceptance-evidence/*.zip' | ForEach-Object { [ordered]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_).Hash} })}|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/original-gamma-transport.docs-before.json"
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `647403f016195194eb252876ec5e57ecfa3095c6`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
$rows=[ordered]@{}
$name='再帰関数値の終端効果'
$row=[regex]::Match($status,'(?m)^\| '+$name+' \|[^\r\n]*').Value
$row=$row.Replace('残るのはreify入力','productionの元値・checked source値はSource `'+$pub.Source+'` で元Γの実frameを検査してから受取scopeへ移し、同形の別frameを拒否する。型・const・効果・predicateと局所binderを含む新4件がPASS。残るのはreify入力')
$row=$row.Replace('引数全体の実Γ','推論参照を含む引数全体の実Γ')
$row=$row.Replace('[fixtureのΓ](convergence-evidence-history.md#explicit-fixture-source-gamma)。','[fixtureのΓ](convergence-evidence-history.md#explicit-fixture-source-gamma)・[実frameの受渡し](convergence-evidence-history.md#original-gamma-admission-and-transport)。')
$rows[$name]=$row
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,685 PASS／6 FAIL。後続21 packageは2,507 PASS／2 FAIL／1 SKIP** | Source `'+$pub.Source+'` でlocked・全feature Sema lib／testsの1,691件を71.556秒で実行。選択と終端の全ID一致・重複0、直前1,687 IDを維持、新4件がPASS。既知6失敗のID・5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。同じSourceの後続21 package・規定107 targetは2,510 IDを実行し、選択・終端ID一致。Compiler既知2失敗も同じExpressionCycle slot 17／19。CLI 226件とcallable_execution 376件はPASS。owner全featureとconsumer既定featureは別sliceとして原本に保持する。今回のproduction変更に対して直前consumer結果の再利用という旧説明を置換した。[今回の全原本・入力・失敗](acceptance-evidence/task-original-gamma-transport.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace check／Clippy・fmt・構造gateが終了0** | Source `'+$pub.Source+'` のlocked workspace全target／全feature check／Clippy、workspace fmt、Sema doctest 2件を実行。owner Clippyはworkspace実行に包含する。現在のCargo graphからSemaを含む逆依存22 packageを照合し、Cargo入力の変更0を確認した。全10変更pathのbyte pin・公開blobと各step前後のSource／tree／tracked差分0を照合。実frame境界の修復とcut全体302物理LOC増を対象にowner責任を確認し、構造gateはblocking 0。警告は原本に保持する。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持し、今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web受入とはしない。[今回の品質・構造・依存graph原本](acceptance-evidence/task-original-gamma-transport.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **最新Sourceの規定226件PASS。全 check は未再実行** | Source `'+$pub.Source+'`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS、binはcompile済み・runnable test 0件。production ingressの変更に対して、以前の「直前Sourceの再利用」という説明を今回の実行結果へ置換した。全checkの再実行は含めない。以前の入力・件数・失敗は履歴と原本に保持する。[今回の実行原本](acceptance-evidence/task-original-gamma-transport.raw.zip)。 |'
foreach($name in $rows.Keys){$pattern='(?m)^\| '+[regex]::Escape($name)+' \|[^\r\n]*';if([regex]::Matches($status,$pattern).Count -ne 1){throw 'Current row not unique'};$replacement=$rows[$name];$status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match)$replacement})}
if([regex]::Match($status,'(?m)^\| Generic Match[^\r\n]*').Value -cne $accepted){throw 'Accepted feature status changed'}
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$note=@"

## Original gamma admission and transport

2026-11-13。実装・公開 Source ``$($pub.Source)``、tree ``$($pub.Tree)``、parent ``$($pub.Parent)``。既存mainで10 Rust pathをcommit／非force pushし、公開headと全変更blobを照合。tracked差分0、未追跡 ``%SystemDrive%/`` を保持した。

- 元のΓを受取scopeの形で読み直す不具合を修復した。実frame identityを所有するlexical transportへ型・const・効果の参照変換を集約し、元Γでのadmissionと受取scopeへの変換を一つの制御付きfoldにした。Fnの局所binderは保持し、ambient参照だけを移す。checked source値もport選択の前に同じ境界へ通す。旧constructorを置換し、別readerを残さない。
- 開発時の旧Sourceでは初期2回帰が0 PASS／2 FAIL。修復過程の7件の引数不足compile error、修復後16件、正しい256候補selectorを含む最終17件PASSを区別して原本に保持した。最初のnegative回帰は最終版でconst・効果・単独length拒否も検査するよう拡張した。旧runを最終test sourceの実行とは扱わない。
- 全feature ownerは1,691件／1,685 PASS／6 FAIL／0 SKIP、71.556秒、slow 0。直前1,687 IDをすべて保持し、新4件PASS。選択・終端ID一致、重複0。既知6失敗と実診断5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。
- 現在のCargo metadataとinvertから全22 packageを確認し、後続21 package・107 targetを同じSourceで実行した。2,510 ID／2,507 PASS／2 FAIL／1 SKIP。Compilerの既知2失敗は同じExpressionCycle slot 17／19。CLI 226、callable_execution 376がPASS。3 targetはcompile-only。過去のconsumer runへ最新Sourceを付け替えていない。
- locked workspace全target／全feature check／Clippy、fmt、Sema doctest 2件は終了0。structure-audit-gateも終了0。変更10 pathは302物理LOC増。lexical.rsは328 LOCで実frame対応の唯一のowner、original_value.rsは225 LOCで元値のadmission、operand.rsは498 LOCで由来を保持する。transaction.rsは2,741 LOCだがこのcutは既存probe orchestrationのscope捕捉位置を2 LOC増で移すだけで、新しい状態や別の責務を加えない。テストは各ownerへ配置し、型walker・frame表・権限表の複製を追加しない。Cargo依存・公開API・layer方向・unsafe・依存追加なし。サイズだけを理由とする分割は行わない。実寸・fan-in／fan-out・全警告は原本に保持する。
- Supersedes: 現状一覧の「consumerとworkspace品質は過去Sourceの実測を再利用」という説明は、今回production ingressを変更して同じSourceで再実行したため置換した。以前の実測・full SHA・原本は履歴として保持する。Generic Match、caller-bound recursion、共有prefixの受入判定は維持する。
- 本cutの受入範囲は元値・checked source値のBound参照admissionと実frame間の移送である。項目別の現状・残作業は[current-status.md](current-status.md)の一か所へ集約する。

原本 [task-original-gamma-transport.raw.zip](acceptance-evidence/task-original-gamma-transport.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$($archive.SHA256.ToLowerInvariant())``。全entryのpath・長さ・SHA-256をreadback検証した。
"@
$append=[Text.UTF8Encoding]::new($false).GetBytes($note)
$stream=[IO.File]::Open($historyPath,[IO.FileMode]::Append,[IO.FileAccess]::Write)
try{$stream.Write($append)}finally{$stream.Dispose()}
Write-Output 'Updated four current rows and appended evidence history'