$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$root=$PSScriptRoot
$pub=Get-Content -Raw "$root/original-gamma-transport.publication.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/original-gamma-transport.docs-before.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/original-gamma-transport.archive.json"|ConvertFrom-Json
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$status=[IO.File]::ReadAllText($statusPath)
$historyBytes=[IO.File]::ReadAllBytes($historyPath)
$prefix=[byte[]]::new([int]$before.HistoryBytes)
[Array]::Copy($historyBytes,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -cne $before.HistorySHA256){throw 'History prefix changed'}
$added=[Text.Encoding]::UTF8.GetString($historyBytes,$prefix.Length,$historyBytes.Length-$prefix.Length)
if([regex]::Matches($added,'(?m)^## Original gamma admission and transport\r?$').Count -ne 1){throw 'Historical section is not unique'}
if(@(Compare-Object -CaseSensitive $before.AcceptedGenericMatch @(Get-Content $statusPath|Where-Object {$_ -match '^\| Generic Match'})).Count){throw 'Accepted Generic Match row changed'}
$rows=@('再帰関数値の終端効果','再帰本体の型表現／Semaの推移的逆依存','CLIの規定対象／全 check 照合','workspace check／Clippy・fmt・構造gate')
$surfaces=[Collections.Generic.List[object]]::new()
foreach($row in $rows){
    $matches=[regex]::Matches($status,'(?m)^\| '+[regex]::Escape($row)+' \|[^\r\n]*')
    if($matches.Count -ne 1 -or (!$matches[0].Value.Contains($pub.Source) -and $row -ne 'CLIの規定対象／全 check 照合')){throw 'Current row is stale or duplicated'}
    $surfaces.Add([pscustomobject]@{File=$statusPath;Text=$matches[0].Value})
}
$surfaces.Add([pscustomobject]@{File=$historyPath;Text=$added})
$links=[Collections.Generic.List[object]]::new()
foreach($surface in $surfaces){
    foreach($match in [regex]::Matches($surface.Text,'\]\(([^)]+)\)')){
        $target=$match.Groups[1].Value
        if($target -match '^https?://'){continue}
        $parts=$target.Split('#',2)
        $path=[IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetDirectoryName($surface.File)) $parts[0]))
        if(!(Test-Path -LiteralPath $path -PathType Leaf)){throw "Missing changed link: $target"}
        if($parts.Count -eq 2){
            $headings=@(Get-Content $path|Where-Object {$_ -match '^#{1,6} '}|ForEach-Object {($_ -replace '^#{1,6} ','').ToLowerInvariant() -replace '[^a-z0-9 -]','' -replace ' ','-'})
            if($headings -cnotcontains $parts[1]){throw "Missing changed anchor: $target"}
        }
        $links.Add([pscustomobject]@{File=$surface.File;Target=$target;Resolved=$path})
    }
}
foreach($frozen in $before.FrozenArchives){if((Get-FileHash -LiteralPath $frozen.Path).Hash -cne $frozen.SHA256){throw 'Existing frozen archive changed'}}
if((Get-FileHash $archive.Path -Algorithm SHA256).Hash -cne $archive.SHA256){throw 'Frozen ZIP changed'}
foreach($p in $pub.Paths){if((git hash-object -- $p.Path) -ne $p.Blob -or (Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -cne $p.SHA256){throw 'Tested Rust source changed'}}
git diff --check
if($LASTEXITCODE -ne 0){throw 'Whitespace validation failed'}
[ordered]@{Version=1;Source=$pub.Source;Tree=$pub.Tree;CurrentRows=4;GenericMatchUnchanged=$true;HistoryPrefixBytes=$prefix.Length;HistoryPrefixSHA256=$before.HistorySHA256;ChangedLinks=@($links.ToArray());ArchiveSHA256=$archive.SHA256;RustPinsUnchanged=$true}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/original-gamma-transport.docs-validation.json"
Write-Output "Documentation verified: four current rows, $($links.Count) links, unchanged Generic Match and historical prefix."
