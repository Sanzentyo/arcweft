$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$publication=Get-Content -Raw "$root/original-gamma-transport.publication.json"|ConvertFrom-Json
$quality=Get-Content -Raw "$root/original-gamma-transport.owner-validation.json"|ConvertFrom-Json
$baseline=Get-Content -Raw "$root/fixture-source-gamma.owner-terminal.json"|ConvertFrom-Json
$previous=Get-Content -Raw "$root/fixture-source-gamma.owner-summary.json"|ConvertFrom-Json
if($quality.Source -ne $publication.Source -or $quality.Tree -ne $publication.Tree -or $quality.Steps.Count -ne 3){throw 'Owner input differs'}
foreach($step in $quality.Steps){
    $expected=if($step.Name -eq 'owner-run'){100}else{0}
    if($step.ExitCode -ne $expected -or !$step.SourcePinsVerified){throw 'Owner step outcome differs'}
    if((Get-FileHash "$root/$($step.Output)" -Algorithm SHA256).Hash -ne $step.OutputSHA256 -or (Get-FileHash "$root/$($step.Log)" -Algorithm SHA256).Hash -ne $step.LogSHA256){throw 'Owner output changed'}
}
$log=[IO.File]::ReadAllText("$root/original-gamma-transport.owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1691 tests run: 1685 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Owner terminal summary differs'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1691\) (\S+) (.+)\r?$')|ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/original-gamma-transport.owner-list.json"|ConvertFrom-Json
$ids=@(foreach($suite in $listing.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$suite.Name+'$'+$case.Name}}})
if($ids.Count -ne 1691 -or $terminal.Count -ne 1691 -or @($terminal|Group-Object Id|Where-Object Count -GT 1).Count -or @(Compare-Object -CaseSensitive @($ids|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Owner selected and terminal IDs differ'}
$delta=@(Compare-Object -CaseSensitive @($baseline.Id|Sort-Object) @($ids|Sort-Object))
if($delta.Count -ne 4 -or @($delta|Where-Object SideIndicator -CNE '=>').Count){throw 'Baseline test IDs changed'}
$new=@($terminal|Where-Object {$delta.InputObject -ccontains $_.Id})
if($new.Count -ne 4 -or @($new|Where-Object Result -CNE 'PASS').Count){throw 'New authority regressions did not pass'}
$failed=@($terminal|Where-Object Result -CEQ 'FAIL'|ForEach-Object Name|Sort-Object)
if(@(Compare-Object -CaseSensitive $previous.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Actual owner failures changed'}
$cargoDiff=@(git diff --name-only $previous.Source HEAD -- Cargo.toml Cargo.lock .cargo ':(glob)**/Cargo.toml')
if($cargoDiff.Count){throw 'Dependency graph inputs changed'}
$measurements=@(foreach($p in $publication.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($publication.Source):$($p.Path)") -ne $p.Blob){throw 'Published input changed'}
    $old=@(git show "$($publication.ChangeBase):$($p.Path)" 2>$null);$baseLines=if($LASTEXITCODE -eq 0){$old.Count}else{0}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    [pscustomobject]@{Path=$p.Path;Bytes=(Get-Item -LiteralPath $p.Path).Length;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;SHA256=$p.SHA256;Blob=$p.Blob}
})
if($measurements.Count -ne 10 -or (git rev-parse HEAD) -ne $publication.Source -or (git rev-parse 'HEAD^{tree}') -ne $publication.Tree -or @(git diff --name-only HEAD).Count){throw 'Final source identity differs'}
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/original-gamma-transport.owner-terminal.json"
[ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Parent=$publication.Parent;Selected=1691;Passed=1685;Failed=6;Skipped=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;IdsEqual=$true;Duplicates=0;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);SlowTests=if($summary.Groups['slow'].Success){[int]$summary.Groups['slow'].Value}else{0};Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;Baseline=$previous.Source;ClippyCoveredByWorkspace=$true;FmtExit=0;SourcePinsVerified=$true;Measurements=$measurements;GraphCargoInputsUnchanged=$true;ReverseGraphEvidence='original-gamma-transport.metadata.json';ConsumerTestsRerun=$true;ConsumerDisposition='Actual source-frame admission and target transport change a shared production ingress; all reverse consumers are validated separately at the same source.'}|ConvertTo-Json -Depth 8|Set-Content -Encoding utf8 "$root/original-gamma-transport.owner-summary.json"
Get-Content -LiteralPath "$root/original-gamma-transport.owner-summary.json" -TotalCount 18


