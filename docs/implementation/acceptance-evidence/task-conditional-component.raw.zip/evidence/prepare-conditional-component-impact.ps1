$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$metadata=Get-Content -Raw "$root/conditional-component.metadata.json"|ConvertFrom-Json
$owner=@($metadata.packages|Where-Object name -CEQ 'arcweft-lang-sema')
if($owner.Count -ne 1){throw 'Owner package identity is ambiguous'}
$closure=[Collections.Generic.HashSet[string]]::new()
[void]$closure.Add($owner[0].id)
do {
    $changed=$false
    foreach($node in $metadata.resolve.nodes){
        if(-not $closure.Contains($node.id)){
            foreach($dependency in $node.deps){
                if($closure.Contains($dependency.pkg)){$changed=$closure.Add($node.id) -or $changed;break}
            }
        }
    }
} while($changed)
$packages=@($metadata.packages|Where-Object {$closure.Contains($_.id)}|Sort-Object name)
$plan=Get-Content -Raw "$root/inference-source-gamma-compiler/inference-source-gamma-compiler-plan.json"|ConvertFrom-Json
if(@(Compare-Object -CaseSensitive @($packages.name) @($plan.closure|Sort-Object)).Count){throw 'Consumer closure changed; must regenerate target plan'}
foreach($suffix in @('reverse','compiler')){
    $destination="$root/conditional-component-$suffix"
    [void](New-Item -ItemType Directory -Path $destination -Force)
    if($suffix -eq 'reverse'){
        Copy-Item -LiteralPath "$root/inference-source-gamma-reverse/plan.json" -Destination "$destination/plan.json"
    }else{
        Copy-Item -LiteralPath "$root/inference-source-gamma-compiler/inference-source-gamma-compiler-plan.json" -Destination "$destination/conditional-component-compiler-plan.json"
    }
    (Get-Content -Raw "$root/inference-source-gamma-$suffix/run.ps1").Replace('inference-source-gamma','conditional-component')|Set-Content -Encoding utf8 "$destination/run.ps1"
}
(Get-Content -Raw "$root/run-inference-source-gamma-broad.ps1").Replace('inference-source-gamma','conditional-component')|Set-Content -Encoding utf8 "$root/run-conditional-component-broad.ps1"
[ordered]@{Version=1;Owner=$owner[0].id;Packages=$packages.name;PackageIds=$packages.id;PackageCount=$packages.Count;DependencyKinds='all normal/dev/build edges from full all-feature resolved metadata';PreviousTargetInventoryReused=$true;CurrentClosureEqual=$true;TargetCount=107;InventoryWillBeComparedDuringEachList=$true;MetadataSHA256=(Get-FileHash "$root/conditional-component.metadata.json" -Algorithm SHA256).Hash}|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/conditional-component.impact.json"
Write-Output "Current graph: $($packages.Count) packages; prior complete 107-target inventory retained for live list comparison"
