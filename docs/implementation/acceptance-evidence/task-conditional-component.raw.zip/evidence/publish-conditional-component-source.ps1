$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/conditional-component.publication.json"|ConvertFrom-Json
if((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Publication source changed'}
foreach($path in $pub.Paths){if((git hash-object -- $path.Path) -ne $path.Blob){throw 'Source bytes changed'}}
& pwsh -NoProfile -File "$root/audit-conditional-component-consumers.ps1"
if($LASTEXITCODE){throw 'Consumer audit failed'}
git fetch origin main > "$root/conditional-component.source-fetch.log" 2>&1
if($LASTEXITCODE){throw 'Fetch failed'}
$remote=(git rev-parse origin/main).Trim()
if($remote -notin @($pub.Parent,$pub.Source)){throw 'Remote moved; reconcile before publication'}
git push origin main > "$root/conditional-component.source-push.log" 2>&1
if($LASTEXITCODE){throw 'Source push failed'}
$observed=(git ls-remote origin refs/heads/main).Split()[0]
if($LASTEXITCODE -or $observed -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source){throw 'Published remote head differs'}
foreach($path in $pub.Paths){if((git rev-parse "origin/main:$($path.Path)") -ne $path.Blob){throw 'Published source blob differs'}}
$pub.Pushed=$true
$pub|Add-Member -NotePropertyName RemoteObserved -NotePropertyValue $observed -Force
$pub|Add-Member -NotePropertyName Published -NotePropertyValue (Get-Date -Format o) -Force
$pub|ConvertTo-Json -Depth 7|Set-Content -Encoding utf8 "$root/conditional-component.publication.json"
Write-Output "PUBLISHED source $observed; all six blobs verified"
& pwsh -NoProfile -File "$root/make-conditional-component-archive.ps1"
if($LASTEXITCODE){throw 'Archive failed'}
& pwsh -NoProfile -File "$root/update-conditional-component-docs.ps1"
if($LASTEXITCODE){throw 'Documentation update failed'}
& pwsh -NoProfile -File "$root/validate-conditional-component-docs.ps1"
if($LASTEXITCODE){throw 'Documentation validation failed'}
git diff --stat
