$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location -LiteralPath 'D:/git/arcweft'
$pub=Get-Content -Raw "$root/conditional-component.publication.json"|ConvertFrom-Json
$owner=Get-Content -Raw "$root/conditional-component.owner-summary.json"|ConvertFrom-Json
$consumers=Get-Content -Raw "$root/conditional-component.consumer-summary.json"|ConvertFrom-Json
$archive=Get-Content -Raw "$root/conditional-component.archive.json"|ConvertFrom-Json
$structure=Get-Content -Raw "$root/conditional-component.structure.json"|ConvertFrom-Json
$before=Get-Content -Raw "$root/conditional-component.docs-before.json"|ConvertFrom-Json
if((git rev-parse HEAD) -ne $pub.Source -or (git rev-parse origin/main) -ne $pub.Source -or @(git diff --name-only HEAD).Count){throw 'Source must be published and clean before documentation'}
if($owner.Passed -ne 1695 -or $owner.Failed -ne 6 -or $consumers.Passed -ne 2507 -or $consumers.Failed -ne 2 -or !$archive.AllEntriesVerified -or $structure.ExitCode -ne 0){throw 'Actual evidence differs'}
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$historyPath='D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$bytes=[IO.File]::ReadAllBytes($historyPath)
if($bytes.Length -ne $before.HistoryBytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)) -cne $before.HistorySHA256){throw 'Historical prefix changed'}
$rows=@{}
$rows['再帰関数値の終端効果']='| 再帰関数値の終端効果 | **caller-bound recursion・共有prefixの受入を維持。有限基底内の条件付き最小化を接続し公開。本体内推論は継続** | 最新Source `SOURCE`。Native／AWBCで42を返す既受入と各step公開JSON保存復元、完了値ごとのcaptureを維持する。元値は実Source Γ・import leaseと実frameで検査・移送し、導入operandは選択キーの実application lease、子callは自分のSource Γを保持する。数学層のwhole-row D⇒C・局所∀を維持し、Scheme／Bindableだけを最小化する共通kernelへ移した。確定Futureは先に係数へ代入し、有限基底内の未確定Futureは最小解・principal条件・全行共通witnessに自由変数として残る。親で非principalな子の解を選んでも受入に変わらない反例を含む新4件はPASS。外部Futureの任意supportを扱う量化済み残余条件・検査済み基底へのlowering・guardと一体の親import・条件付き独立replayは未完了であり、このkernelの検証だけで完了とはしない。reify入力の元operand導出、checked primitive effect ownerと行seal、全portのΓ統合、MGU／rank・型ownerの局所∀、frontend prepared value／effect・body一回準備・一括sealを続ける。[既受入](convergence-evidence-history.md#recursive-terminal-effects-in-function-values)・[Γとowner](convergence-evidence-history.md#inference-references-and-application-leases)・[今回の条件付きkernel](convergence-evidence-history.md#conditional-component-minimization)。 |'
$rows['再帰本体の型表現／Semaの推移的逆依存']='| 再帰本体の型表現／Semaの推移的逆依存 | **最新Semaは1,695 PASS／6 FAIL。後続21 packageは2,507 PASS／2 FAIL／1 SKIP** | Source `SOURCE` と同一のRust bytesでlocked・全feature Sema lib／testsの1,701件を74.220秒で実行。直前1,697 IDを保持し、新4件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。同じSourceの後続21 package・107 targetの2,510 IDも選択・終端一致。Compiler既知2失敗は同じExpressionCycle slot 17／19。CLI 226件・callable_execution 376件はPASS。owner全featureとconsumer既定featureを別sliceとして保持する。検証入力・過去の実測は履歴に残し、既受入機能を未完了へ戻さない。[今回の全原本・入力・診断](acceptance-evidence/task-conditional-component.raw.zip)。 |'
$rows['CLIの規定対象／全 check 照合']='| CLIの規定対象／全 check 照合 | **最新Sourceの規定226件PASS。全 check は未再実行** | Source `SOURCE`、locked・既定feature／filterのlibrary 196件と規定の統合6 target 30件がPASS。binはcompile済み・runnable test 0件。今回の効果completion内部の変更に対する再実行結果へ更新した。以前の入力・件数・失敗は履歴と原本に保持する。[今回の実行原本](acceptance-evidence/task-conditional-component.raw.zip)。 |'
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **最新Sourceでworkspace check／Clippy・fmt・構造gateが終了0** | Source `SOURCE` と同一のRust bytesでlocked workspace全target／全feature check／Clippy、workspace fmt、Sema doctest 2件を実行。owner Clippyはworkspaceに包含。全featureのresolved Cargo graphでSemaを含む逆依存22 packageを確認し、現在の全107 targetをlistと終端で照合した。Cargo入力の変更0、6 pathのtest pin／commit blob一致。305物理LOC増を対象に、componentが一度の条件付き最小化、最終closureがadmit済み係数、observationと独立replayがその係数を読む責務を確認した。構造gateはblocking 0。警告を原本に保持する。CARGO_INCREMENTAL=0、jobs／profile上書きなし。全体cargo cleanは9:08に履行済み。WasmはSource `d20f11a7fa9762662df0cdbbe042670207b0177b` の終了0を保持する。今回のTier 2・新しい再帰本体のNative／AWBC・Native／Web最終受入は未実行。[今回の品質・構造・依存graph原本](acceptance-evidence/task-conditional-component.raw.zip)・[clean履歴](convergence-evidence-history.md#template-opening-authority)・[Wasm原本](acceptance-evidence/task-retained-source-probe-preparation.raw.zip)。 |'
$status=[IO.File]::ReadAllText($statusPath)
foreach($key in $rows.Keys){
    $pattern='(?m)^\| '+[regex]::Escape($key)+' \|[^\r\n]*'
    if([regex]::Matches($status,$pattern).Count -ne 1){throw "Current row not unique: $key"}
    $replacement=$rows[$key].Replace('SOURCE',$pub.Source)
    $status=[regex]::Replace($status,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m) $replacement})
}
$status=$status.Replace('この更新の基点の `main` と `origin/main` は `4c6e76d8faf23d2806db0cb5dd3fc0112914f603`','この更新の基点の `main` と `origin/main` は `'+$pub.Source+'`')
[IO.File]::WriteAllText($statusPath,$status,[Text.UTF8Encoding]::new($false))
$hash=$archive.SHA256.ToLowerInvariant()
$addition=@"

## Conditional component minimization

2026-11-13。基点 ``$($pub.Parent)``、実装・公開Source ``$($pub.Source)``、tree ``$($pub.Tree)``。既存mainの6 Rust pathを通常commit／非force pushし、ownerが検証したdirty bytesとcommit全blobの一致を照合した。既存の未追跡 ``%SystemDrive%/`` を保持した。

- Scheme／Bindableの係数だけを一度に最小化する共通component kernelへ、既存の全Future実値specializationと通常solveを移した。確定Futureはminimization前に代入する。有限基底内の未確定Futureは外部係数のまま残し、最小解・satisfiable／principal domain・全行で共有する離散witnessを同時に保持する。最終closure・observation・独立canonical replayは同じ確定係数を読む。任意の外部supportを閉じたと主張するAPIは公開していない。
- 新4件はFuture依存の最小解、x∪y=fで親がxを選んでも子の非principalを救済しない反例、行全体で共通のchoice、予算0後の元graphの再利用を検証する。既存の新label・依存引数・capability closedness・whole-row D⇒C・局所∀・独立replayの条件を弱めない。
- ownerは1,701件／1,695 PASS／6 FAIL／0 SKIP、74.220秒、5 suite。直前1,697 IDを維持し新4件PASS、選択・終端ID一致・重複0。既知6失敗と5 ExpressionCycle／1 PendingCallableEffectProjectionは不変。初回開発buildのprivate field参照エラーは正当なFunctionRefの照会へ直し、失敗原本を保持した。途中の非pin listを最終owner証拠として扱わない。
- 全featureのresolved Cargo graphはSemaを含む22 package。後続21 package／107 targetを同じSourceで再実行し、2,510 ID／2,507 PASS／2 FAIL／1 SKIP、選択・終端ID一致。Compiler既知2失敗とExpressionCycle slot 17／19は不変。CLI 226・callable_execution 376 PASS、3 targetはcompile-only。locked workspace全target／全feature check／Clippy、fmt、Sema doctest 2件と構造gateは終了0。
- 6 pathは合計305物理LOC増。component.rsは251 LOC（101増）、独立test ownerは456 LOC（212増）。同じrelation／completionの責務を維持し、二つ目のsolver・型walker・依存・unsafe・公開互換readerは追加しない。fan-in 12／fan-out 19、全pathの寸法と分類は原本へ保持する。
- Supersedes: 現状一覧の「条件付きcompletion」を一括した未完了表記から、検証した有限基底kernelと、未接続の外部support・残余条件・guarded importを区別した。旧Sourceの結果を新Sourceへ付け替えず、既受入Generic Match・caller-bound recursion・共有prefixは維持する。現在の残作業は[current-status.md](current-status.md)だけへ集約する。

原本 [task-conditional-component.raw.zip](acceptance-evidence/task-conditional-component.raw.zip) は $($archive.Entries) entries、raw $($archive.RawBytes) bytes、ZIP $($archive.ZIPBytes) bytes、SHA-256 ``$hash``。manifestと全entryのportable path・長さ・SHA-256をreadback検証した。
"@
[IO.File]::AppendAllText($historyPath,$addition+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Updated four current rows and appended the frozen evidence history'
