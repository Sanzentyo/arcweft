$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='awbc-dialogue-input-integrated-20261108'
$owner='awbc-dialogue-input-zero-budget-20261108'
$base=(git rev-parse HEAD).Trim()
if($base -ne '3ec9934b355c88193229818b84a4ef20b16f07c9'){throw 'Unexpected evidence base'}
$terminal=Get-Content "$taskTemp/$stem.noncli-r2.runtime.terminal-audit.json" -Raw|ConvertFrom-Json -Depth 30
if($terminal.executed -ne 7345 -or $terminal.passed -ne 7345 -or $terminal.failed -ne 0 -or $terminal.skipped -ne 18 -or $terminal.sourceDrift -ne 0 -or $terminal.catalogCaseDrift -ne 0){throw 'Unexpected terminal'}
$freeze=Get-Content "$taskTemp/$stem.noncli-r2.source-freeze.json" -Raw|ConvertFrom-Json -Depth 30
$qualitySource=Get-Content "$taskTemp/$owner.workspace-quality.source.json" -Raw|ConvertFrom-Json -Depth 30
foreach($row in @($freeze.paths)+@($qualitySource.inputs)){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Input changed: $($row.path)"}}
$quality=@(foreach($name in @('check','clippy','structure','fmt')){$r=Get-Content "$taskTemp/$owner.workspace-quality.$name.receipt.json" -Raw|ConvertFrom-Json -Depth 30;if($r.exitCode -ne 0 -or $r.sourceDrift -ne 0){throw 'Quality failed'};[ordered]@{name=$name;receipt=$r}})
$graph=Get-Content "$taskTemp/$stem.graph-review.json" -Raw|ConvertFrom-Json -Depth 30
$catalog=Get-Content "$taskTemp/$stem.noncli-r2.catalog.inventory.json" -Raw|ConvertFrom-Json -Depth 30
$cases=@($catalog.rows|Where-Object status -eq 'matches');$packages=@($cases.package|Sort-Object -Unique)
$compileOnly=@($graph.reversePackages|Where-Object {$_ -notin $packages -and $_ -ne 'arcweft-cli'})
if($packages.Count -ne 49 -or @($cases|Group-Object {$_.binary+'|'+$_.test}|Where-Object Count -gt 1).Count -or @(Compare-Object $compileOnly @('arcweft','arcweft-bundle-assets','arcweft-render-web')).Count){throw 'Consumer corpus differs'}
$required=@('native_deferred_dialogue_retains_cancellation_during_zero_operation_steps','saved_awbc_deferred_dialogue_retains_cancellation_during_zero_operation_steps','saved_awbc_deferred_dialogue_rejects_forged_pending_cancellation_packets','live_and_inert_input_admission_share_order_replay_and_limit_checks')
foreach($name in $required){if(@($cases|Where-Object {$_.test.EndsWith('::'+$name)}).Count -ne 1){throw 'New regression missing/duplicated'}}
$pins=@(Get-Content "$taskTemp/$stem.noncli-r2.binaries-before.json" -Raw|ConvertFrom-Json)
$first=Get-Content "$taskTemp/$stem.noncli.catalog.json" -Raw|ConvertFrom-Json
if($first.exitCode -ne 101){throw 'Original preparation result differs'}
$archive='docs/implementation/acceptance-evidence/task-awbc-dialogue-input-noncli-consumers.raw.zip'
if(Test-Path $archive){throw 'Archive exists'}
$names=@("$stem.metadata.json","$stem.metadata.log","$stem.metadata.receipt.json","$stem.graph-review.json","$owner.structure-review.json",'run-awbc-input-integrated-consumers-20261108.ps1','run-awbc-input-integrated-consumers-r2-20261108.ps1','run-awbc-dialogue-input-quality-20261108.ps1','run-source-frozen-matrix-20261108.ps1','audit-nextest-final-result.ps1','record-awbc-input-noncli-20261108.ps1',"$owner.source.verified.json","$owner.owner-evidence.verified.json",'existing-consumer-fixture-checkpoint-20261108.verified.json','existing-consumer-fixture-checkpoint-20261108.inventory-after.json')
$files=@(Get-ChildItem $taskTemp -File|Where-Object {$_.Name.StartsWith("$stem.noncli.") -or $_.Name.StartsWith("$stem.noncli-r2.") -or $_.Name.StartsWith("$owner.workspace-quality.") -or $_.Name -in $names}|ForEach-Object {[pscustomobject]@{path=$_.FullName;entry=$_.Name}})
$files+=@(Get-ChildItem "$taskTemp/$owner.structure-report" -File|ForEach-Object {[pscustomobject]@{path=$_.FullName;entry=('structure/'+$_.Name)}})
$entries=@(foreach($file in $files){[ordered]@{entry=$file.entry;bytes=(Get-Item $file.path).Length;sha256=(Get-FileHash $file.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.path,$file.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256 -or $entry.Length -ne $row.bytes){throw 'Archive differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$base;featureSource='17e34d99e32c4618ac6ed866a7ee9ccdcff441c5';finalRustSource='c96539d2fa8107fac34b03bf7568cbb4ce7b16a5';fixtureCheckpoint=$base
 graph=$graph;validation=$terminal;quality=$quality;structure=(Get-Content "$taskTemp/$owner.structure-review.json" -Raw|ConvertFrom-Json -Depth 30)
 corpus=[ordered]@{matchedPackages=$packages;compileOnlyNonCli=$compileOnly;selected=7345;unique=7345;overlap=0;ignored=18;actualTestExecutables=$pins.Count;sourceInputs=$freeze.paths.Count;currentSourceDrift=0;requiredRegressions=$required}
 preparationFailure=[ordered]@{receipt=$first;cause='E0786 was an mmap refusal for the existing arcweft_bundle rlib, with Windows paging-file error1455 in player-native lib tests and player-scene scroll_regions. It is preparation exit101 with no runtime result, not corrupt source metadata or a failed test.';recovery='Retry the same selection/features/default jobs in a fresh epoch, reusing completed artifacts. No Cargo clean, job override, assertion/budget/profile/default-filter change or artifact relocation.'}
 sourceIdentity='Quality froze 3417 inputs at the feature checkpoint plus its unused-import removal; the non-CLI run froze c96539d2fa8107fac34b03bf7568cbb4ce7b16a5. All those hashes still match current files. The subsequent nine-file fixture checkpoint changed only Git ownership, preserving all 12 original source-file bytes. Current WIP is 3 tracked / 4 actual untracked.'
 correction='selectedPackages=0 counts explicit -p flags, while the workspace catalog matches 49 packages. The generic held=14 label comes from the historical template. It does not describe the live 3/4 inventory; all old receipts remain unchanged.'
 acceptance='7345/7345 pass, 18 exclusions retained, including the four new distinct regressions. Workspace all-target/all-feature check and Clippy, canonical structure gate and seven Rust path format checks exit0. Earlier focused runs are separate and are not added to this corpus.'
 remaining='Default-feature CLI 711 is independently building/running; no current CLI terminal is included here. Native public Save, other platforms/Tier2 and final Native-Web parity remain separate. Generic Match and previously accepted feature cuts remain accepted.'
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledger='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledger));$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'awbcDialogueInputNonCliConsumers'){throw 'Record exists'}
$fragment=([ordered]@{awbcDialogueInputNonCliConsumers=$record}|ConvertTo-Json -Depth 100).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}');$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($p in $old.PSObject.Properties){if(($p.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($p.Name)|ConvertTo-Json -Depth 99 -Compress)){throw 'Old result changed'}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledger),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md';$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| 共有契約／推移的逆依存matrix |')){
 "| 共有契約／推移的逆依存matrix | **対話入力修復後の非CLI：7345／7345 PASS・18 SKIP。CLIを別構成で照合中** | Rust Source c96539d2fa8107fac34b03bf7568cbb4ce7b16a5、fixture checkpoint $base。Cargo graphはworkspace98／resolved846／Core逆依存53。非CLI全feature lib／testsは49 package・7345件すべてPASS、4新regressionを各1回含む。compile-onlyはarcweft／arcweft-bundle-assets／arcweft-render-web。実test executable $($pins.Count)本を元pathで前後hash照合し、3417入力drift0。最初のOS1455は準備失敗101として保存し、同条件の新epochで回復した。先行8052件・owner runは履歴へ保全し、新runへ合算しない。現在のCLI711件は終端確認後に反映する。[全選択・初回失敗・実binary・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| 対話取消入力のstep保留／保存admission |')){
 $_.Replace('**Native／保存AWBCの追加owner条件を検証・公開。新Sourceの全逆依存・gateは照合中**','**Native／保存AWBCのowner・非CLI全逆依存・gateを検証・公開。CLIは照合中**')
 }elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 "| workspace check／Clippy・fmt・構造gate | **対話入力修復後の全workspace gateは終了0** | Rust Source c96539d2fa8107fac34b03bf7568cbb4ce7b16a5 と同じ3417入力を前後照合した全target／全feature workspace check／Clippy、canonical構造gate、7 Rust path fmtが終了0。Source checkpoint $base は元9ファイルの内容を変えず、追加Cargo依存・feature変更・unsafeは0。各ownerのbyte数・実LOC・埋込みtest・増加量・依存fan-in/outと責任を原本へ記録した。全14 family・他platform／Tier2・全表示parityの最終受入とは区別する。[実測・構造責任・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$addition=@"

## 2026-11-08 — 対話入力修復後の全非CLI逆依存とworkspace gate

Rust Source **c96539d2fa8107fac34b03bf7568cbb4ce7b16a5**、内容不変のconsumer checkpoint **$base** で、非CLI全feature lib／testsの**49 package・7345／7345 PASS・18 SKIP**。Core逆依存53は新Cargo graphでも差分0。compile-only3はarcweft／arcweft-bundle-assets／arcweft-render-web。4新regressionを各1回含み、先行owner結果を重ねない。実test executable $($pins.Count)本を元pathで前後照合し、3417入力drift0。全workspace check／Clippy・構造gate・7 Rust path fmtも同じ入力で終了0。

初回は既存arcweft_bundle rlibのmmapがWindowsページングファイル不足OS1455で拒否され、player-native lib test／player-scene scroll_regionsの準備が101で停止した。テスト失敗・metadata破損とみなさず、原本を保持して同条件・既定jobsで再試行し回復した。生成物を移動・コピー・退避せず、clean・profile／assertion／budget／除外変更もない。generic labelのselectedPackages=0は明示-p件数、held=14は旧templateで、実49 package／現在3 tracked・4 actual untrackedとは区別する。Source checkpoint後も元12ファイルの内容は同一。CLI711件は別途ビルド・実行中で、この非CLI結果へ加えない。旧Sourceの8052件と失敗4件、全SHAは保持する。Generic Match等は受入のまま。[構造の実測・失敗原本・各終端・公開receipt](acceptance-evidence/task-flow-registry-execution.json)。raw $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::AppendAllText($historyPath,"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$base;earlierRecordsPreserved=$old.PSObject.Properties.Name.Count;passed=7345;packages=$packages.Count;actualTestExecutables=$pins.Count;rawEntries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json
