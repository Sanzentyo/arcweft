$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='awbc-dialogue-input-integrated-20261108'
foreach($name in @('check','clippy','structure','fmt')){
 $receipt=Get-Content "$taskTemp/awbc-dialogue-input-zero-budget-20261108.workspace-quality.$name.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw 'Quality gate failed'}
}
& "$taskTemp/assert-no-arcweft-build.ps1"
$base=(git rev-parse HEAD).Trim()
$started=[DateTime]::UtcNow.ToString('o')
& cargo metadata --locked --all-features --format-version 1 1> "$taskTemp/$stem.metadata.json" 2> "$taskTemp/$stem.metadata.log"
$exit=$LASTEXITCODE
[ordered]@{version=1;base=$base;command=@('cargo','metadata','--locked','--all-features','--format-version','1');exitCode=$exit;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$taskTemp/$stem.metadata.receipt.json"
if($exit -ne 0){throw 'Metadata failed'}
$meta=Get-Content "$taskTemp/$stem.metadata.json" -Raw|ConvertFrom-Json -Depth 100
$core=@($meta.packages|Where-Object name -eq 'arcweft-core')
if($core.Count -ne 1){throw 'Core owner ambiguous'}
$reverse=[Collections.Generic.HashSet[string]]::new();[void]$reverse.Add($core[0].id)
do{
 $changed=$false
 foreach($node in $meta.resolve.nodes){
  if($reverse.Contains($node.id)){continue}
  foreach($edge in $node.deps){if($reverse.Contains($edge.pkg)){[void]$reverse.Add($node.id);$changed=$true;break}}
 }
}while($changed)
$packages=@($meta.packages|Where-Object {$_.id -in $meta.workspace_members -and $reverse.Contains($_.id)}|ForEach-Object name|Sort-Object -Unique)
$prior=Get-Content "$taskTemp/scope-results-integrated-20261108.graph-review.json" -Raw|ConvertFrom-Json
if($meta.workspace_members.Count -ne 98 -or $meta.resolve.nodes.Count -ne 846 -or @(Compare-Object $prior.reversePackages $packages).Count){throw 'Dependency graph changed; select new consumers'}
[ordered]@{version=1;base=$base;workspace=$meta.workspace_members.Count;resolved=$meta.resolve.nodes.Count;core='arcweft-core';reversePackages=$packages;reverseCount=$packages.Count;graphDriftFromPriorCut=0;featurePoints=@('non-CLI workspace all-features lib/tests','CLI default features lib/tests');defaultCargoJobs=$true;buildArtifactRelocation=$false}|ConvertTo-Json -Depth 15|Set-Content "$taskTemp/$stem.graph-review.json"
& "$taskTemp/run-source-frozen-matrix-20261108.ps1" -Stem "$stem.noncli" -Selection @('--locked','--workspace','--exclude','arcweft-cli','--all-features','--lib','--tests','-E','rdeps(=arcweft-core)') -ExpectedMatches 7345 -AdditionalPaths @('crates/arcweft-core/src/engine/dialogue/scope.rs')
if($LASTEXITCODE -ne 0){throw 'Non-CLI reverse consumers failed; inspect original result before CLI build'}
$fixtures=@(& rg --files tests/fixtures/arcw samples -g '*.arcw' -g '*.json' -g '*.toml')
if($LASTEXITCODE -ne 0 -or -not $fixtures.Count){throw 'Fixture inventory missing'}
& "$taskTemp/run-awbc-input-cli-main-20261108.ps1" -Stem "$stem.cli" -Selection @('--locked','-p','arcweft-cli','--lib','--tests') -ExpectedMatches 711 -AdditionalPaths (@('crates/arcweft-core/src/engine/dialogue/scope.rs')+$fixtures)
exit $LASTEXITCODE
