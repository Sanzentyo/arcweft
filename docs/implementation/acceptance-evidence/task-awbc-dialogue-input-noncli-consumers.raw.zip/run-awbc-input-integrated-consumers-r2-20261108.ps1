$ErrorActionPreference='Stop'
Set-Location 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='awbc-dialogue-input-integrated-20261108'
$failed=Get-Content "$taskTemp/$stem.noncli.catalog.json" -Raw|ConvertFrom-Json
if($failed.exitCode -ne 101 -or $failed.sourceDrift -ne 0){throw 'Original preparation result differs'}
& "$taskTemp/run-source-frozen-matrix-20261108.ps1" -Stem "$stem.noncli-r2" -Selection @('--locked','--workspace','--exclude','arcweft-cli','--all-features','--lib','--tests','-E','rdeps(=arcweft-core)') -ExpectedMatches 7345 -AdditionalPaths @('crates/arcweft-core/src/engine/dialogue/scope.rs')
if($LASTEXITCODE -ne 0){throw 'Non-CLI reverse consumers failed; inspect before CLI build'}
$fixtures=@(& rg --files tests/fixtures/arcw samples -g '*.arcw' -g '*.json' -g '*.toml')
if($LASTEXITCODE -ne 0 -or -not $fixtures.Count){throw 'Fixture inventory missing'}
& "$taskTemp/run-awbc-input-cli-main-20261108.ps1" -Stem "$stem.cli" -Selection @('--locked','-p','arcweft-cli','--lib','--tests') -ExpectedMatches 711 -AdditionalPaths (@('crates/arcweft-core/src/engine/dialogue/scope.rs')+$fixtures)
exit $LASTEXITCODE
