#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod decision;
use decision::{DecisionControl, DecisionWork, EffectDecision, EffectDecisionReplacement};

#[derive(Default)]
struct Meter(usize);
impl DecisionControl for Meter {
    type Error = std::convert::Infallible;
    fn charge(&mut self, _: DecisionWork) -> Result<(), Self::Error> {
        self.0 += 1;
        Ok(())
    }
}

fn main() {
    for count in 1..=6 {
        let entries = 1usize << count;
        let mut old = Meter::default();
        let mut new = Meter::default();
        let controls: Vec<_> = (0..count)
            .map(|i| EffectDecision::variable(i, &mut Meter::default()).unwrap())
            .collect();
        let mut table: Vec<_> = (0..entries)
            .map(|i| EffectDecision::variable(count + i, &mut old).unwrap())
            .collect();
        for selector in &controls {
            table = table.chunks_exact(2)
                .map(|pair| selector.conditional(&pair[1], &pair[0], &mut old).unwrap())
                .collect();
        }
        let result = EffectDecision::select_table(
            count,
            entries,
            &mut new,
            |i| EffectDecisionReplacement::Decision(&controls[i]),
            |i, _| Ok(EffectDecisionReplacement::Variable(count + i)),
        ).unwrap().unwrap();
        assert_eq!(table.pop().unwrap(), result);
        println!("table selectors={count} entries={entries} old={} new={}", old.0, new.0);
    }
    for count in [2usize, 3, 4, 8, 16, 32] {
        let terms: Vec<_> = (0..count)
            .map(|i| EffectDecision::variable(i, &mut Meter::default()).unwrap())
            .collect();
        let mut old = Meter::default();
        let mut new = Meter::default();
        let pairwise = terms.iter().fold(EffectDecision::constant(true), |value, term| value.and(term, &mut old).unwrap());
        let shared = EffectDecision::all(&terms, &mut new).unwrap();
        assert_eq!(pairwise, shared);
        println!("conjunction terms={count} old={} new={}", old.0, new.0);
    }
}
