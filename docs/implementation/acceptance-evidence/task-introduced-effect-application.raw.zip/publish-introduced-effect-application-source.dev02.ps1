param([Parameter(Mandatory)][string]$Commit)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$base = '866e4d03a9675f79e6023b29c5c34affd45b9103'
$ref = 'refs/heads/main'
if ((git branch --show-current) -ne 'main' -or (git rev-parse HEAD) -ne $Commit) {
    throw 'Checkout differs from validated source.'
}
git merge-base --is-ancestor $base $Commit
if ($LASTEXITCODE -ne 0) { throw 'Validated source is outside the expected publication base.' }
if (@(git status --porcelain --untracked-files=no -- crates).Count) { throw 'Source paths contain local changes.' }
$paths = @(git diff --name-only $base HEAD)
if ($paths.Count -eq 0 -or @($paths | Where-Object { -not $_.StartsWith('crates/arcweft-lang-sema/src/') }).Count) {
    throw 'Unexpected source publication paths.'
}
git diff --check $base HEAD
if ($LASTEXITCODE -ne 0) { throw 'Source diff check failed.' }
$remote = git ls-remote --exit-code origin $ref
if ($LASTEXITCODE -ne 0) { throw 'Remote ref lookup failed.' }
$before = $remote.Split()[0]
if ($before -ne $base) { throw 'Remote source base moved.' }
git push origin "HEAD:$ref"
if ($LASTEXITCODE -ne 0) { throw 'Source push failed.' }
$remote = git ls-remote --exit-code origin $ref
if ($LASTEXITCODE -ne 0) { throw 'Published ref lookup failed.' }
$after = $remote.Split()[0]
git fetch --no-tags origin $ref
if ($LASTEXITCODE -ne 0) { throw 'Published source fetch failed.' }
$fetched = git rev-parse FETCH_HEAD
if ($after -ne $Commit -or $fetched -ne $Commit) { throw 'Published commit differs.' }
$blobs = [ordered]@{}
foreach ($path in $paths) {
    $local = git rev-parse "HEAD:$path"
    $published = git rev-parse "FETCH_HEAD:$path"
    if ($LASTEXITCODE -ne 0 -or $published -ne $local) { throw "Published blob differs for $path." }
    $blobs[$path] = $published
}
@{
    version = 1
    base = $before
    source = $Commit
    remote = $after
    fetched = $fetched
    ref = $ref
    blobs = $blobs
    observed_at = Get-Date -Format o
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $root 'introduced-effect-application.dev02-source-publication.json') -Encoding utf8NoBOM
"Verified $Commit, $($blobs.Count) source blobs."



