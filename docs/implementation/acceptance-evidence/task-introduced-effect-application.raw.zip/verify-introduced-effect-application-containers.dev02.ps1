param([Parameter(Mandatory)][string]$Commit)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
if ((git rev-parse HEAD) -ne $Commit) { throw 'Checkout revision differs from the CLI verification source.' }
$exe = (Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$binary = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
$old = @('dev01','dev02') | ForEach-Object {
    Get-Content -LiteralPath (Join-Path $root "contextual-callback-containers.$_-prior-run.json") -Raw | ConvertFrom-Json
}
if ($old.binary -contains $binary) { throw 'CLI executable still matches the historical build.' }
$outcomes = @(
    foreach ($previous in $old.runs) {
        $arguments = [string[]]$previous.args
        $inputHash = (Get-FileHash -LiteralPath $arguments[1] -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($inputHash -ne $previous.source_sha256) { throw ('Source fixture changed: '+$previous.case) }
        $prefix = Join-Path $root ('introduced-effect-application.dev02-container-'+$previous.case)
        $stdout = $prefix+'.stdout.log'
        $stderr = $prefix+'.stderr.log'
        & $exe @arguments 1> $stdout 2> $stderr
        $code = $LASTEXITCODE
        $document = if ((Get-Item -LiteralPath $stdout).Length) {
            Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json
        } else {
            $null
        }
        $diagnosis = Get-Content -LiteralPath $stderr -Raw
        @{
            case=$previous.case
            input_sha256=$inputHash
            args=$arguments
            exit=$code
            final_status=$document.final_status
            diagnosis=$diagnosis
            previous_exit=$previous.exit
            previous_final_status=$previous.final_status
            previous_diagnostic=$previous.diagnostic
            stdout=[IO.Path]::GetFileName($stdout)
            stderr=[IO.Path]::GetFileName($stderr)
        }
    }
)
@{ version=1; source=$Commit; binary_sha256=$binary; runs=$outcomes; observed=(Get-Date -Format o) } | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $root 'introduced-effect-application.dev02-cli-containers.json') -Encoding utf8NoBOM
$outcomes | ForEach-Object { '{0} exit {1} (prior {2}), status {3}' -f $_.case,$_.exit,$_.previous_exit,$_.final_status }

