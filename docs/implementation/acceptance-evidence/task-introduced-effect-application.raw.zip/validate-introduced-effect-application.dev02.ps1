param([Parameter(Mandatory)][string]$Commit)

$ErrorActionPreference='Stop'
$env:CARGO_INCREMENTAL='0'
$root=Split-Path -Parent $PSCommandPath
$prefix='introduced-effect-application.dev02'

function Invoke-Validation {
    param([string]$Name, [string]$Command, [string[]]$Arguments, [int[]]$Allowed=@(0))

    if ((git rev-parse HEAD) -ne $Commit -or @(git status --porcelain --untracked-files=no -- crates/arcweft-lang-sema).Count) {
        throw 'Checkout changed from the verified source.'
    }
    Write-Host "Starting $Name"
    $log=Join-Path $root "$prefix-$Name.log"
    $started=Get-Date -Format o
    & $Command @Arguments *> $log
    $code=$LASTEXITCODE
    $summary=@(
        Select-String -LiteralPath $log -Pattern '^error|^ *Finished|^ *Summary \[' |
            Select-Object -ExpandProperty Line -Last 8
    )
    @{
        version=1
        source=$Commit
        command=@($Command)+$Arguments
        started=$started
        finished=Get-Date -Format o
        exit=$code
        summary=$summary
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $root "$prefix-$Name.result.json") -Encoding utf8NoBOM
    $summary
    Write-Host "Finished $Name exit $code"
    if ($code -notin $Allowed) { throw "$Name exited $code." }
}

Invoke-Validation 'structure' just @('structure-audit-gate')
Invoke-Validation 'dependency-graph' cargo @('tree','--locked','--workspace','--invert','arcweft-lang-sema','--prefix','none','--edges','normal,dev,build','--no-dedupe')
Invoke-Validation 'workspace-check' cargo @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Validation 'workspace-clippy' cargo @('clippy','--locked','--workspace','--all-targets','--all-features')
$filter='rdeps(=arcweft-lang-sema)'
$testFlags=@('-E',$filter,'--no-fail-fast','--no-tests','fail')
Invoke-Validation 'reverse-tests' cargo (@('nextest','run','--locked','--workspace','--lib','--tests','--exclude','arcweft-cli')+$testFlags) -Allowed @(0,100)
Invoke-Validation 'reverse-cli' cargo (@('nextest','run','--locked','-p','arcweft-cli','--lib','--bins')+$testFlags) -Allowed @(0,100)
Invoke-Validation 'reverse-cli-fixtures' cargo (@('nextest','run','--locked','-p','arcweft-cli','--test','runtime_native_options','--test','check_core_cli','--test','native_style_parity_sample','--test','release_trust_json','--test','arcw_fixtures_check_run','--test','seq04_8_4_persistent_cache_build_cli_goldens')+$testFlags) -Allowed @(0,100)




