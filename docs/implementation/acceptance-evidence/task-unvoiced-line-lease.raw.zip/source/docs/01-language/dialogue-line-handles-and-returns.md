# Dialogue Content Calls, `with` Blocks, Line Output Values, and Scoped Handles

> **Canonical surface:** Content application is defined by
> [CharacterDialogue authoring](character-dialogue.md). Direct calls use
> `character(args)[content]`; the handle, `with`, return, and scope contracts
> below apply to that typed call.

Arcweft supports concise dialogue while preserving typed control over voice, BGM, stage objects, hooks, and cancellation.

Related:

- [Dialogue Calls, Line Plans, Cancellation, and Scoped Content Blocks](dialogue-calls-scopes-cancellation.md)
- [Dialogue Character Configuration, Views, Interpolation, and Preload](dialogue-character-methods-and-views.md)
- [Dialogue Content Actions, Ruby, Interpolation, and Line Marks](dialogue-content-actions-ruby-and-interpolation.md)
- [Flow-Integrated Scenario Syntax](scenario-surface-syntax.md)
- [Character Stage / Sprite / Voice Timeline](../03-presentation/character-stage.md)
- [Audio / Spatial / TTS / BGM](../03-presentation/audio.md)

---

## Accepted dialogue-call forms

The preferred detailed shape is:

```arcw
character(args)[dialogue]
with {
    line plan
}
```

For script-like sections, `with:` is indentation sugar for the same block:

```arcw
character(args)[dialogue]
with:
    line plan
```

For ordinary lines, the speaker itself can receive the content block:

```arcw
alice()[
    おはよう。[p]
]
with:
    at(0.42s):
        alice.stage.look(smile)
```

This is equivalent to the canonical detailed form:

```arcw
alice()[
    おはよう。[p]
]
with:
    at(0.42s):
        alice.stage.look(smile)
```

The colon form is the shortest speaker-call sugar:

```arcw
alice:
    おはよう。[p]
with:
    at(0.42s):
        alice.stage.look(smile)
```

This is equivalent to the same canonical detailed form:

```arcw
alice()[
    おはよう。[p]
]
with:
    at(0.42s):
        alice.stage.look(smile)
```

All four source forms produce the same typed `DialogueLine`. The canonical
semantic shape uses an explicit character content call plus a `with { ... }`
plan, while formatters may preserve `with:` in hand-written scenario files.
Configured dialogue values retain their options when called, for example
`alice2(voice=auto)[...]`.

---

## Why `alice()[...] with {}` is reasonable

It is realistic and useful because `alice()[...]` is only interpreted as a
dialogue content call when `alice` has type `CharacterDialogue` or
`Ref<Character>` and appears in flow-item position.

```arcw
alice()[おはよう。[p]]
```

is a dialogue call.

```arcw
items[index]
```

is normal indexing, because `items` is not a speaker.

If a parser cannot decide during lossless parsing, it retains both interpretations under a `PostfixBracket` CST node. HIR preserves their typed structure and exact recovery ownership. Semantic analysis selects the unique valid interpretation using the target type and expected result; a rejected alternative does not make the selected program invalid. Required recovery in the selected interpretation or shared target still prevents compilation.

```text
CharacterDialogue + [DialogueText] in flow item context
  -> DialogueContentCall

Collection + [Expr]
  -> IndexExpr
```

The formatter may expand ambiguous cases to `alice()[...]`.

---

## `with {}` and `with:` sugar

Both block forms are supported. `with { ... }` is canonical; `with:` is syntax sugar for an indented source block.

```arcw
alice()[おはよう。[p]]
with {
    at(0.42s) { alice.stage.look(smile) }
}
```

```arcw
alice()[おはよう。[p]]
with:
    at(0.42s):
        alice.stage.look(smile)
```

The two forms are equivalent after parsing. Project formatting controls the printed source style.

```toml
[fmt.dialogue]
line_plan_style = "indent"   # "indent" | "brace" | "preserve"
```

`with:` begins a line-plan block only when it is aligned with the speaker line or content call. Inside dialogue text, `with:` is ordinary text unless escaped or parsed as part of a content action. Lowering should normalize it to the same representation as `with { ... }`.

A bare block after dialogue content is not a line plan:

```arcw
alice()[おはよう。[p]] {
    debug_log()
}
```

The `{ ... }` above is a separate lexical scope. Use `with { ... }` when the block is intended to be a line plan.

---

## Colon speaker sugar with `with:`

The following is a concise complex line. The `alice:` head is syntax sugar for a character dialogue call, and `with:` is syntax sugar for `with { ... }`.

```arcw
alice(voice=auto, look=.smile):
    今日は少しだけ、|[変な夢](へんなゆめ)を見たんだ。[p]
with:
    at(0.42s):
        alice.stage.look(.worried, crossfade=120ms)

    cancel on input(.SkipLine):
        'line.voice |> drop(stop_now)
        text.flush(mode = .Instant)
        continue
```

It is equivalent to:

```arcw
alice(voice=auto, look=.smile)[
    今日は少しだけ、|[変な夢](へんなゆめ)を見たんだ。[p]
]
with:
    at(0.42s):
        alice.stage.look(.worried, crossfade=120ms)

    cancel on input(.SkipLine):
        'line.voice |> drop(stop_now)
        text.flush(mode = .Instant)
        continue
```

---

## Line result values

A line plan may export a value with `out`. Without an explicit `out`, the line result is `()`.

```arcw
let handles = alice(voice=auto)[
    聞いて。[p]
]
with:
    let voice = line.voice_handle()
    let look = alice.stage.look(.smile)
    out (voice, look)
```

The type is inferred from the `out` expression. A type annotation on a `let`
binding of the line result supplies the expected type for `out`. For example,
`let reply: Option<String>` allows the line plan to select `out .Some("yes")`.

A marked line handler may be the only path that supplies a non-Unit result, as
in the `.Released` [line-local mark example](dialogue-calls-scopes-cancellation.md#line-plan-block).
That `out` selects the result of its exact `DialogueLine` application, and all
normal and mark-handler outputs must agree on one result type. An On-only
result stays pending until a mark selects it; a normal close without a
selection, or a second effective mark selection, fails. Distinct mark handlers
may provide alternative selectors, and a later cancellation `out` may replace a
pending mark-selected result before publication.

```text
alice(...)[...] with: out (voice, look)
  -> (VoiceHandle, StageCueHandle)
```

If a cancellation branch can complete the line differently, it must either:

```text
- out the same result type,
- perform non-returning flow control such as goto/return FlowExit,
- or choose an ordinary line result type `Result<T, LineCancel>` and `out`
  `Ok(T)` or `Err(LineCancel)` on the corresponding paths.
```

The normal `out` value is the pending result while the line is active. A
cancellation branch may select another value of the same result type before
the line publishes its result. The selected result is published once, after
cancelled children and the applicable scoped cleanup have finished.

Example with explicit cancel result:

```arcw
let result = alice(voice=auto)[
    聞いて。[p]
]
with:
    cancel on input(.SkipLine):
        out Err(LineCancel.Skipped)

    out Ok(())
```

Here `result` has type `Result<(), LineCancel>`. Applying ordinary `try` to
the line expression instead propagates `Err` and binds the unwrapped `()`.

For most visual-novel lines, cancel handlers use `continue`, `goto`, or `return Ok(FlowExit....)`, so ordinary bindings remain ergonomic.

---

## Tuple destructuring and `_` discard

Line results can be destructured.

```arcw
let (line_alice, (face0, face1, voice)) = alice(
    id=@say.opening.dream_hint,
    voice=auto,
    look=.smile,
)[
    今日は少しだけ、|[変な夢](へんなゆめ)を見たんだ。[p]
]
with:
    let line_alice = alice.stage.acquire(scope=line)
    let voice = line.voice_handle()
    let face0 = line_alice.look(.smile)
    let face1 = at(0.42s):
        line_alice.look(.worried, crossfade=120ms)

    out (line_alice, (face0, face1, voice))
```

`_` explicitly discards a returned value.

```arcw
let (_, (face0, _, voice)) = alice(voice=auto)[
    聞いて。[p]
]
with:
    let actor = alice.stage.acquire(scope=line)
    let face0 = actor.look(smile)
    let face1 = at(0.42s): actor.look(worried)
    let voice = line.voice_handle()
    out (actor, (face0, face1, voice))
```

A wildcard discards its projected value. If the value owns a scoped handle,
Arcweft runs that handle's drop policy. A handle forwarded through another
dialogue line's `out` retains the identity and drop policy of the line that
issued it. When cleanup requires a host acknowledgement, the receiving
continuation resumes after that acknowledgement arrives.

---

## Scoped handles

Line plans can create handles for voice, BGM, animation, stage leases, subscriptions, and scheduled cues.

```arcw
pub trait ScopedHandle {
    fn drop_policy(self) -> DropPolicy
}

pub enum DropPolicy {
    Cancel,
    Stop { fade: Duration },
    Finish,
    Release,
    Detach,
}
```

Default policies:

| Handle | Default when dropped in line scope |
|---|---|
| `VoiceHandle` | stop or release line voice; skip/cancel uses line cancel policy |
| `BgmHandle(scope=line)` | stop/fade according to BGM policy |
| `BgmHandle(scope=global)` | detach; not stopped by line drop |
| `AnimationHandle` | cancel pending animation unless marked `complete_on_drop` |
| `ScheduledCueHandle<T>` | cancel cue if it has not fired |
| `StageLease` | release lease; does not hide sprite unless `hide_on_drop=true` |
| `SignalSubscription` | unsubscribe |
| `HookHandle` | unregister hook |

`line.voice_handle()` acquires the line's affine voice lease. If voice resolution
finds no playback, the lease still participates in `out`, ownership transfer,
and discard. Dropping that lease completes locally without a playback command.
A rejected playback start remains a line failure.

A returned handle lives in the receiving scope. When that scope ends, the handle is dropped. Binding it to `_` drops it immediately.

```arcw
let _ = bgm.play(@bgm.tension, scope=line, drop=fade(300ms))
// BGM is started and then immediately dropped, so it is faded/stopped immediately.
// LSP warns because this is probably a mistake.
```

To persist BGM beyond the line, detach it or use a global scope explicitly.

```arcw
let bgm_handle = alice()[始まるよ。[p]]
with:
    let bgm = bgm.play(@bgm.tension, scope=line, drop=fade(300ms))
    out bgm.detach()
```

---

## Line-plan scope

`with:` creates a lexical scope.

```arcw
alice:
    聞いて。[p]
with:
    let local_color = rgb("#ffffff")
    at(0.2s):
        flash(color=local_color)

// local_color is not visible here.
```

Only values exported with `out` from the line plan can escape the line. Borrowed values such as `&'frame T` and `&'lease T` cannot be exported or captured across `at`, `await`, `yield`, or cancellation boundaries.

The line owns its initial external inputs. Semantic analysis selects one Copy
or Move of each complete captured binding after the target and content operands
have been evaluated. A moved input becomes unavailable in the caller, even when
the line only borrows it or moves one field. Inside the line, the input starts
initialized in that line's frame and may be borrowed, consumed, or returned with
`out`. Copy inputs remain available in the caller.

A reached `defer` in the line root, `init`, or a nested lexical scope may take
an owned initial input. Its sole capture packet retains that value until cleanup
starts; cleanup receives it once when the frozen scope outcome matches the
registration's filter. A skipped registration releases its owned packet. Moving
a received handle into another registration preserves the original issuing
line's resource authority. Scope completion, result binding, and return wait for
the applicable cleanup, including a cleanup suspended in another dialogue.

A value-producing scope evaluates its result once and retains sole ownership
while cleanup is suspended. Binding that result in the outer scope, or discarding
it, happens after cleanup completes. A failed or cancelled scope exit discards
the pending result instead of publishing it to the caller.

Initial inputs and inputs shared after reveal have different lifetimes. Only
the root values actually used by unscheduled line work are shared at reveal,
and their complete value graphs must permit Copy. Scheduled children instead
receive their separately owned capture packets. A suspended call retains its
actual input packet until transfer into the activation frame; saving does not
create another owner for those values.

A scheduled child takes its captured handles from the line packet exactly once,
when its complete `Run` command batch is admitted. If a later command in that
batch is invalid, the packet and its leases remain in line custody; no child is
published from a partial batch.

---

## Stage object handles and preload

Characters expose object-like stage APIs. These APIs return scoped handles and
support explicit preloading.

```arcw
preload next @flow.alice_intro:
    alice.stage.prefetch(pose=normal, faces=[smile, worried], view=@view.MainDialogue)
    alice.voice_for(@say.alice_intro.001).preload()
    bgm.prepare(@bgm.alice_theme)
```

Within a line:

```arcw
let actor = alice.stage.acquire(scope=line)
let pose = actor.pose(normal)
let face = actor.look(smile)
```

`actor.look` borrows the `StageActor` receiver. The actor remains available for
another look or for `out`; each returned cue owns its own new handle.

The stage subsystem owns reuse of loaded sprite atlases, expression meshes, and
text-layout assets. Authors select the handle lifetime; they do not construct a
generic memo cache in source.

```arcw
let actor = alice.stage.acquire(scope=scene)
```

Preload declarations are hints, not hidden blocking operations. If an asset is not ready at use time, the normal unary `Need<T>` / pending-display rules still apply; domain failure belongs to its payload Result.

---

## Shadowing speaker names

A line result binding may technically shadow a speaker alias:

```arcw
let (alice, _) = alice()[おはよう。[p]] with:
    let actor = alice.stage.acquire(scope=line)
    out (actor, ())
```

This is allowed but discouraged, because after the binding `alice` refers to the stage handle, not the speaker alias. The LSP warns by default. Prefer a distinct name:

```arcw
let (alice_actor, _) = alice()[おはよう。[p]] with:
    let actor = alice.stage.acquire(scope=line)
    out (actor, ())
```

---

## Desugaring summary

```arcw
alice()[
    おはよう。[p]
]
with:
    at(0.42s): alice.stage.look(smile)
```

becomes conceptually:

```arcw
alice()[
    おはよう。[p]
]
with:
    at(0.42s): alice.stage.look(smile)
```

```arcw
alice:
    おはよう。[p]
with:
    at(0.42s): alice.stage.look(smile)
```

also becomes the same call.

```arcw
let (_, cue) = alice()[おはよう。[p]] with:
    let cue = at(0.42s): alice.stage.look(smile)
    out (line.voice_handle(), cue)
```

runs `drop_now` on the discarded voice handle immediately after destructuring, while `cue` remains owned by the surrounding scope.

