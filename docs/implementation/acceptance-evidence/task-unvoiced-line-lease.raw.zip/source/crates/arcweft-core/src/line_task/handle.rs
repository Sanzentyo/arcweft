use super::defer::{
    AwbcRuntimeDeferredRegistrationSnapshot, RuntimeDeferInFlight, RuntimeDeferUnwindState,
    RuntimeDeferUnwindStep, RuntimeLineDeferredRegistration, RuntimeScopedDeferDecision,
};
use super::{
    LineTaskLaneView, LineTaskLiveState, LineTaskNodeState, LineTaskPlanView, LineTaskReducerView,
    LineTaskScheduledCompletion, LineTaskWork, LineTaskWorkInstance, LineTaskWorkTag,
    RuntimeDialogueContentEventKind, ScopeExit,
};
use crate::effect::RuntimeDropPolicy;
use crate::pattern::{RuntimeOpaqueTypeOwner, RuntimeOpaqueTypeProducerId};
use crate::presentation::{
    RuntimeCommandQueue, RuntimeDialogueVoiceState, RuntimeStageRejectCode, RuntimeVoiceSessionId,
    RuntimeVoiceStartTicket,
};
use crate::runtime_id::{
    DialogueActivationId, RuntimeDeferRegistrationId, RuntimeDeferSiteId, RuntimeLineHandleSiteId,
    RuntimeLineHandleToken, RuntimeLineTaskNodeId, RuntimeLocalDeclarationId,
};
use crate::scope::{
    RuntimeDeferOutcomeFilter, RuntimeDeferRegistrationFrontier,
    RuntimePreparedDeferredRegistration, defer_registration_stack_is_ordered,
};
use crate::task::RuntimeProgramOwner;
use crate::time::LogicalDuration;
use crate::value::ownership::{RuntimeOwnedSlotId, RuntimeValuePath};
use crate::value::{
    RuntimeHandleKind, RuntimeLocalBinding, RuntimeLocalSlot, RuntimeOpaquePersistence,
    RuntimeOpaqueValue, RuntimeOpaqueValueClass, RuntimePlaceStorage, RuntimeValue,
    RuntimeValueView,
};
use arcweft_character::id::CharacterId;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use std::num::NonZeroU64;
use thiserror::Error;

mod journal_rows;

pub const MAX_LINE_HANDLE_SITES: usize = 128;
pub const MAX_LINE_LIVE_HANDLES: usize = 256;
pub const MAX_LINE_SCHEDULED_CALLBACKS: usize = 128;
pub const MAX_LINE_COMMAND_HISTORY: usize = 1_024;

/// Actual backend coordinates admit fixed metadata without adding a wire
/// codec to a construction-only plan identity.
pub(crate) trait RuntimeDialogueTypeCoordinate {
    fn admit_type_metadata(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>;

    fn original_value_type<'a>(
        &self,
        owner: &'a RuntimeProgramOwner,
    ) -> Result<
        crate::program_types::RuntimeProgramValueType<'a>,
        crate::value::AwbcRuntimeValueSnapshotError,
    >;
}

impl RuntimeDialogueTypeCoordinate for crate::runtime_id::RuntimePlanTypeId {
    fn admit_type_metadata(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        admission.validate_metadata(&self.get().get())
    }

    fn original_value_type<'a>(
        &self,
        owner: &'a RuntimeProgramOwner,
    ) -> Result<
        crate::program_types::RuntimeProgramValueType<'a>,
        crate::value::AwbcRuntimeValueSnapshotError,
    > {
        let RuntimeProgramOwner::Plan(plan) = owner else {
            return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                message: "Native dialogue type requires its original plan owner".to_owned(),
            });
        };
        plan.type_table()
            .get(*self)
            .ok_or(crate::plan::RuntimePlanTypeResolutionError::UnknownType { ty: *self })
            .map_err(crate::program_types::RuntimeProgramTypeError::from)?;
        Ok(crate::program_types::RuntimeProgramValueType::Plan {
            program: &plan.inventory,
            ty: *self,
        })
    }
}

impl RuntimeDialogueTypeCoordinate for crate::awbc::schema::AwbcTypeId {
    fn admit_type_metadata(
        &self,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError> {
        admission.validate_metadata(&self.0)
    }

    fn original_value_type<'a>(
        &self,
        owner: &'a RuntimeProgramOwner,
    ) -> Result<
        crate::program_types::RuntimeProgramValueType<'a>,
        crate::value::AwbcRuntimeValueSnapshotError,
    > {
        let RuntimeProgramOwner::Awbc(program) = owner else {
            return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                message: "AWBC dialogue type requires its original program owner".to_owned(),
            });
        };
        program
            .runtime_types
            .get(self.index())
            .ok_or(
                crate::awbc::type_projection::AwbcTypeProjectionError::RuntimeTypeOutOfBounds {
                    index: self.0,
                },
            )
            .map_err(crate::program_types::RuntimeProgramTypeError::from)?;
        Ok(crate::program_types::RuntimeProgramValueType::Awbc { program, ty: *self })
    }
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RuntimeLineHandleScope {
    Line,
}

/// Closed producer role of one handle site. Cue's two runtime behaviors are
/// distinct here even though both yield the single source type `CueHandle`.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum RuntimeLineHandleSiteKind {
    StageActor,
    ScheduledCue,
    StageLookCue,
    Voice,
}

impl RuntimeLineHandleSiteKind {
    #[must_use]
    pub const fn handle_kind(self) -> RuntimeHandleKind {
        match self {
            Self::StageActor => RuntimeHandleKind::StageActor,
            Self::ScheduledCue | Self::StageLookCue => RuntimeHandleKind::Cue,
            Self::Voice => RuntimeHandleKind::Voice,
        }
    }
}

/// One dense typed handle-producing site in a sealed line task group.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeLineHandleSite {
    id: RuntimeLineHandleSiteId,
    source_ordinal: u32,
    kind: RuntimeLineHandleSiteKind,
    result_type: crate::runtime_id::RuntimePlanTypeId,
    character: Option<CharacterId>,
    scheduled_child: Option<RuntimeLineTaskNodeId>,
    opaque_owner: RuntimeOpaqueTypeOwner,
}

impl RuntimeLineHandleSite {
    pub(crate) fn new(
        id: RuntimeLineHandleSiteId,
        source_ordinal: u32,
        kind: RuntimeLineHandleSiteKind,
        result_type: crate::runtime_id::RuntimePlanTypeId,
        character: Option<CharacterId>,
        scheduled_child: Option<RuntimeLineTaskNodeId>,
        opaque_owner: RuntimeOpaqueTypeOwner,
    ) -> Result<Self, LineRuntimeError> {
        Self::validate_metadata(
            kind,
            character.is_some(),
            scheduled_child.is_some(),
            opaque_owner.producer(),
            opaque_owner.value_class(),
            opaque_owner.persistence(),
        )?;
        Ok(Self {
            id,
            source_ordinal,
            kind,
            result_type,
            character,
            scheduled_child,
            opaque_owner,
        })
    }

    /// Checks the borrowed declaration before copying an opaque site owner.
    pub(crate) fn validate_metadata(
        kind: RuntimeLineHandleSiteKind,
        has_character: bool,
        has_scheduled_child: bool,
        producer: &RuntimeOpaqueTypeProducerId,
        value_class: RuntimeOpaqueValueClass,
        persistence: RuntimeOpaquePersistence,
    ) -> Result<(), LineRuntimeError> {
        let handle_kind = kind.handle_kind();
        if value_class != RuntimeOpaqueValueClass::AffineHandle(handle_kind)
            || persistence != RuntimeOpaquePersistence::SnapshotOnly
            || producer.as_str() != handle_kind.producer_label()
        {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        }
        let valid_shape = match kind {
            RuntimeLineHandleSiteKind::StageActor | RuntimeLineHandleSiteKind::StageLookCue => {
                has_character && !has_scheduled_child
            }
            RuntimeLineHandleSiteKind::ScheduledCue => !has_character && has_scheduled_child,
            RuntimeLineHandleSiteKind::Voice => !has_character && !has_scheduled_child,
        };
        if !valid_shape {
            return Err(LineRuntimeError::InvalidHandleSite);
        }
        Ok(())
    }

    #[must_use]
    pub const fn id(&self) -> RuntimeLineHandleSiteId {
        self.id
    }

    #[must_use]
    pub const fn source_ordinal(&self) -> u32 {
        self.source_ordinal
    }

    #[must_use]
    pub const fn site_kind(&self) -> RuntimeLineHandleSiteKind {
        self.kind
    }

    #[must_use]
    pub const fn kind(&self) -> RuntimeHandleKind {
        self.kind.handle_kind()
    }

    #[must_use]
    pub const fn result_type(&self) -> crate::runtime_id::RuntimePlanTypeId {
        self.result_type
    }

    #[must_use]
    pub const fn character(&self) -> Option<&CharacterId> {
        self.character.as_ref()
    }

    #[must_use]
    pub const fn scheduled_child(&self) -> Option<RuntimeLineTaskNodeId> {
        self.scheduled_child
    }

    #[must_use]
    pub const fn opaque_owner(&self) -> &RuntimeOpaqueTypeOwner {
        &self.opaque_owner
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub enum RuntimeHandleOwnerSlot {
    LineScope,
    ActivationLocal(RuntimeOwnedSlotId),
    /// A reached lexical defer packet before its child body starts.
    ScopedDefer(RuntimeDeferRegistrationId),
    /// A skipped lexical defer whose capture still has a pending host release.
    RetiringScopedDefer(RuntimeDeferRegistrationId),
    ChildScope(LineTaskWorkTag),
    DialogueResult(RuntimeValuePath),
    ParentFiber {
        /// The execution that authorized publication, independent of the
        /// physical namespace used by an attached child's local slot.
        receiver_execution: crate::runtime_id::ExecutionInstanceId,
        slot: RuntimeOwnedSlotId,
    },
    /// A returned token in another line's pending result. The issuer keeps
    /// the lease and its host-command journal.
    ReceivedDialogueResult {
        receiver: DialogueActivationId,
        path: RuntimeValuePath,
    },
    /// A value parked on a reached Line while the issuer retains its lease.
    LineRegistry {
        receiver: DialogueActivationId,
        key: arcweft_id::LifetimeRegistryKey,
        path: RuntimeValuePath,
    },
    /// The value left the registry. Its issuer still owns cleanup settlement.
    RetiringLineRegistry {
        receiver: DialogueActivationId,
    },
    /// The receiving line discarded its result value while the issuer still
    /// owns release settlement.
    RetiringDialogueResult {
        receiver: DialogueActivationId,
    },
}

impl RuntimeHandleOwnerSlot {
    pub(crate) const fn parent_fiber(
        receiver_execution: crate::runtime_id::ExecutionInstanceId,
        slot: RuntimeOwnedSlotId,
    ) -> Self {
        Self::ParentFiber {
            receiver_execution,
            slot,
        }
    }

    fn validate_published_receiver(
        &self,
        issuer: &DialogueActivationId,
        execution: crate::runtime_id::ExecutionInstanceId,
    ) -> Result<(), LineRuntimeError> {
        match self {
            Self::ParentFiber {
                receiver_execution, ..
            } if *receiver_execution == execution => Ok(()),
            Self::ReceivedDialogueResult { receiver, .. } | Self::LineRegistry { receiver, .. }
                if receiver != issuer && receiver.artifact() == issuer.artifact() =>
            {
                Ok(())
            }
            Self::ReceivedDialogueResult { .. } | Self::LineRegistry { .. } => {
                Err(LineRuntimeError::WrongActivation)
            }
            _ => Err(LineRuntimeError::WrongOwner),
        }
    }

    pub(crate) fn in_dialogue_fiber(
        receiver_execution: crate::runtime_id::ExecutionInstanceId,
        activation: &DialogueActivationId,
        token: &RuntimeLineHandleToken,
        slot: RuntimeOwnedSlotId,
    ) -> Self {
        if token.activation() == activation {
            Self::ActivationLocal(slot)
        } else {
            Self::parent_fiber(receiver_execution, slot)
        }
    }
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RuntimeHandleLeaseState {
    Allocating,
    Active,
    Pending,
    Running,
    Completed,
    Cancelling,
    Cancelled,
    Failed,
    Released,
}

pub(crate) const fn result_lease_was_retired(state: RuntimeHandleLeaseState) -> bool {
    matches!(
        state,
        RuntimeHandleLeaseState::Cancelling
            | RuntimeHandleLeaseState::Cancelled
            | RuntimeHandleLeaseState::Released
    )
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeStageActorLease {
    character: CharacterId,
}

impl RuntimeStageActorLease {
    #[must_use]
    pub const fn new(character: CharacterId) -> Self {
        Self { character }
    }

    #[must_use]
    pub const fn character(&self) -> &CharacterId {
        &self.character
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeCueOrigin {
    Scheduled {
        child: RuntimeLineTaskNodeId,
        deadline: LogicalDuration,
    },
    StageLook,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeCueLease {
    origin: RuntimeCueOrigin,
}

impl RuntimeCueLease {
    #[must_use]
    pub const fn new(origin: RuntimeCueOrigin) -> Self {
        Self { origin }
    }

    #[must_use]
    pub const fn origin(&self) -> &RuntimeCueOrigin {
        &self.origin
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeVoiceLease {
    /// The line owns a voice slot even when resolution yields no playback.
    Unvoiced,
    Playback {
        session: RuntimeVoiceSessionId,
        lease_ordinal: u32,
        stop_on_last_release: bool,
    },
}

impl RuntimeVoiceLease {
    #[must_use]
    pub const fn new(
        session: RuntimeVoiceSessionId,
        lease_ordinal: u32,
        stop_on_last_release: bool,
    ) -> Self {
        Self::Playback {
            session,
            lease_ordinal,
            stop_on_last_release,
        }
    }
}

pub(crate) enum RuntimeVoiceLeaseAdmission {
    Issue(RuntimeVoiceLease),
    Start(RuntimeVoiceStartTicket),
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum RuntimeHandleResource {
    StageActor(RuntimeStageActorLease),
    Cue(RuntimeCueLease),
    Voice(RuntimeVoiceLease),
}

impl RuntimeHandleResource {
    #[must_use]
    pub const fn kind(&self) -> RuntimeHandleKind {
        match self {
            Self::StageActor(_) => RuntimeHandleKind::StageActor,
            Self::Cue(_) => RuntimeHandleKind::Cue,
            Self::Voice(_) => RuntimeHandleKind::Voice,
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeHandleLease {
    token: RuntimeLineHandleToken,
    owner: RuntimeHandleOwnerSlot,
    state: RuntimeHandleLeaseState,
    resource: RuntimeHandleResource,
}

impl RuntimeHandleLease {
    pub(crate) fn validate_deferred_capture(
        &self,
        handle: &crate::value::ownership::RuntimeAffineLineHandle,
        owner: &RuntimeHandleOwnerSlot,
    ) -> Result<(), LineRuntimeError> {
        if self.owner() != owner {
            return Err(LineRuntimeError::WrongOwner);
        }
        if self.resource().kind() != handle.kind() {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        }
        if self.state() == RuntimeHandleLeaseState::Released
            || (matches!(self.resource(), RuntimeHandleResource::StageActor(_))
                && self.state() == RuntimeHandleLeaseState::Allocating)
        {
            return Err(LineRuntimeError::InvalidDeferredTransition);
        }
        Ok(())
    }
    pub(crate) fn validate_active_stage_actor(
        &self,
        character: &CharacterId,
    ) -> Result<(), LineRuntimeError> {
        let RuntimeHandleResource::StageActor(actor) = self.resource() else {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        };
        if actor.character() != character {
            return Err(LineRuntimeError::WrongActorCharacter);
        }
        if self.state() != RuntimeHandleLeaseState::Active {
            return Err(LineRuntimeError::InvalidLeaseTransition {
                expected: RuntimeHandleLeaseState::Active,
                actual: self.state(),
            });
        }
        Ok(())
    }

    #[must_use]
    pub const fn token(&self) -> &RuntimeLineHandleToken {
        &self.token
    }

    #[must_use]
    pub const fn owner(&self) -> &RuntimeHandleOwnerSlot {
        &self.owner
    }

    #[must_use]
    pub const fn state(&self) -> RuntimeHandleLeaseState {
        self.state
    }

    pub(crate) const fn admits_line_registry(&self) -> bool {
        matches!(
            self.state,
            RuntimeHandleLeaseState::Active
                | RuntimeHandleLeaseState::Pending
                | RuntimeHandleLeaseState::Running
                | RuntimeHandleLeaseState::Completed
        )
    }

    #[must_use]
    pub const fn resource(&self) -> &RuntimeHandleResource {
        &self.resource
    }
}

#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub struct RuntimeLineHandleLedger {
    issuance_by_site: BTreeMap<RuntimeLineHandleSiteId, u32>,
    #[serde(with = "journal_rows")]
    leases: BTreeMap<RuntimeLineHandleToken, RuntimeHandleLease>,
}

/// One activation owner; decoding can construct only its inert value storage.
///
/// ```compile_fail
/// use arcweft_core::line_task::RuntimeDialogueActivationState;
/// let _: RuntimeDialogueActivationState<u32> = serde_json::from_str("{}").unwrap();
/// ```
#[derive(Debug, Deserialize, PartialEq, Serialize)]
#[serde(
    deny_unknown_fields,
    bound(
        serialize = "T: Serialize, V: crate::value::InertRuntimeValueStorage, RuntimeScheduledLineTask<V>: Serialize",
        deserialize = "T: Deserialize<'de>, V: crate::value::InertRuntimeValueStorage, RuntimeScheduledLineTask<V>: Deserialize<'de>"
    )
)]
pub struct RuntimeDialogueActivationState<T, V = RuntimeValue> {
    ledger: RuntimeLineHandleLedger,
    #[serde(
        default,
        skip_serializing_if = "crate::effect::RuntimeScopeRegistry::is_empty"
    )]
    line_registry: crate::effect::RuntimeScopeRegistry,
    command_sequence: u64,
    #[serde(with = "journal_rows")]
    issued_commands: BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    #[serde(with = "journal_rows")]
    superseded_commands: BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    resolved_commands: std::collections::BTreeSet<crate::presentation::RuntimeLineCommandId>,
    scheduled: Vec<RuntimeScheduledLineTask<V>>,
    deferred: Vec<RuntimeLineDeferredRegistration<V>>,
    next_defer_registration: RuntimeDeferRegistrationFrontier,
    defer_unwind: Option<RuntimeDeferUnwindState>,
    result: RuntimeDialogueResultState<T, V>,
    frame_released: bool,
    #[serde(skip)]
    prepared_commands: Vec<crate::presentation::RuntimeLineHostCommand>,
}

/// Metadata-only rollback for host outcomes. The ledger and command rows hold
/// handle identities, never runtime values or capture packets.
#[derive(Clone, Debug, PartialEq)]
struct RuntimeDialogueOutcomeJournal {
    ledger: RuntimeLineHandleLedger,
    command_sequence: u64,
    issued_commands: BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    superseded_commands: BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    resolved_commands: std::collections::BTreeSet<crate::presentation::RuntimeLineCommandId>,
    prepared_commands: Vec<crate::presentation::RuntimeLineHostCommand>,
}

/// A checked host-outcome transition over handle and command metadata only.
/// The live activation retains sole custody of its result and capture values
/// until this stage is committed.
#[derive(Debug)]
pub(crate) struct RuntimeDialogueOutcomeStage {
    before: RuntimeDialogueOutcomeJournal,
    after: RuntimeDialogueOutcomeJournal,
}

#[derive(Debug)]
pub(crate) struct RuntimePreparedResultSelection<T> {
    tag: LineTaskWorkTag,
    ty: T,
    journal: RuntimeDialogueOutcomeStage,
    ledger: RuntimeLineHandleLedger,
}

#[derive(Debug)]
pub(crate) struct RuntimePreparedLineCommands {
    journal: RuntimeDialogueOutcomeStage,
}

#[derive(Debug)]
pub(crate) struct RuntimePreparedScheduledPacketTake {
    token: RuntimeLineHandleToken,
    locals: Vec<RuntimeLocalDeclarationId>,
}

pub(crate) struct RuntimePreparedSchedule {
    token: RuntimeLineHandleToken,
    child: RuntimeLineTaskNodeId,
    work: LineTaskWorkTag,
    deadline: LogicalDuration,
    capture_locals: Box<[RuntimeLocalDeclarationId]>,
    observed_count: usize,
}

impl RuntimeDialogueOutcomeStage {
    pub(crate) const fn ledger(&self) -> &RuntimeLineHandleLedger {
        &self.after.ledger
    }

    pub(crate) fn ledger_mut(&mut self) -> &mut RuntimeLineHandleLedger {
        &mut self.after.ledger
    }

    pub(crate) fn issued_command(
        &self,
        command: &crate::presentation::RuntimeLineCommandId,
    ) -> Option<&crate::presentation::RuntimeLineHostCommand> {
        self.after.issued_commands.get(command)
    }

    pub(crate) fn consume_issued_command(
        &mut self,
        command: &crate::presentation::RuntimeLineCommandId,
    ) -> Result<crate::presentation::RuntimeLineHostCommand, LineRuntimeError> {
        let issued = self
            .after
            .issued_commands
            .remove(command)
            .ok_or(LineRuntimeError::UnknownCommandOutcome)?;
        self.after.resolved_commands.insert(command.clone());
        Ok(issued)
    }
}

#[derive(Debug)]
struct RuntimeDeferredRegistrationStage {
    ledger: RuntimeLineHandleLedger,
    commands: Option<RuntimeCommandQueue>,
    decision: RuntimeScopedDeferDecision,
}

#[derive(Debug)]
pub(crate) struct RuntimePreparedNextDeferred {
    exit: ScopeExit,
    registration: Option<RuntimeDeferRegistrationId>,
    transition: Option<RuntimeDeferredRegistrationStage>,
    commands: Option<RuntimeDialogueOutcomeStage>,
}

pub(crate) enum RuntimePreparedScopedDeferUnwind {
    Run(RuntimeLineHandleLedger),
    Skip(RuntimePreparedLineCommands),
}

impl RuntimePreparedScopedDeferUnwind {
    pub(crate) const fn decision(&self) -> RuntimeScopedDeferDecision {
        match self {
            Self::Run(_) => RuntimeScopedDeferDecision::Run,
            Self::Skip(_) => RuntimeScopedDeferDecision::Skipped,
        }
    }
}

/// Borrowed scheduled-packet preflight with a metadata-only ledger candidate.
/// Packet custody moves only when the complete command batch commits.
#[derive(Debug)]
pub(crate) struct RuntimeScheduledCompletionStage {
    before: RuntimeLineHandleLedger,
    ledger: RuntimeLineHandleLedger,
    packets: Vec<RuntimeScheduledPacketTransition>,
}

#[derive(Debug)]
pub(crate) struct RuntimeScheduledChildAdmissionProof {
    token: RuntimeLineHandleToken,
    terminal: RuntimeScheduledState,
    locals: Vec<RuntimeLocalDeclarationId>,
}

#[derive(Debug)]
enum RuntimeScheduledPacketTransition {
    Unstarted {
        token: RuntimeLineHandleToken,
        terminal: RuntimeScheduledState,
    },
    Work {
        token: RuntimeLineHandleToken,
        terminal: RuntimeScheduledState,
    },
}

impl RuntimeScheduledPacketTransition {
    fn token(&self) -> &RuntimeLineHandleToken {
        match self {
            Self::Unstarted { token, .. } | Self::Work { token, .. } => token,
        }
    }
}

impl RuntimeScheduledCompletionStage {
    pub(crate) const fn ledger(&self) -> &RuntimeLineHandleLedger {
        &self.ledger
    }

    pub(crate) fn ledger_mut(&mut self) -> &mut RuntimeLineHandleLedger {
        &mut self.ledger
    }
}

impl RuntimeDialogueOutcomeJournal {
    fn capture<T>(state: &RuntimeDialogueActivationState<T>) -> Self {
        Self {
            ledger: state.ledger.clone(),
            command_sequence: state.command_sequence,
            issued_commands: state.issued_commands.clone(),
            superseded_commands: state.superseded_commands.clone(),
            resolved_commands: state.resolved_commands.clone(),
            prepared_commands: state.prepared_commands.clone(),
        }
    }

    fn restore<T>(self, state: &mut RuntimeDialogueActivationState<T>) {
        state.ledger = self.ledger;
        state.command_sequence = self.command_sequence;
        state.issued_commands = self.issued_commands;
        state.superseded_commands = self.superseded_commands;
        state.resolved_commands = self.resolved_commands;
        state.prepared_commands = self.prepared_commands;
    }
}

impl<T> RuntimeDialogueActivationState<T> {
    /// Visits every runtime value retained by active dialogue result, defer,
    /// and scheduled-capture custody.
    pub(crate) fn visit_runtime_values<E>(
        &self,
        mut visitor: impl FnMut(&RuntimeValue) -> Result<(), E>,
    ) -> Result<(), E> {
        self.visit_retained_value_roots(|value| {
            crate::value::visit_runtime_value_graph(value, &mut visitor)
        })
    }
}

/// Post-publication affine authority retained only while parent-owned handles
/// remain live. Executable dialogue frame, reducer, schedule, and result state
/// are deliberately absent.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct RuntimePublishedDialogueHandles {
    ledger: RuntimeLineHandleLedger,
    command_sequence: u64,
    #[serde(with = "journal_rows")]
    issued_commands: BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    resolved_commands: std::collections::BTreeSet<crate::presentation::RuntimeLineCommandId>,
}

pub(crate) type AwbcRuntimeDialogueActivationSnapshot<T> =
    RuntimeDialogueActivationState<T, crate::value::AwbcRuntimeValueSnapshot>;

impl<T: Clone> Clone for AwbcRuntimeDialogueActivationSnapshot<T> {
    fn clone(&self) -> Self {
        Self {
            ledger: self.ledger.clone(),
            line_registry: self.line_registry.clone(),
            command_sequence: self.command_sequence,
            issued_commands: self.issued_commands.clone(),
            superseded_commands: self.superseded_commands.clone(),
            resolved_commands: self.resolved_commands.clone(),
            scheduled: self.scheduled.clone(),
            deferred: self.deferred.clone(),
            next_defer_registration: self.next_defer_registration,
            defer_unwind: self.defer_unwind.clone(),
            result: self.result.clone(),
            frame_released: self.frame_released,
            prepared_commands: self.prepared_commands.clone(),
        }
    }
}

pub(crate) type AwbcRuntimePublishedDialogueHandlesSnapshot = RuntimePublishedDialogueHandles;

type AwbcRuntimeScheduledLineTaskSnapshot =
    RuntimeScheduledLineTask<crate::value::AwbcRuntimeValueSnapshot>;
type AwbcRuntimeLocalBindingSnapshot = RuntimeLocalBinding<crate::value::AwbcRuntimeValueSnapshot>;
type AwbcRuntimeScheduledCaptureCustodySnapshot =
    RuntimeScheduledCaptureCustody<crate::value::AwbcRuntimeValueSnapshot>;

type AwbcRuntimeDialogueResultSnapshot<T> =
    RuntimeDialogueResultState<T, crate::value::AwbcRuntimeValueSnapshot>;

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct RuntimeHandleDropReceipt {
    commands: Vec<crate::presentation::RuntimeLineHostCommand>,
}

impl RuntimeHandleDropReceipt {
    pub(crate) fn from_commands(
        commands: Vec<crate::presentation::RuntimeLineHostCommand>,
    ) -> Self {
        Self { commands }
    }

    pub(crate) fn into_commands(self) -> Vec<crate::presentation::RuntimeLineHostCommand> {
        self.commands
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct RuntimeDialogueCommitReceipt {
    commands: Vec<crate::presentation::RuntimeLineHostCommand>,
}

impl RuntimeDialogueCommitReceipt {
    pub(crate) fn extend_parent_commands(&mut self, receipt: RuntimeHandleDropReceipt) {
        self.commands.extend(receipt.into_commands());
    }

    pub(crate) fn into_commands(self) -> Vec<crate::presentation::RuntimeLineHostCommand> {
        self.commands
    }
}

#[derive(Debug, Deserialize, PartialEq, Serialize)]
#[serde(
    deny_unknown_fields,
    bound(
        serialize = "T: Serialize, V: crate::value::InertRuntimeValueStorage",
        deserialize = "T: Deserialize<'de>, V: crate::value::InertRuntimeValueStorage"
    )
)]
pub enum RuntimeDialogueResultState<T, V = RuntimeValue> {
    Uncommitted,
    Committed {
        ty: T,
        value: V,
    },
    Selected {
        ty: T,
        value: V,
        source: LineTaskWorkTag,
    },
    Publishing {
        ty: T,
        value: V,
    },
    Published,
    Abandoned,
}

impl<T: Clone> Clone for AwbcRuntimeDialogueResultSnapshot<T> {
    fn clone(&self) -> Self {
        match self {
            Self::Uncommitted => Self::Uncommitted,
            Self::Committed { ty, value } => Self::Committed {
                ty: ty.clone(),
                value: value.clone(),
            },
            Self::Selected { ty, value, source } => Self::Selected {
                ty: ty.clone(),
                value: value.clone(),
                source: source.clone(),
            },
            Self::Publishing { ty, value } => Self::Publishing {
                ty: ty.clone(),
                value: value.clone(),
            },
            Self::Published => Self::Published,
            Self::Abandoned => Self::Abandoned,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RuntimeDialogueTerminalKind {
    Published,
    Abandoned,
}

impl<T: Clone> Default for RuntimeDialogueActivationState<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T: Clone> RuntimeDialogueActivationState<T> {
    #[must_use]
    pub fn new() -> Self {
        Self {
            ledger: RuntimeLineHandleLedger::default(),
            line_registry: crate::effect::RuntimeScopeRegistry::default(),
            command_sequence: 0,
            issued_commands: BTreeMap::new(),
            superseded_commands: BTreeMap::new(),
            resolved_commands: std::collections::BTreeSet::new(),
            scheduled: Vec::new(),
            deferred: Vec::new(),
            next_defer_registration: RuntimeDeferRegistrationFrontier::initial(),
            defer_unwind: None,
            result: RuntimeDialogueResultState::Uncommitted,
            frame_released: false,
            prepared_commands: Vec::new(),
        }
    }

    pub(crate) fn line_registry(
        &self,
    ) -> Result<&crate::effect::RuntimeScopeRegistry, LineRuntimeError> {
        if self.frame_released {
            return Err(LineRuntimeError::ActivationFrameReleased);
        }
        Ok(&self.line_registry)
    }

    pub(crate) fn line_registry_mut(
        &mut self,
    ) -> Result<&mut crate::effect::RuntimeScopeRegistry, LineRuntimeError> {
        if self.frame_released {
            return Err(LineRuntimeError::ActivationFrameReleased);
        }
        Ok(&mut self.line_registry)
    }

    /// Checks the sole lifecycle condition before moving captured affine values.
    pub(crate) fn can_register_deferred(&self) -> Result<(), LineRuntimeError> {
        self.prepare_deferred_identity().map(|_| ())
    }

    fn prepare_deferred_identity(
        &self,
    ) -> Result<RuntimePreparedDeferredRegistration, LineRuntimeError> {
        if self.frame_released {
            return Err(LineRuntimeError::ActivationFrameReleased);
        }
        if self.defer_unwind.is_some() {
            return Err(LineRuntimeError::InvalidDeferredTransition);
        }
        self.next_defer_registration
            .prepare()
            .ok_or(LineRuntimeError::DeferRegistrationIdentityExhausted)
    }

    /// Pushes one dynamic registration onto this activation's line-root stack.
    /// Repeated registrations of the same site are retained independently.
    pub fn register_deferred(
        &mut self,
        site: RuntimeDeferSiteId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: Vec<RuntimeValue>,
    ) -> Result<RuntimeDeferRegistrationId, LineRuntimeError> {
        let prepared = self.inspect_deferred_registration(&captures)?;
        Ok(self.register_deferred_prepared(site, outcome_filter, captures, prepared))
    }

    pub(crate) fn register_deferred_prepared(
        &mut self,
        site: RuntimeDeferSiteId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: Vec<RuntimeValue>,
        prepared: RuntimePreparedDeferredRegistration,
    ) -> RuntimeDeferRegistrationId {
        let registration =
            self.commit_deferred_registration(site, outcome_filter, captures, prepared);
        let id = registration.id();
        self.deferred.push(registration);
        id
    }

    /// Preflights every lifecycle and lease check before an executor takes
    /// the capture packet from registers or lexical locals.
    pub(crate) fn inspect_deferred_registration(
        &self,
        captures: &[RuntimeValue],
    ) -> Result<RuntimePreparedDeferredRegistration, LineRuntimeError> {
        self.inspect_deferred_registration_refs(&captures.iter().collect::<Vec<_>>())
    }

    pub(crate) fn inspect_deferred_registration_refs(
        &self,
        captures: &[&RuntimeValue],
    ) -> Result<RuntimePreparedDeferredRegistration, LineRuntimeError> {
        self.inspect_deferred_registration_with(captures, |_, _| {
            Err(LineRuntimeError::UnknownHandle)
        })
    }

    /// The executor authenticates received captures against their original
    /// issuer and exact source slot; this activation only owns its own leases.
    pub(crate) fn inspect_deferred_registration_with(
        &self,
        captures: &[&RuntimeValue],
        mut inspect_received: impl FnMut(
            &crate::value::ownership::RuntimeAffineLineHandle,
            usize,
        ) -> Result<(), LineRuntimeError>,
    ) -> Result<RuntimePreparedDeferredRegistration, LineRuntimeError> {
        let prepared = self.prepare_deferred_identity()?;
        let mut tokens = std::collections::BTreeSet::new();
        for (ordinal, capture) in captures.iter().enumerate() {
            for handle in capture
                .line_handle_projection()
                .map_err(|_| LineRuntimeError::InvalidDeferredTransition)?
            {
                if !tokens.insert(handle.token().clone()) {
                    return Err(LineRuntimeError::DuplicateHandleOccurrence);
                }
                let Some(lease) = self.ledger.lease(handle.token()) else {
                    inspect_received(&handle, ordinal)?;
                    continue;
                };
                if lease.resource().kind() != handle.kind() {
                    return Err(LineRuntimeError::WrongOpaqueProducer);
                }
                if matches!(lease.resource(), RuntimeHandleResource::StageActor(_))
                    && lease.state() == RuntimeHandleLeaseState::Allocating
                {
                    return Err(LineRuntimeError::InvalidDeferredTransition);
                }
            }
        }
        Ok(prepared)
    }

    /// Commits the checked registration after its sole capture packet moves.
    pub(crate) fn commit_deferred_registration(
        &mut self,
        site: RuntimeDeferSiteId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: Vec<RuntimeValue>,
        prepared: RuntimePreparedDeferredRegistration,
    ) -> RuntimeLineDeferredRegistration {
        let id = self.next_defer_registration.commit(prepared);
        RuntimeLineDeferredRegistration::new(id, site, outcome_filter, captures)
    }

    /// Allocates a distinct registration for an activation-local lexical scope.
    /// Its owner retains the returned packet until that scope exits; the line
    /// root stack remains reserved for registrations that survive reveal.
    pub(crate) fn allocate_deferred_registration(
        &mut self,
        site: RuntimeDeferSiteId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: Vec<RuntimeValue>,
    ) -> Result<RuntimeLineDeferredRegistration, LineRuntimeError> {
        let prepared = self.inspect_deferred_registration(&captures)?;
        Ok(self.commit_deferred_registration(site, outcome_filter, captures, prepared))
    }

    /// Freezes the exit reason before executing any deferred body. A body
    /// failure cannot restart the stack with a different filter.
    pub(crate) fn begin_deferred_unwind(
        &mut self,
        exit: ScopeExit,
    ) -> Result<(), LineRuntimeError> {
        if self.frame_released {
            return Err(LineRuntimeError::ActivationFrameReleased);
        }
        match &self.defer_unwind {
            Some(unwind) if unwind.exit != exit => Err(LineRuntimeError::InvalidDeferredTransition),
            Some(_) => Ok(()),
            None => {
                self.defer_unwind = Some(RuntimeDeferUnwindState {
                    exit,
                    inflight: None,
                });
                Ok(())
            }
        }
    }

    /// Selects exactly one LIFO registration. Skipped bodies release their
    /// affine packet; runnable bodies transfer custody to one typed child tag.
    pub(crate) fn prepare_next_deferred(
        &mut self,
        activation: &DialogueActivationId,
    ) -> Result<Option<RuntimeDeferUnwindStep>, LineRuntimeError> {
        let exit = self
            .defer_unwind
            .as_ref()
            .ok_or(LineRuntimeError::InvalidDeferredTransition)?
            .exit;
        let prepared = self.inspect_next_deferred(activation, exit)?;
        Ok(self.commit_next_deferred_prepared(prepared))
    }

    /// Preflights the fixed unwind reason, top capture packet, lease moves,
    /// and command journal before any deferred owner is popped.
    pub(crate) fn inspect_next_deferred(
        &mut self,
        activation: &DialogueActivationId,
        exit: ScopeExit,
    ) -> Result<RuntimePreparedNextDeferred, LineRuntimeError> {
        self.inspect_next_deferred_with(activation, exit, |_, _, _| {
            Err(LineRuntimeError::WrongActivation)
        })
    }

    pub(crate) fn inspect_next_deferred_with(
        &mut self,
        activation: &DialogueActivationId,
        exit: ScopeExit,
        inspect_received: impl FnMut(
            &crate::value::ownership::RuntimeAffineLineHandle,
            RuntimeDeferRegistrationId,
            u32,
        ) -> Result<(), LineRuntimeError>,
    ) -> Result<RuntimePreparedNextDeferred, LineRuntimeError> {
        if self.frame_released {
            return Err(LineRuntimeError::ActivationFrameReleased);
        }
        if let Some(unwind) = &self.defer_unwind
            && (unwind.exit != exit || unwind.inflight.is_some())
        {
            return Err(LineRuntimeError::InvalidDeferredTransition);
        }
        let Some(registration) = self.deferred.last() else {
            return Ok(RuntimePreparedNextDeferred {
                exit,
                registration: None,
                transition: None,
                commands: None,
            });
        };
        let id = registration.id();
        let mut transition = self.stage_deferred_registration(
            activation,
            id,
            registration.outcome_filter(),
            registration.captures(),
            exit,
            RuntimeHandleOwnerSlot::LineScope,
            inspect_received,
        )?;
        let commands = if let Some(queue) = transition.commands.take() {
            let before = RuntimeDialogueOutcomeJournal::capture(self);
            self.record_commands(activation, queue)?;
            let after = RuntimeDialogueOutcomeJournal::capture(self);
            before.clone().restore(self);
            Some(RuntimeDialogueOutcomeStage { before, after })
        } else {
            None
        };
        Ok(RuntimePreparedNextDeferred {
            exit,
            registration: Some(id),
            transition: Some(transition),
            commands,
        })
    }

    /// Applies a checked top-of-stack transition and moves its sole capture
    /// packet to the selected child or drops it after staged release commands.
    pub(crate) fn commit_next_deferred_prepared(
        &mut self,
        prepared: RuntimePreparedNextDeferred,
    ) -> Option<RuntimeDeferUnwindStep> {
        let RuntimePreparedNextDeferred {
            exit,
            registration,
            transition,
            commands,
        } = prepared;
        assert!(
            self.defer_unwind
                .as_ref()
                .is_none_or(|unwind| { unwind.exit == exit && unwind.inflight.is_none() })
        );
        assert_eq!(
            self.deferred
                .last()
                .map(RuntimeLineDeferredRegistration::id),
            registration
        );
        if let Some(commands) = commands {
            self.commit_runtime_outcomes(commands);
        }
        self.defer_unwind.get_or_insert(RuntimeDeferUnwindState {
            exit,
            inflight: None,
        });
        let transition = transition?;
        self.ledger = transition.ledger;
        let registration = self.deferred.pop().expect("checked pending defer exists");
        let step = match transition.decision {
            RuntimeScopedDeferDecision::Run => {
                self.defer_unwind.as_mut().expect("unwind exists").inflight =
                    Some(RuntimeDeferInFlight {
                        id: registration.id(),
                        site: registration.site(),
                    });
                RuntimeDeferUnwindStep::Run(registration)
            }
            RuntimeScopedDeferDecision::Skipped => {
                RuntimeDeferUnwindStep::Skipped(registration.id())
            }
        };
        Some(step)
    }

    /// Atomically transfers or drops one registration owned by an activation
    /// lexical scope. The caller retains its scope stack and fixed exit reason.
    pub(crate) fn prepare_scoped_deferred(
        &mut self,
        activation: &DialogueActivationId,
        registration: &RuntimeLineDeferredRegistration,
        exit: ScopeExit,
    ) -> Result<RuntimeScopedDeferDecision, LineRuntimeError> {
        let prepared = self.inspect_scoped_defer_unwind(
            activation,
            registration.id(),
            registration.outcome_filter(),
            registration.captures(),
            exit,
        )?;
        let decision = prepared.decision();
        self.commit_scoped_defer_unwind(prepared);
        Ok(decision)
    }

    pub(crate) fn inspect_scoped_defer_unwind(
        &mut self,
        activation: &DialogueActivationId,
        id: RuntimeDeferRegistrationId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: &[RuntimeValue],
        exit: ScopeExit,
    ) -> Result<RuntimePreparedScopedDeferUnwind, LineRuntimeError> {
        self.inspect_scoped_defer_unwind_with(
            activation,
            id,
            outcome_filter,
            captures,
            exit,
            |_, _, _| Err(LineRuntimeError::WrongActivation),
        )
    }

    pub(crate) fn inspect_scoped_defer_unwind_with(
        &mut self,
        activation: &DialogueActivationId,
        id: RuntimeDeferRegistrationId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: &[RuntimeValue],
        exit: ScopeExit,
        inspect_received: impl FnMut(
            &crate::value::ownership::RuntimeAffineLineHandle,
            RuntimeDeferRegistrationId,
            u32,
        ) -> Result<(), LineRuntimeError>,
    ) -> Result<RuntimePreparedScopedDeferUnwind, LineRuntimeError> {
        if self.frame_released || self.defer_unwind.is_some() {
            return Err(LineRuntimeError::InvalidDeferredTransition);
        }
        let owner = RuntimeHandleOwnerSlot::ScopedDefer(id);
        let stage = self.stage_deferred_registration(
            activation,
            id,
            outcome_filter,
            captures,
            exit,
            owner,
            inspect_received,
        )?;
        match stage.commands {
            Some(commands) => self
                .inspect_record_commands_with_ledger(activation, &commands, None, stage.ledger)
                .map(RuntimePreparedScopedDeferUnwind::Skip),
            None => Ok(RuntimePreparedScopedDeferUnwind::Run(stage.ledger)),
        }
    }

    pub(crate) fn commit_scoped_defer_unwind(
        &mut self,
        prepared: RuntimePreparedScopedDeferUnwind,
    ) {
        match prepared {
            RuntimePreparedScopedDeferUnwind::Run(ledger) => self.commit_ledger(ledger),
            RuntimePreparedScopedDeferUnwind::Skip(commands) => {
                self.record_commands_prepared(commands)
            }
        }
    }

    fn stage_deferred_registration(
        &self,
        activation: &DialogueActivationId,
        id: RuntimeDeferRegistrationId,
        outcome_filter: RuntimeDeferOutcomeFilter,
        captures: &[RuntimeValue],
        exit: ScopeExit,
        owner: RuntimeHandleOwnerSlot,
        mut inspect_received: impl FnMut(
            &crate::value::ownership::RuntimeAffineLineHandle,
            RuntimeDeferRegistrationId,
            u32,
        ) -> Result<(), LineRuntimeError>,
    ) -> Result<RuntimeDeferredRegistrationStage, LineRuntimeError> {
        let mut tokens = std::collections::BTreeSet::new();
        let mut local_tokens = std::collections::BTreeSet::new();
        for (ordinal, capture) in captures.iter().enumerate() {
            for handle in capture
                .line_handle_projection()
                .map_err(|_| LineRuntimeError::InvalidDeferredTransition)?
            {
                if !tokens.insert(handle.token().clone()) {
                    return Err(LineRuntimeError::InvalidDeferredTransition);
                }
                if handle.token().activation() != activation {
                    inspect_received(
                        &handle,
                        id,
                        u32::try_from(ordinal).map_err(|_| LineRuntimeError::OwnedSlotOverflow)?,
                    )?;
                    continue;
                }
                local_tokens.insert(handle.token().clone());
                let lease = self
                    .ledger
                    .lease(handle.token())
                    .ok_or(LineRuntimeError::UnknownHandle)?;
                if lease.owner() != &owner || lease.resource().kind() != handle.kind() {
                    return Err(LineRuntimeError::WrongOwner);
                }
            }
        }
        let mut ledger = self.ledger.clone();
        let (commands, decision) = if outcome_filter.matches(exit) {
            let tag =
                LineTaskWorkTag::activation(activation.clone(), super::LineTaskWork::Defer(id));
            for token in &local_tokens {
                ledger.transfer(
                    token,
                    &owner,
                    RuntimeHandleOwnerSlot::ChildScope(tag.clone()),
                )?;
            }
            (None, RuntimeScopedDeferDecision::Run)
        } else {
            let mut queue = RuntimeCommandQueue::new(activation.clone(), self.command_sequence);
            for token in &local_tokens {
                ledger.drop_owned(token, &owner, &mut queue)?;
            }
            (Some(queue), RuntimeScopedDeferDecision::Skipped)
        };
        Ok(RuntimeDeferredRegistrationStage {
            ledger,
            commands,
            decision,
        })
    }

    /// Completes only the child named by the activation's in-flight record.
    pub(crate) fn complete_deferred_child(
        &mut self,
        activation: &DialogueActivationId,
        id: RuntimeDeferRegistrationId,
        site: RuntimeDeferSiteId,
        live: &std::collections::BTreeSet<RuntimeLineHandleToken>,
    ) -> Result<(), LineRuntimeError> {
        if self
            .defer_unwind
            .as_ref()
            .and_then(|unwind| unwind.inflight)
            != Some(RuntimeDeferInFlight { id, site })
        {
            return Err(LineRuntimeError::InvalidDeferredTransition);
        }
        let tag = LineTaskWorkTag::activation(activation.clone(), super::LineTaskWork::Defer(id));
        self.finish_child_scope(
            &tag,
            live,
            &std::collections::BTreeSet::new(),
            RuntimeDropPolicy::Default,
        )?;
        self.defer_unwind.as_mut().expect("unwind exists").inflight = None;
        Ok(())
    }

    /// Closes a lexical-scope defer child after its owning frame has verified
    /// the exact in-flight registration and frozen exit reason. The shared
    /// ledger handles capture drops; it does not invent a second scope stack.
    pub(crate) fn complete_scoped_deferred_child(
        &mut self,
        activation: &DialogueActivationId,
        id: RuntimeDeferRegistrationId,
        live: &std::collections::BTreeSet<RuntimeLineHandleToken>,
    ) -> Result<(), LineRuntimeError> {
        let tag = LineTaskWorkTag::activation(activation.clone(), super::LineTaskWork::Defer(id));
        self.finish_child_scope(
            &tag,
            live,
            &std::collections::BTreeSet::new(),
            RuntimeDropPolicy::Default,
        )
    }

    /// Returns the currently pending line-root registrations in stack order.
    #[must_use]
    pub fn deferred_registrations(&self) -> &[RuntimeLineDeferredRegistration] {
        &self.deferred
    }

    /// Once the exit is frozen, a deferred-body failure cannot change which
    /// outcome-filtered registrations run.
    #[must_use]
    pub(crate) fn deferred_exit(&self) -> Option<ScopeExit> {
        self.defer_unwind.as_ref().map(|unwind| unwind.exit)
    }

    /// Validates saved defer sites against the executable table that owns them.
    /// The registry remains backend-neutral; each executable owner supplies
    /// the site-membership rule for its own table.
    pub fn validate_deferred_sites(
        &self,
        mut contains_site: impl FnMut(RuntimeDeferSiteId) -> bool,
    ) -> Result<(), LineRuntimeError> {
        if let Some(registration) = self
            .deferred
            .iter()
            .find(|registration| !contains_site(registration.site()))
        {
            return Err(LineRuntimeError::UnknownDeferredSite {
                site: registration.site(),
            });
        }
        if let Some(inflight) = self
            .defer_unwind
            .as_ref()
            .and_then(|unwind| unwind.inflight)
            && !contains_site(inflight.site)
        {
            return Err(LineRuntimeError::UnknownDeferredSite {
                site: inflight.site,
            });
        }
        Ok(())
    }

    pub(crate) const fn command_sequence(&self) -> u64 {
        self.command_sequence
    }

    #[must_use]
    pub(crate) fn has_pending_commands(&self) -> bool {
        !self.issued_commands.is_empty() || !self.superseded_commands.is_empty()
    }

    pub(crate) fn scheduled(&self) -> &[RuntimeScheduledLineTask] {
        &self.scheduled
    }

    pub(crate) fn scheduled_packet_for_child(
        &self,
        token: &RuntimeLineHandleToken,
    ) -> Result<&[RuntimeLocalBinding], LineRuntimeError> {
        let packet = self
            .scheduled
            .iter()
            .find(|scheduled| scheduled.token() == token)
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        packet.packet_for_child_fiber()
    }

    pub(crate) fn inspect_scheduled_packet_take(
        &self,
        token: &RuntimeLineHandleToken,
    ) -> Result<RuntimePreparedScheduledPacketTake, LineRuntimeError> {
        let packet = self.scheduled_packet_for_child(token)?;
        Ok(RuntimePreparedScheduledPacketTake {
            token: token.clone(),
            locals: packet.iter().map(|binding| binding.local).collect(),
        })
    }

    pub(crate) fn take_scheduled_capture_packet_prepared(
        &mut self,
        prepared: RuntimePreparedScheduledPacketTake,
    ) -> Box<[RuntimeLocalBinding]> {
        let packet = self
            .take_scheduled_capture_packet(&prepared.token)
            .expect("checked scheduled packet remains available for child transfer");
        assert_eq!(
            packet
                .iter()
                .map(|binding| binding.local)
                .collect::<Vec<_>>(),
            prepared.locals,
            "scheduled child packet must match its borrowed proof"
        );
        packet
    }

    pub(crate) fn take_scheduled_capture_packet(
        &mut self,
        token: &RuntimeLineHandleToken,
    ) -> Result<Box<[RuntimeLocalBinding]>, LineRuntimeError> {
        let packet = exact_scheduled_packet_mut(&mut self.scheduled, token)?;
        packet.take_packet_for_child_fiber()
    }

    pub(crate) fn admit_scheduled_child_bindings(
        &mut self,
        token: &RuntimeLineHandleToken,
        bindings: Box<[RuntimeLocalSlot]>,
        terminal: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        let proof = self.inspect_scheduled_child_bindings(token, &bindings, terminal)?;
        self.admit_scheduled_child_bindings_prepared(proof, bindings);
        Ok(())
    }

    pub(crate) fn inspect_scheduled_child_bindings(
        &self,
        token: &RuntimeLineHandleToken,
        bindings: &[RuntimeLocalSlot],
        terminal: RuntimeScheduledState,
    ) -> Result<RuntimeScheduledChildAdmissionProof, LineRuntimeError> {
        let references = bindings
            .iter()
            .map(|binding| (binding.local(), binding.storage()))
            .collect::<Vec<_>>();
        self.inspect_scheduled_child_binding_refs(token, &references, terminal)
    }

    pub(crate) fn inspect_scheduled_child_binding_refs(
        &self,
        token: &RuntimeLineHandleToken,
        bindings: &[(
            RuntimeLocalDeclarationId,
            &RuntimePlaceStorage<RuntimeValue>,
        )],
        terminal: RuntimeScheduledState,
    ) -> Result<RuntimeScheduledChildAdmissionProof, LineRuntimeError> {
        let packet = self
            .scheduled
            .iter()
            .find(|scheduled| scheduled.token() == token)
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        packet.inspect_child_fiber_binding_refs(bindings, terminal)?;
        Ok(RuntimeScheduledChildAdmissionProof {
            token: token.clone(),
            terminal,
            locals: bindings.iter().map(|(local, _)| *local).collect(),
        })
    }

    pub(crate) fn admit_scheduled_child_bindings_prepared(
        &mut self,
        proof: RuntimeScheduledChildAdmissionProof,
        bindings: Box<[RuntimeLocalSlot]>,
    ) {
        assert_eq!(
            bindings
                .iter()
                .map(|binding| binding.local())
                .collect::<Vec<_>>(),
            proof.locals,
            "scheduled child bindings must match their borrowed admission proof"
        );
        let packet = exact_scheduled_packet_mut(&mut self.scheduled, &proof.token)
            .expect("checked scheduled child packet remains present");
        packet
            .admit_child_fiber_bindings(bindings, proof.terminal)
            .expect("checked scheduled child admission remains valid");
    }

    pub(crate) fn scheduled_child_locals(
        &self,
        token: &RuntimeLineHandleToken,
    ) -> Result<Box<[RuntimeLocalDeclarationId]>, LineRuntimeError> {
        let packet = self
            .scheduled
            .iter()
            .find(|scheduled| scheduled.token() == token)
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        Ok(packet.child_fiber_locals()?.to_vec().into_boxed_slice())
    }

    pub(crate) fn terminalize_unstarted_scheduled_packet(
        &mut self,
        token: &RuntimeLineHandleToken,
        terminal: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        let packet = exact_scheduled_packet_mut(&mut self.scheduled, token)?;
        packet.move_packet_to_line_scope(terminal)
    }

    pub(crate) fn complete_unstarted_scheduled(
        &mut self,
        completion: &LineTaskScheduledCompletion,
    ) -> Result<(), LineRuntimeError> {
        let mut stage = self.begin_scheduled_completion_stage();
        self.stage_unstarted_scheduled_completion(&mut stage, completion)?;
        self.commit_scheduled_completion_stage(stage);
        Ok(())
    }

    #[must_use]
    pub(crate) fn begin_scheduled_completion_stage(&self) -> RuntimeScheduledCompletionStage {
        RuntimeScheduledCompletionStage {
            before: self.ledger.clone(),
            ledger: self.ledger.clone(),
            packets: Vec::new(),
        }
    }

    pub(crate) fn stage_unstarted_scheduled_completion(
        &self,
        stage: &mut RuntimeScheduledCompletionStage,
        completion: &LineTaskScheduledCompletion,
    ) -> Result<(), LineRuntimeError> {
        let terminal = match completion.exit() {
            ScopeExit::Completed => RuntimeScheduledState::Completed,
            ScopeExit::Cancelled => RuntimeScheduledState::Cancelled,
            ScopeExit::Failed => RuntimeScheduledState::Failed,
        };
        if stage
            .packets
            .iter()
            .any(|transition| transition.token() == completion.token())
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        let packet = self
            .scheduled
            .iter()
            .find(|scheduled| scheduled.token() == completion.token())
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        stage_unstarted_scheduled_completion(&mut stage.ledger, packet, terminal)?;
        stage
            .packets
            .push(RuntimeScheduledPacketTransition::Unstarted {
                token: completion.token().clone(),
                terminal,
            });
        Ok(())
    }

    pub(crate) fn stage_scheduled_work_completion(
        &self,
        stage: &mut RuntimeScheduledCompletionStage,
        token: &RuntimeLineHandleToken,
        failed: bool,
        cancelled: bool,
    ) -> Result<(), LineRuntimeError> {
        if stage
            .packets
            .iter()
            .any(|transition| transition.token() == token)
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        let packet = self
            .scheduled
            .iter()
            .find(|scheduled| scheduled.token() == token)
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        let (expected, terminal) = scheduled_work_terminal(packet.state(), failed, cancelled)?;
        packet.require_line_scope()?;
        if expected != terminal
            && (!scheduled_transition_is_legal(expected, terminal)
                || !scheduled_custody_is_admissible(terminal, &packet.custody))
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        stage_scheduled_capture_completion(
            &mut stage.ledger,
            packet,
            terminal,
            packet
                .line_scope_captures()?
                .iter()
                .flat_map(|binding| binding.storage().values()),
        )?;
        stage.packets.push(RuntimeScheduledPacketTransition::Work {
            token: token.clone(),
            terminal,
        });
        Ok(())
    }

    pub(crate) fn stage_scheduled_child_work_completion(
        &self,
        stage: &mut RuntimeScheduledCompletionStage,
        proof: &RuntimeScheduledChildAdmissionProof,
        bindings: &[RuntimeLocalSlot],
        failed: bool,
        cancelled: bool,
    ) -> Result<(), LineRuntimeError> {
        let references = bindings
            .iter()
            .map(|binding| (binding.local(), binding.storage()))
            .collect::<Vec<_>>();
        self.stage_scheduled_child_work_completion_refs(
            stage,
            proof,
            &references,
            failed,
            cancelled,
        )
    }

    pub(crate) fn stage_scheduled_child_work_completion_refs(
        &self,
        stage: &mut RuntimeScheduledCompletionStage,
        proof: &RuntimeScheduledChildAdmissionProof,
        bindings: &[(
            RuntimeLocalDeclarationId,
            &RuntimePlaceStorage<RuntimeValue>,
        )],
        failed: bool,
        cancelled: bool,
    ) -> Result<(), LineRuntimeError> {
        if stage
            .packets
            .iter()
            .any(|transition| transition.token() == &proof.token)
            || bindings.iter().map(|(local, _)| *local).collect::<Vec<_>>() != proof.locals
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        let packet = self
            .scheduled
            .iter()
            .find(|scheduled| scheduled.token() == &proof.token)
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        packet.inspect_child_fiber_binding_refs(bindings, proof.terminal)?;
        let (_, terminal) = scheduled_work_terminal(packet.state(), failed, cancelled)?;
        if terminal != proof.terminal {
            return Err(LineRuntimeError::InvalidScheduledWorkState);
        }
        stage_scheduled_capture_completion(
            &mut stage.ledger,
            packet,
            terminal,
            bindings.iter().flat_map(|(_, storage)| storage.values()),
        )?;
        stage.packets.push(RuntimeScheduledPacketTransition::Work {
            token: proof.token.clone(),
            terminal,
        });
        Ok(())
    }

    /// Simulates final child custody on a metadata-only scheduled completion
    /// candidate. The caller may keep appending drop commands until its whole
    /// dynamic line command batch has passed preflight.
    pub(crate) fn stage_child_scope_finish(
        &self,
        stage: &mut RuntimeScheduledCompletionStage,
        commands: &mut RuntimeCommandQueue,
        tag: &LineTaskWorkTag,
        live: &std::collections::BTreeSet<RuntimeLineHandleToken>,
        returned: &std::collections::BTreeSet<RuntimeLineHandleToken>,
        policy: RuntimeDropPolicy,
    ) -> Result<(), LineRuntimeError> {
        assert_eq!(
            self.ledger, stage.before,
            "child scope preflight must use the current activation ledger"
        );
        stage_child_scope_finish(&mut stage.ledger, commands, tag, live, returned, policy)
    }

    pub(crate) fn commit_scheduled_completion_stage(
        &mut self,
        stage: RuntimeScheduledCompletionStage,
    ) {
        assert_eq!(
            self.ledger, stage.before,
            "scheduled completion proof must match the original ledger"
        );
        for transition in stage.packets {
            match transition {
                RuntimeScheduledPacketTransition::Unstarted { token, terminal } => {
                    let packet = exact_scheduled_packet_mut(&mut self.scheduled, &token)
                        .expect("checked scheduled packet remains present");
                    packet
                        .move_packet_to_line_scope(terminal)
                        .expect("checked scheduled packet transition remains valid");
                }
                RuntimeScheduledPacketTransition::Work { token, terminal } => {
                    let packet = exact_scheduled_packet_mut(&mut self.scheduled, &token)
                        .expect("checked scheduled packet remains present");
                    packet.state = terminal;
                }
            }
        }
        self.ledger = stage.ledger;
    }

    pub(crate) fn take_commit_receipt(&mut self) -> RuntimeDialogueCommitReceipt {
        RuntimeDialogueCommitReceipt {
            commands: std::mem::take(&mut self.prepared_commands),
        }
    }

    pub(crate) fn replace_transaction_parts(
        &mut self,
        ledger: RuntimeLineHandleLedger,
        scheduled: Vec<RuntimeScheduledLineTask>,
    ) {
        self.ledger = ledger;
        self.scheduled = scheduled;
    }

    pub(crate) fn commit_ledger(&mut self, ledger: RuntimeLineHandleLedger) {
        self.ledger = ledger;
    }

    pub(crate) fn inspect_schedule(
        &self,
        token: &RuntimeLineHandleToken,
        child: RuntimeLineTaskNodeId,
        work: &LineTaskWorkTag,
        deadline: LogicalDuration,
        capture_locals: &[RuntimeLocalDeclarationId],
    ) -> Result<RuntimePreparedSchedule, LineRuntimeError> {
        if self.scheduled.len() >= MAX_LINE_SCHEDULED_CALLBACKS {
            return Err(LineRuntimeError::ScheduledCallbackLimitExceeded);
        }
        if self
            .scheduled
            .iter()
            .any(|existing| existing.token() == token)
        {
            return Err(LineRuntimeError::DuplicateHandleToken);
        }
        if work.scheduled_token() != Some(token)
            || !matches!(work.work(), super::LineTaskWork::Node(_))
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureOwner);
        }
        if !local_ids_are_unique(capture_locals.iter().copied()) {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        Ok(RuntimePreparedSchedule {
            token: token.clone(),
            child,
            work: work.clone(),
            deadline,
            capture_locals: capture_locals.to_vec().into_boxed_slice(),
            observed_count: self.scheduled.len(),
        })
    }

    pub(crate) fn schedule_prepared(
        &mut self,
        prepared: RuntimePreparedSchedule,
        captures: Box<[RuntimeLocalBinding]>,
    ) {
        assert_eq!(self.scheduled.len(), prepared.observed_count);
        assert!(
            captures
                .iter()
                .map(|binding| binding.local)
                .eq(prepared.capture_locals.iter().copied()),
            "prepared schedule requires the same owned capture packet"
        );
        self.scheduled.push(RuntimeScheduledLineTask {
            token: prepared.token,
            child: prepared.child,
            work: prepared.work,
            deadline: prepared.deadline,
            custody: RuntimeScheduledCaptureCustody::Packet(captures),
            state: RuntimeScheduledState::Armed,
        });
    }

    pub(crate) fn advance_schedules(
        &mut self,
        elapsed: LogicalDuration,
        reducer: &mut LineTaskLiveState,
    ) -> Result<(), LineRuntimeError> {
        if reducer.is_closing() || reducer.is_closed() {
            return Ok(());
        }
        if !self.scheduled.iter().any(|packet| {
            (packet.state() == RuntimeScheduledState::Armed && packet.deadline() <= elapsed)
                || (matches!(
                    packet.state(),
                    RuntimeScheduledState::Armed | RuntimeScheduledState::Running
                ) && self.ledger.lease(packet.token()).is_some_and(|lease| {
                    matches!(
                        lease.owner(),
                        RuntimeHandleOwnerSlot::RetiringLineRegistry { .. }
                    )
                }))
        }) {
            return Ok(());
        }
        let mut ledger = self.ledger.clone();
        let mut staged_reducer = reducer.clone();
        let mut due = Vec::new();
        let mut cancelled = Vec::new();
        let mut cancelling = Vec::new();
        for (index, callback) in self.scheduled.iter().enumerate() {
            let lease = ledger
                .lease(callback.token())
                .ok_or(LineRuntimeError::UnknownHandle)?;
            if matches!(
                lease.owner(),
                RuntimeHandleOwnerSlot::RetiringLineRegistry { .. }
            ) {
                match callback.state() {
                    RuntimeScheduledState::Armed => {
                        stage_unstarted_scheduled_completion(
                            &mut ledger,
                            callback,
                            RuntimeScheduledState::Cancelled,
                        )?;
                        cancelled.push(index);
                        continue;
                    }
                    RuntimeScheduledState::Running => {
                        if staged_reducer.cancel_scheduled_cue(callback.token())? {
                            ledger.set_state(
                                callback.token(),
                                RuntimeHandleLeaseState::Running,
                                RuntimeHandleLeaseState::Cancelling,
                            )?;
                            cancelling.push(index);
                        } else {
                            stage_unstarted_scheduled_completion(
                                &mut ledger,
                                callback,
                                RuntimeScheduledState::Cancelled,
                            )?;
                            cancelled.push(index);
                        }
                        continue;
                    }
                    _ => {}
                }
            }
            if callback.state() == RuntimeScheduledState::Armed && callback.deadline() <= elapsed {
                if callback.validate_custody().is_err()
                    || !scheduled_custody_is_admissible(
                        RuntimeScheduledState::Running,
                        &callback.custody,
                    )
                {
                    return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
                }
                ledger.set_state(
                    callback.token(),
                    RuntimeHandleLeaseState::Pending,
                    RuntimeHandleLeaseState::Running,
                )?;
                due.push((
                    callback.deadline(),
                    callback.token().clone(),
                    callback.child(),
                    index,
                ));
            }
        }
        due.sort();
        for (_, token, _, _) in &due {
            staged_reducer.mark_scheduled_ready(token.clone())?;
        }
        for (_, _, _, index) in due {
            self.scheduled[index].state = RuntimeScheduledState::Running;
        }
        for index in cancelled {
            self.scheduled[index]
                .move_packet_to_line_scope(RuntimeScheduledState::Cancelled)
                .expect("checked scheduled packet transition remains valid");
        }
        for index in cancelling {
            self.scheduled[index].state = RuntimeScheduledState::Cancelling;
        }
        self.ledger = ledger;
        *reducer = staged_reducer;
        Ok(())
    }

    pub(crate) fn complete_scheduled_work(
        &mut self,
        token: &RuntimeLineHandleToken,
        failed: bool,
        cancelled: bool,
    ) -> Result<(), LineRuntimeError> {
        let mut stage = self.begin_scheduled_completion_stage();
        self.stage_scheduled_work_completion(&mut stage, token, failed, cancelled)?;
        self.commit_scheduled_completion_stage(stage);
        Ok(())
    }

    pub(crate) fn record_commands(
        &mut self,
        activation: &DialogueActivationId,
        queue: crate::presentation::RuntimeCommandQueue,
    ) -> Result<(), LineRuntimeError> {
        if queue.activation() != activation || queue.start_sequence() != self.command_sequence {
            return Err(LineRuntimeError::StaleCommandQueue);
        }
        let next_sequence = queue.next_sequence();
        let commands = queue.into_commands();
        if self
            .issued_commands
            .len()
            .checked_add(self.superseded_commands.len())
            .and_then(|count| count.checked_add(self.resolved_commands.len()))
            .and_then(|count| count.checked_add(commands.len()))
            .is_none_or(|count| count > MAX_LINE_COMMAND_HISTORY)
        {
            return Err(LineRuntimeError::CommandHistoryLimitExceeded);
        }
        let mut issued = self.issued_commands.clone();
        let mut superseded = self.superseded_commands.clone();
        for command in &commands {
            if let crate::presentation::RuntimeLineHostCommand::Stage(
                crate::presentation::RuntimeStageCommand::CancelCue { cue, .. },
            ) = command
            {
                let retired = issued
                    .iter()
                    .filter(|(_, prior)| {
                        matches!(
                            prior,
                            crate::presentation::RuntimeLineHostCommand::Stage(
                                crate::presentation::RuntimeStageCommand::SetCharacterLook {
                                    cue: prior_cue,
                                    ..
                                }
                            ) if prior_cue == cue
                        )
                    })
                    .map(|(id, _)| id.clone())
                    .collect::<Vec<_>>();
                for id in retired {
                    if let Some(command) = issued.remove(&id) {
                        superseded.insert(id, command);
                    }
                }
            }
            if issued
                .insert(command.command().clone(), command.clone())
                .is_some()
                || superseded.contains_key(command.command())
                || self.resolved_commands.contains(command.command())
            {
                return Err(LineRuntimeError::DuplicateCommandIdentity);
            }
        }
        self.command_sequence = next_sequence;
        self.issued_commands = issued;
        self.superseded_commands = superseded;
        self.prepared_commands.extend(commands);
        Ok(())
    }

    /// Checks a complete command queue while retaining the current line
    /// journal. Host command rows contain identities and metadata only.
    pub(crate) fn inspect_record_commands(
        &mut self,
        activation: &DialogueActivationId,
        queue: &RuntimeCommandQueue,
    ) -> Result<RuntimePreparedLineCommands, LineRuntimeError> {
        self.inspect_record_commands_with_ledger(activation, queue, None, self.ledger.clone())
    }

    /// Preflights command publication and its checked lease transition as one
    /// metadata transaction. Retained result and capture packets are never
    /// copied, and the caller can move their sole owners after this succeeds.
    pub(crate) fn inspect_record_commands_with_ledger(
        &mut self,
        activation: &DialogueActivationId,
        queue: &RuntimeCommandQueue,
        resolved: Option<&crate::presentation::RuntimeLineCommandId>,
        ledger: RuntimeLineHandleLedger,
    ) -> Result<RuntimePreparedLineCommands, LineRuntimeError> {
        let before = RuntimeDialogueOutcomeJournal::capture(self);
        let result = (|| {
            if let Some(command) = resolved {
                self.consume_issued_command(command)?;
            }
            self.record_commands(activation, queue.clone())?;
            self.ledger = ledger;
            Ok(RuntimeDialogueOutcomeJournal::capture(self))
        })();
        match result {
            Ok(after) => {
                before.clone().restore(self);
                Ok(RuntimePreparedLineCommands {
                    journal: RuntimeDialogueOutcomeStage { before, after },
                })
            }
            Err(error) => {
                before.restore(self);
                Err(error)
            }
        }
    }

    pub(crate) fn record_commands_prepared(&mut self, prepared: RuntimePreparedLineCommands) {
        self.commit_runtime_outcomes(prepared.journal);
    }

    /// Reconciles one running child instruction against the coarse but exact
    /// `ChildScope(tag)` ledger owner. Register-local moves are executor
    /// details; disappearance is a typed drop and newly appearing tokens are
    /// rejected.
    pub(crate) fn reconcile_child_scope_step(
        &mut self,
        tag: &LineTaskWorkTag,
        before: &std::collections::BTreeSet<RuntimeLineHandleToken>,
        after: &std::collections::BTreeSet<RuntimeLineHandleToken>,
        drops: &super::RuntimeHandleDropAuthorization,
    ) -> Result<(), LineRuntimeError> {
        drops.validate_removed(
            |token| before.contains(token),
            |token| after.contains(token),
        )?;
        if after.iter().any(|token| !before.contains(token)) {
            return Err(LineRuntimeError::UnexpectedChildHandleOccurrence);
        }
        let owner = RuntimeHandleOwnerSlot::ChildScope(tag.clone());
        let mut ledger = self.ledger.clone();
        let mut queue =
            RuntimeCommandQueue::new(tag.activation_id().clone(), self.command_sequence);
        for token in before {
            if token.activation() != tag.activation_id() {
                return Err(LineRuntimeError::WrongActivation);
            }
            let lease = ledger.lease(token).ok_or(LineRuntimeError::UnknownHandle)?;
            if lease.owner() != &owner {
                return Err(LineRuntimeError::WrongOwner);
            }
            if !after.contains(token) {
                let policy = drops
                    .policy_for(token)
                    .ok_or(LineRuntimeError::UnjournaledHandleDrop)?;
                ledger.drop_owned_with_policy(token, &owner, policy, &mut queue)?;
            }
        }
        self.record_commands(tag.activation_id(), queue)?;
        self.ledger = ledger;
        Ok(())
    }

    /// Closes child custody by moving only declared surviving capture tokens
    /// back to `LineScope` and dropping every other live token before the child
    /// carrier disappears.
    pub(crate) fn finish_child_scope(
        &mut self,
        tag: &LineTaskWorkTag,
        live: &std::collections::BTreeSet<RuntimeLineHandleToken>,
        returned: &std::collections::BTreeSet<RuntimeLineHandleToken>,
        policy: RuntimeDropPolicy,
    ) -> Result<(), LineRuntimeError> {
        let mut ledger = self.ledger.clone();
        let mut queue =
            RuntimeCommandQueue::new(tag.activation_id().clone(), self.command_sequence);
        stage_child_scope_finish(&mut ledger, &mut queue, tag, live, returned, policy)?;
        self.record_commands(tag.activation_id(), queue)?;
        self.ledger = ledger;
        Ok(())
    }

    pub(crate) fn reconcile_child_registry_owners(
        &mut self,
        activation: &DialogueActivationId,
        before: &BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        after: &BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        drops: &super::RuntimeHandleDropAuthorization,
    ) -> Result<(), LineRuntimeError> {
        if after.keys().any(|token| !before.contains_key(token)) {
            return Err(LineRuntimeError::UnexpectedChildHandleOccurrence);
        }
        let mut ledger = self.ledger.clone();
        let mut queue = RuntimeCommandQueue::new(*activation, self.command_sequence);
        for (token, source) in before
            .iter()
            .filter(|(token, _)| token.activation() == activation)
        {
            if ledger
                .lease(token)
                .ok_or(LineRuntimeError::UnknownHandle)?
                .owner()
                != source
            {
                return Err(LineRuntimeError::WrongOwner);
            }
            match after.get(token) {
                Some(destination) if source == destination => {}
                Some(destination) => ledger.transfer(token, source, destination.clone())?,
                None => ledger.drop_owned_with_policy(
                    token,
                    source,
                    drops
                        .policy_for(token)
                        .ok_or(LineRuntimeError::UnjournaledHandleDrop)?,
                    &mut queue,
                )?,
            }
        }
        self.record_commands(activation, queue)?;
        self.ledger = ledger;
        Ok(())
    }

    pub(crate) fn consume_issued_command(
        &mut self,
        command: &crate::presentation::RuntimeLineCommandId,
    ) -> Result<crate::presentation::RuntimeLineHostCommand, LineRuntimeError> {
        let command = self
            .issued_commands
            .remove(command)
            .ok_or(LineRuntimeError::UnknownCommandOutcome)?;
        self.resolved_commands.insert(command.command().clone());
        Ok(command)
    }

    pub(crate) fn superseded_command(
        &self,
        command: &crate::presentation::RuntimeLineCommandId,
    ) -> Option<&crate::presentation::RuntimeLineHostCommand> {
        self.superseded_commands.get(command)
    }

    pub(crate) fn resolve_superseded(
        &mut self,
        command: &crate::presentation::RuntimeLineCommandId,
    ) -> Option<crate::presentation::RuntimeLineHostCommand> {
        let resolved = self.superseded_commands.remove(command)?;
        self.resolved_commands.insert(command.clone());
        Some(resolved)
    }

    pub(crate) fn resolve_superseded_cue(&mut self, cue: &RuntimeLineHandleToken) {
        let commands = self
            .superseded_commands
            .iter()
            .filter(|(_, command)| {
                matches!(
                    command,
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::SetCharacterLook {
                            cue: prior,
                            ..
                        }
                    ) if prior == cue
                )
            })
            .map(|(id, _)| id.clone())
            .collect::<Vec<_>>();
        for command in commands {
            let _ = self.resolve_superseded(&command);
        }
    }

    pub(crate) fn resolve_issued_cancel_for_cue(&mut self, cue: &RuntimeLineHandleToken) {
        let commands = self
            .issued_commands
            .iter()
            .filter(|(_, command)| {
                matches!(
                    command,
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::CancelCue {
                            cue: pending,
                            ..
                        }
                    ) if pending == cue
                )
            })
            .map(|(id, _)| id.clone())
            .collect::<Vec<_>>();
        for command in commands {
            if self.issued_commands.remove(&command).is_some() {
                self.resolved_commands.insert(command);
            }
        }
    }

    pub(crate) fn is_resolved(&self, command: &crate::presentation::RuntimeLineCommandId) -> bool {
        self.resolved_commands.contains(command)
    }

    /// Reduces one non-activation host outcome against the sole command and
    /// lease journal. Pending Acquire/SetLook acceptance/voice-start tickets
    /// remain the executor frame's responsibility; completion, cancellation,
    /// release, cleanup rejection, and superseded-look races are shared here.
    pub(crate) fn accept_runtime_outcome(
        &mut self,
        outcome: &crate::presentation::RuntimeLineHostOutcome,
    ) -> Result<Option<LineRuntimeError>, LineRuntimeError> {
        let (stage, mut diagnostics) =
            self.stage_runtime_outcomes(std::slice::from_ref(outcome))?;
        self.commit_runtime_outcomes(stage);
        Ok(diagnostics.pop())
    }

    /// Reduces one host delivery batch atomically. Duplicate, stale, or
    /// mismatched evidence rejects the complete batch without advancing any
    /// lease or command journal row.
    pub(crate) fn accept_runtime_outcomes(
        &mut self,
        outcomes: &[crate::presentation::RuntimeLineHostOutcome],
    ) -> Result<Vec<LineRuntimeError>, LineRuntimeError> {
        let (stage, diagnostics) = self.stage_runtime_outcomes(outcomes)?;
        self.commit_runtime_outcomes(stage);
        Ok(diagnostics)
    }

    pub(crate) fn stage_runtime_outcomes(
        &mut self,
        outcomes: &[crate::presentation::RuntimeLineHostOutcome],
    ) -> Result<(RuntimeDialogueOutcomeStage, Vec<LineRuntimeError>), LineRuntimeError> {
        let before = RuntimeDialogueOutcomeJournal::capture(self);
        let result = (|| {
            let mut diagnostics = Vec::new();
            for outcome in outcomes {
                if let Some(diagnostic) = self.reduce_runtime_outcome(outcome)? {
                    diagnostics.push(diagnostic);
                }
            }
            Ok(diagnostics)
        })();
        match result {
            Ok(diagnostics) => {
                let after = RuntimeDialogueOutcomeJournal::capture(self);
                before.clone().restore(self);
                Ok((RuntimeDialogueOutcomeStage { before, after }, diagnostics))
            }
            Err(error) => {
                before.restore(self);
                Err(error)
            }
        }
    }

    pub(crate) fn commit_runtime_outcomes(&mut self, stage: RuntimeDialogueOutcomeStage) {
        assert_eq!(
            RuntimeDialogueOutcomeJournal::capture(self),
            stage.before,
            "staged host outcomes must commit against their original activation metadata"
        );
        stage.after.restore(self);
    }

    /// Runs a read-only pending-operation preflight against the checked host
    /// outcome state without publishing that state or copying retained values.
    pub(crate) fn with_staged_outcomes<R>(
        &mut self,
        stage: &RuntimeDialogueOutcomeStage,
        inspect: impl FnOnce(&Self) -> R,
    ) -> R {
        let before = RuntimeDialogueOutcomeJournal::capture(self);
        assert_eq!(
            before, stage.before,
            "staged host outcomes must inspect their original activation metadata"
        );
        stage.after.clone().restore(self);
        let result = inspect(self);
        before.restore(self);
        result
    }

    fn reduce_runtime_outcome(
        &mut self,
        outcome: &crate::presentation::RuntimeLineHostOutcome,
    ) -> Result<Option<LineRuntimeError>, LineRuntimeError> {
        let command_id = outcome.command();
        let Some(command) = self.issued_commands.get(command_id).cloned() else {
            if self.resolved_commands.contains(command_id) {
                return Err(LineRuntimeError::DuplicateCommandOutcome);
            }
            let Some(command) = self.superseded_commands.get(command_id).cloned() else {
                return Err(LineRuntimeError::UnknownCommandOutcome);
            };
            let crate::presentation::RuntimeLineHostCommand::Stage(
                crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. },
            ) = command
            else {
                return Err(LineRuntimeError::StageOutcomeMismatch);
            };
            return match outcome {
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Accepted {
                        cue: echoed, ..
                    },
                ) if echoed == &cue => Ok(None),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Completed {
                        cue: echoed, ..
                    },
                ) if echoed == &cue => {
                    self.ledger.set_state(
                        &cue,
                        RuntimeHandleLeaseState::Cancelling,
                        RuntimeHandleLeaseState::Released,
                    )?;
                    self.resolve_superseded(command_id);
                    self.resolve_issued_cancel_for_cue(&cue);
                    Ok(None)
                }
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Rejected { .. },
                ) => {
                    self.ledger.set_state(
                        &cue,
                        RuntimeHandleLeaseState::Cancelling,
                        RuntimeHandleLeaseState::Released,
                    )?;
                    self.resolve_superseded(command_id);
                    self.resolve_issued_cancel_for_cue(&cue);
                    Ok(None)
                }
                _ => Err(LineRuntimeError::StageOutcomeMismatch),
            };
        };

        let diagnostic = match (&command, outcome) {
            (
                crate::presentation::RuntimeLineHostCommand::Stage(
                    crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. },
                ),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Completed {
                        cue: echoed, ..
                    },
                ),
            ) if cue == echoed => {
                self.ledger.set_state(
                    cue,
                    RuntimeHandleLeaseState::Running,
                    RuntimeHandleLeaseState::Completed,
                )?;
                self.resolve_superseded_cue(cue);
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Stage(
                    crate::presentation::RuntimeStageCommand::CancelCue { cue, .. },
                ),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Cancelled {
                        cue: echoed, ..
                    },
                ),
            ) if cue == echoed => {
                self.ledger.set_state(
                    cue,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Cancelled,
                )?;
                self.ledger.set_state(
                    cue,
                    RuntimeHandleLeaseState::Cancelled,
                    RuntimeHandleLeaseState::Released,
                )?;
                self.resolve_superseded_cue(cue);
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Stage(
                    crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. },
                ),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::ReleasedActor {
                        actor: echoed,
                        ..
                    },
                ),
            ) if actor == echoed => {
                self.ledger.set_state(
                    actor,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Released,
                )?;
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Voice(
                    crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice {
                        handle, ..
                    },
                ),
                crate::presentation::RuntimeLineHostOutcome::Voice(
                    crate::presentation::RuntimeVoiceCommandOutcome::Released {
                        handle: echoed,
                        ..
                    },
                ),
            ) if handle == echoed => {
                self.ledger.set_state(
                    handle,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Released,
                )?;
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Stage(command),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Rejected { code, .. },
                ),
            ) => {
                fail_command_lease(&mut self.ledger, command)?;
                if let crate::presentation::RuntimeStageCommand::CancelCue { cue, .. } = command {
                    self.resolve_superseded_cue(cue);
                }
                Some(LineRuntimeError::StageCommandRejected { code: *code })
            }
            (
                crate::presentation::RuntimeLineHostCommand::Voice(command),
                crate::presentation::RuntimeLineHostOutcome::Voice(
                    crate::presentation::RuntimeVoiceCommandOutcome::Rejected { failure, .. },
                ),
            ) => {
                fail_voice_command_lease(&mut self.ledger, command)?;
                Some(LineRuntimeError::VoiceStartRejected {
                    failure: failure.clone(),
                })
            }
            _ => return Err(LineRuntimeError::StageOutcomeMismatch),
        };
        self.issued_commands.remove(command_id);
        self.resolved_commands.insert(command_id.clone());
        Ok(diagnostic)
    }

    pub(crate) fn commit_result(
        &mut self,
        ty: T,
        value: RuntimeValue,
    ) -> Result<(), LineRuntimeError> {
        if !matches!(self.result, RuntimeDialogueResultState::Uncommitted) {
            return Err(LineRuntimeError::ResultAlreadyCommitted);
        }
        self.result = RuntimeDialogueResultState::Committed { ty, value };
        Ok(())
    }

    /// Selects the line result at one joined mark or cancellation handler
    /// completion. The value and every affine lease advance together.
    pub(crate) fn select_result(
        &mut self,
        tag: &LineTaskWorkTag,
        ty: T,
        value: RuntimeValue,
    ) -> Result<(), LineRuntimeError>
    where
        T: PartialEq,
    {
        let prepared = self.validate_result_selection(tag, &ty, &value)?;
        self.select_result_prepared(prepared, value);
        Ok(())
    }

    /// Checks type, source transition, every old/new affine lease, and the
    /// resulting command journal while the selected value is still borrowed
    /// from its child owner.
    pub(crate) fn validate_result_selection(
        &mut self,
        tag: &LineTaskWorkTag,
        ty: &T,
        value: &RuntimeValue,
    ) -> Result<RuntimePreparedResultSelection<T>, LineRuntimeError>
    where
        T: PartialEq,
    {
        if !tag.is_well_formed()
            || !matches!(
                tag.work(),
                LineTaskWork::Cancellation(_) | LineTaskWork::Node(_)
            )
        {
            return Err(LineRuntimeError::InvalidActivationOperation);
        }
        let pending_value = match (&self.result, tag.work()) {
            (RuntimeDialogueResultState::Uncommitted, _) => None,
            (
                RuntimeDialogueResultState::Committed {
                    ty: pending_ty,
                    value,
                },
                _,
            ) if pending_ty == ty => Some(value),
            (
                RuntimeDialogueResultState::Selected {
                    ty: pending_ty,
                    value,
                    source,
                },
                LineTaskWork::Cancellation(_),
            ) if pending_ty == ty && matches!(source.work(), LineTaskWork::Node(_)) => Some(value),
            (RuntimeDialogueResultState::Committed { .. }, _) => {
                return Err(LineRuntimeError::ResultPatternOrTypeMismatch);
            }
            (RuntimeDialogueResultState::Selected { ty: pending_ty, .. }, _)
                if pending_ty != ty =>
            {
                return Err(LineRuntimeError::ResultPatternOrTypeMismatch);
            }
            (RuntimeDialogueResultState::Selected { .. }, _) => {
                return Err(LineRuntimeError::InvalidResultTransition);
            }
            _ => return Err(LineRuntimeError::InvalidResultTransition),
        };
        let mut ledger = self.ledger.clone();
        let mut commands =
            RuntimeCommandQueue::new(tag.activation_id().clone(), self.command_sequence);
        let mut old_tokens = std::collections::BTreeSet::new();
        if let Some(pending_value) = pending_value {
            for handle in pending_value
                .line_handle_projection()
                .map_err(|_| LineRuntimeError::InvalidHandlePayload)?
            {
                if !old_tokens.insert(handle.token().clone()) {
                    return Err(LineRuntimeError::DuplicateHandleOccurrence);
                }
                if handle.token().activation() != tag.activation_id() {
                    // The registry transaction retires this exact result slot
                    // through the published issuer before committing selection.
                    continue;
                }
                ledger.drop_owned(
                    handle.token(),
                    &RuntimeHandleOwnerSlot::DialogueResult(handle.path().clone()),
                    &mut commands,
                )?;
            }
        }
        let mut selected_tokens = std::collections::BTreeSet::new();
        for handle in value
            .line_handle_projection()
            .map_err(|_| LineRuntimeError::InvalidHandlePayload)?
        {
            if !selected_tokens.insert(handle.token().clone()) {
                return Err(LineRuntimeError::DuplicateHandleOccurrence);
            }
            if old_tokens.contains(handle.token()) {
                return Err(LineRuntimeError::DuplicateHandleOccurrence);
            }
            if handle.token().activation() != tag.activation_id() {
                return Err(LineRuntimeError::WrongActivation);
            }
            let lease = ledger
                .lease(handle.token())
                .ok_or(LineRuntimeError::UnknownHandle)?;
            if lease.resource().kind() != handle.kind() {
                return Err(LineRuntimeError::WrongOpaqueProducer);
            }
            ledger.transfer(
                handle.token(),
                &RuntimeHandleOwnerSlot::ChildScope(tag.clone()),
                RuntimeHandleOwnerSlot::DialogueResult(handle.path().clone()),
            )?;
        }
        let before = RuntimeDialogueOutcomeJournal::capture(self);
        self.record_commands(tag.activation_id(), commands)?;
        let after = RuntimeDialogueOutcomeJournal::capture(self);
        before.clone().restore(self);
        Ok(RuntimePreparedResultSelection {
            tag: tag.clone(),
            ty: ty.clone(),
            journal: RuntimeDialogueOutcomeStage { before, after },
            ledger,
        })
    }

    /// Commits a checked selection after the child has yielded its sole
    /// value. No validation or packet duplication occurs after this move.
    pub(crate) fn select_result_prepared(
        &mut self,
        prepared: RuntimePreparedResultSelection<T>,
        value: RuntimeValue,
    ) {
        let RuntimePreparedResultSelection {
            tag,
            ty,
            mut journal,
            ledger,
        } = prepared;
        journal.after.ledger = ledger;
        self.commit_runtime_outcomes(journal);
        self.result = RuntimeDialogueResultState::Selected {
            ty,
            value,
            source: tag,
        };
    }

    pub(crate) fn begin_result_publication(&mut self) -> Result<(), LineRuntimeError> {
        if !matches!(
            self.result,
            RuntimeDialogueResultState::Committed { .. }
                | RuntimeDialogueResultState::Selected { .. }
        ) {
            return Err(LineRuntimeError::InvalidResultTransition);
        }
        let previous = std::mem::replace(&mut self.result, RuntimeDialogueResultState::Uncommitted);
        let (ty, value) = match previous {
            RuntimeDialogueResultState::Committed { ty, value }
            | RuntimeDialogueResultState::Selected { ty, value, .. } => (ty, value),
            _ => unreachable!("publication source was checked before taking its owner"),
        };
        self.result = RuntimeDialogueResultState::Publishing { ty, value };
        Ok(())
    }

    /// Transfers the sole result value out of line custody after every result
    /// pattern and handle-ledger preflight has succeeded.
    pub(crate) fn finish_result_publication(
        &mut self,
    ) -> Result<(T, RuntimeValue), LineRuntimeError> {
        if !matches!(self.result, RuntimeDialogueResultState::Publishing { .. }) {
            return Err(LineRuntimeError::InvalidResultTransition);
        }
        if self.has_pending_commands()
            || self.ledger.leases().values().any(|lease| {
                lease.state() != RuntimeHandleLeaseState::Released
                    && !matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
            })
        {
            return Err(LineRuntimeError::UnownedLeaseAtPublish);
        }
        let previous = std::mem::replace(&mut self.result, RuntimeDialogueResultState::Published);
        let RuntimeDialogueResultState::Publishing { ty, value } = previous else {
            unreachable!("publication result was checked before taking its owner")
        };
        Ok((ty, value))
    }

    pub(crate) fn abandon(&mut self) -> Result<(), LineRuntimeError> {
        match self.result {
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Committed { .. }
            | RuntimeDialogueResultState::Selected { .. }
            | RuntimeDialogueResultState::Publishing { .. } => {
                self.result = RuntimeDialogueResultState::Abandoned;
                Ok(())
            }
            RuntimeDialogueResultState::Abandoned => Ok(()),
            RuntimeDialogueResultState::Published => Err(LineRuntimeError::InvalidResultTransition),
        }
    }

    pub(crate) fn has_returned_scheduled_captures(&self) -> bool {
        self.scheduled.iter().any(|scheduled| {
            matches!(&scheduled.custody, RuntimeScheduledCaptureCustody::LineScope(slots) if !slots.is_empty())
        })
    }

    /// Prepares activation-owned leases for deterministic close. Unstarted
    /// scheduled work is cancelled and its captures are staged for release.
    /// The line consumes its capture slots when it commits the cleanup journal
    /// and ledger. A running child retains its custody until it reports completion.
    pub(crate) fn prepare_handle_unwind(
        &mut self,
        activation: &DialogueActivationId,
        preserve_result: bool,
    ) -> Result<(), LineRuntimeError> {
        if self.has_pending_deferred_work() {
            return Err(LineRuntimeError::DeferredRegistrationsRemain);
        }
        let mut ledger = self.ledger.clone();
        for scheduled in self.scheduled.iter().filter(|scheduled| {
            matches!(scheduled.custody, RuntimeScheduledCaptureCustody::Packet(_))
        }) {
            stage_unstarted_scheduled_completion(
                &mut ledger,
                scheduled,
                RuntimeScheduledState::Cancelled,
            )?;
        }
        let mut commands = crate::presentation::RuntimeCommandQueue::new(
            activation.clone(),
            self.command_sequence,
        );
        let mut leases = ledger.leases().values().cloned().collect::<Vec<_>>();
        leases.reverse();
        for lease in leases {
            if lease.state() == RuntimeHandleLeaseState::Released
                || matches!(
                    lease.owner(),
                    RuntimeHandleOwnerSlot::ChildScope(_)
                        | RuntimeHandleOwnerSlot::LineRegistry { .. }
                )
                || matches!(
                    lease.state(),
                    RuntimeHandleLeaseState::Allocating | RuntimeHandleLeaseState::Cancelling
                )
            {
                continue;
            }
            if preserve_result
                && matches!(
                    lease.owner(),
                    RuntimeHandleOwnerSlot::DialogueResult(_)
                        | RuntimeHandleOwnerSlot::ParentFiber { .. }
                )
            {
                continue;
            }
            ledger.drop_owned(lease.token(), lease.owner(), &mut commands)?;
        }
        self.record_commands(activation, commands)?;
        for scheduled in &mut self.scheduled {
            match &mut scheduled.custody {
                RuntimeScheduledCaptureCustody::Packet(_) => {
                    scheduled.custody = RuntimeScheduledCaptureCustody::LineScope(Box::new([]));
                    scheduled.state = RuntimeScheduledState::Cancelled;
                }
                RuntimeScheduledCaptureCustody::LineScope(slots) => *slots = Box::new([]),
                RuntimeScheduledCaptureCustody::ChildFiber(_) => {}
            }
        }
        self.ledger = ledger;
        Ok(())
    }

    pub(crate) fn release_frame(&mut self) -> Result<(), LineRuntimeError> {
        if self.frame_released {
            return Err(LineRuntimeError::DuplicateFrameRelease);
        }
        if self.has_pending_deferred_work() {
            return Err(LineRuntimeError::DeferredRegistrationsRemain);
        }
        if !self
            .retained_registry_line_handles()
            .map_err(|_| LineRuntimeError::InvalidHandlePayload)?
            .is_empty()
        {
            return Err(LineRuntimeError::UnownedLeaseAtPublish);
        }
        self.line_registry.clear();
        self.frame_released = true;
        Ok(())
    }

    #[must_use]
    pub(crate) fn failure_close_ready(&self) -> bool {
        !self.has_pending_deferred_work()
            && self.issued_commands.is_empty()
            && self.superseded_commands.is_empty()
            && self.scheduled.iter().all(|scheduled| {
                matches!(
                    scheduled.state(),
                    RuntimeScheduledState::Completed
                        | RuntimeScheduledState::Cancelled
                        | RuntimeScheduledState::Failed
                )
            })
            && self
                .ledger
                .leases()
                .values()
                .all(|lease| lease.state() == RuntimeHandleLeaseState::Released)
    }

    #[must_use]
    pub(crate) fn successful_close_ready(&self) -> bool {
        !self.has_pending_deferred_work()
            && self.issued_commands.is_empty()
            && self.superseded_commands.is_empty()
            && self.scheduled.iter().all(|scheduled| {
                matches!(
                    scheduled.state(),
                    RuntimeScheduledState::Completed
                        | RuntimeScheduledState::Cancelled
                        | RuntimeScheduledState::Failed
                )
            })
            && self.ledger.leases().values().all(|lease| {
                lease.state() == RuntimeHandleLeaseState::Released
                    || matches!(
                        lease.owner(),
                        RuntimeHandleOwnerSlot::DialogueResult(_)
                            | RuntimeHandleOwnerSlot::ParentFiber { .. }
                    )
            })
    }

    #[must_use]
    pub(crate) fn is_terminal(&self) -> bool {
        !self.has_pending_deferred_work()
            && self.terminal_kind().is_some()
            && self.failure_close_ready()
    }

    #[must_use]
    pub(crate) fn terminal_kind(&self) -> Option<RuntimeDialogueTerminalKind> {
        if !self.frame_released || self.has_pending_deferred_work() {
            return None;
        }
        match self.result {
            RuntimeDialogueResultState::Published => Some(RuntimeDialogueTerminalKind::Published),
            RuntimeDialogueResultState::Abandoned => Some(RuntimeDialogueTerminalKind::Abandoned),
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Committed { .. }
            | RuntimeDialogueResultState::Selected { .. }
            | RuntimeDialogueResultState::Publishing { .. } => None,
        }
    }

    pub(crate) fn into_published_handles(
        self,
    ) -> Result<RuntimePublishedDialogueHandles, LineRuntimeError> {
        self.can_into_published_handles()?;
        Ok(RuntimePublishedDialogueHandles {
            ledger: self.ledger,
            command_sequence: self.command_sequence,
            issued_commands: self.issued_commands,
            resolved_commands: self.resolved_commands,
        })
    }

    pub(crate) fn can_into_published_handles(&self) -> Result<(), LineRuntimeError> {
        if self.terminal_kind() != Some(RuntimeDialogueTerminalKind::Published)
            || self.has_pending_deferred_work()
            || !self.issued_commands.is_empty()
            || !self.superseded_commands.is_empty()
            || !self.prepared_commands.is_empty()
            || self.scheduled.iter().any(|scheduled| {
                !matches!(
                    scheduled.state(),
                    RuntimeScheduledState::Completed
                        | RuntimeScheduledState::Cancelled
                        | RuntimeScheduledState::Failed
                )
            })
            || self.ledger.leases().values().any(|lease| {
                lease.state() != RuntimeHandleLeaseState::Released
                    && !matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
            })
        {
            return Err(LineRuntimeError::TerminalDispositionMismatch);
        }
        Ok(())
    }

    /// Checks the terminal published shape before releasing the frame and
    /// moving the result into its prepared parent destination. The only two
    /// subsequent line mutations must be `release_frame` and
    /// `finish_result_publication`.
    pub(crate) fn inspect_publish_completion(&self) -> Result<(), LineRuntimeError> {
        if self.frame_released
            || !matches!(self.result, RuntimeDialogueResultState::Publishing { .. })
            || self.has_pending_deferred_work()
            || !self.issued_commands.is_empty()
            || !self.superseded_commands.is_empty()
            || !self.prepared_commands.is_empty()
            || self.scheduled.iter().any(|scheduled| {
                !matches!(
                    scheduled.state(),
                    RuntimeScheduledState::Completed
                        | RuntimeScheduledState::Cancelled
                        | RuntimeScheduledState::Failed
                )
            })
            || self.ledger.leases().values().any(|lease| {
                lease.state() != RuntimeHandleLeaseState::Released
                    && !matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
            })
        {
            return Err(LineRuntimeError::TerminalDispositionMismatch);
        }
        Ok(())
    }

    /// Checks the abandoned terminal shape before the final frame release.
    pub(crate) fn inspect_abandon_completion(&self) -> Result<(), LineRuntimeError> {
        if self.frame_released
            || !matches!(self.result, RuntimeDialogueResultState::Abandoned)
            || !self.failure_close_ready()
        {
            return Err(LineRuntimeError::TerminalDispositionMismatch);
        }
        Ok(())
    }
}

impl<T> AwbcRuntimeDialogueActivationSnapshot<T> {
    pub(crate) fn visit_saved_value_roots<E>(
        &self,
        visit: &mut impl FnMut(&crate::value::AwbcRuntimeValueSnapshot) -> Result<(), E>,
    ) -> Result<(), E> {
        self.visit_retained_value_roots(visit)
    }
}

impl<T: Clone> AwbcRuntimeDialogueActivationSnapshot<T> {
    #[cfg(test)]
    pub(crate) fn from_live(
        state: &RuntimeDialogueActivationState<T>,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError>
    where
        T: RuntimeDialogueTypeCoordinate,
    {
        Self::from_live_with_owner(state, None)
    }

    #[cfg(test)]
    pub(crate) fn from_live_for_program(
        state: &RuntimeDialogueActivationState<T>,
        owner: &RuntimeProgramOwner,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError>
    where
        T: RuntimeDialogueTypeCoordinate,
    {
        Self::from_live_with_owner(state, Some(owner))
    }

    #[cfg(test)]
    fn from_live_with_owner(
        state: &RuntimeDialogueActivationState<T>,
        owner: Option<&RuntimeProgramOwner>,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError>
    where
        T: RuntimeDialogueTypeCoordinate,
    {
        let mut admission = match owner {
            Some(owner) => crate::value::RuntimeRetainedValueAdmission::for_program(
                owner.clone(),
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ),
            None => crate::value::RuntimeRetainedValueAdmission::standalone(
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ),
        };
        state.admit_retained_resources(None, &mut admission)?;
        Self::from_admitted_live(state, owner)
    }

    pub(crate) fn from_admitted_live(
        state: &RuntimeDialogueActivationState<T>,
        owner: Option<&RuntimeProgramOwner>,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError> {
        Ok(Self {
            ledger: state.ledger.clone(),
            line_registry: state.line_registry.clone(),
            command_sequence: state.command_sequence,
            issued_commands: state.issued_commands.clone(),
            superseded_commands: state.superseded_commands.clone(),
            resolved_commands: state.resolved_commands.clone(),
            scheduled: state
                .scheduled
                .iter()
                .map(|scheduled| AwbcRuntimeScheduledLineTaskSnapshot::from_live(scheduled, owner))
                .collect::<Result<_, _>>()?,
            deferred: state
                .deferred
                .iter()
                .map(|deferred| {
                    AwbcRuntimeDeferredRegistrationSnapshot::from_admitted_live(deferred, owner)
                })
                .collect::<Result<_, _>>()?,
            next_defer_registration: state.next_defer_registration,
            defer_unwind: state.defer_unwind.clone(),
            result: AwbcRuntimeDialogueResultSnapshot::from_live(&state.result, owner)?,
            frame_released: state.frame_released,
            prepared_commands: Vec::new(),
        })
    }

    #[cfg(test)]
    pub(crate) fn into_live<'a>(
        self,
        owner: impl Into<crate::value::RuntimeValueRestoreContext<'a>>,
    ) -> Result<RuntimeDialogueActivationState<T>, crate::value::AwbcRuntimeValueSnapshotError>
    where
        T: RuntimeDialogueTypeCoordinate,
    {
        let owner = owner.into();
        self.admit_retained_resources(
            None,
            &mut crate::value::RuntimeRetainedValueAdmission::for_program(
                owner.owner().clone(),
                crate::entry::RuntimeSchemaLimits::engine_default(),
            ),
        )?;
        self.into_admitted_live(owner)
    }

    pub(crate) fn into_admitted_live<'a>(
        self,
        owner: impl Into<crate::value::RuntimeValueRestoreContext<'a>>,
    ) -> Result<RuntimeDialogueActivationState<T>, crate::value::AwbcRuntimeValueSnapshotError>
    {
        let owner = owner.into();
        Ok(RuntimeDialogueActivationState {
            ledger: self.ledger,
            line_registry: self.line_registry,
            command_sequence: self.command_sequence,
            issued_commands: self.issued_commands,
            superseded_commands: self.superseded_commands,
            resolved_commands: self.resolved_commands,
            scheduled: self
                .scheduled
                .into_iter()
                .map(|scheduled| scheduled.into_live(owner))
                .collect::<Result<_, _>>()?,
            deferred: self
                .deferred
                .into_iter()
                .map(|registration| registration.into_admitted_live(owner))
                .collect::<Result<_, _>>()?,
            next_defer_registration: self.next_defer_registration,
            defer_unwind: self.defer_unwind,
            result: self.result.into_live(owner)?,
            frame_released: self.frame_released,
            prepared_commands: Vec::new(),
        })
    }
}

impl AwbcRuntimeScheduledLineTaskSnapshot {
    fn from_live(
        state: &RuntimeScheduledLineTask,
        owner: Option<&RuntimeProgramOwner>,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError> {
        state
            .validate_custody()
            .map_err(|error| scheduled_custody_snapshot_error(&error))?;
        Ok(Self {
            token: state.token.clone(),
            child: state.child,
            work: state.work.clone(),
            deadline: state.deadline,
            custody: AwbcRuntimeScheduledCaptureCustodySnapshot::from_live(&state.custody, owner)?,
            state: state.state,
        })
    }

    fn into_live<'a>(
        self,
        owner: impl Into<crate::value::RuntimeValueRestoreContext<'a>>,
    ) -> Result<RuntimeScheduledLineTask, crate::value::AwbcRuntimeValueSnapshotError> {
        let owner = owner.into();
        let custody = self.custody.into_live(owner)?;
        RuntimeScheduledLineTask::try_from_parts(
            self.token,
            self.child,
            self.work,
            self.deadline,
            custody,
            self.state,
        )
        .map_err(|error| scheduled_custody_snapshot_error(&error))
    }
}

impl AwbcRuntimeScheduledCaptureCustodySnapshot {
    fn from_live(
        custody: &RuntimeScheduledCaptureCustody,
        owner: Option<&RuntimeProgramOwner>,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError> {
        Ok(match custody {
            RuntimeScheduledCaptureCustody::Packet(bindings) => {
                Self::Packet(snapshot_local_bindings(bindings, owner)?)
            }
            RuntimeScheduledCaptureCustody::ChildFiber(locals) => Self::ChildFiber(locals.clone()),
            RuntimeScheduledCaptureCustody::LineScope(bindings) => Self::LineScope(
                bindings
                    .iter()
                    .map(|binding| {
                        Ok::<_, crate::value::AwbcRuntimeValueSnapshotError>(
                            crate::value::RuntimeLocalSlot::new(
                                binding.local(),
                                binding.storage().try_map_ref(&mut |value| {
                                    snapshot_runtime_value_for_owner(value, owner)
                                })?,
                            ),
                        )
                    })
                    .collect::<Result<_, _>>()?,
            ),
        })
    }

    fn into_live<'a>(
        self,
        owner: impl Into<crate::value::RuntimeValueRestoreContext<'a>>,
    ) -> Result<RuntimeScheduledCaptureCustody, crate::value::AwbcRuntimeValueSnapshotError> {
        let owner = owner.into();
        Ok(match self {
            Self::Packet(bindings) => {
                RuntimeScheduledCaptureCustody::Packet(live_local_bindings(bindings, owner)?)
            }
            Self::ChildFiber(locals) => RuntimeScheduledCaptureCustody::ChildFiber(locals),
            Self::LineScope(bindings) => RuntimeScheduledCaptureCustody::LineScope(
                bindings
                    .into_vec()
                    .into_iter()
                    .map(|binding| binding.into_admitted_live_for_program(owner))
                    .collect::<Result<Vec<_>, crate::value::AwbcRuntimeValueSnapshotError>>()?
                    .into_boxed_slice(),
            ),
        })
    }
}

fn snapshot_runtime_value_for_owner(
    value: &RuntimeValue,
    owner: Option<&RuntimeProgramOwner>,
) -> Result<crate::value::AwbcRuntimeValueSnapshot, crate::value::AwbcRuntimeValueSnapshotError> {
    crate::value::AwbcRuntimeValueSnapshot::from_admitted_storage(value, owner)
}

fn snapshot_local_bindings(
    bindings: &[RuntimeLocalBinding],
    owner: Option<&RuntimeProgramOwner>,
) -> Result<Box<[AwbcRuntimeLocalBindingSnapshot]>, crate::value::AwbcRuntimeValueSnapshotError> {
    bindings
        .iter()
        .map(|capture| {
            Ok(AwbcRuntimeLocalBindingSnapshot {
                local: capture.local,
                value: snapshot_runtime_value_for_owner(&capture.value, owner)?,
            })
        })
        .collect()
}

fn live_local_bindings(
    bindings: Box<[AwbcRuntimeLocalBindingSnapshot]>,
    owner: crate::value::RuntimeValueRestoreContext<'_>,
) -> Result<Box<[RuntimeLocalBinding]>, crate::value::AwbcRuntimeValueSnapshotError> {
    bindings
        .into_vec()
        .into_iter()
        .map(|capture| {
            Ok(RuntimeLocalBinding {
                local: capture.local,
                value: capture.value.into_admitted_runtime_value(owner)?,
            })
        })
        .collect::<Result<Vec<_>, crate::value::AwbcRuntimeValueSnapshotError>>()
        .map(Vec::into_boxed_slice)
}

fn scheduled_custody_snapshot_error(
    error: &LineRuntimeError,
) -> crate::value::AwbcRuntimeValueSnapshotError {
    crate::value::AwbcRuntimeValueSnapshotError::Message {
        message: error.to_string(),
    }
}

fn exact_scheduled_packet_mut<'a>(
    scheduled: &'a mut [RuntimeScheduledLineTask],
    token: &RuntimeLineHandleToken,
) -> Result<&'a mut RuntimeScheduledLineTask, LineRuntimeError> {
    scheduled
        .iter_mut()
        .find(|scheduled| scheduled.token() == token)
        .ok_or(LineRuntimeError::MissingScheduledWork)
}

impl<T: Clone> AwbcRuntimeDialogueResultSnapshot<T> {
    fn from_live(
        state: &RuntimeDialogueResultState<T>,
        owner: Option<&RuntimeProgramOwner>,
    ) -> Result<Self, crate::value::AwbcRuntimeValueSnapshotError> {
        Ok(match state {
            RuntimeDialogueResultState::Uncommitted => Self::Uncommitted,
            RuntimeDialogueResultState::Committed { ty, value } => Self::Committed {
                ty: ty.clone(),
                value: snapshot_runtime_value_for_owner(value, owner)?,
            },
            RuntimeDialogueResultState::Selected { ty, value, source } => Self::Selected {
                ty: ty.clone(),
                value: snapshot_runtime_value_for_owner(value, owner)?,
                source: source.clone(),
            },
            RuntimeDialogueResultState::Publishing { ty, value } => Self::Publishing {
                ty: ty.clone(),
                value: snapshot_runtime_value_for_owner(value, owner)?,
            },
            RuntimeDialogueResultState::Published => Self::Published,
            RuntimeDialogueResultState::Abandoned => Self::Abandoned,
        })
    }

    fn into_live<'a>(
        self,
        owner: impl Into<crate::value::RuntimeValueRestoreContext<'a>>,
    ) -> Result<RuntimeDialogueResultState<T>, crate::value::AwbcRuntimeValueSnapshotError> {
        let owner = owner.into();
        Ok(match self {
            Self::Uncommitted => RuntimeDialogueResultState::Uncommitted,
            Self::Committed { ty, value } => RuntimeDialogueResultState::Committed {
                ty,
                value: value.into_admitted_runtime_value(owner)?,
            },
            Self::Selected { ty, value, source } => RuntimeDialogueResultState::Selected {
                ty,
                value: value.into_admitted_runtime_value(owner)?,
                source,
            },
            Self::Publishing { ty, value } => RuntimeDialogueResultState::Publishing {
                ty,
                value: value.into_admitted_runtime_value(owner)?,
            },
            Self::Published => RuntimeDialogueResultState::Published,
            Self::Abandoned => RuntimeDialogueResultState::Abandoned,
        })
    }
}

impl RuntimePublishedDialogueHandles {
    pub(crate) fn lease(&self, token: &RuntimeLineHandleToken) -> Option<&RuntimeHandleLease> {
        self.ledger.lease(token)
    }

    pub(crate) fn has_lease_matching(
        &self,
        predicate: impl FnMut(&RuntimeHandleLease) -> bool,
    ) -> bool {
        self.ledger.leases().values().any(predicate)
    }

    pub(crate) fn receiver_slots(
        &self,
    ) -> impl Iterator<
        Item = (
            &RuntimeLineHandleToken,
            crate::runtime_id::ExecutionInstanceId,
            RuntimeOwnedSlotId,
        ),
    > {
        self.ledger.leases().iter().filter_map(|(token, lease)| {
            match (lease.owner(), lease.state()) {
                (
                    _,
                    RuntimeHandleLeaseState::Released
                    | RuntimeHandleLeaseState::Cancelling
                    | RuntimeHandleLeaseState::Cancelled
                    | RuntimeHandleLeaseState::Failed,
                ) => None,
                (
                    RuntimeHandleOwnerSlot::ParentFiber {
                        receiver_execution,
                        slot,
                    },
                    _,
                ) => Some((token, *receiver_execution, *slot)),
                _ => None,
            }
        })
    }

    pub(crate) fn received_result_leases(
        &self,
    ) -> impl Iterator<
        Item = (
            &RuntimeLineHandleToken,
            &DialogueActivationId,
            &RuntimeValuePath,
        ),
    > {
        self.ledger
            .leases()
            .iter()
            .filter_map(|(token, lease)| match lease.owner() {
                RuntimeHandleOwnerSlot::ReceivedDialogueResult { receiver, path } => {
                    Some((token, receiver, path))
                }
                _ => None,
            })
    }

    pub(crate) fn pending_result_retirements(&self) -> impl Iterator<Item = &DialogueActivationId> {
        self.ledger
            .leases()
            .values()
            .filter_map(|lease| match lease.owner() {
                RuntimeHandleOwnerSlot::RetiringDialogueResult { receiver }
                | RuntimeHandleOwnerSlot::ReceivedDialogueResult { receiver, .. }
                | RuntimeHandleOwnerSlot::RetiringLineRegistry { receiver }
                    if lease.state() == RuntimeHandleLeaseState::Cancelling =>
                {
                    Some(receiver)
                }
                _ => None,
            })
    }

    pub(crate) fn has_pending_result_retirement(&self, receiver: &DialogueActivationId) -> bool {
        self.pending_result_retirements()
            .any(|owner| owner == receiver)
    }

    pub(crate) fn restored_received_result_is_valid(
        &self,
        receiver: &DialogueActivationId,
        handle: &crate::value::ownership::RuntimeAffineLineHandle,
        publishing: bool,
    ) -> bool {
        self.result_lease(receiver, handle)
            .is_ok_and(|lease| publishing || !result_lease_was_retired(lease.state()))
    }

    pub(crate) fn result_drop_queue(&self, issuer: DialogueActivationId) -> RuntimeCommandQueue {
        RuntimeCommandQueue::new(issuer, self.command_sequence)
    }

    pub(crate) fn result_lease(
        &self,
        receiver: &DialogueActivationId,
        handle: &crate::value::ownership::RuntimeAffineLineHandle,
    ) -> Result<&RuntimeHandleLease, LineRuntimeError> {
        let lease = self
            .ledger
            .lease(handle.token())
            .ok_or(LineRuntimeError::UnknownHandle)?;
        if !matches!(lease.owner(),
            RuntimeHandleOwnerSlot::ReceivedDialogueResult { receiver: owner, path }
            if owner == receiver && path == handle.path()
        ) {
            return Err(LineRuntimeError::WrongOwner);
        }
        if lease.resource().kind() != handle.kind() {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        }
        Ok(lease)
    }

    pub(crate) fn publish_received_result(
        &mut self,
        execution: crate::runtime_id::ExecutionInstanceId,
        receiver: &DialogueActivationId,
        handle: &crate::value::ownership::RuntimeAffineLineHandle,
        destination: RuntimeOwnedSlotId,
    ) -> Result<(), LineRuntimeError> {
        let lease = self.result_lease(receiver, handle)?;
        if result_lease_was_retired(lease.state()) {
            return Err(LineRuntimeError::ReleasedHandle);
        }
        let expected = lease.owner().clone();
        self.ledger.transfer(
            handle.token(),
            &expected,
            RuntimeHandleOwnerSlot::parent_fiber(execution, destination),
        )
    }

    /// Queues release at the original issuer while the result shape is still
    /// needed for its pattern. A retry observes the existing receipt.
    pub(crate) fn stage_received_result_drop(
        &mut self,
        receiver: &DialogueActivationId,
        handle: &crate::value::ownership::RuntimeAffineLineHandle,
        queue: &mut RuntimeCommandQueue,
    ) -> Result<bool, LineRuntimeError> {
        let lease = self.result_lease(receiver, handle)?;
        match lease.state() {
            RuntimeHandleLeaseState::Released => return Ok(true),
            RuntimeHandleLeaseState::Cancelling => return Ok(false),
            _ => {}
        }
        let expected = lease.owner().clone();
        self.ledger.drop_owned(handle.token(), &expected, queue)?;
        if self.result_lease(receiver, handle)?.state() == RuntimeHandleLeaseState::Cancelled {
            // The issuer has already finished the scheduled callback. There
            // is no host outcome to wait for on this cancelled cue.
            self.ledger.drop_owned(handle.token(), &expected, queue)?;
        }
        Ok(self.result_lease(receiver, handle)?.state() == RuntimeHandleLeaseState::Released)
    }

    /// Removes the result slot only after its value is consumed or discarded.
    /// In-flight releases continue under the unchanged issuer command ID.
    pub(crate) fn remove_received_result(
        &mut self,
        receiver: &DialogueActivationId,
        handle: &crate::value::ownership::RuntimeAffineLineHandle,
    ) -> Result<(), LineRuntimeError> {
        let lease = self.result_lease(receiver, handle)?;
        if !matches!(
            lease.state(),
            RuntimeHandleLeaseState::Cancelling | RuntimeHandleLeaseState::Released
        ) {
            return Err(LineRuntimeError::InvalidDropTransition);
        }
        self.ledger
            .leases
            .get_mut(handle.token())
            .expect("result lease was checked")
            .owner = RuntimeHandleOwnerSlot::RetiringDialogueResult {
            receiver: *receiver,
        };
        Ok(())
    }

    pub(crate) fn restore_admit(
        &self,
        activation: &DialogueActivationId,
    ) -> Result<(), LineRuntimeError> {
        validate_restored_ledger(activation, &self.ledger)?;
        validate_restored_command_journal(
            activation,
            self.command_sequence,
            &self.issued_commands,
            &BTreeMap::new(),
            &self.resolved_commands,
            &self.ledger,
            |_, _, _| false,
        )?;
        if self
            .ledger
            .leases()
            .values()
            .any(|lease| match lease.owner() {
                RuntimeHandleOwnerSlot::ParentFiber { .. } => false,
                RuntimeHandleOwnerSlot::ReceivedDialogueResult { receiver, .. } => {
                    receiver == activation
                        || receiver.artifact() != activation.artifact()
                        || lease.state() == RuntimeHandleLeaseState::Cancelled
                        || !published_result_retirement_is_correlated(lease, &self.issued_commands)
                }
                RuntimeHandleOwnerSlot::LineRegistry { receiver, .. } => {
                    receiver == activation
                        || !published_result_retirement_is_correlated(lease, &self.issued_commands)
                }
                RuntimeHandleOwnerSlot::RetiringDialogueResult { receiver }
                | RuntimeHandleOwnerSlot::RetiringLineRegistry { receiver } => {
                    receiver == activation
                        || receiver.artifact() != activation.artifact()
                        || !matches!(
                            lease.state(),
                            RuntimeHandleLeaseState::Cancelling | RuntimeHandleLeaseState::Released
                        )
                        || !published_result_retirement_is_correlated(lease, &self.issued_commands)
                }
                _ => lease.state() != RuntimeHandleLeaseState::Released,
            })
        {
            return Err(LineRuntimeError::InvalidRestoredLedgerState);
        }
        Ok(())
    }

    #[must_use]
    pub(crate) fn has_live_leases(&self) -> bool {
        self.ledger
            .leases()
            .values()
            .any(|lease| lease.state() != RuntimeHandleLeaseState::Released)
    }

    pub(crate) fn accept_outcome(
        &mut self,
        outcome: &crate::presentation::RuntimeLineHostOutcome,
    ) -> Result<Option<LineRuntimeError>, LineRuntimeError> {
        let mut candidate = self.clone();
        let diagnostic = candidate.reduce_outcome(outcome)?;
        *self = candidate;
        Ok(diagnostic)
    }

    fn reduce_outcome(
        &mut self,
        outcome: &crate::presentation::RuntimeLineHostOutcome,
    ) -> Result<Option<LineRuntimeError>, LineRuntimeError> {
        let command_id = outcome.command();
        let Some(command) = self.issued_commands.remove(command_id) else {
            return Err(if self.resolved_commands.contains(command_id) {
                LineRuntimeError::DuplicateCommandOutcome
            } else {
                LineRuntimeError::UnknownCommandOutcome
            });
        };
        let rejected = match (&command, outcome) {
            (
                crate::presentation::RuntimeLineHostCommand::Stage(
                    crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. },
                ),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::ReleasedActor {
                        actor: echoed,
                        ..
                    },
                ),
            ) if actor == echoed => {
                self.ledger.set_state(
                    actor,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Released,
                )?;
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Stage(
                    crate::presentation::RuntimeStageCommand::CancelCue { cue, .. },
                ),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Cancelled {
                        cue: echoed, ..
                    },
                ),
            ) if cue == echoed => {
                self.ledger.set_state(
                    cue,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Cancelled,
                )?;
                self.ledger.set_state(
                    cue,
                    RuntimeHandleLeaseState::Cancelled,
                    RuntimeHandleLeaseState::Released,
                )?;
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Voice(
                    crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice {
                        handle, ..
                    },
                ),
                crate::presentation::RuntimeLineHostOutcome::Voice(
                    crate::presentation::RuntimeVoiceCommandOutcome::Released {
                        handle: echoed,
                        ..
                    },
                ),
            ) if handle == echoed => {
                self.ledger.set_state(
                    handle,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Released,
                )?;
                None
            }
            (
                crate::presentation::RuntimeLineHostCommand::Stage(command),
                crate::presentation::RuntimeLineHostOutcome::Stage(
                    crate::presentation::RuntimeStageCommandOutcome::Rejected { code, .. },
                ),
            ) => {
                let token = published_command_token(command)?;
                self.ledger.set_state(
                    token,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Failed,
                )?;
                self.ledger.set_state(
                    token,
                    RuntimeHandleLeaseState::Failed,
                    RuntimeHandleLeaseState::Released,
                )?;
                Some(LineRuntimeError::StageCommandRejected { code: *code })
            }
            (
                crate::presentation::RuntimeLineHostCommand::Voice(command),
                crate::presentation::RuntimeLineHostOutcome::Voice(
                    crate::presentation::RuntimeVoiceCommandOutcome::Rejected { failure, .. },
                ),
            ) => {
                let token = published_voice_command_token(command)?;
                self.ledger.set_state(
                    token,
                    RuntimeHandleLeaseState::Cancelling,
                    RuntimeHandleLeaseState::Failed,
                )?;
                self.ledger.set_state(
                    token,
                    RuntimeHandleLeaseState::Failed,
                    RuntimeHandleLeaseState::Released,
                )?;
                Some(LineRuntimeError::VoiceStartRejected {
                    failure: failure.clone(),
                })
            }
            _ => return Err(LineRuntimeError::StageOutcomeMismatch),
        };
        self.resolved_commands.insert(command_id.clone());
        Ok(rejected)
    }

    /// Prepares the original issuer's complete ownership and command update
    /// for one receiving instruction. Each token has one exact destination,
    /// including values transferred out of the receiving fiber.
    pub(crate) fn inspect_receiver_custody(
        &self,
        activation: &DialogueActivationId,
        execution: crate::runtime_id::ExecutionInstanceId,
        before: &BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        after: &BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        drops: &super::RuntimeHandleDropAuthorization,
    ) -> Result<(Self, RuntimeHandleDropReceipt), LineRuntimeError> {
        if after.keys().any(|token| !before.contains_key(token)) {
            return Err(LineRuntimeError::UnexpectedParentHandleOccurrence);
        }
        let mut candidate = self.clone();
        let mut queue = RuntimeCommandQueue::new(activation.clone(), candidate.command_sequence);
        for (token, source) in before {
            if token.activation() != activation {
                return Err(LineRuntimeError::WrongActivation);
            }
            source.validate_published_receiver(activation, execution)?;
            let lease = candidate
                .ledger
                .lease(token)
                .ok_or(LineRuntimeError::UnknownHandle)?;
            if lease.owner() != source {
                return Err(LineRuntimeError::WrongOwner);
            }
            match after.get(token) {
                Some(destination) if destination == source => {}
                Some(destination) => {
                    destination.validate_published_receiver(activation, execution)?;
                    if matches!(
                        destination,
                        RuntimeHandleOwnerSlot::ReceivedDialogueResult { .. }
                            | RuntimeHandleOwnerSlot::LineRegistry { .. }
                    ) && result_lease_was_retired(lease.state())
                    {
                        return Err(LineRuntimeError::ReleasedHandle);
                    }
                    candidate
                        .ledger
                        .transfer(token, source, destination.clone())?;
                }
                None => {
                    let policy = drops
                        .policy_for(token)
                        .ok_or(LineRuntimeError::UnjournaledHandleDrop)?;
                    candidate
                        .ledger
                        .drop_owned_with_policy(token, source, policy, &mut queue)?;
                }
            }
        }
        let commands = candidate.record_parent_drop_commands(activation, queue)?;
        Ok((candidate, RuntimeHandleDropReceipt { commands }))
    }

    pub(crate) fn record_parent_drop_commands(
        &mut self,
        activation: &DialogueActivationId,
        queue: RuntimeCommandQueue,
    ) -> Result<Vec<crate::presentation::RuntimeLineHostCommand>, LineRuntimeError> {
        if queue.activation() != activation || queue.start_sequence() != self.command_sequence {
            return Err(LineRuntimeError::StaleCommandQueue);
        }
        let next_sequence = queue.next_sequence();
        let commands = queue.into_commands();
        if self
            .issued_commands
            .len()
            .checked_add(self.resolved_commands.len())
            .and_then(|count| count.checked_add(commands.len()))
            .is_none_or(|count| count > MAX_LINE_COMMAND_HISTORY)
        {
            return Err(LineRuntimeError::CommandHistoryLimitExceeded);
        }
        let mut issued = self.issued_commands.clone();
        for command in &commands {
            if command.command().activation() != activation
                || issued
                    .insert(command.command().clone(), command.clone())
                    .is_some()
                || self.resolved_commands.contains(command.command())
            {
                return Err(LineRuntimeError::DuplicateCommandIdentity);
            }
        }
        self.command_sequence = next_sequence;
        self.issued_commands = issued;
        Ok(commands)
    }

    #[must_use]
    pub(crate) fn is_terminal(&self) -> bool {
        !self.has_live_leases()
            && self.issued_commands.is_empty()
            && self.received_result_leases().next().is_none()
            && !self.has_lease_matching(|lease| {
                matches!(lease.owner(), RuntimeHandleOwnerSlot::LineRegistry { .. })
            })
    }
}

fn published_command_token(
    command: &crate::presentation::RuntimeStageCommand,
) -> Result<&RuntimeLineHandleToken, LineRuntimeError> {
    match command {
        crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. } => Ok(actor),
        crate::presentation::RuntimeStageCommand::CancelCue { cue, .. } => Ok(cue),
        crate::presentation::RuntimeStageCommand::AcquireActor { .. }
        | crate::presentation::RuntimeStageCommand::SetCharacterLook { .. } => {
            Err(LineRuntimeError::StageOutcomeMismatch)
        }
    }
}

fn published_voice_command_token(
    command: &crate::presentation::RuntimeVoiceCommand,
) -> Result<&RuntimeLineHandleToken, LineRuntimeError> {
    match command {
        crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice { handle, .. } => Ok(handle),
        crate::presentation::RuntimeVoiceCommand::StartDialogueVoice { .. } => {
            Err(LineRuntimeError::StageOutcomeMismatch)
        }
    }
}

fn validate_restored_ledger(
    activation: &DialogueActivationId,
    ledger: &RuntimeLineHandleLedger,
) -> Result<(), LineRuntimeError> {
    for (site, next) in &ledger.issuance_by_site {
        if *next == 0
            || ledger
                .leases
                .keys()
                .filter(|token| token.site() == *site)
                .any(|token| token.issuance() >= *next)
        {
            return Err(LineRuntimeError::InvalidRestoredLedgerState);
        }
    }
    for (token, lease) in &ledger.leases {
        if token != lease.token()
            || token.activation() != activation
            || ledger
                .issuance_by_site
                .get(&token.site())
                .is_none_or(|next| token.issuance() >= *next)
        {
            return Err(LineRuntimeError::InvalidRestoredLedgerState);
        }
        match lease.owner() {
            RuntimeHandleOwnerSlot::ChildScope(work)
                if work.activation_id() != activation || !work.is_well_formed() =>
            {
                return Err(LineRuntimeError::InvalidRestoredLedgerState);
            }
            RuntimeHandleOwnerSlot::LineRegistry { receiver, key, .. }
                if receiver.artifact() != activation.artifact()
                    || key.scope() != &arcweft_id::LifetimeScopeKind::Line
                    || lease.state() == RuntimeHandleLeaseState::Allocating =>
            {
                return Err(LineRuntimeError::InvalidRestoredLedgerState);
            }
            RuntimeHandleOwnerSlot::RetiringLineRegistry { receiver }
                if receiver.artifact() != activation.artifact()
                    || !match lease.state() {
                        RuntimeHandleLeaseState::Pending | RuntimeHandleLeaseState::Running => {
                            matches!(lease.resource(), RuntimeHandleResource::Cue(cue)
                                if matches!(cue.origin(), RuntimeCueOrigin::Scheduled { .. }))
                        }
                        RuntimeHandleLeaseState::Cancelling | RuntimeHandleLeaseState::Released => {
                            true
                        }
                        _ => false,
                    } =>
            {
                return Err(LineRuntimeError::InvalidRestoredLedgerState);
            }
            RuntimeHandleOwnerSlot::RetiringScopedDefer(_)
                if lease.state() != RuntimeHandleLeaseState::Cancelling =>
            {
                return Err(LineRuntimeError::InvalidRestoredLedgerState);
            }
            RuntimeHandleOwnerSlot::LineScope
            | RuntimeHandleOwnerSlot::ActivationLocal(_)
            | RuntimeHandleOwnerSlot::ScopedDefer(_)
            | RuntimeHandleOwnerSlot::RetiringScopedDefer(_)
            | RuntimeHandleOwnerSlot::DialogueResult(_)
            | RuntimeHandleOwnerSlot::ChildScope(_)
            | RuntimeHandleOwnerSlot::ParentFiber { .. }
            | RuntimeHandleOwnerSlot::LineRegistry { .. }
            | RuntimeHandleOwnerSlot::RetiringLineRegistry { .. }
            | RuntimeHandleOwnerSlot::ReceivedDialogueResult { .. }
            | RuntimeHandleOwnerSlot::RetiringDialogueResult { .. } => {}
        }
        let valid_state = match lease.resource() {
            RuntimeHandleResource::StageActor(_) => matches!(
                lease.state(),
                RuntimeHandleLeaseState::Allocating
                    | RuntimeHandleLeaseState::Active
                    | RuntimeHandleLeaseState::Cancelling
                    | RuntimeHandleLeaseState::Failed
                    | RuntimeHandleLeaseState::Released
            ),
            RuntimeHandleResource::Cue(_) => matches!(
                lease.state(),
                RuntimeHandleLeaseState::Pending
                    | RuntimeHandleLeaseState::Running
                    | RuntimeHandleLeaseState::Completed
                    | RuntimeHandleLeaseState::Cancelling
                    | RuntimeHandleLeaseState::Cancelled
                    | RuntimeHandleLeaseState::Failed
                    | RuntimeHandleLeaseState::Released
            ),
            RuntimeHandleResource::Voice(RuntimeVoiceLease::Unvoiced) => matches!(
                lease.state(),
                RuntimeHandleLeaseState::Active | RuntimeHandleLeaseState::Released
            ),
            RuntimeHandleResource::Voice(RuntimeVoiceLease::Playback { .. }) => matches!(
                lease.state(),
                RuntimeHandleLeaseState::Active
                    | RuntimeHandleLeaseState::Completed
                    | RuntimeHandleLeaseState::Cancelling
                    | RuntimeHandleLeaseState::Failed
                    | RuntimeHandleLeaseState::Released
            ),
        };
        if !valid_state {
            return Err(LineRuntimeError::InvalidRestoredLedgerState);
        }
    }
    Ok(())
}

fn validate_restored_command_journal(
    activation: &DialogueActivationId,
    command_sequence: u64,
    issued: &BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    superseded: &BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
    resolved: &std::collections::BTreeSet<crate::presentation::RuntimeLineCommandId>,
    ledger: &RuntimeLineHandleLedger,
    validate_received_actor: impl Fn(
        &crate::presentation::RuntimeLineCommandId,
        &RuntimeLineHandleToken,
        &CharacterId,
    ) -> bool,
) -> Result<(), LineRuntimeError> {
    if issued
        .len()
        .checked_add(superseded.len())
        .and_then(|count| count.checked_add(resolved.len()))
        .is_none_or(|count| {
            count > MAX_LINE_COMMAND_HISTORY
                || usize::try_from(command_sequence).ok() != Some(count)
        })
        || issued
            .keys()
            .any(|id| superseded.contains_key(id) || resolved.contains(id))
        || superseded.keys().any(|id| resolved.contains(id))
    {
        return Err(LineRuntimeError::InvalidRestoredCommandJournal);
    }
    for (id, command) in issued.iter().chain(superseded) {
        if id != command.command()
            || id.activation() != activation
            || id.sequence() >= command_sequence
            || !restored_command_references_are_valid(
                command,
                activation,
                ledger,
                &validate_received_actor,
            )
            || !restored_issued_command_state_is_valid(command, ledger)
        {
            return Err(LineRuntimeError::InvalidRestoredCommandJournal);
        }
    }
    if superseded.values().any(|command| {
        !matches!(
            command,
            crate::presentation::RuntimeLineHostCommand::Stage(
                crate::presentation::RuntimeStageCommand::SetCharacterLook { .. }
            )
        )
    }) || resolved
        .iter()
        .any(|id| id.activation() != activation || id.sequence() >= command_sequence)
    {
        return Err(LineRuntimeError::InvalidRestoredCommandJournal);
    }
    Ok(())
}

fn restored_issued_command_state_is_valid(
    command: &crate::presentation::RuntimeLineHostCommand,
    ledger: &RuntimeLineHandleLedger,
) -> bool {
    let state = |token: &RuntimeLineHandleToken| ledger.lease(token).map(RuntimeHandleLease::state);
    match command {
        crate::presentation::RuntimeLineHostCommand::Stage(command) => match command {
            crate::presentation::RuntimeStageCommand::AcquireActor { actor, .. } => {
                state(actor) == Some(RuntimeHandleLeaseState::Allocating)
            }
            crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. } => matches!(
                state(cue),
                Some(RuntimeHandleLeaseState::Pending | RuntimeHandleLeaseState::Running)
            ),
            crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. } => {
                state(actor) == Some(RuntimeHandleLeaseState::Cancelling)
            }
            crate::presentation::RuntimeStageCommand::CancelCue { cue, .. } => {
                state(cue) == Some(RuntimeHandleLeaseState::Cancelling)
            }
        },
        crate::presentation::RuntimeLineHostCommand::Voice(command) => match command {
            crate::presentation::RuntimeVoiceCommand::StartDialogueVoice { .. } => true,
            crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice { handle, .. } => {
                ledger.lease(handle).is_some_and(|lease| {
                    lease.state() == RuntimeHandleLeaseState::Cancelling
                        && matches!(
                            lease.resource(),
                            RuntimeHandleResource::Voice(RuntimeVoiceLease::Playback { .. })
                        )
                })
            }
        },
    }
}

fn restored_command_references_are_valid(
    command: &crate::presentation::RuntimeLineHostCommand,
    activation: &DialogueActivationId,
    ledger: &RuntimeLineHandleLedger,
    validate_received_actor: impl Fn(
        &crate::presentation::RuntimeLineCommandId,
        &RuntimeLineHandleToken,
        &CharacterId,
    ) -> bool,
) -> bool {
    let token_is = |token: &RuntimeLineHandleToken, kind| {
        token.activation() == activation
            && ledger
                .lease(token)
                .is_some_and(|lease| lease.resource().kind() == kind)
    };
    match command {
        crate::presentation::RuntimeLineHostCommand::Stage(command) => match command {
            crate::presentation::RuntimeStageCommand::AcquireActor { actor, .. }
            | crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. } => {
                token_is(actor, RuntimeHandleKind::StageActor)
            }
            crate::presentation::RuntimeStageCommand::SetCharacterLook {
                command,
                cue,
                actor,
                character,
                ..
            } => {
                token_is(cue, RuntimeHandleKind::Cue)
                    && if actor.activation() == activation {
                        token_is(actor, RuntimeHandleKind::StageActor)
                    } else {
                        actor.activation().artifact() == activation.artifact()
                            && validate_received_actor(command, actor, character)
                    }
            }
            crate::presentation::RuntimeStageCommand::CancelCue { cue, .. } => {
                token_is(cue, RuntimeHandleKind::Cue)
            }
        },
        crate::presentation::RuntimeLineHostCommand::Voice(command) => match command {
            crate::presentation::RuntimeVoiceCommand::StartDialogueVoice { .. } => true,
            crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice { handle, .. } => {
                token_is(handle, RuntimeHandleKind::Voice)
            }
        },
    }
}

fn fail_command_lease(
    ledger: &mut RuntimeLineHandleLedger,
    command: &crate::presentation::RuntimeStageCommand,
) -> Result<(), LineRuntimeError> {
    let token = match command {
        crate::presentation::RuntimeStageCommand::AcquireActor { actor, .. }
        | crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. } => actor,
        crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. }
        | crate::presentation::RuntimeStageCommand::CancelCue { cue, .. } => cue,
    };
    fail_lease(ledger, token)
}

fn fail_voice_command_lease(
    ledger: &mut RuntimeLineHandleLedger,
    command: &crate::presentation::RuntimeVoiceCommand,
) -> Result<(), LineRuntimeError> {
    match command {
        crate::presentation::RuntimeVoiceCommand::StartDialogueVoice { .. } => Ok(()),
        crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice { handle, .. } => {
            fail_lease(ledger, handle)
        }
    }
}

fn fail_lease(
    ledger: &mut RuntimeLineHandleLedger,
    token: &RuntimeLineHandleToken,
) -> Result<(), LineRuntimeError> {
    let state = ledger
        .lease(token)
        .ok_or(LineRuntimeError::UnknownHandle)?
        .state();
    if state == RuntimeHandleLeaseState::Released {
        return Ok(());
    }
    ledger.set_state(token, state, RuntimeHandleLeaseState::Failed)?;
    ledger.set_state(
        token,
        RuntimeHandleLeaseState::Failed,
        RuntimeHandleLeaseState::Released,
    )
}

impl RuntimeLineHandleLedger {
    pub(crate) fn issue(
        &mut self,
        activation: &DialogueActivationId,
        site: &RuntimeLineHandleSite,
        resource: RuntimeHandleResource,
        owner: RuntimeHandleOwnerSlot,
    ) -> Result<RuntimeOpaqueValue, LineRuntimeError> {
        self.issue_exact(
            activation,
            site.id(),
            site.kind(),
            site.opaque_owner(),
            resource,
            owner,
        )
    }

    /// Issues one resource from executor-neutral, already-admitted site
    /// evidence. Structured plans and Product AWBC keep their own exact type
    /// coordinates; the ledger consumes only their common runtime site,
    /// handle-kind, and opaque-owner proof.
    pub(crate) fn issue_exact(
        &mut self,
        activation: &DialogueActivationId,
        site: RuntimeLineHandleSiteId,
        kind: RuntimeHandleKind,
        opaque_owner: &RuntimeOpaqueTypeOwner,
        resource: RuntimeHandleResource,
        owner: RuntimeHandleOwnerSlot,
    ) -> Result<RuntimeOpaqueValue, LineRuntimeError> {
        if resource.kind() != kind
            || opaque_owner.value_class() != RuntimeOpaqueValueClass::AffineHandle(kind)
            || opaque_owner.persistence() != RuntimeOpaquePersistence::SnapshotOnly
            || opaque_owner.producer()
                != &kind
                    .try_producer()
                    .map_err(|_| LineRuntimeError::WrongOpaqueProducer)?
        {
            return Err(LineRuntimeError::InvalidHandleSite);
        }
        if self.leases.len() >= MAX_LINE_LIVE_HANDLES {
            return Err(LineRuntimeError::LiveHandleLimitExceeded);
        }
        let issuance = self.issuance_by_site.get(&site).copied().unwrap_or(0);
        let next = issuance
            .checked_add(1)
            .ok_or(LineRuntimeError::HandleIssuanceOverflow)?;
        let token = RuntimeLineHandleToken::new(activation.clone(), site, issuance);
        if self.leases.contains_key(&token) {
            return Err(LineRuntimeError::DuplicateHandleToken);
        }
        let state = match &resource {
            RuntimeHandleResource::StageActor(_) => RuntimeHandleLeaseState::Allocating,
            RuntimeHandleResource::Cue(cue) => match cue.origin() {
                RuntimeCueOrigin::Scheduled { .. } | RuntimeCueOrigin::StageLook => {
                    RuntimeHandleLeaseState::Pending
                }
            },
            RuntimeHandleResource::Voice(_) => RuntimeHandleLeaseState::Active,
        };
        let opaque = RuntimeOpaqueValue::new_exact(opaque_owner, token.encode_payload());
        self.issuance_by_site.insert(site, next);
        self.leases.insert(
            token.clone(),
            RuntimeHandleLease {
                token,
                owner,
                state,
                resource,
            },
        );
        Ok(opaque)
    }

    pub(crate) fn transfer(
        &mut self,
        token: &RuntimeLineHandleToken,
        expected: &RuntimeHandleOwnerSlot,
        destination: RuntimeHandleOwnerSlot,
    ) -> Result<(), LineRuntimeError> {
        let lease = self
            .leases
            .get_mut(token)
            .ok_or(LineRuntimeError::UnknownHandle)?;
        if lease.owner != *expected {
            return Err(LineRuntimeError::WrongOwner);
        }
        if lease.state == RuntimeHandleLeaseState::Released {
            return Err(LineRuntimeError::ReleasedHandle);
        }
        if let RuntimeHandleOwnerSlot::LineRegistry { receiver, key, .. } = &destination {
            if !lease.admits_line_registry() {
                return Err(LineRuntimeError::ReleasedHandle);
            }
            let crosses_issuer = matches!(expected, RuntimeHandleOwnerSlot::ParentFiber { .. });
            if receiver.artifact() != token.activation().artifact()
                || (receiver != token.activation()) != crosses_issuer
                || key.scope() != &arcweft_id::LifetimeScopeKind::Line
            {
                return Err(LineRuntimeError::WrongActivation);
            }
        }
        if !owner_transition_is_legal(&lease.owner, &destination) {
            return Err(LineRuntimeError::IllegalOwnerTransition);
        }
        lease.owner = destination;
        Ok(())
    }

    pub(crate) fn drop_owned(
        &mut self,
        token: &RuntimeLineHandleToken,
        expected: &RuntimeHandleOwnerSlot,
        commands: &mut RuntimeCommandQueue,
    ) -> Result<(), LineRuntimeError> {
        self.drop_owned_with_policy(token, expected, RuntimeDropPolicy::Default, commands)
    }

    pub(crate) fn drop_owned_with_policy(
        &mut self,
        token: &RuntimeLineHandleToken,
        expected: &RuntimeHandleOwnerSlot,
        policy: RuntimeDropPolicy,
        commands: &mut RuntimeCommandQueue,
    ) -> Result<(), LineRuntimeError> {
        let lease = self
            .leases
            .get_mut(token)
            .ok_or(LineRuntimeError::UnknownHandle)?;
        if lease.owner != *expected {
            return Err(LineRuntimeError::WrongOwner);
        }
        let registry_retirement = match expected {
            RuntimeHandleOwnerSlot::LineRegistry { receiver, .. } => {
                Some(RuntimeHandleOwnerSlot::RetiringLineRegistry {
                    receiver: *receiver,
                })
            }
            _ => None,
        };
        if let Some(retirement) = &registry_retirement
            && (matches!(
                lease.state,
                RuntimeHandleLeaseState::Cancelling | RuntimeHandleLeaseState::Released
            ) || matches!(
                (&lease.resource, lease.state),
                (
                    RuntimeHandleResource::Cue(cue),
                    RuntimeHandleLeaseState::Pending | RuntimeHandleLeaseState::Running
                ) if matches!(cue.origin(), RuntimeCueOrigin::Scheduled { .. })
            ))
        {
            lease.owner = retirement.clone();
            return Ok(());
        }
        if lease.state == RuntimeHandleLeaseState::Released {
            return Err(LineRuntimeError::ReleasedHandle);
        }
        match &lease.resource {
            RuntimeHandleResource::StageActor(_) => {
                if lease.state != RuntimeHandleLeaseState::Allocating {
                    commands.push_release_actor(token.clone())?;
                    lease.state = RuntimeHandleLeaseState::Cancelling;
                }
            }
            RuntimeHandleResource::Cue(cue) => match (cue.origin(), lease.state) {
                (
                    RuntimeCueOrigin::StageLook,
                    RuntimeHandleLeaseState::Pending | RuntimeHandleLeaseState::Running,
                ) => {
                    commands.push_cancel_cue(token.clone())?;
                    lease.state = RuntimeHandleLeaseState::Cancelling;
                }
                (RuntimeCueOrigin::Scheduled { .. }, RuntimeHandleLeaseState::Pending) => {
                    lease.state = RuntimeHandleLeaseState::Cancelled;
                }
                (RuntimeCueOrigin::Scheduled { .. }, RuntimeHandleLeaseState::Running) => {
                    lease.state = RuntimeHandleLeaseState::Cancelling;
                }
                (_, RuntimeHandleLeaseState::Completed | RuntimeHandleLeaseState::Cancelled) => {
                    lease.state = RuntimeHandleLeaseState::Released;
                }
                (RuntimeCueOrigin::Scheduled { .. }, RuntimeHandleLeaseState::Failed)
                    if registry_retirement.is_some() =>
                {
                    lease.state = RuntimeHandleLeaseState::Released;
                }
                _ => return Err(LineRuntimeError::InvalidDropTransition),
            },
            RuntimeHandleResource::Voice(RuntimeVoiceLease::Unvoiced) => {
                lease.state = RuntimeHandleLeaseState::Released;
            }
            RuntimeHandleResource::Voice(RuntimeVoiceLease::Playback { .. }) => {
                commands.push_release_voice(token.clone(), policy)?;
                lease.state = RuntimeHandleLeaseState::Cancelling;
            }
        }
        if let Some(retirement) = registry_retirement {
            lease.owner = retirement;
        } else if let RuntimeHandleOwnerSlot::ScopedDefer(registration) = expected {
            lease.owner = if lease.state == RuntimeHandleLeaseState::Cancelling {
                RuntimeHandleOwnerSlot::RetiringScopedDefer(*registration)
            } else {
                RuntimeHandleOwnerSlot::LineScope
            };
        } else if matches!(expected, RuntimeHandleOwnerSlot::ChildScope(_)) {
            // The value has left the child. The line journal owns any ensuing
            // release outcome while the child continues or retires.
            lease.owner = RuntimeHandleOwnerSlot::LineScope;
        }
        Ok(())
    }

    pub(crate) fn decode_affine_handle(
        value: RuntimeValueView<'_>,
        expected_kind: RuntimeHandleKind,
    ) -> Result<RuntimeLineHandleToken, LineRuntimeError> {
        let RuntimeValueView::Opaque(value) = value else {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        };
        if value.producer()
            != &expected_kind
                .try_producer()
                .map_err(|_| LineRuntimeError::WrongOpaqueProducer)?
            || value.value_class() != RuntimeOpaqueValueClass::AffineHandle(expected_kind)
            || value.persistence() != RuntimeOpaquePersistence::SnapshotOnly
        {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        }
        RuntimeLineHandleToken::try_decode_view(value.payload())
            .map_err(|_| LineRuntimeError::InvalidHandlePayload)
    }

    pub(crate) fn set_state(
        &mut self,
        token: &RuntimeLineHandleToken,
        expected: RuntimeHandleLeaseState,
        state: RuntimeHandleLeaseState,
    ) -> Result<(), LineRuntimeError> {
        let lease = self
            .leases
            .get_mut(token)
            .ok_or(LineRuntimeError::UnknownHandle)?;
        if lease.state != expected {
            return Err(LineRuntimeError::InvalidLeaseTransition {
                expected,
                actual: lease.state,
            });
        }
        if !lease_transition_is_legal(expected, state) {
            return Err(LineRuntimeError::InvalidLeaseTransition {
                expected,
                actual: state,
            });
        }
        lease.state = state;
        if matches!(lease.owner, RuntimeHandleOwnerSlot::RetiringScopedDefer(_))
            && state != RuntimeHandleLeaseState::Cancelling
        {
            lease.owner = RuntimeHandleOwnerSlot::LineScope;
        }
        Ok(())
    }

    pub(crate) fn lease(&self, token: &RuntimeLineHandleToken) -> Option<&RuntimeHandleLease> {
        self.leases.get(token)
    }

    #[must_use]
    pub fn leases(&self) -> &BTreeMap<RuntimeLineHandleToken, RuntimeHandleLease> {
        &self.leases
    }

    pub(crate) fn next_voice_lease_ordinal(&self) -> Result<u32, LineRuntimeError> {
        let count = self
            .leases
            .values()
            .filter(|lease| matches!(lease.resource(), RuntimeHandleResource::Voice(_)))
            .count();
        u32::try_from(count).map_err(|_| LineRuntimeError::HandleIssuanceOverflow)
    }

    pub(crate) fn prepare_voice_lease(
        &self,
        voice: &RuntimeDialogueVoiceState,
    ) -> Result<RuntimeVoiceLeaseAdmission, LineRuntimeError> {
        Ok(match voice {
            RuntimeDialogueVoiceState::Absent => {
                RuntimeVoiceLeaseAdmission::Issue(RuntimeVoiceLease::Unvoiced)
            }
            RuntimeDialogueVoiceState::Ready(session)
            | RuntimeDialogueVoiceState::Completed(session) => RuntimeVoiceLeaseAdmission::Issue(
                RuntimeVoiceLease::new(session.clone(), self.next_voice_lease_ordinal()?, true),
            ),
            RuntimeDialogueVoiceState::Lazy(ticket) => {
                RuntimeVoiceLeaseAdmission::Start(ticket.clone())
            }
            RuntimeDialogueVoiceState::Failed(failure) => {
                return Err(LineRuntimeError::VoiceStartRejected {
                    failure: failure.clone(),
                });
            }
        })
    }

    pub(crate) fn admit_voice_leases(
        &self,
        voice: &RuntimeDialogueVoiceState,
    ) -> Result<(), LineRuntimeError> {
        for lease in self.leases.values() {
            let RuntimeHandleResource::Voice(lease) = lease.resource() else {
                continue;
            };
            let admitted = match (lease, voice) {
                (RuntimeVoiceLease::Unvoiced, RuntimeDialogueVoiceState::Absent)
                | (RuntimeVoiceLease::Playback { .. }, RuntimeDialogueVoiceState::Failed(_)) => {
                    true
                }
                (
                    RuntimeVoiceLease::Playback { session, .. },
                    RuntimeDialogueVoiceState::Ready(active)
                    | RuntimeDialogueVoiceState::Completed(active),
                ) => session == active,
                _ => false,
            };
            if !admitted {
                return Err(LineRuntimeError::InvalidRestoredVoiceLease);
            }
        }
        Ok(())
    }

    #[must_use = "decode the runtime line-handle token from the opaque value"]
    pub fn token_from_value(
        value: &RuntimeValue,
    ) -> Result<RuntimeLineHandleToken, LineRuntimeError> {
        let RuntimeValue::Opaque(value) = value else {
            return Err(LineRuntimeError::WrongOpaqueProducer);
        };
        RuntimeLineHandleToken::try_decode_payload(value.payload())
            .map_err(|_| LineRuntimeError::InvalidHandlePayload)
    }
}

fn owner_transition_is_legal(
    source: &RuntimeHandleOwnerSlot,
    destination: &RuntimeHandleOwnerSlot,
) -> bool {
    if matches!(destination, RuntimeHandleOwnerSlot::LineRegistry { .. }) {
        return matches!(
            source,
            RuntimeHandleOwnerSlot::ActivationLocal(_)
                | RuntimeHandleOwnerSlot::ChildScope(_)
                | RuntimeHandleOwnerSlot::ParentFiber { .. }
        );
    }
    if let RuntimeHandleOwnerSlot::ScopedDefer(id) = source {
        return matches!(
            destination,
            RuntimeHandleOwnerSlot::ChildScope(tag)
                if tag.work() == super::LineTaskWork::Defer(*id)
        );
    }
    matches!(
        (source, destination),
        (
            RuntimeHandleOwnerSlot::LineScope | RuntimeHandleOwnerSlot::ActivationLocal(_),
            RuntimeHandleOwnerSlot::ActivationLocal(_)
                | RuntimeHandleOwnerSlot::ScopedDefer(_)
                | RuntimeHandleOwnerSlot::ChildScope(_)
                | RuntimeHandleOwnerSlot::DialogueResult(_)
        ) | (
            RuntimeHandleOwnerSlot::ActivationLocal(_),
            RuntimeHandleOwnerSlot::LineScope
        ) | (
            RuntimeHandleOwnerSlot::ChildScope(_),
            RuntimeHandleOwnerSlot::LineScope
                | RuntimeHandleOwnerSlot::DialogueResult(_)
                | RuntimeHandleOwnerSlot::ScopedDefer(_)
        ) | (
            RuntimeHandleOwnerSlot::DialogueResult(_)
                | RuntimeHandleOwnerSlot::ParentFiber { .. }
                | RuntimeHandleOwnerSlot::ReceivedDialogueResult { .. },
            RuntimeHandleOwnerSlot::ParentFiber { .. }
        ) | (
            RuntimeHandleOwnerSlot::ParentFiber { .. },
            RuntimeHandleOwnerSlot::ReceivedDialogueResult { .. }
        )
    )
}

const fn lease_transition_is_legal(
    source: RuntimeHandleLeaseState,
    destination: RuntimeHandleLeaseState,
) -> bool {
    matches!(
        (source, destination),
        (
            RuntimeHandleLeaseState::Allocating,
            RuntimeHandleLeaseState::Active
                | RuntimeHandleLeaseState::Cancelling
                | RuntimeHandleLeaseState::Failed
        ) | (
            RuntimeHandleLeaseState::Active,
            RuntimeHandleLeaseState::Cancelling
                | RuntimeHandleLeaseState::Completed
                | RuntimeHandleLeaseState::Failed
        ) | (
            RuntimeHandleLeaseState::Pending,
            RuntimeHandleLeaseState::Running
                | RuntimeHandleLeaseState::Cancelling
                | RuntimeHandleLeaseState::Cancelled
                | RuntimeHandleLeaseState::Failed
        ) | (
            RuntimeHandleLeaseState::Running,
            RuntimeHandleLeaseState::Completed
                | RuntimeHandleLeaseState::Cancelling
                | RuntimeHandleLeaseState::Cancelled
                | RuntimeHandleLeaseState::Failed
        ) | (
            RuntimeHandleLeaseState::Cancelling,
            RuntimeHandleLeaseState::Cancelled
                | RuntimeHandleLeaseState::Released
                | RuntimeHandleLeaseState::Failed
        ) | (
            RuntimeHandleLeaseState::Completed
                | RuntimeHandleLeaseState::Cancelled
                | RuntimeHandleLeaseState::Failed,
            RuntimeHandleLeaseState::Released
        )
    )
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum RuntimeScheduledState {
    Armed,
    Running,
    Completed,
    Cancelling,
    Cancelled,
    Failed,
}

#[derive(Debug, Deserialize, PartialEq, Serialize)]
#[serde(
    deny_unknown_fields,
    rename_all = "snake_case",
    bound(
        serialize = "V: crate::value::InertRuntimeValueStorage, RuntimeLocalSlot<V>: Serialize",
        deserialize = "V: crate::value::InertRuntimeValueStorage, RuntimeLocalSlot<V>: Deserialize<'de>"
    )
)]
enum RuntimeScheduledCaptureCustody<V = RuntimeValue> {
    Packet(Box<[RuntimeLocalBinding<V>]>),
    ChildFiber(Box<[RuntimeLocalDeclarationId]>),
    LineScope(Box<[RuntimeLocalSlot<V>]>),
}

impl<V> RuntimeScheduledCaptureCustody<V> {
    fn values(&self) -> impl Iterator<Item = &V> {
        self.values_with_depth().map(|(_, value)| value)
    }

    fn values_with_depth(&self) -> Box<dyn Iterator<Item = (usize, &V)> + '_> {
        match self {
            Self::Packet(bindings) => Box::new(bindings.iter().map(|binding| (0, &binding.value))),
            Self::LineScope(slots) => Box::new(
                slots
                    .iter()
                    .flat_map(|slot| slot.storage().values_with_depth()),
            ),
            Self::ChildFiber(_) => Box::new(std::iter::empty()),
        }
    }
}

#[derive(Debug, Deserialize, PartialEq, Serialize)]
#[serde(
    deny_unknown_fields,
    bound(
        serialize = "V: crate::value::InertRuntimeValueStorage, RuntimeScheduledCaptureCustody<V>: Serialize",
        deserialize = "V: crate::value::InertRuntimeValueStorage, RuntimeScheduledCaptureCustody<V>: Deserialize<'de>"
    )
)]
pub struct RuntimeScheduledLineTask<V = RuntimeValue> {
    token: RuntimeLineHandleToken,
    child: RuntimeLineTaskNodeId,
    work: LineTaskWorkTag,
    deadline: LogicalDuration,
    custody: RuntimeScheduledCaptureCustody<V>,
    state: RuntimeScheduledState,
}

impl Clone for AwbcRuntimeScheduledCaptureCustodySnapshot {
    fn clone(&self) -> Self {
        match self {
            Self::Packet(bindings) => Self::Packet(bindings.clone()),
            Self::ChildFiber(locals) => Self::ChildFiber(locals.clone()),
            Self::LineScope(slots) => Self::LineScope(slots.clone()),
        }
    }
}

impl Clone for AwbcRuntimeScheduledLineTaskSnapshot {
    fn clone(&self) -> Self {
        Self {
            token: self.token.clone(),
            child: self.child,
            work: self.work.clone(),
            deadline: self.deadline,
            custody: self.custody.clone(),
            state: self.state,
        }
    }
}

fn scheduled_work_terminal(
    state: RuntimeScheduledState,
    failed: bool,
    cancelled: bool,
) -> Result<(RuntimeScheduledState, RuntimeScheduledState), LineRuntimeError> {
    Ok(match state {
        RuntimeScheduledState::Running => (
            RuntimeScheduledState::Running,
            if failed {
                RuntimeScheduledState::Failed
            } else if cancelled {
                RuntimeScheduledState::Cancelled
            } else {
                RuntimeScheduledState::Completed
            },
        ),
        RuntimeScheduledState::Cancelling => (
            RuntimeScheduledState::Cancelling,
            if failed {
                RuntimeScheduledState::Failed
            } else {
                RuntimeScheduledState::Cancelled
            },
        ),
        RuntimeScheduledState::Completed => (
            RuntimeScheduledState::Completed,
            RuntimeScheduledState::Completed,
        ),
        RuntimeScheduledState::Cancelled => (
            RuntimeScheduledState::Cancelled,
            RuntimeScheduledState::Cancelled,
        ),
        RuntimeScheduledState::Failed => {
            (RuntimeScheduledState::Failed, RuntimeScheduledState::Failed)
        }
        RuntimeScheduledState::Armed => return Err(LineRuntimeError::InvalidScheduledWorkState),
    })
}

fn stage_scheduled_capture_completion<'a>(
    ledger: &mut RuntimeLineHandleLedger,
    packet: &RuntimeScheduledLineTask,
    terminal: RuntimeScheduledState,
    captures: impl IntoIterator<Item = &'a RuntimeValue>,
) -> Result<(), LineRuntimeError> {
    let terminal_lease = match terminal {
        RuntimeScheduledState::Completed => RuntimeHandleLeaseState::Completed,
        RuntimeScheduledState::Cancelled => RuntimeHandleLeaseState::Cancelled,
        RuntimeScheduledState::Failed => RuntimeHandleLeaseState::Failed,
        RuntimeScheduledState::Armed
        | RuntimeScheduledState::Running
        | RuntimeScheduledState::Cancelling => {
            return Err(LineRuntimeError::InvalidScheduledWorkState);
        }
    };
    let lease = ledger
        .lease(packet.token())
        .ok_or(LineRuntimeError::UnknownHandle)?;
    let retiring = matches!(
        lease.owner(),
        RuntimeHandleOwnerSlot::RetiringLineRegistry { .. }
    );
    ledger.set_state(packet.token(), lease.state(), terminal_lease)?;
    if retiring {
        ledger.set_state(
            packet.token(),
            terminal_lease,
            RuntimeHandleLeaseState::Released,
        )?;
    }
    let expected_owner = RuntimeHandleOwnerSlot::ChildScope(packet.work().clone());
    let mut tokens = std::collections::BTreeSet::new();
    for capture in captures {
        for handle in capture
            .line_handle_projection()
            .map_err(|_| LineRuntimeError::InvalidScheduledCaptureGraph)?
        {
            if !tokens.insert(handle.token().clone()) {
                return Err(LineRuntimeError::DuplicateHandleOccurrence);
            }
            let lease = ledger
                .lease(handle.token())
                .ok_or(LineRuntimeError::UnknownHandle)?;
            if lease.state() == RuntimeHandleLeaseState::Released {
                continue;
            }
            match lease.owner() {
                owner if owner == &expected_owner => ledger.transfer(
                    handle.token(),
                    &expected_owner,
                    RuntimeHandleOwnerSlot::LineScope,
                )?,
                RuntimeHandleOwnerSlot::LineScope => {}
                _ => return Err(LineRuntimeError::WrongOwner),
            }
        }
    }
    Ok(())
}

fn stage_child_scope_finish(
    ledger: &mut RuntimeLineHandleLedger,
    commands: &mut RuntimeCommandQueue,
    tag: &LineTaskWorkTag,
    live: &std::collections::BTreeSet<RuntimeLineHandleToken>,
    returned: &std::collections::BTreeSet<RuntimeLineHandleToken>,
    policy: RuntimeDropPolicy,
) -> Result<(), LineRuntimeError> {
    if returned.iter().any(|token| !live.contains(token)) {
        return Err(LineRuntimeError::UnexpectedChildHandleOccurrence);
    }
    let owner = RuntimeHandleOwnerSlot::ChildScope(tag.clone());
    for token in live {
        if token.activation() != tag.activation_id() {
            return Err(LineRuntimeError::WrongActivation);
        }
        let lease = ledger.lease(token).ok_or(LineRuntimeError::UnknownHandle)?;
        if lease.owner() != &owner {
            return Err(LineRuntimeError::WrongOwner);
        }
        if returned.contains(token) {
            ledger.transfer(token, &owner, RuntimeHandleOwnerSlot::LineScope)?;
        } else {
            ledger.drop_owned_with_policy(token, &owner, policy, commands)?;
        }
    }
    Ok(())
}

fn stage_unstarted_scheduled_completion(
    ledger: &mut RuntimeLineHandleLedger,
    packet: &RuntimeScheduledLineTask,
    terminal: RuntimeScheduledState,
) -> Result<(), LineRuntimeError> {
    if !is_terminal_scheduled_state(terminal)
        || !scheduled_transition_is_legal(packet.state, terminal)
        || packet.validate_custody().is_err()
    {
        return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
    }
    let RuntimeScheduledCaptureCustody::Packet(captures) = &packet.custody else {
        return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
    };
    stage_scheduled_capture_completion(
        ledger,
        packet,
        terminal,
        captures.iter().map(|binding| &binding.value),
    )
}

impl RuntimeScheduledLineTask {
    #[must_use = "construct a validated scheduled line task"]
    pub fn new(
        token: RuntimeLineHandleToken,
        child: RuntimeLineTaskNodeId,
        work: LineTaskWorkTag,
        deadline: LogicalDuration,
        captures: Box<[RuntimeLocalBinding]>,
    ) -> Result<Self, LineRuntimeError> {
        Self::try_from_parts(
            token,
            child,
            work,
            deadline,
            RuntimeScheduledCaptureCustody::Packet(captures),
            RuntimeScheduledState::Armed,
        )
    }

    fn packet_for_child_fiber(&self) -> Result<&[RuntimeLocalBinding], LineRuntimeError> {
        if self.state != RuntimeScheduledState::Running || self.validate_custody().is_err() {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        match &self.custody {
            RuntimeScheduledCaptureCustody::Packet(bindings) => Ok(bindings),
            RuntimeScheduledCaptureCustody::ChildFiber(_)
            | RuntimeScheduledCaptureCustody::LineScope(_) => {
                Err(LineRuntimeError::InvalidScheduledCaptureTransition)
            }
        }
    }

    pub(crate) fn take_packet_for_child_fiber(
        &mut self,
    ) -> Result<Box<[RuntimeLocalBinding]>, LineRuntimeError> {
        self.packet_for_child_fiber()?;

        let custody = std::mem::replace(
            &mut self.custody,
            RuntimeScheduledCaptureCustody::Packet(Vec::new().into_boxed_slice()),
        );
        match custody {
            RuntimeScheduledCaptureCustody::Packet(bindings) => {
                let locals = bindings
                    .iter()
                    .map(|binding| binding.local)
                    .collect::<Vec<_>>()
                    .into_boxed_slice();
                self.custody = RuntimeScheduledCaptureCustody::ChildFiber(locals);
                Ok(bindings)
            }
            custody => {
                self.custody = custody;
                Err(LineRuntimeError::InvalidScheduledCaptureTransition)
            }
        }
    }

    pub(crate) fn admit_child_fiber_bindings(
        &mut self,
        bindings: Box<[RuntimeLocalSlot]>,
        terminal: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        self.inspect_child_fiber_bindings(&bindings, terminal)?;
        let original_locals = match &self.custody {
            RuntimeScheduledCaptureCustody::ChildFiber(locals) => locals.clone(),
            RuntimeScheduledCaptureCustody::Packet(_)
            | RuntimeScheduledCaptureCustody::LineScope(_) => {
                unreachable!("checked scheduled child custody remains present")
            }
        };
        let mut returned = bindings
            .into_vec()
            .into_iter()
            .map(|binding| (binding.local(), binding))
            .collect::<BTreeMap<_, _>>();
        let ordered = original_locals
            .iter()
            .filter_map(|local| returned.remove(local))
            .collect::<Vec<_>>()
            .into_boxed_slice();
        self.custody = RuntimeScheduledCaptureCustody::LineScope(ordered);
        self.state = terminal;
        Ok(())
    }

    fn inspect_child_fiber_bindings(
        &self,
        bindings: &[RuntimeLocalSlot],
        terminal: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        let references = bindings
            .iter()
            .map(|binding| (binding.local(), binding.storage()))
            .collect::<Vec<_>>();
        self.inspect_child_fiber_binding_refs(&references, terminal)
    }

    fn inspect_child_fiber_binding_refs(
        &self,
        bindings: &[(
            RuntimeLocalDeclarationId,
            &RuntimePlaceStorage<RuntimeValue>,
        )],
        terminal: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        if !matches!(
            self.state,
            RuntimeScheduledState::Running | RuntimeScheduledState::Cancelling
        ) || !matches!(&self.custody, RuntimeScheduledCaptureCustody::ChildFiber(_))
            || self.validate_custody().is_err()
            || !is_terminal_scheduled_state(terminal)
            || !scheduled_transition_is_legal(self.state, terminal)
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }

        let original_locals = match &self.custody {
            RuntimeScheduledCaptureCustody::ChildFiber(locals) => locals,
            RuntimeScheduledCaptureCustody::Packet(_)
            | RuntimeScheduledCaptureCustody::LineScope(_) => {
                return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
            }
        };
        let mut returned = std::collections::BTreeSet::new();
        for (local, _) in bindings {
            if !returned.insert(*local) {
                return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
            }
        }
        if returned
            .iter()
            .any(|local| !original_locals.iter().any(|original| original == local))
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        Ok(())
    }

    pub(crate) fn move_packet_to_line_scope(
        &mut self,
        terminal: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        if !matches!(&self.custody, RuntimeScheduledCaptureCustody::Packet(_))
            || !is_terminal_scheduled_state(terminal)
            || !scheduled_transition_is_legal(self.state, terminal)
            || self.validate_custody().is_err()
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }

        let custody = std::mem::replace(
            &mut self.custody,
            RuntimeScheduledCaptureCustody::Packet(Vec::new().into_boxed_slice()),
        );
        match custody {
            RuntimeScheduledCaptureCustody::Packet(bindings) => {
                self.custody = RuntimeScheduledCaptureCustody::LineScope(
                    bindings
                        .into_vec()
                        .into_iter()
                        .map(RuntimeLocalSlot::from)
                        .collect::<Vec<_>>()
                        .into_boxed_slice(),
                );
                self.state = terminal;
                Ok(())
            }
            custody => {
                self.custody = custody;
                Err(LineRuntimeError::InvalidScheduledCaptureTransition)
            }
        }
    }

    pub(crate) fn line_scope_captures(&self) -> Result<&[RuntimeLocalSlot], LineRuntimeError> {
        self.validate_custody()?;
        match &self.custody {
            RuntimeScheduledCaptureCustody::LineScope(bindings) => Ok(bindings),
            RuntimeScheduledCaptureCustody::Packet(_)
            | RuntimeScheduledCaptureCustody::ChildFiber(_) => {
                Err(LineRuntimeError::InvalidScheduledCaptureTransition)
            }
        }
    }

    pub(crate) fn child_fiber_locals(
        &self,
    ) -> Result<&[RuntimeLocalDeclarationId], LineRuntimeError> {
        self.validate_custody()?;
        match &self.custody {
            RuntimeScheduledCaptureCustody::ChildFiber(locals) => Ok(locals),
            RuntimeScheduledCaptureCustody::Packet(_)
            | RuntimeScheduledCaptureCustody::LineScope(_) => {
                Err(LineRuntimeError::InvalidScheduledCaptureTransition)
            }
        }
    }

    fn require_line_scope(&self) -> Result<(), LineRuntimeError> {
        if matches!(&self.custody, RuntimeScheduledCaptureCustody::LineScope(_))
            && self.validate_custody().is_ok()
        {
            Ok(())
        } else {
            Err(LineRuntimeError::InvalidScheduledCaptureTransition)
        }
    }

    pub(crate) fn transition(
        &mut self,
        expected: RuntimeScheduledState,
        state: RuntimeScheduledState,
    ) -> Result<(), LineRuntimeError> {
        if self.state != expected || !scheduled_transition_is_legal(expected, state) {
            return Err(LineRuntimeError::InvalidScheduledTransition {
                expected,
                actual: self.state,
            });
        }
        if self.validate_custody().is_err()
            || !scheduled_custody_is_admissible(state, &self.custody)
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureTransition);
        }
        self.state = state;
        Ok(())
    }
}

fn scheduled_custody_is_admissible<V>(
    state: RuntimeScheduledState,
    custody: &RuntimeScheduledCaptureCustody<V>,
) -> bool {
    if !matches!(
        (state, custody),
        (
            RuntimeScheduledState::Armed,
            RuntimeScheduledCaptureCustody::Packet(_)
        ) | (
            RuntimeScheduledState::Running | RuntimeScheduledState::Cancelling,
            RuntimeScheduledCaptureCustody::Packet(_)
                | RuntimeScheduledCaptureCustody::ChildFiber(_)
        ) | (
            RuntimeScheduledState::Completed
                | RuntimeScheduledState::Cancelled
                | RuntimeScheduledState::Failed,
            RuntimeScheduledCaptureCustody::LineScope(_)
        )
    ) {
        return false;
    }
    custody_values_are_well_formed(custody)
}

const fn is_terminal_scheduled_state(state: RuntimeScheduledState) -> bool {
    matches!(
        state,
        RuntimeScheduledState::Completed
            | RuntimeScheduledState::Cancelled
            | RuntimeScheduledState::Failed
    )
}

fn custody_values_are_well_formed<V>(custody: &RuntimeScheduledCaptureCustody<V>) -> bool {
    match custody {
        RuntimeScheduledCaptureCustody::Packet(bindings) => local_bindings_are_unique(bindings),
        RuntimeScheduledCaptureCustody::LineScope(slots) => {
            local_ids_are_unique(slots.iter().map(RuntimeLocalSlot::local))
        }
        RuntimeScheduledCaptureCustody::ChildFiber(locals) => {
            local_ids_are_unique(locals.iter().copied())
        }
    }
}

fn local_bindings_are_unique<V>(bindings: &[RuntimeLocalBinding<V>]) -> bool {
    local_ids_are_unique(bindings.iter().map(|binding| binding.local))
}

fn local_ids_are_unique<I>(locals: I) -> bool
where
    I: IntoIterator<Item = RuntimeLocalDeclarationId>,
{
    let mut seen = std::collections::BTreeSet::new();
    locals.into_iter().all(|local| seen.insert(local))
}

const fn scheduled_transition_is_legal(
    source: RuntimeScheduledState,
    destination: RuntimeScheduledState,
) -> bool {
    matches!(
        (source, destination),
        (
            RuntimeScheduledState::Armed,
            RuntimeScheduledState::Running
                | RuntimeScheduledState::Cancelling
                | RuntimeScheduledState::Cancelled
                | RuntimeScheduledState::Failed
        ) | (
            RuntimeScheduledState::Running,
            RuntimeScheduledState::Completed
                | RuntimeScheduledState::Cancelling
                | RuntimeScheduledState::Cancelled
                | RuntimeScheduledState::Failed
        ) | (
            RuntimeScheduledState::Cancelling,
            RuntimeScheduledState::Cancelled | RuntimeScheduledState::Failed
        )
    )
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum LineRuntimeError {
    #[error("runtime plan has no accepted artifact generation")]
    UnboundArtifact,
    #[error("dialogue occurrence identity overflowed")]
    DialogueOccurrenceOverflow,
    #[error("dialogue occurrence namespace capacity exceeded")]
    DialogueNamespaceCapacity,
    #[error("dialogue content has no result-producing line task group")]
    MissingTaskGroup,
    #[error("dialogue content references a missing line task group")]
    UnknownTaskGroup,
    #[error("dialogue activation references a missing content plan")]
    UnknownContentPlan,
    #[error("dialogue result target does not match its line task group")]
    DialogueResultTypeMismatch,
    #[error("line handle has the wrong opaque producer")]
    WrongOpaqueProducer,
    #[error("line handle payload is not the canonical token record")]
    InvalidHandlePayload,
    #[error("line handle generation is stale")]
    StaleGeneration,
    #[error("line handle belongs to a different activation")]
    WrongActivation,
    #[error("line handle site is invalid for its resource")]
    InvalidHandleSite,
    #[error("line handle token is duplicated")]
    DuplicateHandleToken,
    #[error("one affine line handle token occurs more than once in a runtime value graph")]
    DuplicateHandleOccurrence,
    #[error("line handle is not live in this activation")]
    UnknownHandle,
    #[error("line handle is owned by another runtime slot")]
    WrongOwner,
    #[error("line handle owner transition is not legal in the dialogue lifecycle")]
    IllegalOwnerTransition,
    #[error("line ownership references unknown runtime local declaration {local}")]
    UnknownOwnedLocal {
        local: crate::runtime_id::RuntimeLocalDeclarationId,
    },
    #[error("runtime environment slot identity overflowed")]
    OwnedSlotOverflow,
    #[error("line handle was already released")]
    ReleasedHandle,
    #[error("line handle lease transition expected {expected:?}, found {actual:?}")]
    InvalidLeaseTransition {
        expected: RuntimeHandleLeaseState,
        actual: RuntimeHandleLeaseState,
    },
    #[error("line handle cannot be dropped from its current resource state")]
    InvalidDropTransition,
    #[error("scheduled line task transition expected {expected:?}, found {actual:?}")]
    InvalidScheduledTransition {
        expected: RuntimeScheduledState,
        actual: RuntimeScheduledState,
    },
    #[error("scheduled capture custody transition is invalid")]
    InvalidScheduledCaptureTransition,
    #[error("stage actor belongs to a different Character")]
    WrongActorCharacter,
    #[error("look belongs to a different Character")]
    WrongLookOwner,
    #[error("restored voice lease differs from its dialogue voice state")]
    InvalidRestoredVoiceLease,
    #[error("dialogue voice start was rejected: {failure:?}")]
    VoiceStartRejected {
        failure: crate::presentation::RuntimeVoiceFailure,
    },
    #[error("cue delay is negative")]
    NegativeCueDelay,
    #[error("cue delay is not a valid Duration")]
    InvalidCueDelay,
    #[error("cue delay or deadline overflowed")]
    CueDeadlineOverflow,
    #[error("dialogue logical elapsed time overflowed")]
    DialogueElapsedOverflow,
    #[error("line handle issuance ordinal overflowed")]
    HandleIssuanceOverflow,
    #[error("line activation program counter overflowed")]
    ActivationProgramCounterOverflow,
    #[error("line activation contains an operation outside its admitted role")]
    InvalidActivationOperation,
    #[error("stage command outcome does not match the pending typed operation")]
    StageOutcomeMismatch,
    #[error("actor look crossfade is not a valid Duration")]
    InvalidCrossfade,
    #[error("drop policy does not match its typed payload")]
    InvalidDropPolicy,
    #[error("scheduled line callback limit exceeded")]
    ScheduledCallbackLimitExceeded,
    #[error("line-root frame cannot be released while deferred registrations remain")]
    DeferredRegistrationsRemain,
    #[error("defer registration identity domain is exhausted")]
    DeferRegistrationIdentityExhausted,
    #[error(
        "deferred unwind transition disagrees with the activation's fixed exit and work identity"
    )]
    InvalidDeferredTransition,
    #[error("deferred registration site is absent from the executable table: {site}")]
    UnknownDeferredSite { site: RuntimeDeferSiteId },
    #[error("scheduled callback does not have one exact child-scope capture owner")]
    InvalidScheduledCaptureOwner,
    #[error("scheduled callback work has no exact runtime packet")]
    MissingScheduledWork,
    #[error("scheduled callback runtime instance was already queued or activated")]
    DuplicateScheduledWorkInstance,
    #[error("scheduled callback work is not in a completable runtime state")]
    InvalidScheduledWorkState,
    #[error("scheduled callback capture graph violates its admitted ownership packet")]
    InvalidScheduledCaptureGraph,
    #[error("detached scheduled callback cannot capture an affine line handle")]
    DetachedAffineCapture,
    #[error("line-task group capture must be unrestricted because group work may fan out")]
    AffineGroupCapture,
    #[error("live line handle limit exceeded")]
    LiveHandleLimitExceeded,
    #[error(transparent)]
    CommandSequence(#[from] crate::presentation::RuntimeCommandQueueError),
    #[error("dialogue presentation command identity was issued twice")]
    DuplicateCommandIdentity,
    #[error("dialogue presentation command queue does not continue the activation sequence")]
    StaleCommandQueue,
    #[error("dialogue command history limit exceeded")]
    CommandHistoryLimitExceeded,
    #[error("dialogue transaction produced host commands at a non-publishing boundary")]
    UnexpectedPreparedCommands,
    #[error("host outcome does not belong to an issued command in this dialogue activation")]
    UnknownCommandOutcome,
    #[error("host outcome belongs to a stale dialogue activation")]
    StaleCommandOutcome,
    #[error("host outcome belongs to a command superseded by a later resource transaction")]
    SupersededCommandOutcome,
    #[error("host outcome repeats a command outcome already resolved by this activation")]
    DuplicateCommandOutcome,
    #[error(
        "dialogue content event belongs to a stale activation: expected {expected:?}, got {actual:?}"
    )]
    StaleContentEvent {
        expected: crate::runtime_id::DialogueActivationId,
        actual: crate::runtime_id::DialogueActivationId,
    },
    #[error(
        "dialogue content event coordinate is absent from the accepted content plan: {event:?}"
    )]
    UnknownContentEvent {
        event: crate::step::RuntimeDialogueContentEventKind,
    },
    #[error("dialogue content event repeats within one input batch: {event:?}")]
    DuplicateContentEvent {
        event: crate::step::RuntimeDialogueContentEventKind,
    },
    #[error("dialogue advance repeats for activation {activation:?}")]
    DuplicateDialogueAdvance {
        activation: crate::runtime_id::DialogueActivationId,
    },
    #[error("dialogue ingress targets stale activation {activation:?}")]
    StaleDialogueIngress {
        activation: crate::runtime_id::DialogueActivationId,
    },
    #[error("dialogue ingress targets activation {activation:?} outside its ready phase")]
    DialogueIngressNotReady {
        activation: crate::runtime_id::DialogueActivationId,
    },
    #[error("dialogue content event was already consumed by this activation: {event:?}")]
    ConsumedContentEvent {
        event: crate::step::RuntimeDialogueContentEventKind,
    },
    #[error("dialogue input action repeats within one input batch: {event:?}")]
    DuplicateInputActionEvent {
        event: crate::step::RuntimeDialogueInputActionEvent,
    },
    #[error("dialogue input action was already consumed by this activation: {event:?}")]
    ConsumedInputActionEvent {
        event: crate::step::RuntimeDialogueInputActionEvent,
    },
    #[error("dialogue input action history exceeds the retained sequence limit")]
    InputActionHistoryLimitExceeded,
    #[error("dialogue content event arrived outside a live line-task reducer: {event:?}")]
    ContentEventOutsideLiveLineTask {
        event: crate::step::RuntimeDialogueContentEventKind,
    },
    #[error("dialogue result was not committed")]
    ResultNotCommitted,
    #[error("dialogue result was committed twice")]
    ResultAlreadyCommitted,
    #[error("dialogue result failed its exact type or pattern")]
    ResultPatternOrTypeMismatch,
    #[error("dialogue result transaction cannot make this lifecycle transition")]
    InvalidResultTransition,
    #[error("dialogue activation frame was released twice")]
    DuplicateFrameRelease,
    #[error("dialogue publication left a live lease outside the parent-fiber owner")]
    UnownedLeaseAtPublish,
    #[error("parent fiber already owns a closed ledger for this dialogue activation")]
    DuplicateClosedLedger,
    #[error("dialogue activation registry already contains this activation")]
    DuplicateActivationLedger,
    #[error("dialogue activation registry does not contain this activation")]
    UnknownActivationLedger,
    #[error("dialogue activation frame has already published and only handle leases remain")]
    ActivationFrameReleased,
    #[error("parent-owned line handle was dropped before its dialogue result was published")]
    ParentHandleBeforePublication,
    #[error("parent AWBC execution introduced a line handle absent from its source fiber graph")]
    UnexpectedParentHandleOccurrence,
    #[error("line-task child execution introduced a line handle absent from its source graph")]
    UnexpectedChildHandleOccurrence,
    #[error(
        "affine line handle disappeared without the typed Drop instruction that owns its policy"
    )]
    UnjournaledHandleDrop,
    #[error("restored dialogue handle ledger violates activation/resource ownership invariants")]
    InvalidRestoredLedgerState,
    #[error(
        "restored dialogue command journal is noncanonical or has an invalid resource reference"
    )]
    InvalidRestoredCommandJournal,
    #[error("restored scheduled work is inconsistent with its cue resource or activation")]
    InvalidRestoredScheduledState,
    #[error("restored dialogue result is inconsistent with its ledger/frame phase")]
    InvalidRestoredResultState,
    #[error("restored line-root deferred registrations violate stack or capture ownership")]
    InvalidRestoredDeferredState,
    #[error(
        "restored scoped defer registration is outside its activation's allocation or duplicates a retained registration"
    )]
    InvalidRestoredScopedDeferIdentity,
    #[error("dialogue activation transaction was superseded by a newer commit")]
    StaleActivationTransaction,
    #[error("dialogue activation transaction revision overflowed")]
    ActivationTransactionRevisionOverflow,
    #[error("dialogue activation transaction is not terminal")]
    ActivationTransactionNotTerminal,
    #[error("active dialogue transaction carries a terminal frame disposition")]
    UnexpectedTerminalDisposition,
    #[error("dialogue terminal disposition does not match the committed result state")]
    TerminalDispositionMismatch,
    #[error("host rejected a stage command: {code:?}")]
    StageCommandRejected { code: RuntimeStageRejectCode },
}

impl<T, V> RuntimeDialogueActivationState<T, V> {
    pub(crate) fn received_defer_slots(
        &self,
        execution: crate::runtime_id::ExecutionInstanceId,
        activation: &DialogueActivationId,
    ) -> Result<BTreeMap<RuntimeLineHandleToken, RuntimeOwnedSlotId>, LineRuntimeError>
    where
        V: crate::value::RuntimeStoredValue,
    {
        let mut slots = BTreeMap::new();
        for packet in &self.deferred {
            for (token, slot) in packet.received_handle_slots(execution, activation)? {
                if slots.insert(token, slot).is_some() {
                    return Err(LineRuntimeError::DuplicateHandleOccurrence);
                }
            }
        }
        Ok(slots)
    }

    pub(crate) fn retained_registry_line_handles(
        &self,
    ) -> Result<
        Vec<(
            &arcweft_id::LifetimeRegistryKey,
            crate::value::ownership::RuntimeAffineLineHandle,
        )>,
        crate::value::AwbcRuntimeValueSnapshotError,
    > {
        self.line_registry.line_handle_rows()
    }

    pub(crate) const fn ledger(&self) -> &RuntimeLineHandleLedger {
        &self.ledger
    }

    pub(crate) fn restore_admit_reducer<P: LineTaskPlanView>(
        &self,
        activation: &DialogueActivationId,
        plan: &P,
        reducer: &impl LineTaskReducerView,
    ) -> Result<(), LineRuntimeError> {
        if reducer.activation() != activation {
            return Err(LineRuntimeError::InvalidRestoredScheduledState);
        }
        if let RuntimeDialogueResultState::Selected { source, .. } = &self.result {
            if source.activation_id() != activation || !source.is_well_formed() {
                return Err(LineRuntimeError::InvalidRestoredResultState);
            }
            match source.work() {
                LineTaskWork::Cancellation(action)
                    if reducer.cancellation_action() == Some(&action)
                        && plan.has_cancellation_work(&action)
                        && !reducer
                            .activation_lane()
                            .outstanding()
                            .any(|work| matches!(work, LineTaskWork::Cancellation(candidate) if candidate == &action))
                        && matches!(
                            reducer.phase(),
                            super::LineTaskPhase::Closing {
                                exit: ScopeExit::Cancelled
                            } | super::LineTaskPhase::Closed {
                                exit: ScopeExit::Cancelled
                            }
                        ) => {}
                LineTaskWork::Node(action) => {
                    let mark = super::mark_result_source(plan, action)
                        .ok_or(LineRuntimeError::InvalidRestoredResultState)?;
                    if !reducer
                        .consumed_content_events()
                        .any(|event| *event == RuntimeDialogueContentEventKind::Mark(mark))
                        || matches!(
                            reducer.phase(),
                            super::LineTaskPhase::Closing {
                                exit: ScopeExit::Failed
                            } | super::LineTaskPhase::Closed {
                                exit: ScopeExit::Failed
                            }
                        )
                    {
                        return Err(LineRuntimeError::InvalidRestoredResultState);
                    }
                    let completed = match source.instance() {
                        LineTaskWorkInstance::Activation(_) => reducer
                            .activation_lane()
                            .node_states()
                            .get(action.index())
                            .is_some_and(|state| *state == LineTaskNodeState::Completed),
                        LineTaskWorkInstance::Scheduled(token) => {
                            let scheduled = self.scheduled.iter().find(|scheduled| {
                                scheduled.token() == token
                                    && plan.scheduled_child(token.site()) == Some(scheduled.child())
                            });
                            let Some(scheduled) = scheduled else {
                                return Err(LineRuntimeError::InvalidRestoredResultState);
                            };
                            let mut subtree = std::collections::BTreeSet::new();
                            if super::collect_line_task_subtree(
                                plan,
                                scheduled.child(),
                                &mut subtree,
                            )
                            .is_err()
                                || !subtree.contains(&action)
                            {
                                return Err(LineRuntimeError::InvalidRestoredResultState);
                            }
                            reducer
                                .scheduled_lanes()
                                .find(|(lane_token, _)| *lane_token == token)
                                .map_or_else(
                                    || scheduled.state() == RuntimeScheduledState::Completed,
                                    |(_, lane)| {
                                        lane.node_states().get(action.index()).is_some_and(
                                            |state| *state == LineTaskNodeState::Completed,
                                        )
                                    },
                                )
                        }
                    };
                    if !completed {
                        return Err(LineRuntimeError::InvalidRestoredResultState);
                    }
                }
                LineTaskWork::Cancellation(_)
                | LineTaskWork::Cleanup(_)
                | LineTaskWork::Defer(_) => {
                    return Err(LineRuntimeError::InvalidRestoredResultState);
                }
            }
        }
        let ready = reducer
            .scheduled_ready()
            .cloned()
            .collect::<std::collections::BTreeSet<_>>();
        let lanes = reducer
            .scheduled_lanes()
            .map(|(token, _)| token.clone())
            .collect::<std::collections::BTreeSet<_>>();
        if ready.len() != reducer.scheduled_ready().len()
            || lanes.len() != reducer.scheduled_lanes().len()
            || ready.iter().any(|token| lanes.contains(token))
        {
            return Err(LineRuntimeError::InvalidRestoredScheduledState);
        }
        for scheduled in &self.scheduled {
            if scheduled.token().activation() != reducer.activation()
                || scheduled.work().scheduled_token() != Some(scheduled.token())
            {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
            let (expects_ready, expects_lane) = match (&scheduled.state, &scheduled.custody) {
                (RuntimeScheduledState::Armed, RuntimeScheduledCaptureCustody::Packet(_))
                | (
                    RuntimeScheduledState::Completed
                    | RuntimeScheduledState::Cancelled
                    | RuntimeScheduledState::Failed,
                    RuntimeScheduledCaptureCustody::LineScope(_),
                ) => (false, false),
                (RuntimeScheduledState::Running, RuntimeScheduledCaptureCustody::Packet(_)) => {
                    (true, false)
                }
                (
                    RuntimeScheduledState::Running | RuntimeScheduledState::Cancelling,
                    RuntimeScheduledCaptureCustody::ChildFiber(_),
                ) => (false, true),
                _ => return Err(LineRuntimeError::InvalidRestoredScheduledState),
            };
            if ready.contains(scheduled.token()) != expects_ready
                || lanes.contains(scheduled.token()) != expects_lane
            {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
        }
        if ready.iter().chain(lanes.iter()).any(|token| {
            !self
                .scheduled
                .iter()
                .any(|scheduled| scheduled.token() == token)
        }) {
            return Err(LineRuntimeError::InvalidRestoredScheduledState);
        }
        Ok(())
    }

    pub(crate) fn scheduled_child_custody_keys(
        &self,
    ) -> Vec<(LineTaskWorkTag, RuntimeLineHandleToken)> {
        self.scheduled
            .iter()
            .filter(|scheduled| {
                matches!(
                    &scheduled.custody,
                    RuntimeScheduledCaptureCustody::ChildFiber(_)
                )
            })
            .map(|scheduled| (scheduled.work().clone(), scheduled.token().clone()))
            .collect()
    }

    pub(crate) fn unstarted_scheduled_work(&self) -> impl Iterator<Item = &LineTaskWorkTag> {
        self.scheduled.iter().filter_map(|scheduled| {
            matches!(scheduled.custody, RuntimeScheduledCaptureCustody::Packet(_))
                .then_some(scheduled.work())
        })
    }

    pub(crate) const fn result(&self) -> &RuntimeDialogueResultState<T, V> {
        &self.result
    }

    pub(crate) fn retained_result_line_handles(
        &self,
    ) -> Result<Vec<crate::value::ownership::RuntimeAffineLineHandle>, LineRuntimeError>
    where
        V: crate::value::RuntimeStoredValue,
    {
        match &self.result {
            RuntimeDialogueResultState::Committed { value, .. }
            | RuntimeDialogueResultState::Selected { value, .. }
            | RuntimeDialogueResultState::Publishing { value, .. } => value
                .borrowed_view()
                .line_handle_projection()
                .map_err(|_| LineRuntimeError::InvalidHandlePayload),
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Published
            | RuntimeDialogueResultState::Abandoned => Ok(Vec::new()),
        }
    }

    /// A Publishing value still carries its full pattern shape while drops
    /// settle. The receiver must prove its pattern discards each retired lease.
    pub(crate) fn admit_result_discards(
        &self,
        retired_received: impl Fn(&crate::value::ownership::RuntimeAffineLineHandle) -> bool,
        validate: impl FnOnce(
            RuntimeValueView<'_>,
            &std::collections::BTreeSet<RuntimeLineHandleToken>,
        ) -> Result<(), LineRuntimeError>,
    ) -> Result<(), LineRuntimeError>
    where
        V: crate::value::RuntimeStoredValue,
    {
        let RuntimeDialogueResultState::Publishing { value, .. } = &self.result else {
            return Ok(());
        };
        let view = value.borrowed_view();
        let retired = view
            .line_handle_projection()
            .map_err(|_| LineRuntimeError::InvalidRestoredResultState)?
            .into_iter()
            .filter(|handle| {
                self.ledger.lease(handle.token()).map_or_else(
                    || retired_received(handle),
                    |lease| result_lease_was_retired(lease.state()),
                )
            })
            .map(|handle| handle.token().clone())
            .collect::<std::collections::BTreeSet<_>>();
        if retired.is_empty() {
            return Ok(());
        }
        validate(view, &retired)
    }

    pub(crate) fn issued_command(
        &self,
        command: &crate::presentation::RuntimeLineCommandId,
    ) -> Option<&crate::presentation::RuntimeLineHostCommand> {
        self.issued_commands.get(command)
    }

    pub(crate) fn visit_retained_value_roots<E>(
        &self,
        mut visit: impl FnMut(&V) -> Result<(), E>,
    ) -> Result<(), E> {
        self.visit_retained_values_with_depth(|_, value| visit(value))
    }

    fn visit_retained_values_with_depth<E>(
        &self,
        mut visit: impl FnMut(usize, &V) -> Result<(), E>,
    ) -> Result<(), E> {
        for scheduled in &self.scheduled {
            for (depth, value) in scheduled.custody.values_with_depth() {
                visit(depth, value)?;
            }
        }
        for deferred in &self.deferred {
            for value in deferred.captures() {
                visit(0, value)?;
            }
        }
        match &self.result {
            RuntimeDialogueResultState::Committed { value, .. }
            | RuntimeDialogueResultState::Selected { value, .. }
            | RuntimeDialogueResultState::Publishing { value, .. } => visit(0, value)?,
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Published
            | RuntimeDialogueResultState::Abandoned => {}
        }
        Ok(())
    }

    /// Joins the original program's resource bank while retaining value custody.
    /// Activation/ledger and backend type obligations remain on their owners.
    pub(crate) fn admit_retained_resources(
        &self,
        activation: Option<DialogueActivationId>,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        T: RuntimeDialogueTypeCoordinate,
        V: crate::value::RuntimeStoredValue,
    {
        admission.status()?;
        if !self.prepared_commands.is_empty() {
            return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                message: "cannot snapshot an in-flight line command preparation".to_owned(),
            });
        }
        admission.validate_metadata(&(
            &self.ledger,
            self.command_sequence,
            &self.issued_commands,
            &self.superseded_commands,
            &self.resolved_commands,
            self.next_defer_registration,
            &self.defer_unwind,
            self.frame_released,
            &self.prepared_commands,
        ))?;
        if !self.line_registry.is_empty() {
            let activation = activation.filter(|_| !self.frame_released).ok_or_else(|| {
                crate::value::AwbcRuntimeValueSnapshotError::Message {
                    message: "line registry requires its original unreleased dialogue activation"
                        .to_owned(),
                }
            })?;
            self.line_registry.admit_retained(
                crate::effect::RuntimeRegistryOwner::Dialogue(activation),
                admission,
            )?;
        }
        admission.validate_metadata_collection(self.scheduled.len())?;
        admission.validate_metadata_collection(self.deferred.len())?;
        for scheduled in &self.scheduled {
            scheduled
                .validate_custody()
                .map_err(|error| scheduled_custody_snapshot_error(&error))?;
            admission.validate_metadata(&(
                &scheduled.token,
                scheduled.child,
                &scheduled.work,
                scheduled.deadline,
                scheduled.state,
            ))?;
            match &scheduled.custody {
                RuntimeScheduledCaptureCustody::Packet(bindings) => {
                    admission.validate_metadata_collection(bindings.len())?;
                    for binding in bindings {
                        admission.validate_metadata(&binding.local)?;
                    }
                }
                RuntimeScheduledCaptureCustody::ChildFiber(locals) => {
                    admission.validate_metadata(locals)?;
                }
                RuntimeScheduledCaptureCustody::LineScope(slots) => {
                    admission.validate_metadata_collection(slots.len())?;
                    for slot in slots {
                        admission.validate_metadata(&slot.local())?;
                        slot.storage().admit_record_headers(admission)?;
                    }
                }
            }
        }
        for deferred in &self.deferred {
            admission.validate_metadata(&(
                deferred.id(),
                deferred.site(),
                deferred.outcome_filter(),
            ))?;
            admission.validate_metadata_collection(deferred.captures().len())?;
        }
        match &self.result {
            RuntimeDialogueResultState::Committed { ty, .. }
            | RuntimeDialogueResultState::Publishing { ty, .. } => {
                ty.admit_type_metadata(admission)?;
            }
            RuntimeDialogueResultState::Selected { ty, source, .. } => {
                ty.admit_type_metadata(admission)?;
                admission.validate_metadata(source)?;
            }
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Published
            | RuntimeDialogueResultState::Abandoned => {}
        }
        admission.admit_composite(V::admission_origin(), |owner, resources| {
            self.visit_retained_values_with_depth(|depth, value| {
                let view = value.borrowed_view();
                resources.validate_view(view, depth, None)?;
                crate::value::AwbcRuntimeValueSnapshot::validate_admitted_storage_view(
                    view, owner, resources,
                )
            })?;
            if let Some(owner) = owner {
                self.admit_original_types(owner, resources)?;
            }
            Ok(())
        })
    }

    fn admit_original_types(
        &self,
        owner: &RuntimeProgramOwner,
        resources: &crate::entry::schema::value_encoding::ValueResourceAdmission,
    ) -> Result<(), crate::value::AwbcRuntimeValueSnapshotError>
    where
        T: RuntimeDialogueTypeCoordinate,
        V: crate::value::RuntimeStoredValue,
    {
        for deferred in &self.deferred {
            deferred.admit_original_capture_types(owner, resources)?;
        }
        if let Some((_, site)) = self.deferred_inflight() {
            let exists = match owner {
                RuntimeProgramOwner::Plan(plan) => plan.defer_function_site(site).is_some(),
                RuntimeProgramOwner::Awbc(program) => {
                    program.defer_sites.get(site.index()).is_some()
                }
            };
            if !exists {
                return Err(crate::value::AwbcRuntimeValueSnapshotError::Message {
                    message: LineRuntimeError::UnknownDeferredSite { site }.to_string(),
                });
            }
        }
        match &self.result {
            RuntimeDialogueResultState::Committed { value, ty }
            | RuntimeDialogueResultState::Selected { value, ty, .. }
            | RuntimeDialogueResultState::Publishing { value, ty } => {
                ty.original_value_type(owner)?.validate_snapshot_storage(
                    value.borrowed_view(),
                    &resources.work(),
                    V::admission_origin(),
                )?;
            }
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Published
            | RuntimeDialogueResultState::Abandoned => {}
        }
        Ok(())
    }

    /// The exact child whose capture packet has left the registration stack.
    #[must_use]
    pub(crate) fn deferred_inflight(
        &self,
    ) -> Option<(RuntimeDeferRegistrationId, RuntimeDeferSiteId)> {
        self.defer_unwind
            .as_ref()
            .and_then(|unwind| unwind.inflight)
            .map(|inflight| (inflight.id, inflight.site))
    }

    fn allocated_defer_registration(&self, id: RuntimeDeferRegistrationId) -> bool {
        self.next_defer_registration.contains(id)
    }

    /// Lexical scopes own their packets, but registration numbers come from
    /// this activation, including packets without any affine handle leases.
    pub(crate) fn admit_restored_scoped_defer_registrations(
        &self,
        registrations: impl IntoIterator<Item = RuntimeDeferRegistrationId>,
    ) -> Result<(), LineRuntimeError> {
        let mut scoped = BTreeSet::new();
        for id in registrations {
            if !self.allocated_defer_registration(id) || !scoped.insert(id) {
                return Err(LineRuntimeError::InvalidRestoredScopedDeferIdentity);
            }
        }
        if !scoped.is_empty()
            && (self.deferred.iter().any(|row| scoped.contains(&row.id()))
                || self
                    .deferred_inflight()
                    .is_some_and(|(id, _)| scoped.contains(&id)))
        {
            return Err(LineRuntimeError::InvalidRestoredScopedDeferIdentity);
        }
        Ok(())
    }

    fn has_pending_deferred_work(&self) -> bool {
        !self.deferred.is_empty()
            || self
                .defer_unwind
                .as_ref()
                .is_some_and(|unwind| unwind.inflight.is_some())
    }

    #[cfg(test)]
    pub(crate) fn restore_admit(
        &self,
        activation: &DialogueActivationId,
    ) -> Result<(), LineRuntimeError>
    where
        V: crate::value::RuntimeStoredValue,
    {
        self.restore_admit_with_deferred_child(
            activation,
            None,
            |_, _, _| false,
            |_, _| false,
            |_, _, _| false,
        )
    }

    pub(crate) fn restore_admit_with_deferred_child(
        &self,
        activation: &DialogueActivationId,
        expected_child: Option<(RuntimeDeferRegistrationId, RuntimeDeferSiteId)>,
        validate_received_actor: impl Fn(
            &crate::presentation::RuntimeLineCommandId,
            &RuntimeLineHandleToken,
            &CharacterId,
        ) -> bool,
        mut validate_received_result: impl FnMut(
            &crate::value::ownership::RuntimeAffineLineHandle,
            bool,
        ) -> bool,
        mut validate_received_defer: impl FnMut(
            &crate::value::ownership::RuntimeAffineLineHandle,
            RuntimeDeferRegistrationId,
            u32,
        ) -> bool,
    ) -> Result<(), LineRuntimeError>
    where
        V: crate::value::RuntimeStoredValue,
    {
        if self.frame_released && self.has_pending_deferred_work() {
            return Err(LineRuntimeError::InvalidRestoredDeferredState);
        }
        let inflight = self.deferred_inflight();
        if !defer_registration_stack_is_ordered(
            self.deferred.iter().map(RuntimeLineDeferredRegistration::id),
            inflight.map(|(id, _)| id),
        )
            || self
                .deferred
                .last()
                .is_some_and(|registration| !self.allocated_defer_registration(registration.id()))
            || inflight.is_some_and(|(id, _)| !self.allocated_defer_registration(id))
            || self.ledger.leases().values().any(|lease| {
                matches!(
                    lease.owner(),
                    RuntimeHandleOwnerSlot::ScopedDefer(id) | RuntimeHandleOwnerSlot::RetiringScopedDefer(id)
                        if !self.allocated_defer_registration(*id)
                )
            })
        {
            return Err(LineRuntimeError::InvalidRestoredDeferredState);
        }
        // An activation-only snapshot supplies None. Product restore supplies
        // the exact child owner it authenticated from its fiber snapshot.
        if inflight != expected_child {
            return Err(LineRuntimeError::InvalidRestoredDeferredState);
        }
        validate_restored_ledger(activation, &self.ledger)?;
        if self
            .ledger
            .leases()
            .values()
            .any(|lease| match lease.owner() {
                RuntimeHandleOwnerSlot::RetiringScopedDefer(_) => {
                    if matches!(lease.resource(), RuntimeHandleResource::Cue(cue)
                        if matches!(cue.origin(), RuntimeCueOrigin::Scheduled { .. }))
                    {
                        !self.scheduled.iter().any(|scheduled| {
                            scheduled.token() == lease.token()
                                && matches!(
                                    scheduled.state(),
                                    RuntimeScheduledState::Running
                                        | RuntimeScheduledState::Cancelling
                                )
                        })
                    } else {
                        !published_result_retirement_is_correlated(lease, &self.issued_commands)
                    }
                }
                RuntimeHandleOwnerSlot::ReceivedDialogueResult { .. }
                | RuntimeHandleOwnerSlot::RetiringDialogueResult { .. } => true,
                RuntimeHandleOwnerSlot::LineRegistry { receiver, .. } => receiver != activation,
                RuntimeHandleOwnerSlot::RetiringLineRegistry { receiver } => {
                    receiver != activation || !self.publishing_retirement_is_correlated(lease)
                }
                _ => false,
            })
        {
            return Err(LineRuntimeError::InvalidRestoredLedgerState);
        }
        validate_restored_command_journal(
            activation,
            self.command_sequence,
            &self.issued_commands,
            &self.superseded_commands,
            &self.resolved_commands,
            &self.ledger,
            validate_received_actor,
        )?;
        let mut scheduled_tokens = std::collections::BTreeSet::new();
        let mut scheduled_capture_tokens = std::collections::BTreeSet::new();
        for scheduled in &self.scheduled {
            scheduled.validate_custody()?;
            if scheduled.token().activation() != activation
                || scheduled.work().activation_id() != activation
                || scheduled.work().scheduled_token() != Some(scheduled.token())
                || !scheduled_tokens.insert(scheduled.token().clone())
            {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
            let lease = self
                .ledger
                .lease(scheduled.token())
                .ok_or(LineRuntimeError::InvalidRestoredScheduledState)?;
            let RuntimeHandleResource::Cue(cue) = lease.resource() else {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            };
            if !matches!(
                cue.origin(),
                RuntimeCueOrigin::Scheduled { child, deadline }
                    if *child == scheduled.child() && *deadline == scheduled.deadline()
            ) {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
            let lease_state_matches = match scheduled.state() {
                RuntimeScheduledState::Armed => lease.state() == RuntimeHandleLeaseState::Pending,
                RuntimeScheduledState::Running => lease.state() == RuntimeHandleLeaseState::Running,
                RuntimeScheduledState::Cancelling => matches!(
                    lease.state(),
                    RuntimeHandleLeaseState::Cancelling | RuntimeHandleLeaseState::Cancelled
                ),
                RuntimeScheduledState::Completed => matches!(
                    lease.state(),
                    RuntimeHandleLeaseState::Completed | RuntimeHandleLeaseState::Released
                ),
                RuntimeScheduledState::Cancelled => matches!(
                    lease.state(),
                    RuntimeHandleLeaseState::Cancelled | RuntimeHandleLeaseState::Released
                ),
                RuntimeScheduledState::Failed => matches!(
                    lease.state(),
                    RuntimeHandleLeaseState::Failed | RuntimeHandleLeaseState::Released
                ),
            };
            if !lease_state_matches {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
            let expected_capture_owner = match &scheduled.custody {
                RuntimeScheduledCaptureCustody::Packet(_) => {
                    Some(RuntimeHandleOwnerSlot::ChildScope(scheduled.work().clone()))
                }
                RuntimeScheduledCaptureCustody::LineScope(_) => {
                    Some(RuntimeHandleOwnerSlot::LineScope)
                }
                RuntimeScheduledCaptureCustody::ChildFiber(_) => None,
            };
            if let Some(expected_owner) = expected_capture_owner {
                let mut expected_tokens = std::collections::BTreeSet::new();
                for capture in scheduled.custody.values() {
                    for handle in capture
                        .borrowed_view()
                        .line_handle_projection()
                        .map_err(|_| LineRuntimeError::InvalidRestoredScheduledState)?
                    {
                        if handle.token().activation() != activation
                            || !expected_tokens.insert(handle.token().clone())
                            || !scheduled_capture_tokens.insert(handle.token().clone())
                        {
                            return Err(LineRuntimeError::InvalidRestoredScheduledState);
                        }
                        let capture_lease = self
                            .ledger
                            .lease(handle.token())
                            .ok_or(LineRuntimeError::InvalidRestoredScheduledState)?;
                        if capture_lease.owner() != &expected_owner
                            || capture_lease.state() == RuntimeHandleLeaseState::Released
                        {
                            return Err(LineRuntimeError::InvalidRestoredScheduledState);
                        }
                    }
                }
                let child_owned = self
                    .ledger
                    .leases()
                    .values()
                    .filter(|lease| {
                        lease.owner()
                            == &RuntimeHandleOwnerSlot::ChildScope(scheduled.work().clone())
                    })
                    .map(|lease| lease.token().clone())
                    .collect::<std::collections::BTreeSet<_>>();
                if matches!(
                    &scheduled.custody,
                    RuntimeScheduledCaptureCustody::Packet(_)
                ) && child_owned != expected_tokens
                    || matches!(
                        &scheduled.custody,
                        RuntimeScheduledCaptureCustody::LineScope(_)
                    ) && !child_owned.is_empty()
                {
                    return Err(LineRuntimeError::InvalidRestoredScheduledState);
                }
            }
        }
        for lease in self.ledger.leases().values() {
            if matches!(
                lease.resource(),
                RuntimeHandleResource::Cue(RuntimeCueLease {
                    origin: RuntimeCueOrigin::Scheduled { .. },
                })
            ) && !scheduled_tokens.contains(lease.token())
            {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
            if let RuntimeHandleOwnerSlot::ChildScope(work) = lease.owner()
                && let Some(token) = work.scheduled_token()
                && !self
                    .scheduled
                    .iter()
                    .any(|scheduled| scheduled.token() == token && scheduled.work() == work)
            {
                return Err(LineRuntimeError::InvalidRestoredScheduledState);
            }
        }
        for registration in &self.deferred {
            for (ordinal, capture) in registration.captures().iter().enumerate() {
                for handle in capture
                    .borrowed_view()
                    .line_handle_projection()
                    .map_err(|_| LineRuntimeError::InvalidRestoredDeferredState)?
                {
                    if !scheduled_capture_tokens.insert(handle.token().clone()) {
                        return Err(LineRuntimeError::InvalidRestoredDeferredState);
                    }
                    if handle.token().activation() != activation {
                        if !validate_received_defer(
                            &handle,
                            registration.id(),
                            u32::try_from(ordinal)
                                .map_err(|_| LineRuntimeError::OwnedSlotOverflow)?,
                        ) {
                            return Err(LineRuntimeError::InvalidRestoredDeferredState);
                        }
                        continue;
                    }
                    let capture_lease = self
                        .ledger
                        .lease(handle.token())
                        .ok_or(LineRuntimeError::InvalidRestoredDeferredState)?;
                    if capture_lease.resource().kind() != handle.kind()
                        || capture_lease.owner() != &RuntimeHandleOwnerSlot::LineScope
                        || capture_lease.state() == RuntimeHandleLeaseState::Released
                    {
                        return Err(LineRuntimeError::InvalidRestoredDeferredState);
                    }
                }
            }
        }
        let mut result_tokens = std::collections::BTreeSet::new();
        match &self.result {
            RuntimeDialogueResultState::Uncommitted => {
                if self.ledger.leases().values().any(|lease| {
                    matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
                        || (matches!(lease.owner(), RuntimeHandleOwnerSlot::DialogueResult(_))
                            && !result_lease_was_retired(lease.state()))
                }) {
                    return Err(LineRuntimeError::InvalidRestoredResultState);
                }
            }
            RuntimeDialogueResultState::Committed { value, .. }
            | RuntimeDialogueResultState::Selected { value, .. }
            | RuntimeDialogueResultState::Publishing { value, .. } => {
                let publishing =
                    matches!(self.result, RuntimeDialogueResultState::Publishing { .. });
                for handle in value
                    .borrowed_view()
                    .line_handle_projection()
                    .map_err(|_| LineRuntimeError::InvalidRestoredResultState)?
                {
                    if handle.token().activation() != activation {
                        if !validate_received_result(&handle, publishing) {
                            return Err(LineRuntimeError::InvalidRestoredResultState);
                        }
                        continue;
                    }
                    if !result_tokens.insert(handle.token().clone()) {
                        return Err(LineRuntimeError::InvalidRestoredResultState);
                    }
                    let lease = self
                        .ledger
                        .lease(handle.token())
                        .ok_or(LineRuntimeError::InvalidRestoredResultState)?;
                    if lease.resource().kind() != handle.kind()
                        || lease.owner()
                            != &RuntimeHandleOwnerSlot::DialogueResult(handle.path().clone())
                        || (result_lease_was_retired(lease.state())
                            && (!publishing || !self.publishing_retirement_is_correlated(lease)))
                    {
                        return Err(LineRuntimeError::InvalidRestoredResultState);
                    }
                }
                if matches!(
                    &self.result,
                    RuntimeDialogueResultState::Committed { .. }
                        | RuntimeDialogueResultState::Selected { .. }
                ) && self.ledger.leases().values().any(|lease| {
                    matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
                }) {
                    return Err(LineRuntimeError::InvalidRestoredResultState);
                }
            }
            RuntimeDialogueResultState::Abandoned => {
                if self.ledger.leases().values().any(|lease| {
                    matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
                        || (matches!(lease.owner(), RuntimeHandleOwnerSlot::DialogueResult(_))
                            && !result_lease_was_retired(lease.state()))
                }) {
                    return Err(LineRuntimeError::InvalidRestoredResultState);
                }
            }
            RuntimeDialogueResultState::Published => {
                return Err(LineRuntimeError::InvalidRestoredResultState);
            }
        }
        result_tokens.retain(|token| {
            self.ledger
                .lease(token)
                .is_some_and(|lease| !result_lease_was_retired(lease.state()))
        });
        let ledger_result_tokens = self
            .ledger
            .leases()
            .values()
            .filter(|lease| {
                matches!(lease.owner(), RuntimeHandleOwnerSlot::DialogueResult(_))
                    && !result_lease_was_retired(lease.state())
            })
            .map(|lease| lease.token().clone())
            .collect::<std::collections::BTreeSet<_>>();
        if ledger_result_tokens != result_tokens {
            return Err(LineRuntimeError::InvalidRestoredResultState);
        }
        if self.frame_released || !self.prepared_commands.is_empty() {
            return Err(LineRuntimeError::InvalidRestoredResultState);
        }
        Ok(())
    }

    fn publishing_retirement_is_correlated(&self, lease: &RuntimeHandleLease) -> bool {
        if lease.state() != RuntimeHandleLeaseState::Cancelling {
            return true;
        }
        if let RuntimeHandleResource::Cue(cue) = lease.resource()
            && matches!(cue.origin(), RuntimeCueOrigin::Scheduled { .. })
        {
            return self.scheduled.iter().any(|scheduled| {
                scheduled.token() == lease.token()
                    && scheduled.state() == RuntimeScheduledState::Cancelling
            });
        }
        published_result_retirement_is_correlated(lease, &self.issued_commands)
    }
}

fn published_result_retirement_is_correlated(
    lease: &RuntimeHandleLease,
    issued_commands: &BTreeMap<
        crate::presentation::RuntimeLineCommandId,
        crate::presentation::RuntimeLineHostCommand,
    >,
) -> bool {
    if let RuntimeHandleResource::Cue(cue) = lease.resource()
        && matches!(cue.origin(), RuntimeCueOrigin::Scheduled { .. })
    {
        return !matches!(
            lease.state(),
            RuntimeHandleLeaseState::Pending
                | RuntimeHandleLeaseState::Running
                | RuntimeHandleLeaseState::Cancelling
        );
    }
    lease.state() != RuntimeHandleLeaseState::Cancelling
        || issued_commands
            .values()
            .filter(|command| {
                let token = match command {
                    crate::presentation::RuntimeLineHostCommand::Stage(command) => {
                        published_command_token(command).ok()
                    }
                    crate::presentation::RuntimeLineHostCommand::Voice(command) => {
                        published_voice_command_token(command).ok()
                    }
                };
                token == Some(lease.token())
            })
            .count()
            == 1
}

impl<V> RuntimeScheduledLineTask<V> {
    #[must_use]
    pub const fn token(&self) -> &RuntimeLineHandleToken {
        &self.token
    }

    #[must_use]
    pub const fn child(&self) -> RuntimeLineTaskNodeId {
        self.child
    }

    #[must_use]
    pub const fn work(&self) -> &LineTaskWorkTag {
        &self.work
    }

    #[must_use]
    pub const fn deadline(&self) -> LogicalDuration {
        self.deadline
    }

    #[must_use]
    pub const fn state(&self) -> RuntimeScheduledState {
        self.state
    }

    fn validate_custody(&self) -> Result<(), LineRuntimeError> {
        scheduled_custody_is_admissible(self.state, &self.custody)
            .then_some(())
            .ok_or(LineRuntimeError::InvalidScheduledCaptureTransition)
    }

    fn try_from_parts(
        token: RuntimeLineHandleToken,
        child: RuntimeLineTaskNodeId,
        work: LineTaskWorkTag,
        deadline: LogicalDuration,
        custody: RuntimeScheduledCaptureCustody<V>,
        state: RuntimeScheduledState,
    ) -> Result<Self, LineRuntimeError> {
        if work.scheduled_token() != Some(&token)
            || !matches!(work.work(), super::LineTaskWork::Node(_))
        {
            return Err(LineRuntimeError::InvalidScheduledCaptureOwner);
        }
        let scheduled = Self {
            token,
            child,
            work,
            deadline,
            custody,
            state,
        };
        scheduled.validate_custody()?;
        Ok(scheduled)
    }
}

#[cfg(test)]
mod tests {
    use super::{
        AwbcRuntimeDialogueActivationSnapshot, AwbcRuntimeScheduledCaptureCustodySnapshot,
        LineRuntimeError, RuntimeCueLease, RuntimeCueOrigin, RuntimeDeferUnwindStep,
        RuntimeDialogueActivationState, RuntimeDialogueResultState, RuntimeHandleLease,
        RuntimeHandleLeaseState, RuntimeHandleOwnerSlot, RuntimeHandleResource,
        RuntimeLineDeferredRegistration, RuntimeScheduledCaptureCustody, RuntimeScheduledLineTask,
        ScopeExit,
    };
    use crate::awbc::schema::{
        AwbcAgentTypeShape, AwbcProgram, AwbcRuntimeType, AwbcRuntimeTypeShape, AwbcTypeId,
    };
    use crate::line_task::{
        LineTaskWork, LineTaskWorkTag, RuntimeDeferOutcomeFilter, RuntimeScheduledState,
    };
    use crate::runtime_id::{
        DialogueActivationId, RuntimeDeferSiteId, RuntimeDialogueContentPlanId,
        RuntimeLineHandleSiteId, RuntimeLineHandleToken, RuntimeLineTaskNodeId,
        RuntimeLocalDeclarationId, RuntimePersistentFiberId, RuntimePlanTypeId,
    };
    use crate::time::LogicalDuration;
    use crate::value::{RuntimeAgentValue, RuntimeDataShape, RuntimeLocalBinding, RuntimeValue};
    use crate::{pattern::RuntimeSemanticTypeId, task::RuntimeProgramOwner};
    use std::num::NonZeroU32;

    #[test]
    fn result_and_frame_transitions_are_typed_and_terminal() {
        let mut state = RuntimeDialogueActivationState::<RuntimePlanTypeId>::new();
        assert!(!state.is_terminal());
        state.abandon().expect("abandon uncommitted result");
        state.release_frame().expect("release frame");
        assert!(state.is_terminal());
        assert_eq!(
            state.release_frame(),
            Err(LineRuntimeError::DuplicateFrameRelease)
        );

        let mut published = RuntimeDialogueActivationState::new();
        published
            .commit_result(
                RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
                RuntimeValue::Unit,
            )
            .expect("commit");
        published
            .begin_result_publication()
            .expect("begin publication");
        published
            .finish_result_publication()
            .expect("finish publication");
        assert_eq!(
            published.abandon(),
            Err(LineRuntimeError::InvalidResultTransition)
        );
    }

    fn scheduled_activation() -> DialogueActivationId {
        DialogueActivationId::new(
            crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x73; 32])
                .expect("artifact"),
            RuntimePersistentFiberId::from_allocated(1),
            RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            9,
        )
    }

    #[test]
    fn cancellation_selection_replaces_only_the_unpublished_result_once() {
        let mut state = RuntimeDialogueActivationState::<RuntimePlanTypeId>::new();
        let ty = RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN);
        state
            .commit_result(ty, RuntimeValue::String("normal".to_owned()))
            .expect("initial result");
        let action =
            arcweft_interaction_model::input::InputActionId::new("SkipLine").expect("input action");
        let tag = LineTaskWorkTag::activation(
            scheduled_activation(),
            LineTaskWork::Cancellation(action.clone()),
        );
        state
            .select_result(&tag, ty, RuntimeValue::String("cancelled".to_owned()))
            .expect("one selected cancellation result");
        assert_eq!(
            state.result(),
            &RuntimeDialogueResultState::Selected {
                ty,
                value: RuntimeValue::String("cancelled".to_owned()),
                source: tag.clone(),
            }
        );
        assert_eq!(
            state.select_result(&tag, ty, RuntimeValue::Unit),
            Err(LineRuntimeError::InvalidResultTransition)
        );
        state.begin_result_publication().expect("publish selection");
        assert_eq!(
            state.result(),
            &RuntimeDialogueResultState::Publishing {
                ty,
                value: RuntimeValue::String("cancelled".to_owned()),
            }
        );
    }

    fn defer_site(index: usize) -> RuntimeDeferSiteId {
        RuntimeDeferSiteId::from_zero_based(index).expect("defer site")
    }

    fn deferred(capture: &str) -> Vec<RuntimeValue> {
        vec![RuntimeValue::String(capture.to_owned())]
    }

    fn deferred_program_owner() -> RuntimeProgramOwner {
        use crate::awbc::schema::{
            AwbcBlockId, AwbcEffectSetId, AwbcFrameLayoutId, AwbcFunction, AwbcFunctionFlags,
            AwbcFunctionId, AwbcFunctionKind, AwbcSignature, AwbcSignatureId, AwbcTableRange,
        };
        let mut program = AwbcProgram {
            runtime_types: vec![
                AwbcRuntimeType::new(
                    RuntimeSemanticTypeId::from_bytes([0xd0; 32]),
                    AwbcRuntimeTypeShape::Unit,
                ),
                AwbcRuntimeType::new(
                    RuntimeSemanticTypeId::from_bytes([0xd1; 32]),
                    AwbcRuntimeTypeShape::String,
                ),
                AwbcRuntimeType::new(
                    RuntimeSemanticTypeId::from_bytes([0xd2; 32]),
                    AwbcRuntimeTypeShape::Bool,
                ),
                AwbcRuntimeType::new(
                    RuntimeSemanticTypeId::from_bytes([0xd3; 32]),
                    AwbcRuntimeTypeShape::Tuple(vec![AwbcTypeId(2), AwbcTypeId(1)]),
                ),
                AwbcRuntimeType::new(
                    RuntimeSemanticTypeId::from_bytes([0xd4; 32]),
                    AwbcRuntimeTypeShape::Choice(vec![AwbcTypeId(1), AwbcTypeId(3)]),
                ),
            ],
            signatures: vec![AwbcSignature {
                params: vec![AwbcTypeId(4)],
                result: Some(AwbcTypeId(0)),
                effects: AwbcEffectSetId(0),
            }],
            ..AwbcProgram::default()
        };
        for ordinal in 0..2u8 {
            program.functions.push(AwbcFunction {
                definition: crate::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity(
                    [0xe0 + ordinal; 32],
                ),
                semantic_role: crate::plan::RuntimeFunctionSemanticRole::Ordinary,
                public_id: None,
                kind: AwbcFunctionKind::Ordinary,
                signature: AwbcSignatureId(0),
                type_context: None,
                input_ownership: Vec::new(),
                frame_layout: AwbcFrameLayoutId(0),
                blocks: AwbcTableRange::new(0, 0),
                entry_block: AwbcBlockId(0),
                flags: AwbcFunctionFlags::empty(),
            });
            program.defer_sites.push(AwbcFunctionId(u32::from(ordinal)));
        }
        RuntimeProgramOwner::Awbc(std::sync::Arc::new(program))
    }

    #[test]
    fn line_root_defers_are_dynamic_lifo_entries_filtered_by_exit() {
        let activation = scheduled_activation();
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        let repeated_site = defer_site(0);
        state
            .register_deferred(
                repeated_site,
                RuntimeDeferOutcomeFilter::Always,
                deferred("oldest"),
            )
            .expect("register first occurrence");
        let completion_only = state
            .register_deferred(
                defer_site(1),
                RuntimeDeferOutcomeFilter::Completed,
                deferred("skip on failure"),
            )
            .expect("register completion-only callback");
        state
            .register_deferred(
                repeated_site,
                RuntimeDeferOutcomeFilter::Failed,
                deferred("newest"),
            )
            .expect("register repeated site");

        assert_eq!(
            state
                .deferred_registrations()
                .iter()
                .map(RuntimeLineDeferredRegistration::site)
                .collect::<Vec<_>>(),
            [repeated_site, defer_site(1), repeated_site]
        );
        assert_eq!(
            state.release_frame(),
            Err(LineRuntimeError::DeferredRegistrationsRemain)
        );
        state
            .begin_deferred_unwind(ScopeExit::Failed)
            .expect("fix failure exit");
        let Some(RuntimeDeferUnwindStep::Run(newest)) = state
            .prepare_next_deferred(&activation)
            .expect("prepare newest callback")
        else {
            panic!("newest callback must run")
        };
        assert_eq!(
            newest.captures(),
            [RuntimeValue::String("newest".to_owned())]
        );
        assert_eq!(
            state.prepare_next_deferred(&activation).err(),
            Some(LineRuntimeError::InvalidDeferredTransition)
        );
        assert_eq!(
            state.begin_deferred_unwind(ScopeExit::Completed),
            Err(LineRuntimeError::InvalidDeferredTransition)
        );
        assert_eq!(
            state.complete_deferred_child(
                &activation,
                completion_only,
                newest.site(),
                &std::collections::BTreeSet::new(),
            ),
            Err(LineRuntimeError::InvalidDeferredTransition)
        );
        let snapshot = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("snapshot in-flight defer identity");
        let owner = deferred_program_owner();
        let unpaired = snapshot
            .into_live(&owner)
            .expect("restore activation values");
        assert_eq!(
            unpaired.restore_admit(&activation),
            Err(LineRuntimeError::InvalidRestoredDeferredState)
        );
        assert_eq!(
            unpaired.restore_admit_with_deferred_child(
                &activation,
                Some((newest.id(), defer_site(1))),
                |_, _, _| false,
                |_, _| false,
                |_, _, _| false,
            ),
            Err(LineRuntimeError::InvalidRestoredDeferredState)
        );
        unpaired
            .restore_admit_with_deferred_child(
                &activation,
                Some((newest.id(), newest.site())),
                |_, _, _| false,
                |_, _| false,
                |_, _, _| false,
            )
            .expect("the exact saved child owner admits an in-flight activation");
        state
            .complete_deferred_child(
                &activation,
                newest.id(),
                newest.site(),
                &std::collections::BTreeSet::new(),
            )
            .expect("complete newest");
        let Some(RuntimeDeferUnwindStep::Skipped(skipped)) = state
            .prepare_next_deferred(&activation)
            .expect("skip completion-only")
        else {
            panic!("completion-only callback is skipped")
        };
        assert_eq!(skipped, completion_only);
        let Some(RuntimeDeferUnwindStep::Run(oldest)) = state
            .prepare_next_deferred(&activation)
            .expect("prepare oldest callback")
        else {
            panic!("oldest callback must run")
        };
        assert_eq!(
            oldest.captures(),
            [RuntimeValue::String("oldest".to_owned())]
        );
        state
            .complete_deferred_child(
                &activation,
                oldest.id(),
                oldest.site(),
                &std::collections::BTreeSet::new(),
            )
            .expect("complete oldest");
        assert!(
            state
                .prepare_next_deferred(&activation)
                .expect("empty stack")
                .is_none()
        );
        state.abandon().expect("close uncommitted activation");
        state.release_frame().expect("all registrations consumed");
        assert!(state.is_terminal());
    }

    #[test]
    fn skipped_line_defer_releases_its_affine_capture() {
        let activation = scheduled_activation();
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        let kind = crate::value::RuntimeHandleKind::Voice;
        let owner = crate::pattern::RuntimeOpaqueTypeOwner::exact_with(
            kind.try_producer().expect("voice producer"),
            RuntimeSemanticTypeId::from_bytes([0x8f; 32]),
            crate::value::RuntimeOpaqueValueClass::AffineHandle(kind),
            crate::value::RuntimeOpaquePersistence::SnapshotOnly,
        );
        let value = state
            .ledger
            .issue_exact(
                &activation,
                RuntimeLineHandleSiteId::from_zero_based(0),
                kind,
                &owner,
                RuntimeHandleResource::Voice(super::RuntimeVoiceLease::new(
                    crate::presentation::RuntimeVoiceSessionId::try_new("voice")
                        .expect("voice session"),
                    0,
                    false,
                )),
                RuntimeHandleOwnerSlot::LineScope,
            )
            .expect("issue line-scoped voice handle");
        let token = RuntimeLineHandleToken::try_decode_payload(value.payload())
            .expect("issued handle token");
        let id = state
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Completed,
                vec![RuntimeValue::Opaque(value)],
            )
            .expect("register captured handle");
        state
            .begin_deferred_unwind(ScopeExit::Failed)
            .expect("fix failure exit");
        let Some(RuntimeDeferUnwindStep::Skipped(skipped)) = state
            .prepare_next_deferred(&activation)
            .expect("skip nonmatching body")
        else {
            panic!("completion-only body must skip")
        };
        assert_eq!(skipped, id);
        assert_eq!(
            state.ledger.lease(&token).expect("captured lease").state(),
            RuntimeHandleLeaseState::Cancelling
        );
        assert!(state.has_pending_commands());
        assert!(state.deferred_registrations().is_empty());
    }

    #[test]
    fn deferred_unwind_snapshot_keeps_the_fixed_exit_between_registrations() {
        let activation = scheduled_activation();
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        state
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Failed,
                deferred("run after restore"),
            )
            .expect("register failure body");
        state
            .register_deferred(
                defer_site(1),
                RuntimeDeferOutcomeFilter::Completed,
                deferred("skip before snapshot"),
            )
            .expect("register completion body");
        state
            .begin_deferred_unwind(ScopeExit::Failed)
            .expect("fix failure exit");
        assert!(matches!(
            state.prepare_next_deferred(&activation).expect("skip top"),
            Some(RuntimeDeferUnwindStep::Skipped(_))
        ));
        let snapshot = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("snapshot between deferred bodies");
        let encoded = serde_json::to_vec(&snapshot).expect("encode snapshot");
        let decoded: AwbcRuntimeDialogueActivationSnapshot<AwbcTypeId> =
            serde_json::from_slice(&encoded).expect("decode snapshot");
        let mut restored = decoded
            .into_live(&deferred_program_owner())
            .expect("restore values");
        restored
            .restore_admit(&activation)
            .expect("admit fixed-exit state");
        assert_eq!(
            restored.begin_deferred_unwind(ScopeExit::Completed),
            Err(LineRuntimeError::InvalidDeferredTransition)
        );
        let Some(RuntimeDeferUnwindStep::Run(remaining)) = restored
            .prepare_next_deferred(&activation)
            .expect("resume LIFO")
        else {
            panic!("remaining failure body runs")
        };
        assert_eq!(
            remaining.captures(),
            [RuntimeValue::String("run after restore".to_owned())]
        );
    }

    #[test]
    fn line_root_defer_stack_round_trips_in_activation_snapshot_order() {
        let activation = scheduled_activation();
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        let first = state
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Always,
                deferred("first capture"),
            )
            .expect("register first callback");
        let second = state
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Cancelled,
                vec![RuntimeValue::Tuple(vec![
                    RuntimeValue::Bool(true),
                    RuntimeValue::String("nested".to_owned()),
                ])],
            )
            .expect("register same site with a distinct capture");
        assert_eq!(first.get().get(), 1);
        assert_eq!(second.get().get(), 2);
        assert_eq!(
            serde_json::to_value(state.next_defer_registration).unwrap(),
            serde_json::json!(3)
        );
        state
            .restore_admit(&activation)
            .expect("admit pending defer stack");

        let snapshot = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("snapshot deferred captures");
        let encoded = serde_json::to_vec(&snapshot).expect("serialize activation snapshot");
        let decoded: AwbcRuntimeDialogueActivationSnapshot<AwbcTypeId> =
            serde_json::from_slice(&encoded).expect("deserialize activation snapshot");
        let mut restored = decoded
            .into_live(&deferred_program_owner())
            .expect("restore captured runtime values for selected program");
        restored
            .restore_admit(&activation)
            .expect("admit restored defer stack");

        assert_eq!(restored.deferred, state.deferred);
        assert_eq!(
            restored.next_defer_registration,
            state.next_defer_registration
        );
        let third = restored
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Always,
                deferred("after restore"),
            )
            .expect("restored activation continues issuing distinct IDs");
        assert_eq!(third.get().get(), 3);
        restored
            .begin_deferred_unwind(ScopeExit::Cancelled)
            .expect("fix cancel exit");
        for expected in ["after restore", "nested", "first capture"] {
            let Some(RuntimeDeferUnwindStep::Run(registration)) = restored
                .prepare_next_deferred(&activation)
                .expect("prepare restored callback")
            else {
                panic!("all restored callbacks match")
            };
            let label = match &registration.captures()[0] {
                RuntimeValue::String(value) => value.as_str(),
                RuntimeValue::Tuple(_) => "nested",
                _ => panic!("exact captured shape"),
            };
            assert_eq!(label, expected);
            restored
                .complete_deferred_child(
                    &activation,
                    registration.id(),
                    registration.site(),
                    &std::collections::BTreeSet::new(),
                )
                .expect("complete restored callback");
        }
        assert!(
            restored
                .prepare_next_deferred(&activation)
                .expect("drained")
                .is_none()
        );
    }

    #[test]
    fn original_defer_capture_type_is_checked_before_copy_and_projection() {
        let owner = deferred_program_owner();
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        state
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Always,
                vec![RuntimeValue::Bool(true)],
            )
            .unwrap();
        assert!(matches!(
            AwbcRuntimeDialogueActivationSnapshot::from_live_for_program(&state, &owner),
            Err(crate::value::AwbcRuntimeValueSnapshotError::ProgramType(_))
        ));
        let saved = AwbcRuntimeDialogueActivationSnapshot::from_live(&state).unwrap();
        let before = serde_json::to_vec(&saved).unwrap();
        let mut admission = crate::value::RuntimeRetainedValueAdmission::for_program(
            owner.clone(),
            crate::entry::RuntimeSchemaLimits::engine_default(),
        );
        let first = saved
            .admit_retained_resources(None, &mut admission)
            .unwrap_err();
        assert!(matches!(
            first,
            crate::value::AwbcRuntimeValueSnapshotError::ProgramType(_)
        ));
        assert_eq!(
            saved
                .admit_retained_resources(None, &mut admission)
                .unwrap_err(),
            first
        );
        assert_eq!(serde_json::to_vec(&saved).unwrap(), before);
        assert!(saved.into_live(&owner).is_err());
        assert_eq!(state.deferred[0].captures(), &[RuntimeValue::Bool(true)]);
    }

    #[test]
    fn restored_defer_stack_rejects_released_frames_and_unknown_sites() {
        let activation = scheduled_activation();
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        state
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Always,
                deferred("capture"),
            )
            .expect("register callback");
        assert_eq!(
            state.validate_deferred_sites(|_| false),
            Err(LineRuntimeError::UnknownDeferredSite {
                site: defer_site(0)
            })
        );

        let mut snapshot = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("snapshot pending callback");
        snapshot.frame_released = true;
        let owner = deferred_program_owner();
        let restored = snapshot.into_live(&owner).expect("restore snapshot values");
        assert_eq!(
            restored.restore_admit(&activation),
            Err(LineRuntimeError::InvalidRestoredDeferredState)
        );

        let mut bad_sequence = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("negative fixture retains only inert captures");
        let first = bad_sequence.deferred[0].clone();
        bad_sequence.deferred.push(first);
        let bad_sequence = bad_sequence
            .into_live(&owner)
            .expect("restore inert values");
        assert_eq!(
            bad_sequence.restore_admit(&activation),
            Err(LineRuntimeError::InvalidRestoredDeferredState)
        );
        let mut bad_counter = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        bad_counter
            .register_deferred(
                defer_site(0),
                RuntimeDeferOutcomeFilter::Always,
                deferred("capture"),
            )
            .expect("register independent callback");
        bad_counter.next_defer_registration =
            crate::scope::RuntimeDeferRegistrationFrontier::initial();
        assert_eq!(
            bad_counter.restore_admit(&activation),
            Err(LineRuntimeError::InvalidRestoredDeferredState)
        );
    }

    fn scheduled_state() -> (
        DialogueActivationId,
        RuntimeDialogueActivationState<AwbcTypeId>,
    ) {
        let activation = scheduled_activation();
        let site = RuntimeLineHandleSiteId::from_zero_based(0);
        let child = RuntimeLineTaskNodeId::from_zero_based(1).expect("child");
        let action = RuntimeLineTaskNodeId::from_zero_based(2).expect("action");
        let deadline = LogicalDuration::from_nanos(7);
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        for issuance in 0..2 {
            let token = RuntimeLineHandleToken::new(activation.clone(), site, issuance);
            let work = LineTaskWorkTag::scheduled(token.clone(), action);
            state.ledger.leases.insert(
                token.clone(),
                RuntimeHandleLease {
                    token: token.clone(),
                    owner: RuntimeHandleOwnerSlot::LineScope,
                    state: RuntimeHandleLeaseState::Pending,
                    resource: RuntimeHandleResource::Cue(RuntimeCueLease::new(
                        RuntimeCueOrigin::Scheduled { child, deadline },
                    )),
                },
            );
            state.scheduled.push(
                RuntimeScheduledLineTask::new(token, child, work, deadline, Box::default())
                    .expect("scheduled packet"),
            );
        }
        state.ledger.issuance_by_site.insert(site, 2);
        (activation, state)
    }

    #[test]
    fn partial_child_slot_returns_once_and_retains_every_remaining_owner_in_snapshot() {
        let (_, mut state) = scheduled_state();
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let record = RuntimeValue::try_record(
            ["moved", "first", "second"]
                .into_iter()
                .map(|name| {
                    (
                        name.to_owned(),
                        RuntimeValue::NeedHandle(crate::tests::reusable_need(name)),
                    )
                })
                .collect(),
        )
        .unwrap();
        let packet = &mut state.scheduled[0];
        packet.custody = RuntimeScheduledCaptureCustody::Packet(Box::new([RuntimeLocalBinding {
            local,
            value: record,
        }]));
        packet.state = RuntimeScheduledState::Running;
        let bindings = packet.take_packet_for_child_fiber().unwrap();
        let mut env = crate::value::RuntimeEnv::default();
        for binding in bindings {
            env.set(binding.local, binding.value);
        }
        let read = crate::value::RuntimeLocalRead::from_admitted_place(
            local,
            crate::value::RuntimeLocalReadMode::Move,
            vec![crate::value::RuntimeRecordFieldId::try_from_zero_based_ordinal(0).unwrap()]
                .into_boxed_slice(),
        );
        assert_eq!(
            env.read(&read).unwrap(),
            RuntimeValue::NeedHandle(crate::tests::reusable_need("moved"))
        );
        let slots = env.into_slots().into_boxed_slice();
        assert_eq!(slots.len(), 1);
        assert_eq!(slots[0].storage().values().count(), 2);
        assert!(matches!(
            packet.inspect_child_fiber_bindings(
                &[slots[0].clone(), slots[0].clone()],
                RuntimeScheduledState::Completed
            ),
            Err(LineRuntimeError::InvalidScheduledCaptureTransition)
        ));
        packet
            .admit_child_fiber_bindings(slots, RuntimeScheduledState::Completed)
            .unwrap();
        assert_eq!(packet.line_scope_captures().unwrap().len(), 1);
        let owner = RuntimeProgramOwner::Awbc(std::sync::Arc::new(AwbcProgram::default()));
        let snapshot =
            AwbcRuntimeScheduledCaptureCustodySnapshot::from_live(&packet.custody, Some(&owner))
                .unwrap();
        let bytes = serde_json::to_vec(&snapshot).unwrap();
        let snapshot: AwbcRuntimeScheduledCaptureCustodySnapshot =
            serde_json::from_slice(&bytes).unwrap();
        let restored = snapshot.into_live(&owner).unwrap();
        assert_eq!(restored, packet.custody);
        assert_eq!(
            restored.values().collect::<Vec<_>>(),
            vec![
                &RuntimeValue::NeedHandle(crate::tests::reusable_need("first")),
                &RuntimeValue::NeedHandle(crate::tests::reusable_need("second")),
            ]
        );
    }

    #[test]
    fn same_site_scheduled_packets_round_trip_by_exact_token() {
        let (activation, state) = scheduled_state();
        state
            .restore_admit(&activation)
            .expect("same-site issuance tokens are distinct packets");
        let snapshot = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("snapshot exact packets");
        let owner = RuntimeProgramOwner::Awbc(std::sync::Arc::new(AwbcProgram::default()));
        let restored = snapshot.into_live(&owner).expect("restore exact packets");
        restored
            .restore_admit(&activation)
            .expect("round-trip exact packets");
        assert_eq!(restored.scheduled.len(), 2);
        assert_ne!(restored.scheduled[0].token(), restored.scheduled[1].token());
        assert!(
            restored
                .scheduled
                .iter()
                .all(|scheduled| scheduled.state() == RuntimeScheduledState::Armed)
        );
    }

    #[test]
    fn retiring_one_running_registry_cue_cancels_only_its_scheduled_lane() {
        use crate::line_task::{
            ChildCancelPolicy, ChildJoinPolicy, LineTaskCleanup, LineTaskCommand, LineTaskGroup,
            LineTaskLiveState, LineTaskNode, LineTaskReadyEvents, LineTaskTrigger,
            RuntimeLineHandleSite, RuntimeLineHandleSiteKind, complete_live_line_task_work,
            progress_live_line_task_group,
        };
        use crate::pattern::RuntimeOpaqueTypeOwner;
        use crate::presentation::RuntimeCommandQueue;
        use crate::runtime_id::{ExecutionInstanceId, RuntimePlanTypeId};
        use crate::value::ownership::{RuntimeOwnedSlotId, RuntimeValuePath};
        use crate::value::{RuntimeHandleKind, RuntimeOpaquePersistence, RuntimeOpaqueValueClass};
        use std::collections::BTreeSet;

        let (activation, mut line) = scheduled_state();
        let node = |index| RuntimeLineTaskNodeId::from_zero_based(index).unwrap();
        let ty = RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN);
        let token = line.scheduled[0].token().clone();
        let sibling = line.scheduled[1].token().clone();
        let site = RuntimeLineHandleSite::new(
            token.site(),
            0,
            RuntimeLineHandleSiteKind::ScheduledCue,
            ty,
            None,
            Some(node(1)),
            RuntimeOpaqueTypeOwner::exact_with(
                RuntimeHandleKind::Cue.try_producer().unwrap(),
                crate::pattern::RuntimeSemanticTypeId::from_bytes([0x79; 32]),
                RuntimeOpaqueValueClass::AffineHandle(RuntimeHandleKind::Cue),
                RuntimeOpaquePersistence::SnapshotOnly,
            ),
        )
        .unwrap();
        let group = LineTaskGroup::new(
            crate::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity([71; 32]),
            crate::plan::RuntimeEffectSet::empty(),
            Box::new([]),
            Box::new([]),
            Box::new([]),
            ty,
            Box::new([site]),
            node(0),
            Box::new([
                LineTaskNode::Sequence(Box::new([node(1)])),
                LineTaskNode::Child {
                    trigger: LineTaskTrigger::Scheduled(token.site()),
                    join_policy: ChildJoinPolicy::Join,
                    cancel_policy: ChildCancelPolicy::CancelAndJoin,
                    scope: node(2),
                },
                LineTaskNode::Action(Box::new([crate::plan::FlowOp::Return(String::new())])),
            ]),
            Box::new([]),
            LineTaskCleanup::default(),
        );
        let owner = RuntimeHandleOwnerSlot::LineRegistry {
            receiver: activation,
            key: arcweft_id::LifetimeRegistryKey::new(
                arcweft_id::LifetimeScopeKind::Line,
                Box::new([arcweft_id::DeclarationName::try_new("cue").unwrap()]),
            ),
            path: RuntimeValuePath::root(),
        };
        let local = RuntimeHandleOwnerSlot::ActivationLocal(RuntimeOwnedSlotId::environment_local(
            ExecutionInstanceId::from_allocated(std::num::NonZeroU64::MIN),
            RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN),
        ));
        line.ledger
            .transfer(&token, &RuntimeHandleOwnerSlot::LineScope, local.clone())
            .unwrap();
        line.ledger.transfer(&token, &local, owner.clone()).unwrap();
        let elapsed = line.scheduled[0].deadline();
        let mut reducer = LineTaskLiveState::new(&group, activation);
        let marks = BTreeSet::new();
        let events = LineTaskReadyEvents::new(&marks);
        line.advance_schedules(elapsed, &mut reducer).unwrap();
        let started = progress_live_line_task_group(&group, elapsed, events, &mut reducer).unwrap();
        assert_eq!(started.commands.len(), 2);
        for cue in [&token, &sibling] {
            assert!(line.take_scheduled_capture_packet(cue).unwrap().is_empty());
        }
        let mut queue = RuntimeCommandQueue::new(activation, line.command_sequence());
        line.ledger.drop_owned(&token, &owner, &mut queue).unwrap();
        assert!(queue.into_commands().is_empty());
        line.advance_schedules(elapsed, &mut reducer).unwrap();
        let cancelled =
            progress_live_line_task_group(&group, elapsed, events, &mut reducer).unwrap();
        let tag = LineTaskWorkTag::scheduled(token.clone(), node(2));
        assert_eq!(
            cancelled.commands,
            [LineTaskCommand::Cancel { tag: tag.clone() }]
        );

        let proof = line
            .inspect_scheduled_child_bindings(&token, &[], RuntimeScheduledState::Cancelled)
            .unwrap();
        let mut stage = line.begin_scheduled_completion_stage();
        line.stage_scheduled_child_work_completion(&mut stage, &proof, &[], false, true)
            .unwrap();
        line.admit_scheduled_child_bindings_prepared(proof, Box::new([]));
        line.commit_scheduled_completion_stage(stage);
        complete_live_line_task_work(&group, &mut reducer, tag, false).unwrap();

        assert_eq!(
            line.ledger.lease(&token).unwrap().state(),
            RuntimeHandleLeaseState::Released
        );
        assert_eq!(
            line.ledger.lease(&sibling).unwrap().state(),
            RuntimeHandleLeaseState::Running
        );
        let restored = LineTaskLiveState::restore(&group, reducer.snapshot()).unwrap();
        assert!(restored.has_outstanding());
        assert_eq!(restored.snapshot().scheduled_lanes().len(), 1);
        assert_eq!(restored.snapshot().scheduled_lanes()[0].token(), &sibling);
    }

    #[test]
    fn dialogue_snapshot_rebinds_data_shape_result_to_selected_program() {
        let value_type = RuntimeSemanticTypeId::from_bytes([0xc7; 32]);
        let shape_type = RuntimeSemanticTypeId::from_bytes([0xc8; 32]);
        let owner = RuntimeProgramOwner::Awbc(std::sync::Arc::new(AwbcProgram {
            runtime_types: vec![
                AwbcRuntimeType::new(value_type, AwbcRuntimeTypeShape::Bool),
                AwbcRuntimeType::new(
                    shape_type,
                    AwbcRuntimeTypeShape::Agent(AwbcAgentTypeShape::DataShape(AwbcTypeId(0))),
                ),
            ],
            ..AwbcProgram::default()
        }));
        let witness = RuntimeDataShape::bind(owner.clone(), shape_type)
            .expect("selected AWBC contains the DataShape row");
        let mut state = RuntimeDialogueActivationState::<AwbcTypeId>::new();
        state.result = RuntimeDialogueResultState::Committed {
            ty: AwbcTypeId(1),
            value: RuntimeValue::Agent(RuntimeAgentValue::DataShape(witness.clone())),
        };
        let activation = scheduled_activation();
        let site = RuntimeLineHandleSiteId::from_zero_based(0);
        let token = RuntimeLineHandleToken::new(activation, site, 0);
        let work = LineTaskWorkTag::scheduled(
            token.clone(),
            RuntimeLineTaskNodeId::from_zero_based(2).expect("action node"),
        );
        let scheduled = RuntimeScheduledLineTask::new(
            token,
            RuntimeLineTaskNodeId::from_zero_based(1).expect("child node"),
            work,
            LogicalDuration::from_nanos(7),
            Box::new([RuntimeLocalBinding {
                local: RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN),
                value: RuntimeValue::Agent(RuntimeAgentValue::DataShape(witness)),
            }]),
        )
        .expect("scheduled packet accepts unique capture locals");
        state.scheduled.push(scheduled);

        let snapshot = AwbcRuntimeDialogueActivationSnapshot::from_live_for_program(&state, &owner)
            .expect("DataShape result and capture snapshot their semantic identities");
        let unrelated_owner =
            RuntimeProgramOwner::Awbc(std::sync::Arc::new(AwbcProgram::default()));
        assert!(snapshot.clone().into_live(&unrelated_owner).is_err());
        let restored = snapshot
            .into_live(&owner)
            .expect("selected program rebinds the DataShape witness");
        assert_eq!(restored, state);
        let RuntimeDialogueResultState::Committed {
            value: RuntimeValue::Agent(RuntimeAgentValue::DataShape(witness)),
            ..
        } = &restored.result
        else {
            panic!("restored DataShape result")
        };

        assert!(witness.program_owner().same_program(&owner));
        assert_eq!(witness.shape_type(), shape_type);
        assert_eq!(witness.value_type(), value_type);
    }

    #[test]
    fn restore_rejects_scheduled_cue_without_its_exact_packet() {
        let (activation, mut state) = scheduled_state();
        state.scheduled.pop();
        assert_eq!(
            state.restore_admit(&activation),
            Err(LineRuntimeError::InvalidRestoredScheduledState)
        );
    }

    #[test]
    fn restore_rejects_duplicate_scheduled_packet_token() {
        let (activation, state) = scheduled_state();
        let mut state = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("negative fixture retains only inert packets");
        state.scheduled.push(state.scheduled[0].clone());
        let owner = RuntimeProgramOwner::Awbc(std::sync::Arc::new(AwbcProgram::default()));
        let state = state.into_live(&owner).expect("restore inert values");
        assert_eq!(
            state.restore_admit(&activation),
            Err(LineRuntimeError::InvalidRestoredScheduledState)
        );
    }

    #[test]
    fn failure_unwind_terminalizes_unstarted_scheduled_packets_exactly_once() {
        let (activation, mut state) = scheduled_state();
        state.abandon().expect("abandon result");

        state
            .prepare_handle_unwind(&activation, false)
            .expect("unstarted packets unwind");

        assert!(state.scheduled.iter().all(|scheduled| {
            scheduled.state() == RuntimeScheduledState::Cancelled
                && scheduled.line_scope_captures().is_ok()
        }));
        assert!(
            state
                .ledger
                .leases()
                .values()
                .all(|lease| { lease.state() == RuntimeHandleLeaseState::Released })
        );
        assert!(state.failure_close_ready());
    }

    #[test]
    fn failure_unwind_rejects_invalid_packet_without_mutation() {
        let (activation, mut state) = scheduled_state();
        let token = state.scheduled[0].token().clone();
        state
            .ledger
            .leases
            .get_mut(&token)
            .expect("fixture cue")
            .state = RuntimeHandleLeaseState::Active;
        let unchanged = AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
            .expect("inert scheduled state");

        assert!(state.prepare_handle_unwind(&activation, false).is_err());
        assert_eq!(
            AwbcRuntimeDialogueActivationSnapshot::from_live(&state)
                .expect("inert scheduled state after rejection"),
            unchanged
        );
    }
}
