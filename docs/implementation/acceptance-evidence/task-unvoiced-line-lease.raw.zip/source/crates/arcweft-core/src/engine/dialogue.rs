//! Native dialogue execution around one revisioned activation transaction.
//!
//! Pre-reveal operations, lexical cleanup, line-task progression, host-command
//! outcomes, and result publication all mutate the same activation frame and
//! line ledger. Keeping their transitions together lets each step stage a
//! complete candidate before publishing requests or child fibers; the registry
//! and shared ledger remain separate owners in `store` and `line_task`.

mod scope;
mod store;

pub use store::DialogueActivationStore;
pub(in crate::engine) use store::{
    DialogueActivationFrame, DialogueActivationScope, DialogueActivationStoreRollbackImage,
    DialogueActivationTransaction, DialogueCommitDisposition, DialogueLineTaskState,
    PendingActivationHostCall, PendingLineOperation,
};

use super::{
    DialogueExecutionStatus, DialogueRuntimePhase, Engine, RuntimeDiagnostic, RuntimeEvalError,
    RuntimeLocalBinding, RuntimeStepOutput, RuntimeValue,
};
use crate::effect::{
    LineEffectRequest, RuntimeDropPolicy, RuntimeDropPolicyExpr, RuntimeEffectExpr,
    RuntimeEffectMaterializeError,
};
use crate::line_task::{
    LineRuntimeError, LineTaskLiveState, LineTaskReadyEvents, MAX_LINE_SCHEDULED_CALLBACKS,
    RuntimeCueLease, RuntimeCueOrigin, RuntimeDeferUnwindStep, RuntimeDialogueActivationState,
    RuntimeDialogueResultState, RuntimeHandleLeaseState, RuntimeHandleOwnerSlot,
    RuntimeHandleResource, RuntimeLineHandleSiteKind, RuntimeStageActorLease, RuntimeVoiceLease,
    RuntimeVoiceLeaseAdmission, ScopeExit, progress_live_line_task_group,
};
use crate::pattern::RuntimePattern;
use crate::plan::{FlowEvent, FlowOp, RuntimeDeferOwner, RuntimeLineOperation};
use crate::presentation::{
    RuntimeCommandQueue, RuntimeDialogueVoiceState, RuntimeLineHostOutcome,
    RuntimeStageCommandOutcome, RuntimeVoiceCommandOutcome,
};
use crate::pure::RuntimeCallBackend;
use crate::runtime_id::{
    DialogueActivationId, RuntimeDeferSiteId, RuntimeLineHandleToken, RuntimePlanTypeId,
};
use crate::value::RuntimeExprKind;
use crate::value::ownership::RuntimeOwnedSlotId;
use thiserror::Error;

type NativeDialogueActivationState = RuntimeDialogueActivationState<RuntimePlanTypeId>;

enum NativeDialogueHandleTransition<'a> {
    Receive(&'a std::collections::BTreeMap<RuntimeLineHandleToken, RuntimeOwnedSlotId>),
    Result(&'a [crate::value::ownership::RuntimeAffineLineHandle]),
    Registry(&'a crate::effect::RuntimeRegistryLineChange<'a>),
}

/// Between evaluations the step owns the activation transaction. During an
/// evaluation the engine temporarily owns it and can borrow the whole contour.
struct DialogueActivationExecutionSlot(Option<DialogueActivationTransaction>);

impl DialogueActivationExecutionSlot {
    fn transaction(&self) -> &DialogueActivationTransaction {
        self.0.as_ref().expect("dialogue step owns its transaction")
    }

    fn transaction_mut(&mut self) -> &mut DialogueActivationTransaction {
        self.0.as_mut().expect("dialogue step owns its transaction")
    }
}

#[derive(Clone, Debug, Error, PartialEq)]
pub(crate) enum DialogueExecutionError {
    #[error(transparent)]
    Evaluation(#[from] RuntimeEvalError),
    #[error(transparent)]
    Pattern(#[from] crate::pattern::RuntimePatternMatchError),
    #[error(transparent)]
    Line(#[from] LineRuntimeError),
    #[error(transparent)]
    LineTaskCompletion(#[from] crate::line_task::LineTaskCompletionError),
    #[error("line-task child failed: {message}")]
    ChildFailed { message: String },
    #[error("dialogue activation host call failed: {message}")]
    HostCallFailed { message: String },
    #[error(transparent)]
    EffectMaterialization(#[from] RuntimeEffectMaterializeError),
    #[error("dialogue activation effect failed: {message}")]
    ActivationEffectFailed { message: String },
    #[error("dialogue activation execution failed: {message}")]
    ActivationExecutionFailed { message: String },
}

pub(super) struct DialogueLineTaskStart {
    pub(super) event: Option<FlowEvent>,
    pub(super) request_cancellation: bool,
    pub(super) group: crate::runtime_id::RuntimeLineTaskGroupId,
    pub(super) activation: crate::line_task::LineTaskActivation,
    pub(super) captures: Box<[RuntimeLocalBinding]>,
    pub(super) callback_sites: Vec<crate::runtime_id::RuntimeDialogueEffectSiteId>,
}

pub(super) enum DialogueActivationStep {
    Continue,
    Execution(RuntimeStepOutput),
    Reveal(DialogueLineTaskStart),
    Deferred(super::NativeLineTaskExecutionBatch),
    HostCall(Box<crate::step::RuntimeHostCallRequest>),
    Effect(LineEffectRequest),
}

enum ActivationScopeStep {
    Waiting(Option<crate::line_task::PreparedRuntimeParentFiberReconciliation>),
    Deferred(
        super::NativeLineTaskExecutionBatch,
        Option<crate::line_task::PreparedRuntimeParentFiberReconciliation>,
    ),
    Finished(Option<crate::line_task::PreparedRuntimeParentFiberReconciliation>),
}

enum DialoguePublicationOutcome {
    Pending,
    Published(crate::line_task::RuntimeDialoguePublishedCommitProof),
}

/// A borrowed view of the frames displaced while the selected fiber runs
/// dialogue code. Each transaction holds the frame that it displaced.
#[derive(Clone, Copy)]
pub(super) struct InlineDialogueExecution<'a> {
    stack: &'a [DialogueActivationTransaction],
    running: &'a super::NativeFlowExecutionFrame,
}

impl<'a> InlineDialogueExecution<'a> {
    pub(super) fn suspended_frame(self) -> Option<&'a super::NativeFlowExecutionFrame> {
        Some(&self.stack.first()?.frame().execution)
    }

    fn frame_for(
        self,
        activation: &DialogueActivationId,
    ) -> Option<&'a super::NativeFlowExecutionFrame> {
        let index = self
            .stack
            .iter()
            .position(|row| row.activation() == activation)?;
        Some(self.frame_at(index))
    }

    fn frame_at(self, index: usize) -> &'a super::NativeFlowExecutionFrame {
        self.stack
            .get(index + 1)
            .map_or(self.running, |next| &next.frame().execution)
    }

    pub(super) fn frames(
        self,
    ) -> impl DoubleEndedIterator<Item = (DialogueActivationId, &'a super::NativeFlowExecutionFrame)>
    {
        self.stack
            .iter()
            .enumerate()
            .map(move |(index, row)| (*row.activation(), self.frame_at(index)))
    }

    pub(super) fn validate_parent_allocations(
        self,
        next_fiber_id: u64,
        limits: crate::entry::RuntimeSchemaLimits,
    ) -> Result<(), String> {
        if !self.stack.is_empty() && !limits.permits_depth(self.stack.len()) {
            return Err("native inline dialogue stack exceeds the retained depth limit".into());
        }
        for (index, row) in self.stack.iter().enumerate() {
            row.validate_execution_parent(self.frame_at(index), next_fiber_id)?;
        }
        Ok(())
    }
}

impl Engine {
    pub(super) fn inline_dialogue_execution(&self) -> InlineDialogueExecution<'_> {
        InlineDialogueExecution {
            stack: &self.dialogue_activations.inline_stack,
            running: &self.fiber.frame,
        }
    }

    fn validate_inline_dialogue_entry(
        &self,
        transaction: &DialogueActivationTransaction,
    ) -> Result<(), LineRuntimeError> {
        transaction.line().line_registry()?;
        if self.fiber.id != transaction.frame().parent
            || self.fiber.persistent_id != transaction.activation().owner_fiber()
            || !self
                .fiber
                .frame
                .program
                .same_program(&transaction.frame().execution.program)
        {
            return Err(LineRuntimeError::InvalidActivationOperation);
        }
        if !crate::entry::RuntimeSchemaLimits::engine_default()
            .permits_depth(self.dialogue_activations.inline_stack.len() + 1)
        {
            return Err(LineRuntimeError::InvalidActivationOperation);
        }
        Ok(())
    }

    fn enter_inline_dialogue(&mut self, mut transaction: DialogueActivationTransaction) {
        std::mem::swap(
            &mut self.fiber.frame,
            &mut transaction.frame_mut().execution,
        );
        self.dialogue_activations.inline_stack.push(transaction);
    }

    pub(super) fn restore_inline_dialogues(
        &mut self,
        order: &[DialogueActivationId],
    ) -> Result<(), LineRuntimeError> {
        for activation in order {
            let transaction = self.dialogue_activations.begin_transaction(activation)?;
            self.validate_inline_dialogue_entry(&transaction)?;
            self.enter_inline_dialogue(transaction);
        }
        Ok(())
    }

    fn with_inline_dialogue<T>(
        &mut self,
        slot: &mut DialogueActivationExecutionSlot,
        run: impl FnOnce(&mut Self) -> T,
    ) -> Result<T, LineRuntimeError> {
        let transaction = slot.transaction();
        self.validate_inline_dialogue_entry(transaction)?;
        self.enter_inline_dialogue(slot.0.take().expect("dialogue step owns its transaction"));
        let result = run(self);
        let mut transaction = self
            .dialogue_activations
            .inline_stack
            .pop()
            .expect("inline operation retains its transaction");
        std::mem::swap(
            &mut self.fiber.frame,
            &mut transaction.frame_mut().execution,
        );
        slot.0 = Some(transaction);
        Ok(result)
    }

    pub(super) fn begin_dialogue_activation_transaction(
        &mut self,
        activation: &crate::runtime_id::DialogueActivationId,
    ) -> Result<DialogueActivationTransaction, DialogueExecutionError> {
        self.dialogue_activations
            .begin_transaction(activation)
            .map_err(Into::into)
    }

    pub(super) fn commit_dialogue_activation_transaction(
        &mut self,
        transaction: DialogueActivationTransaction,
        output: &mut RuntimeStepOutput,
    ) -> Result<(), DialogueExecutionError> {
        let receipt = self
            .dialogue_activations
            .commit_transaction(transaction)
            .map_err(DialogueExecutionError::from)?;
        Self::publish_dialogue_line_receipt(receipt.into_line(), output);
        Ok(())
    }

    fn commit_terminal_dialogue_activation_transaction(
        &mut self,
        transaction: DialogueActivationTransaction,
        proof: crate::line_task::RuntimeDialogueAbandonedCommitProof,
        output: &mut RuntimeStepOutput,
    ) -> DialogueCommitDisposition {
        let receipt = self
            .dialogue_activations
            .commit_terminal_prepared(transaction, proof);
        let (line, disposition) = receipt.into_parts();
        Self::publish_dialogue_line_receipt(line, output);
        disposition
    }

    fn commit_published_dialogue_activation_transaction(
        &mut self,
        transaction: DialogueActivationTransaction,
        proof: crate::line_task::RuntimeDialoguePublishedCommitProof,
        output: &mut RuntimeStepOutput,
    ) -> DialogueCommitDisposition {
        let receipt = self
            .dialogue_activations
            .commit_published_prepared(transaction, proof);
        let (line, disposition) = receipt.into_parts();
        Self::publish_dialogue_line_receipt(line, output);
        disposition
    }

    pub(super) fn publish_dialogue_line_receipt(
        receipt: crate::line_task::RuntimeDialogueCommitReceipt,
        output: &mut RuntimeStepOutput,
    ) {
        output
            .requests
            .line_commands
            .extend(receipt.into_commands());
    }

    fn apply_dialogue_commit_disposition(&mut self, disposition: DialogueCommitDisposition) {
        match disposition {
            DialogueCommitDisposition::Published { bindings, arrivals } => {
                if let Some(receiver) = self.dialogue_activations.inline_stack.last_mut() {
                    receiver.record_result_arrivals(arrivals);
                }
                self.fiber.frame.env.bind_all(bindings);
                self.fiber.frame.status = super::FlowFiberStatus::Running;
            }
            DialogueCommitDisposition::Failed { error } => {
                self.fiber.frame.status = super::FlowFiberStatus::Failed(error.to_string());
            }
        }
    }

    pub(super) fn commit_and_suspend_dialogue(
        &mut self,
        mut transaction: DialogueActivationTransaction,
        output: &mut RuntimeStepOutput,
        step: DialogueActivationStep,
    ) {
        let activation = transaction.activation().clone();
        let phase = transaction.frame().phase;
        let mut execution_output = None;
        let (start, deferred_batch, host_call, effect) = match step {
            DialogueActivationStep::Continue => (None, None, None, None),
            DialogueActivationStep::Execution(staged) => {
                execution_output = Some(staged);
                (None, None, None, None)
            }
            DialogueActivationStep::Reveal(start) => (Some(start), None, None, None),
            DialogueActivationStep::Deferred(batch) => (None, Some(batch), None, None),
            DialogueActivationStep::HostCall(request) => (None, None, Some(*request), None),
            DialogueActivationStep::Effect(effect) => (None, None, None, Some(effect)),
        };
        let (transaction, batch, event, commit_proof) = match start {
            Some(start) => {
                if start.group != transaction.frame().task_group {
                    self.begin_dialogue_failure(
                        transaction,
                        LineRuntimeError::InvalidActivationOperation.into(),
                        output,
                    );
                    return;
                }
                if self
                    .plan
                    .line_task_groups()
                    .get(start.group.index())
                    .is_none()
                {
                    self.begin_dialogue_failure(
                        transaction,
                        LineRuntimeError::UnknownTaskGroup.into(),
                        output,
                    );
                    return;
                }
                let commit_proof = match self
                    .dialogue_activations
                    .inspect_commit_transaction(&transaction)
                {
                    Ok(proof) => proof,
                    Err(error) => {
                        self.begin_dialogue_failure(transaction, error.into(), output);
                        return;
                    }
                };
                let run_count = start
                    .activation
                    .commands
                    .iter()
                    .filter(|command| {
                        matches!(command, crate::line_task::LineTaskCommand::Run { .. })
                    })
                    .count();
                let first_callback_ordinal = u64::try_from(run_count)
                    .ok()
                    .and_then(|count| self.next_fiber_id.checked_add(count))
                    .ok_or(RuntimeEvalError::FiberIdentityOverflow);
                let first_callback_ordinal = match first_callback_ordinal {
                    Ok(ordinal) => ordinal,
                    Err(error) => {
                        self.begin_dialogue_failure(transaction, error.into(), output);
                        return;
                    }
                };
                let prepared_callbacks = match self.inspect_dialogue_effect_callbacks(
                    &activation,
                    &transaction.frame().effect_callbacks,
                    &start.callback_sites,
                    first_callback_ordinal,
                ) {
                    Ok(prepared) => prepared,
                    Err(error) => {
                        self.begin_dialogue_failure(transaction, error.into(), output);
                        return;
                    }
                };
                let mut batch = match self.prepare_line_task_commands(
                    &mut transaction,
                    start.activation,
                    &start.captures,
                    start.request_cancellation,
                ) {
                    Ok(batch) => batch,
                    Err(error) => {
                        self.begin_dialogue_failure(transaction, error, output);
                        return;
                    }
                };
                assert_eq!(batch.next_fiber_id, first_callback_ordinal);
                let callbacks = Self::take_dialogue_effect_callbacks(
                    &mut transaction.frame_mut().effect_callbacks,
                    &start.callback_sites,
                )
                .expect("borrowed callback-site preflight remains valid");
                self.commit_dialogue_effect_callbacks(
                    transaction.frame().parent,
                    &mut batch,
                    callbacks,
                    prepared_callbacks,
                );
                (transaction, Some(batch), start.event, Some(commit_proof))
            }
            None => (transaction, None, None, None),
        };
        let committed = match commit_proof {
            Some(proof) => {
                let receipt = self
                    .dialogue_activations
                    .commit_prepared(transaction, proof);
                Self::publish_dialogue_line_receipt(receipt.into_line(), output);
                Ok(())
            }
            None => self.commit_dialogue_activation_transaction(transaction, output),
        };
        match committed {
            Ok(()) => {
                self.fiber.frame.status = super::FlowFiberStatus::Dialogue(
                    DialogueExecutionStatus::new(activation.clone(), phase),
                );
            }
            Err(error) => {
                self.fail_eval(error, output);
                return;
            }
        }
        if let Some(batch) = batch {
            self.commit_line_task_execution_batch(batch);
        }
        if let Some(batch) = deferred_batch {
            self.commit_line_task_execution_batch(batch);
        }
        if let Some(request) = host_call {
            self.advance_host_call_sequence();
            output.requests.host_calls.push(request);
        }
        if let Some(effect) = effect {
            output.effects.line.push(effect);
        }
        if let Some(event) = event {
            output.flow_events.push(event);
        }
        if let Some(staged) = execution_output {
            output.merge(staged);
        }
    }

    pub(super) fn begin_dialogue_failure(
        &mut self,
        mut transaction: DialogueActivationTransaction,
        error: DialogueExecutionError,
        output: &mut RuntimeStepOutput,
    ) {
        let state = transaction.frame_mut();
        if state.failure.is_none() {
            output
                .diagnostics
                .push(RuntimeDiagnostic::new(error.to_string()));
            state.failure = Some(error);
        }
        state.phase = DialogueRuntimePhase::Closing;
        self.request_line_task_cancellation(transaction.activation());
        self.resume_dialogue_failure_close(transaction, output);
    }

    fn prepare_dialogue_deferred_child(
        &self,
        transaction: &mut DialogueActivationTransaction,
        exit: ScopeExit,
    ) -> Result<Option<super::NativeLineTaskExecutionBatch>, DialogueExecutionError> {
        if transaction.line().deferred_exit().is_none()
            && transaction.line().deferred_registrations().is_empty()
        {
            return Ok(None);
        }
        let activation_id = transaction.activation().clone();
        let fixed_exit = transaction.line().deferred_exit().unwrap_or(exit);
        transaction.line_mut().begin_deferred_unwind(fixed_exit)?;
        if transaction.line().deferred_inflight().is_some()
            || transaction.line().has_pending_commands()
        {
            return Ok(None);
        }
        loop {
            let before = transaction
                .line()
                .deferred_registrations()
                .last()
                .map(|packet| packet.received_handle_slots(self.fiber.execution, &activation_id))
                .transpose()?
                .unwrap_or_default();
            let prepared = transaction
                .line()
                .deferred_registrations()
                .last()
                .filter(|registration| registration.outcome_filter().matches(fixed_exit))
                .map(|registration| self.inspect_deferred_line_child(registration))
                .transpose()?;
            let received = if before.is_empty() {
                None
            } else {
                let after = prepared
                    .as_ref()
                    .map(|child| child.received_handle_slots(&activation_id))
                    .unwrap_or_default();
                let mut drops = crate::line_task::RuntimeHandleDropAuthorization::default();
                if prepared.is_none() {
                    drops.authorize_tokens(before.keys().cloned())?;
                }
                Some(
                    self.dialogue_activations
                        .inspect_parent_fiber_reconciliation(
                            self.published_receiver_execution(),
                            &before,
                            &after,
                            &drops,
                        )?,
                )
            };
            let unwind = transaction.line_mut().inspect_next_deferred_with(
                &activation_id,
                fixed_exit,
                |handle, registration, ordinal| {
                    self.dialogue_activations.inspect_received_defer_capture(
                        self.published_receiver_execution(),
                        handle,
                        RuntimeOwnedSlotId::LineDeferCapture {
                            execution: self.fiber.execution,
                            activation: activation_id,
                            registration,
                            ordinal,
                        },
                    )
                },
            )?;
            let received_transition = received.is_some();
            transaction.stage_received_handles(received);
            match transaction.line_mut().commit_next_deferred_prepared(unwind) {
                Some(RuntimeDeferUnwindStep::Run(registration)) => {
                    let batch = self.commit_prepared_deferred_line_child(
                        transaction.frame().parent,
                        &activation_id,
                        registration,
                        prepared.expect("matching defer was preflighted before moving captures"),
                        super::defer::NativeDeferParent::Root,
                    );
                    return Ok(Some(batch));
                }
                Some(RuntimeDeferUnwindStep::Skipped(id)) => {
                    if received_transition {
                        return Ok(None);
                    }
                    if transaction
                        .line()
                        .deferred_registrations()
                        .last()
                        .is_some_and(|pending| pending.id() >= id)
                    {
                        return Err(LineRuntimeError::InvalidDeferredTransition.into());
                    }
                    if transaction.line().has_pending_commands() {
                        return Ok(None);
                    }
                }
                None => return Ok(None),
            }
        }
    }

    pub(super) fn resume_dialogue_failure_close(
        &mut self,
        mut transaction: DialogueActivationTransaction,
        output: &mut RuntimeStepOutput,
    ) {
        let activation_id = transaction.activation().clone();
        match self
            .dialogue_activations
            .prepare_result_abandonment(&mut transaction)
        {
            Ok(false) => {}
            Ok(true) => {
                match self.commit_dialogue_activation_transaction(transaction, output) {
                    Ok(()) => {
                        self.fiber.frame.status =
                            super::FlowFiberStatus::Dialogue(DialogueExecutionStatus::new(
                                activation_id,
                                DialogueRuntimePhase::Closing,
                            ));
                    }
                    Err(error) => self.fail_eval(error, output),
                }
                return;
            }
            Err(error) => {
                self.fail_eval(error, output);
                return;
            }
        }
        if !self.has_joined_dialogue_work(&activation_id) {
            while !transaction.frame().scopes.is_empty() {
                let (frame, line) = transaction.parts_mut();
                let step = match self.prepare_activation_scope_exit(
                    &activation_id,
                    frame,
                    line,
                    ScopeExit::Failed,
                ) {
                    Ok(step) => step,
                    Err(error) => {
                        self.fail_eval(error, output);
                        return;
                    }
                };
                match step {
                    ActivationScopeStep::Finished(None) => {}
                    ActivationScopeStep::Waiting(received)
                    | ActivationScopeStep::Finished(received) => {
                        transaction.stage_received_handles(received);
                        match self.commit_dialogue_activation_transaction(transaction, output) {
                            Ok(()) => {
                                self.fiber.frame.status =
                                    super::FlowFiberStatus::Dialogue(DialogueExecutionStatus::new(
                                        activation_id,
                                        DialogueRuntimePhase::Closing,
                                    ));
                            }
                            Err(error) => self.fail_eval(error, output),
                        }
                        return;
                    }
                    ActivationScopeStep::Deferred(batch, received) => {
                        transaction.stage_received_handles(received);
                        match self.commit_dialogue_activation_transaction(transaction, output) {
                            Ok(()) => {
                                self.fiber.frame.status =
                                    super::FlowFiberStatus::Dialogue(DialogueExecutionStatus::new(
                                        activation_id,
                                        DialogueRuntimePhase::Closing,
                                    ));
                                self.commit_line_task_execution_batch(batch);
                            }
                            Err(error) => self.fail_eval(error, output),
                        }
                        return;
                    }
                }
            }
            let batch =
                match self.prepare_dialogue_deferred_child(&mut transaction, ScopeExit::Failed) {
                    Ok(batch) => batch,
                    Err(error) => {
                        self.fail_eval(error, output);
                        return;
                    }
                };
            if let Some(batch) = batch {
                match self.commit_dialogue_activation_transaction(transaction, output) {
                    Ok(()) => {
                        self.fiber.frame.status =
                            super::FlowFiberStatus::Dialogue(DialogueExecutionStatus::new(
                                activation_id,
                                DialogueRuntimePhase::Closing,
                            ));
                        self.commit_line_task_execution_batch(batch);
                    }
                    Err(error) => self.fail_eval(error, output),
                }
                return;
            }
            let activation = transaction.line();
            if activation.deferred_inflight().is_none()
                && activation.deferred_registrations().is_empty()
                && !activation.has_pending_commands()
                && let Err(cleanup) = self.unwind_dialogue_handles(&mut transaction, false)
            {
                output.diagnostics.push(RuntimeDiagnostic::new(format!(
                    "dialogue cleanup after primary failure also failed: {cleanup}"
                )));
            }
        }
        let pending_received_release = self
            .dialogue_activations
            .has_staged_result_retirement(&transaction);
        let (state, activation) = transaction.parts_mut();
        let terminal = activation.failure_close_ready()
            && !self.has_joined_dialogue_work(&activation_id)
            && !pending_received_release;
        if terminal {
            let Some(error) = state.failure.clone() else {
                self.fail_eval(LineRuntimeError::InvalidResultTransition, output);
                return;
            };
            if let Err(error) =
                transaction.stage_disposition(DialogueCommitDisposition::Failed { error })
            {
                self.fail_eval(error, output);
                return;
            }
            let proof = match self
                .dialogue_activations
                .inspect_terminal_transaction(&transaction)
            {
                Ok(proof) => proof,
                Err(error) => {
                    self.dialogue_activations
                        .restore_rejected_transaction(transaction)
                        .expect("rejected sole dialogue transaction restores its owner");
                    self.fail_eval(error, output);
                    return;
                }
            };
            transaction
                .line_mut()
                .release_frame()
                .expect("prepared terminal close permits frame release");
            let disposition =
                self.commit_terminal_dialogue_activation_transaction(transaction, proof, output);
            self.apply_dialogue_commit_disposition(disposition);
        } else {
            let activation = transaction.activation().clone();
            let phase = transaction.frame().phase;
            match self.commit_dialogue_activation_transaction(transaction, output) {
                Ok(()) => {
                    self.fiber.frame.status = super::FlowFiberStatus::Dialogue(
                        DialogueExecutionStatus::new(activation, phase),
                    );
                }
                Err(error) => self.fail_eval(error, output),
            }
        }
    }

    pub(super) fn resume_dialogue_successful_close(
        &mut self,
        mut transaction: DialogueActivationTransaction,
        output: &mut RuntimeStepOutput,
    ) {
        let activation_id = transaction.activation().clone();
        transaction.frame_mut().phase = DialogueRuntimePhase::Closing;
        let mut staged_registry_release = false;
        if !self.has_joined_dialogue_work(&activation_id) {
            let Some(exit) = transaction.frame().line_task.closed_exit() else {
                self.begin_dialogue_failure(
                    transaction,
                    LineRuntimeError::InvalidDeferredTransition.into(),
                    output,
                );
                return;
            };
            let batch = match self.prepare_dialogue_deferred_child(&mut transaction, exit) {
                Ok(batch) => batch,
                Err(error) => {
                    self.begin_dialogue_failure(transaction, error, output);
                    return;
                }
            };
            if let Some(batch) = batch {
                match self.commit_dialogue_activation_transaction(transaction, output) {
                    Ok(()) => {
                        self.fiber.frame.status =
                            super::FlowFiberStatus::Dialogue(DialogueExecutionStatus::new(
                                activation_id,
                                DialogueRuntimePhase::Closing,
                            ));
                        self.commit_line_task_execution_batch(batch);
                    }
                    Err(error) => self.fail_eval(error, output),
                }
                return;
            }
            let activation = transaction.line();
            if activation.deferred_inflight().is_none()
                && activation.deferred_registrations().is_empty()
                && !activation.has_pending_commands()
            {
                match self.unwind_dialogue_handles(&mut transaction, true) {
                    Ok(staged) => staged_registry_release = staged,
                    Err(error) => {
                        self.begin_dialogue_failure(transaction, error, output);
                        return;
                    }
                }
            }
        }
        let activation = transaction.line();
        let terminal = activation.successful_close_ready()
            && !staged_registry_release
            && !self.has_joined_dialogue_work(&activation_id)
            && !self
                .dialogue_activations
                .has_staged_result_retirement(&transaction);
        if terminal {
            self.resume_dialogue_publication_with_transaction(transaction, output);
        } else {
            let activation = transaction.activation().clone();
            let phase = transaction.frame().phase;
            match self.commit_dialogue_activation_transaction(transaction, output) {
                Ok(()) => {
                    self.fiber.frame.status = super::FlowFiberStatus::Dialogue(
                        DialogueExecutionStatus::new(activation, phase),
                    );
                }
                Err(error) => self.fail_eval(error, output),
            }
        }
    }

    fn unwind_dialogue_handles(
        &self,
        transaction: &mut DialogueActivationTransaction,
        preserve_result: bool,
    ) -> Result<bool, DialogueExecutionError> {
        let received = self
            .dialogue_activations
            .retire_line_registry(transaction, self.fiber.execution)?;
        let staged = received.is_some();
        transaction.stage_received_handles(received);
        let activation_id = *transaction.activation();
        transaction
            .line_mut()
            .prepare_handle_unwind(&activation_id, preserve_result)?;
        Ok(staged)
    }

    pub(super) fn consume_dialogue_host_outcomes(
        &mut self,
        transaction: &mut DialogueActivationTransaction,
        outcomes: &[RuntimeLineHostOutcome],
    ) -> Result<(), DialogueExecutionError> {
        let activation_id = transaction.activation().clone();
        let (state, activation) = transaction.parts_mut();
        let mut ledger = activation.ledger().clone();
        let pending = pending_command_id(state).cloned();
        let mut outcome_error = None;
        for outcome in outcomes {
            let command_id = outcome.command();
            if command_id.activation() != &activation_id {
                return Err(LineRuntimeError::StaleCommandOutcome.into());
            }
            if state.phase == DialogueRuntimePhase::Activating
                && pending
                    .as_ref()
                    .is_some_and(|pending| pending == command_id)
            {
                continue;
            }
            let Some(command) = activation.issued_command(command_id).cloned() else {
                if activation.is_resolved(command_id) {
                    return Err(LineRuntimeError::DuplicateCommandOutcome.into());
                }
                let Some(command) = activation.superseded_command(command_id).cloned() else {
                    return Err(LineRuntimeError::UnknownCommandOutcome.into());
                };
                match (&command, outcome) {
                    (
                        crate::presentation::RuntimeLineHostCommand::Stage(
                            crate::presentation::RuntimeStageCommand::SetCharacterLook {
                                cue, ..
                            },
                        ),
                        RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Accepted {
                            cue: echoed,
                            ..
                        }),
                    ) if cue == echoed => continue,
                    (
                        crate::presentation::RuntimeLineHostCommand::Stage(
                            crate::presentation::RuntimeStageCommand::SetCharacterLook {
                                cue, ..
                            },
                        ),
                        RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Completed {
                            cue: echoed,
                            ..
                        }),
                    ) if cue == echoed => {
                        ledger.set_state(
                            cue,
                            RuntimeHandleLeaseState::Cancelling,
                            RuntimeHandleLeaseState::Released,
                        )?;
                        let _ = activation.resolve_superseded(command_id);
                        activation.resolve_issued_cancel_for_cue(cue);
                        continue;
                    }
                    (
                        crate::presentation::RuntimeLineHostCommand::Stage(
                            crate::presentation::RuntimeStageCommand::SetCharacterLook {
                                cue, ..
                            },
                        ),
                        RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Rejected {
                            ..
                        }),
                    ) => {
                        ledger.set_state(
                            cue,
                            RuntimeHandleLeaseState::Cancelling,
                            RuntimeHandleLeaseState::Released,
                        )?;
                        let _ = activation.resolve_superseded(command_id);
                        activation.resolve_issued_cancel_for_cue(cue);
                        continue;
                    }
                    _ => return Err(LineRuntimeError::StageOutcomeMismatch.into()),
                }
            };
            let mut terminal = false;
            match (&command, outcome) {
                (
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::AcquireActor { actor, .. },
                    ),
                    RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Acquired {
                        actor: echoed,
                        ..
                    }),
                ) if actor == echoed => {
                    ledger.set_state(
                        actor,
                        RuntimeHandleLeaseState::Allocating,
                        RuntimeHandleLeaseState::Active,
                    )?;
                    terminal = true;
                    clear_pending_command(state, command_id);
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. },
                    ),
                    RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Accepted {
                        cue: echoed,
                        ..
                    }),
                ) if cue == echoed => {
                    let lease = ledger.lease(cue).ok_or(LineRuntimeError::UnknownHandle)?;
                    if lease.state() == RuntimeHandleLeaseState::Pending {
                        ledger.set_state(
                            cue,
                            RuntimeHandleLeaseState::Pending,
                            RuntimeHandleLeaseState::Running,
                        )?;
                    } else if lease.state() != RuntimeHandleLeaseState::Running {
                        return Err(LineRuntimeError::StageOutcomeMismatch.into());
                    }
                    clear_pending_command(state, command_id);
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. },
                    ),
                    RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Completed {
                        cue: echoed,
                        ..
                    }),
                ) if cue == echoed => {
                    ledger.set_state(
                        cue,
                        RuntimeHandleLeaseState::Running,
                        RuntimeHandleLeaseState::Completed,
                    )?;
                    activation.resolve_superseded_cue(cue);
                    terminal = true;
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::CancelCue { cue, .. },
                    ),
                    RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Cancelled {
                        cue: echoed,
                        ..
                    }),
                ) if cue == echoed => {
                    ledger.set_state(
                        cue,
                        RuntimeHandleLeaseState::Cancelling,
                        RuntimeHandleLeaseState::Cancelled,
                    )?;
                    ledger.set_state(
                        cue,
                        RuntimeHandleLeaseState::Cancelled,
                        RuntimeHandleLeaseState::Released,
                    )?;
                    terminal = true;
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. },
                    ),
                    RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::ReleasedActor {
                        actor: echoed,
                        ..
                    }),
                ) if actor == echoed => {
                    ledger.set_state(
                        actor,
                        RuntimeHandleLeaseState::Cancelling,
                        RuntimeHandleLeaseState::Released,
                    )?;
                    terminal = true;
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Voice(
                        crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice {
                            handle,
                            ..
                        },
                    ),
                    RuntimeLineHostOutcome::Voice(RuntimeVoiceCommandOutcome::Released {
                        handle: echoed,
                        ..
                    }),
                ) if handle == echoed => {
                    ledger.set_state(
                        handle,
                        RuntimeHandleLeaseState::Cancelling,
                        RuntimeHandleLeaseState::Released,
                    )?;
                    terminal = true;
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Voice(
                        crate::presentation::RuntimeVoiceCommand::StartDialogueVoice { .. },
                    ),
                    RuntimeLineHostOutcome::Voice(RuntimeVoiceCommandOutcome::Started {
                        session,
                        ..
                    }),
                ) => {
                    if state.phase == DialogueRuntimePhase::Closing {
                        let Some(PendingLineOperation::StartVoice {
                            command: pending,
                            site,
                            ..
                        }) = state.pending_line_operation.as_ref()
                        else {
                            return Err(LineRuntimeError::StageOutcomeMismatch.into());
                        };
                        if pending != command_id {
                            return Err(LineRuntimeError::StageOutcomeMismatch.into());
                        }
                        let site = self
                            .plan
                            .line_task_groups()
                            .get(state.task_group.index())
                            .and_then(|group| group.handle_site(*site))
                            .cloned()
                            .ok_or(LineRuntimeError::InvalidHandleSite)?;
                        if site.site_kind() != RuntimeLineHandleSiteKind::Voice {
                            return Err(LineRuntimeError::InvalidHandleSite.into());
                        }
                        let ordinal = ledger.next_voice_lease_ordinal()?;
                        let _ = ledger.issue(
                            &activation_id,
                            &site,
                            RuntimeHandleResource::Voice(RuntimeVoiceLease::new(
                                session.clone(),
                                ordinal,
                                true,
                            )),
                            RuntimeHandleOwnerSlot::LineScope,
                        )?;
                    }
                    state.voice = RuntimeDialogueVoiceState::Ready(session.clone());
                    terminal = true;
                    clear_pending_command(state, command_id);
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Stage(_),
                    RuntimeLineHostOutcome::Stage(RuntimeStageCommandOutcome::Rejected {
                        code,
                        ..
                    }),
                ) => {
                    fail_issued_command_lease(&mut ledger, &command)?;
                    if let crate::presentation::RuntimeLineHostCommand::Stage(
                        crate::presentation::RuntimeStageCommand::CancelCue { cue, .. },
                    ) = &command
                    {
                        activation.resolve_superseded_cue(cue);
                    }
                    clear_pending_command(state, command_id);
                    activation.consume_issued_command(command_id)?;
                    outcome_error =
                        Some(LineRuntimeError::StageCommandRejected { code: *code }.into());
                    break;
                }
                (
                    crate::presentation::RuntimeLineHostCommand::Voice(_),
                    RuntimeLineHostOutcome::Voice(RuntimeVoiceCommandOutcome::Rejected {
                        failure,
                        ..
                    }),
                ) => {
                    fail_issued_command_lease(&mut ledger, &command)?;
                    state.voice = RuntimeDialogueVoiceState::Failed(failure.clone());
                    clear_pending_command(state, command_id);
                    activation.consume_issued_command(command_id)?;
                    outcome_error = Some(
                        LineRuntimeError::VoiceStartRejected {
                            failure: failure.clone(),
                        }
                        .into(),
                    );
                    break;
                }
                _ => return Err(LineRuntimeError::StageOutcomeMismatch.into()),
            }
            if terminal {
                activation.consume_issued_command(command_id)?;
            }
        }
        activation.commit_ledger(ledger);
        match outcome_error {
            Some(error) => Err(error),
            None => Ok(()),
        }
    }

    pub(super) fn resume_dialogue_activation(
        &mut self,
        transaction: DialogueActivationTransaction,
        outcomes: &[RuntimeLineHostOutcome],
        input: &mut super::RuntimeStepInput,
        events: &[super::TaskEvent],
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> (
        DialogueActivationTransaction,
        Result<DialogueActivationStep, DialogueExecutionError>,
    ) {
        let mut slot = DialogueActivationExecutionSlot(Some(transaction));
        let result = self.resume_dialogue_activation_in_slot(
            &mut slot,
            outcomes,
            input,
            events,
            pure_backend,
        );
        (
            slot.0.expect("dialogue step returns its transaction"),
            result,
        )
    }

    fn resume_dialogue_activation_in_slot(
        &mut self,
        slot: &mut DialogueActivationExecutionSlot,
        outcomes: &[RuntimeLineHostOutcome],
        input: &mut super::RuntimeStepInput,
        events: &[super::TaskEvent],
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<DialogueActivationStep, DialogueExecutionError> {
        let transaction = slot.transaction_mut();
        let activation_id = transaction.activation().clone();
        let (frame, activation) = transaction.parts_mut();
        if !frame.execution.pending_ops.is_empty()
            || !frame.execution.control_stack.is_empty()
            || !matches!(frame.execution.status, super::FlowFiberStatus::Running)
        {
            let next_is_registry_write = matches!(
                frame.execution.status,
                super::FlowFiberStatus::Running
            ) && matches!(
                frame.execution.original_operation_remainder(&self.plan).and_then(|ops| ops.first()),
                Some(FlowOp::EvaluatedEffect(effect))
                    if effect.registry_mutation_key().is_some_and(|key| matches!(
                        key.scope(), arcweft_id::LifetimeScopeKind::Line | arcweft_id::LifetimeScopeKind::Flow))
            );
            if next_is_registry_write {
                return self.execute_queued_activation_registry_mutation(
                    slot,
                    input,
                    events,
                    pure_backend,
                );
            }
            let before = self.activation_local_handle_owners(&activation_id, frame, activation)?;
            let staged =
                self.step_dialogue_execution(slot, None, input, events, pure_backend, None)?;
            let arrivals = slot.transaction_mut().take_result_arrivals();
            let transition = (!arrivals.is_empty())
                .then_some(NativeDialogueHandleTransition::Receive(&arrivals));
            self.reconcile_activation_instruction(slot.transaction_mut(), &before, transition)?;
            return Ok(DialogueActivationStep::Execution(staged));
        }
        if frame.pending_line_operation.is_some() {
            match self.resume_pending_line_operation(&activation_id, frame, activation, outcomes) {
                Ok(true) => advance_activation_pc(frame)?,
                Ok(false) => {}
                Err(error) => return Err(error),
            }
            return Ok(DialogueActivationStep::Continue);
        }
        if let Some(pending) = frame.pending_host_call.clone() {
            let Some(index) = input
                .host_call_results
                .iter()
                .position(|result| result.id == pending.id)
            else {
                return Ok(DialogueActivationStep::Continue);
            };
            let result = input.host_call_results.remove(index);
            let value = result
                .outcome
                .map_err(|error| DialogueExecutionError::HostCallFailed {
                    message: error.message,
                })?;
            self.plan
                .validate_live_value(
                    pending.result,
                    value.value(),
                    crate::entry::RuntimeSchemaLimits::engine_default(),
                )
                .map_err(|error| DialogueExecutionError::HostCallFailed {
                    message: error.to_string(),
                })?;
            if !unique_affine_line_handles(value.value())?.is_empty() {
                return Err(LineRuntimeError::InvalidActivationOperation.into());
            }
            if let Some(binding) = &pending.binding {
                let bindings = crate::pattern::match_runtime_pattern_owned(
                    &self.plan,
                    binding,
                    value.into_value(),
                    self.fiber.frame.env.function_instantiation(),
                )?
                .ok_or_else(|| RuntimeEvalError::PatternMismatch("host result".to_owned()))?;
                frame.execution.env.bind_all(bindings);
            }
            frame.pending_host_call = None;
            advance_activation_pc(frame)?;
            return Ok(DialogueActivationStep::Continue);
        }
        let activation_exhausted = !frame.exiting_for_result
            && self
                .plan
                .line_task_groups()
                .get(frame.task_group.index())
                .is_some_and(|group| frame.activation_pc == group.activation_ops().len());
        if frame.exiting_for_result || activation_exhausted {
            if !frame.scopes.is_empty() {
                let step = self.prepare_activation_scope_exit(
                    &activation_id,
                    frame,
                    activation,
                    ScopeExit::Completed,
                )?;
                return match step {
                    ActivationScopeStep::Waiting(received) => {
                        slot.transaction_mut().stage_received_handles(received);
                        Ok(DialogueActivationStep::Continue)
                    }
                    ActivationScopeStep::Finished(received) => {
                        slot.transaction_mut().stage_received_handles(received);
                        Ok(DialogueActivationStep::Continue)
                    }
                    ActivationScopeStep::Deferred(batch, received) => {
                        slot.transaction_mut().stage_received_handles(received);
                        Ok(DialogueActivationStep::Deferred(batch))
                    }
                };
            }
            if activation.has_pending_commands() {
                return Ok(DialogueActivationStep::Continue);
            }
            return self
                .begin_dialogue_reveal(&activation_id, frame, activation)
                .map(DialogueActivationStep::Reveal);
        }
        let plan = std::sync::Arc::clone(&self.plan);
        let group = plan
            .line_task_groups()
            .get(frame.task_group.index())
            .ok_or(LineRuntimeError::UnknownTaskGroup)?;
        let operation = group
            .activation_ops()
            .get(frame.activation_pc)
            .ok_or(LineRuntimeError::ResultNotCommitted)?;
        if let FlowOp::EvaluatedEffect(effect) = operation
            && let Some(key) = effect.registry_mutation_key()
        {
            return self.execute_activation_registry_mutation(
                slot,
                group.effects(),
                key,
                effect,
                pure_backend,
            );
        }
        let assignment_before =
            self.activation_local_handle_owners(&activation_id, frame, activation)?;
        match operation {
            FlowOp::EnterScope { identity } => {
                frame
                    .execution
                    .env
                    .push_scope_with_identity(identity.clone());
                frame.scopes.push(DialogueActivationScope::new());
            }
            FlowOp::ExitScope => {
                let step = self.prepare_activation_scope_exit(
                    &activation_id,
                    frame,
                    activation,
                    ScopeExit::Completed,
                )?;
                return match step {
                    ActivationScopeStep::Waiting(received) => {
                        slot.transaction_mut().stage_received_handles(received);
                        Ok(DialogueActivationStep::Continue)
                    }
                    ActivationScopeStep::Deferred(batch, received) => {
                        slot.transaction_mut().stage_received_handles(received);
                        Ok(DialogueActivationStep::Deferred(batch))
                    }
                    ActivationScopeStep::Finished(received) => {
                        advance_activation_pc(frame)?;
                        slot.transaction_mut().stage_received_handles(received);
                        Ok(DialogueActivationStep::Continue)
                    }
                };
            }
            FlowOp::ExitScopeBind { pattern, expr } => {
                return self.execute_activation_scope_binding(
                    slot,
                    pattern,
                    expr,
                    &assignment_before,
                    pure_backend,
                );
            }
            FlowOp::Let { pattern, expr } => {
                self.bind_dialogue_let(
                    &activation_id,
                    slot,
                    pattern,
                    expr,
                    &assignment_before,
                    pure_backend,
                )?;
            }
            FlowOp::HostCall { binding, target } => {
                let (args, named_args) = self
                    .with_inline_dialogue(slot, |this| {
                        this.evaluate_host_call_arguments(&target.args, pure_backend)
                    })?
                    .map_err(|message| DialogueExecutionError::HostCallFailed { message })?;
                let frame = slot.transaction_mut().frame_mut();
                for value in args
                    .iter()
                    .chain(named_args.iter().map(|argument| &argument.value))
                {
                    if !unique_affine_line_handles(value.value())?.is_empty() {
                        return Err(LineRuntimeError::InvalidActivationOperation.into());
                    }
                }
                let result = self
                    .plan
                    .type_table()
                    .get(target.result)
                    .map(|declaration| declaration.semantic_identity())
                    .ok_or(LineRuntimeError::InvalidActivationOperation)?;
                let id = self.preview_host_call_id(&target.public_id);
                frame.pending_host_call = Some(PendingActivationHostCall {
                    id: id.clone(),
                    result: target.result,
                    binding: binding.clone(),
                });
                self.reconcile_activation_instruction(
                    slot.transaction_mut(),
                    &assignment_before,
                    None,
                )?;
                return Ok(DialogueActivationStep::HostCall(Box::new(
                    target
                        .producer
                        .sealed_definition()
                        .and_then(|producer| {
                            crate::step::RuntimeHostCallRequest::admit(
                                id,
                                producer,
                                self.generation,
                                crate::task::HostTaskRequest::Custom {
                                    capability: crate::task::HostCapabilityId(
                                        target.capability.clone(),
                                    ),
                                    operation: target.operation.clone(),
                                    manifest_contract: target.contract,
                                    args,
                                    named_args,
                                },
                                result,
                                target.mode,
                                target.deterministic,
                                &mut self.need_producers,
                            )
                        })
                        .map_err(|error| DialogueExecutionError::HostCallFailed {
                            message: error.to_string(),
                        })?,
                )));
            }
            FlowOp::LineOperation { binding, operation } => {
                self.execute_line_operation(
                    &activation_id,
                    slot,
                    binding.clone(),
                    operation.clone(),
                    pure_backend,
                )?;
            }
            FlowOp::CommitDialogueResult { value } => {
                let rollback = if assignment_before
                    .keys()
                    .any(|token| token.activation() != &activation_id)
                {
                    Some(
                        self.inert_rollback_image_with_dialogue(
                            Some(slot.transaction()),
                            crate::entry::RuntimeSchemaLimits::engine_default(),
                        )
                        .map_err(
                            |message| DialogueExecutionError::ActivationExecutionFailed { message },
                        )?
                        .0,
                    )
                } else {
                    None
                };
                let result = (|| {
                    let value = self.evaluate_dialogue_expr(slot, value, pure_backend)?;
                    let transaction = slot.transaction_mut();
                    let (frame, activation) = transaction.parts_mut();
                    let handles =
                        self.stage_dialogue_result(&activation_id, frame, activation, value)?;
                    frame.exiting_for_result = true;
                    self.reconcile_activation_instruction(
                        transaction,
                        &assignment_before,
                        Some(NativeDialogueHandleTransition::Result(&handles)),
                    )?;
                    advance_activation_pc(transaction.frame_mut())?;
                    Ok(DialogueActivationStep::Continue)
                })();
                return match (result, rollback) {
                    (Err(cause), Some(image)) => {
                        let owner = crate::task::RuntimeProgramOwner::Plan(self.plan.clone());
                        Err(self.restore_failed_dialogue_instruction(
                            slot.transaction_mut(),
                            image,
                            &owner,
                            cause,
                        ))
                    }
                    (result, _) => result,
                };
            }
            FlowOp::EvaluatedEffect(effect) => {
                let request = self.execute_dialogue_evaluated_effect(
                    &activation_id,
                    slot,
                    effect,
                    pure_backend,
                )?;
                if let Some(request) = request {
                    let request = match request {
                        LineEffectRequest::Panic(message)
                        | LineEffectRequest::Fail(message)
                        | LineEffectRequest::Bail(message) => {
                            return Err(DialogueExecutionError::ActivationEffectFailed { message });
                        }
                        request => request,
                    };
                    self.reconcile_activation_instruction(
                        slot.transaction_mut(),
                        &assignment_before,
                        None,
                    )?;
                    advance_activation_pc(slot.transaction_mut().frame_mut())?;
                    return Ok(DialogueActivationStep::Effect(request));
                }
            }
            FlowOp::RegisterDefer {
                site,
                outcome,
                captures,
                owner,
            } => {
                self.register_dialogue_defer(frame, activation, *site, *outcome, captures, *owner)?;
            }
            operation => {
                let mut position = super::NativeCodeCursor::root(
                    &plan,
                    crate::plan::code::RuntimeCodeOwner::LineTask {
                        group: frame.task_group,
                        body: crate::plan::code::RuntimeLineCodeBody::Activation,
                    },
                )
                .ok_or(LineRuntimeError::InvalidActivationOperation)?;
                if !position.set_operation(frame.activation_pc) {
                    return Err(LineRuntimeError::InvalidActivationOperation.into());
                }
                let source = position
                    .source_operation(&plan)
                    .ok_or(LineRuntimeError::InvalidActivationOperation)?;
                let staged = self.step_dialogue_execution(
                    slot,
                    Some((operation, source)),
                    input,
                    events,
                    pure_backend,
                    None,
                )?;
                self.reconcile_activation_instruction(
                    slot.transaction_mut(),
                    &assignment_before,
                    None,
                )?;
                advance_activation_pc(slot.transaction_mut().frame_mut())?;
                return Ok(DialogueActivationStep::Execution(staged));
            }
        }
        self.reconcile_activation_instruction(slot.transaction_mut(), &assignment_before, None)?;
        let frame = slot.transaction_mut().frame_mut();
        if frame.pending_line_operation.is_none() {
            advance_activation_pc(frame)?;
        }
        Ok(DialogueActivationStep::Continue)
    }

    /// Runs one ordinary opcode or resumes one suspension in the activation's
    /// owned frame. All direct/value/default calls use the ordinary invocation
    /// stack; the enclosing dialogue continuation remains suspended.
    fn step_dialogue_execution(
        &mut self,
        slot: &mut DialogueActivationExecutionSlot,
        operation: Option<(&FlowOp, super::code_cursor::NativeSourceOperation)>,
        input: &mut super::RuntimeStepInput,
        events: &[super::TaskEvent],
        pure_backend: &mut impl RuntimeCallBackend,
        line_registry: Option<super::registry::NativeActivationRegistryExecution<'_>>,
    ) -> Result<RuntimeStepOutput, DialogueExecutionError> {
        let mut staged = RuntimeStepOutput::default();
        let mut drop_policy = None;
        self.with_inline_dialogue(slot, |this| {
            let line_registry =
                line_registry.map(super::registry::NativeLineRegistryExecution::Activation);
            if let Some((operation, source)) = operation {
                this.execute_flow_operation(
                    std::borrow::Cow::Borrowed(operation),
                    source,
                    None,
                    &mut staged,
                    pure_backend,
                    &mut drop_policy,
                    line_registry,
                );
            } else if !this.resume_suspended(input, events, &mut staged, pure_backend) {
                this.step_flow_with_line_registry(
                    &mut staged,
                    pure_backend,
                    &mut drop_policy,
                    line_registry,
                );
            }
        })?;
        let frame = slot.transaction_mut().frame_mut();
        frame
            .execution
            .env
            .set_assignment_discard_boundary(drop_policy)?;
        match &frame.execution.status {
            super::FlowFiberStatus::Failed(message) => {
                Err(DialogueExecutionError::ActivationExecutionFailed {
                    message: message.clone(),
                })
            }
            super::FlowFiberStatus::Done(_) => {
                Err(LineRuntimeError::InvalidActivationOperation.into())
            }
            _ => Ok(staged),
        }
    }

    fn activation_local_handle_owners(
        &self,
        activation: &DialogueActivationId,
        frame: &DialogueActivationFrame,
        line: &NativeDialogueActivationState,
    ) -> Result<
        std::collections::BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        DialogueExecutionError,
    > {
        let mut owners = std::collections::BTreeMap::new();
        for (token, slot) in line.received_defer_slots(self.fiber.execution, activation)? {
            owners.insert(
                token,
                RuntimeHandleOwnerSlot::parent_fiber(self.published_receiver_execution(), slot),
            );
        }
        for (token, slot) in frame.received_scoped_defer_slots(self.fiber.execution, activation)? {
            if owners
                .insert(
                    token,
                    RuntimeHandleOwnerSlot::parent_fiber(self.published_receiver_execution(), slot),
                )
                .is_some()
            {
                return Err(LineRuntimeError::DuplicateHandleOccurrence.into());
            }
        }
        for (local, value) in frame.execution.env.bindings() {
            let slot = frame
                .execution
                .owned_local_slot(self.fiber.execution, local);
            for handle in unique_affine_line_handles(value)? {
                let owner = RuntimeHandleOwnerSlot::in_dialogue_fiber(
                    self.published_receiver_execution(),
                    activation,
                    handle.token(),
                    slot,
                );
                if owners.insert(handle.token().clone(), owner).is_some() {
                    return Err(LineRuntimeError::DuplicateHandleOccurrence.into());
                }
            }
        }
        for (token, slot) in frame.scope_result_handle_slots(self.fiber.execution, activation)? {
            let owner = RuntimeHandleOwnerSlot::in_dialogue_fiber(
                self.published_receiver_execution(),
                activation,
                &token,
                slot,
            );
            if owners.insert(token, owner).is_some() {
                return Err(LineRuntimeError::DuplicateHandleOccurrence.into());
            }
        }
        Ok(owners)
    }

    fn reconcile_activation_instruction(
        &self,
        transaction: &mut DialogueActivationTransaction,
        before: &std::collections::BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        transition: Option<NativeDialogueHandleTransition<'_>>,
    ) -> Result<(), DialogueExecutionError> {
        let id = *transaction.activation();
        let (frame, line) = transaction.parts_mut();
        let received =
            self.commit_activation_assignment_discards(&id, frame, line, before, transition)?;
        transaction.stage_received_handles(received);
        Ok(())
    }

    fn commit_activation_assignment_discards(
        &self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        frame: &mut DialogueActivationFrame,
        activation: &mut NativeDialogueActivationState,
        before: &std::collections::BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        transition: Option<NativeDialogueHandleTransition<'_>>,
    ) -> Result<
        Option<crate::line_task::PreparedRuntimeParentFiberReconciliation>,
        DialogueExecutionError,
    > {
        let mut drops = frame.execution.env.take_assignment_discard_authorization();
        let mut after = self.activation_local_handle_owners(activation_id, frame, activation)?;
        if !drops.has_displaced_values() && before == &after && transition.is_none() {
            return Ok(None);
        }
        let mut before_registry;
        let (arrivals, result, before) = match transition {
            Some(NativeDialogueHandleTransition::Receive(arrivals)) => {
                (Some(arrivals), None, before)
            }
            Some(NativeDialogueHandleTransition::Result(handles)) => {
                (None, Some((activation_id, handles)), before)
            }
            Some(NativeDialogueHandleTransition::Registry(change)) => {
                before_registry = before.clone();
                change.merge_receiver_custody(
                    *activation_id,
                    &mut before_registry,
                    &mut after,
                    &mut drops,
                    |handle, source| {
                        self.dialogue_activations.validate_registry_handle(
                            activation_id,
                            activation.ledger(),
                            handle,
                            source,
                        )
                    },
                )?;
                (None, None, &before_registry)
            }
            None => (None, None, before),
        };
        drops.validate_removed(
            |token| before.contains_key(token),
            |token| after.contains_key(token),
        )?;
        let received = self
            .dialogue_activations
            .inspect_received_fiber_reconciliation(
                self.published_receiver_execution(),
                before,
                &after,
                &drops,
                arrivals,
                result,
            )?;
        let mut ledger = activation.ledger().clone();
        let mut commands =
            RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
        for (token, destination) in &after {
            if token.activation() != activation_id {
                continue;
            }
            let Some(source) = before.get(token) else {
                continue;
            };
            if source != destination {
                let current = ledger
                    .lease(token)
                    .ok_or(LineRuntimeError::UnknownHandle)?
                    .owner();
                if current == source {
                    ledger.transfer(token, source, destination.clone())?;
                } else if current != destination {
                    return Err(LineRuntimeError::WrongOwner.into());
                }
            }
        }
        for token in drops.displaced_tokens() {
            if token.activation() != activation_id {
                continue;
            }
            let owner = before
                .get(token)
                .ok_or(LineRuntimeError::UnjournaledHandleDrop)?;
            let policy = drops
                .policy_for(token)
                .ok_or(LineRuntimeError::UnjournaledHandleDrop)?;
            ledger.drop_owned_with_policy(token, owner, policy, &mut commands)?;
        }
        flush_commands(activation_id, activation, commands)?;
        activation.commit_ledger(ledger);
        Ok(received)
    }

    /// Captures the exact reached defer site without executing its body.
    /// Affine locals move only after the complete capture/ledger preflight.
    fn register_dialogue_defer(
        &mut self,
        frame: &mut DialogueActivationFrame,
        activation: &mut NativeDialogueActivationState,
        site: RuntimeDeferSiteId,
        outcome: crate::line_task::RuntimeDeferOutcomeFilter,
        captures: &[crate::value::RuntimeExpr],
        owner_kind: RuntimeDeferOwner,
    ) -> Result<(), DialogueExecutionError> {
        activation.can_register_deferred()?;
        match owner_kind {
            RuntimeDeferOwner::CurrentScope
                if frame
                    .scopes
                    .last()
                    .is_some_and(|scope| scope.exit.is_none()) => {}
            RuntimeDeferOwner::LineRoot if frame.scopes.is_empty() => {}
            _ => return Err(LineRuntimeError::InvalidActivationOperation.into()),
        }
        let source_slots =
            super::defer::defer_source_slots(self.fiber.execution, &frame.execution, captures)?;
        let prepared = super::defer::inspect_line_defer(
            &self.plan,
            &frame.execution.env,
            activation,
            site,
            captures,
            super::defer::NativeDeferCaptureOwner::Activation(owner_kind),
            |handle, ordinal| {
                self.dialogue_activations.inspect_received_defer_capture(
                    self.published_receiver_execution(),
                    handle,
                    source_slots[ordinal],
                )
            },
        )?;
        let scoped_registration = prepared.commit(
            &mut frame.execution.env,
            activation,
            site,
            outcome,
            captures,
        );
        if let Some(registration) = scoped_registration {
            frame
                .scopes
                .last_mut()
                .expect("current scope was checked")
                .deferred
                .push(super::defer::NativeLexicalDeferred {
                    packet: registration,
                    source: super::defer::NativeDeferSource::Activation,
                });
        }
        Ok(())
    }

    fn evaluate_dialogue_expr(
        &mut self,
        slot: &mut DialogueActivationExecutionSlot,
        expression: &crate::value::RuntimeExpr,
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<RuntimeValue, DialogueExecutionError> {
        self.with_inline_dialogue(slot, |this| {
            this.evaluate_expr_with_backend(expression, pure_backend)
        })?
        .map_err(Into::into)
    }

    fn bind_dialogue_let(
        &mut self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        slot: &mut DialogueActivationExecutionSlot,
        pattern: &RuntimePattern,
        expression: &crate::value::RuntimeExpr,
        before: &std::collections::BTreeMap<RuntimeLineHandleToken, RuntimeHandleOwnerSlot>,
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<(), DialogueExecutionError> {
        let value = self.evaluate_dialogue_expr(slot, expression, pure_backend)?;
        let (frame, activation) = slot.transaction_mut().parts_mut();
        let preconsumed_local = match expression.kind() {
            RuntimeExprKind::Local(read)
                if read.mode() == crate::value::RuntimeLocalReadMode::Move =>
            {
                Some(read.local())
            }
            _ => None,
        };
        if !crate::pattern::inspect_runtime_pattern_owned(
            &self.plan,
            pattern,
            &value,
            self.fiber.frame.env.function_instantiation(),
        )? {
            return Err(
                RuntimeEvalError::PatternMismatch(super::runtime_value_label(&value)).into(),
            );
        }
        let handles = unique_affine_line_handles(&value)?;
        let result_tokens = handles
            .iter()
            .map(|handle| handle.token().clone())
            .collect::<std::collections::BTreeSet<_>>();
        let mut ledger = activation.ledger().clone();
        let mut commands =
            RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
        let mut moved_sources = std::collections::BTreeSet::new();
        let mut discarded_received = Vec::new();
        for handle in handles {
            let issued_here = handle.token().activation() == activation_id;
            let source = if issued_here {
                let lease = ledger
                    .lease(handle.token())
                    .ok_or(LineRuntimeError::UnknownHandle)?;
                if lease.resource().kind() != handle.kind() {
                    return Err(LineRuntimeError::WrongOpaqueProducer.into());
                }
                lease.owner().clone()
            } else {
                before
                    .get(handle.token())
                    .filter(|owner| matches!(owner, RuntimeHandleOwnerSlot::ParentFiber { .. }))
                    .cloned()
                    .ok_or(LineRuntimeError::WrongOwner)?
            };
            match &source {
                RuntimeHandleOwnerSlot::LineScope => {}
                RuntimeHandleOwnerSlot::ActivationLocal(slot)
                | RuntimeHandleOwnerSlot::ParentFiber { slot, .. } => {
                    let mut source_local = if let Some(local) = preconsumed_local {
                        (&frame
                            .execution
                            .owned_local_slot(self.fiber.execution, local)
                            == slot
                            && value_contains_token(&value, handle.token())?)
                        .then_some(local)
                    } else {
                        None
                    };
                    for (local, value) in frame.execution.env.bindings() {
                        if &frame
                            .execution
                            .owned_local_slot(self.fiber.execution, local)
                            == slot
                            && value_contains_token(value, handle.token())?
                        {
                            if source_local.replace(local).is_some() {
                                return Err(LineRuntimeError::DuplicateHandleOccurrence.into());
                            }
                        }
                    }
                    let local = source_local.ok_or(LineRuntimeError::WrongOwner)?;
                    moved_sources.insert(local);
                }
                _ => return Err(LineRuntimeError::WrongOwner.into()),
            }
            let destination = preview_result_destination_local(pattern, &value, handle.token())?;
            if !issued_here {
                if destination.is_none() {
                    discarded_received.push(handle);
                }
            } else if let Some(local) = destination {
                let destination = RuntimeHandleOwnerSlot::ActivationLocal(
                    frame
                        .execution
                        .owned_local_slot(self.fiber.execution, local),
                );
                if source != destination {
                    ledger.transfer(handle.token(), &source, destination)?;
                }
            } else {
                ledger.drop_owned(handle.token(), &source, &mut commands)?;
            }
        }
        if !value.ownership().permits_copy() && result_tokens.is_empty() {
            let RuntimeExprKind::Local(read) = expression.kind() else {
                return Err(LineRuntimeError::InvalidActivationOperation.into());
            };
            moved_sources.insert(read.local());
        }
        for local in &moved_sources {
            if Some(*local) == preconsumed_local {
                continue;
            }
            let source = frame
                .execution
                .env
                .get(*local)
                .ok_or(RuntimeEvalError::UnknownLocal(*local))?;
            if unique_affine_line_handles(source)?
                .iter()
                .any(|handle| !result_tokens.contains(handle.token()))
            {
                return Err(LineRuntimeError::InvalidActivationOperation.into());
            }
        }
        frame
            .execution
            .env
            .authorize_assignment_discard_handles(discarded_received)?;
        flush_commands(activation_id, activation, commands)?;
        activation.commit_ledger(ledger);
        for local in moved_sources {
            if Some(local) == preconsumed_local {
                continue;
            }
            let _ = frame
                .execution
                .env
                .take(local)
                .ok_or(RuntimeEvalError::UnknownLocal(local))?;
        }
        let bindings = crate::pattern::match_runtime_pattern_owned(
            &self.plan,
            pattern,
            value,
            self.fiber.frame.env.function_instantiation(),
        )
        .expect("checked dialogue let projection remains valid")
        .expect("checked dialogue let pattern remains matched");
        frame.execution.env.bind_all(bindings);
        Ok(())
    }

    fn execute_line_operation(
        &mut self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        slot: &mut DialogueActivationExecutionSlot,
        binding: Option<RuntimePattern>,
        operation: RuntimeLineOperation,
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<(), DialogueExecutionError> {
        let plan = std::sync::Arc::clone(&self.plan);
        let group = plan
            .line_task_groups()
            .get(slot.transaction().frame().task_group.index())
            .ok_or(LineRuntimeError::UnknownTaskGroup)?;
        let site = group
            .handle_site(operation.site())
            .cloned()
            .ok_or(LineRuntimeError::InvalidHandleSite)?;
        match operation {
            RuntimeLineOperation::AcquireActor {
                character, scope, ..
            } => {
                let (state, activation) = slot.transaction_mut().parts_mut();
                if site.site_kind() != RuntimeLineHandleSiteKind::StageActor
                    || site.character() != Some(&character)
                {
                    return Err(LineRuntimeError::InvalidHandleSite.into());
                }
                let mut ledger = activation.ledger().clone();
                let value = RuntimeValue::Opaque(ledger.issue(
                    activation_id,
                    &site,
                    RuntimeHandleResource::StageActor(RuntimeStageActorLease::new(
                        character.clone(),
                    )),
                    RuntimeHandleOwnerSlot::LineScope,
                )?);
                let token = RuntimeLineHandleToken::try_decode_payload(match &value {
                    RuntimeValue::Opaque(value) => value.payload(),
                    _ => unreachable!("ledger issue returns one opaque value"),
                })
                .map_err(|_| LineRuntimeError::InvalidHandlePayload)?;
                let mut commands =
                    RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
                let command = commands
                    .push_acquire_actor(token.clone(), character, scope)
                    .map_err(LineRuntimeError::from)?;
                let prepared = activation.inspect_record_commands_with_ledger(
                    activation_id,
                    &commands,
                    None,
                    ledger,
                )?;
                activation.record_commands_prepared(prepared);
                state.pending_line_operation = Some(PendingLineOperation::AcquireActor {
                    command,
                    binding,
                    value,
                    token,
                });
            }
            RuntimeLineOperation::Schedule {
                delay,
                child,
                captures,
                ..
            } => {
                if site.site_kind() != RuntimeLineHandleSiteKind::ScheduledCue
                    || site.scheduled_child() != Some(child)
                {
                    return Err(LineRuntimeError::InvalidHandleSite.into());
                }
                let RuntimeValue::Duration(delay) =
                    self.evaluate_dialogue_expr(slot, &delay, pure_backend)?
                else {
                    return Err(LineRuntimeError::InvalidCueDelay.into());
                };
                let deadline = slot
                    .transaction()
                    .frame()
                    .elapsed
                    .checked_add(delay)
                    .ok_or(LineRuntimeError::CueDeadlineOverflow)?;
                let captures = captures
                    .iter()
                    .map(|capture| {
                        self.evaluate_dialogue_expr(slot, capture.value(), pure_backend)
                            .map(|value| RuntimeLocalBinding {
                                local: capture.local(),
                                value,
                            })
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                let (state, activation) = slot.transaction_mut().parts_mut();
                if activation.scheduled().len() >= MAX_LINE_SCHEDULED_CALLBACKS {
                    return Err(LineRuntimeError::ScheduledCallbackLimitExceeded.into());
                }
                let mut ledger = activation.ledger().clone();
                let (scope, join_policy) = match group.node(child) {
                    Some(crate::line_task::LineTaskNode::Child {
                        scope, join_policy, ..
                    }) => (*scope, *join_policy),
                    _ => return Err(LineRuntimeError::InvalidScheduledCaptureOwner.into()),
                };
                let mut captured_tokens = std::collections::BTreeSet::new();
                let mut capture_transfers = Vec::new();
                for capture in &captures {
                    for handle in unique_affine_line_handles(&capture.value)? {
                        if !captured_tokens.insert(handle.token().clone()) {
                            return Err(LineRuntimeError::DuplicateHandleOccurrence.into());
                        }
                        if join_policy == crate::line_task::ChildJoinPolicy::Detached {
                            return Err(LineRuntimeError::DetachedAffineCapture.into());
                        }
                        let expected = ledger
                            .lease(handle.token())
                            .map(|lease| lease.owner().clone())
                            .ok_or(LineRuntimeError::UnknownHandle)?;
                        if !matches!(
                            expected,
                            RuntimeHandleOwnerSlot::LineScope
                                | RuntimeHandleOwnerSlot::ActivationLocal(_)
                        ) {
                            return Err(LineRuntimeError::WrongOwner.into());
                        }
                        capture_transfers.push((handle.token().clone(), expected));
                    }
                }
                let value = RuntimeValue::Opaque(ledger.issue(
                    activation_id,
                    &site,
                    RuntimeHandleResource::Cue(RuntimeCueLease::new(RuntimeCueOrigin::Scheduled {
                        child,
                        deadline,
                    })),
                    RuntimeHandleOwnerSlot::LineScope,
                )?);
                let token = token_from_value(&value)?;
                let work = crate::line_task::LineTaskWorkTag::scheduled(token.clone(), scope);
                let prepared_schedule = activation.inspect_schedule(
                    &token,
                    child,
                    &work,
                    deadline,
                    &captures
                        .iter()
                        .map(|capture| capture.local)
                        .collect::<Vec<_>>(),
                )?;
                for (captured, expected) in capture_transfers {
                    ledger.transfer(
                        &captured,
                        &expected,
                        RuntimeHandleOwnerSlot::ChildScope(work.clone()),
                    )?;
                }
                let mut commands =
                    RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
                self.inspect_operation_binding(
                    activation_id,
                    &mut ledger,
                    &mut commands,
                    binding.as_ref(),
                    &value,
                )?;
                let prepared_commands = activation.inspect_record_commands_with_ledger(
                    activation_id,
                    &commands,
                    None,
                    ledger,
                )?;
                let bindings = self.bind_operation_value_owned(binding.as_ref(), value);
                activation.schedule_prepared(prepared_schedule, captures.into_boxed_slice());
                activation.record_commands_prepared(prepared_commands);
                state.execution.env.bind_all(bindings);
            }
            RuntimeLineOperation::ActorLook {
                character,
                actor,
                look,
                crossfade,
                ..
            } => {
                let (state, activation) = slot.transaction_mut().parts_mut();
                if site.site_kind() != RuntimeLineHandleSiteKind::StageLookCue
                    || site.character() != Some(&character)
                {
                    return Err(LineRuntimeError::InvalidHandleSite.into());
                }
                let actor_value = state
                    .execution
                    .env
                    .get(actor.local())
                    .ok_or(RuntimeEvalError::UnknownLocal(actor.local()))?;
                let actor_token = self.dialogue_activations.borrow_stage_actor(
                    self.published_receiver_execution(),
                    activation_id,
                    activation.ledger(),
                    actor_value.view(),
                    state
                        .execution
                        .owned_local_slot(self.fiber.execution, actor.local()),
                    &character,
                )?;
                let look_value = self.evaluate_dialogue_expr(slot, &look, pure_backend)?;
                let look = crate::character_nominal::RuntimeCharacterLookSourceAuthority::decode_program_value(
                    crate::program_types::RuntimeProgramTypes::Plan(&plan),
                    &character,
                    &look_value,
                ).map_err(|_| LineRuntimeError::WrongLookOwner)?;
                let RuntimeValue::Duration(crossfade) =
                    self.evaluate_dialogue_expr(slot, &crossfade, pure_backend)?
                else {
                    return Err(LineRuntimeError::InvalidCrossfade.into());
                };
                let (state, activation) = slot.transaction_mut().parts_mut();
                let mut ledger = activation.ledger().clone();
                let value = RuntimeValue::Opaque(ledger.issue(
                    activation_id,
                    &site,
                    RuntimeHandleResource::Cue(RuntimeCueLease::new(RuntimeCueOrigin::StageLook)),
                    RuntimeHandleOwnerSlot::LineScope,
                )?);
                let token = token_from_value(&value)?;
                let mut commands =
                    RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
                let command = commands
                    .push_set_character_look(token.clone(), actor_token, character, look, crossfade)
                    .map_err(LineRuntimeError::from)?;
                let prepared = activation.inspect_record_commands_with_ledger(
                    activation_id,
                    &commands,
                    None,
                    ledger,
                )?;
                activation.record_commands_prepared(prepared);
                state.pending_line_operation = Some(PendingLineOperation::ActorLook {
                    command,
                    binding,
                    value,
                    token,
                });
            }
            RuntimeLineOperation::VoiceHandle { .. } => {
                let (state, activation) = slot.transaction_mut().parts_mut();
                if site.site_kind() != RuntimeLineHandleSiteKind::Voice {
                    return Err(LineRuntimeError::InvalidHandleSite.into());
                }
                match activation.ledger().prepare_voice_lease(&state.voice)? {
                    RuntimeVoiceLeaseAdmission::Issue(lease) => {
                        let mut ledger = activation.ledger().clone();
                        let value = RuntimeValue::Opaque(ledger.issue(
                            activation_id,
                            &site,
                            RuntimeHandleResource::Voice(lease),
                            RuntimeHandleOwnerSlot::LineScope,
                        )?);
                        let mut commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        self.inspect_operation_binding(
                            activation_id,
                            &mut ledger,
                            &mut commands,
                            binding.as_ref(),
                            &value,
                        )?;
                        let prepared = activation.inspect_record_commands_with_ledger(
                            activation_id,
                            &commands,
                            None,
                            ledger,
                        )?;
                        let bindings = self.bind_operation_value_owned(binding.as_ref(), value);
                        activation.record_commands_prepared(prepared);
                        state.execution.env.bind_all(bindings);
                    }
                    RuntimeVoiceLeaseAdmission::Start(ticket) => {
                        let mut commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        let command = commands
                            .push_start_voice(ticket)
                            .map_err(LineRuntimeError::from)?;
                        let prepared =
                            activation.inspect_record_commands(activation_id, &commands)?;
                        activation.record_commands_prepared(prepared);
                        state.pending_line_operation = Some(PendingLineOperation::StartVoice {
                            command,
                            binding,
                            site: site.id(),
                        });
                    }
                }
            }
        }
        Ok(())
    }

    fn resume_pending_line_operation(
        &mut self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        state: &mut DialogueActivationFrame,
        activation: &mut NativeDialogueActivationState,
        outcomes: &[RuntimeLineHostOutcome],
    ) -> Result<bool, DialogueExecutionError> {
        let pending = state
            .pending_line_operation
            .as_ref()
            .ok_or(LineRuntimeError::InvalidActivationOperation)?;
        match pending {
            PendingLineOperation::AcquireActor {
                command,
                binding,
                value,
                token,
            } => {
                require_issued_command(activation_id, activation, &command)?;
                let Some(outcome) = outcomes.iter().find_map(|outcome| match outcome {
                    RuntimeLineHostOutcome::Stage(outcome) if outcome.command() == command => {
                        Some(outcome)
                    }
                    _ => None,
                }) else {
                    return Ok(false);
                };
                match outcome {
                    RuntimeStageCommandOutcome::Acquired { actor, .. } if actor == token => {
                        let mut ledger = activation.ledger().clone();
                        ledger.set_state(
                            &token,
                            RuntimeHandleLeaseState::Allocating,
                            RuntimeHandleLeaseState::Active,
                        )?;
                        let mut commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        self.inspect_operation_binding(
                            activation_id,
                            &mut ledger,
                            &mut commands,
                            binding.as_ref(),
                            &value,
                        )?;
                        let prepared = activation.inspect_record_commands_with_ledger(
                            activation_id,
                            &commands,
                            Some(command),
                            ledger,
                        )?;
                        let Some(PendingLineOperation::AcquireActor { binding, value, .. }) =
                            state.pending_line_operation.take()
                        else {
                            unreachable!("checked pending actor operation is retained")
                        };
                        let bindings = self.bind_operation_value_owned(binding.as_ref(), value);
                        activation.record_commands_prepared(prepared);
                        state.execution.env.bind_all(bindings);
                    }
                    RuntimeStageCommandOutcome::Rejected { code, .. } => {
                        let mut ledger = activation.ledger().clone();
                        ledger.set_state(
                            &token,
                            RuntimeHandleLeaseState::Allocating,
                            RuntimeHandleLeaseState::Failed,
                        )?;
                        ledger.set_state(
                            &token,
                            RuntimeHandleLeaseState::Failed,
                            RuntimeHandleLeaseState::Released,
                        )?;
                        let commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        let prepared = activation.inspect_record_commands_with_ledger(
                            activation_id,
                            &commands,
                            Some(command),
                            ledger,
                        )?;
                        activation.record_commands_prepared(prepared);
                        state.pending_line_operation = None;
                        return Err(LineRuntimeError::StageCommandRejected { code: *code }.into());
                    }
                    _ => return Err(LineRuntimeError::StageOutcomeMismatch.into()),
                }
            }
            PendingLineOperation::ActorLook {
                command,
                binding,
                value,
                token,
            } => {
                require_issued_command(activation_id, activation, &command)?;
                let Some(outcome) = outcomes.iter().find_map(|outcome| match outcome {
                    RuntimeLineHostOutcome::Stage(outcome) if outcome.command() == command => {
                        Some(outcome)
                    }
                    _ => None,
                }) else {
                    return Ok(false);
                };
                match outcome {
                    RuntimeStageCommandOutcome::Accepted { cue, .. } if cue == token => {
                        let mut ledger = activation.ledger().clone();
                        ledger.set_state(
                            &token,
                            RuntimeHandleLeaseState::Pending,
                            RuntimeHandleLeaseState::Running,
                        )?;
                        let mut commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        self.inspect_operation_binding(
                            activation_id,
                            &mut ledger,
                            &mut commands,
                            binding.as_ref(),
                            &value,
                        )?;
                        let prepared = activation.inspect_record_commands_with_ledger(
                            activation_id,
                            &commands,
                            Some(command),
                            ledger,
                        )?;
                        let Some(PendingLineOperation::ActorLook { binding, value, .. }) =
                            state.pending_line_operation.take()
                        else {
                            unreachable!("checked pending look operation is retained")
                        };
                        let bindings = self.bind_operation_value_owned(binding.as_ref(), value);
                        activation.record_commands_prepared(prepared);
                        state.execution.env.bind_all(bindings);
                    }
                    RuntimeStageCommandOutcome::Rejected { code, .. } => {
                        let mut ledger = activation.ledger().clone();
                        ledger.set_state(
                            &token,
                            RuntimeHandleLeaseState::Pending,
                            RuntimeHandleLeaseState::Failed,
                        )?;
                        ledger.set_state(
                            &token,
                            RuntimeHandleLeaseState::Failed,
                            RuntimeHandleLeaseState::Released,
                        )?;
                        let commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        let prepared = activation.inspect_record_commands_with_ledger(
                            activation_id,
                            &commands,
                            Some(command),
                            ledger,
                        )?;
                        activation.record_commands_prepared(prepared);
                        state.pending_line_operation = None;
                        return Err(LineRuntimeError::StageCommandRejected { code: *code }.into());
                    }
                    _ => return Err(LineRuntimeError::StageOutcomeMismatch.into()),
                }
            }
            PendingLineOperation::StartVoice {
                command,
                binding,
                site,
            } => {
                require_issued_command(activation_id, activation, &command)?;
                let Some(outcome) = outcomes.iter().find_map(|outcome| match outcome {
                    RuntimeLineHostOutcome::Voice(outcome) if outcome.command() == command => {
                        Some(outcome)
                    }
                    _ => None,
                }) else {
                    return Ok(false);
                };
                let session = match outcome {
                    RuntimeVoiceCommandOutcome::Started { session, .. } => session,
                    RuntimeVoiceCommandOutcome::Rejected { failure, .. } => {
                        let commands = RuntimeCommandQueue::new(
                            activation_id.clone(),
                            activation.command_sequence(),
                        );
                        let ledger = activation.ledger().clone();
                        let prepared = activation.inspect_record_commands_with_ledger(
                            activation_id,
                            &commands,
                            Some(command),
                            ledger,
                        )?;
                        activation.record_commands_prepared(prepared);
                        state.voice = RuntimeDialogueVoiceState::Failed(failure.clone());
                        state.pending_line_operation = None;
                        return Err(LineRuntimeError::VoiceStartRejected {
                            failure: failure.clone(),
                        }
                        .into());
                    }
                    RuntimeVoiceCommandOutcome::Released { .. } => {
                        return Err(LineRuntimeError::StageOutcomeMismatch.into());
                    }
                };
                let group = self
                    .plan
                    .line_task_groups()
                    .get(state.task_group.index())
                    .ok_or(LineRuntimeError::UnknownTaskGroup)?;
                let site = group
                    .handle_site(*site)
                    .cloned()
                    .ok_or(LineRuntimeError::InvalidHandleSite)?;
                let mut ledger = activation.ledger().clone();
                let ordinal = ledger.next_voice_lease_ordinal()?;
                let value = RuntimeValue::Opaque(ledger.issue(
                    activation_id,
                    &site,
                    RuntimeHandleResource::Voice(RuntimeVoiceLease::new(
                        session.clone(),
                        ordinal,
                        true,
                    )),
                    RuntimeHandleOwnerSlot::LineScope,
                )?);
                let mut commands =
                    RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
                self.inspect_operation_binding(
                    activation_id,
                    &mut ledger,
                    &mut commands,
                    binding.as_ref(),
                    &value,
                )?;
                let prepared = activation.inspect_record_commands_with_ledger(
                    activation_id,
                    &commands,
                    Some(command),
                    ledger,
                )?;
                let Some(PendingLineOperation::StartVoice { binding, .. }) =
                    state.pending_line_operation.take()
                else {
                    unreachable!("checked pending voice operation is retained")
                };
                let bindings = self.bind_operation_value_owned(binding.as_ref(), value);
                state.voice = RuntimeDialogueVoiceState::Ready(session.clone());
                activation.record_commands_prepared(prepared);
                state.execution.env.bind_all(bindings);
            }
        }
        state.pending_line_operation = None;
        Ok(true)
    }

    fn inspect_operation_binding(
        &self,
        activation_id: &DialogueActivationId,
        ledger: &mut crate::line_task::RuntimeLineHandleLedger,
        commands: &mut RuntimeCommandQueue,
        pattern: Option<&RuntimePattern>,
        value: &RuntimeValue,
    ) -> Result<(), DialogueExecutionError> {
        let Some(pattern) = pattern else {
            return Ok(());
        };
        if !crate::pattern::inspect_runtime_pattern_owned(
            &self.plan,
            pattern,
            value,
            self.fiber.frame.env.function_instantiation(),
        )? {
            return Err(LineRuntimeError::ResultPatternOrTypeMismatch.into());
        }
        for handle in unique_affine_line_handles(value)? {
            let expected = ledger
                .lease(handle.token())
                .map(|lease| lease.owner().clone())
                .ok_or(LineRuntimeError::UnknownHandle)?;
            if !matches!(expected, RuntimeHandleOwnerSlot::LineScope) {
                return Err(LineRuntimeError::WrongOwner.into());
            }
            let destination = preview_result_destination_local(pattern, value, handle.token())?
                .map(|local| self.activation_slot(activation_id, local))
                .transpose()?
                .map(RuntimeHandleOwnerSlot::ActivationLocal);
            match destination {
                Some(destination) => ledger.transfer(handle.token(), &expected, destination)?,
                None => ledger.drop_owned(handle.token(), &expected, commands)?,
            }
        }
        Ok(())
    }

    fn bind_operation_value_owned(
        &self,
        pattern: Option<&RuntimePattern>,
        value: RuntimeValue,
    ) -> Vec<RuntimeLocalBinding> {
        let Some(pattern) = pattern else {
            return Vec::new();
        };
        crate::pattern::match_runtime_pattern_owned(
            &self.plan,
            pattern,
            value,
            self.fiber.frame.env.function_instantiation(),
        )
        .expect("preflighted operation pattern remains valid")
        .expect("preflighted operation pattern remains matched")
    }

    fn stage_dialogue_result(
        &mut self,
        activation_id: &DialogueActivationId,
        state: &mut DialogueActivationFrame,
        activation: &mut NativeDialogueActivationState,
        value: RuntimeValue,
    ) -> Result<Vec<crate::value::ownership::RuntimeAffineLineHandle>, DialogueExecutionError> {
        if !matches!(activation.result(), RuntimeDialogueResultState::Uncommitted) {
            return Err(LineRuntimeError::ResultAlreadyCommitted.into());
        }
        let checked = self
            .plan
            .checked_type(state.result_target.ty())
            .map_err(|_| LineRuntimeError::ResultPatternOrTypeMismatch)?
            .ok_or(LineRuntimeError::ResultPatternOrTypeMismatch)?;
        if !checked.accepts_value(&value) {
            return Err(LineRuntimeError::ResultPatternOrTypeMismatch.into());
        }
        let handles = unique_affine_line_handles(&value)?;
        let mut ledger = activation.ledger().clone();
        for handle in handles
            .iter()
            .filter(|handle| handle.token().activation() == activation_id)
        {
            let lease = ledger
                .lease(handle.token())
                .ok_or(LineRuntimeError::UnknownHandle)?;
            if lease.resource().kind() != handle.kind() {
                return Err(LineRuntimeError::WrongOpaqueProducer.into());
            }
            let expected = lease.owner().clone();
            if !matches!(
                expected,
                RuntimeHandleOwnerSlot::LineScope | RuntimeHandleOwnerSlot::ActivationLocal(_)
            ) {
                return Err(LineRuntimeError::WrongOwner.into());
            }
            ledger.transfer(
                handle.token(),
                &expected,
                RuntimeHandleOwnerSlot::DialogueResult(handle.path().clone()),
            )?;
        }
        activation.commit_ledger(ledger);
        activation.commit_result(state.result_target.ty(), value)?;
        Ok(handles)
    }

    fn begin_dialogue_reveal(
        &mut self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        state: &mut DialogueActivationFrame,
        activation: &mut NativeDialogueActivationState,
    ) -> Result<DialogueLineTaskStart, DialogueExecutionError> {
        if !matches!(
            activation.result(),
            RuntimeDialogueResultState::Uncommitted | RuntimeDialogueResultState::Committed { .. }
        ) || !state.scopes.is_empty()
            || activation.has_pending_commands()
            || state.target.is_none()
        {
            return Err(LineRuntimeError::ResultNotCommitted.into());
        }
        let plan = std::sync::Arc::clone(&self.plan);
        let group = plan
            .line_task_groups()
            .get(state.task_group.index())
            .ok_or(LineRuntimeError::UnknownTaskGroup)?;
        let task_inputs = state.task_inputs_for_reveal(group.shared_inputs())?;
        let mut live = LineTaskLiveState::new(group, activation_id.clone());
        activation.advance_schedules(state.elapsed, &mut live)?;
        let line_task_activation = progress_live_line_task_group(
            group,
            state.elapsed,
            LineTaskReadyEvents::new(&std::collections::BTreeSet::new()),
            &mut live,
        )?;
        let template = self
            .plan
            .dialogue_content()
            .get(state.content)
            .ok_or(crate::line_task::LineRuntimeError::UnknownContentPlan)?
            .template();
        state.line_task = DialogueLineTaskState::Live(live);
        state.task_inputs = task_inputs.clone();
        state.phase = DialogueRuntimePhase::Ready;
        Ok(DialogueLineTaskStart {
            event: Some(FlowEvent::DialogueLine {
                activation: activation_id.clone(),
                line: state.line.clone(),
                template,
                target: state.target.take().expect("reveal target was preflighted"),
                values: std::mem::take(&mut state.values),
            }),
            request_cancellation: false,
            group: state.task_group,
            activation: line_task_activation,
            captures: task_inputs,
            callback_sites: Vec::new(),
        })
    }

    pub(super) fn resume_dialogue_publication(
        &mut self,
        transaction: DialogueActivationTransaction,
        output: &mut RuntimeStepOutput,
    ) {
        self.resume_dialogue_publication_with_transaction(transaction, output);
    }

    fn resume_dialogue_publication_with_transaction(
        &mut self,
        mut transaction: DialogueActivationTransaction,
        output: &mut RuntimeStepOutput,
    ) {
        let activation_id = transaction.activation().clone();
        transaction.frame_mut().phase = DialogueRuntimePhase::Publishing;
        match self.try_publish_dialogue_result(&activation_id, &mut transaction) {
            Ok(DialoguePublicationOutcome::Pending) => {
                let activation = transaction.activation().clone();
                let phase = transaction.frame().phase;
                match self.commit_dialogue_activation_transaction(transaction, output) {
                    Ok(()) => {
                        self.fiber.frame.status = super::FlowFiberStatus::Dialogue(
                            DialogueExecutionStatus::new(activation, phase),
                        );
                    }
                    Err(error) => self.fail_eval(error, output),
                }
            }
            Ok(DialoguePublicationOutcome::Published(proof)) => {
                let disposition = self.commit_published_dialogue_activation_transaction(
                    transaction,
                    proof,
                    output,
                );
                self.apply_dialogue_commit_disposition(disposition);
            }
            Err(error) => self.begin_dialogue_failure(transaction, error, output),
        }
    }

    fn try_publish_dialogue_result(
        &mut self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        transaction: &mut DialogueActivationTransaction,
    ) -> Result<DialoguePublicationOutcome, DialogueExecutionError> {
        let (state, activation) = transaction.parts_mut();
        let (ty, value, begin_publication) = match activation.result() {
            RuntimeDialogueResultState::Committed { ty, value } => (*ty, value, true),
            RuntimeDialogueResultState::Selected { ty, value, .. } => (*ty, value, true),
            RuntimeDialogueResultState::Publishing { ty, value } => (*ty, value, false),
            RuntimeDialogueResultState::Uncommitted
            | RuntimeDialogueResultState::Published
            | RuntimeDialogueResultState::Abandoned => {
                return Err(LineRuntimeError::ResultNotCommitted.into());
            }
        };
        if ty != state.result_target.ty() {
            return Err(LineRuntimeError::ResultPatternOrTypeMismatch.into());
        }
        let checked = self
            .plan
            .checked_type(ty)
            .map_err(|_| LineRuntimeError::ResultPatternOrTypeMismatch)?
            .ok_or(LineRuntimeError::ResultPatternOrTypeMismatch)?;
        if !checked.accepts_value(&value) {
            return Err(LineRuntimeError::ResultPatternOrTypeMismatch.into());
        }
        if !crate::pattern::inspect_runtime_pattern_owned(
            &self.plan,
            state.result_target.pattern(),
            value,
            self.fiber.frame.env.function_instantiation(),
        )? {
            return Err(LineRuntimeError::ResultPatternOrTypeMismatch.into());
        }
        let destinations = unique_affine_line_handles(value)?
            .into_iter()
            .map(|handle| {
                let destination = preview_result_destination_local(
                    state.result_target.pattern(),
                    value,
                    handle.token(),
                )?
                .map(|local| self.owned_slot(local))
                .transpose()?;
                Ok::<_, DialogueExecutionError>((handle, destination))
            })
            .collect::<Result<Vec<_>, _>>()?;
        let local_destinations = || {
            destinations
                .iter()
                .filter(|(handle, _)| handle.token().activation() == activation_id)
        };
        let parent_owners = destinations
            .iter()
            .filter_map(|(handle, destination)| {
                destination.map(|slot| (handle.token().clone(), slot))
            })
            .collect::<std::collections::BTreeMap<_, _>>();
        if begin_publication {
            let mut ledger = activation.ledger().clone();
            let mut commands =
                RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
            let mut remaining = ledger
                .leases()
                .values()
                .filter(|lease| {
                    !matches!(
                        lease.owner(),
                        RuntimeHandleOwnerSlot::DialogueResult(_)
                            | RuntimeHandleOwnerSlot::ParentFiber { .. }
                    ) && lease.state() != RuntimeHandleLeaseState::Released
                })
                .map(|lease| (lease.token().clone(), lease.owner().clone()))
                .collect::<Vec<_>>();
            remaining.reverse();
            for (token, owner) in remaining {
                ledger.drop_owned(&token, &owner, &mut commands)?;
            }
            activation.commit_ledger(ledger);
            flush_commands(activation_id, activation, commands)?;
            activation.begin_result_publication()?;
        }
        if activation.has_pending_commands() {
            return Ok(DialoguePublicationOutcome::Pending);
        }
        let mut ledger = activation.ledger().clone();
        let mut commands =
            RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
        for (handle, destination) in local_destinations() {
            if destination.is_some() {
                continue;
            }
            let Some(lease) = ledger.lease(handle.token()) else {
                return Err(LineRuntimeError::UnknownHandle.into());
            };
            if matches!(
                lease.state(),
                RuntimeHandleLeaseState::Released | RuntimeHandleLeaseState::Cancelling
            ) {
                continue;
            }
            ledger.drop_owned(
                handle.token(),
                &RuntimeHandleOwnerSlot::DialogueResult(handle.path().clone()),
                &mut commands,
            )?;
        }
        activation.commit_ledger(ledger);
        flush_commands(activation_id, activation, commands)?;
        let handles = destinations
            .iter()
            .map(|(handle, _)| handle.clone())
            .collect::<Vec<_>>();
        let (ready, received) = self
            .dialogue_activations
            .inspect_received_result_publication(
                activation_id,
                self.published_receiver_execution(),
                self.fiber.execution,
                &handles,
                &parent_owners,
                !activation.has_pending_commands(),
            )?;
        if !ready {
            transaction.stage_received_handles(received);
            return Ok(DialoguePublicationOutcome::Pending);
        }
        let mut ledger = activation.ledger().clone();
        for (handle, destination) in local_destinations() {
            if let Some(destination) = destination {
                ledger.transfer(
                    handle.token(),
                    &RuntimeHandleOwnerSlot::DialogueResult(handle.path().clone()),
                    RuntimeHandleOwnerSlot::parent_fiber(
                        self.published_receiver_execution(),
                        *destination,
                    ),
                )?;
            }
        }
        activation.commit_ledger(ledger);
        if activation.ledger().leases().values().any(|lease| {
            lease.state() != RuntimeHandleLeaseState::Released
                && !matches!(lease.owner(), RuntimeHandleOwnerSlot::ParentFiber { .. })
        }) {
            return Err(LineRuntimeError::UnownedLeaseAtPublish.into());
        }
        transaction.stage_received_handles(received);
        let proof = self
            .dialogue_activations
            .inspect_published_transaction(transaction)?;
        let (state, activation) = transaction.parts_mut();
        activation
            .release_frame()
            .expect("prepared publication permits frame release");
        let (_, value) = activation
            .finish_result_publication()
            .expect("prepared publication transfers its sole result owner");
        let bindings = crate::pattern::match_runtime_pattern_owned(
            &self.plan,
            state.result_target.pattern(),
            value,
            self.fiber.frame.env.function_instantiation(),
        )
        .expect("prepared publication pattern remains valid")
        .expect("publication pattern passed borrowed owning preflight");
        transaction
            .stage_disposition(DialogueCommitDisposition::Published {
                bindings,
                arrivals: parent_owners,
            })
            .expect("prepared publication has a vacant disposition");
        Ok(DialoguePublicationOutcome::Published(proof))
    }

    fn execute_activation_registry_mutation(
        &mut self,
        slot: &mut DialogueActivationExecutionSlot,
        effects: &crate::plan::RuntimeEffectSet,
        key: &arcweft_id::LifetimeRegistryKey,
        effect: &RuntimeEffectExpr,
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<DialogueActivationStep, DialogueExecutionError> {
        use super::registry::{
            NativeDialogueRegistryMutation, NativeDialogueRegistryTarget,
            NativePreparedRegistryMutation,
        };
        use arcweft_id::LifetimeScopeKind;

        let failure = |message| DialogueExecutionError::ActivationEffectFailed { message };
        let required = arcweft_id::EffectId::state_write(key);
        if !effects.iter().any(|effect| effect.covers(&required)) {
            return Err(RuntimeEffectMaterializeError::RegistryWriteNotAuthorized {
                effect: required,
            }
            .into());
        }
        let owner = crate::task::RuntimeProgramOwner::Plan(self.plan.clone());
        let transaction = slot.transaction();
        if !transaction.frame().execution.program.same_program(&owner) {
            return Err(RuntimeEffectMaterializeError::RegistryContextRequired.into());
        }

        let id = *transaction.activation();
        let binding = transaction.frame().execution.env.source_function_context();
        let before =
            self.activation_local_handle_owners(&id, transaction.frame(), transaction.line())?;
        let (image, mut admission) = self
            .inert_rollback_image_with_dialogue(
                Some(transaction),
                crate::entry::RuntimeSchemaLimits::engine_default(),
            )
            .map_err(failure)?;
        let (target, rows) = match key.scope() {
            LifetimeScopeKind::Line => (
                NativeDialogueRegistryTarget::Line,
                transaction.line().line_registry()?,
            ),
            LifetimeScopeKind::Flow => {
                let parent = transaction.frame().parent;
                self.dialogue_parent_flow_registry(parent, id)
                    .ok_or(RuntimeEffectMaterializeError::RegistryContextRequired)?
            }
            _ => return Err(RuntimeEffectMaterializeError::RegistryContextRequired.into()),
        };
        let (destination, source) = target.origin(id);
        let prepared = NativePreparedRegistryMutation::prepare(
            &self.plan,
            effect,
            rows,
            destination,
            source,
            &binding,
            &mut admission,
        )
        .map_err(|error| failure(error.to_string()))?;
        let result = (|| {
            let evaluated = prepared
                .input()
                .map(|input| self.evaluate_dialogue_expr(slot, input, pure_backend))
                .transpose()?;
            let mut validate = |handle: &crate::value::ownership::RuntimeAffineLineHandle| {
                let source = before
                    .get(handle.token())
                    .ok_or(LineRuntimeError::WrongOwner)?;
                self.dialogue_activations.validate_registry_handle(
                    &id,
                    slot.transaction().line().ledger(),
                    handle,
                    source,
                )
            };
            let mutation = prepared
                .finish(evaluated, Some(&mut validate))
                .map_err(|error| failure(error.to_string()))?;

            let transaction = slot.transaction_mut();
            let change = mutation
                .line_change()
                .map_err(|error| failure(error.to_string()))?;
            self.reconcile_activation_instruction(
                transaction,
                &before,
                change
                    .as_ref()
                    .map(NativeDialogueHandleTransition::Registry),
            )?;
            advance_activation_pc(transaction.frame_mut())?;
            self.commit_dialogue_registry_mutation(
                transaction,
                NativeDialogueRegistryMutation { target, mutation },
            )
            .map_err(|error| failure(error.to_string()))?;
            Ok(DialogueActivationStep::Continue)
        })();
        match result {
            Ok(step) => Ok(step),
            Err(cause) => Err(self.restore_failed_dialogue_instruction(
                slot.transaction_mut(),
                image,
                &owner,
                cause,
            )),
        }
    }

    fn execute_queued_activation_registry_mutation(
        &mut self,
        slot: &mut DialogueActivationExecutionSlot,
        input: &mut super::RuntimeStepInput,
        events: &[super::TaskEvent],
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<DialogueActivationStep, DialogueExecutionError> {
        use super::registry::NativeActivationRegistryExecution;

        let failure = |message| DialogueExecutionError::ActivationEffectFailed { message };
        let transaction = slot.transaction();
        let activation = *transaction.activation();
        let owner = crate::task::RuntimeProgramOwner::Plan(self.plan.clone());
        let before = self.activation_local_handle_owners(
            &activation,
            transaction.frame(),
            transaction.line(),
        )?;
        let (image, mut admission) = self
            .inert_rollback_image_with_dialogue(
                Some(transaction),
                crate::entry::RuntimeSchemaLimits::engine_default(),
            )
            .map_err(failure)?;
        let result = (|| {
            let mut pending = None;
            let staged = self.step_dialogue_execution(
                slot,
                None,
                input,
                events,
                pure_backend,
                Some(NativeActivationRegistryExecution {
                    admission: &mut admission,
                    before: &before,
                    pending: &mut pending,
                }),
            )?;
            let write = pending.ok_or(LineRuntimeError::InvalidActivationOperation)?;
            let transaction = slot.transaction_mut();
            let change = write
                .mutation
                .line_change()
                .map_err(|error| failure(error.to_string()))?;
            self.reconcile_activation_instruction(
                transaction,
                &before,
                change
                    .as_ref()
                    .map(NativeDialogueHandleTransition::Registry),
            )?;
            self.commit_dialogue_registry_mutation(transaction, write)
                .map_err(|error| failure(error.to_string()))?;
            Ok(DialogueActivationStep::Execution(staged))
        })();
        match result {
            Ok(step) => Ok(step),
            Err(cause) => Err(self.restore_failed_dialogue_instruction(
                slot.transaction_mut(),
                image,
                &owner,
                cause,
            )),
        }
    }

    fn restore_failed_dialogue_instruction(
        &mut self,
        transaction: &mut DialogueActivationTransaction,
        image: super::NativeEngineRollbackImage,
        owner: &crate::task::RuntimeProgramOwner,
        cause: DialogueExecutionError,
    ) -> DialogueExecutionError {
        let result = Self::from_rollback_image(image, owner).and_then(|mut restored| {
            let original = restored
                .dialogue_activations
                .begin_transaction(transaction.activation())
                .map_err(|error| error.to_string())?;
            *transaction = original;
            *self = restored;
            Ok(())
        });
        match result {
            Ok(()) => cause,
            Err(message) => DialogueExecutionError::ActivationEffectFailed {
                message: format!("{cause}; instruction rollback failed: {message}"),
            },
        }
    }

    fn execute_dialogue_evaluated_effect(
        &mut self,
        activation_id: &crate::runtime_id::DialogueActivationId,
        slot: &mut DialogueActivationExecutionSlot,
        effect: &RuntimeEffectExpr,
        pure_backend: &mut impl RuntimeCallBackend,
    ) -> Result<Option<LineEffectRequest>, DialogueExecutionError> {
        effect.require_context_free()?;
        if !matches!(effect, RuntimeEffectExpr::Drop { .. }) {
            let values = effect
                .argument_exprs()
                .into_iter()
                .map(|expression| self.evaluate_dialogue_expr(slot, expression, pure_backend))
                .collect::<Result<Vec<_>, _>>()?;
            let request = effect.materialize(&values)?;
            if let Some(LineEffectRequest::Wait(crate::effect::RuntimeWaitTarget::Duration(
                duration,
            ))) = &request
            {
                slot.transaction_mut().frame_mut().execution.status =
                    crate::time::LogicalWait::start(*duration).map_or(
                        super::FlowFiberStatus::Running,
                        super::FlowFiberStatus::DurationWaiting,
                    );
            }
            return Ok(request);
        }
        let RuntimeEffectExpr::Drop { target, policy } = effect else {
            unreachable!("non-drop effects were handled above");
        };
        let policy = match policy {
            RuntimeDropPolicyExpr::Default => RuntimeDropPolicy::Default,
            RuntimeDropPolicyExpr::Cancel => RuntimeDropPolicy::Cancel,
            RuntimeDropPolicyExpr::Stop { fade } => {
                let RuntimeValue::Duration(fade) =
                    self.evaluate_dialogue_expr(slot, fade, pure_backend)?
                else {
                    return Err(LineRuntimeError::InvalidDropPolicy.into());
                };
                RuntimeDropPolicy::Stop { fade }
            }
            RuntimeDropPolicyExpr::Finish => RuntimeDropPolicy::Finish,
            RuntimeDropPolicyExpr::Release => RuntimeDropPolicy::Release,
            RuntimeDropPolicyExpr::Detach => RuntimeDropPolicy::Detach,
        };
        let source_local = match target.kind() {
            RuntimeExprKind::Local(read)
                if read.mode() == crate::value::RuntimeLocalReadMode::Move
                    && read.fields().is_empty() =>
            {
                Some(read.local())
            }
            _ => None,
        };
        let target = match source_local {
            Some(local) => slot
                .transaction_mut()
                .frame_mut()
                .execution
                .env
                .take(local)
                .ok_or(RuntimeEvalError::UnknownLocal(local))?,
            None => self.evaluate_dialogue_expr(slot, target, pure_backend)?,
        };
        let (state, activation) = slot.transaction_mut().parts_mut();
        let result = (|| {
            let handles = unique_affine_line_handles(&target)?;
            let mut ledger = activation.ledger().clone();
            let mut commands =
                RuntimeCommandQueue::new(activation_id.clone(), activation.command_sequence());
            let mut drops_received_handle = false;
            for handle in handles {
                if handle.token().activation() != activation_id {
                    drops_received_handle = true;
                    continue;
                }
                let expected = ledger
                    .lease(handle.token())
                    .map(|lease| lease.owner().clone())
                    .ok_or(LineRuntimeError::UnknownHandle)?;
                if !matches!(
                    expected,
                    RuntimeHandleOwnerSlot::LineScope | RuntimeHandleOwnerSlot::ActivationLocal(_)
                ) {
                    return Err(DialogueExecutionError::from(LineRuntimeError::WrongOwner));
                }
                ledger.drop_owned_with_policy(handle.token(), &expected, policy, &mut commands)?;
            }
            if drops_received_handle {
                state
                    .execution
                    .env
                    .set_assignment_discard_boundary(Some(policy))?;
            }
            activation.commit_ledger(ledger);
            flush_commands(activation_id, activation, commands)?;
            Ok(())
        })();
        if result.is_err()
            && let Some(local) = source_local
        {
            state.execution.env.set(local, target);
        }
        result.map(|()| None)
    }
    fn activation_slot(
        &self,
        activation: &DialogueActivationId,
        local: crate::runtime_id::RuntimeLocalDeclarationId,
    ) -> Result<RuntimeOwnedSlotId, LineRuntimeError> {
        self.plan
            .local_declarations()
            .get(local)
            .ok_or(LineRuntimeError::UnknownOwnedLocal { local })?;
        Ok(RuntimeOwnedSlotId::NativeDialogueLocal {
            execution: self.fiber.execution,
            activation: *activation,
            local: crate::runtime_id::RuntimeLocalSlotId::from_allocated(
                std::num::NonZeroU64::from(local.get()),
            ),
        })
    }
    fn owned_slot(
        &self,
        local: crate::runtime_id::RuntimeLocalDeclarationId,
    ) -> Result<RuntimeOwnedSlotId, LineRuntimeError> {
        self.plan
            .local_declarations()
            .get(local)
            .ok_or(LineRuntimeError::UnknownOwnedLocal { local })?;
        Ok(self
            .fiber
            .frame
            .owned_local_slot(self.fiber.execution, local))
    }
}

fn token_from_value(value: &RuntimeValue) -> Result<RuntimeLineHandleToken, LineRuntimeError> {
    let RuntimeValue::Opaque(value) = value else {
        return Err(LineRuntimeError::WrongOpaqueProducer);
    };
    RuntimeLineHandleToken::try_decode_payload(value.payload())
        .map_err(|_| LineRuntimeError::InvalidHandlePayload)
}

fn advance_activation_pc(state: &mut DialogueActivationFrame) -> Result<(), LineRuntimeError> {
    state.activation_pc = state
        .activation_pc
        .checked_add(1)
        .ok_or(LineRuntimeError::ActivationProgramCounterOverflow)?;
    Ok(())
}

pub(super) fn unique_affine_line_handles(
    value: &RuntimeValue,
) -> Result<Vec<crate::value::ownership::RuntimeAffineLineHandle>, LineRuntimeError> {
    let handles = value
        .view()
        .line_handle_projection()
        .map_err(|_| LineRuntimeError::InvalidHandlePayload)?;
    let mut tokens = std::collections::BTreeSet::new();
    for handle in &handles {
        if !tokens.insert(handle.token().clone()) {
            return Err(LineRuntimeError::DuplicateHandleOccurrence);
        }
    }
    Ok(handles)
}

fn value_contains_token(
    value: &RuntimeValue,
    token: &RuntimeLineHandleToken,
) -> Result<bool, LineRuntimeError> {
    Ok(unique_affine_line_handles(value)?
        .iter()
        .any(|handle| handle.token() == token))
}

fn preview_result_destination_local(
    pattern: &crate::pattern::RuntimePattern,
    value: &RuntimeValue,
    token: &RuntimeLineHandleToken,
) -> Result<Option<crate::runtime_id::RuntimeLocalDeclarationId>, LineRuntimeError> {
    let destinations = crate::pattern::runtime_pattern_handle_destinations(pattern, value, token)
        .map_err(|_| LineRuntimeError::InvalidHandlePayload)?;
    match destinations.as_slice() {
        [] => Ok(None),
        [local] => Ok(Some(*local)),
        _ => Err(LineRuntimeError::DuplicateHandleOccurrence),
    }
}

fn flush_commands(
    activation_id: &crate::runtime_id::DialogueActivationId,
    activation: &mut NativeDialogueActivationState,
    commands: RuntimeCommandQueue,
) -> Result<(), LineRuntimeError> {
    activation.record_commands(activation_id, commands)
}

fn require_issued_command(
    activation_id: &crate::runtime_id::DialogueActivationId,
    activation: &NativeDialogueActivationState,
    command: &crate::presentation::RuntimeLineCommandId,
) -> Result<(), LineRuntimeError> {
    if command.activation() != activation_id || activation.issued_command(command).is_none() {
        return Err(LineRuntimeError::UnknownCommandOutcome);
    }
    Ok(())
}

fn pending_command_id(
    state: &DialogueActivationFrame,
) -> Option<&crate::presentation::RuntimeLineCommandId> {
    match state.pending_line_operation.as_ref()? {
        PendingLineOperation::AcquireActor { command, .. }
        | PendingLineOperation::ActorLook { command, .. }
        | PendingLineOperation::StartVoice { command, .. } => Some(command),
    }
}

fn clear_pending_command(
    state: &mut DialogueActivationFrame,
    command: &crate::presentation::RuntimeLineCommandId,
) {
    if pending_command_id(state).is_some_and(|pending| pending == command) {
        state.pending_line_operation = None;
    }
}

fn fail_issued_command_lease(
    ledger: &mut crate::line_task::RuntimeLineHandleLedger,
    command: &crate::presentation::RuntimeLineHostCommand,
) -> Result<(), LineRuntimeError> {
    let token = match command {
        crate::presentation::RuntimeLineHostCommand::Stage(command) => match command {
            crate::presentation::RuntimeStageCommand::AcquireActor { actor, .. }
            | crate::presentation::RuntimeStageCommand::ReleaseActor { actor, .. } => Some(actor),
            crate::presentation::RuntimeStageCommand::SetCharacterLook { cue, .. }
            | crate::presentation::RuntimeStageCommand::CancelCue { cue, .. } => Some(cue),
        },
        crate::presentation::RuntimeLineHostCommand::Voice(command) => match command {
            crate::presentation::RuntimeVoiceCommand::StartDialogueVoice { .. } => None,
            crate::presentation::RuntimeVoiceCommand::ReleaseDialogueVoice { handle, .. } => {
                Some(handle)
            }
        },
    };
    let Some(token) = token else {
        return Ok(());
    };
    let state_before = ledger
        .lease(token)
        .ok_or(LineRuntimeError::UnknownHandle)?
        .state();
    if state_before == RuntimeHandleLeaseState::Released {
        return Ok(());
    }
    ledger.set_state(token, state_before, RuntimeHandleLeaseState::Failed)?;
    ledger.set_state(
        token,
        RuntimeHandleLeaseState::Failed,
        RuntimeHandleLeaseState::Released,
    )
}

#[cfg(test)]
mod tests {
    use super::{
        ActivationScopeStep, DialogueActivationFrame, DialogueActivationScope,
        DialogueLineTaskState, DialogueRuntimePhase, Engine,
    };
    use crate::effect::{RuntimeDropPolicyExpr, RuntimeEffectExpr};
    use crate::line_task::{
        ChildCancelPolicy, ChildJoinPolicy, LineTaskActivation, LineTaskCleanup, LineTaskCommand,
        LineTaskExitPolicy, LineTaskGroup, LineTaskWorkTag, RuntimeCueLease, RuntimeCueOrigin,
        RuntimeDeferOutcomeFilter, RuntimeDialogueActivationState, RuntimeHandleLeaseState,
        RuntimeHandleOwnerSlot, RuntimeHandleResource, RuntimeLineHandleLedger,
        RuntimeLineHandleSite, RuntimeLineHandleSiteKind, RuntimeStageActorLease, ScopeExit,
    };
    use crate::pattern::{
        RuntimeOpaqueTypeAdmission, RuntimeOpaqueTypeOwner, RuntimePattern,
        RuntimePatternBindingCoordinate, RuntimePatternBindingPath, RuntimePatternBindingStep,
        RuntimePatternKind, RuntimeSemanticTypeId,
    };
    use crate::plan::{
        RuntimeDialogueResultTarget, RuntimeEffectSet, RuntimeExecutableBodySeed,
        RuntimeFlowOpSeed, RuntimeFunctionSiteBodyKind, RuntimeFunctionSiteBodySeed,
        RuntimeFunctionSiteDeclarationSeed, RuntimeLocalDeclarationSeed, RuntimePlanBuilder,
        RuntimePlanTypeProjection, RuntimePlanTypeSeed,
    };
    use crate::pure::VmRuntimePureCallBackend;
    use crate::runtime_id::{
        DialogueActivationId, RuntimeDialogueContentPlanId, RuntimeLineHandleSiteId,
        RuntimeLineTaskGroupId, RuntimeLineTaskNodeId, RuntimeLocalDeclarationId,
        RuntimePersistentFiberId, RuntimePlanTypeId,
    };
    use crate::time::LogicalDuration;
    use crate::value::{
        RuntimeExpr, RuntimeExprKind, RuntimeHandleKind, RuntimeLocalBinding,
        RuntimeOpaquePersistence, RuntimeOpaqueValueClass, RuntimeValue,
    };
    use std::num::NonZeroU32;

    fn activation_id() -> DialogueActivationId {
        DialogueActivationId::new(
            crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x5e; 32])
                .expect("artifact"),
            RuntimePersistentFiberId::from_allocated(1),
            RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            0,
        )
    }

    #[test]
    fn invalid_later_cancel_keeps_the_scheduled_affine_packet_in_line_custody() {
        let plan = RuntimePlanBuilder::new().finish().expect("empty plan");
        let mut engine = Engine::new(plan);
        let activation = activation_id();
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        engine
            .dialogue_activations
            .begin(activation.clone(), activation_frame(&engine, local))
            .expect("activation");
        let mut transaction = engine
            .dialogue_activations
            .begin_transaction(&activation)
            .expect("sole owner");
        let child = RuntimeLineTaskNodeId::from_zero_based(1).expect("child");
        let scope = RuntimeLineTaskNodeId::from_zero_based(2).expect("scope");
        let deadline = LogicalDuration::from_nanos(7);
        let site = RuntimeLineHandleSite::new(
            RuntimeLineHandleSiteId::from_zero_based(0),
            0,
            RuntimeLineHandleSiteKind::ScheduledCue,
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            None,
            Some(child),
            RuntimeOpaqueTypeOwner::exact_with(
                RuntimeHandleKind::Cue.try_producer().expect("cue producer"),
                RuntimeSemanticTypeId::from_bytes([0x79; 32]),
                RuntimeOpaqueValueClass::AffineHandle(RuntimeHandleKind::Cue),
                RuntimeOpaquePersistence::SnapshotOnly,
            ),
        )
        .expect("scheduled cue site");
        let mut ledger = transaction.line().ledger().clone();
        let cue_value = RuntimeValue::Opaque(
            ledger
                .issue(
                    &activation,
                    &site,
                    RuntimeHandleResource::Cue(RuntimeCueLease::new(RuntimeCueOrigin::Scheduled {
                        child,
                        deadline,
                    })),
                    RuntimeHandleOwnerSlot::LineScope,
                )
                .expect("cue lease"),
        );
        let token = super::token_from_value(&cue_value).expect("cue token");
        transaction.line_mut().commit_ledger(ledger);
        let work = LineTaskWorkTag::scheduled(token.clone(), scope);
        let proof = transaction
            .line()
            .inspect_schedule(&token, child, &work, deadline, &[local])
            .expect("schedule proof");
        let need = crate::tests::reusable_need("need.native.scheduled.capture");
        transaction.line_mut().schedule_prepared(
            proof,
            vec![RuntimeLocalBinding {
                local,
                value: RuntimeValue::NeedHandle(need.clone()),
            }]
            .into_boxed_slice(),
        );
        let group = LineTaskGroup::new(
            crate::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity([71; 32]),
            crate::plan::RuntimeEffectSet::empty(),
            Box::new([]),
            Box::new([]),
            Box::new([]),
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            Box::new([]),
            scope,
            Box::new([]),
            Box::new([]),
            LineTaskCleanup::default(),
        );
        transaction
            .line_mut()
            .advance_schedules(
                deadline,
                &mut crate::line_task::LineTaskLiveState::new(&group, activation),
            )
            .expect("running packet");
        let activation_step = LineTaskActivation {
            commands: vec![
                LineTaskCommand::Run {
                    tag: work.clone(),
                    policy: LineTaskExitPolicy {
                        join: ChildJoinPolicy::Join,
                        cancel: ChildCancelPolicy::Detach,
                    },
                },
                LineTaskCommand::Cancel { tag: work },
            ],
            scheduled_completions: Vec::new(),
        };
        assert!(
            engine
                .prepare_line_task_commands(&mut transaction, activation_step, &[], false)
                .is_err()
        );
        assert!(matches!(
            transaction.line().scheduled_packet_for_child(&token),
            Ok([RuntimeLocalBinding { value: RuntimeValue::NeedHandle(actual), .. }]) if actual == &need
        ));
        assert!(engine.child_fibers.is_empty());
    }

    fn scoped_defer_engine() -> (Engine, crate::runtime_id::RuntimeDeferSiteId) {
        let unit = RuntimeSemanticTypeId::from_bytes([0x71; 32]);
        let mut builder = RuntimePlanBuilder::new();
        builder
            .admit_type_batch(
                [RuntimePlanTypeSeed::new(
                    unit,
                    RuntimePlanTypeProjection::Unit,
                )],
                [],
            )
            .expect("unit type");
        let function = builder
            .reserve_function_site_seed(RuntimeFunctionSiteDeclarationSeed {
                definition: crate::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity(
                    [41; 32],
                ),
                role: crate::plan::RuntimeFunctionSemanticRole::Effect,
                function_type: None,
                inputs: Box::new([]),
                result: unit,
                body_kind: RuntimeFunctionSiteBodyKind::Executable,
                effects: RuntimeEffectSet::empty(),
            })
            .expect("defer body");
        builder
            .define_function_site_seed(
                &function,
                RuntimeFunctionSiteBodySeed::Executable(RuntimeExecutableBodySeed {
                    effects: RuntimeEffectSet::empty(),
                    ops: Box::new([RuntimeFlowOpSeed::Noop]),
                }),
            )
            .expect("defer body definition");
        let site = builder
            .reserve_defer_site_seed(&function)
            .expect("defer site");
        (Engine::new(builder.finish().expect("plan")), site)
    }

    fn activation_frame(
        engine: &Engine,
        local: RuntimeLocalDeclarationId,
    ) -> DialogueActivationFrame {
        let ty = RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN);
        let mut locals = crate::value::RuntimeEnv::default();
        locals.set(local, RuntimeValue::Unit);
        DialogueActivationFrame {
            parent: crate::engine::FlowFiberId::default(),
            line: crate::plan::RuntimeLineId::from_runtime_line_value("line.fixture")
                .expect("line"),
            content: RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            target: Some(crate::value::RuntimeOpaqueValue::new_exact(
                &crate::pattern::RuntimeOpaqueTypeOwner::exact(
                    crate::value::RuntimeCharacterDialogueProducerId::get(),
                    crate::pattern::RuntimeSemanticTypeId::from_bytes([0x47; 32]),
                ),
                RuntimeValue::Unit,
            )),
            task_group: RuntimeLineTaskGroupId::from_zero_based(0).expect("group"),
            task_inputs: Box::new([]),
            execution: crate::engine::NativeFlowExecutionFrame::running(
                crate::task::RuntimeProgramOwner::Plan(engine.program_plan()),
                locals,
            ),
            line_task: DialogueLineTaskState::NotStarted,
            elapsed: LogicalDuration::default(),
            phase: DialogueRuntimePhase::Activating,
            result_target: RuntimeDialogueResultTarget::new(
                ty,
                RuntimePattern::from_admitted_parts(ty, RuntimePatternKind::Discard),
            ),
            voice: crate::presentation::RuntimeDialogueVoiceState::Absent,
            values: Box::new([]),
            effect_callbacks: Box::new([]),
            activation_pc: 0,
            exiting_for_result: false,
            scopes: Vec::new(),
            pending_scope_result: None,
            pending_line_operation: None,
            pending_host_call: None,
            failure: None,
        }
    }

    #[test]
    fn withdrawn_dialogue_frame_shares_the_parent_rollback_budget() {
        use crate::entry::RuntimeSchemaLimits;
        use crate::task::RuntimeProgramOwner;

        let mut engine = Engine::new(RuntimePlanBuilder::new().finish().unwrap());
        let owner = RuntimeProgramOwner::Plan(engine.program_plan());
        let activation = DialogueActivationId::new(
            crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x5e; 32]).unwrap(),
            engine.fiber.persistent_id,
            RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            0,
        );
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let parent_value = RuntimeValue::String("p".repeat(1024));
        let child_value = RuntimeValue::String("c".repeat(1024));
        let mut frame = activation_frame(&engine, local);
        frame.parent = engine.fiber.id;
        frame.target = None;
        frame.execution.env = crate::value::RuntimeEnv::default();
        frame.task_inputs = Box::new([RuntimeLocalBinding {
            local,
            value: child_value.clone(),
        }]);
        engine.fiber.frame.selected_dialogue_result = Some(parent_value.clone());
        engine
            .dialogue_activations
            .begin(activation, frame)
            .unwrap();
        let transaction = engine
            .dialogue_activations
            .begin_transaction(&activation)
            .unwrap();

        let full_limits = RuntimeSchemaLimits::engine_default();
        let low_limits = RuntimeSchemaLimits {
            max_encoded_bytes: 1536,
            ..full_limits
        };
        let live_failure = engine
            .inert_rollback_image_with_dialogue(Some(&transaction), low_limits)
            .err()
            .expect("two individually admissible roots exceed their shared session allowance");
        assert!(live_failure.contains("encoded_bytes"), "{live_failure}");
        let (image, _) = engine
            .inert_rollback_image_with_dialogue(Some(&transaction), full_limits)
            .unwrap();
        let restore_failure = image.admit_rollback_values(&owner, low_limits).unwrap_err();
        assert!(
            restore_failure.contains("encoded_bytes"),
            "{restore_failure}"
        );
        assert_eq!(transaction.frame().task_inputs[0].value, child_value);
        let mut restored = Engine::from_rollback_image(image, &owner).unwrap();
        assert_eq!(
            restored.fiber.frame.selected_dialogue_result,
            Some(parent_value)
        );
        let restored = restored
            .dialogue_activations
            .begin_transaction(&activation)
            .unwrap();
        assert_eq!(restored.frame().task_inputs[0].value, child_value);
    }

    #[test]
    fn inline_dialogue_reads_the_reached_line_and_its_suspended_flow() {
        use crate::effect::{
            RuntimeRegistryOwner, RuntimeRegistryReadKind, RuntimeRegistryWriteSource,
            RuntimeScopeRegistry,
        };
        use crate::entry::RuntimeSchemaLimits;
        use crate::task::RuntimeProgramOwner;
        use crate::value::{RuntimeEnv, RuntimeRetainedValueAdmission};
        use arcweft_id::{DeclarationName, LifetimeRegistryKey, LifetimeScopeKind};

        let (plan, flow) = super::super::registry::tests::flow_registry_plan(true);
        let mut engine = Engine::for_flow(plan, &flow).unwrap();
        for _ in 0..2 {
            let step = engine.step(Default::default(), Default::default());
            assert_eq!(step.stats.executed_ops, 1);
            assert!(step.output.diagnostics.is_empty(), "{step:?}");
        }
        let boolean = crate::pattern::RuntimeCheckedType::Bool.semantic_identity_digest();
        let ty = engine.plan.type_table().id_for_semantic(boolean).unwrap();
        let owner = RuntimeProgramOwner::Plan(engine.program_plan());
        let activation = DialogueActivationId::new(
            crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x5e; 32]).unwrap(),
            engine.fiber.persistent_id,
            RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            0,
        );
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let mut frame = activation_frame(&engine, local);
        frame.parent = engine.fiber.id;
        frame.target = None;
        frame.execution.env = RuntimeEnv::default();
        engine.fiber.frame.selected_dialogue_result = Some(RuntimeValue::String("p".repeat(1024)));
        frame.execution.selected_dialogue_result = Some(RuntimeValue::String("e".repeat(1024)));
        frame.task_inputs = Box::new([RuntimeLocalBinding {
            local,
            value: RuntimeValue::String("a".repeat(1024)),
        }]);
        engine
            .dialogue_activations
            .begin(activation, frame)
            .unwrap();
        let mut transaction = engine
            .dialogue_activations
            .begin_transaction(&activation)
            .unwrap();
        let key = |scope| {
            LifetimeRegistryKey::new(scope, Box::new([DeclarationName::try_new("flag").unwrap()]))
        };
        let flow_key = key(LifetimeScopeKind::Flow);
        let line_key = key(LifetimeScopeKind::Line);
        let write =
            |rows: &mut RuntimeScopeRegistry, key: &LifetimeRegistryKey, scope, source, flag| {
                let mut admission = RuntimeRetainedValueAdmission::for_program(
                    owner.clone(),
                    RuntimeSchemaLimits::engine_default(),
                );
                rows.prepare_write(scope, key, boolean, None, source, &mut admission)
                    .unwrap()
                    .capture(&RuntimeValue::Bool(flag))
                    .unwrap()
                    .commit(rows)
                    .unwrap();
            };
        write(
            transaction.line_mut().line_registry_mut().unwrap(),
            &line_key,
            RuntimeRegistryOwner::Dialogue(activation),
            RuntimeRegistryWriteSource::NativeLine { activation },
            true,
        );

        let mut slot = super::DialogueActivationExecutionSlot(Some(transaction));
        let mut backend = VmRuntimePureCallBackend::default();
        for (key, expected) in [(&flow_key, false), (&line_key, true)] {
            let limits = RuntimeSchemaLimits::engine_default();
            for (limit, should_pass) in [(2500, false), (3300, true)] {
                let result = engine
                    .with_inline_dialogue(&mut slot, |engine| {
                        engine.read_registry_value(
                            key,
                            RuntimeRegistryReadKind::Required,
                            ty,
                            RuntimeSchemaLimits {
                                max_encoded_bytes: limit,
                                ..limits
                            },
                        )
                    })
                    .unwrap();
                if should_pass {
                    assert_eq!(result, Ok(RuntimeValue::Bool(expected)));
                } else {
                    let error = result.unwrap_err();
                    assert!(matches!(
                        error,
                        super::RuntimeEvalError::RegistryReadAdmission(_)
                    ));
                    assert!(error.to_string().contains("encoded_bytes"), "{error}");
                }
            }
            let expression = RuntimeExpr::from_admitted_parts(
                ty,
                RuntimeExprKind::RegistryRead {
                    key: key.clone(),
                    kind: RuntimeRegistryReadKind::Required,
                },
            );
            assert_eq!(
                engine.evaluate_dialogue_expr(&mut slot, &expression, &mut backend),
                Ok(RuntimeValue::Bool(expected)),
            );
        }
        engine
            .with_inline_dialogue(&mut slot, |engine| {
                let nested = DialogueActivationId::new(
                    crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x5e; 32]).unwrap(),
                    engine.fiber.persistent_id,
                    RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
                    1,
                );
                let mut frame = activation_frame(engine, local);
                frame.parent = engine.fiber.id;
                frame.target = None;
                frame.execution.env = RuntimeEnv::default();
                frame.execution.selected_dialogue_result =
                    Some(RuntimeValue::String("n".repeat(1024)));
                engine.dialogue_activations.begin(nested, frame).unwrap();
                let mut transaction = engine
                    .dialogue_activations
                    .begin_transaction(&nested)
                    .unwrap();
                write(
                    transaction.line_mut().line_registry_mut().unwrap(),
                    &line_key,
                    RuntimeRegistryOwner::Dialogue(nested),
                    RuntimeRegistryWriteSource::NativeLine { activation: nested },
                    false,
                );
                let mut nested_slot = super::DialogueActivationExecutionSlot(Some(transaction));
                let limits = RuntimeSchemaLimits::engine_default();
                let (image, _) = engine
                    .inert_rollback_image_with_dialogue(Some(nested_slot.transaction()), limits)
                    .unwrap();
                engine.fiber.frame.selected_dialogue_result = None;
                nested_slot
                    .transaction_mut()
                    .frame_mut()
                    .execution
                    .selected_dialogue_result = None;
                let failure = super::DialogueExecutionError::ActivationEffectFailed {
                    message: "registry operation failed".into(),
                };
                assert_eq!(
                    engine.restore_failed_dialogue_instruction(
                        nested_slot.transaction_mut(),
                        image,
                        &owner,
                        failure.clone(),
                    ),
                    failure,
                );
                assert_eq!(
                    engine.fiber.frame.selected_dialogue_result,
                    Some(RuntimeValue::String("e".repeat(1024))),
                );
                engine
                    .with_inline_dialogue(&mut nested_slot, |engine| {
                        let image = engine.inert_rollback_image().unwrap();
                        assert!(
                            image
                                .admit_rollback_values(
                                    &owner,
                                    RuntimeSchemaLimits {
                                        max_encoded_bytes: 3500,
                                        ..limits
                                    }
                                )
                                .unwrap_err()
                                .contains("encoded_bytes"),
                            "all three execution owners use one retained budget",
                        );
                        engine.dialogue_activations.inline_stack[0]
                            .frame_mut()
                            .execution
                            .selected_dialogue_result = None;
                        engine.dialogue_activations.inline_stack[1]
                            .frame_mut()
                            .execution
                            .selected_dialogue_result = None;
                        engine.fiber.frame.selected_dialogue_result = None;
                        *engine = Engine::from_rollback_image(image, &owner).unwrap();
                        assert_eq!(
                            engine.fiber.frame.selected_dialogue_result,
                            Some(RuntimeValue::String("n".repeat(1024))),
                        );
                        for key in [&line_key, &flow_key] {
                            let result = engine.read_registry_value(
                                key,
                                RuntimeRegistryReadKind::Required,
                                ty,
                                RuntimeSchemaLimits {
                                    max_encoded_bytes: 3500,
                                    ..RuntimeSchemaLimits::engine_default()
                                },
                            );
                            let error = result.unwrap_err();
                            assert!(error.to_string().contains("encoded_bytes"), "{error}");
                            assert_eq!(
                                engine.read_registry_value(
                                    key,
                                    RuntimeRegistryReadKind::Required,
                                    ty,
                                    RuntimeSchemaLimits {
                                        max_encoded_bytes: 4600,
                                        ..RuntimeSchemaLimits::engine_default()
                                    },
                                ),
                                Ok(RuntimeValue::Bool(false)),
                            );
                        }
                    })
                    .unwrap();
                assert_eq!(
                    nested_slot
                        .transaction()
                        .frame()
                        .execution
                        .selected_dialogue_result,
                    Some(RuntimeValue::String("n".repeat(1024))),
                );
                assert_eq!(
                    engine.fiber.frame.selected_dialogue_result,
                    Some(RuntimeValue::String("e".repeat(1024))),
                );
                engine
                    .dialogue_activations
                    .commit_transaction(nested_slot.0.take().unwrap())
                    .unwrap();
                assert_eq!(
                    engine.read_registry_value(
                        &line_key,
                        RuntimeRegistryReadKind::Required,
                        ty,
                        RuntimeSchemaLimits::engine_default(),
                    ),
                    Ok(RuntimeValue::Bool(true)),
                );
            })
            .unwrap();
        assert!(engine.dialogue_activations.inline_stack.is_empty());
        assert_eq!(
            engine.fiber.frame.selected_dialogue_result,
            Some(RuntimeValue::String("p".repeat(1024))),
        );
        assert!(
            slot.transaction()
                .frame()
                .execution
                .env
                .flow_registry()
                .is_none()
        );
        assert!(engine.fiber.frame.env.flow_registry().is_some());
    }

    #[test]
    fn dialogue_drop_source_take_is_committed_with_registry_revision() {
        let plan = RuntimePlanBuilder::new().finish().expect("empty plan");
        let mut engine = Engine::new(plan);
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let activation = DialogueActivationId::new(
            crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x5e; 32])
                .expect("artifact"),
            RuntimePersistentFiberId::from_allocated(1),
            RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            0,
        );
        engine
            .dialogue_activations
            .begin(activation.clone(), activation_frame(&engine, local))
            .expect("activation");
        let owner = engine
            .dialogue_activations
            .begin_transaction(&activation)
            .expect("sole dialogue owner");
        let effect = RuntimeEffectExpr::Drop {
            target: RuntimeExpr::from_admitted_parts(
                RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
                RuntimeExprKind::Local(crate::value::RuntimeLocalRead::from_admitted_parts(
                    local,
                    crate::value::RuntimeLocalReadMode::Move,
                )),
            ),
            policy: RuntimeDropPolicyExpr::Default,
        };
        let mut pure = VmRuntimePureCallBackend::default();
        let mut slot = super::DialogueActivationExecutionSlot(Some(owner));
        engine
            .execute_dialogue_evaluated_effect(&activation, &mut slot, &effect, &mut pure)
            .expect("drop candidate");
        let mut owner = slot.0.take().unwrap();
        assert!(owner.frame().execution.env.get(local).is_none());
        owner.frame_mut().execution.env.push_scope();
        owner
            .frame_mut()
            .scopes
            .push(DialogueActivationScope::new());
        assert_eq!(
            engine.dialogue_activations.begin_transaction(&activation),
            Err(crate::line_task::LineRuntimeError::StaleActivationTransaction)
        );
        engine
            .dialogue_activations
            .commit_transaction(owner)
            .expect("sole owner commits its drop and scope");
        let live = engine
            .dialogue_activations
            .begin_transaction(&activation)
            .expect("live frame");
        assert_eq!(live.frame().execution.env.get(local), None);
        assert_eq!(live.frame().scopes.len(), 1);
        assert!(engine.fiber.frame.env.get(local).is_none());
    }

    #[test]
    fn init_scope_deferred_children_run_lifo_with_frozen_completion_filter() {
        let (engine, site) = scoped_defer_engine();
        let id = activation_id();
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let mut frame = activation_frame(&engine, local);
        frame.execution.env.push_scope();
        frame.scopes.push(DialogueActivationScope::new());
        let mut line = RuntimeDialogueActivationState::new();
        let first = line
            .allocate_deferred_registration(site, RuntimeDeferOutcomeFilter::Completed, vec![])
            .expect("first reached defer");
        let second = line
            .allocate_deferred_registration(site, RuntimeDeferOutcomeFilter::Completed, vec![])
            .expect("second reached defer");
        let failed = line
            .allocate_deferred_registration(site, RuntimeDeferOutcomeFilter::Failed, vec![])
            .expect("failed-only defer");
        let first_id = first.id();
        let second_id = second.id();
        frame.scopes[0]
            .deferred
            .extend([first, second, failed].map(|packet| {
                crate::engine::defer::NativeLexicalDeferred {
                    packet,
                    source: crate::engine::defer::NativeDeferSource::Activation,
                }
            }));
        let ty = RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN);
        line.commit_result(ty, RuntimeValue::Unit)
            .expect("result staged before scope exit");

        let ActivationScopeStep::Deferred(_, _) = engine
            .prepare_activation_scope_exit(&id, &mut frame, &mut line, ScopeExit::Completed)
            .expect("first scope step")
        else {
            panic!("the last matching registration must run first");
        };
        assert_eq!(
            frame.scopes[0]
                .inflight
                .as_ref()
                .map(|row| (row.id, row.site)),
            Some((second_id, site))
        );
        assert_eq!(frame.scopes[0].exit, Some(ScopeExit::Completed));
        line.complete_scoped_deferred_child(&id, second_id, &Default::default())
            .expect("second child closes");
        frame.scopes[0].inflight = None;

        let ActivationScopeStep::Deferred(_, _) = engine
            .prepare_activation_scope_exit(&id, &mut frame, &mut line, ScopeExit::Failed)
            .expect("frozen scope step")
        else {
            panic!("earlier completion registration must run next");
        };
        assert_eq!(
            frame.scopes[0]
                .inflight
                .as_ref()
                .map(|row| (row.id, row.site)),
            Some((first_id, site))
        );
        assert_eq!(frame.scopes[0].exit, Some(ScopeExit::Completed));
        line.complete_scoped_deferred_child(&id, first_id, &Default::default())
            .expect("first child closes");
        frame.scopes[0].inflight = None;

        assert!(matches!(
            engine.prepare_activation_scope_exit(&id, &mut frame, &mut line, ScopeExit::Failed),
            Ok(ActivationScopeStep::Finished(None))
        ));
        assert!(frame.scopes.is_empty());
        assert!(matches!(
            line.result(),
            crate::line_task::RuntimeDialogueResultState::Committed {
                value: RuntimeValue::Unit,
                ..
            }
        ));
    }

    #[test]
    fn init_out_unwinds_scope_without_resuming_later_plan_ops() {
        let plan = RuntimePlanBuilder::new().finish().expect("empty plan");
        let mut engine = Engine::new(plan);
        let id = activation_id();
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let mut frame = activation_frame(&engine, local);
        frame.execution.env.push_scope();
        frame.scopes.push(DialogueActivationScope::new());
        frame.activation_pc = 3;
        frame.exiting_for_result = true;
        engine
            .dialogue_activations
            .begin(id.clone(), frame)
            .expect("activation");
        let mut transaction = engine
            .dialogue_activations
            .begin_transaction(&id)
            .expect("transaction");
        transaction
            .line_mut()
            .commit_result(
                RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
                RuntimeValue::Unit,
            )
            .expect("staged result");

        let (transaction, result) = engine.resume_dialogue_activation(
            transaction,
            &[],
            &mut crate::step::RuntimeStepInput::default(),
            &[],
            &mut VmRuntimePureCallBackend::default(),
        );
        assert!(matches!(
            result,
            Ok(super::DialogueActivationStep::Continue)
        ));
        assert!(transaction.frame().scopes.is_empty());
        assert_eq!(transaction.frame().activation_pc, 3);
        assert!(matches!(
            transaction.line().result(),
            crate::line_task::RuntimeDialogueResultState::Committed { .. }
        ));
    }

    #[test]
    fn init_host_call_request_commits_before_reply_binds_continuation() {
        let unit = RuntimeSemanticTypeId::from_bytes([0x74; 32]);
        let mut builder = RuntimePlanBuilder::new();
        builder
            .admit_type_batch(
                [RuntimePlanTypeSeed::new(
                    unit,
                    RuntimePlanTypeProjection::Unit,
                )],
                [],
            )
            .expect("unit type");
        let mut engine = Engine::new(builder.finish().expect("plan"));
        let id = activation_id();
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        let mut frame = activation_frame(&engine, local);
        frame.activation_pc = 2;
        let call_id = crate::step::RuntimeHostCallId("init.log".to_owned());
        frame.pending_host_call = Some(super::PendingActivationHostCall {
            id: call_id.clone(),
            result: RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            binding: None,
        });
        engine
            .dialogue_activations
            .begin(id.clone(), frame)
            .expect("activation");
        let transaction = engine
            .dialogue_activations
            .begin_transaction(&id)
            .expect("transaction");
        let request = engine
            .admit_host_call(crate::step::RuntimeHostCallStart {
                id: call_id.clone(),
                producer: crate::tests::host_producer(),
                request: crate::task::HostTaskRequest::custom("log", "info", []),
                result: unit,
                mode: crate::step::RuntimeHostCallMode::Suspend,
                deterministic: true,
            })
            .unwrap();
        let mut output = crate::step::RuntimeStepOutput::default();
        engine.commit_and_suspend_dialogue(
            transaction,
            &mut output,
            super::DialogueActivationStep::HostCall(Box::new(request.clone())),
        );
        assert_eq!(output.requests.host_calls, vec![request]);
        let transaction = engine
            .dialogue_activations
            .begin_transaction(&id)
            .expect("committed host call");
        let reply = crate::step::RuntimeHostCallResult {
            id: call_id,
            outcome: Ok(crate::value::RuntimePayload::from(RuntimeValue::Unit)),
        };
        let (transaction, result) = engine.resume_dialogue_activation(
            transaction,
            &[],
            &mut crate::step::RuntimeStepInput {
                host_call_results: vec![reply],
                ..crate::step::RuntimeStepInput::default()
            },
            &[],
            &mut VmRuntimePureCallBackend::default(),
        );
        assert!(matches!(
            result,
            Ok(super::DialogueActivationStep::Continue)
        ));
        assert!(transaction.frame().pending_host_call.is_none());
        assert_eq!(transaction.frame().activation_pc, 3);
    }

    #[test]
    fn init_evaluated_log_effect_publishes_after_activation_commit() {
        let plan = RuntimePlanBuilder::new().finish().expect("empty plan");
        let mut engine = Engine::new(plan);
        let id = activation_id();
        let local = RuntimeLocalDeclarationId::from_accepted_ordinal(NonZeroU32::MIN);
        engine
            .dialogue_activations
            .begin(id.clone(), activation_frame(&engine, local))
            .expect("activation");
        let transaction = engine
            .dialogue_activations
            .begin_transaction(&id)
            .expect("transaction");
        let effect = RuntimeEffectExpr::Log {
            level: "info".to_owned(),
            message: RuntimeExpr::from_admitted_parts(
                RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
                RuntimeExprKind::Value(RuntimeValue::String("line init".to_owned())),
            ),
            fields: Vec::new(),
        };
        let mut slot = super::DialogueActivationExecutionSlot(Some(transaction));
        let request = engine
            .execute_dialogue_evaluated_effect(
                &id,
                &mut slot,
                &effect,
                &mut VmRuntimePureCallBackend::default(),
            )
            .expect("evaluated effect")
            .expect("log request");
        assert!(matches!(request, crate::effect::LineEffectRequest::Log(_)));
        let mut output = crate::step::RuntimeStepOutput::default();
        engine.commit_and_suspend_dialogue(
            slot.0.take().unwrap(),
            &mut output,
            super::DialogueActivationStep::Effect(request.clone()),
        );
        assert_eq!(output.effects.line, vec![request]);
        assert!(engine.dialogue_activations.begin_transaction(&id).is_ok());
    }

    #[test]
    fn init_scope_let_and_assignment_move_custody_and_journal_exact_release() {
        let actor_type = RuntimeSemanticTypeId::from_bytes([0x73; 32]);
        let producer = crate::value::RuntimeHandleKind::StageActor
            .try_producer()
            .expect("producer");
        let mut builder = RuntimePlanBuilder::new();
        let admitted = builder
            .admit_type_batch(
                [RuntimePlanTypeSeed::new(
                    actor_type,
                    RuntimePlanTypeProjection::Opaque {
                        producer: producer.clone(),
                        admission: RuntimeOpaqueTypeAdmission::ExactIdentity,
                        value_class: crate::value::RuntimeOpaqueValueClass::AffineHandle(
                            crate::value::RuntimeHandleKind::StageActor,
                        ),
                        persistence: crate::value::RuntimeOpaquePersistence::SnapshotOnly,
                        arguments: Box::new([]),
                    },
                )],
                [
                    RuntimeLocalDeclarationSeed::new(crate::engine::dialogue::manual_local_source("arcweft-core.fixture.engine.dialogue.init_scope_let_and_assignment_move_custody_and_journal_exact_release.binding_a"), actor_type),
                    RuntimeLocalDeclarationSeed::new(crate::engine::dialogue::manual_local_source("arcweft-core.fixture.engine.dialogue.init_scope_let_and_assignment_move_custody_and_journal_exact_release.binding_b"), actor_type),
                    RuntimeLocalDeclarationSeed::new(crate::engine::dialogue::manual_local_source("arcweft-core.fixture.engine.dialogue.init_scope_let_and_assignment_move_custody_and_journal_exact_release.binding_c"), actor_type),
                ],
            )
            .expect("local declaration");
        let locals = admitted
            .local_ids()
            .iter()
            .map(|local| {
                let pattern = builder
                    .lower_pattern_seed_for_test(crate::plan::RuntimePatternSeed::new(
                        actor_type,
                        crate::plan::RuntimePatternSeedKind::Bind {
                            mutable: true,
                            local: local.clone(),
                        },
                    ))
                    .unwrap();
                pattern.binding_declarations().next().unwrap().local()
            })
            .collect::<Vec<_>>();
        builder
            .declare_test_input_locals(admitted.local_ids())
            .unwrap();
        let mut engine = Engine::new(builder.finish().expect("plan"));
        let id = activation_id();
        let source = locals[0];
        let destination = locals[1];
        let mut frame = activation_frame(&engine, source);
        frame.execution.env = crate::value::RuntimeEnv::default();
        frame.execution.env.push_scope();
        frame.scopes.push(DialogueActivationScope::new());
        let character =
            arcweft_character::id::CharacterId::try_new("character.fixture").expect("character");
        let site = RuntimeLineHandleSite::new(
            RuntimeLineHandleSiteId::from_zero_based(0),
            0,
            RuntimeLineHandleSiteKind::StageActor,
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            Some(character.clone()),
            None,
            RuntimeOpaqueTypeOwner::exact_with(
                producer,
                actor_type,
                crate::value::RuntimeOpaqueValueClass::AffineHandle(
                    crate::value::RuntimeHandleKind::StageActor,
                ),
                crate::value::RuntimeOpaquePersistence::SnapshotOnly,
            ),
        )
        .expect("site");
        let mut ledger = RuntimeLineHandleLedger::default();
        let owner = RuntimeHandleOwnerSlot::ActivationLocal(
            engine.activation_slot(&id, source).expect("local owner"),
        );
        let actor = ledger
            .issue(
                &id,
                &site,
                RuntimeHandleResource::StageActor(RuntimeStageActorLease::new(character.clone())),
                owner,
            )
            .expect("actor issue");
        let token = crate::runtime_id::RuntimeLineHandleToken::try_decode_payload(actor.payload())
            .expect("actor token");
        ledger
            .set_state(
                &token,
                RuntimeHandleLeaseState::Allocating,
                RuntimeHandleLeaseState::Active,
            )
            .expect("actor acquired");
        frame.execution.env.set(source, RuntimeValue::Opaque(actor));
        engine.dialogue_activations.begin(id, frame).unwrap();
        let mut transaction = engine.dialogue_activations.begin_transaction(&id).unwrap();
        transaction.line_mut().commit_ledger(ledger);
        let mut slot = super::DialogueActivationExecutionSlot(Some(transaction));
        let path = RuntimePatternBindingPath::try_from_steps([RuntimePatternBindingStep::Whole])
            .expect("whole binding");
        let pattern = RuntimePattern::from_admitted_parts(
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            RuntimePatternKind::Bind {
                mutable: false,
                binding: RuntimePatternBindingCoordinate::from_admitted_parts(destination, path),
            },
        );
        let expr = RuntimeExpr::from_admitted_parts(
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            RuntimeExprKind::Local(crate::value::RuntimeLocalRead::from_admitted_parts(
                source,
                crate::value::RuntimeLocalReadMode::Move,
            )),
        );
        engine
            .bind_dialogue_let(
                &id,
                &mut slot,
                &pattern,
                &expr,
                &Default::default(),
                &mut VmRuntimePureCallBackend::default(),
            )
            .expect("affine let transfers owner");
        let (frame, line) = slot.transaction_mut().parts_mut();
        assert!(frame.execution.env.get(source).is_none());
        assert!(matches!(
            frame.execution.env.get(destination),
            Some(RuntimeValue::Opaque(_))
        ));
        assert_eq!(
            line.ledger().lease(&token).expect("lease").owner(),
            &RuntimeHandleOwnerSlot::ActivationLocal(
                engine
                    .activation_slot(&id, destination)
                    .expect("destination owner"),
            )
        );

        let incoming_local = locals[2];
        let mut ledger = line.ledger().clone();
        let incoming = ledger
            .issue(
                &id,
                &site,
                RuntimeHandleResource::StageActor(RuntimeStageActorLease::new(character)),
                RuntimeHandleOwnerSlot::ActivationLocal(
                    engine.activation_slot(&id, incoming_local).unwrap(),
                ),
            )
            .unwrap();
        let incoming_token =
            crate::runtime_id::RuntimeLineHandleToken::try_decode_payload(incoming.payload())
                .unwrap();
        ledger
            .set_state(
                &incoming_token,
                RuntimeHandleLeaseState::Allocating,
                RuntimeHandleLeaseState::Active,
            )
            .unwrap();
        line.commit_ledger(ledger);
        frame
            .execution
            .env
            .set(incoming_local, RuntimeValue::Opaque(incoming));
        let incoming_expr = RuntimeExpr::from_admitted_parts(
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            RuntimeExprKind::Local(crate::value::RuntimeLocalRead::from_admitted_parts(
                incoming_local,
                crate::value::RuntimeLocalReadMode::Move,
            )),
        );
        let before = engine
            .activation_local_handle_owners(&id, frame, line)
            .unwrap();
        let value = engine
            .evaluate_dialogue_expr(
                &mut slot,
                &incoming_expr,
                &mut VmRuntimePureCallBackend::default(),
            )
            .unwrap();
        let (frame, line) = slot.transaction_mut().parts_mut();
        frame
            .execution
            .env
            .assign_runtime_place(crate::value::RuntimeMutablePlace::Local(destination), value)
            .unwrap();
        engine
            .commit_activation_assignment_discards(&id, frame, line, &before, None)
            .unwrap();
        assert_eq!(
            line.ledger().lease(&token).unwrap().state(),
            RuntimeHandleLeaseState::Cancelling
        );
        assert_eq!(
            line.ledger().lease(&incoming_token).unwrap().owner(),
            &RuntimeHandleOwnerSlot::ActivationLocal(
                engine.activation_slot(&id, destination).unwrap()
            )
        );
        let commands = line.take_commit_receipt().into_commands();
        let [
            crate::presentation::RuntimeLineHostCommand::Stage(
                crate::presentation::RuntimeStageCommand::ReleaseActor { command, actor },
            ),
        ] = commands.as_slice()
        else {
            panic!("only the displaced actor is released");
        };
        assert_eq!(actor, &token);
        assert!(matches!(
            engine.prepare_activation_scope_exit(&id, frame, line, ScopeExit::Completed),
            Ok(ActivationScopeStep::Waiting(None))
        ));
        line.accept_runtime_outcome(&crate::presentation::RuntimeLineHostOutcome::Stage(
            crate::presentation::RuntimeStageCommandOutcome::ReleasedActor {
                command: command.clone(),
                actor: actor.clone(),
            },
        ))
        .unwrap();
        assert_eq!(
            line.ledger().lease(&token).unwrap().state(),
            RuntimeHandleLeaseState::Released
        );

        assert!(matches!(
            engine.prepare_activation_scope_exit(&id, frame, line, ScopeExit::Completed),
            Ok(ActivationScopeStep::Finished(None))
        ));
        assert!(frame.scopes.is_empty());
        assert!(frame.execution.env.get(source).is_none());
        assert!(frame.execution.env.get(destination).is_none());
        assert!(line.has_pending_commands());
        assert!(matches!(
            line.take_commit_receipt().into_commands().as_slice(),
            [crate::presentation::RuntimeLineHostCommand::Stage(
                crate::presentation::RuntimeStageCommand::ReleaseActor { .. }
            )]
        ));
    }
}

#[cfg(test)]
fn manual_local_source(declaration: &str) -> crate::plan::RuntimeLocalDeclarationSource {
    // This fixture declares a semantic binding name independent of its value,
    // type, source offset, and builder-issued local ordinal.
    let mut identity = blake3::Hasher::new();
    identity.update(b"arcweft.manual-fixture-binding.v1\0");
    identity.update(declaration.as_bytes());
    crate::plan::RuntimeLocalDeclarationSource::Binding {
        identity: *identity.finalize().as_bytes(),
        declaration: crate::plan::RuntimeLocalBindingDeclaration::new(
            crate::plan::RuntimeLocalBindingKind::PatternBinding,
            false,
            crate::plan::RuntimeLocalBindingStorage::Derived,
        ),
    }
}
