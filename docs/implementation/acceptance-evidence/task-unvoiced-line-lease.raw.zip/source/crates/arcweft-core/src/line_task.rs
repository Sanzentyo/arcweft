use crate::plan::FlowOp;
use crate::runtime_id::{
    DialogueActivationId, RuntimeDialogueMarkId, RuntimeLineHandleSiteId, RuntimeLineHandleToken,
    RuntimeLineTaskNodeId, RuntimeLocalDeclarationId, RuntimePlanTypeId,
};
use crate::step::{RuntimeDialogueContentEventKind, RuntimeDialogueInputActionEvent};
use crate::time::LogicalDuration;
use arcweft_interaction_model::input::InputActionId;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use thiserror::Error;

mod activation;
mod defer;
mod drop_authorization;
mod handle;
#[cfg(test)]
mod result_selection_tests;
pub(crate) mod semantic;
pub use semantic::LinePlanSemanticDigest;

pub use crate::scope::{RuntimeDeferOutcomeFilter, ScopeExit};
pub use defer::RuntimeLineDeferredRegistration;
pub(crate) use defer::{RuntimeDeferUnwindStep, RuntimeScopedDeferDecision};
pub(crate) use drop_authorization::RuntimeHandleDropAuthorization;

pub(crate) use activation::{
    PreparedRuntimeParentFiberReconciliation, RuntimeDialogueAbandonedCommitProof,
    RuntimeDialogueActivationRegistry, RuntimeDialogueActivationTransaction,
    RuntimeDialogueCommitProof, RuntimeDialoguePublishedCommitProof,
    RuntimeDialogueRegistryCommitReceipt, RuntimeDialogueRegistrySaveSnapshot,
    RuntimeDialogueRegistrySnapshotError, RuntimeDialogueRetainedContour,
    RuntimePublishedDialogueRegistry,
};
pub(crate) use defer::AwbcRuntimeDeferredRegistrationSnapshot;

pub(crate) use handle::{
    AwbcRuntimeDialogueActivationSnapshot, AwbcRuntimePublishedDialogueHandlesSnapshot,
    RuntimeDialogueCommitReceipt, RuntimeDialogueTerminalKind, RuntimeHandleDropReceipt,
    RuntimePreparedLineCommands, RuntimePreparedScheduledPacketTake,
    RuntimePreparedScopedDeferUnwind, RuntimePublishedDialogueHandles,
    RuntimeScheduledChildAdmissionProof, RuntimeScheduledCompletionStage,
    RuntimeVoiceLeaseAdmission,
};

pub use handle::{
    LineRuntimeError, MAX_LINE_HANDLE_SITES, MAX_LINE_LIVE_HANDLES, MAX_LINE_SCHEDULED_CALLBACKS,
    RuntimeCueLease, RuntimeCueOrigin, RuntimeDialogueActivationState, RuntimeDialogueResultState,
    RuntimeHandleLease, RuntimeHandleLeaseState, RuntimeHandleOwnerSlot, RuntimeHandleResource,
    RuntimeLineHandleLedger, RuntimeLineHandleScope, RuntimeLineHandleSite,
    RuntimeLineHandleSiteKind, RuntimeScheduledLineTask, RuntimeScheduledState,
    RuntimeStageActorLease, RuntimeVoiceLease,
};

/// Sealed, plan-owned task graph activated with one dialogue content plan.
///
/// The graph never carries host request spellings or raw effects. Its only
/// executable leaves are typed flow operations, evaluated by the native flow
/// executor in a child fiber with external captures and exact activation
/// exports, or a scheduled child's explicit capture packet.
#[derive(Clone, Debug, PartialEq)]
pub struct LineTaskGroup {
    definition: crate::plan::RuntimeFunctionDefinitionIdentity,
    effects: crate::plan::RuntimeEffectSet,
    initial_inputs: Box<[crate::value::RuntimeLocalRead]>,
    shared_inputs: Box<[RuntimeLocalDeclarationId]>,
    activation_ops: Box<[FlowOp]>,
    result_type: RuntimePlanTypeId,
    handle_sites: Box<[RuntimeLineHandleSite]>,
    root: RuntimeLineTaskNodeId,
    nodes: Box<[LineTaskNode]>,
    cancel_rules: Box<[LineCancelRule]>,
    cleanup: LineTaskCleanup,
}

impl LineTaskGroup {
    pub(crate) fn new(
        definition: crate::plan::RuntimeFunctionDefinitionIdentity,
        effects: crate::plan::RuntimeEffectSet,
        initial_inputs: Box<[crate::value::RuntimeLocalRead]>,
        shared_inputs: Box<[RuntimeLocalDeclarationId]>,
        activation_ops: Box<[FlowOp]>,
        result_type: RuntimePlanTypeId,
        handle_sites: Box<[RuntimeLineHandleSite]>,
        root: RuntimeLineTaskNodeId,
        nodes: Box<[LineTaskNode]>,
        cancel_rules: Box<[LineCancelRule]>,
        cleanup: LineTaskCleanup,
    ) -> Self {
        Self {
            definition,
            effects,
            initial_inputs,
            shared_inputs,
            activation_ops,
            result_type,
            handle_sites,
            root,
            nodes,
            cancel_rules,
            cleanup,
        }
    }

    #[must_use]
    pub const fn definition(&self) -> crate::plan::RuntimeFunctionDefinitionIdentity {
        self.definition
    }

    #[must_use]
    pub const fn effects(&self) -> &crate::plan::RuntimeEffectSet {
        &self.effects
    }

    #[must_use]
    pub const fn initial_inputs(&self) -> &[crate::value::RuntimeLocalRead] {
        &self.initial_inputs
    }

    #[must_use]
    pub const fn shared_inputs(&self) -> &[RuntimeLocalDeclarationId] {
        &self.shared_inputs
    }

    #[must_use]
    pub const fn activation_ops(&self) -> &[FlowOp] {
        &self.activation_ops
    }

    #[must_use]
    pub const fn result_type(&self) -> RuntimePlanTypeId {
        self.result_type
    }

    #[must_use]
    pub const fn handle_sites(&self) -> &[RuntimeLineHandleSite] {
        &self.handle_sites
    }

    #[must_use]
    pub fn handle_site(&self, id: RuntimeLineHandleSiteId) -> Option<&RuntimeLineHandleSite> {
        self.handle_sites.get(id.index())
    }

    #[must_use]
    pub const fn root(&self) -> RuntimeLineTaskNodeId {
        self.root
    }

    #[must_use]
    pub const fn nodes(&self) -> &[LineTaskNode] {
        &self.nodes
    }

    #[must_use]
    pub const fn cancel_rules(&self) -> &[LineCancelRule] {
        &self.cancel_rules
    }

    #[must_use]
    pub const fn cleanup(&self) -> &LineTaskCleanup {
        &self.cleanup
    }

    #[must_use]
    pub fn node(&self, id: RuntimeLineTaskNodeId) -> Option<&LineTaskNode> {
        self.nodes.get(id.index())
    }

    /// Resolves a reducer command to its original owning body. Missing commands
    /// are invalid coordinates, rather than successful empty instruction lists.
    #[must_use]
    pub(crate) fn command_code_body(
        &self,
        tag: &LineTaskWorkTag,
    ) -> Option<crate::plan::code::RuntimeLineCodeBody> {
        use crate::plan::code::RuntimeLineCodeBody;
        match tag.work() {
            LineTaskWork::Node(node) => match self.node(node) {
                Some(LineTaskNode::Action(_)) => Some(RuntimeLineCodeBody::Action(node)),
                _ => None,
            },
            LineTaskWork::Cancellation(action) => self
                .cancel_rules
                .iter()
                .position(|rule| rule.trigger == action)
                .map(|rule| RuntimeLineCodeBody::Cancellation { rule }),
            LineTaskWork::Cleanup(exit) => Some(RuntimeLineCodeBody::Cleanup(exit)),
            LineTaskWork::Defer(_) => None,
        }
    }
}

/// Read-only graph surface consumed by the common native/AWBC reducer.
/// Payload ownership is deliberately absent: executors map a command to their
/// own native ops or AWBC function body after reduction.
pub(crate) trait LineTaskPlanView {
    fn node_count(&self) -> usize;
    fn root_node(&self) -> RuntimeLineTaskNodeId;
    fn node_view(&self, id: RuntimeLineTaskNodeId) -> Option<LineTaskNodeView<'_>>;
    fn has_action(&self, node: RuntimeLineTaskNodeId) -> bool;
    fn cancellation_action(&self, actions: &[InputActionId]) -> Option<InputActionId>;
    fn has_cancellation_work(&self, action: &InputActionId) -> bool;
    fn has_cleanup(&self, exit: ScopeExit) -> bool;
    fn scheduled_child(&self, _site: RuntimeLineHandleSiteId) -> Option<RuntimeLineTaskNodeId> {
        None
    }
}

/// Typed, activation-scoped events that may arm line-task children during one
/// reducer step.
#[derive(Clone, Copy, Debug)]
pub(crate) struct LineTaskReadyEvents<'a> {
    marks: &'a BTreeSet<RuntimeDialogueMarkId>,
    input_actions: &'a [InputActionId],
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub(crate) struct AcceptedLineTaskContentEvents {
    marks: BTreeSet<RuntimeDialogueMarkId>,
}

impl AcceptedLineTaskContentEvents {
    pub(crate) const fn ready(&self) -> LineTaskReadyEvents<'_> {
        LineTaskReadyEvents::new(&self.marks)
    }
}

impl<'a> LineTaskReadyEvents<'a> {
    pub(crate) const fn new(marks: &'a BTreeSet<RuntimeDialogueMarkId>) -> Self {
        Self {
            marks,
            input_actions: &[],
        }
    }

    pub(crate) const fn with_input_actions(mut self, input_actions: &'a [InputActionId]) -> Self {
        self.input_actions = input_actions;
        self
    }

    const fn marks(self) -> &'a BTreeSet<RuntimeDialogueMarkId> {
        self.marks
    }

    const fn input_actions(self) -> &'a [InputActionId] {
        self.input_actions
    }
}

#[derive(Clone, Debug)]
pub(crate) enum LineTaskNodeView<'a> {
    Sequence(&'a [RuntimeLineTaskNodeId]),
    Start(&'a [RuntimeLineTaskNodeId]),
    Parallel(&'a [RuntimeLineTaskNodeId]),
    Child {
        trigger: LineTaskTrigger,
        policy: LineTaskExitPolicy,
        scope: RuntimeLineTaskNodeId,
    },
    Action,
}

impl LineTaskPlanView for LineTaskGroup {
    fn node_count(&self) -> usize {
        self.nodes.len()
    }

    fn root_node(&self) -> RuntimeLineTaskNodeId {
        self.root
    }

    fn node_view(&self, id: RuntimeLineTaskNodeId) -> Option<LineTaskNodeView<'_>> {
        match self.node(id)? {
            LineTaskNode::Sequence(children) => Some(LineTaskNodeView::Sequence(children)),
            LineTaskNode::Start(children) => Some(LineTaskNodeView::Start(children)),
            LineTaskNode::Parallel { children, .. } => Some(LineTaskNodeView::Parallel(children)),
            LineTaskNode::Child {
                trigger,
                join_policy,
                cancel_policy,
                scope,
                ..
            } => Some(LineTaskNodeView::Child {
                trigger: trigger.clone(),
                policy: LineTaskExitPolicy::new(*join_policy, *cancel_policy),
                scope: *scope,
            }),
            LineTaskNode::Action(_) => Some(LineTaskNodeView::Action),
        }
    }

    fn cancellation_action(&self, actions: &[InputActionId]) -> Option<InputActionId> {
        actions.iter().find_map(|action| {
            self.cancel_rules
                .iter()
                .any(|rule| &rule.trigger == action)
                .then(|| action.clone())
        })
    }

    fn has_action(&self, node: RuntimeLineTaskNodeId) -> bool {
        matches!(self.node(node), Some(LineTaskNode::Action(ops)) if !ops.is_empty())
    }

    fn has_cleanup(&self, exit: ScopeExit) -> bool {
        !self.cleanup.actions(exit).is_empty()
    }

    fn scheduled_child(&self, site: RuntimeLineHandleSiteId) -> Option<RuntimeLineTaskNodeId> {
        self.handle_site(site)?.scheduled_child()
    }

    fn has_cancellation_work(&self, action: &InputActionId) -> bool {
        self.cancel_rules
            .iter()
            .find(|rule| &rule.trigger == action)
            .is_some_and(|rule| !rule.action.is_empty())
    }
}

/// Dense, preorder-indexed node of a sealed line task graph.
#[derive(Clone, Debug, PartialEq)]
pub enum LineTaskNode {
    Sequence(Box<[RuntimeLineTaskNodeId]>),
    Start(Box<[RuntimeLineTaskNodeId]>),
    Parallel {
        policy: ParallelPolicy,
        children: Box<[RuntimeLineTaskNodeId]>,
    },
    Child {
        trigger: LineTaskTrigger,
        join_policy: ChildJoinPolicy,
        cancel_policy: ChildCancelPolicy,
        scope: RuntimeLineTaskNodeId,
    },
    Action(Box<[FlowOp]>),
}

/// Parallel group execution policy.
#[derive(Clone, Copy, Debug, Default, Deserialize, PartialEq, Serialize)]
pub enum ParallelPolicy {
    #[default]
    JoinAll,
}

/// Condition that starts a line-scoped child task.
#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
pub enum LineTaskTrigger {
    #[default]
    Immediate,
    Mark(RuntimeDialogueMarkId),
    Scheduled(RuntimeLineHandleSiteId),
}

/// Whether the containing graph waits for a child scope to finish.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub enum ChildJoinPolicy {
    #[default]
    Join,
    Detached,
}

/// How a running child fiber is handled when its dialogue line is cancelled.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub enum ChildCancelPolicy {
    #[default]
    CancelAndJoin,
    Finish,
    Detach,
}

/// Nearest lexical child exit policy. Nested child scopes replace this policy;
/// it is carried to the executor with every action command.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(crate) struct LineTaskExitPolicy {
    pub join: ChildJoinPolicy,
    pub cancel: ChildCancelPolicy,
}

impl LineTaskExitPolicy {
    const fn new(join: ChildJoinPolicy, cancel: ChildCancelPolicy) -> Self {
        Self { join, cancel }
    }
}

/// One input-action-selected cancellation branch.
#[derive(Clone, Debug, PartialEq)]
pub struct LineCancelRule {
    trigger: InputActionId,
    action: Box<[FlowOp]>,
}

impl LineCancelRule {
    pub(crate) fn new(trigger: InputActionId, action: Box<[FlowOp]>) -> Self {
        Self { trigger, action }
    }

    #[must_use]
    pub const fn trigger(&self) -> &InputActionId {
        &self.trigger
    }

    #[must_use]
    pub const fn action(&self) -> &[FlowOp] {
        &self.action
    }
}

/// Typed value exported by a flow choice or line action.
///
/// This remains an effect payload because its consumer is the host/output
/// boundary; it is not part of the line-task graph topology.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub struct LineOutRequest {
    pub label: Option<String>,
    pub value: String,
}

/// Typed cleanup actions and host cleanup policy for a line task group.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct LineCleanupPolicy {
    pub child_tasks: ChildTaskCleanup,
    pub presentation: PresentationCleanup,
    pub audio: AudioCleanup,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct LineTaskCleanup {
    completed: Box<[FlowOp]>,
    cancelled: Box<[FlowOp]>,
    failed: Box<[FlowOp]>,
    policy: LineCleanupPolicy,
}

impl LineTaskCleanup {
    pub(crate) const fn new(
        completed: Box<[FlowOp]>,
        cancelled: Box<[FlowOp]>,
        failed: Box<[FlowOp]>,
        policy: LineCleanupPolicy,
    ) -> Self {
        Self {
            completed,
            cancelled,
            failed,
            policy,
        }
    }

    #[must_use]
    pub const fn actions(&self, exit: ScopeExit) -> &[FlowOp] {
        match exit {
            ScopeExit::Completed => &self.completed,
            ScopeExit::Cancelled => &self.cancelled,
            ScopeExit::Failed => &self.failed,
        }
    }

    #[must_use]
    pub const fn policy(&self) -> &LineCleanupPolicy {
        &self.policy
    }
}

/// How line-scoped child tasks are treated on cleanup.
#[derive(Clone, Copy, Debug, Default, Deserialize, PartialEq, Serialize)]
pub enum ChildTaskCleanup {
    #[default]
    CancelAndJoin,
    Detach,
    Finish,
}

/// How presentation handles registered in the line lifetime are cleaned up.
#[derive(Clone, Copy, Debug, Default, Deserialize, PartialEq, Serialize)]
pub enum PresentationCleanup {
    #[default]
    DropRegistered,
    KeepRegistered,
}

/// How line-scoped audio handles are cleaned up.
#[derive(Clone, Copy, Debug, Default, Deserialize, PartialEq, Serialize)]
pub enum AudioCleanup {
    #[default]
    StopRegistered,
    FadeRegistered,
    KeepRegistered,
}

/// Precise owner tag for an action fiber.  This is deliberately not merely a
/// node id: cleanup and cancellation branches are distinct work of the same
/// activation and must not be mistaken for a graph node completing.
#[derive(Clone, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub enum LineTaskWorkInstance {
    Activation(DialogueActivationId),
    Scheduled(RuntimeLineHandleToken),
}

impl LineTaskWorkInstance {
    #[must_use]
    pub const fn activation(&self) -> &DialogueActivationId {
        match self {
            Self::Activation(activation) => activation,
            Self::Scheduled(token) => token.activation(),
        }
    }

    #[must_use]
    pub const fn scheduled_token(&self) -> Option<&RuntimeLineHandleToken> {
        match self {
            Self::Activation(_) => None,
            Self::Scheduled(token) => Some(token),
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub struct LineTaskWorkTag {
    instance: LineTaskWorkInstance,
    work: LineTaskWork,
}

impl LineTaskWorkTag {
    #[must_use]
    pub(crate) const fn activation(activation: DialogueActivationId, work: LineTaskWork) -> Self {
        Self {
            instance: LineTaskWorkInstance::Activation(activation),
            work,
        }
    }

    #[must_use]
    pub(crate) const fn scheduled(
        token: RuntimeLineHandleToken,
        node: RuntimeLineTaskNodeId,
    ) -> Self {
        Self {
            instance: LineTaskWorkInstance::Scheduled(token),
            work: LineTaskWork::Node(node),
        }
    }

    #[must_use]
    pub const fn instance(&self) -> &LineTaskWorkInstance {
        &self.instance
    }

    #[must_use]
    pub const fn activation_id(&self) -> &DialogueActivationId {
        self.instance.activation()
    }

    #[must_use]
    pub const fn scheduled_token(&self) -> Option<&RuntimeLineHandleToken> {
        self.instance.scheduled_token()
    }

    #[must_use]
    pub fn work(&self) -> LineTaskWork {
        self.work.clone()
    }

    #[must_use]
    pub(crate) const fn is_well_formed(&self) -> bool {
        matches!(
            (&self.instance, &self.work),
            (LineTaskWorkInstance::Activation(_), _)
                | (LineTaskWorkInstance::Scheduled(_), LineTaskWork::Node(_))
        )
    }
}

#[derive(Clone, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
pub enum LineTaskWork {
    Node(RuntimeLineTaskNodeId),
    Cancellation(InputActionId),
    Cleanup(ScopeExit),
    /// Dialogue-owned dynamic work; never enters reducer outstanding sets.
    Defer(crate::runtime_id::RuntimeDeferRegistrationId),
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub enum LineTaskCompletionError {
    #[error("line-task completion belongs to a different dialogue activation")]
    StaleActivation {
        expected: DialogueActivationId,
        actual: DialogueActivationId,
    },
    #[error("line-task completion does not name one outstanding work item")]
    UnknownOrDuplicateWork { tag: LineTaskWorkTag },
    #[error("line-task completion names an invalid scheduled runtime instance")]
    InvalidScheduledInstance { token: RuntimeLineHandleToken },
}

/// Actions made runnable by one executor-neutral reducer transition.
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct LineTaskActivation {
    pub commands: Vec<LineTaskCommand>,
    pub scheduled_completions: Vec<LineTaskScheduledCompletion>,
}

impl LineTaskActivation {
    pub(crate) fn append(&mut self, mut other: Self) {
        self.commands.append(&mut other.commands);
        self.scheduled_completions
            .append(&mut other.scheduled_completions);
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct LineTaskScheduledCompletion {
    token: RuntimeLineHandleToken,
    exit: ScopeExit,
}

impl LineTaskScheduledCompletion {
    pub(crate) const fn new(token: RuntimeLineHandleToken, exit: ScopeExit) -> Self {
        Self { token, exit }
    }

    pub(crate) const fn token(&self) -> &RuntimeLineHandleToken {
        &self.token
    }

    pub(crate) const fn exit(&self) -> ScopeExit {
        self.exit
    }
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) enum LineTaskCommand {
    Run {
        tag: LineTaskWorkTag,
        policy: LineTaskExitPolicy,
    },
    Cancel {
        tag: LineTaskWorkTag,
    },
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LineTaskActiveRoot {
    node: RuntimeLineTaskNodeId,
}

impl LineTaskActiveRoot {
    pub(crate) const fn new(node: RuntimeLineTaskNodeId) -> Self {
        Self { node }
    }

    pub(crate) const fn node(self) -> RuntimeLineTaskNodeId {
        self.node
    }
}

/// Snapshot-persisted state for each dense node in one active dialogue line.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub enum LineTaskNodeState {
    #[default]
    Armed,
    Running,
    Cancelling,
    Detached,
    Completed,
    Cancelled,
    Failed,
}

impl LineTaskNodeState {
    #[must_use]
    pub const fn is_terminal(self) -> bool {
        matches!(
            self,
            Self::Detached | Self::Completed | Self::Cancelled | Self::Failed
        )
    }
}

/// Lifecycle of an active group.  Closing is an observable protocol state,
/// not a queue deletion: executor-owned work is allowed to unwind and joined
/// work is accounted for before the parent dialogue may resume.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub enum LineTaskPhase {
    #[default]
    Active,
    Closing {
        exit: ScopeExit,
    },
    Closed {
        exit: ScopeExit,
    },
}

/// Canonical persistence carrier for one reducer activation. Executors map it
/// to their own DTO/wire schema; no executor may reconstruct live reducer
/// state from selected fields.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[serde(bound(
    serialize = "A: Serialize, S: Serialize, R: Serialize, E: Serialize, I: Serialize",
    deserialize = "A: InertLineTaskLane + Deserialize<'de>, S: Deserialize<'de>, R: Deserialize<'de>, E: Deserialize<'de>, I: Deserialize<'de>"
))]
pub struct LineTaskReducerState<A, S, R, E, I> {
    activation: DialogueActivationId,
    phase: LineTaskPhase,
    cancellation_action: Option<InputActionId>,
    activation_lane: A,
    scheduled_lanes: S,
    scheduled_ready: R,
    consumed_content_events: E,
    consumed_input_actions: I,
    cleanup_started: bool,
}

pub type LineTaskLiveSnapshot = LineTaskReducerState<
    LineTaskExecutionLaneSnapshot,
    Box<[LineTaskScheduledLaneSnapshot]>,
    Box<[RuntimeLineHandleToken]>,
    Box<[RuntimeDialogueContentEventKind]>,
    Box<[RuntimeDialogueInputActionEvent]>,
>;

/// Live reducer metadata under its original line-task plan. Captures remain
/// owned by the enclosing dialogue execution frame.
///
/// ```compile_fail
/// use arcweft_core::line_task::LineTaskLiveState;
/// let _: LineTaskLiveState = serde_json::from_str("{}").unwrap();
/// ```
pub type LineTaskLiveState = LineTaskReducerState<
    LineTaskExecutionLane,
    BTreeMap<RuntimeLineHandleToken, LineTaskExecutionLane>,
    BTreeSet<RuntimeLineHandleToken>,
    BTreeSet<RuntimeDialogueContentEventKind>,
    BTreeSet<RuntimeDialogueInputActionEvent>,
>;

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LineTaskExecutionLaneStorage<O, R, C> {
    node_states: Box<[LineTaskNodeState]>,
    outstanding: O,
    active_roots: R,
    cancelling_nodes: C,
}

pub type LineTaskExecutionLaneSnapshot = LineTaskExecutionLaneStorage<
    Box<[LineTaskWork]>,
    Box<[LineTaskActiveRoot]>,
    Box<[RuntimeLineTaskNodeId]>,
>;

type LineTaskExecutionLane = LineTaskExecutionLaneStorage<
    BTreeSet<LineTaskWork>,
    BTreeSet<LineTaskActiveRoot>,
    BTreeSet<RuntimeLineTaskNodeId>,
>;

trait InertLineTaskLane {}
impl InertLineTaskLane for LineTaskExecutionLaneSnapshot {}

pub(crate) trait LineTaskRows<T> {
    fn rows<'a>(&'a self) -> impl ExactSizeIterator<Item = &'a T>
    where
        T: 'a;
}

impl<T> LineTaskRows<T> for Box<[T]> {
    fn rows<'a>(&'a self) -> impl ExactSizeIterator<Item = &'a T>
    where
        T: 'a,
    {
        self.iter()
    }
}

impl<T> LineTaskRows<T> for BTreeSet<T> {
    fn rows<'a>(&'a self) -> impl ExactSizeIterator<Item = &'a T>
    where
        T: 'a,
    {
        self.iter()
    }
}

pub(crate) trait LineTaskLaneView {
    fn node_states(&self) -> &[LineTaskNodeState];
    fn outstanding(&self) -> impl ExactSizeIterator<Item = &LineTaskWork>;
    fn active_roots(&self) -> impl ExactSizeIterator<Item = &LineTaskActiveRoot>;
    fn cancelling_nodes(&self) -> impl ExactSizeIterator<Item = &RuntimeLineTaskNodeId>;
}

impl<O, R, C> LineTaskLaneView for LineTaskExecutionLaneStorage<O, R, C>
where
    O: LineTaskRows<LineTaskWork>,
    R: LineTaskRows<LineTaskActiveRoot>,
    C: LineTaskRows<RuntimeLineTaskNodeId>,
{
    fn node_states(&self) -> &[LineTaskNodeState] {
        &self.node_states
    }
    fn outstanding(&self) -> impl ExactSizeIterator<Item = &LineTaskWork> {
        self.outstanding.rows()
    }
    fn active_roots(&self) -> impl ExactSizeIterator<Item = &LineTaskActiveRoot> {
        self.active_roots.rows()
    }
    fn cancelling_nodes(&self) -> impl ExactSizeIterator<Item = &RuntimeLineTaskNodeId> {
        self.cancelling_nodes.rows()
    }
}

pub(crate) trait LineTaskScheduledRows<L> {
    fn lanes<'a>(&'a self) -> impl ExactSizeIterator<Item = (&'a RuntimeLineHandleToken, &'a L)>
    where
        L: 'a;
}

impl<L> LineTaskScheduledRows<L> for BTreeMap<RuntimeLineHandleToken, L> {
    fn lanes<'a>(&'a self) -> impl ExactSizeIterator<Item = (&'a RuntimeLineHandleToken, &'a L)>
    where
        L: 'a,
    {
        self.iter()
    }
}

impl LineTaskScheduledRows<LineTaskExecutionLaneSnapshot> for Box<[LineTaskScheduledLaneSnapshot]> {
    fn lanes<'a>(
        &'a self,
    ) -> impl ExactSizeIterator<
        Item = (
            &'a RuntimeLineHandleToken,
            &'a LineTaskExecutionLaneSnapshot,
        ),
    >
    where
        LineTaskExecutionLaneSnapshot: 'a,
    {
        self.iter().map(|row| (&row.token, &row.lane))
    }
}

/// Borrowed access to the sole reducer/lane grammar. Ordered live sets and
/// inert rows retain their actual storage; validation constructs no snapshot.
pub(crate) trait LineTaskReducerView {
    type Lane: LineTaskLaneView;
    fn activation(&self) -> &DialogueActivationId;
    fn phase(&self) -> LineTaskPhase;
    fn cancellation_action(&self) -> Option<&InputActionId>;
    fn activation_lane(&self) -> &Self::Lane;
    fn scheduled_lanes(
        &self,
    ) -> impl ExactSizeIterator<Item = (&RuntimeLineHandleToken, &Self::Lane)>;
    fn scheduled_ready(&self) -> impl ExactSizeIterator<Item = &RuntimeLineHandleToken>;
    fn consumed_content_events(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeDialogueContentEventKind>;
    fn consumed_input_actions(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeDialogueInputActionEvent>;
    fn cleanup_started(&self) -> bool;

    /// Admits borrowed ingress against the actual live or inert history before
    /// an executor retains a packet. No live value or reducer is reconstructed.
    fn inspect_input_action_events<'event>(
        &self,
        events: impl IntoIterator<Item = &'event RuntimeDialogueInputActionEvent>,
    ) -> Result<RuntimePreparedLineInputActions<'event>, LineRuntimeError> {
        let limits = crate::entry::RuntimeSchemaLimits::engine_default();
        let history = self.consumed_input_actions();
        let history_len = history.len();
        let mut accepted = Vec::new();
        for event in events
            .into_iter()
            .filter(|event| event.activation() == self.activation())
        {
            let count = history_len
                .checked_add(accepted.len())
                .and_then(|count| count.checked_add(1));
            if count.is_none_or(|count| !limits.permits_sequence_items(count)) {
                return Err(LineRuntimeError::InputActionHistoryLimitExceeded);
            }
            accepted.push(event);
        }
        accepted.sort_by(|left, right| {
            (left.epoch(), left.sequence(), left.action()).cmp(&(
                right.epoch(),
                right.sequence(),
                right.action(),
            ))
        });
        let mut batch = BTreeSet::new();
        for event in &accepted {
            if !batch.insert(*event) {
                return Err(LineRuntimeError::DuplicateInputActionEvent {
                    event: (*event).clone(),
                });
            }
        }
        if !batch.is_empty() {
            for event in history {
                if batch.contains(event) {
                    return Err(LineRuntimeError::ConsumedInputActionEvent {
                        event: event.clone(),
                    });
                }
            }
        }
        Ok(RuntimePreparedLineInputActions { events: accepted })
    }
}

impl<A, S, R, E, I> LineTaskReducerView for LineTaskReducerState<A, S, R, E, I>
where
    A: LineTaskLaneView,
    S: LineTaskScheduledRows<A>,
    R: LineTaskRows<RuntimeLineHandleToken>,
    E: LineTaskRows<RuntimeDialogueContentEventKind>,
    I: LineTaskRows<RuntimeDialogueInputActionEvent>,
{
    type Lane = A;
    fn activation(&self) -> &DialogueActivationId {
        &self.activation
    }
    fn phase(&self) -> LineTaskPhase {
        self.phase
    }
    fn cancellation_action(&self) -> Option<&InputActionId> {
        self.cancellation_action.as_ref()
    }
    fn activation_lane(&self) -> &Self::Lane {
        &self.activation_lane
    }
    fn scheduled_lanes(
        &self,
    ) -> impl ExactSizeIterator<Item = (&RuntimeLineHandleToken, &Self::Lane)> {
        self.scheduled_lanes.lanes()
    }
    fn scheduled_ready(&self) -> impl ExactSizeIterator<Item = &RuntimeLineHandleToken> {
        self.scheduled_ready.rows()
    }
    fn consumed_content_events(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeDialogueContentEventKind> {
        self.consumed_content_events.rows()
    }
    fn consumed_input_actions(
        &self,
    ) -> impl ExactSizeIterator<Item = &RuntimeDialogueInputActionEvent> {
        self.consumed_input_actions.rows()
    }
    fn cleanup_started(&self) -> bool {
        self.cleanup_started
    }
}

impl<A, S, R, E, I> LineTaskReducerState<A, S, R, E, I> {
    pub(crate) fn admit_for_plan<P: LineTaskPlanView>(
        &self,
        plan: &P,
    ) -> Result<(), LineTaskSnapshotError>
    where
        Self: LineTaskReducerView,
    {
        validate_snapshot(plan, self)
    }

    pub(crate) fn admit_retained<P: LineTaskPlanView>(
        &self,
        plan: &P,
        admission: &mut crate::value::RuntimeRetainedValueAdmission,
    ) -> Result<(), LineTaskSnapshotError>
    where
        Self: LineTaskReducerView + Serialize,
    {
        admission.validate_metadata(self)?;
        self.admit_for_plan(plan)
    }
}

impl LineTaskExecutionLaneSnapshot {
    pub(crate) fn new(
        node_states: Box<[LineTaskNodeState]>,
        outstanding: Box<[LineTaskWork]>,
        active_roots: Box<[LineTaskActiveRoot]>,
        cancelling_nodes: Box<[RuntimeLineTaskNodeId]>,
    ) -> Self {
        Self {
            node_states,
            outstanding,
            active_roots,
            cancelling_nodes,
        }
    }

    pub const fn node_states(&self) -> &[LineTaskNodeState] {
        &self.node_states
    }

    pub const fn outstanding(&self) -> &[LineTaskWork] {
        &self.outstanding
    }

    pub const fn active_roots(&self) -> &[LineTaskActiveRoot] {
        &self.active_roots
    }

    pub const fn cancelling_nodes(&self) -> &[RuntimeLineTaskNodeId] {
        &self.cancelling_nodes
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LineTaskScheduledLaneSnapshot {
    token: RuntimeLineHandleToken,
    lane: LineTaskExecutionLaneSnapshot,
}

impl LineTaskScheduledLaneSnapshot {
    pub const fn new(token: RuntimeLineHandleToken, lane: LineTaskExecutionLaneSnapshot) -> Self {
        Self { token, lane }
    }

    #[must_use]
    pub const fn token(&self) -> &RuntimeLineHandleToken {
        &self.token
    }

    #[must_use]
    pub const fn lane(&self) -> &LineTaskExecutionLaneSnapshot {
        &self.lane
    }
}

impl LineTaskLiveSnapshot {
    #[must_use]
    pub(crate) fn new(
        activation: DialogueActivationId,
        phase: LineTaskPhase,
        cancellation_action: Option<InputActionId>,
        activation_lane: LineTaskExecutionLaneSnapshot,
        scheduled_lanes: Box<[LineTaskScheduledLaneSnapshot]>,
        scheduled_ready: Box<[RuntimeLineHandleToken]>,
        consumed_content_events: Box<[RuntimeDialogueContentEventKind]>,
        consumed_input_actions: Box<[RuntimeDialogueInputActionEvent]>,
        cleanup_started: bool,
    ) -> Self {
        Self {
            activation,
            phase,
            cancellation_action,
            activation_lane,
            scheduled_lanes,
            scheduled_ready,
            consumed_content_events,
            consumed_input_actions,
            cleanup_started,
        }
    }

    #[must_use]
    pub const fn activation(&self) -> &DialogueActivationId {
        &self.activation
    }

    #[must_use]
    pub const fn phase(&self) -> LineTaskPhase {
        self.phase
    }

    #[must_use]
    pub const fn cancellation_action(&self) -> Option<&InputActionId> {
        self.cancellation_action.as_ref()
    }

    #[must_use]
    pub const fn node_states(&self) -> &[LineTaskNodeState] {
        self.activation_lane.node_states()
    }

    #[must_use]
    pub const fn outstanding(&self) -> &[LineTaskWork] {
        self.activation_lane.outstanding()
    }

    #[must_use]
    pub const fn active_roots(&self) -> &[LineTaskActiveRoot] {
        self.activation_lane.active_roots()
    }

    #[must_use]
    pub const fn cancelling_nodes(&self) -> &[RuntimeLineTaskNodeId] {
        self.activation_lane.cancelling_nodes()
    }

    #[must_use]
    pub const fn scheduled_lanes(&self) -> &[LineTaskScheduledLaneSnapshot] {
        &self.scheduled_lanes
    }

    #[must_use]
    pub const fn scheduled_ready(&self) -> &[RuntimeLineHandleToken] {
        &self.scheduled_ready
    }

    #[must_use]
    pub const fn consumed_content_events(&self) -> &[RuntimeDialogueContentEventKind] {
        &self.consumed_content_events
    }

    #[must_use]
    pub const fn cleanup_started(&self) -> bool {
        self.cleanup_started
    }

    #[must_use]
    pub const fn consumed_input_actions(&self) -> &[RuntimeDialogueInputActionEvent] {
        &self.consumed_input_actions
    }

    /// Returns the exact runtime work identities that must each have one
    /// joined executor child. Static node coordinates alone are insufficient
    /// because scheduled lanes distinguish concurrent issuances by token.
    pub(crate) fn outstanding_tags(&self) -> BTreeSet<LineTaskWorkTag> {
        self.activation_lane
            .outstanding
            .iter()
            .cloned()
            .map(|work| LineTaskWorkTag::activation(self.activation.clone(), work))
            .chain(self.scheduled_lanes.iter().flat_map(|scheduled| {
                scheduled
                    .lane()
                    .outstanding()
                    .iter()
                    .filter_map(|work| match work {
                        LineTaskWork::Node(node) => {
                            Some(LineTaskWorkTag::scheduled(scheduled.token().clone(), *node))
                        }
                        LineTaskWork::Cancellation(_)
                        | LineTaskWork::Cleanup(_)
                        | LineTaskWork::Defer(_) => None,
                    })
            }))
            .collect()
    }
}

#[derive(Clone, Debug, Error, Eq, PartialEq)]
pub(crate) enum LineTaskSnapshotError {
    #[error(transparent)]
    Value(#[from] crate::value::AwbcRuntimeValueSnapshotError),
    #[error("line-task snapshot has {actual} node states; plan has {expected} nodes")]
    NodeStateCount { expected: usize, actual: usize },
    #[error("line-task snapshot references unknown node {node}")]
    UnknownNode { node: RuntimeLineTaskNodeId },
    #[error("line-task snapshot repeats active root {node}")]
    DuplicateActiveRoot { node: RuntimeLineTaskNodeId },
    #[error("line-task snapshot repeats cancelling node {node}")]
    DuplicateCancellingNode { node: RuntimeLineTaskNodeId },
    #[error("line-task snapshot repeats outstanding work {work:?}")]
    DuplicateOutstanding { work: LineTaskWork },
    #[error("line-task snapshot repeats scheduled runtime instance {token:?}")]
    DuplicateScheduledInstance { token: RuntimeLineHandleToken },
    #[error("line-task snapshot references an unknown scheduled runtime instance {token:?}")]
    UnknownScheduledInstance { token: RuntimeLineHandleToken },
    #[error("line-task snapshot scheduled lane does not match its token {token:?}")]
    InvalidScheduledLane { token: RuntimeLineHandleToken },
    #[error("line-task snapshot repeats consumed dialogue content event {event:?}")]
    DuplicateContentEvent {
        event: RuntimeDialogueContentEventKind,
    },
    #[error("line-task snapshot repeats consumed input action {event:?}")]
    DuplicateInputActionEvent {
        event: RuntimeDialogueInputActionEvent,
    },
    #[error("line-task snapshot contains an input action for a different activation")]
    StaleInputActionEvent {
        event: RuntimeDialogueInputActionEvent,
    },
    #[error("line-task snapshot marks terminal node {node} as an active root")]
    TerminalActiveRoot { node: RuntimeLineTaskNodeId },
    #[error("line-task snapshot marks node {node} cancelling without Cancelling state")]
    CancellingNodeState { node: RuntimeLineTaskNodeId },
    #[error("line-task snapshot work {work:?} is incompatible with its phase")]
    WorkPhase { work: LineTaskWork },
    #[error("line-task snapshot cleanup flag is incompatible with its phase")]
    CleanupPhase,
    #[error("line-task snapshot cancellation action is incompatible with its phase or plan")]
    CancellationAction,
}

impl LineTaskExecutionLane {
    fn new(node_count: usize) -> Self {
        Self {
            node_states: vec![LineTaskNodeState::Armed; node_count].into_boxed_slice(),
            outstanding: BTreeSet::new(),
            active_roots: BTreeSet::new(),
            cancelling_nodes: BTreeSet::new(),
        }
    }

    fn snapshot(&self) -> LineTaskExecutionLaneSnapshot {
        LineTaskExecutionLaneSnapshot::new(
            self.node_states.clone(),
            self.outstanding.iter().cloned().collect(),
            self.active_roots.iter().copied().collect(),
            self.cancelling_nodes.iter().copied().collect(),
        )
    }

    fn from_snapshot(snapshot: LineTaskExecutionLaneSnapshot) -> Self {
        Self {
            node_states: snapshot.node_states,
            outstanding: snapshot.outstanding.into_vec().into_iter().collect(),
            active_roots: snapshot.active_roots.into_vec().into_iter().collect(),
            cancelling_nodes: snapshot.cancelling_nodes.into_vec().into_iter().collect(),
        }
    }

    fn node_state(&self, node: RuntimeLineTaskNodeId) -> Option<LineTaskNodeState> {
        self.node_states.get(node.index()).copied()
    }

    fn set_node_state(&mut self, node: RuntimeLineTaskNodeId, state: LineTaskNodeState) {
        if let Some(slot) = self.node_states.get_mut(node.index()) {
            *slot = state;
        }
    }

    fn cancel_pending_nodes(&mut self) {
        for (index, state) in self.node_states.iter_mut().enumerate() {
            if !state.is_terminal() {
                *state = LineTaskNodeState::Cancelling;
                if let Some(node) = RuntimeLineTaskNodeId::from_zero_based(index) {
                    self.cancelling_nodes.insert(node);
                }
            }
        }
    }
}

/// Borrowed, bounded identities admitted before a reducer or inbox retains them.
pub(crate) struct RuntimePreparedLineInputActions<'event> {
    events: Vec<&'event RuntimeDialogueInputActionEvent>,
}

impl RuntimePreparedLineInputActions<'_> {
    pub(crate) fn into_pending_events(self) -> Vec<RuntimeDialogueInputActionEvent> {
        self.events.into_iter().cloned().collect()
    }
}

impl LineTaskLiveState {
    #[must_use]
    pub(crate) fn new<P: LineTaskPlanView>(group: &P, activation: DialogueActivationId) -> Self {
        Self {
            activation,
            phase: LineTaskPhase::Active,
            cancellation_action: None,
            activation_lane: LineTaskExecutionLane::new(group.node_count()),
            scheduled_lanes: BTreeMap::new(),
            scheduled_ready: BTreeSet::new(),
            consumed_content_events: BTreeSet::new(),
            consumed_input_actions: BTreeSet::new(),
            cleanup_started: false,
        }
    }

    /// Returns the sole complete persistence representation of this reducer.
    #[must_use]
    pub(crate) fn snapshot(&self) -> LineTaskLiveSnapshot {
        LineTaskLiveSnapshot::new(
            self.activation.clone(),
            self.phase,
            self.cancellation_action.clone(),
            self.activation_lane.snapshot(),
            self.scheduled_lanes
                .iter()
                .map(|(token, lane)| {
                    LineTaskScheduledLaneSnapshot::new(token.clone(), lane.snapshot())
                })
                .collect(),
            self.scheduled_ready.iter().cloned().collect(),
            self.consumed_content_events.iter().copied().collect(),
            self.consumed_input_actions.iter().cloned().collect(),
            self.cleanup_started,
        )
    }

    /// Restores only an owner-validated complete snapshot. `P` is the same
    /// plan view used by the reducer, so native and AWBC share validation.
    #[cfg(test)]
    pub(crate) fn restore<P: LineTaskPlanView>(
        plan: &P,
        snapshot: LineTaskLiveSnapshot,
    ) -> Result<Self, LineTaskSnapshotError> {
        validate_snapshot(plan, &snapshot)?;
        Ok(Self::from_admitted_snapshot(snapshot))
    }

    pub(crate) fn from_admitted_snapshot(snapshot: LineTaskLiveSnapshot) -> Self {
        Self {
            activation: snapshot.activation,
            phase: snapshot.phase,
            cancellation_action: snapshot.cancellation_action,
            activation_lane: LineTaskExecutionLane::from_snapshot(snapshot.activation_lane),
            scheduled_lanes: snapshot
                .scheduled_lanes
                .into_vec()
                .into_iter()
                .map(|scheduled| {
                    (
                        scheduled.token,
                        LineTaskExecutionLane::from_snapshot(scheduled.lane),
                    )
                })
                .collect(),
            scheduled_ready: snapshot.scheduled_ready.into_vec().into_iter().collect(),
            consumed_content_events: snapshot
                .consumed_content_events
                .into_vec()
                .into_iter()
                .collect(),
            consumed_input_actions: snapshot
                .consumed_input_actions
                .into_vec()
                .into_iter()
                .collect(),
            cleanup_started: snapshot.cleanup_started,
        }
    }

    #[must_use]
    pub(crate) fn is_closing(&self) -> bool {
        matches!(self.phase, LineTaskPhase::Closing { .. })
    }

    #[must_use]
    pub(crate) fn is_closed(&self) -> bool {
        self.closed_exit().is_some()
    }

    pub(crate) fn closed_exit(&self) -> Option<ScopeExit> {
        match self.phase {
            LineTaskPhase::Closed { exit } => Some(exit),
            LineTaskPhase::Active | LineTaskPhase::Closing { .. } => None,
        }
    }

    pub(crate) fn accepts_result_selection<P: LineTaskPlanView>(
        &self,
        plan: &P,
        tag: &LineTaskWorkTag,
    ) -> bool {
        if tag.activation_id() != &self.activation || !tag.is_well_formed() {
            return false;
        }
        match (tag.instance(), tag.work()) {
            (LineTaskWorkInstance::Activation(_), LineTaskWork::Cancellation(action)) => {
                self.cancellation_action.as_ref() == Some(&action)
                    && matches!(
                        self.phase,
                        LineTaskPhase::Closing {
                            exit: ScopeExit::Cancelled
                        }
                    )
                    && self
                        .activation_lane
                        .outstanding
                        .contains(&LineTaskWork::Cancellation(action))
            }
            (instance, LineTaskWork::Node(action)) => {
                if !matches!(
                    self.phase,
                    LineTaskPhase::Active
                        | LineTaskPhase::Closing {
                            exit: ScopeExit::Completed
                        }
                ) || !matches!(plan.node_view(action), Some(LineTaskNodeView::Action))
                {
                    return false;
                }
                let lane = match instance {
                    LineTaskWorkInstance::Activation(_) => Some(&self.activation_lane),
                    LineTaskWorkInstance::Scheduled(token) => self.scheduled_lanes.get(token),
                };
                let Some(lane) = lane else {
                    return false;
                };
                lane.outstanding.contains(&LineTaskWork::Node(action))
                    && mark_result_source(plan, action).is_some_and(|mark| {
                        self.consumed_content_events
                            .contains(&RuntimeDialogueContentEventKind::Mark(mark))
                    })
            }
            (
                _,
                LineTaskWork::Cancellation(_) | LineTaskWork::Cleanup(_) | LineTaskWork::Defer(_),
            ) => false,
        }
    }

    #[must_use]
    pub fn node_state(&self, node: RuntimeLineTaskNodeId) -> Option<LineTaskNodeState> {
        self.activation_lane.node_state(node)
    }

    pub(crate) fn mark_scheduled_ready(
        &mut self,
        token: RuntimeLineHandleToken,
    ) -> Result<bool, LineRuntimeError> {
        if token.activation() != &self.activation {
            return Err(LineRuntimeError::WrongActivation);
        }
        if self.scheduled_lanes.contains_key(&token) || !self.scheduled_ready.insert(token) {
            return Err(LineRuntimeError::DuplicateScheduledWorkInstance);
        }
        Ok(true)
    }

    /// Returns whether the scheduled lane has a child to cancel. A ready
    /// token without a lane still belongs to its unstarted capture packet.
    pub(crate) fn cancel_scheduled_cue(
        &mut self,
        token: &RuntimeLineHandleToken,
    ) -> Result<bool, LineRuntimeError> {
        if self.scheduled_ready.remove(token) {
            return Ok(false);
        }
        let lane = self
            .scheduled_lanes
            .get_mut(token)
            .ok_or(LineRuntimeError::MissingScheduledWork)?;
        let mut work = lane.outstanding.iter();
        let (Some(LineTaskWork::Node(node)), None) = (work.next(), work.next()) else {
            return Err(LineRuntimeError::InvalidScheduledWorkState);
        };
        let node = *node;
        if lane.node_state(node) != Some(LineTaskNodeState::Running) {
            return Err(LineRuntimeError::InvalidScheduledWorkState);
        }
        lane.set_node_state(node, LineTaskNodeState::Cancelling);
        lane.cancelling_nodes.insert(node);
        Ok(true)
    }

    /// Validates and consumes one step's exact content-reveal events as one
    /// transaction. The content-plan owner supplies `contains`; no event is
    /// recorded if any activation, coordinate, duplicate, or replay check
    /// fails.
    pub(crate) fn accept_content_event_kinds(
        &mut self,
        events: &[RuntimeDialogueContentEventKind],
        mut contains: impl FnMut(RuntimeDialogueContentEventKind) -> bool,
    ) -> Result<AcceptedLineTaskContentEvents, LineRuntimeError> {
        let mut batch = BTreeSet::new();
        for &kind in events {
            if !contains(kind) {
                return Err(LineRuntimeError::UnknownContentEvent { event: kind });
            }
            if !batch.insert(kind) {
                return Err(LineRuntimeError::DuplicateContentEvent { event: kind });
            }
            if self.consumed_content_events.contains(&kind) {
                return Err(LineRuntimeError::ConsumedContentEvent { event: kind });
            }
        }
        self.consumed_content_events.extend(batch.iter().copied());
        let mut accepted = AcceptedLineTaskContentEvents::default();
        for event in batch {
            match event {
                RuntimeDialogueContentEventKind::Mark(mark) => {
                    accepted.marks.insert(mark);
                }
                RuntimeDialogueContentEventKind::Effect(_) => {}
            }
        }
        Ok(accepted)
    }

    /// Accepts only input actions routed to this exact dialogue activation.
    /// Input identity prevents stale or replayed actions from canceling a line.
    pub(crate) fn accept_input_action_events(
        &mut self,
        events: &[RuntimeDialogueInputActionEvent],
    ) -> Result<Vec<InputActionId>, LineRuntimeError> {
        let prepared = self.inspect_input_action_events(events.iter())?;
        let mut seen_actions = BTreeSet::new();
        let actions = prepared
            .events
            .iter()
            .filter_map(|event| {
                seen_actions
                    .insert(event.action())
                    .then(|| event.action().clone())
            })
            .collect();
        self.consumed_input_actions
            .extend(prepared.events.into_iter().cloned());
        Ok(actions)
    }

    fn complete_work(
        &mut self,
        tag: LineTaskWorkTag,
        failed: bool,
    ) -> Result<(), LineTaskCompletionError> {
        if tag.activation_id() != &self.activation {
            return Err(LineTaskCompletionError::StaleActivation {
                expected: self.activation.clone(),
                actual: tag.activation_id().clone(),
            });
        }
        let lane = match tag.instance() {
            LineTaskWorkInstance::Activation(_) => &mut self.activation_lane,
            LineTaskWorkInstance::Scheduled(token) => {
                self.scheduled_lanes.get_mut(token).ok_or_else(|| {
                    LineTaskCompletionError::UnknownOrDuplicateWork { tag: tag.clone() }
                })?
            }
        };
        let work = tag.work();
        if !lane.outstanding.remove(&work) {
            return Err(LineTaskCompletionError::UnknownOrDuplicateWork { tag });
        }
        if let LineTaskWork::Node(node) = work {
            lane.set_node_state(
                node,
                if matches!(self.phase, LineTaskPhase::Closing { .. })
                    || lane.node_state(node) == Some(LineTaskNodeState::Cancelling)
                {
                    LineTaskNodeState::Cancelled
                } else if failed {
                    LineTaskNodeState::Failed
                } else {
                    LineTaskNodeState::Completed
                },
            );
        }
        Ok(())
    }

    fn begin_close(&mut self, exit: ScopeExit) -> bool {
        if !matches!(self.phase, LineTaskPhase::Active) {
            return false;
        }
        self.phase = LineTaskPhase::Closing { exit };
        self.activation_lane.cancel_pending_nodes();
        for lane in self.scheduled_lanes.values_mut() {
            lane.cancel_pending_nodes();
        }
        true
    }

    fn has_outstanding(&self) -> bool {
        !self.activation_lane.outstanding.is_empty()
            || self
                .scheduled_lanes
                .values()
                .any(|lane| !lane.outstanding.is_empty())
    }
}

fn mark_result_source<P: LineTaskPlanView>(
    plan: &P,
    action: RuntimeLineTaskNodeId,
) -> Option<RuntimeDialogueMarkId> {
    if !matches!(plan.node_view(action), Some(LineTaskNodeView::Action)) {
        return None;
    }
    let mut source = None;
    for child in (0..plan.node_count()).filter_map(RuntimeLineTaskNodeId::from_zero_based) {
        let Some(LineTaskNodeView::Child {
            trigger: LineTaskTrigger::Mark(mark),
            policy:
                LineTaskExitPolicy {
                    join: ChildJoinPolicy::Join,
                    cancel: ChildCancelPolicy::CancelAndJoin,
                },
            scope,
        }) = plan.node_view(child)
        else {
            continue;
        };
        if scope == action && source.replace(mark).is_some() {
            return None;
        }
    }
    source
}

fn validate_snapshot<P: LineTaskPlanView>(
    plan: &P,
    snapshot: &impl LineTaskReducerView,
) -> Result<(), LineTaskSnapshotError> {
    validate_lane_snapshot(plan, snapshot.activation_lane(), snapshot.phase(), false)?;
    let mut scheduled_instances = BTreeSet::new();
    for (token, lane) in snapshot.scheduled_lanes() {
        if token.activation() != snapshot.activation()
            || plan.scheduled_child(token.site()).is_none()
        {
            return Err(LineTaskSnapshotError::UnknownScheduledInstance {
                token: token.clone(),
            });
        }
        if !scheduled_instances.insert(token.clone()) {
            return Err(LineTaskSnapshotError::DuplicateScheduledInstance {
                token: token.clone(),
            });
        }
        validate_lane_snapshot(plan, lane, snapshot.phase(), true).map_err(|_| {
            LineTaskSnapshotError::InvalidScheduledLane {
                token: token.clone(),
            }
        })?;
        validate_scheduled_lane_scope(plan, token, lane).map_err(|()| {
            LineTaskSnapshotError::InvalidScheduledLane {
                token: token.clone(),
            }
        })?;
    }
    for token in snapshot.scheduled_ready() {
        if token.activation() != snapshot.activation()
            || plan.scheduled_child(token.site()).is_none()
        {
            return Err(LineTaskSnapshotError::UnknownScheduledInstance {
                token: token.clone(),
            });
        }
        if !scheduled_instances.insert(token.clone()) {
            return Err(LineTaskSnapshotError::DuplicateScheduledInstance {
                token: token.clone(),
            });
        }
    }
    let mut content_events = BTreeSet::new();
    for &event in snapshot.consumed_content_events() {
        if !content_events.insert(event) {
            return Err(LineTaskSnapshotError::DuplicateContentEvent { event });
        }
    }
    let mut input_actions = BTreeSet::new();
    for event in snapshot.consumed_input_actions() {
        if event.activation() != snapshot.activation() {
            return Err(LineTaskSnapshotError::StaleInputActionEvent {
                event: event.clone(),
            });
        }
        if !input_actions.insert(event) {
            return Err(LineTaskSnapshotError::DuplicateInputActionEvent {
                event: event.clone(),
            });
        }
    }
    if snapshot.cleanup_started() && matches!(snapshot.phase(), LineTaskPhase::Active) {
        return Err(LineTaskSnapshotError::CleanupPhase);
    }
    match (snapshot.phase(), snapshot.cancellation_action()) {
        (
            LineTaskPhase::Closing {
                exit: ScopeExit::Cancelled,
            }
            | LineTaskPhase::Closed {
                exit: ScopeExit::Cancelled,
            },
            Some(action),
        ) if plan.cancellation_action(std::slice::from_ref(action)) == Some(action.clone()) => {}
        (LineTaskPhase::Active, None)
        | (
            LineTaskPhase::Closing {
                exit: ScopeExit::Completed | ScopeExit::Failed,
            },
            None,
        )
        | (
            LineTaskPhase::Closed {
                exit: ScopeExit::Completed | ScopeExit::Failed,
            },
            None,
        ) => {}
        _ => return Err(LineTaskSnapshotError::CancellationAction),
    }
    Ok(())
}

fn validate_lane_snapshot<P: LineTaskPlanView>(
    plan: &P,
    lane: &impl LineTaskLaneView,
    phase: LineTaskPhase,
    scheduled: bool,
) -> Result<(), LineTaskSnapshotError> {
    if lane.node_states().len() != plan.node_count() {
        return Err(LineTaskSnapshotError::NodeStateCount {
            expected: plan.node_count(),
            actual: lane.node_states().len(),
        });
    }
    let validate_node = |node| {
        plan.node_view(node)
            .is_some()
            .then_some(())
            .ok_or(LineTaskSnapshotError::UnknownNode { node })
    };
    let mut roots = BTreeSet::new();
    for root in lane.active_roots() {
        let node = root.node;
        validate_node(node)?;
        if !roots.insert(node) {
            return Err(LineTaskSnapshotError::DuplicateActiveRoot { node });
        }
        if lane.node_states()[node.index()].is_terminal() {
            return Err(LineTaskSnapshotError::TerminalActiveRoot { node });
        }
    }
    let mut cancelling = BTreeSet::new();
    for &node in lane.cancelling_nodes() {
        validate_node(node)?;
        if !cancelling.insert(node) {
            return Err(LineTaskSnapshotError::DuplicateCancellingNode { node });
        }
        if lane.node_states()[node.index()] != LineTaskNodeState::Cancelling {
            return Err(LineTaskSnapshotError::CancellingNodeState { node });
        }
    }
    let mut outstanding = BTreeSet::new();
    for work in lane.outstanding() {
        if !outstanding.insert(work.clone()) {
            return Err(LineTaskSnapshotError::DuplicateOutstanding { work: work.clone() });
        }
        match work {
            LineTaskWork::Node(node) => validate_node(*node)?,
            LineTaskWork::Cancellation(_) | LineTaskWork::Cleanup(_) => {}
            LineTaskWork::Defer(_) => {
                return Err(LineTaskSnapshotError::WorkPhase { work: work.clone() });
            }
        }
        let valid_phase = match work {
            LineTaskWork::Node(_) => !matches!(phase, LineTaskPhase::Closed { .. }),
            LineTaskWork::Cancellation(_) | LineTaskWork::Cleanup(_) => {
                !scheduled && matches!(phase, LineTaskPhase::Closing { .. })
            }
            LineTaskWork::Defer(_) => false,
        };
        if !valid_phase {
            return Err(LineTaskSnapshotError::WorkPhase { work: work.clone() });
        }
    }
    Ok(())
}

fn validate_scheduled_lane_scope<P: LineTaskPlanView>(
    plan: &P,
    token: &RuntimeLineHandleToken,
    lane: &impl LineTaskLaneView,
) -> Result<(), ()> {
    let child = plan.scheduled_child(token.site()).ok_or(())?;
    let Some(LineTaskNodeView::Child {
        trigger: LineTaskTrigger::Scheduled(site),
        policy,
        scope,
    }) = plan.node_view(child)
    else {
        return Err(());
    };
    if site != token.site()
        || policy.join != ChildJoinPolicy::Join
        || policy.cancel != ChildCancelPolicy::CancelAndJoin
        || !matches!(plan.node_view(scope), Some(LineTaskNodeView::Action))
    {
        return Err(());
    }
    let mut allowed = BTreeSet::new();
    collect_line_task_subtree(plan, child, &mut allowed)?;
    for (index, state) in lane.node_states().iter().copied().enumerate() {
        if state != LineTaskNodeState::Armed {
            let node = RuntimeLineTaskNodeId::from_zero_based(index).ok_or(())?;
            if !allowed.contains(&node) {
                return Err(());
            }
        }
    }
    if lane.outstanding().len() == 0
        || lane
            .outstanding()
            .any(|work| !matches!(work, LineTaskWork::Node(node) if allowed.contains(node)))
        || lane
            .active_roots()
            .any(|root| !allowed.contains(&root.node()))
        || lane.cancelling_nodes().any(|node| !allowed.contains(node))
        || !matches!(
            lane.node_states()[child.index()],
            LineTaskNodeState::Running | LineTaskNodeState::Cancelling
        )
    {
        return Err(());
    }
    Ok(())
}

fn collect_line_task_subtree<P: LineTaskPlanView>(
    plan: &P,
    node: RuntimeLineTaskNodeId,
    nodes: &mut BTreeSet<RuntimeLineTaskNodeId>,
) -> Result<(), ()> {
    if !nodes.insert(node) {
        return Ok(());
    }
    match plan.node_view(node).ok_or(())? {
        LineTaskNodeView::Sequence(children)
        | LineTaskNodeView::Start(children)
        | LineTaskNodeView::Parallel(children) => {
            for child in children {
                collect_line_task_subtree(plan, *child, nodes)?;
            }
        }
        LineTaskNodeView::Child { scope, .. } => {
            collect_line_task_subtree(plan, scope, nodes)?;
        }
        LineTaskNodeView::Action => {}
    }
    Ok(())
}

fn drain_cancellations(state: &mut LineTaskLiveState, activation: &mut LineTaskActivation) {
    activation.commands.extend(
        std::mem::take(&mut state.activation_lane.cancelling_nodes)
            .into_iter()
            .map(|node| LineTaskCommand::Cancel {
                tag: LineTaskWorkTag::activation(
                    state.activation.clone(),
                    LineTaskWork::Node(node),
                ),
            }),
    );
    for (token, lane) in &mut state.scheduled_lanes {
        activation
            .commands
            .extend(
                std::mem::take(&mut lane.cancelling_nodes)
                    .into_iter()
                    .map(|node| LineTaskCommand::Cancel {
                        tag: LineTaskWorkTag::scheduled(token.clone(), node),
                    }),
            );
    }
}

/// Starts or progresses a sealed line-task graph. Node identity, rather than
/// a traversal ordinal, makes repeated host steps idempotent.
pub(crate) fn progress_live_line_task_group<P: LineTaskPlanView>(
    group: &P,
    elapsed: LogicalDuration,
    events: LineTaskReadyEvents<'_>,
    state: &mut LineTaskLiveState,
) -> Result<LineTaskActivation, LineRuntimeError> {
    if !matches!(state.phase, LineTaskPhase::Active) {
        return Ok(LineTaskActivation::default());
    }
    let mut candidate = state.clone();
    let mut activation = LineTaskActivation::default();
    let activation_instance = LineTaskWorkInstance::Activation(candidate.activation.clone());
    activate_node(
        group,
        group.root_node(),
        elapsed,
        events,
        &mut candidate.activation_lane,
        &activation_instance,
        LineTaskExitPolicy::default(),
        &mut activation,
    );
    progress_active_roots(
        group,
        elapsed,
        events,
        &mut candidate.activation_lane,
        &activation_instance,
        &mut activation,
    );
    progress_ready_scheduled(group, elapsed, events, &mut candidate, &mut activation)?;
    drain_cancellations(&mut candidate, &mut activation);
    *state = candidate;
    Ok(activation)
}

/// Begins the cancellation closing protocol. The returned activation contains
/// only cancellation work; cleanup is emitted after joined work has drained.
/// This gives every executor the same ordering without exposing its queue.
pub(crate) fn cancel_live_line_task_group<P: LineTaskPlanView>(
    group: &P,
    events: LineTaskReadyEvents<'_>,
    state: &mut LineTaskLiveState,
) -> Option<(InputActionId, LineTaskActivation)> {
    let action = group.cancellation_action(events.input_actions())?;
    if !state.begin_close(ScopeExit::Cancelled) {
        return None;
    }
    state.cancellation_action = Some(action.clone());
    let mut activation = LineTaskActivation::default();
    if group.has_cancellation_work(&action) {
        activation.commands.push(LineTaskCommand::Run {
            tag: LineTaskWorkTag::activation(
                state.activation.clone(),
                LineTaskWork::Cancellation(action.clone()),
            ),
            policy: LineTaskExitPolicy::new(ChildJoinPolicy::Join, ChildCancelPolicy::Finish),
        });
        state
            .activation_lane
            .outstanding
            .insert(LineTaskWork::Cancellation(action.clone()));
    }
    drain_cancellations(state, &mut activation);
    Some((action, activation))
}

/// Completes a live line scope after an explicit host advance.
pub(crate) fn finish_live_line_task_group<P: LineTaskPlanView>(
    group: &P,
    state: &mut LineTaskLiveState,
) -> LineTaskActivation {
    state.begin_close(ScopeExit::Completed);
    let mut activation = finalize_live_line_task_close(group, state);
    drain_cancellations(state, &mut activation);
    activation
}

/// Begins failure close for one accepted reducer graph. This is the sole
/// reducer-owned transition used by both structured and Product executors;
/// executor adapters only realize the returned typed child commands.
pub(crate) fn fail_live_line_task_group<P: LineTaskPlanView>(
    group: &P,
    state: &mut LineTaskLiveState,
) -> LineTaskActivation {
    state.begin_close(ScopeExit::Failed);
    let mut activation = finalize_live_line_task_close(group, state);
    drain_cancellations(state, &mut activation);
    activation
}

/// Completes one tagged work item, then emits cleanup exactly once when the
/// closing protocol has no joined graph work left.
pub(crate) fn complete_live_line_task_work<P: LineTaskPlanView>(
    group: &P,
    state: &mut LineTaskLiveState,
    tag: LineTaskWorkTag,
    failed: bool,
) -> Result<LineTaskActivation, LineTaskCompletionError> {
    let mut candidate = state.clone();
    let instance = tag.instance().clone();
    candidate.complete_work(tag, failed)?;
    let mut activation = LineTaskActivation::default();
    if matches!(candidate.phase, LineTaskPhase::Active) {
        let empty_marks = BTreeSet::new();
        let ready = LineTaskReadyEvents::new(&empty_marks);
        match &instance {
            LineTaskWorkInstance::Activation(_) => {
                activate_node(
                    group,
                    group.root_node(),
                    LogicalDuration::default(),
                    ready,
                    &mut candidate.activation_lane,
                    &instance,
                    LineTaskExitPolicy::default(),
                    &mut activation,
                );
                progress_active_roots(
                    group,
                    LogicalDuration::default(),
                    ready,
                    &mut candidate.activation_lane,
                    &instance,
                    &mut activation,
                );
            }
            LineTaskWorkInstance::Scheduled(token) => {
                progress_scheduled_lane(
                    group,
                    token,
                    LogicalDuration::default(),
                    ready,
                    &mut candidate,
                    &mut activation,
                )
                .map_err(|_| {
                    LineTaskCompletionError::InvalidScheduledInstance {
                        token: token.clone(),
                    }
                })?;
            }
        }
    }
    if failed && matches!(candidate.phase, LineTaskPhase::Active) {
        candidate.begin_close(ScopeExit::Failed);
    }
    activation
        .commands
        .extend(finalize_live_line_task_close(group, &mut candidate).commands);
    drain_cancellations(&mut candidate, &mut activation);
    *state = candidate;
    Ok(activation)
}

/// Advances Closing after executor-owned joined work reports drained.
pub(crate) fn finalize_live_line_task_close<P: LineTaskPlanView>(
    group: &P,
    state: &mut LineTaskLiveState,
) -> LineTaskActivation {
    let LineTaskPhase::Closing { exit } = state.phase else {
        return LineTaskActivation::default();
    };
    if state.has_outstanding() {
        return LineTaskActivation::default();
    }
    if state.cleanup_started {
        state.phase = LineTaskPhase::Closed { exit };
        return LineTaskActivation::default();
    }
    state.cleanup_started = true;
    if !group.has_cleanup(exit) {
        state.phase = LineTaskPhase::Closed { exit };
        return LineTaskActivation::default();
    }
    state
        .activation_lane
        .outstanding
        .insert(LineTaskWork::Cleanup(exit));
    LineTaskActivation {
        commands: vec![LineTaskCommand::Run {
            tag: LineTaskWorkTag::activation(state.activation.clone(), LineTaskWork::Cleanup(exit)),
            policy: LineTaskExitPolicy::new(ChildJoinPolicy::Join, ChildCancelPolicy::Finish),
        }],
        scheduled_completions: Vec::new(),
    }
}

fn activate_node<P: LineTaskPlanView>(
    group: &P,
    id: RuntimeLineTaskNodeId,
    elapsed: LogicalDuration,
    events: LineTaskReadyEvents<'_>,
    lane: &mut LineTaskExecutionLane,
    instance: &LineTaskWorkInstance,
    policy: LineTaskExitPolicy,
    activation: &mut LineTaskActivation,
) {
    let Some(node) = group.node_view(id) else {
        return;
    };
    match node {
        LineTaskNodeView::Sequence(nodes) => {
            if lane.node_state(id) == Some(LineTaskNodeState::Armed) {
                lane.set_node_state(id, LineTaskNodeState::Running);
            }
            if let Some(exit) = sequence_exit(nodes, lane) {
                lane.set_node_state(id, exit);
                cancel_remaining(nodes, lane);
                return;
            }
            if let Some(child) = nodes.iter().find(|child| {
                !lane
                    .node_state(**child)
                    .is_some_and(LineTaskNodeState::is_terminal)
            }) {
                activate_node(
                    group, *child, elapsed, events, lane, instance, policy, activation,
                );
            }
            if let Some(exit) = sequence_exit(nodes, lane) {
                lane.set_node_state(id, exit);
                cancel_remaining(nodes, lane);
            }
        }
        LineTaskNodeView::Start(nodes) => {
            if lane.node_state(id) == Some(LineTaskNodeState::Armed) {
                lane.set_node_state(id, LineTaskNodeState::Running);
                for child in nodes {
                    activate_node(
                        group, *child, elapsed, events, lane, instance, policy, activation,
                    );
                }
                lane.active_roots
                    .extend(nodes.iter().copied().map(LineTaskActiveRoot::new));
                lane.set_node_state(id, LineTaskNodeState::Completed);
            }
        }
        LineTaskNodeView::Parallel(children) => {
            if lane.node_state(id) == Some(LineTaskNodeState::Armed) {
                lane.set_node_state(id, LineTaskNodeState::Running);
            }
            for child in children {
                activate_node(
                    group, *child, elapsed, events, lane, instance, policy, activation,
                );
            }
            if let Some(exit) = parallel_exit(children, lane) {
                lane.set_node_state(id, exit);
                if exit != LineTaskNodeState::Completed {
                    cancel_remaining(children, lane);
                }
            }
        }
        child @ LineTaskNodeView::Child { .. } => {
            activate_child(
                group, id, elapsed, events, lane, instance, activation, child,
            );
        }
        LineTaskNodeView::Action => {
            if lane.node_state(id) == Some(LineTaskNodeState::Armed) {
                lane.set_node_state(id, LineTaskNodeState::Running);
                if !group.has_action(id) {
                    lane.set_node_state(id, LineTaskNodeState::Completed);
                    return;
                }
                let work = LineTaskWork::Node(id);
                if policy.join == ChildJoinPolicy::Detached {
                    lane.set_node_state(id, LineTaskNodeState::Detached);
                } else {
                    lane.outstanding.insert(work.clone());
                }
                activation.commands.push(LineTaskCommand::Run {
                    tag: LineTaskWorkTag {
                        instance: instance.clone(),
                        work,
                    },
                    policy,
                });
            }
        }
    }
}

fn activate_child<P: LineTaskPlanView>(
    group: &P,
    id: RuntimeLineTaskNodeId,
    elapsed: LogicalDuration,
    events: LineTaskReadyEvents<'_>,
    lane: &mut LineTaskExecutionLane,
    instance: &LineTaskWorkInstance,
    activation: &mut LineTaskActivation,
    node: LineTaskNodeView<'_>,
) {
    let LineTaskNodeView::Child {
        trigger,
        policy: child_policy,
        scope,
    } = node
    else {
        return;
    };
    if matches!(trigger, LineTaskTrigger::Scheduled(_)) {
        return;
    }
    if lane.node_state(id) == Some(LineTaskNodeState::Armed) && trigger_is_ready(&trigger, events) {
        lane.set_node_state(id, LineTaskNodeState::Running);
        activate_node(
            group,
            scope,
            elapsed,
            events,
            lane,
            instance,
            child_policy,
            activation,
        );
        if child_policy.join == ChildJoinPolicy::Detached {
            lane.active_roots.insert(LineTaskActiveRoot::new(scope));
            lane.set_node_state(id, LineTaskNodeState::Detached);
        }
    } else if lane.node_state(id) == Some(LineTaskNodeState::Running) {
        activate_node(
            group,
            scope,
            elapsed,
            events,
            lane,
            instance,
            child_policy,
            activation,
        );
        if let Some(exit) = lane.node_state(scope).filter(|state| state.is_terminal()) {
            lane.set_node_state(id, exit);
        }
    }
}

fn progress_ready_scheduled<P: LineTaskPlanView>(
    group: &P,
    elapsed: LogicalDuration,
    events: LineTaskReadyEvents<'_>,
    state: &mut LineTaskLiveState,
    activation: &mut LineTaskActivation,
) -> Result<(), LineRuntimeError> {
    let ready = std::mem::take(&mut state.scheduled_ready);
    for token in ready {
        if token.activation() != &state.activation || state.scheduled_lanes.contains_key(&token) {
            return Err(LineRuntimeError::DuplicateScheduledWorkInstance);
        }
        let (child, scope, policy) = scheduled_lane_schema(group, &token)?;
        let instance = LineTaskWorkInstance::Scheduled(token.clone());
        let mut lane = LineTaskExecutionLane::new(group.node_count());
        lane.set_node_state(child, LineTaskNodeState::Running);
        activate_node(
            group, scope, elapsed, events, &mut lane, &instance, policy, activation,
        );
        if let Some(exit) = lane.node_state(scope).filter(|state| state.is_terminal()) {
            lane.set_node_state(child, exit);
        }
        if lane.outstanding.is_empty() {
            activation
                .scheduled_completions
                .push(LineTaskScheduledCompletion::new(
                    token,
                    ScopeExit::Completed,
                ));
            continue;
        }
        state.scheduled_lanes.insert(token, lane);
    }
    Ok(())
}

fn progress_scheduled_lane<P: LineTaskPlanView>(
    group: &P,
    token: &RuntimeLineHandleToken,
    elapsed: LogicalDuration,
    events: LineTaskReadyEvents<'_>,
    state: &mut LineTaskLiveState,
    activation: &mut LineTaskActivation,
) -> Result<(), LineRuntimeError> {
    let (child, scope, policy) = scheduled_lane_schema(group, token)?;
    let mut lane = state
        .scheduled_lanes
        .remove(token)
        .ok_or(LineRuntimeError::MissingScheduledWork)?;
    let instance = LineTaskWorkInstance::Scheduled(token.clone());
    activate_node(
        group, scope, elapsed, events, &mut lane, &instance, policy, activation,
    );
    progress_active_roots(group, elapsed, events, &mut lane, &instance, activation);
    if let Some(exit) = lane.node_state(scope).filter(|state| state.is_terminal()) {
        lane.set_node_state(child, exit);
    }
    let terminal = lane
        .node_state(child)
        .is_some_and(LineTaskNodeState::is_terminal)
        && lane.outstanding.is_empty()
        && lane.active_roots.is_empty();
    if !terminal {
        state.scheduled_lanes.insert(token.clone(), lane);
    }
    Ok(())
}

fn scheduled_lane_schema<P: LineTaskPlanView>(
    group: &P,
    token: &RuntimeLineHandleToken,
) -> Result<
    (
        RuntimeLineTaskNodeId,
        RuntimeLineTaskNodeId,
        LineTaskExitPolicy,
    ),
    LineRuntimeError,
> {
    let child = group
        .scheduled_child(token.site())
        .ok_or(LineRuntimeError::InvalidScheduledWorkState)?;
    let Some(LineTaskNodeView::Child {
        trigger: LineTaskTrigger::Scheduled(site),
        policy,
        scope,
    }) = group.node_view(child)
    else {
        return Err(LineRuntimeError::InvalidScheduledWorkState);
    };
    if site != token.site()
        || policy.join != ChildJoinPolicy::Join
        || policy.cancel != ChildCancelPolicy::CancelAndJoin
        || !matches!(group.node_view(scope), Some(LineTaskNodeView::Action))
    {
        return Err(LineRuntimeError::InvalidScheduledWorkState);
    }
    Ok((child, scope, policy))
}

fn sequence_exit(
    children: &[RuntimeLineTaskNodeId],
    lane: &LineTaskExecutionLane,
) -> Option<LineTaskNodeState> {
    for child in children {
        match lane.node_state(*child)? {
            LineTaskNodeState::Failed => return Some(LineTaskNodeState::Failed),
            LineTaskNodeState::Cancelled | LineTaskNodeState::Cancelling => {
                return Some(LineTaskNodeState::Cancelled);
            }
            LineTaskNodeState::Armed | LineTaskNodeState::Running => return None,
            LineTaskNodeState::Detached | LineTaskNodeState::Completed => {}
        }
    }
    Some(LineTaskNodeState::Completed)
}

fn parallel_exit(
    children: &[RuntimeLineTaskNodeId],
    lane: &LineTaskExecutionLane,
) -> Option<LineTaskNodeState> {
    let states = children
        .iter()
        .map(|child| lane.node_state(*child))
        .collect::<Option<Vec<_>>>()?;
    if states.contains(&LineTaskNodeState::Failed) {
        Some(LineTaskNodeState::Failed)
    } else if states.contains(&LineTaskNodeState::Cancelled)
        || states.contains(&LineTaskNodeState::Cancelling)
    {
        Some(LineTaskNodeState::Cancelled)
    } else if states.iter().all(|state| state.is_terminal()) {
        Some(LineTaskNodeState::Completed)
    } else {
        None
    }
}

fn cancel_remaining(children: &[RuntimeLineTaskNodeId], lane: &mut LineTaskExecutionLane) {
    for child in children {
        if !lane
            .node_state(*child)
            .is_some_and(LineTaskNodeState::is_terminal)
        {
            lane.set_node_state(*child, LineTaskNodeState::Cancelling);
            lane.cancelling_nodes.insert(*child);
        }
    }
}

fn progress_active_roots<P: LineTaskPlanView>(
    group: &P,
    elapsed: LogicalDuration,
    events: LineTaskReadyEvents<'_>,
    lane: &mut LineTaskExecutionLane,
    instance: &LineTaskWorkInstance,
    activation: &mut LineTaskActivation,
) {
    let roots = lane.active_roots.iter().copied().collect::<Vec<_>>();
    for root in roots {
        if lane
            .node_state(root.node())
            .is_some_and(LineTaskNodeState::is_terminal)
        {
            lane.active_roots.remove(&root);
            continue;
        }
        activate_node(
            group,
            root.node(),
            elapsed,
            events,
            lane,
            instance,
            LineTaskExitPolicy::default(),
            activation,
        );
        if lane
            .node_state(root.node())
            .is_some_and(LineTaskNodeState::is_terminal)
        {
            lane.active_roots.remove(&root);
        }
    }
}

fn trigger_is_ready(trigger: &LineTaskTrigger, events: LineTaskReadyEvents<'_>) -> bool {
    match trigger {
        LineTaskTrigger::Immediate => true,
        LineTaskTrigger::Mark(mark) => events.marks().contains(mark),
        LineTaskTrigger::Scheduled(_) => false,
    }
}

#[cfg(test)]
mod retained_reducer_tests {
    use super::*;
    use crate::entry::{RuntimeSchemaError, RuntimeSchemaLimits};
    use crate::value::{AwbcRuntimeValueSnapshotError, RuntimeRetainedValueAdmission};
    use std::num::NonZeroU32;

    fn activation() -> DialogueActivationId {
        DialogueActivationId::new(
            crate::effect::RuntimeArtifactFingerprint::try_from_bytes([0x63; 32]).unwrap(),
            crate::runtime_id::RuntimePersistentFiberId::from_allocated(1),
            crate::runtime_id::RuntimeDialogueContentPlanId::from_accepted_ordinal(NonZeroU32::MIN),
            1,
        )
    }

    fn group(count: usize) -> LineTaskGroup {
        let node = |index| RuntimeLineTaskNodeId::from_zero_based(index).unwrap();
        let mut nodes = vec![LineTaskNode::Action(Box::new([])); count];
        if count > 1 {
            nodes[0] = LineTaskNode::Sequence((1..count).map(node).collect());
        }
        LineTaskGroup::new(
            crate::plan::RuntimeFunctionDefinitionIdentity::from_accepted_identity([72; 32]),
            crate::plan::RuntimeEffectSet::empty(),
            Box::new([]),
            Box::new([]),
            Box::new([]),
            RuntimePlanTypeId::from_accepted_ordinal(NonZeroU32::MIN),
            Box::new([]),
            node(0),
            nodes.into_boxed_slice(),
            Box::new([]),
            LineTaskCleanup::default(),
        )
    }

    #[test]
    fn live_and_inert_reducers_obey_exact_collection_limits_without_projection() {
        let plan = group(64);
        let live = LineTaskLiveState::new(&plan, activation());
        let inert = live.snapshot();
        let before = serde_json::to_vec(&inert).unwrap();
        let mut exact = RuntimeRetainedValueAdmission::standalone(RuntimeSchemaLimits {
            max_sequence_items: 64,
            ..RuntimeSchemaLimits::engine_default()
        });
        live.admit_retained(&plan, &mut exact).unwrap();
        inert.admit_retained(&plan, &mut exact).unwrap();
        let mut short = RuntimeRetainedValueAdmission::standalone(RuntimeSchemaLimits {
            max_sequence_items: 63,
            ..RuntimeSchemaLimits::engine_default()
        });
        let failure = live.admit_retained(&plan, &mut short).unwrap_err();
        assert_eq!(
            failure,
            LineTaskSnapshotError::Value(AwbcRuntimeValueSnapshotError::Resource(
                RuntimeSchemaError::BudgetExceeded {
                    budget: "sequence_items",
                }
            ),)
        );
        assert_eq!(
            inert.admit_retained(&plan, &mut short).unwrap_err(),
            failure
        );
        let mut short = RuntimeRetainedValueAdmission::standalone(RuntimeSchemaLimits {
            max_sequence_items: 63,
            ..RuntimeSchemaLimits::engine_default()
        });
        assert_eq!(
            inert.admit_retained(&plan, &mut short).unwrap_err(),
            failure
        );
        assert_eq!(serde_json::to_vec(&live.snapshot()).unwrap(), before);
        assert_eq!(serde_json::to_vec(&inert).unwrap(), before);
        let decoded: LineTaskLiveSnapshot = serde_json::from_slice(&before).unwrap();
        decoded.admit_retained(&plan, &mut exact).unwrap();
        assert_eq!(decoded, inert);
    }

    #[derive(Serialize)]
    #[serde(transparent)]
    struct BorrowOnlyRows<T>(Box<[T]>);

    impl<T> LineTaskRows<T> for BorrowOnlyRows<T> {
        fn rows<'a>(&'a self) -> impl ExactSizeIterator<Item = &'a T>
        where
            T: 'a,
        {
            self.0.iter()
        }
    }

    #[test]
    fn reducer_admission_requires_no_clone_and_shares_the_enclosing_work_bank() {
        let plan = group(1);
        let saved = LineTaskLiveState::new(&plan, activation()).snapshot();
        assert!(saved.scheduled_lanes.is_empty());
        let lane = LineTaskExecutionLaneStorage {
            node_states: saved.activation_lane.node_states,
            outstanding: BorrowOnlyRows(saved.activation_lane.outstanding),
            active_roots: BorrowOnlyRows(saved.activation_lane.active_roots),
            cancelling_nodes: BorrowOnlyRows(saved.activation_lane.cancelling_nodes),
        };
        let reducer = LineTaskReducerState {
            activation: saved.activation,
            phase: saved.phase,
            cancellation_action: saved.cancellation_action,
            activation_lane: lane,
            scheduled_lanes: BTreeMap::new(),
            scheduled_ready: BorrowOnlyRows(saved.scheduled_ready),
            consumed_content_events: BorrowOnlyRows(saved.consumed_content_events),
            consumed_input_actions: BorrowOnlyRows(saved.consumed_input_actions),
            cleanup_started: saved.cleanup_started,
        };
        let before = serde_json::to_vec(&reducer).unwrap();
        let limits = RuntimeSchemaLimits {
            max_sequence_items: 512,
            max_validation_work: 512,
            ..RuntimeSchemaLimits::engine_default()
        };
        let mut fresh = RuntimeRetainedValueAdmission::standalone(limits);
        reducer.admit_retained(&plan, &mut fresh).unwrap();
        let mut shared = RuntimeRetainedValueAdmission::standalone(limits);
        shared.validate_metadata(&[(); 511][..]).unwrap();
        let failure = reducer.admit_retained(&plan, &mut shared).unwrap_err();
        assert!(matches!(
            failure,
            LineTaskSnapshotError::Value(AwbcRuntimeValueSnapshotError::Resource(
                RuntimeSchemaError::ValidationWork {
                    limit: 512,
                    consumed: 513,
                    ..
                }
            ),)
        ));
        assert_eq!(
            reducer.admit_retained(&plan, &mut shared).unwrap_err(),
            failure
        );
        assert_eq!(serde_json::to_vec(&reducer).unwrap(), before);
    }
    #[test]
    fn live_and_inert_input_admission_share_order_replay_and_limit_checks() {
        use arcweft_interaction_model::input::{InputEpoch, InputSequence};
        let event = |sequence| {
            RuntimeDialogueInputActionEvent::new(
                activation(),
                InputActionId::new("input.cancel").unwrap(),
                InputEpoch::new(1),
                InputSequence::new(sequence),
            )
        };
        let first = event(1);
        let second = event(2);
        fn check(
            reducer: &impl LineTaskReducerView,
            first: &RuntimeDialogueInputActionEvent,
            second: &RuntimeDialogueInputActionEvent,
        ) {
            let admitted = reducer
                .inspect_input_action_events([second, first])
                .unwrap()
                .into_pending_events();
            assert_eq!(admitted, [first.clone(), second.clone()]);
            assert!(matches!(
                reducer
                    .inspect_input_action_events([first, first])
                    .err()
                    .unwrap(),
                LineRuntimeError::DuplicateInputActionEvent { .. }
            ));
            assert_eq!(
                reducer
                    .inspect_input_action_events(std::iter::repeat_n(first, 65_537))
                    .err()
                    .unwrap(),
                LineRuntimeError::InputActionHistoryLimitExceeded
            );
        }
        let mut live = LineTaskLiveState::new(&group(1), activation());
        check(&live, &first, &second);
        check(&live.snapshot(), &first, &second);
        live.accept_input_action_events(std::slice::from_ref(&first))
            .unwrap();
        let inert = live.snapshot();
        for failure in [
            live.inspect_input_action_events([&first]).err().unwrap(),
            inert.inspect_input_action_events([&first]).err().unwrap(),
        ] {
            assert_eq!(
                failure,
                LineRuntimeError::ConsumedInputActionEvent {
                    event: first.clone()
                }
            );
        }
        assert_eq!(live.snapshot(), inert);
    }
}
