$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\git\arcweft'
$env:CARGO_INCREMENTAL='0'
$env:NEXTEST_EXPERIMENTAL_LIBTEST_JSON='1'
$root=$PSScriptRoot
$publication=Get-Content -Raw "$root/original-source-owner-fixed.publication.json" | ConvertFrom-Json
$steps=[Collections.Generic.List[object]]::new()
function Assert-Source {
    if ((git rev-parse HEAD) -ne $publication.Source -or (git rev-parse 'HEAD^{tree}') -ne $publication.Tree -or @(git diff --name-only HEAD).Count -ne 0) { throw 'Validation input changed' }
}
function Run-Step([string]$name,[string]$command,[string[]]$arguments,[string]$output,[string]$errors) {
    Assert-Source
    $started=Get-Date -Format o
    Write-Output "START $name"
    & $command @arguments > $output 2> $errors
    $code=$LASTEXITCODE
    Assert-Source
    $steps.Add([pscustomobject]@{Name=$name;Command=$command;Arguments=$arguments;Started=$started;Finished=(Get-Date -Format o);ExitCode=$code;Output=$output;OutputSHA256=(Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash;Errors=$errors;ErrorsSHA256=(Get-FileHash -LiteralPath $errors -Algorithm SHA256).Hash})
    [ordered]@{Version=1;Source=$publication.Source;Tree=$publication.Tree;Environment=@{CARGO_INCREMENTAL='0'};Steps=@($steps.ToArray())} | ConvertTo-Json -Depth 9 | Set-Content -Encoding utf8 "$root/original-source-owner-fixed.validation.json"
    Write-Output "END $name exit=$code"
}
Run-Step 'owner-list' 'cargo' @('nextest','list','-p','arcweft-lang-sema','--locked','--all-features','--lib','--tests','--message-format','json') "$root/original-source-owner-fixed.owner-list.json" "$root/original-source-owner-fixed.owner-build.log"
if ($steps[-1].ExitCode -ne 0) { exit $steps[-1].ExitCode }
Run-Step 'owner-run' 'cargo' @('nextest','run','-p','arcweft-lang-sema','--locked','--all-features','--lib','--tests','--no-fail-fast','--message-format','libtest-json-plus') "$root/original-source-owner-fixed.owner-results.jsonl" "$root/original-source-owner-fixed.owner-run.log"
Run-Step 'workspace-check' 'cargo' @('check','--workspace','--locked','--all-targets','--all-features') "$root/original-source-owner-fixed.workspace-check.stdout" "$root/original-source-owner-fixed.workspace-check.log"
Run-Step 'workspace-clippy' 'cargo' @('clippy','--workspace','--locked','--all-targets','--all-features') "$root/original-source-owner-fixed.workspace-clippy.stdout" "$root/original-source-owner-fixed.workspace-clippy.log"
Run-Step 'fmt' 'cargo' @('fmt','--all','--','--check') "$root/original-source-owner-fixed.fmt.stdout" "$root/original-source-owner-fixed.fmt.log"
Run-Step 'structure' 'just' @('structure-audit-gate') "$root/original-source-owner-fixed.structure.stdout" "$root/original-source-owner-fixed.structure.log"
Run-Step 'sema-doctest' 'cargo' @('test','-p','arcweft-lang-sema','--locked','--all-features','--doc') "$root/original-source-owner-fixed.sema-doctest.stdout" "$root/original-source-owner-fixed.sema-doctest.log"
if (@($steps | Where-Object { $_.ExitCode -ne 0 -and $_.Name -ne 'owner-run' }).Count -ne 0) { exit 1 }
exit $steps[1].ExitCode
