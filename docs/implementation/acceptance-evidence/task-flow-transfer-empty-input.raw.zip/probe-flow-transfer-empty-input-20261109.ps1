$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$cli='flow-transfer-empty-input-20261109.cli-r1'
$pin=Get-Content "$r/$cli.main-before.json" -Raw|ConvertFrom-Json -DateKind String
$freeze=Get-Content "$r/$cli.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20 -DateKind String
if($freeze.base -ne (git rev-parse HEAD).Trim()){throw 'Probe source differs from CLI source'}
function Assert-Main {if((Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -ne $pin.sha256){throw 'Pinned CLI changed'}}
function Assert-Source {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}}
Assert-Main
Assert-Source
$started=[DateTime]::UtcNow.ToString('o')
$rows=@(foreach($case in @(
    [pscustomobject]@{name='empty-control';manifest="$r/stateful-goto-current-20261109.empty-control/arcw.toml";expected=0},
    [pscustomobject]@{name='self-goto';manifest="$r/stateful-goto-current-20261109.self-goto/arcw.toml";expected=1},
    [pscustomobject]@{name='modern-feedback';manifest='D:/git/arcweft/samples/modern-feedback-view/arcw.toml';expected=1}
)){
    $stem="$r/flow-transfer-empty-input-20261109.probe.$($case.name)"
    if(Test-Path ($stem+'.check.log')){throw 'Probe epoch exists'}
    $source=Join-Path (Split-Path $case.manifest) 'src/main.arcw'
    $sourceHash=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant()
    $artifact="D:/git/arcweft/target/arcweft/flow-transfer-empty-input-$($case.name).awfb"
    if(Test-Path -LiteralPath $artifact){throw 'Output artifact epoch exists'}
    Assert-Main
    & $pin.path check --manifest-path $case.manifest --json *> ($stem+'.check.log')
    $check=$LASTEXITCODE
    Assert-Main
    & $pin.path bundle --manifest-path $case.manifest --profile main --output $artifact --json *> ($stem+'.bundle.log')
    $bundle=$LASTEXITCODE
    Assert-Main
    if($check -ne $case.expected -or $bundle -ne $case.expected){throw ('Unexpected check/bundle result: '+$case.name)}
    if((Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant() -ne $sourceHash){throw 'Probe input changed'}
    $row=[ordered]@{name=$case.name;manifest=$case.manifest;source=$source;sourceSha256=$sourceHash;sourceDrift=0;checkExitCode=$check;bundleExitCode=$bundle;artifactExists=(Test-Path -LiteralPath $artifact)}
    if($case.expected -eq 0){
        $row.artifact=[ordered]@{path=$artifact;bytes=(Get-Item -LiteralPath $artifact).Length;sha256=(Get-FileHash -LiteralPath $artifact).Hash.ToLowerInvariant()}
    }else{
        foreach($kind in @('check','bundle')){if(!([IO.File]::ReadAllText($stem+".$kind.log").Contains('sema.goto.argument_count'))){throw 'Missing source-backed transfer diagnostic'}}
        if($row.artifactExists){throw 'Rejected transfer produced a bundle'}
        $row.diagnostic='sema.goto.argument_count'
    }
    $row
})
Assert-Source
Assert-Main
$record=[ordered]@{version=1;source=$freeze.base;main=$pin;binaryDrift=0;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o');rows=$rows;scope='Reuses the actual nextest-pinned CLI at its original path. The old minimal fixtures and complete repository sample are unchanged. No extra Cargo build or artifact copy. Missing argument rejection is complete; explicit transfer, runtime cleanup/input preservation and Native/Web sample interaction remain pending.'}
$record|ConvertTo-Json -Depth 15|Set-Content "$r/flow-transfer-empty-input-20261109.probe.json" -Encoding utf8
$rows|ConvertTo-Json -Depth 8
