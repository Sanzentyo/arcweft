$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$stem="$r/flow-transfer-empty-input-20261109.quality"
$freeze=Get-Content "$r/flow-transfer-empty-input-20261109.owner-r1.source-freeze.json" -Raw|ConvertFrom-Json -Depth 20
& "$r/assert-no-arcweft-build.ps1"
function Assert-Inputs {
    foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Source drift: '+$row.path)}}
}
function Invoke-Recorded([string]$name,[string[]]$arguments) {
    Assert-Inputs
    $started=[DateTime]::UtcNow.ToString('o')
    & cargo @arguments *> ($stem+".$name.log")
    $code=$LASTEXITCODE
    Assert-Inputs
    [ordered]@{version=1;base=$freeze.base;command=$arguments;exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 10|Set-Content ($stem+".$name.receipt.json") -Encoding utf8
    if($code -ne 0){throw ('Quality failed: '+$name)}
}
Invoke-Recorded 'metadata' @('metadata','--locked','--all-features','--format-version','1')
$m=Get-Content ($stem+'.metadata.log') -Raw|ConvertFrom-Json -Depth 100
$root=@($m.packages|Where-Object name -eq 'arcweft-lang-sema')
if($root.Count -ne 1){throw 'Missing Sema owner'}
$closure=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
[void]$closure.Add($root[0].id)
do {
    $changed=$false
    foreach($node in $m.resolve.nodes){if(!$closure.Contains($node.id) -and @($node.dependencies|Where-Object {$closure.Contains($_)}).Count){$changed=$closure.Add($node.id) -or $changed}}
}while($changed)
$packages=@($m.packages|Where-Object {$_.id -in $m.workspace_members -and $closure.Contains($_.id)}|Sort-Object name|Select-Object name,id)
Invoke-Recorded 'tree' @('tree','--locked','--all-features','--target','all','--invert','arcweft-lang-sema','--prefix','none','--format','{p}')
$treeNames=@(Get-Content ($stem+'.tree.log')|ForEach-Object {if($_ -match '^([A-Za-z0-9_-]+) v'){ $Matches[1] }}|Where-Object {$_ -in $m.packages.name}|Sort-Object -Unique)
if(@(Compare-Object @($packages.name) $treeNames).Count){throw 'Metadata/tree reverse closure differs'}
[ordered]@{version=1;base=$freeze.base;metadataSha256=(Get-FileHash ($stem+'.metadata.log')).Hash.ToLowerInvariant();workspacePackages=$m.workspace_members.Count;owners=@('arcweft-lang-sema');selection='rdeps(=arcweft-lang-sema)';packages=$packages;packageCount=$packages.Count;treeAgreement=$true}|ConvertTo-Json -Depth 8|Set-Content "$r/flow-transfer-empty-input-20261109.graph.json" -Encoding utf8
Invoke-Recorded 'check' @('check','--locked','--workspace','--all-targets','--all-features')
Invoke-Recorded 'clippy' @('clippy','--locked','-p','arcweft-lang-sema','--all-targets','--all-features')
$paths=@(git diff --name-only -- '*.rs')+@('crates/arcweft-lang-sema/src/final_analysis/tests/flow_transfer.rs')
Assert-Inputs
& rustfmt --check --edition 2024 --config skip_children=true $paths *> ($stem+'.fmt.log')
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=$freeze.base;paths=$paths;exitCode=$code;sourceDrift=0}|ConvertTo-Json -Depth 8|Set-Content ($stem+'.fmt.receipt.json') -Encoding utf8
if($code -ne 0){throw 'Format failed'}
Write-Output 'Flow transfer quality complete'
