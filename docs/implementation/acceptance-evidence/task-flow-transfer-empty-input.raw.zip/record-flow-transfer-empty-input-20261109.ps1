$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$r=$PSScriptRoot
$lf=[string][char]10
. "$r/convergence-image-git-bytes.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$r/$name" -Raw|ConvertFrom-Json -Depth 100 -DateKind String}
$prefix='flow-transfer-empty-input-20261109'
$pub=Read-Record "$prefix.source.verified.json"
$owner=Read-Record "$prefix.owner-r1.runtime.terminal-audit.json"
$noncli=Read-Record "$prefix.noncli-r1.runtime.terminal-audit.json"
$cli=Read-Record "$prefix.cli-r1.runtime.terminal-audit.json"
$oldCli=Read-Record 'style-environment-integrated-20261109.cli-r1.runtime.terminal-audit.json'
$pin=Read-Record "$prefix.cli-r1.main-audit.json"
$coverage=Read-Record "$prefix.coverage.json"
$graph=Read-Record "$prefix.graph.json"
$probe=Read-Record "$prefix.probe.json"
$diagnostics=Read-Record "$prefix.failure-diagnostics.json"
$quality=[ordered]@{}
foreach($name in @('check','clippy','fmt')){$quality[$name]=Read-Record "$prefix.quality.$name.receipt.json";if($quality[$name].exitCode -ne 0 -or $quality[$name].sourceDrift -ne 0){throw 'Quality receipt failed'}}
if((git rev-parse HEAD).Trim() -ne $pub.commit -or $pub.commit -ne $noncli.base -or $cli.base -ne $pub.commit){throw 'Published source mismatch'}
if($owner.passed -ne 6 -or $owner.failed -ne 0 -or $noncli.passed -ne 3630 -or $noncli.failed -ne 0 -or $cli.executed -ne 711 -or $cli.passed -ne 707 -or $cli.failed -ne 4){throw 'Unexpected terminal results'}
if(($cli.failureSet|ConvertTo-Json -Depth 12 -Compress) -cne ($oldCli.failureSet|ConvertTo-Json -Depth 12 -Compress)){throw 'CLI failure set changed'}
foreach($run in @($owner,$noncli,$cli)){if($run.sourceDrift -ne 0 -or $run.catalogCaseDrift -ne 0){throw 'Matrix drift'}}
if($coverage.missing.Count -ne 0 -or $coverage.duplicates.Count -ne 0 -or $coverage.baselineCases -ne 3622 -or $coverage.currentCases -ne 3630){throw 'Coverage changed'}
if($pin.binaryDrift -ne 0 -or $probe.binaryDrift -ne 0 -or $probe.sourceDrift -ne 0 -or $pin.sha256 -ne $probe.main.sha256){throw 'Actual CLI changed'}
$control=@($probe.rows|Where-Object name -eq 'empty-control')[0]
if($control.artifact.sha256 -ne 'b5aa326bb5e140ceb389032c5e10818c5e177b28247c2e98692d68031024b61e'){throw 'Stateful startup control changed'}
$archive="docs/implementation/acceptance-evidence/task-flow-transfer-empty-input.raw.zip"
if(Test-Path -LiteralPath $archive){throw 'Archive exists'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=@(Get-ChildItem -LiteralPath $r -File -Filter "$prefix*"|Where-Object {$_.Extension -in @('.json','.log','.patch','.txt')})
$files+=@(Get-Item "$r/run-flow-transfer-empty-quality-20261109.ps1","$r/probe-flow-transfer-empty-input-20261109.ps1","$r/audit-flow-transfer-empty-cli-failures-20261109.ps1","$r/record-flow-transfer-empty-input-20261109.ps1")
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in ($files|Sort-Object FullName -Unique)){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{$entries=$zip.Entries.Count;if(@($zip.Entries|Where-Object FullName -match '\.(exe|awfb|dll|pdb|rlib|rmeta)$').Count){throw 'Build artifact archived'}}finally{$zip.Dispose()}
$entry=[ordered]@{
 version=1;date='2026-11-09';publication=$pub
 status='Argumentless static goto and compact Choice transfers now reject missing complete formal inputs during semantic analysis. This completes that admission boundary, not parameterized transfer execution.'
 contract='One method on the checked callable catalog reads the exact original Flow declaration signature, including unused and wildcard formals. Goto statement sealing and compact Choice validation share this authority. No local-use reconstruction, implicit root-state injection or new ordinary call capability. Stateful Entry startup remains a separate typed invocation.'
 owner=$owner;graph=$graph;quality=$quality;nonCli=$noncli;cli=$cli;main=$pin;coverage=$coverage;failureDiagnostics=$diagnostics;actualCliProbe=$probe
 freshMatrix=[ordered]@{executed=($noncli.executed+$cli.executed);passed=($noncli.passed+$cli.passed);failed=($noncli.failed+$cli.failed);skipped=($noncli.skipped+$cli.skipped);scope='Only the final non-CLI all-feature run and CLI default run. Do not add owner6, initial development5, prior Source runs, or separate check/bundle probes.'}
 preservation='Prior Sema3622 case IDs are retained without omissions or duplicates. Added8 comprise prior Environment Compiler3/Sema1 and this admission change Sema4. Zero-input static/dynamic goto and compact Choice, foreign-generation rejection, stateful startup, and all selected existing behavior remain passing.'
 actualProbe='Same original-path nextest-pinned CLI: unchanged empty stateful Flow check0/bundle0, 13 instructions/38016 bytes and identical prior artifact hash. Unchanged minimal self-goto and complete repository modern-feedback check1/bundle1 with sema.goto.argument_count, outputs absent. Source and main hashes unchanged. The earlier actual check0 and AWBC block0/block25 failures remain historical evidence for their recorded Source.'
 diagnosticDisplayLimit='The semantic diagnostic retains its original SourceSpan, but actual CLI output says source text is unavailable and omits span labels. Original-line rendering is unaccepted and remains a separate CLI consumer boundary; no display success is claimed.'
 pending='Implement explicit Flow argument binding and transfer through RuntimePlan, Native cleanup/private rollback and AWBC/public save. Preserve source evaluation and value cleanup order, full formal admission and the original sample behavior. Complete modern-feedback AWFB and actual Native/Web operation/capture acceptance.'
 archive=[ordered]@{path=$archive;entries=$entries;bytes=(Get-Item -LiteralPath $archive).Length;sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()}
}
$registry='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$original=[Text.Encoding]::UTF8.GetString((Read-GitBytes @('show',('HEAD:'+$registry)))).TrimEnd()
$prior=$original|ConvertFrom-Json -Depth 100 -DateKind String
if(@($prior.PSObject.Properties).Count -ne 152 -or $prior.PSObject.Properties.Name -contains 'flowTransferEmptyInputAdmission'){throw 'Unexpected registry state'}
$combined=$original.Substring(0,$original.Length-1).TrimEnd()+','+$lf+'  "flowTransferEmptyInputAdmission": '+($entry|ConvertTo-Json -Depth 100)+$lf+'}'+$lf
$after=$combined|ConvertFrom-Json -Depth 100 -DateKind String
foreach($property in $prior.PSObject.Properties){if(($property.Value|ConvertTo-Json -Depth 100 -Compress) -cne ($after.($property.Name)|ConvertTo-Json -Depth 100 -Compress)){throw ('History changed: '+$property.Name)}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $registry),$combined,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$generic=@($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')})
$gotoRow='| 引数を持つFlowへのgoto | **引数なし転送の不足入力拒否は検証・公開済み。明示引数の転送は未達** | Source '+$pub.commit+'。元Flow宣言のcomplete formalを単一のchecked catalogから取得し、裸のgotoとChoice省略形を意味解析で検査する。未使用／wildcard formalも数え、root stateを暗黙補完しない。stateful Entryの初期入力と、引数なしの静的／動的goto・Choiceの既受入は維持。実CLIで同じ最小2入力を確認し、空Flowはcheck／13命令AWFB成功・以前と同じhash、自己gotoはcheck／bundleともsema.goto.argument_countで拒否・出力なし。旧AWBCでの遅い失敗は履歴へ保持。明示引数のbinding／評価順／cleanupを越えた値保持／両実行器への転送は継続する。診断の原文位置表示が現CLIで省略される問題も未達。sample固有の状態は専用行へ集約した。[実測・full SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$sampleRow='| modern-feedback-viewのSource/API移行 | **現行APIへの移行を公開済み。現Engineはgotoの不足引数を拒否、AWFBと実操作は未達** | sample Source 8d9a57e08bdcbd207b322fd3cd80337688d23f49。元画像／metadata、全Style・font stack・各Text property、input metadata、2 Actionとpayload、2 mount scope、全対話／分岐／GameState／自己gotoを保持した現行API移行を維持する。Engine '+$pub.commit+' の同じ実CLIでcheck／bundleは下のgoto不足引数診断で終了1、出力なし。以前のEngineでの実check成功とAWBC block25拒否は履歴へ保持し、現在の成功として重複掲載しない。入力API移行やStyleの受入を戻さず、明示引数転送の修復後にAWFB／Native／Web操作・画像parityを検証する。[原本・全SHA・保持範囲](acceptance-evidence/task-flow-registry-execution.json)。 |'
$matrixRow='| 共有契約／推移的逆依存matrix | **今回Sema範囲4341実行：4337 PASS／4 FAIL／24 SKIP** | Source '+$pub.commit+'。metadata／target-all tree一致の逆依存22 packageを、非CLI全feature21とCLI既定へ分けた。非CLI3630／3630 PASS・1 SKIP・281.133秒。旧Sema3622件の欠落／重複0、追加8件は既存Environment4と今回Sema4。CLIの失敗・本体pinは専用行へ集約。Source／catalog／実EXE drift0。最終2 runのみ集計し、owner6件・初回dev5件・旧run・別CLI probeを加算しない。前回View5397件は元Source・入力に対する実測として履歴へ保持し、今回の再実行とはしない。workspace全98 packageの全target／全feature check、Sema全target／全feature Clippy、変更Rust8 pathのfmtは終了0。[終端・品質・coverage・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$cliRow='| CLIの規定対象／全 check 照合 | **goto入力検査後のCLI既定711件：707 PASS／4 FAIL／23 SKIP** | Source '+$pub.commit+'。先行と同じ4失敗IDと実診断を照合し、新規失敗0。Scrollのshared callable Expr15拒否、active dialogue has no voice、promotion2件のsolver到達前Expr8 type-check拒否は未解消。元pathの実CLIとtest EXEを前後照合し、本体SHA256は'+$pin.sha256+'。別の最小対照／sample check・bundle probeは711件へ加算せず、対象行と履歴で範囲を区別する。[診断・本体pin・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'
$status=(@($status -split $lf|ForEach-Object {
 if($_.StartsWith('| 引数を持つFlowへのgoto ')){$gotoRow}
 elseif($_.StartsWith('| modern-feedback-viewのSource/API移行 ')){$sampleRow}
 elseif($_.StartsWith('| 共有契約／推移的逆依存matrix ')){$matrixRow}
 elseif($_.StartsWith('| CLIの規定対象／全 check 照合 ')){$cliRow}
 elseif($_.StartsWith('確認日 ')){$_.Replace('8d9a57e08bdcbd207b322fd3cd80337688d23f49',$pub.commit)}
 else{$_}
})) -join $lf
if((@($status -split $lf|Where-Object {$_.StartsWith('| Generic Match ')}) -join $lf) -cne ($generic -join $lf)){throw 'Generic Match acceptance changed'}
[IO.File]::WriteAllText($statusPath,$status.Replace(([string][char]13+[char]10),$lf),[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-09 — Flowの引数なし転送を元formal ABIで検査

Source $($pub.commit) をmainへ通常公開し、parent／tree／9 pathのblobとpatchを照合した。元Flow宣言のcomplete formalをchecked callable catalogから検査する一つの所有APIへ、裸のgotoとChoice省略形を接続した。未使用・wildcard formalも含め、引数を渡していない入力を意味解析で拒否する。stateful Entryのtyped startupをこの検査へ流用せず、root stateの暗黙補完や、inert Flow参照への通常call権限を追加していない。明示引数のbinding／転送やcleanup保持は未実装のままであり、このcutをそれらの受入にしない。

owner6件は全PASS。workspace98 packageのlocked／全target／全feature check、Sema全target／全feature Clippy、変更Rust8 pathのfmtは終了0。Clippy終了0を警告0とは記さない。owner／品質／非CLIは3921入力、CLIは$($cli.sourceInputs)入力でSource差分0。metadataとtarget-all逆依存treeが一致し、Sema逆依存22 packageを非CLI全feature21とCLI既定へ分けた。非CLI3630／3630 PASS・1 SKIP・281.133秒。旧Sema3622 IDの欠落／重複0、追加8は先行Environment Compiler3／Sema1と今回Sema4。CLI711実行は707 PASS／4 FAIL／23 SKIP。同じ4失敗IDとScroll Expr15／voice不在／promotion2件のsolver前Expr8をrawから照合した。今回の最終2 runだけで4341実行／4337 PASS／4 FAIL／24 SKIP。owner6や初回dev5、旧Source run、別probeは加算しない。Source／catalog／test EXE差分0、実CLI本体SHA256 $($pin.sha256) のruntime前後pin一致。過去のView5397件と全full SHAは元入力に対する履歴として保持する。

同じ実CLIを追加Cargo buildなしで元pathから再利用し、以前の最小2 fixtureと現repo modern-feedbackを変更せずcheck／bundleを実行した。空stateful Flowは両方終了0、13命令／38016 bytes／SHA256 $($control.artifact.sha256) で以前と一致。自己gotoと完全なsampleは両方終了1、sema.goto.argument_count、出力なし。以前のcheck0／AWBC block0・25の失敗を削除せず、遅いABI失敗を意味解析で早く拒否した現在との差を記録する。sampleのAPI移行とStyle等の既受入は戻さない。一方、実CLIのSource本文表示は利用できずspan label省略のnoteが出るため、原文位置の表示成功は主張しない。

現状一覧のgoto／sample／matrix／CLI行を今回の範囲へ更新し、旧check成功を現Engineの成功として重複掲載しない。Generic Match行を含む他項目の受入は変更していない。既存152 registry propertyの全値を保持し、flowTransferEmptyInputAdmissionを追加した。原本 $archive は$entries entry／$($entry.archive.bytes) bytes、SHA256 $($entry.archive.sha256)。ログ・metadata・patchと記録scriptだけを格納し、EXE／AWFB等のbuild artifactをコピーしていない。
"@
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
[IO.File]::WriteAllText($historyPath,[IO.File]::ReadAllText($historyPath).TrimEnd()+$lf+$history.Replace(([string][char]13+[char]10),$lf)+$lf,[Text.UTF8Encoding]::new($false))
[ordered]@{source=$pub.commit;preservedRecords=@($prior.PSObject.Properties).Count;records=@($after.PSObject.Properties).Count;archive=$entry.archive}|ConvertTo-Json -Depth 8|Set-Content "$r/$prefix.acceptance-record.json" -Encoding utf8
Get-Content "$r/$prefix.acceptance-record.json"
