param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
function Final-Cases([string]$run){
    $audit=Read-Record "$run.runtime.terminal-audit"
    $lines=[IO.File]::ReadAllLines("$e/$run.runtime.log")
    $summary=[Array]::FindIndex($lines,[Predicate[string]]{param($line) $line -cmatch '^\s*Summary\s+\['})
    if($summary -lt 0){throw "Missing terminal: $run"}
    $rows=@{}
    foreach($line in $lines[($summary+1)..($lines.Length-1)]){
        if($line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
            $key=$Matches[2]+"`t"+$Matches[3]
            if($rows.ContainsKey($key)){throw 'Duplicate terminal case'}
            $rows[$key]=[ordered]@{binary=$Matches[2];test=$Matches[3];status=$Matches[1];run=$run}
        }
    }
    if($rows.Count -ne $audit.executed -or $audit.sourceDrift -or $audit.catalogCaseDrift){throw "Terminal/source mismatch: $run"}
    return $rows
}
$reuse=Read-Record "$Stem.reuse"
$full=Read-Record "$Stem.full-catalog.inventory"
$coverage=@{}
function Add-Case($row,[string]$kind){$key=$row.binary+"`t"+$row.test;if($coverage.ContainsKey($key)){throw "Duplicate coverage: $key"};$coverage[$key]=[ordered]@{binary=$row.binary;test=$row.test;status=$row.status;run=$row.run;kind=$kind}}
$fresh=Final-Cases "$Stem.remaining"
foreach($row in $fresh.Values){Add-Case $row 'fresh'}
if($reuse.reusedCaseCount){
    $old=Final-Cases $reuse.reusedOwnerRun
    foreach($row in $reuse.reusedCases){$key=$row.binary+"`t"+$row.test;if(-not $old.ContainsKey($key) -or $old[$key].status -notin @('PASS','SLOW')){throw 'Reused case was not passing'};Add-Case $old[$key] 'reused-identical-executable'}
}
if($reuse.reuseFocused){
    $focused=Final-Cases $reuse.focusedRun
    foreach($row in $reuse.focusedCases){$key=$row.binary+"`t"+$row.test;if(-not $focused.ContainsKey($key) -or $focused[$key].status -notin @('PASS','SLOW')){throw 'Focused case was not passing'};Add-Case $focused[$key] 'reused-identical-executable'}
}
$wanted=@($full.rows|Where-Object status -eq 'matches')
$expected=@($wanted|ForEach-Object {$_.binary+"`t"+$_.test})
if($coverage.Count -ne $wanted.Count -or @(Compare-Object $expected @($coverage.Keys)).Count){throw 'Full distinct case coverage differs'}
$subsets=[ordered]@{}
foreach($name in @('genericMatch','view40','qualifiedAction11','referenceRegressions7')){
    $previous=Read-Record "entity-reference-types-$name"
    $observed=@(foreach($row in $previous.cases){$key=$row.binary+"`t"+$row.test;if(-not $coverage.ContainsKey($key)){throw "Accepted case absent: $key"};$coverage[$key]})
    $failed=@($observed|Where-Object {$_.status -notin @('PASS','SLOW')})
    $subsets[$name]=[ordered]@{passed=$observed.Count-$failed.Count;failed=$failed.Count;caseDrift=0;cases=$observed}
}
$newNames=@('action_declaration_retains_its_original_public_identity_through_serde_and_layout','action_declaration_admits_one_non_generic_record_payload_and_bounds_its_identity','action_nominal_source_preserves_identity_and_preflights_payload_shape_before_materializing','action_nominal_wire_retains_the_original_declaration_and_rejects_foreign_families','action_declarations_require_one_exact_non_generic_record_payload','structural_nominal_variants_keep_their_declaration_identity','action_payload_type_retains_the_original_declaration_in_plan_and_decoded_awbc')
$new=@(foreach($name in $newNames){$found=@($coverage.Values|Where-Object {$_.test.EndsWith('::'+$name) -or $_.test -eq $name});if($found.Count -ne 1){throw "New case count differs: $name"};$found[0]})
$subsets['actionIdentity7']=[ordered]@{passed=@($new|Where-Object {$_.status -in @('PASS','SLOW')}).Count;failed=@($new|Where-Object {$_.status -notin @('PASS','SLOW')}).Count;cases=$new}
$failed=@($coverage.Values|Where-Object {$_.status -notin @('PASS','SLOW')})
$record=[ordered]@{version=1;source=(git rev-parse HEAD).Trim();fullCatalog=$Stem+'.full-catalog';distinctCases=$coverage.Count;passed=$coverage.Count-$failed.Count;failed=$failed.Count;freshCases=$fresh.Count;reusedPackageCases=$reuse.reusedCaseCount;reusedFocusedCases=$(if($reuse.reuseFocused){3}else{0});caseDrift=0;sourceInputs=$reuse.sourceInputs;sourceDrift=0;reuseProof=$reuse;subsets=$subsets;failures=$failed;cases=@($coverage.Values|Sort-Object binary,test);scope='Distinct coverage combines fresh remaining runtime with precisely proven passing executions. This is not relabeled as a single fresh full-suite run.'}
$record|ConvertTo-Json -Depth 30|Set-Content -LiteralPath "$e/action-original-declaration-normal-coverage.json" -Encoding utf8
[ordered]@{distinctCases=$record.distinctCases;passed=$record.passed;failed=$record.failed;fresh=$fresh.Count;reused=$reuse.reusedCaseCount;focused=$record.reusedFocusedCases;requiredSubsets=@($subsets.Keys|ForEach-Object {[ordered]@{name=$_;passed=$subsets[$_].passed;failed=$subsets[$_].failed}})}|ConvertTo-Json -Depth 8
