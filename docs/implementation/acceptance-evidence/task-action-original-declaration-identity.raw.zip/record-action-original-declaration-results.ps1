$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
function Read-Record([string]$name){Get-Content -LiteralPath "$e/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$source='7104b200150b9b85b31cd686c48573b92b2028d3'
if((git rev-parse HEAD).Trim() -ne $source){throw 'Source HEAD differs'}
$stem='action-original-declaration-reverse-normal1-20261103'
$normal=Read-Record "$stem.remaining.runtime.terminal-audit"
$coverage=Read-Record 'action-original-declaration-normal-coverage'
if(-not $normal.isPassingRun -or $coverage.failed -or $coverage.caseDrift -or $coverage.sourceDrift -or $coverage.distinctCases -ne 9194){throw 'Current normal coverage has not passed'}
foreach($subset in $coverage.subsets.PSObject.Properties){if($subset.Value.failed){throw "Required subset failed: $($subset.Name)"}}
$coverageSummary=$coverage|Select-Object * -ExcludeProperty cases
$coverageSummary|Add-Member -NotePropertyName caseProvenanceArchiveEntry -NotePropertyValue 'action-original-declaration-normal-coverage.json'
$cli=Read-Record 'action-original-declaration-reverse-cli1-20261103.runtime.terminal-audit'
if($cli.sourceDrift -or $cli.catalogCaseDrift -or $cli.executed -ne 693){throw 'CLI input or case drift'}
$quality=@(foreach($suffix in @('check','clippy','structure')){$name="action-original-declaration-quality1-20261103-$suffix";$receipt=Read-Record $name;if($receipt.exitCode -or $receipt.sourceDrift){throw "Quality failed: $name"};[ordered]@{run=$name;receipt=$receipt}})
$format=Read-Record 'action-original-declaration-format-check'
if($format.exitCode -or $format.source -ne $source -or $format.paths -ne 22){throw 'Formatting check differs'}
$quality += [ordered]@{run='action-original-declaration-format-check';receipt=$format}
$supplemental=[ordered]@{}
foreach($suffix in @('docs','wasm')){$name="action-original-declaration-docs-wasm1-20261103-$suffix";$receipt=Read-Record $name;if($receipt.exitCode -or $receipt.sourceDrift){throw "Supplemental failed: $name"};$supplemental[$suffix]=$receipt}
$docRows=@();$docCrate=$null
foreach($line in [IO.File]::ReadLines("$e/action-original-declaration-docs-wasm1-20261103-docs.log")){
    if($line -match '^\s*Doc-tests\s+(\S+)'){$docCrate=$Matches[1]}
    elseif($line -match '^test result: ok[.] (\d+) passed; (\d+) failed; (\d+) ignored;'){
        if(-not $docCrate){throw 'Doctest result has no crate owner'}
        $docRows += [ordered]@{crate=$docCrate;passed=[int]$Matches[1];failed=[int]$Matches[2];ignored=[int]$Matches[3]};$docCrate=$null
    }
}
if($docRows.Count -ne 9 -or @($docRows|Where-Object failed -ne 0).Count){throw 'Doctest crate terminals differ'}
$docTotal=0;foreach($docRow in $docRows){$docTotal+=$docRow.passed}
[ordered]@{version=1;run='action-original-declaration-docs-wasm1-20261103-docs';rows=$docRows;passed=$docTotal;failed=0}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$e/action-original-declaration-doctest-cases.json" -Encoding utf8
$freeze=Read-Record 'action-original-declaration-goldens1-20261103.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Current input drift: $($row.path)"}}
$untracked=Read-Record 'task-documentation-final-untracked-before'
foreach($row in $untracked.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Original untracked drift: $($row.path)"}}
$metrics=Import-Csv -LiteralPath "$e/action-original-declaration-quality1-20261103.structure-report/file_metrics.csv"
$packages=Import-Csv -LiteralPath "$e/action-original-declaration-quality1-20261103.structure-report/package_metrics.csv"
$cohesion=@(foreach($path in Get-Content -LiteralPath "$e/checkpoint-action-original-declaration.owned.txt"){
    $metric=@($metrics|Where-Object path -eq $path)
    if($metric.Count -ne 1 -or (Get-Item -LiteralPath $path).Length -ne [long]$metric[0].bytes){throw "Structural measurement differs: $path"}
    $disposition=switch -Regex ($path){
        '^crates/arcweft-lang-sema/' {'Accepted HIR Action declarations supply their original PublicId to the existing nominal declaration identity producer. The producer retains ownership of its structural digest; no lexical reconstruction or new schema catalog.';break}
        '^crates/arcweft-runtime-plan/' {'The existing type inventory lowers borrowed original declaration metadata into the corresponding AWBC row. Ownership cloning occurs only when the final row is constructed; no secondary identity authority.';break}
        '/task/semantic[.]rs$' {'One charged semantic encoder owns the declaration digest and optional original Action identity tuple. Type and domain rows call this same encoder; exact and one-under limits are tested.';break}
        '/entry/schema/nominal' {'The nominal schema owner authenticates the optional Action family and one non-generic named record shape, bounds identity strings before retention, and rejects conflicting payload owners. Its existing graph encoding and behavioral tests stay with this invariant.';break}
        '/awbc/' {'The existing AWBC type schema, wire codec and structural verifier retain the declaration identity in the closed nominal type algebra. Structural nominal variants remain valid; Action identities require one exact non-generic record. No host I/O or parallel Action registry.';break}
        '/plan/type_table' {'The existing type table and source grammar retain original nominal metadata. Source preflight authenticates family, root role and zero arity before materialization; the same final type table remains the authority.';break}
        '/plan/body_semantic/nominal' {'The nominal body transcript calls the shared charged declaration encoder. Literal version-one goldens document the complete bytes, including ordinary non-Action markers.';break}
        default {'Existing behavioral consumer tests migrate borrowed declaration metadata and verify original identity through real Native/canonical decoded AWBC execution. No production owner or API is introduced solely for test placement.'}
    }
    [ordered]@{path=$path;crate=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLoc=[int]$metric[0].physical_lines;embeddedTestLoc=[int]$metric[0].embedded_test_lines;classification=$metric[0].classification;dependencyMetrics=@($packages|Where-Object package -eq $metric[0].owner)[0];disposition=$disposition;apiReview='Public API changes express borrowed versus owned identity after removing Copy. No visibility widening for physical splitting, new dependency direction or unrelated mutable state.'}
})
$recordPath='docs/implementation/acceptance-evidence/task-action-original-declaration-identity.json'
if(Test-Path -LiteralPath $recordPath){throw 'Preserve the existing record'}
& "$e/archive-action-original-declaration-results.ps1"
$record=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=$source
    publication=(Read-Record 'checkpoint-action-original-declaration.verified')
    authority='RuntimeNominalDeclarationId is the one original declaration identity: producer-owned digest plus optional validated Action PublicId. The existing schema graph, source type table, semantic transcript, Native type metadata, AWBC row and version-one codecs retain this identity. Action payloads have one non-generic named record owner. Metadata does not confer executable channel authority.'
    acceptance=[ordered]@{normal=$normal;distinctCoverage=$coverageSummary;cli=$cli;cliDelta=(Read-Record 'action-original-declaration-cli-delta');cliDiagnostics=(Read-Record 'action-original-declaration-cli-diagnostic-excerpts');quality=$quality;supplemental=$supplemental;doctestCases=(Read-Record 'action-original-declaration-doctest-cases');resolvedGraph=(Read-Record 'action-original-declaration.reverse-graph-reuse')}
    provenance=[ordered]@{sourceEpoch='action-original-declaration-goldens1-20261103';sourceInputs=$freeze.paths.Count;sourceDrift=0;heldTracked=12;originalUntracked=6;originalUntrackedDrift=0;reuse=(Read-Record "$stem.reuse");meaning='The 70-package catalog selected 9194 distinct normal cases. Previously passing Sema, RuntimePlan, Compiler and focused Core results were not reused because their test executable hashes differ in the full consumer context. All 9194 cases execute afresh. Source pins include preserved user WIP; a published production SHA alone does not describe every CLI fixture.'}
    earlierAttempts=@(
        [ordered]@{run='action-original-declaration-owner1-20261103';result=(Read-Record 'action-original-declaration-owner1-20261103.catalog');reason='Catalog compilation exposed missing PublicId serde adaptation and owned/borrowed identity migrations; no runtime tests executed.'},
        [ordered]@{run='action-original-declaration-owner2-20261103';result=(Read-Record 'action-original-declaration-owner2-20261103.runtime.terminal-audit');reason='3734 passed and one exact nominal-document golden failed. The expected version-one bytes omitted the new ordinary-declaration marker; the literal golden was corrected.'},
        [ordered]@{run='action-original-declaration-owner3-20261103';result=(Read-Record 'action-original-declaration-owner3-20261103.catalog');reason='Catalog compile failed: the new compiler test passed a borrowed decode budget instead of the required value, and Windows E0786 reported mmap/pagefile resource error 1455. No runtime tests executed. The API call was corrected; narrower and later full compilation succeeded without clean, artifact deletion or build concurrency changes.'},
        [ordered]@{run='action-original-declaration-callable1-20261103';result=(Read-Record 'action-original-declaration-callable1-20261103.runtime.terminal-audit');reason='86 passed and 225 failed after nominal verification omitted legitimate structural nominal variants. The closed nominal algebra was repaired generally while retaining the stricter Action-record rule.'},
        [ordered]@{run='action-original-declaration-callable2-20261103';result=(Read-Record 'action-original-declaration-callable2-20261103.runtime.terminal-audit');reason='All 311 callable cases passed after the general verifier repair; this precedes the later shared semantic-body encoding change.'},
        [ordered]@{run='action-original-declaration-owner4-20261103';result=(Read-Record 'action-original-declaration-owner4-20261103.runtime.terminal-audit');reason='4629 passed and two exact semantic-body goldens failed after the declaration tuple was completed. Both omitted the ordinary-declaration marker; only cfg(test) files changed afterward.'},
        [ordered]@{run='action-original-declaration-goldens1-20261103';result=(Read-Record 'action-original-declaration-goldens1-20261103.runtime.terminal-audit');reason='The two repaired exact-byte goldens and the enhanced identity/byte-budget regression all passed. The final full consumer run executes these cases again.'}
    )
    ownershipReview=$cohesion
    corrections=@('The former opaque nominal digest did not retain the original Action PublicId. The existing declaration identity now owns both; no Action schema side table or lexical fallback was added.','Structural nominal variants are legitimate members of the nominal algebra; their initial rejection was a new verifier regression and is fixed without weakening Action payload rules.','The current status consolidates final source and validation results here; earlier counts, failures and full SHAs remain historical evidence.','Generic Match remains accepted and published. Separate CLI failures, metadata foundation work and the overall unfinished goal do not reopen its completed boundary.')
    scopeExclusion='This accepts original nominal Action declaration identity retention and rejection/codec/source-execution coverage. Actual Action emit/receive, executable channel admission, suspended continuation and save/restore remain separate unfinished boundaries in current-status.md. All owned contract markers remain 1. The overall goal remains active.'
    raw=(Read-Record 'action-original-declaration-raw-manifest')
}
$record|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $recordPath -Encoding utf8
[ordered]@{source=$source;normal=$normal.summary;cli=$cli.summary;rawEntries=$record.raw.entries.Count}|ConvertTo-Json
