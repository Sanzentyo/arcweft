param([Parameter(Mandatory)][ValidateSet('normal','cli')][string]$Slice,[Parameter(Mandatory)][string]$Stem,[Parameter(Mandatory)][string]$Epoch,[switch]$GraphOnly)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
$graphPath="$taskTemp/action-qualified-path.reverse-graph.json"
if(-not(Test-Path -LiteralPath $graphPath)) {
    & cargo metadata --format-version 1 --all-features --locked > "$taskTemp/action-callable-constructor.metadata.json" 2> "$taskTemp/action-callable-constructor.metadata.stderr.log"
    if($LASTEXITCODE){throw 'Resolved graph failed'}
    & cargo tree --workspace --invert arcweft-lang-syntax --all-features --locked > "$taskTemp/action-callable-constructor.tree.log" 2>&1
    if($LASTEXITCODE){throw 'Reverse tree failed'}
    $metadata=Get-Content -LiteralPath "$taskTemp/action-callable-constructor.metadata.json" -Raw|ConvertFrom-Json -Depth 100
    $roots=@('arcweft-lang-syntax','arcweft-lang-hir','arcweft-lang-sema','arcweft-runtime-plan','arcweft-lsp')
    $selected=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach($package in $metadata.packages){if($package.name -in $roots){[void]$selected.Add($package.id)}}
    do {
        $changed=$false
        foreach($node in $metadata.resolve.nodes){
            if($selected.Contains($node.id)){continue}
            if(@($node.deps|Where-Object {$selected.Contains($_.pkg)}).Count){[void]$selected.Add($node.id);$changed=$true}
        }
    } while($changed)
    $freeze=Get-Content -LiteralPath "$taskTemp/$Epoch.source-freeze.json" -Raw|ConvertFrom-Json
    $inputs=@($freeze.paths|Where-Object path -Match '(Cargo\.(toml|lock)|rust-toolchain\.toml|\.cargo[/\\]config\.toml)$')
    [ordered]@{version=1;base=(git rev-parse HEAD).Trim();roots=$roots;metadata='action-callable-constructor.metadata.json';graphInputs=$inputs;reversePackages=@($metadata.packages|Where-Object { $_.id -in $metadata.workspace_members -and $selected.Contains($_.id)}|Sort-Object name|ForEach-Object name);workspaceCount=$metadata.workspace_members.Count;resolvedPackages=$metadata.packages.Count}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $graphPath -Encoding utf8
}
$graph=Get-Content -LiteralPath $graphPath -Raw|ConvertFrom-Json
foreach($row in $graph.graphInputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Graph input drift: $($row.path)"}}
if($GraphOnly){[ordered]@{roots=$graph.roots;reversePackages=$graph.reversePackages;reverseCount=$graph.reversePackages.Count;graphInputs=$graph.graphInputs.Count;workspaceCount=$graph.workspaceCount;resolvedPackages=$graph.resolvedPackages}|ConvertTo-Json -Depth 5;exit 0}
$selection=@()
foreach($package in $graph.reversePackages){if(($Slice -eq 'cli') -eq ($package -eq 'arcweft-cli')){$selection+=@('-p',$package)}}
$selection+=@('--all-targets','--all-features','--locked')
$paths=@((Get-Content -LiteralPath "$taskTemp/$Epoch.source-freeze.json" -Raw|ConvertFrom-Json).paths.path)
& "$taskTemp/run-presentation-projection-owner.ps1" -Stem $Stem -Selection $selection -ExpectedMatches -1 -AdditionalPaths $paths
exit $LASTEXITCODE
