$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$record=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-action-original-declaration-identity.json -Raw|ConvertFrom-Json -Depth 100
$normal=$record.acceptance.normal;$cli=$record.acceptance.cli;$delta=$record.acceptance.cliDelta
if(-not $normal.isPassingRun -or $record.acceptance.distinctCoverage.reusedPackageCases -or $record.acceptance.distinctCoverage.reusedFocusedCases){throw 'Expected fresh passing full normal run'}
$sha=$record.source
$link='acceptance-evidence/task-action-original-declaration-identity.json'
$path='docs/implementation/current-status.md'
$text=[IO.File]::ReadAllText([IO.Path]::GetFullPath($path))
function Replace-Line([string]$prefix,[string]$replacement){
    $pattern='(?m)^'+[regex]::Escape($prefix)+'[^\r\n]*'
    if([regex]::Matches($script:text,$pattern).Count -ne 1){throw "Current-status row differs: $prefix"}
    $script:text=[regex]::Replace($script:text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match) $replacement})
}
Replace-Line '確認日:' "確認日: 2026-11-03。最新公開Sourceは$sha。元Action宣言のidentityを既存nominal型ownerへ接続し、影響71 packageを検証した。通常側は9194件を新規実行して全PASS。CLIの実際の失敗、check／Clippy・doctest・Web checkの範囲は下表へ集約する。既存12 tracked／6 actual untracked WIPを保持している。"
Replace-Line '| Action宣言・payload record／型付きチャンネル値 |' "| Action宣言・payload record／型付きチャンネル値 | **修飾付き宣言・call構築と元宣言identity保持は検証・公開済み。送受信・channelの停止復元は別境界** | Source $sha。既存RuntimeNominalDeclarationIdがproducerのdigestと元Action PublicIdを一緒に保持する。Sema／schema graph／type table／semantic transcript／Native／AWBCとversion 1 codecを同じidentityへ揃え、異family・generic／variant payload・同じAction IDの競合を拒否する。暗黙の末尾aliasを作らない値探索、local rootの隠蔽・visibility、通常binder・source order・captureの既受入を維持する。元宣言IDをlexical bindingと独立に保持したpayloadのSource実行はNative／canonical decoded AWBCで実戻り値42。追加7件、既存修飾Action11件は今回も全PASS。metadataから実行権限は作らず、emit／receive・元programでのchannel admission・保存復元は未実装の別境界。[今回の実測・失敗・修復理由・raw]($link)、[宣言・call構築の既受入](acceptance-evidence/task-action-qualified-path.json)。 |"
$genericLabel='| Generic Match `.1.2` C3/C5 |'
Replace-Line $genericLabel ($genericLabel+" **受入・公開済み** | 受入850534b9e9bc8c8872f6528dd00050a5e6e7699e、公開f0e7ae9662b8f216d7f19dcbea3d4341fcfe7ca2。115 transcript、24 coverage、5公開query、7 Native／decoded-AWBC継続・保存の151件。Source $sha・4083入力でも同じ151 IDが151／151 PASS、除外0。完全transcript、uninhabited-domain、Never／let-else、exhaustive-only atomic publicationの既受入を維持する。[受入監査](acceptance-evidence/accepted-generic-c3-c5-closure-audit.json)、[公開記録](acceptance-evidence/accepted-generic-phase-note-publication.json)、[最新151件照合]($link)。 |")
Replace-Line '| 共有契約／推移的逆依存matrix |' "| 共有契約／推移的逆依存matrix | **影響71 packageを照合。通常側9194／9194 PASS** | Source $sha、all-target／all-feature／locked、4083入力。通常70 package中66に実行対象があり、25 ignored。残る4 packageはcompileのみ。先行ownerの成功は実行ファイルのhashが異なるため再利用せず、9194件をすべて新規実行した。既受入Generic Match151／View40／修飾Action11／Entity参照7と今回のAction identity7を同じcase IDで照合し、すべてPASS。Source／case／test EXE差分0。以前の9187件run・Native63件修復は履歴と旧原本へ保持し、この現状行との重複説明を整理した。[実graph・全case・失敗原本・修復]($link)。 |"
Replace-Line '| CLI全target照合 |' "| CLI全target照合 | **$($cli.executed)件を全実行し$($cli.passed) PASS／$($cli.failed) FAIL** | Source $sha、all-target／all-feature／locked、4083入力、$($cli.skipped) ignored。Source／case／test EXE差分0。直前のCLI結果との失敗ID比較は維持$(@($delta.retainedFailureIds).Count)／追加$(@($delta.newlyFailingIds).Count)／解消$(@($delta.resolvedFailureIds).Count)。ID一致だけから原因の同一性を推定せず、今回の全stderrを[原本]($link)へ保持する。CLI統合の未完了を、受入済みの別境界へ転記しない。 |"
Replace-Line '| workspace check／Clippy・fmt・構造gate |' "| workspace check／Clippy・fmt・構造gate | **workspace全98のcheck／Clippy・構造gateは終了0。警告は残存** | Source $shaと同じ4083入力でall-target／all-feature／lockedの全98 gateが終了0。変更Rust 22 pathのrustfmt checkも終了0。9 crateのdoctestは$($record.acceptance.doctestCases.passed)／$($record.acceptance.doctestCases.passed) PASS、うち$(@($record.acceptance.doctestCases.rows|Where-Object passed -eq 0).Count) crateは0件。Web wasm32-unknown-unknown checkも終了0。履歴と今回のgateを一つの再実行として合算しない。[全実測・exact入力・凝集性レビュー]($link)。 |"
[IO.File]::WriteAllText([IO.Path]::GetFullPath($path),$text,[Text.UTF8Encoding]::new($false))
$prefix=Get-Content -LiteralPath "$e/action-original-declaration.history-prefix-before.json" -Raw|ConvertFrom-Json
$history=[IO.Path]::GetFullPath($prefix.path)
$before=[IO.File]::ReadAllBytes($history)
if($before.Length -ne $prefix.bytes -or [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant() -ne $prefix.sha256){throw 'Historical prefix changed before append'}
$append=@"


## 元Action宣言identityの保持と逆依存検証 — 2026-11-03

公開Sourceは$sha（parent 922d1010f066443a7dbe1a424ecdf5f6266ea9d2、tree 15051b8a9f6c4419c07ac583f1e107e07a7f1a25）。22 path／632 insertions／36 deletionsを通常commit・non-forced pushし、full patch・全blob・remoteを照合した。元の12 tracked／6 actual untracked WIPを保持した入力4083 pathをpinした。

既存nominal declaration identityをproducer digestと元Action PublicIdの組へ完成させた。新たなAction schema表・字句名からの逆引き・互換readerは追加していない。schema graph、Source type table、共通semantic encoder、Native metadata、AWBC row／codecが同じidentityを保持する。Action payloadは一つの非generic named recordへ制限する。metadata自体は実行権限を発行しない。送受信・実channel admission・停止保存の実装完了とはしない。

初回owner1はPublicIdのSerde adapterとborrow／owned移行が不足しcatalog compile終了101、runtime未実行。owner2は3735件中3734 PASS／1 exact-byte golden FAIL。owner3は新Compiler caseのdecode budget引数誤りとWindows E0786／mmap 1455でcatalog compile終了101、runtime未実行。API呼出しを修復し、cache削除・clean・build jobs変更は行わず後続compileを成功させた。callable1は311件中86 PASS／225 FAILで、nominal verifierが正当なstructural variantを除外していた新規不具合を修復した。Action record条件を維持したままcallable2は311／311 PASS。owner4は4631件中4629 PASS／2 exact-byte golden FAILで、共通semantic encoderのordinary markerを期待bytesへ補正した。以後はcfg(test)の2 pathだけが変わり、対象goldens1は3／3 PASS。これらの失敗・入力・終端を消さず原本へ保持する。

最終通常側は70 package／9194件をすべて新規実行し、$($normal.summary)。先行成功のSema／RuntimePlan／CompilerとCore対象3件は、全consumer構成の実行ファイルhashが一致しないため再利用しなかった。66 packageに実行対象、4 packageはcompileのみ、25 ignored。Generic Match151／View40／修飾Action11／Entity参照7／新Action identity7の正確なIDを照合し全PASS、Source／case／test EXE差分0。

CLIは$($cli.summary)。直前結果との失敗IDは維持$(@($delta.retainedFailureIds).Count)／追加$(@($delta.newlyFailingIds).Count)／解消$(@($delta.resolvedFailureIds).Count)。同じIDだけから原因の同一性は主張しない。workspace全98のcheck／Clippy・canonical構造gateは終了0、警告あり。変更Rust 22 pathのrustfmt checkも終了0。9 crateのdoctestは$($record.acceptance.doctestCases.passed)件PASS（$(@($record.acceptance.doctestCases.rows|Where-Object passed -eq 0).Count) crateは0件）、Web wasm check終了0。raw archiveは$($record.raw.entries.Count) entries／$($record.raw.bytes) bytes、SHA256 $($record.raw.sha256)、全entry hash差分0。

訂正理由: 現状一覧の旧Source／9187件とNative63件の説明は今回のfull consumer結果で置き換え、旧実測は旧原本とこの履歴に保持した。Generic Matchの受入・公開は維持し、今回も同じ151件の成功を確認した。全体goalやCLIの未達を受入済み機能の残作業へ戻さない。唯一の現状一覧は[current-status.md](current-status.md)、このcutの全入力・失敗・修復・full SHA・所有レビューは[原本]($link)へ集約する。
"@
$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append)
$stream=[IO.File]::Open($history,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try {$stream.Write($bytes)} finally {$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($history);$retained=[byte[]]::new($before.Length);[Array]::Copy($after,$retained,$retained.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($retained)).ToLowerInvariant() -ne $prefix.sha256){throw 'Historical prefix drift after append'}
[ordered]@{version=1;path=$prefix.path;preservedBytes=$prefix.bytes;preservedSha256=$prefix.sha256;prefixDrift=0;appendedBytes=$bytes.Length}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath "$e/action-original-declaration-history-append.json" -Encoding utf8
