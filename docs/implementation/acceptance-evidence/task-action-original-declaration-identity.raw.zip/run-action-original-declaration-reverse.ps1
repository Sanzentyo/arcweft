param([Parameter(Mandatory)][string]$Stem)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$epoch='action-original-declaration-goldens1-20261103'
$freeze=Get-Content -LiteralPath "$e/$epoch.source-freeze.json" -Raw|ConvertFrom-Json
$graph=Get-Content -LiteralPath "$e/action-qualified-path.reverse-graph.json" -Raw|ConvertFrom-Json
foreach($row in $graph.graphInputs){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Resolved graph inputs changed'}}
function Assert-Inputs {foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}}
$selection=@();foreach($package in $graph.reversePackages){if($package -ne 'arcweft-cli'){$selection+=@('-p',$package)}}
$selection+=@('--all-targets','--all-features','--locked')
$catalogName="$Stem.full-catalog"
if(Test-Path -LiteralPath "$e/$catalogName.json"){throw 'Full catalog already exists; observe its original handle'}
Assert-Inputs
$started=[DateTime]::UtcNow.ToString('o')
& cargo nextest list @selection --message-format json *> "$e/$catalogName.log"
$code=$LASTEXITCODE
Assert-Inputs
[ordered]@{version=1;base=(git rev-parse HEAD).Trim();command=@('nextest','list')+$selection+@('--message-format','json');exitCode=$code;sourceInputs=$freeze.paths.Count;sourceDrift=0;startedAt=$started;finishedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$e/$catalogName.json" -Encoding utf8
if($code){throw 'Full consumer catalog failed'}
$line=[IO.File]::ReadLines("$e/$catalogName.log")|Where-Object {$_.StartsWith('{"rust-build-meta"')}|Select-Object -Last 1
$catalog=$line|ConvertFrom-Json -Depth 100
$cases=@(foreach($suite in $catalog.'rust-suites'.PSObject.Properties){foreach($case in $suite.Value.testcases.PSObject.Properties){[ordered]@{package=$suite.Value.'package-name';binary=$suite.Value.'binary-id';test=$case.Name;ignored=$case.Value.ignored;status=$(if($case.Value.ignored){'ignored'}else{$case.Value.'filter-match'.status})}}})
[ordered]@{rows=$cases;excluded=@($cases|Where-Object status -ne 'matches').Count}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath "$e/$catalogName.inventory.json" -Encoding utf8
$pins=@(foreach($suite in $catalog.'rust-suites'.PSObject.Properties){$path=$suite.Value.'binary-path';[ordered]@{binary=$suite.Value.'binary-id';path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$pins|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$e/$catalogName.binaries.json" -Encoding utf8
$currentPins=@{};foreach($pin in $pins){$currentPins[$pin.binary]=$pin.sha256}
$oldStem='action-original-declaration-owner4-20261103'
$oldAudit=Get-Content -LiteralPath "$e/$oldStem.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$oldInventory=Get-Content -LiteralPath "$e/$oldStem.catalog.inventory.json" -Raw|ConvertFrom-Json
$oldPins=Get-Content -LiteralPath "$e/$oldStem.binaries-before.json" -Raw|ConvertFrom-Json
$oldFreeze=Get-Content -LiteralPath "$e/$oldStem.source-freeze.json" -Raw|ConvertFrom-Json
$oldHashes=@{};foreach($row in $oldFreeze.paths){$oldHashes[$row.path]=$row.sha256}
$delta=@($freeze.paths|Where-Object {$oldHashes[$_.path] -ne $_.sha256})
$allowed=@('D:/git/arcweft/crates/arcweft-core/src/entry/schema/nominal/tests.rs','D:/git/arcweft/crates/arcweft-core/src/plan/body_semantic/nominal/tests.rs')
$testOnlyDelta=$delta.Count -eq 2 -and @($delta|Where-Object {([IO.Path]::GetFullPath($_.path) -replace '\\','/') -notin $allowed}).Count -eq 0
if($oldAudit.sourceDrift -or $oldAudit.catalogCaseDrift -or @($oldInventory.rows|Where-Object status -eq 'matches').Count -ne $oldAudit.executed){throw 'Old owner evidence is not internally consistent'}
$candidates=@('arcweft-lang-sema','arcweft-runtime-plan','arcweft-compiler')
$reused=@();$reusedCases=@();$rejected=@()
foreach($package in $candidates){
    $oldCases=@($oldInventory.rows|Where-Object {$_.package -eq $package -and $_.status -eq 'matches'})
    $nowCases=@($cases|Where-Object {$_.package -eq $package -and $_.status -eq 'matches'})
    $a=@($oldCases|ForEach-Object {$_.binary+"`t"+$_.test});$b=@($nowCases|ForEach-Object {$_.binary+"`t"+$_.test})
    $binaryNames=@($oldCases.binary|Sort-Object -Unique)
    $binaryDrift=@($oldPins|Where-Object {$_.binary -in $binaryNames -and $currentPins[$_.binary] -ne $_.sha256})
    $failed=@($oldAudit.failureSet|Where-Object {$_.binary -in $binaryNames})
    if($testOnlyDelta -and $oldCases.Count -gt 0 -and $a.Count -eq $b.Count -and @(Compare-Object $a $b).Count -eq 0 -and $binaryDrift.Count -eq 0 -and $failed.Count -eq 0){
        $reused+=$package;$reusedCases+=$oldCases
    }else{$rejected+=[ordered]@{package=$package;oldCases=$oldCases.Count;newCases=$nowCases.Count;binaryDrift=$binaryDrift.Count;oldFailures=$failed.Count;testOnlyDelta=$testOnlyDelta}}
}
$focusedAudit=Get-Content -LiteralPath "$e/$epoch.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$focusedInventory=Get-Content -LiteralPath "$e/$epoch.catalog.inventory.json" -Raw|ConvertFrom-Json
$focusedPins=Get-Content -LiteralPath "$e/$epoch.binaries-before.json" -Raw|ConvertFrom-Json
$focused=@($focusedInventory.rows|Where-Object status -eq 'matches')
$reuseFocused=$focusedAudit.isPassingRun -and $focusedAudit.sourceDrift -eq 0 -and $focusedAudit.catalogCaseDrift -eq 0 -and $focused.Count -eq 3 -and @($focusedPins|Where-Object {$currentPins[$_.binary] -ne $_.sha256}).Count -eq 0
$filters=@($reused|ForEach-Object {'package(='+$_+')'})
if($reuseFocused){foreach($case in $focused){$filters+="test(=$($case.test))"}}
if($filters.Count){$selection+=@('-E','not('+($filters -join ' | ')+')')}
$total=@($cases|Where-Object status -eq 'matches').Count
$expected=$total-$reusedCases.Count-$(if($reuseFocused){3}else{0})
[ordered]@{version=1;sourceEpoch=$epoch;sourceInputs=$freeze.paths.Count;sourceDrift=0;fullSelectedCases=$total;reusedOwnerRun=$oldStem;reusedPackages=$reused;reusedCases=$reusedCases;reusedCaseCount=$reusedCases.Count;testOnlySourceDelta=$delta;reusedPackageBinaryDrift=0;reusedPackageCaseDrift=0;focusedRun=$epoch;reuseFocused=$reuseFocused;focusedCases=$(if($reuseFocused){$focused}else{@()});freshExpectedCases=$expected;rejectedReuse=$rejected;meaning='Only passing packages with exact case sets and identical current EXE SHA256 are reused; the two input changes are Core cfg(test) modules. The three repaired/enhanced Core cases are reused only when the current Core test EXE is identical to their fresh passing run. Other Core cases and all remaining consumers execute in the full package/feature context.'}|ConvertTo-Json -Depth 15|Set-Content -LiteralPath "$e/$Stem.reuse.json" -Encoding utf8
[ordered]@{full=$total;reusedPackages=$reused;reusedCases=$reusedCases.Count;focusedReused=$reuseFocused;freshExpected=$expected}|ConvertTo-Json -Compress
& "$e/run-presentation-projection-owner.ps1" -Stem "$Stem.remaining" -Selection $selection -ExpectedMatches $expected -AdditionalPaths @($freeze.paths.path)
exit $LASTEXITCODE
