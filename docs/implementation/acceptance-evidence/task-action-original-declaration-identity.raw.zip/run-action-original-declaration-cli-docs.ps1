$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$e='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$e/assert-no-arcweft-build.ps1"
$epoch='action-original-declaration-goldens1-20261103'
$stem='action-original-declaration-reverse-cli1-20261103'
& "$e/run-action-qualified-reverse.ps1" -Slice cli -Stem $stem -Epoch $epoch
if($LASTEXITCODE -notin @(0,100)){throw 'CLI has no valid terminal'}
$prior=Get-Content -LiteralPath "$e/entity-reference-types-reverse-cli1-20261103.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$current=Get-Content -LiteralPath "$e/$stem.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
$oldKeys=@($prior.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$newKeys=@($current.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
[ordered]@{version=1;source=(git rev-parse HEAD).Trim();current=$current;prior=$prior;comparisonSource='2dbd62719e44c02d794aef4ee484f7715c3150dc';retainedFailureIds=@($current.failureSet|Where-Object {($_.binary+"`t"+$_.test) -in $oldKeys});newlyFailingIds=@($current.failureSet|Where-Object {($_.binary+"`t"+$_.test) -notin $oldKeys});resolvedFailureIds=@($prior.failureSet|Where-Object {($_.binary+"`t"+$_.test) -notin $newKeys});causeCaution='Equal failure IDs do not prove equal causes; the full current diagnostics are retained.'}|ConvertTo-Json -Depth 20|Set-Content -LiteralPath "$e/action-original-declaration-cli-delta.json" -Encoding utf8
Write-Output "CLI delta recorded after valid terminal; no inherited nextest exit is treated as an audit failure."
$global:LASTEXITCODE=0
& "$e/run-entity-reference-docs-wasm.ps1" -Stem 'action-original-declaration-docs-wasm1-20261103' -Epoch $epoch
if($LASTEXITCODE){throw 'Supplemental gate failed'}
