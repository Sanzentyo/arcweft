param([Parameter(Mandatory)][string]$Path,[int]$Lines=6)
$ErrorActionPreference='Stop'
$taskStream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
try {
    $taskLength=$taskStream.Length
    $taskWindow=[int][Math]::Min(65536,$taskLength)
    [void]$taskStream.Seek($taskLength-$taskWindow,[IO.SeekOrigin]::Begin)
    $taskBytes=[byte[]]::new($taskWindow)
    $taskRead=0
    while($taskRead -lt $taskWindow){$taskCount=$taskStream.Read($taskBytes,$taskRead,$taskWindow-$taskRead);if($taskCount -eq 0){break};$taskRead+=$taskCount}
    $taskText=[Text.Encoding]::UTF8.GetString($taskBytes,0,$taskRead)
    $taskOutput=@($taskText -split '\r?\n' | Where-Object {$_} | Select-Object -Last $Lines | ForEach-Object {if($_.Length -gt 600){$_.Substring(0,600)+' [line truncated]'}else{$_}})
    [ordered]@{path=$Path;totalBytes=$taskLength;windowBytes=$taskRead;tail=$taskOutput} | ConvertTo-Json -Depth 3
} finally {$taskStream.Dispose()}