$ErrorActionPreference = 'Stop'
$p=Split-Path -Parent $PSCommandPath
function Read-Primary([string]$path) {
    $lines=[IO.File]::ReadAllLines($path)
    for($i=0;$i -lt $lines.Length-1;$i++){
        if($lines[$i] -notmatch '^error\[' -or $lines[$i+1] -notmatch '^\s*--> (.+\.rs):\d+:\d+') { continue }
        $file=$Matches[1].Replace('\','/')
        $message=$lines[$i].Replace('final_analysis::prepared::PreparedExpressionFact','PreparedExpressionFact').Replace('final_analysis::model::','')
        "$file $message"
    }
}
$old=@(Read-Primary (Join-Path $p 'scoped-binding-completion.dev02-check.log'))
$new=@(Read-Primary (Join-Path $p 'standalone-original-effect-closure.dev01-check.log'))
$delta=@(Compare-Object $old $new)
$distinct=@(Compare-Object @($old | Sort-Object -Unique) @($new | Sort-Object -Unique))
$counts=@($delta | Group-Object SideIndicator | Select-Object Name,Count)
$added=@($delta | Where-Object SideIndicator -eq '=>' | Select-Object -ExpandProperty InputObject)
$removed=@($delta | Where-Object SideIndicator -eq '<=' | Select-Object -ExpandProperty InputObject)
@{baseline='scoped-binding-completion.dev02-check.log';checkpoint='standalone-original-effect-closure.dev01-check.log';baseline_primary=$old.Count;checkpoint_primary=$new.Count;added=$added;removed=$removed;distinct_added=@($distinct | Where-Object SideIndicator -eq '=>' | Select-Object -ExpandProperty InputObject);distinct_removed=@($distinct | Where-Object SideIndicator -eq '<=' | Select-Object -ExpandProperty InputObject);method='Primary Rust code diagnostic headers plus source paths, omitting coordinates and alternate final-analysis type qualifiers.'} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $p 'standalone-original-effect-closure.diagnostic-comparison.json') -Encoding utf8NoBOM
@{counts=$counts;added=@($added|Group-Object|Select-Object Count,Name);baseline_primary=$old.Count;checkpoint_primary=$new.Count} | ConvertTo-Json -Depth 5









