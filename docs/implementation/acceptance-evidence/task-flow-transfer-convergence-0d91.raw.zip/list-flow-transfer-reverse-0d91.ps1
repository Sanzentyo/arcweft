param([string]$Attempt = 'r1')
$ErrorActionPreference = 'Stop'
$e = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
Set-Location -LiteralPath 'D:/git/arcweft'
$base = (& git rev-parse HEAD).Trim()
if ($base -ne '0d91cf3a73891486dc34af1369630f75f4114d0a') { throw 'Unexpected Source HEAD' }
if (@(git diff HEAD --name-only).Count -or @(git diff --cached --name-only).Count) { throw 'Source/index is not frozen' }
$manifestDiff = @(git diff b146a7490ac78f413505f8755148ef86c6048384 HEAD --name-only -- Cargo.toml Cargo.lock .cargo ':(glob)crates/**/Cargo.toml')
if ($manifestDiff.Count) { throw 'Dependency inputs changed; regenerate metadata' }
$graph = Get-Content -Raw -LiteralPath (Join-Path $e 'flow-transfer-plan-rdeps.json') | ConvertFrom-Json
$sourceGraph = Get-Content -Raw -LiteralPath (Join-Path $e 'flow-transfer-source-rdeps.json') | ConvertFrom-Json
$packages = @(@($graph.'arcweft-core'.packages) + @($sourceGraph.closure) | Sort-Object -Unique)
if ($packages.Count -ne 54) { throw 'Incomplete reverse closure union' }
foreach ($required in @('arcweft-core','arcweft-lang-hir','arcweft-lang-sema','arcweft-runtime-plan','arcweft-compiler','arcweft-cli')) {
    if ($required -notin $packages) { throw ('Missing owner: ' + $required) }
}
$cargoArgs = @('nextest','list','--locked','--all-features','-E','rdeps(=arcweft-core) or rdeps(=arcweft-lang-hir)','--message-format','json')
foreach ($package in $packages) { $cargoArgs += @('-p',$package) }
[ordered]@{
    version=1;source=$base;tree=(& git rev-parse 'HEAD^{tree}').Trim();packages=$packages;packageCount=54
    cargoArgs=$cargoArgs;metadata='flow-transfer-plan-rdeps-metadata.json';treeEvidence='flow-transfer-plan-rdeps-tree.log'
    reusedBecause='Cargo/lock/config unchanged since pinned metadata; target-all tree had set difference 0'
    sourceStatus=@(git status --short);defaultFilter='preserved';target='host Windows; target-all is graph evidence only'
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $e ('flow-transfer-convergence-reverse-'+$Attempt+'.inputs.json')) -Encoding utf8
& cargo @cargoArgs *> (Join-Path $e ('flow-transfer-convergence-reverse-list-'+$Attempt+'.log'))
exit $LASTEXITCODE
