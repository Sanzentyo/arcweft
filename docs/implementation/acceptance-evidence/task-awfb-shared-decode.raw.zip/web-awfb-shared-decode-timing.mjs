import { createReadStream } from "node:fs";
import { mkdir } from "node:fs/promises";
import { open } from "node:fs/promises";
import { createServer } from "node:http";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "file:///D:/git/arcweft/web/node_modules/playwright/index.mjs";

const root = normalize("D:/git/arcweft/web");
const maxBlockedAdvances = 16;

const contentTypes = new Map([
  [".awfb", "application/octet-stream"],
  [".css", "text/css; charset=utf-8"],
  [".gif", "image/gif"],
  [".html", "text/html; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".png", "image/png"],
  [".ttf", "font/ttf"],
  [".wasm", "application/wasm"],
  [".webp", "image/webp"],
]);

function fail(message) {
  throw new Error(message);
}

function expect(condition, message) {
  if (!condition) {
    fail(message);
  }
}

function staticPath(requestUrl) {
  const url = new URL(requestUrl, "http://127.0.0.1");
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") {
    pathname = "/index.html";
  }
  if (pathname === "/favicon.ico") {
    return "";
  }
  if (pathname.includes("\0")) {
    return null;
  }
  const fullPath = normalize(join(root, pathname));
  return fullPath.startsWith(root) ? fullPath : null;
}

async function serveFile(request, response) {
  const fullPath = request.url === "/player.js" ? process.env.ARW_PROFILE_PLAYER : staticPath(request.url);
  if (fullPath === "") {
    response.writeHead(204);
    response.end();
    return;
  }
  if (!fullPath) {
    response.writeHead(400);
    response.end("bad path");
    return;
  }
  try {
    const file = await open(fullPath, "r");
    await file.close();
  } catch {
    response.writeHead(404);
    response.end("not found");
    return;
  }

  response.writeHead(200, {
    "content-type": contentTypes.get(extname(fullPath).toLowerCase()) ??
      "application/octet-stream",
  });
  createReadStream(fullPath).pipe(response);
}

function startServer() {
  const server = createServer((request, response) => {
    serveFile(request, response).catch((error) => {
      response.writeHead(500);
      response.end(String(error?.stack ?? error));
    });
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      resolve({ server, baseUrl: `http://127.0.0.1:${address.port}` });
    });
  });
}

function closeServer(server) {
  return new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
}

function collectConsoleErrors(page) {
  const errors = [];
  page.on("console", (message) => {
    if (message.type() === "error") {
      errors.push(message.text());
    }
  });
  page.on("pageerror", (error) => errors.push(error.message));
  return errors;
}

async function openReady(browser, baseUrl, options = {}) {
  const { page, errors } = await openBooted(browser, baseUrl, options);
  await advanceDialogueToChoices(page);
  try {
    await page.waitForFunction(
      () =>
        window.__arcweftLastObservation?.choice_count > 0 &&
        window.__arcweftLastObservation?.image_count >= 4 &&
        window.__arcweftLastFrameObservation?.choice_count === 2 &&
        window.__arcweftLastFrameObservation?.image_count === 4,
      null,
      { timeout: 10_000 },
    );
    await assertFrameObservation(page, await canvasViewport(page));
  } catch (error) {
    const state = await page.evaluate(() => ({
      fatal: document.querySelector("#arcweft-fatal")?.textContent ?? null,
      ready: document.querySelector("#arcweft-canvas")?.dataset.arcweftReady ?? null,
      observation: window.__arcweftLastObservation ?? null,
      frameObservation: window.__arcweftLastFrameObservation ?? null,
    }));
    throw new Error(`${error.message}\nstate=${JSON.stringify(state)}`);
  }
  return { page, errors };
}

async function openBooted(browser, baseUrl, options = {}) {
  const viewport = options.viewport ?? { width: 1280, height: 720 };
  const page = await browser.newPage({
    viewport,
    deviceScaleFactor: options.deviceScaleFactor ?? 1,
  });
  if (options.deterministicClock) {
    await installDeterministicClock(page);
  }
  const errors = collectConsoleErrors(page);
  const started = performance.now();
  page.on("pageerror", (error) => console.error("pageerror", error.message));
  page.on("console", (message) => console.log("browser", message.type(), message.text()));
  await page.goto(`${baseUrl}/index.html`);
  expect(await page.evaluate(() => Boolean(navigator.gpu)), "navigator.gpu is unavailable");
  try {
    await page.waitForFunction(
      () => document.querySelector("#arcweft-canvas")?.dataset.arcweftReady === "true",
      null,
      { timeout: 60_000 },
    );
  } catch (error) {
    const state = await page.evaluate(() => ({
      fatal: document.querySelector("#arcweft-fatal")?.textContent ?? null,
      loadingHidden: document.querySelector("#arcweft-loading")?.hidden ?? null,
      ready: document.querySelector("#arcweft-canvas")?.dataset.arcweftReady ?? null,
      observation: window.__arcweftLastObservation ?? null,
    }));
    throw new Error(`${error.message}\nstate=${JSON.stringify(state)}`);
  }
  const profile = await page.evaluate(() => Object.fromEntries(
    performance.getEntriesByType("mark").filter(({name}) => name.startsWith("arcw.")).map(({name, startTime}) => [name, startTime])
  ));
  console.log("startup profile", JSON.stringify(profile));
  console.log("diagnostic startup ms", performance.now() - started);
  return { page, errors };
}

const { server, baseUrl } = await startServer();
let browser;
try {
  const args = ["--enable-unsafe-webgpu"];
  if (process.platform === "win32") args.push("--use-angle=d3d11");
  browser = await chromium.launch({ channel: process.env.ARW_PLAYWRIGHT_CHANNEL || "chrome", headless: true, args });
  const { page, errors } = await openBooted(browser, baseUrl);
  expect(errors.length === 0, `console errors: ${errors.join("\n")}`);
  await page.close();
} finally {
  if (browser) await browser.close();
  await closeServer(server);
}