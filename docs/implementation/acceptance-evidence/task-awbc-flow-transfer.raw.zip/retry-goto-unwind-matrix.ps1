$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-goto-unwind-hardening-20261107'
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
$paths=$freeze.paths
if(@($paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Frozen source changed before retry'}
$started=[DateTime]::UtcNow
$filter='rdeps(=arcweft-core)'
$listArgs=@('nextest','list','--locked','--workspace','--lib','--tests','-E',$filter,'--message-format','json')
& cargo @listArgs > "$taskTemp/$prefix.reverse.retry1.list.json" 2> "$taskTemp/$prefix.reverse.retry1.list.stderr.log"
$listCode=$LASTEXITCODE
[ordered]@{version=1;arguments=$listArgs;exitCode=$listCode;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o');initialAttempt="$prefix.reverse.list.receipt.json"}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.retry1.list.receipt.json" -Encoding utf8
if($listCode -ne 0){exit $listCode}
$list=Get-Content "$taskTemp/$prefix.reverse.retry1.list.json" -Raw|ConvertFrom-Json -Depth 100
$selected=@(foreach($binary in $list.'rust-suites'.PSObject.Properties){foreach($test in $binary.Value.testcases.PSObject.Properties){if($test.Value.'filter-match'.status -eq 'matches'){[pscustomobject][ordered]@{package=$binary.Value.'package-name';binary=$binary.Value.'binary-name';test=$test.Name}}}})
if(!$selected.Count){throw 'Empty reverse selection'}
$selected|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.selection.json" -Encoding utf8
$runArgs=@('nextest','run','--locked','--workspace','--lib','--tests','-E',$filter,'--no-tests','fail','--no-fail-fast')
& cargo @runArgs *> "$taskTemp/$prefix.reverse.log"
$code=$LASTEXITCODE
$drift=@($paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
$summary=@(Select-String -LiteralPath "$taskTemp/$prefix.reverse.log" -Pattern 'Summary \['|ForEach-Object {$_.Line})
[ordered]@{version=1;sourceBase=$freeze.head;filter=$filter;listArguments=$listArgs;listReceipt="$prefix.reverse.retry1.list.receipt.json";arguments=$runArgs;listExitCode=$listCode;filterMatchedTests=$selected.Count;exitCode=$code;sourceInputs=$paths.Count;sourceDrift=$drift;cargoInputs=@($paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'}).Count;cargoDrift=0;summary=$summary;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.receipt.json" -Encoding utf8
$summary|Write-Output
if($drift){throw 'Source changed during matrix retry'}
exit $code
