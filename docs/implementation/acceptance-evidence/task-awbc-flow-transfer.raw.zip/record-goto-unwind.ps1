$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-goto-unwind-hardening-20261107'
$first=Get-Content "$taskTemp/awbc-goto-unwind-20261107.verified.json" -Raw|ConvertFrom-Json
$source=Get-Content "$taskTemp/$prefix.source.verified.json" -Raw|ConvertFrom-Json
$matrix=Get-Content "$taskTemp/$prefix.reverse.receipt.json" -Raw|ConvertFrom-Json
$freeze=Get-Content "$taskTemp/$prefix.source-freeze.json" -Raw|ConvertFrom-Json
if((&git rev-parse HEAD).Trim() -ne $source.commit -or $source.parent -ne $first.commit -or $matrix.sourceBase -ne $first.commit -or $matrix.sourceDrift -ne 0 -or $matrix.listExitCode -ne 0){throw 'Unfinished or changed validation'}
if(@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Frozen inputs changed'}
$untracked=Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json
if(@($untracked.files|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count){throw 'Original untracked WIP changed'}
$selected=Get-Content "$taskTemp/$prefix.reverse.selection.json" -Raw|ConvertFrom-Json
$log=[IO.File]::ReadAllText("$taskTemp/$prefix.reverse.log")
$failed=@([regex]::Matches($log,'(?m)^\s*FAIL\s+\[[^\]]+\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+([^\r\n]+)')|ForEach-Object {[pscustomobject]@{binary=$_.Groups[1].Value;test=$_.Groups[2].Value}}|Sort-Object test -Unique)
$expected=@('agent_observe_native::agent_observe_reports_authored_scroll_view_capture_and_release_filtering','spec_valid_run_edge_fixture_now_executes','verify_json_records_required_solver_checks','verify_json_reports_missing_promotion_proof')
if(@(Compare-Object @($failed.test|Sort-Object) @($expected|Sort-Object)).Count){throw 'New failures require investigation'}
if(($matrix.summary -join "`n") -notmatch '(\d+) tests run: (\d+) passed.*?(\d+) failed.*?(\d+) skipped'){throw 'Unknown terminal summary'}
$counts=[ordered]@{run=[int]$Matches[1];passed=[int]$Matches[2];failed=[int]$Matches[3];skipped=[int]$Matches[4]}
if($counts.run -ne $selected.Count -or $counts.failed -ne $failed.Count){throw 'Matrix count mismatch'}
$quality=[ordered]@{}
foreach($name in @('compiler-owner','fmt','workspace-check','workspace-clippy','structure')){
 $r=Get-Content "$taskTemp/$prefix.$name.receipt.json" -Raw|ConvertFrom-Json
 if($r.exitCode -ne 0){throw "Failed quality: $name"}
 $quality[$name]=$r
}
$cli=Get-Content "$taskTemp/awbc-goto-unwind-cli-20261107.receipt.json" -Raw|ConvertFrom-Json
if($cli.sourceDrift -ne 0 -or $cli.rows.Count -ne 6){throw 'Incomplete original CLI probes'}
$doctest=Get-Content "$taskTemp/$prefix.doctest.receipt.json" -Raw|ConvertFrom-Json
if($doctest.exitCode -ne 0 -or $doctest.sourceDrift -ne 0){throw 'Core doctests failed'}
$names=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name -like 'awbc-goto-unwind-20261107*' -or $_.Name -like "$prefix*" -or $_.Name -like 'awbc-goto-unwind-cli-20261107*'}|ForEach-Object {$_.Name})
$names+=@('run-goto-unwind-validation.ps1','retry-goto-unwind-matrix.ps1','run-goto-cli-after.ps1','record-goto-unwind.ps1','function-scope-20261107.metadata-all.json','awbc-defer-goto-probe-20261107.current.receipt.json','awbc-defer-goto-probe-20261107.audit.json','awbc-defer-goto-probe-20261107.static.arcw','awbc-defer-goto-probe-20261107.dynamic.arcw','awbc-defer-goto-probe-20261107.function.arcw')
$names=@($names|Sort-Object -Unique)
$zipPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-awbc-flow-transfer.raw.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Archive already exists'}
Compress-Archive -LiteralPath @($names|ForEach-Object {"$taskTemp/$_"}) -DestinationPath $zipPath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{foreach($entry in $archive.Entries){$row=$entries|Where-Object entry -eq $entry.FullName;$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($row.bytes -ne $entry.Length -or $row.sha256 -ne $hash){throw 'Archive content mismatch'}};if($archive.Entries.Count -ne $entries.Count){throw 'Archive entry count mismatch'}}finally{$archive.Dispose()}
$cliCount=@($selected|Where-Object package -eq 'arcweft-cli').Count
$cliFailed=@($failed|Where-Object binary -like 'arcweft-cli::*')
$record=[ordered]@{
 version=1;date='2026-11-07';source=$source;initialSource=$first
 scope='Drain all old invocation/scope cleanup before a static/dynamic or selected Choice Flow transfer. Retain the actual unexecuted destination frame and typed original operation in the one live/inert fiber grammar. Preserve Native accepted behavior.'
 originalReproduction=(Get-Content "$taskTemp/awbc-goto-unwind-20261107.repro.receipt.json" -Raw|ConvertFrom-Json)
 initialOwner=(Get-Content "$taskTemp/awbc-goto-unwind-20261107.owner-first.receipt.json" -Raw|ConvertFrom-Json)
 coreOwnerInitial=(Get-Content "$taskTemp/$prefix.core-owner.receipt.json" -Raw|ConvertFrom-Json)
 coreAffectedFixed=(Get-Content "$taskTemp/$prefix.core-fixed-owner.receipt.json" -Raw|ConvertFrom-Json)
 corrections=@(
 'The first four regressions all pass their Native assertion and fail AWBC before the production fix. Source24 CLI exits zero/Done even while AWBC omits invocation cleanup; status alone is not success.'
 'The initial Core owner run is 2318 run / 2316 pass / 2 fail. One new quota test expected a top-level Resource error instead of the owning ProgramType(Resource(nodes)) boundary. The other exposes a real regression in the first source checkpoint: unresolved Goto effects became InternalInvariant instead of MissingDynamicTarget. Correct the expectation and preserve the typed runtime target error; the subsequent six affected tests pass. Do not rewrite or sum the original run.'
 'The storage-only model check proves no execution behavior. The first execution-check overlapped later edits and is retained only as a development attempt. Final workspace quality and reverse runs use the complete frozen input.'
 'The broad input was frozen on the first source commit plus the exact hardening diff. The second source commit publishes identical bytes; original 12 tracked / 6 untracked WIP are preserved and are part of the observed checkout, not asserted clean commit-only test inputs.'
 'Replace the current AWBC goto loss / unverified Choice enumeration with the now verified bounded behavior. Retain old CLI failures, test attempts, counts and full SHAs as history. Do not reopen Native goto/Choice, Line/init or Generic Match acceptance because the overall goal is incomplete.'
 )
 ownerConditions=@('static/dynamic whole-stack cleanup order','called-function and caller cleanup without resuming displaced code','100ms cleanup wait with zero-op blocked / 40ms+60ms progression','selected Choice nested/body cleanup before target','cleanup failure drains callers without entering target','every-step canonical decoded AWBC public JSON save/cold restore','nine forged destination/origin/value/status forms reject before activation and keep sticky admission failure','shared exact live/inert node allowance','pending budget-yield save/restore','callback-free goto remains one original operation','partial presentation unwind needs no extra grant and transfers only actual exiting owners')
 buildAttempts=@(Get-ChildItem -LiteralPath $taskTemp -File -Filter ($prefix+'.reverse*list.receipt.json')|ForEach-Object {Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json})
 quality=$quality;coreDoctests=$doctest
 reverse=[ordered]@{receipt=$matrix;counts=$counts;resolvedPackages=53;actualTestPackages=@($selected.package|Sort-Object -Unique).Count;cliRun=$cliCount;cliPassed=$cliCount-$cliFailed.Count;cliFailed=$cliFailed.Count;nonCliRun=$selected.Count-$cliCount;nonCliFailed=$failed.Count-$cliFailed.Count;failures=$failed}
 cliProbeDevelopment=(Get-Content "$taskTemp/awbc-goto-unwind-cli-20261107.initial-harness.json" -Raw|ConvertFrom-Json)
 originalCliAfter=$cli
 limits='The four existing CLI failures remain. Do not synthesize a clean full-workspace result, add owner counts to the matrix, or relabel earlier Source24 Syntax25 five-failure evidence. This cut does not accept direct raw AWBC return from open scopes, additional AWBC cancellation/Line-affine capture cases, aggregate registration/child-construction resource admission, MustDrop/promotion proofs, Native public saves, other platforms or ignored Tier2 execution.'
 raw=[ordered]@{path='task-awbc-flow-transfer.raw.zip';sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$entries}
}
$jsonPath='D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText($jsonPath)
if($before.Contains('"flowTransferInvocationUnwind"')){throw 'Duplicate evidence key'}
$fragment=([ordered]@{flowTransferInvocationUnwind=$record}|ConvertTo-Json -Depth 80).Trim()
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after|ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($jsonPath,$after,[Text.UTF8Encoding]::new($false))
$history=@"

## 2026-11-07 — AWBC goto / Choice の呼出しスタック cleanup

Source **$($first.commit)**、補強 **$($source.commit)** を既存 main に通常 commit/push。全差分・tree・blob・親 SHA と元 WIP を照合した。移譲元を型付きで保持し、未実行の実移譲先フレームが引数を所有する。元スタックの内側 scope、関数本体、caller の順に cleanup を drain してから切り替え、置換した caller のコードを再開しない。通常の callback なし goto は元の 1 操作で完了する。
初回 goto 4 件は Native の assert 後に AWBC がすべて失敗し、修復後の 28 件、Choice と cleanup 失敗を加えた最終 30 件はすべて PASS。AWBC は各 step の公開 JSON 保存と cold restore を行う。待機中 0 op と 40ms+60ms、失敗後の caller cleanup と移譲先未実行、改変保存 9 条件の原子拒否、共通 node quota、budget yield、scope grant 上限時の所有移譲を検証した。
Core 初回 owner は 2318 件中 2316 PASS / 2 FAIL。quota の新テストは元の ProgramType(Resource(nodes)) を期待するよう訂正した。もう 1 件は初回 checkpoint の unresolved goto effect の分類退行で、MissingDynamicTarget を保持する根本の型付きエラー伝搬へ修復した。後続 affected 6 件は PASS。これを初回全件 PASS に書き換えない。
Core 全 53 逆依存の実測は $($counts.run) 件中 $($counts.passed) PASS / $($counts.failed) FAIL / $($counts.skipped) SKIP。CLI は ${cliCount} 件中 $($cliCount-$cliFailed.Count) PASS / $($cliFailed.Count) FAIL、非 CLI の新規失敗は $($failed.Count-$cliFailed.Count) 件。全 target / 全 feature check・Clippy、18 Rust path の fmt、構造 gate、Core doctest は終了 0。実行入力 $($freeze.paths.Count) 件（root fixture 180 / Cargo 100 を含む）は drift 0。freeze 時の main は初回 SHA、補強 diff を含む同一入力を後続 SHA で公開した。元 12 tracked / 6 untracked WIP を含む実測であり、clean commit のみの検証とは主張しない。
元と同じ 3 CLI Source・1 op / 128 step の Native / AWBC 6 条件も、元の完全な log 順序と Done を確認。実バイナリ hash と入力 hash を保存した。旧 Source24 の exit 0 / Done に cleanup 欠落があった事実も保持する。
現状一覧の AWBC goto 欠落と Choice 未検証の列挙を、上記実測に基づき置換した。直接 raw AWBC return、取消し・Line affine 捕捉、登録・子構築前の集約検査等は当該範囲だけ継続とし、Native / Line-init / Generic Match の既受入を全体 goal の未達で戻さない。以前の Syntax25 の 5 FAIL と後続 fixture 修復は履歴のまま保持する。[全結果・訂正・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIP は $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::AppendAllText('D:/git/arcweft/docs/implementation/convergence-evidence-history.md',$history.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='D:/git/arcweft/docs/implementation/current-status.md'
$lines=[IO.File]::ReadAllLines($statusPath)
$updated=foreach($line in $lines){
 if($line.StartsWith('| 通常 Flow の scoped defer |')){'| 通常 Flow の scoped defer | **Native の既受入を保持。Source／AWBC の通常 cleanup・goto／Choice・待機・Flow registry は対象を検証・公開済み。全体受入は継続中** | Source `'+$source.commit+'`。関数本体と明示 scope の LIFO、generic 捕捉／戻り値、Flow registry の読書き・drop／型付き置換を保持する。static／dynamic goto とFlowから呼んだ関数内 goto は caller を含む cleanup 後に元の移譲先へ進み、Choice も内外の cleanup を待つ。cleanup 失敗は caller を drain し移譲先へ進まない。40ms＋60ms の待機・途中0 op、AWBC の毎 step version 1 公開保存／cold restore、改変保存の拒否と共通 quota を確認。元 CLI 入力でも完全な log 順序を検証したため、旧 goto 欠落・Choice 未検証の列挙を置換した。直接 raw AWBC の開いた scope からの return、全取消し・Line affine 捕捉、登録／子構築前の集約検査は継続中。必須 registry 読取りには静的存在証明が必要。[全実測・旧失敗・訂正・SHA](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 elseif($line.StartsWith('| 共有契約／推移的逆依存matrix |')){'| 共有契約／推移的逆依存matrix | **Core逆依存53パッケージ：'+$counts.passed+' PASS／'+$counts.failed+' FAIL／'+$counts.skipped+' SKIP** | Source `'+$source.commit+'` と同一の固定入力を Windows の workspace 既定 feature・lib／integration で実行。'+$counts.run+'件、実テスト package '+@($selected.package|Sort-Object -Unique).Count+'。非 CLI の失敗 '+($failed.Count-$cliFailed.Count)+' 件。owner 30件／affected 6件を広域へ加算せず、以前の Syntax25 の5 FAIL と後続 Sema fixture修復も履歴に保持する。[全選択・入力・結果・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 elseif($line.StartsWith('| CLIの規定対象／全 check 照合 |')){'| CLIの規定対象／全 check 照合 | **workspace既定CLI '+$cliCount+'件：'+($cliCount-$cliFailed.Count)+' PASS／'+$cliFailed.Count+' FAIL** | Source `'+$source.commit+'`、上記 Core逆依存runの内数。未解消は authored Scroll の意味解析、必須 VoiceHandle に実音声がない実行、promotion 証明／solver の2件。完了済みの監査・取消し cleanup・scalar 修復を戻さない。[失敗ID・実入力・診断](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 elseif($line.StartsWith('| workspace check／Clippy・fmt・構造gate |')){'| workspace check／Clippy・fmt・構造gate | **全target・全feature check／Clippy、fmt、構造gate、Core doctestは終了0** | Source `'+$source.commit+'` と同じ固定入力で確認。fmt は両 Source cut の18 Rust path、Core doctest は現入力の実測。警告・review trigger と初回失敗を原本に保持する。他 platform／Tier2 の受入へ拡張しない。[全実測・公開SHA・原本](acceptance-evidence/task-flow-registry-execution.json)。 |'}
 else{$line}
}
[IO.File]::WriteAllText($statusPath,($updated -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;counts=$counts;entries=$entries.Count;rawSha256=$record.raw.sha256}|ConvertTo-Json -Depth 5
