$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-goto-unwind-cli-20261107'
$freeze=Get-Content "$taskTemp/awbc-goto-unwind-hardening-20261107.source-freeze.json" -Raw|ConvertFrom-Json
$list=Get-Content "$taskTemp/awbc-goto-unwind-hardening-20261107.reverse.retry1.list.receipt.json" -Raw|ConvertFrom-Json
if($list.exitCode -ne 0){throw 'Current CLI has not been built by the complete selection'}
$binary=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$binaryRow=Get-Item -LiteralPath $binary
if($binaryRow.LastWriteTimeUtc -le [DateTime]::Parse($freeze.at)){throw 'CLI binary predates source freeze'}
$binaryHash=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant()
$before=Get-Content "$taskTemp/awbc-defer-goto-probe-20261107.current.receipt.json" -Raw|ConvertFrom-Json
$rows=@(foreach($row in $before.rows){
 $arguments=@($row.arguments)
 $source=$arguments[1]
 if((Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant() -ne $row.sourceSha256){throw 'Original CLI Source changed'}
 $stdout="$taskTemp/$prefix.final.$($row.variant).$($row.executor).json"
 $stderr="$taskTemp/$prefix.final.$($row.variant).$($row.executor).stderr.log"
 $started=[DateTime]::UtcNow
 & $binary @arguments > $stdout 2> $stderr
 $code=$LASTEXITCODE
 if($code -ne 0){throw "CLI invocation failed: $($row.variant)/$($row.executor)"}
 $json=Get-Content -LiteralPath $stdout -Raw|ConvertFrom-Json -Depth 100
 $logs=@($json.steps[-1].observations.logs|ForEach-Object {$_.message})
 $diagnostics=@($json.steps|ForEach-Object {$_.diagnostics}|Where-Object {$_})
 $maxExecuted=($json.steps|ForEach-Object {$_.stats.executed_ops}|Measure-Object -Maximum).Maximum
 if($json.final_status -ne 'done Done' -or $diagnostics.Count -or $maxExecuted -gt 1 -or ($logs -join "`0") -cne ($row.expectedLogs -join "`0")){throw 'Original CLI outcome/order/budget does not match'}
 [ordered]@{variant=$row.variant;executor=$row.executor;arguments=$arguments;exitCode=$code;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o');sourceSha256=$row.sourceSha256;expectedLogs=$row.expectedLogs;actualLogs=$logs;finalStatus=$json.final_status;stepCount=$json.steps.Count;maxExecutedOps=$maxExecuted;stdoutSha256=(Get-FileHash -LiteralPath $stdout).Hash.ToLowerInvariant()}
})
if((Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant() -ne $binaryHash){throw 'CLI binary changed during probe'}
$drift=@($freeze.paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
if($drift){throw 'Source changed during CLI probe'}
[ordered]@{version=1;sourceBase=$freeze.head;sourceFreezeAt=$freeze.at;binary=$binary;binarySha256=$binaryHash;binaryLastWriteUtc=$binaryRow.LastWriteTimeUtc.ToString('o');sourceDrift=$drift;originalReceipt='awbc-defer-goto-probe-20261107.current.receipt.json';rows=$rows}|ConvertTo-Json -Depth 10|Set-Content "$taskTemp/$prefix.receipt.json" -Encoding utf8
@($rows|ForEach-Object {[ordered]@{variant=$_.variant;executor=$_.executor;logs=$_.actualLogs;maxExecutedOps=$_.maxExecutedOps;steps=$_.stepCount}})|ConvertTo-Json -Depth 5
