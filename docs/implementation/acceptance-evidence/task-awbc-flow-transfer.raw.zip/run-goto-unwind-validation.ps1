$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='awbc-goto-unwind-hardening-20261107'
$coreOwner=Get-Content "$taskTemp/$prefix.core-fixed-owner.receipt.json" -Raw | ConvertFrom-Json
if($coreOwner.exitCode -ne 0){throw 'Core owner has unresolved failures'}
$previous=Get-Content "$taskTemp/value-block-trailing-write-20261107.source-freeze.json" -Raw | ConvertFrom-Json
$owned=@(Get-Content "$taskTemp/$prefix.owned-candidates.txt")
$inputPaths=@($previous.paths.path + $owned + 'docs/01-language/block-scopes.md' | Sort-Object -Unique)
$paths=@(foreach($path in $inputPaths){[ordered]@{path=$path;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}})
$base=(&git rev-parse HEAD).Trim()
[ordered]@{version=1;head=$base;at=[DateTime]::UtcNow.ToString('o');paths=$paths}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.source-freeze.json" -Encoding utf8
$cargo=@($paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'})
$oldCargo=@{};foreach($row in $previous.paths|Where-Object {$_.path -eq 'Cargo.lock' -or $_.path -like '*Cargo.toml'}){$oldCargo[$row.path]=$row.sha256}
if(@($cargo|Where-Object {$oldCargo[$_.path] -ne $_.sha256}).Count){throw 'Resolved graph inputs changed'}
$graph=Get-Content "$taskTemp/awbc-defer-runnable-20261107.metadata-reverse-union.json" -Raw|ConvertFrom-Json
$corePackages=@($graph.union|Where-Object {$_.id -notin $graph.extra.id})
if($corePackages.Count -ne $graph.corePackages){throw 'Core reverse package set differs'}
[ordered]@{version=1;sourceBase=$base;metadata='function-scope-20261107.metadata-all.json';cargoInputs=$cargo.Count;cargoDrift=0;resolvedReversePackages=$corePackages.Count;packages=$corePackages}|ConvertTo-Json -Depth 6|Set-Content "$taskTemp/$prefix.graph.json" -Encoding utf8
& cargo tree --locked --workspace --invert arcweft-core *> "$taskTemp/$prefix.reverse.tree.log"
if($LASTEXITCODE -ne 0){throw 'Reverse graph inspection failed'}
foreach($check in @(
 @{name='compiler-owner';arguments=@('nextest','run','--locked','--workspace','--test','scoped_defer','--no-tests','fail','--no-fail-fast')},
 @{name='workspace-check';arguments=@('check','--locked','--workspace','--all-targets','--all-features')},
 @{name='workspace-clippy';arguments=@('clippy','--locked','--workspace','--all-targets','--all-features')},
 @{name='structure';arguments=@('+nightly','-Zscript','tools/structure-audit.rs','--root','.','--fail-on-blocking')}
)){
 $started=[DateTime]::UtcNow;$arguments=$check.arguments
 & cargo @arguments *> "$taskTemp/$prefix.$($check.name).log"
 $code=$LASTEXITCODE
 $drift=@($paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
 [ordered]@{version=1;sourceBase=$base;arguments=$arguments;exitCode=$code;sourceInputs=$paths.Count;sourceDrift=$drift;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.$($check.name).receipt.json" -Encoding utf8
 Write-Output ($check.name+': exit '+$code+'; drift '+$drift)
 if($code -ne 0 -or $drift){exit 1}
}
$rustPaths=@($owned|Where-Object {$_ -like '*.rs'})
& rustfmt --edition 2024 --config skip_children=true --check @rustPaths *> "$taskTemp/$prefix.fmt.log"
$fmtCode=$LASTEXITCODE
[ordered]@{version=1;arguments=@('--edition','2024','--config','skip_children=true','--check')+$rustPaths;exitCode=$fmtCode}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.fmt.receipt.json" -Encoding utf8
if($fmtCode -ne 0){exit $fmtCode}
$started=[DateTime]::UtcNow
$filter='rdeps(=arcweft-core)'
$listArgs=@('nextest','list','--locked','--workspace','--lib','--tests','-E',$filter,'--message-format','json')
& cargo @listArgs > "$taskTemp/$prefix.reverse.list.json" 2> "$taskTemp/$prefix.reverse.list.stderr.log"
$listCode=$LASTEXITCODE
[ordered]@{version=1;arguments=$listArgs;exitCode=$listCode;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.list.receipt.json" -Encoding utf8
if($listCode -ne 0){exit $listCode}
$list=Get-Content "$taskTemp/$prefix.reverse.list.json" -Raw|ConvertFrom-Json -Depth 100
$selected=@(foreach($binary in $list.'rust-suites'.PSObject.Properties){foreach($test in $binary.Value.testcases.PSObject.Properties){if($test.Value.'filter-match'.status -eq 'matches'){[pscustomobject][ordered]@{package=$binary.Value.'package-name';binary=$binary.Value.'binary-name';test=$test.Name}}}})
if(!$selected.Count){throw 'Empty reverse selection'}
$selected|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.selection.json" -Encoding utf8
$runArgs=@('nextest','run','--locked','--workspace','--lib','--tests','-E',$filter,'--no-tests','fail','--no-fail-fast')
& cargo @runArgs *> "$taskTemp/$prefix.reverse.log"
$code=$LASTEXITCODE
$drift=@($paths|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256}).Count
$summary=@(Select-String -LiteralPath "$taskTemp/$prefix.reverse.log" -Pattern 'Summary \['|ForEach-Object {$_.Line})
[ordered]@{version=1;sourceBase=$base;filter=$filter;listArguments=$listArgs;arguments=$runArgs;listExitCode=$listCode;filterMatchedTests=$selected.Count;exitCode=$code;sourceInputs=$paths.Count;sourceDrift=$drift;cargoInputs=$cargo.Count;cargoDrift=0;summary=$summary;startedAt=$started.ToString('o');endedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content "$taskTemp/$prefix.reverse.receipt.json" -Encoding utf8
$summary|Write-Output
if($drift){throw 'Source changed during reverse matrix'}
exit $code
