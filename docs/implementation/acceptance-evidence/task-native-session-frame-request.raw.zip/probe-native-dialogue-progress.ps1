$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$stem='native-dialogue-progress-probe1'
if(Test-Path -LiteralPath (Join-Path $t ($stem+'.receipt.json'))){throw 'Preserve existing probe'}
$binary=(Resolve-Path -LiteralPath 'target/debug/arcw.exe').Path
$source=(Resolve-Path -LiteralPath 'samples/rich-text-full-grammar.arcw').Path
$pins=[ordered]@{binarySha256=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant();sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant()}
$info=[Diagnostics.ProcessStartInfo]::new($binary)
$info.WorkingDirectory=$PWD.Path
$info.UseShellExecute=$false;$info.CreateNoWindow=$true
$info.RedirectStandardInput=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
$info.ArgumentList.Add('agent');$info.ArgumentList.Add('mcp')
$process=[Diagnostics.Process]::Start($info)
$stderr=$process.StandardError.ReadToEndAsync()
$script:requestId=0
function Rpc([string]$method,$parameters){
 $script:requestId++
 $request=[ordered]@{jsonrpc='2.0';id=$script:requestId;method=$method;params=$parameters}
 $process.StandardInput.WriteLine(($request | ConvertTo-Json -Depth 30 -Compress))
 $process.StandardInput.Flush()
 $task=$process.StandardOutput.ReadLineAsync()
 if(-not $task.Wait(60000)){throw ('Timed out: '+$method)}
 $line=$task.Result
 if($null -eq $line){throw 'MCP stdout closed'}
 $response=$line | ConvertFrom-Json -Depth 100
 $line | Set-Content -LiteralPath (Join-Path $t ($stem+'.rpc-'+$script:requestId+'.json')) -Encoding utf8
 if($response.id -ne $script:requestId -or $response.error -or $response.result.isError){throw ('Rejected MCP call: '+$line.Substring(0,[Math]::Min($line.Length,700)))}
 return $response.result
}
function Current-Report {
 $list=Rpc 'resources/list' @{}
 $resources=@($list.resources | Where-Object title -eq 'Latest observation')
 if($resources.Count -ne 1){throw 'Expected one advertised observation resource'}
 $read=Rpc 'resources/read' @{uri=$resources[0].uri}
 return ($read.contents[0].text | ConvertFrom-Json -Depth 100)
}
$frames=[Collections.Generic.List[object]]::new()
$failed=$null
try {
 $null=Rpc 'initialize' @{}
 $null=Rpc 'tools/call' @{name='arcweft.observe';arguments=@{source=$source;entry='entry.rich_text_full_grammar';image='png';layer='dialogue.rich_text';page=0;steps=4;max_ops=128;viewport_width=1280;viewport_height=720}}
 for($index=0;$index -lt 20;$index++){
  $report=Current-Report
  $lines=@($report.text_contexts.entries | ForEach-Object {$_.content.context.frame.line} | Where-Object {$null -ne $_} | Sort-Object -Unique)
  $frame=[ordered]@{index=$index;tick=$report.tick;frame_id=$report.frame_id;steps=$report.steps;lines=$lines;actions=$report.actions;diagnosticCount=@($report.diagnostics).Count}
  $frames.Add($frame)
  [ordered]@{index=$index;tick=$report.tick;frame=$report.frame_id;lines=$lines;actions=@($report.actions).Count} | ConvertTo-Json -Compress
  if($lines -contains 'say.full.005'){break}
  $null=Rpc 'tools/call' @{name='arcweft.action';arguments=@{kind='advance_text'}}
 }
} catch {$failed=$_.ToString();Write-Output $failed}
finally {
 $process.StandardInput.Close()
 if(-not $process.WaitForExit(30000)){$process.Kill($true);$process.WaitForExit()}
 $stderr.GetAwaiter().GetResult() | Set-Content -LiteralPath (Join-Path $t ($stem+'.stderr.log')) -Encoding utf8
}
if((Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant() -ne $pins.sourceSha256){throw 'Probe source changed'}
$receipt=[ordered]@{version=1;base=(git rev-parse HEAD).Trim();pins=$pins;processExit=$process.ExitCode;failure=$failed;frames=$frames;scope='Actual public MCP persistent session;4steps/128max_ops per frame unchanged. No Source edits or reconstructed captures.'}
$receipt | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $t ($stem+'.receipt.json')) -Encoding utf8
if($failed){exit 1}
