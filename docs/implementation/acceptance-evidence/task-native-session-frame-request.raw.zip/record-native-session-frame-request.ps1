$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Read-Record([string]$name){Get-Content -LiteralPath (Join-Path $t ($name+'.json')) -Raw | ConvertFrom-Json -AsHashtable -Depth 100}
$stem='native-session-frame-request-cli-full1-20261106'
$terminal=Read-Record ($stem+'.runtime.terminal-audit')
$owner=Read-Record 'native-session-frame-request-owner3-20261106.runtime.terminal-audit'
$old=Read-Record 'content-style-origin-reverse31-attempt2-20261106.runtime.terminal-audit'
$oldFailures=@($old.failureSet | ForEach-Object {$_.binary+"`t"+$_.test} | Sort-Object)
$failures=@($terminal.failureSet | ForEach-Object {$_.binary+"`t"+$_.test} | Sort-Object)
if($terminal.executed -ne 703 -or $terminal.passed -ne 693 -or $terminal.failed -ne 10 -or $owner.passed -ne 111 -or @(Compare-Object $oldFailures $failures).Count){throw 'Unexpected terminal; retain actual failures'}
$quality=[ordered]@{}
foreach($check in @('check','clippy','structure')){
 $q=Read-Record ('native-session-frame-request-quality1-20261106-'+$check)
 if($q.exitCode -ne 0){throw 'Quality failed'}
 $quality[$check]=$q
}
$freeze=Read-Record ($stem+'.source-freeze')
$ownerFreeze=Read-Record 'native-session-frame-request-owner3-20261106.source-freeze'
$inputIndex=@{};foreach($row in $ownerFreeze.paths){$inputIndex[$row.path]=$row.sha256}
foreach($row in $freeze.paths){if($inputIndex[$row.path] -ne $row.sha256){throw 'Owner/CLI source inputs differ'}}
if($inputIndex.Count -ne $freeze.paths.Count){throw 'Source input counts differ'}
$recordPath='docs/implementation/acceptance-evidence/task-rich-text-property-identity.json'
$historyPath='docs/implementation/convergence-evidence-history.md'
$statusPath='docs/implementation/current-status.md'
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if($record.Contains('nativeSessionFrameRequest')){throw 'Evidence already exists'}
$before=$record | ConvertTo-Json -Depth 100 -Compress
$historyBefore=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath))
$files=@(Get-ChildItem -LiteralPath $t -File | Where-Object {
 $_.Name.StartsWith('native-session-frame-request') -or $_.Name.StartsWith('native-dialogue-progress-probe') -or $_.Name.StartsWith('checkpoint-native-session-frame-request-20261106.')
})
$files+=@(Get-Item -LiteralPath (Join-Path $t 'record-native-session-frame-request.ps1'),(Join-Path $t 'probe-native-dialogue-progress.ps1'),(Join-Path $t 'probe-native-dialogue-progress2.ps1'),(Join-Path $t 'run-presentation-projection-owner.ps1'),(Join-Path $t 'audit-nextest-final-result.ps1'))
$files+=@(Get-ChildItem -LiteralPath (Join-Path $t 'native-session-frame-request-quality1-20261106.structure-report') -File)
. (Join-Path $t 'write-verified-evidence-archive.ps1')
$rawPath='docs/implementation/acceptance-evidence/task-native-session-frame-request.raw.zip'
$raw=Write-VerifiedEvidenceArchive ([IO.Path]::GetFullPath($t)) ([IO.Path]::GetFullPath((Join-Path $PWD $rawPath))) $files
$record.nativeSessionFrameRequest=[ordered]@{
 version=1;recordedAt=[DateTime]::UtcNow.ToString('o');source=Read-Record 'checkpoint-native-session-frame-request-20261106.verified';owner=$owner;fullCli=$terminal;quality=$quality
 graph=Read-Record 'native-session-frame-request.graph';ownership=Read-Record 'native-session-frame-request-owner-measurements'
 failureComparison=[ordered]@{referenceRun=$old.run;referenceBase=$old.base;previousFailures=10;currentFailures=10;newFailureIds=@();noLongerFailingIds=@()}
 initialAttempts=[ordered]@{catalogImportFailure=Read-Record 'native-session-frame-request-owner1-20261106.catalog';sourceGuard=Read-Record 'native-session-frame-request-owner2-guard';reason='Owner1 E0432 was repaired with the narrow runtime_observation import. Owner2 compiled but this agent edited the frozen capture guide; the guard aborted before receipt/inventory/runtime. Neither is passing validation. Owner3 reran the corrected complete input.'}
 probes=[ordered]@{before=Read-Record 'native-dialogue-progress-probe1.receipt';after=Read-Record 'native-dialogue-progress-probe2.receipt';remaining='Probe2 reaches line004 and transition tick51. Entering line005 then fails: prepared-text capture requires67276800 rendered pixels, limit66355200. Preserve this independent capacity condition and stderr; no claim of completed full-grammar progression. Full sample retains typed wave/shake/typewriter/arc/sparkle and jitter/shader/proxies; do not remove their assertions based on a partial source read.'}
 behavior='One private typed NativeFrameObservationRequest owns bounded steps, viewport, sample and canonical diagnostic scope. Initial crop/image/frontier belongs to one request; persistent MCP/script progress retains execution/sample, publishes the actual current frame and does not repeat the initial image. Each step_frames count advances that call, not a cumulatively growing number. Delete duplicate capture-scope models; do not replace a missing target with a viewport image.'
 coverage='CLI-only private owner.111/111PASS incl2request-unit cases and1public two-line MCP regression; fullCLI703run693PASS10FAIL23skip526.897s exit100. CLI all-target/all-feature/locked check and Clippy plus full workspace structure exit0,warnings remain. Source4116/case/executable drift0; original12tracked/6untrackedWIP participates. The exact10 failure IDs equal the previous full31 CLI run. Generic151 was not rerun for this CLI-only cut; last accepted151/151 replay remains in the previous field. No public save, browser runtime or final image parity acceptance inferred.'
 correctionReason='Supersedes the older pending703 total with the actual complete run, and repairs the concrete initial-crop retention bug. A fresh public probe exposes a different bounded-render-work failure on line005, so the three full-grammar conditions remain incomplete with concrete evidence. Other completed features, including Generic Match and style provenance, remain accepted.'
 raw=[ordered]@{path=$rawPath;bytes=$raw.bytes;sha256=$raw.sha256;entries=$raw.entries.Count;entryDrift=0}
}
$record | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $recordPath -Encoding utf8
$status=[IO.File]::ReadAllText((Join-Path $PWD $statusPath)).Replace("`r`n","`n")
$rows=@(foreach($line in ($status -split "`n")){
 if($line.StartsWith('| CLI全target照合 |')){
  '| Native MCP／scriptのフレーム進行 | **当該request所有と2行の実進行は修復・検証・公開済み** | Source ceca5955ab15bee03ac4ca020a708f5b12eea1be。初回image／crop／capture frontierと継続step／viewport／sampleを分離し、同じ型付きrequestで進行する。transition時に初回dialogue layer captureを繰り返さず、step_framesの各countが実tickを進める。owner111／111 PASS、公開MCPの2行・画像再要求なし・tick＋1を含む。full-grammarの後続line005は別の描画上限条件が残る。[実装・失敗原本・全件結果](acceptance-evidence/task-rich-text-property-identity.json)。 |'
  '| CLI全target照合 | **最新の全703実測は693 PASS／10 FAIL** | Source ceca5955ab15bee03ac4ca020a708f5b12eea1be、入力base bcc081105b87501ed23c322724df2ed282c4f1fc。追加3件はPASS、既存10失敗IDとの差分0。残る10 IDはfull-grammar3件、Scroll1件、unsafe1件、run-edge1件、負例診断1件、verifier3件。公開MCP probeでline005到達時のprepared-text描画要求67276800 pixels／上限66355200を再現したため、full-grammarを完了扱いしない。過去の700件runを再計算せず履歴に保持する。[終端・全ID・入力・原本](acceptance-evidence/task-rich-text-property-identity.json)。 |'
 }else{$line}
})
[IO.File]::WriteAllText((Join-Path $PWD $statusPath),($rows -join "`n"),[Text.UTF8Encoding]::new($false))
$append=@'

## 2026-11-06 — Native session frame request ownership

- Source ceca5955ab15bee03ac4ca020a708f5b12eea1be, parent bcc081105b87501ed23c322724df2ed282c4f1fc. Separate one-shot image/crop/frontier from persistent bounded execution, viewport and sample using one private typed request and canonical capture scope. Each public step_frames count applies to that call. The real two-line MCP regression preserves its issued frame/URI context and reaches the second line with no repeated image request and tick+1 progression.
- Owner3:111PASS/615skipped/8.028s; fullCLI:703run693PASS10FAIL23skip526.897s exit100. Compare exact IDs with the last full31 CLI10: no new or removed failure IDs. Source4116/case/executable drift0. Original12tracked/6untrackedWIP participates. CLI all-target/all-feature/locked check/Clippy and workspace structure exit0, warnings remain. This private CLI cut does not relabel older workspace98/Generic151/wasm results as fresh runs.
- Preserve owner1 E0432 and its narrow import repair. Owner2 aborted because this agent edited a frozen guide after compilation; no runtime or accepted catalog receipt. Fresh owner3 includes the corrected guide and complete source. The initial public probe failed immediately after advance by repeating the initial missing dialogue-layer image. Probe2 passes that transition and reaches line004, then entering line005 fails the existing coverage render limit:67276800 pixels required,66355200 allowed. This is concrete remaining work, not completion or an excuse to reopen Generic Match/style provenance. Full sample line005 retains typed wave/shake/typewriter/arc/sparkle,006jitter/shader/proxies; a partial source read suggesting otherwise was corrected before publication and no coverage was deleted.
- [Exact evidence and immutable raw](acceptance-evidence/task-rich-text-property-identity.json); [single current list](current-status.md). All earlier evidence and history remain unchanged.
'@
[IO.File]::AppendAllText((Join-Path $PWD $historyPath),$append+"`n",[Text.UTF8Encoding]::new($false))
$after=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$after.Remove('nativeSessionFrameRequest')
if(($after | ConvertTo-Json -Depth 100 -Compress) -ne $before){throw 'Prior evidence changed'}
$historyAfter=[IO.File]::ReadAllBytes((Join-Path $PWD $historyPath));$prefix=[byte[]]::new($historyBefore.Length);[Array]::Copy($historyAfter,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)) -ne [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($historyBefore))){throw 'History prefix changed'}
[ordered]@{source='ceca5955ab15bee03ac4ca020a708f5b12eea1be';raw=$rawPath;entries=$raw.entries.Count;bytes=$raw.bytes;sha256=$raw.sha256;priorEvidenceDrift=0;historyPrefixDrift=0} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $t 'native-session-frame-request-documentation-audit.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $t 'native-session-frame-request-documentation-audit.json')
