$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$stem='line-init-defer-20261108'
$published=Get-Content "$taskTemp/$stem.delivery-source.verified.json" -Raw|ConvertFrom-Json
$source=$published.commit
if((git rev-parse HEAD).Trim() -ne $source){throw 'Unexpected source base'}
foreach($gate in @('check','clippy','structure','fmt')){
 $receipt=Get-Content "$taskTemp/$stem.workspace-quality-r1.$gate.receipt.json" -Raw|ConvertFrom-Json
 if($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0){throw "Gate failed: $gate"}
}
$terminal=Get-Content "$taskTemp/$stem.scoped-owners-r3.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if($terminal.passed -ne 158 -or $terminal.failed -ne 3 -or $terminal.executed -ne 161 -or $terminal.sourceDrift -ne 0){throw 'Observed terminal differs'}
$epoch=(Get-Content "$taskTemp/$stem.scoped-owners-r3.source-freeze.json" -Raw|ConvertFrom-Json).paths
foreach($row in $epoch){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift: $($row.path)"}}
$untracked=(Get-Content "$taskTemp/task-documentation-final-untracked-before.json" -Raw|ConvertFrom-Json).files
foreach($row in $untracked){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw "Original untracked changed: $($row.path)"}}
. "$taskTemp/convergence-image-git-bytes.ps1"
$metrics=Import-Csv "$taskTemp/$stem.structure-report/file_metrics.csv"
$owned=@(Get-Content "$taskTemp/$stem.delivery-source.owned.txt"|Where-Object {$_ -like '*.rs'})
$rows=@(foreach($path in $owned){
 $metric=@($metrics|Where-Object path -eq $path)
 if($metric.Count -ne 1){throw "Missing file metrics: $path"}
 $oldBytes=Read-GitBytes @('show',('62adc6132c134a990e2dfdfef1b31b2c7501dff4:'+$path))
 $oldText=[Text.Encoding]::UTF8.GetString($oldBytes)
 $oldLines=($oldText -split "`n").Count-[int]$oldText.EndsWith("`n")
 [ordered]@{path=$path;owner=$metric[0].owner;bytes=[long]$metric[0].bytes;physicalLines=[int]$metric[0].physical_lines;embeddedTestLines=[int]$metric[0].embedded_test_lines;growth=[int]$metric[0].physical_lines-$oldLines}
})
[ordered]@{version=1;source=$source;files=$rows;cargoChanges=0;graphEvidence='The unchanged Cargo graph is pinned in task-initial-line-root-defer.raw.zip: workspace 98 / resolved 846 / Core reverse closure 53. This cut does not claim a new Core53 runtime terminal.';ownership='Shared line_task scoped unwind accepts an explicit issuer-authentication callback. Native and AWBC prepare original-issuer transitions before taking scoped packets. Prepared Native registration metadata replaces the previous immediately-mutating registration function; AWBC activation/scoped-child control instructions use one preflighted local ledger and received-custody receipt. Live and inert scoped packets retain exact actual storage identities. No live-value clone, persistent side table, I/O, version bump, or compatibility reader was added.';cohesion='Existing scheduler, Native activation/scoped control, AWBC line-step and snapshot owners retain their coupled transaction responsibilities. Exact physical LOC/growth/embedded test counts are recorded; splitting these steps solely by file size would disperse the ownership proof.'}|ConvertTo-Json -Depth 12|Set-Content "$taskTemp/$stem.ownership-review.json"
$archive='docs/implementation/acceptance-evidence/task-initial-line-init-defer.raw.zip'
if(Test-Path -LiteralPath $archive){throw 'Evidence archive already exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {$_.Name.StartsWith($stem+'.') -or $_.Name -in @('record-line-init-defer-20261108.ps1','run-line-init-workspace-quality-20261108.ps1','run-line-root-frozen-nextest-20261108.ps1','initial-input-line-init-defer-regressions.rs.fragment','initial-input-line-scoped-defer-regressions.rs.fragment','initial-input-line-scoped-wait-regressions.rs.fragment')}|Sort-Object Name)
$items=@(foreach($file in $files){[ordered]@{path=$file.FullName;entry=$file.Name}})+@(Get-ChildItem "$taskTemp/$stem.structure-report" -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.FullName;entry=('structure-report/'+$_.Name)}})
$entries=@(foreach($item in $items){[ordered]@{entry=$item.entry;bytes=(Get-Item -LiteralPath $item.path).Length;sha256=(Get-FileHash -LiteralPath $item.path).Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::Open((Join-Path (Get-Location) $archive),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($item in $items){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$item.path,$item.entry)}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archive))
try{foreach($row in $entries){$entry=$zip.GetEntry($row.entry);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Archive shape differs'};$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Archive content differs'}}}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';inspectedSource=$source;reproductionSource='e8d203f4e8b387c5b2ed2daaf513a0a2c986836b';nativeSource='62adc6132c134a990e2dfdfef1b31b2c7501dff4'
 accepted='The additional simple initial-owned-input -> init defer condition now passes in Native and per-step public-save AWBC. The AWBC-only repair source epoch passed all 154 evaluated_effects/scoped_defer cases before additional cases were introduced. Always/completed/failed filters pass in Native and saved AWBC; saved AWBC also passes nested defer and explicit init scope cases. These bounded passes do not claim full additional-scope acceptance.'
 remaining='Concrete additional conditions remain: Native explicit init scope result binding fails at tick 19 with no active emitted lexical frame; a Native init-defer child dialogue does not finish within the unchanged 512-step limit; saved AWBC init-defer child dialogue fails at tick 51 on an unsupported product-owned dialogue receiver. The waiting tests stop in their first normal branch, so their later cancellation branches did not execute. Their original cancellation selection also targets the last reveal rather than the inner dialogue and must be made explicit before claiming inner-dialogue cancellation.'
 initialFailure='Initial 0 pass / 2 fail / 122 skip: Native tick 17 wrong activation; saved AWBC restore owned-slot mismatch. Native isolated followup passed, then all 154 owners had 153 pass / 1 saved-AWBC-init failure. After AWBC repair all 154 passed. The 5-case extra probe had 3 pass / 2 fail: Native nested ownership and an overly narrow test diagnostic predicate. Updating that predicate observes rejection plus unchanged state directly; it does not weaken a production acceptance condition. The next full 159-case run had 158 pass / 1 Native lexical-cleanup failure. Return cleanup then progressed to the additional explicit-scope boundary.'
 validation=[ordered]@{terminal=$terminal;gates='workspace all-target/all-feature check and Clippy, canonical structure gate, 8 Rust paths fmt exit 0; existing warnings retained';sourceInputs=3416;sourceDrift=0;scope='This 161-case owner result is not a new full Core/Core53/CLI primary matrix.'}
 corrections='No prior accepted boundary is reopened. Generic Match, original Line/init, ordinary defer and initial root-defer acceptance remain as recorded. The newly failing Source inputs identify the exact extra boundaries above. The forged-save test initially rejected a valid rejection diagnostic (fiber function/layout validation); all eight coordinate/removal/duplication mutations now require refusal and preserve the original snapshot, then complete the original execution.'
 originalWork=[ordered]@{tracked=12;untracked=$untracked.Count;heldPatchSha256='c838778adff4d217c794fa25650a77069777260a0df22f27528be31eb3fca53c';note='Focused historical wrapper held=14 metadata is not the actual independently checked WIP count.'}
 raw=[ordered]@{path=(Split-Path $archive -Leaf);sha256=(Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant();entries=$entries}
}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$before=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
$old=$before|ConvertFrom-Json -Depth 100
if($old.PSObject.Properties.Name -contains 'initialInputLineInitDefer'){throw 'Record already exists'}
$fragment=([ordered]@{initialInputLineInitDefer=$record}|ConvertTo-Json -Depth 90).Trim().Replace("`r`n","`n")
$last=$before.LastIndexOf('}')
$after=$before.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$parsed=$after|ConvertFrom-Json -Depth 100
foreach($prop in $old.PSObject.Properties){if(($prop.Value|ConvertTo-Json -Depth 99 -Compress) -cne ($parsed.($prop.Name)|ConvertTo-Json -Depth 99 -Compress)){throw "Historical record changed: $($prop.Name)"}}
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$statusPath=Join-Path (Get-Location) 'docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText($statusPath)
$lines=@($status -split '\r?\n'|ForEach-Object {
 if($_.StartsWith('| Line の初期所有入力 |')){
 "| Line の初期所有入力 | **返却Actor／Copy・root deferの既受入を保持。追加init/scoped条件は一部修復・検証継続中** | root defer Source 5ba67c20a9aacafe3d1dd25939be42c92cddf52a と元のActor再返却／Copy再利用、初期packet／activation保存監査は受入済み。追加Source $source は元発行元の台帳を保持してscoped packetと実子入力を検証し、単純init入力のNative／毎step保存AWBC、outcome filterと8保存改変拒否が通過した。AWBC修復時154 PASS、追加後の最終owner選択は161件中158 PASS／3 FAIL。残る具体条件はNativeの明示init scope結果受取りと、Native／保存AWBCのinit-defer子からの対話待機。待機の取消し枝は初回通常枝で停止したため未実行。原本と再現Sourceを履歴へ保持し、Line/init等の既受入全体を未完了へ戻さない。[各run・全SHA・残条件・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }elseif($_.StartsWith('| workspace check／Clippy・fmt・構造gate |')){
 "| workspace check／Clippy・fmt・構造gate | **init/scoped修復cutの全workspace gateは終了0** | Source $source の全target／全feature workspace check／Clippy、canonical構造gate、8 Rust path fmtが3416入力drift0で終了0。警告と先行Sourceの全gate／Core unit／Core53 matrixは履歴へ保持し、新Sourceの全件結果へ合成しない。Cargo依存変更0。全14 family・他platform／Tier2・全表示parityの最終受入へ拡張しない。[実測・構造責任・原本](acceptance-evidence/task-flow-registry-execution.json)。 |"
 }else{$_}
})
[IO.File]::WriteAllText($statusPath,($lines -join "`n"),[Text.UTF8Encoding]::new($false))
$historyPath=Join-Path (Get-Location) 'docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText($historyPath)
$addition=@"

## 2026-11-08 — 初期所有入力のinit/scoped defer追加条件

再現Source **e8d203f4e8b387c5b2ed2daaf513a0a2c986836b** の初回は0 PASS／2 FAIL／122 SKIP。Nativeはtick17の異activation拒否、保存AWBCは所有slot不一致で停止した。Native修復 **62adc6132c134a990e2dfdfef1b31b2c7501dff4** 後は154件中153 PASS／1保存AWBC FAIL、AWBCのscoped登録・unwind・保存admission修復後は **154 PASS**。元の発行元台帳と実packet／子入力の一致を、値の移動前に検証する。Source **$source** はNativeの入れ子登録も同じprepared移送に揃え、returnが未実行cleanupを待つようにした。

追加5件の初回は3 PASS／2 FAIL。Nativeの受取handle再登録と、改変保存が正しく拒否された診断を狭く限定していたテストが失敗した。後者はtyped保存の復元拒否と元snapshot一致を直接観測する形へ訂正した。次の159件は158 PASS／1 Native lexical cleanup FAIL。returnのcleanup待ちを修復すると、Nativeの明示init scope結果受取りがtick19で「active emitted lexical frameなし」へ進んだ。対話待機2件を追加した最終161件は **158 PASS／3 FAIL**。Nativeの待機は512-step内に完了せず、保存AWBCはtick51でdefer子の対話受取先を拒否する。両待機テストは最初の通常枝で停止し、取消し枝は未実行。さらに最後のrevealを取消す旧helper指定は内側対話を選ばないため、内側取消しの受入を主張する前に入力先を明示する。

最終Sourceのworkspace全target／全feature check／Clippy、構造gateと8 Rust path fmtは終了0、3416入力drift0。Core53／CLIの新統合runではない。大きいscheduler／activation／AWBC line／snapshotは実スロットと取引を所有する既存境界に保ち、LOC／増分／embedded test数をrawへ保持した。既存12 tracked／6 actual untrackedは保持した。旧wrapperのheld=14 labelを現状WIP数に使わない。

現状は一つの初期入力行を追加条件の結果で置換し、単純initの通過と残る3条件を混同しない。Generic Match、元のLine/init、通常deferと初期root deferの受入は維持する。過去の実測・全SHAと失敗原本を削除・上書きしない。[全記録・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath,$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source;archiveEntries=$entries.Count;archiveSha256=$record.raw.sha256;historicalRecordsPreserved=$old.PSObject.Properties.Name.Count;originalUntracked=$untracked.Count;passed=$terminal.passed;failed=$terminal.failed}|ConvertTo-Json -Compress
