$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$taskPrefix = Join-Path $taskTemp 'ordinary-defer-line-captures-20261108.native-quality'
if (Test-Path -LiteralPath "$taskPrefix.source.json") { throw 'Source epoch already exists.' }
$owned = @(Get-Content -LiteralPath "$taskTemp/ordinary-defer-line-captures-20261108.native-cut.owned.txt")
$freeze = @($owned | ForEach-Object { [ordered]@{ path = $_; sha256 = (Get-FileHash -LiteralPath $_).Hash } })
[ordered]@{ base = (& git rev-parse HEAD); paths = $freeze } | ConvertTo-Json -Depth 6 |
    Set-Content -LiteralPath "$taskPrefix.source.json" -Encoding utf8NoBOM
function Assert-Inputs {
    foreach ($row in $freeze) {
        if ((Get-FileHash -LiteralPath $row.path).Hash -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
function Invoke-Recorded([string]$name, [string[]]$cargoArgs) {
    Assert-Inputs
    $started = [DateTime]::UtcNow.ToString('o')
    & cargo @cargoArgs *> "$taskPrefix.$name.log"
    $result = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ arguments = $cargoArgs; exitCode = $result; sourceInputs = $freeze.Count; sourceDrift = 0; startedAt = $started; endedAt = [DateTime]::UtcNow.ToString('o') } |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskPrefix.$name.receipt.json" -Encoding utf8NoBOM
    if ($name -ne 'catalog') { Get-Content -LiteralPath "$taskPrefix.$name.log" -Tail 16 }
    if ($result -ne 0) { throw "$name failed with $result" }
}
Invoke-Recorded 'catalog' @('nextest', 'list', '--locked', '-p', 'arcweft-core', '--lib', '--message-format', 'json')
$json = Get-Content -LiteralPath "$taskPrefix.catalog.log" | Where-Object { $_.StartsWith('{"rust-build-meta"') } | Select-Object -Last 1
$catalog = $json | ConvertFrom-Json -Depth 100
$cases = @($catalog.'rust-suites'.PSObject.Properties | ForEach-Object {
    $suite = $_.Value
    $suite.testcases.PSObject.Properties | ForEach-Object {
        [ordered]@{ package = $suite.'package-name'; binary = $suite.'binary-id'; test = $_.Name; status = $_.Value.'filter-match'.status; ignored = $_.Value.ignored }
    }
})
$cases | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskPrefix.catalog.inventory.json" -Encoding utf8NoBOM
if (@($cases | Where-Object status -eq 'matches').Count -ne 2323) { throw 'Core case count differs from 2323.' }
Invoke-Recorded 'runtime' @('nextest', 'run', '--locked', '-p', 'arcweft-core', '--lib', '--no-tests', 'fail', '--no-fail-fast', '--status-level', 'all', '--final-status-level', 'all')
Invoke-Recorded 'clippy' @('clippy', '--locked', '-p', 'arcweft-core', '-p', 'arcweft-compiler', '--all-targets', '--all-features')
Assert-Inputs
$started = [DateTime]::UtcNow.ToString('o')
& just structure-audit-gate *> "$taskPrefix.structure.log"
$result = $LASTEXITCODE
Assert-Inputs
[ordered]@{ command = 'just structure-audit-gate'; exitCode = $result; sourceInputs = $freeze.Count; sourceDrift = 0; startedAt = $started; endedAt = [DateTime]::UtcNow.ToString('o') } |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskPrefix.structure.receipt.json" -Encoding utf8NoBOM
Get-Content -LiteralPath "$taskPrefix.structure.log" -Tail 9
if ($result -ne 0) { throw 'Structure gate failed.' }
& rustfmt --check --edition 2024 --config skip_children=true @owned
if ($LASTEXITCODE -ne 0) { throw 'Rustfmt check failed.' }
[ordered]@{ command = 'rustfmt --check --edition 2024 --config skip_children=true'; exitCode = 0; paths = $owned; sourceDrift = 0 } |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskPrefix.fmt.receipt.json" -Encoding utf8NoBOM
