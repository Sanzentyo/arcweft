$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = $PSScriptRoot
$taskPrefix = 'ordinary-defer-line-captures-20261108'
$source = Get-Content "$taskTemp/$taskPrefix.native-source.verified.json" -Raw | ConvertFrom-Json
if ((& git rev-parse HEAD).Trim() -ne $source.commit) { throw 'Native source is not current main.' }
$foundation = Get-Content "$taskTemp/ordinary-defer-line-captures-20261107.slot-model-source.verified.json" -Raw | ConvertFrom-Json
$quality = [ordered]@{}
foreach ($name in @('catalog', 'runtime', 'clippy', 'structure', 'fmt')) {
    $receipt = Get-Content "$taskTemp/$taskPrefix.native-quality.$name.receipt.json" -Raw | ConvertFrom-Json
    if ($receipt.exitCode -ne 0 -or $receipt.sourceDrift -ne 0) { throw "Unfinished quality: $name" }
    $quality[$name] = $receipt
}
$doc = Get-Content "$taskTemp/$taskPrefix.native-doc.receipt.json" -Raw | ConvertFrom-Json
if ($doc.exitCode -ne 0) { throw 'Doctests failed.' }
$quality.doctest = $doc
$freeze = Get-Content "$taskTemp/$taskPrefix.native-quality.source.json" -Raw | ConvertFrom-Json
foreach ($row in $freeze.paths) {
    if ((Get-FileHash -LiteralPath $row.path).Hash -ne $row.sha256) { throw "Native source drift: $($row.path)" }
}
$ledgerPath = 'D:/git/arcweft/docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledgerBefore = [IO.File]::ReadAllText($ledgerPath)
if ($ledgerBefore.Contains('"ordinaryFlowLineCaptures"')) { throw 'Evidence already recorded.' }
$archivePath = 'D:/git/arcweft/docs/implementation/acceptance-evidence/task-ordinary-flow-line-captures.raw.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Archive already exists.' }
$rawNames = @(
    @(Get-ChildItem -LiteralPath $taskTemp -File -Filter 'ordinary-defer-line-captures-20261107*' | ForEach-Object Name)
    @(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$taskPrefix*" | ForEach-Object Name)
    @(Get-ChildItem -LiteralPath $taskTemp -File -Filter 'user-whole-clean-20261108*' | ForEach-Object Name)
    @('run-user-whole-clean-20261108.ps1', 'run-native-capture-cut-20261108.ps1', 'run-native-capture-quality-20261108.ps1', 'measure-native-capture-cut-20261108.ps1', 'record-native-captures-20261108.ps1')
) | Sort-Object -Unique
Compress-Archive -LiteralPath @($rawNames | ForEach-Object { Join-Path $taskTemp $_ }) -DestinationPath $archivePath -CompressionLevel Optimal
$entries = @($rawNames | ForEach-Object {
    [ordered]@{ entry = $_; bytes = (Get-Item -LiteralPath "$taskTemp/$_").Length; sha256 = (Get-FileHash -LiteralPath "$taskTemp/$_").Hash.ToLowerInvariant() }
})
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $entries.Count) { throw 'Archive count mismatch.' }
    foreach ($entry in $zip.Entries) {
        $expected = $entries | Where-Object { $_.entry -eq $entry.FullName }
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() } finally { $stream.Dispose() }
        if ($expected.bytes -ne $entry.Length -or $expected.sha256 -ne $hash) { throw 'Archive entry differs.' }
    }
} finally { $zip.Dispose() }
$record = [ordered]@{
    version = 1; date = '2026-11-08'; source = $source; slotFoundation = $foundation
    contract = @(
        'The actual Native packet owns each capture at its execution/fiber/registration/ordinal slot until a prepared child takes it.'
        'Published ParentFiber custody authenticates the receiving root separately from physical child execution/local namespaces. Strict version 1 owner shape replaces the old tuple; no legacy reader.'
        'Live and inert capture admission allows owned affine storage while retaining original ABI/type/resource checks and the actual issuer-ledger contour.'
        'An admitted owning pattern proof commits once; only the exact ignored Line handle graph receives Default cleanup authorization.'
    )
    actual = [ordered]@{
        nativeCaptureCases = @('direct returned Actor capture', 'Actor inside tuple capture', 'outcome-filter skip releases capture')
        integration = [ordered]@{ run = 10; passed = 7; failed = 3; skipped = 89; receipt = Get-Content "$taskTemp/$taskPrefix.integration-boundary.receipt.json" -Raw | ConvertFrom-Json }
        integrationPassed = @('three new Native capture cases', 'two existing Native nested Line transfers', 'two existing saved AWBC nested Line transfers, including root and register tampering rejection')
        scopedDeferRun = [ordered]@{ run = 38; passed = 35; failed = 3; scopedDeferPassed = 30; note = 'Initial combined run. Two failures were the new root-forgery test incorrectly treating canonical decimal-string identity as a JSON number; corrected and rerun in the final integration. The third is the newly exposed nested-Line capture-context failure.' }
        coreOwner = [ordered]@{ run = 2323; passed = 2323; failed = 0; sourceDrift = 0 }
        coreDoctest = [ordered]@{ run = 80; passed = 80; failed = 0 }
        operationBound = 1; tickBound = 512; realStageAcquireAndRelease = 1
        quality = $quality; sourceInputs = $freeze.paths
    }
    failuresAndRepairs = @(
        'The initial actor |> drop fixture was invalid semantic input; replacing it with a valid ignored owning pattern is a fixture correction, not runtime regression evidence.'
        'Valid returned Actor capture reproduced Native WrongOwner and saved AWBC invalid ordinary deferred scope transition. Direct out acquisition separately reproduced RuntimePlanLower rejection.'
        'Slot-model development builds exposed E0282 and E0283 in new Serde tests; explicit identity types repaired them. Final ownership-slot subset: 21 PASS.'
        'Native registration passed after physical packet/root custody integration, but hit the unchanged 512-step bound. Internal frame inspection found unrestricted snapshot rejection for an affine owned capture; packet admission now uses Owned.'
        'After Owned admission, the same bound remained. A direct frame-failure assertion exposed an unjournaled handle drop from a successful ignored pattern; the owning pattern commit now journals that exact graph. Direct, aggregate and skipped-filter cases pass.'
        'The root-forgery test initially used as_u64 on the canonical identity string. Corrected to the actual canonical string encoding; both saved AWBC nested tests pass.'
    )
    outstandingEvidence = @(
        [ordered]@{ test = 'ordinary_defer::native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line'; actual = 'line ownership references unknown runtime local declaration 4'; owner = 'RuntimePlan Line capture emission still uses the enclosing local rather than the deferred executable input frame.' }
        [ordered]@{ test = 'ordinary_defer::saved_awbc_ordinary_flow_defer_keeps_returned_line_actor_until_its_cleanup'; actual = 'invalid ordinary deferred scope transition at tick 15'; owner = 'AWBC ordinary defer still rejects affine Line captures; packet/future-child physical custody and reconciliation remain to integrate.' }
        [ordered]@{ test = 'ordinary_defer::line_result_direct_acquisition_uses_its_owning_line_plan'; actual = 'line capability call ExprId slot 18 must be consumed by typed line-plan lowering'; owner = 'Line out currently bypasses the owning Line operation producer.' }
    )
    limits = @('These three newly reproduced conditions do not reopen previously accepted Native bounded behavior, Line/init, or Generic Match.', 'AWBC cancellation and pre-construction aggregate/count admission remain separate required boundaries.', 'No fresh Core53 matrix or workspace-wide all-target/all-feature check/Clippy was run for this checkpoint. The b6df matrix remains historical Source evidence, not a run of this new source.', 'Core/Compiler Clippy and structural gate exit 0 include warnings/review triggers, not a warning-free result.', 'Native public save/restore and final Native/Web visual acceptance are not established by the internal rollback and saved AWBC tests.')
    ownershipReview = Get-Content "$taskTemp/$taskPrefix.native-quality.ownership-review.json" -Raw | ConvertFrom-Json -Depth 20
    cargoClean = Get-Content "$taskTemp/user-whole-clean-20261108.receipt.json" -Raw | ConvertFrom-Json
    raw = [ordered]@{ path = 'task-ordinary-flow-line-captures.raw.zip'; sha256 = (Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant(); entries = $entries }
}
$fragment = ([ordered]@{ ordinaryFlowLineCaptures = $record } | ConvertTo-Json -Depth 90).Trim().Replace("`r`n", "`n")
$last = $ledgerBefore.LastIndexOf('}')
$ledgerAfter = $ledgerBefore.Substring(0, $last).TrimEnd() + ",`n  " + $fragment.Substring(1, $fragment.Length - 2).Trim() + "`n}`n"
$null = $ledgerAfter | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText($ledgerPath, $ledgerAfter, [Text.UTF8Encoding]::new($false))
$historyPath = 'D:/git/arcweft/docs/implementation/convergence-evidence-history.md'
$history = [IO.File]::ReadAllText($historyPath)
$addition = @"

## 2026-11-08 — Native Flow の Line 捕捉と新しい再現条件

slot 基盤 **$($foundation.commit)** と Native 接続 **$($source.commit)** を既存 main に通常 commit/pushし、親・tree・全 blob・完全差分を照合した。元12 tracked／6 untracked WIPは保持した。実 packet の捕捉スロット、独立した cleanup 子の namespace、受取先 root の認可を区別し、元発行 ledger と live／inert の所有対応を検査する。捕捉は Owned admissionへ通し、成功した owning pattern が無視した handle だけを正規 cleanup に記録する。旧 ParentFiber tuple reader は残さず version 1 の shape を直接移行した。
slot の最終 subset は21 PASS。開発中の E0282／E0283、無効な初回 fixture、Native の512-step停止、内部 frame の unrestricted snapshot 拒否、その後の unjournaled Drop と修復を原本に保持する。上限・ACK・取得解放回数は弱めていない。
最終境界 run は10件中7 PASS／3 FAIL。Native の直接／tuple 捕捉と条件不一致時の解放の3件、既存 Native の入れ子2件と公開保存付き AWBC の入れ子2件が PASS。後者は受取先 root と register の改変をそれぞれ原子拒否する。先行の38件 run は35 PASS／3 FAILで、scoped_defer 30件は全 PASS。2件の失敗は新しい改変テストが canonical string IDを数値と取り違えた問題として修復し、最終runへ含めた。初回結果を全件PASSに書き換えず、別runを合算しない。
残る実際の3失敗は、cleanup 内 Line が外側 local 4を参照する捕捉 context、AWBC の通常 defer の affine 捕捉拒否、直接 out する Line capability の lowering 拒否。具体的な入力・診断を現状一覧の当該行に反映し、既受入の Native 範囲／Line-init／Generic Match を戻さない。Core全2323件、Core doctest80件、Core／Compiler全target・全feature Clippy、17 Rust pathのfmtと構造gateは終了0。新たな Core53 matrix／workspace全体のgateは未実施で、b6dfの実測を新Sourceの結果としない。所有者の実測・凝集性の理由、警告、全失敗と新Source SHAを保持する。
ユーザーの指示による cargo clean は終了0、171973 files／192.3 GiBを削除し、直後の空きは488293679104 bytes。変更済み／未追跡33ファイルのhash、Git statusとHEADは不変。その後に上記の再ビルドを実行した。[全実測・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIPは $($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText($historyPath, $history.TrimEnd() + "`n" + $addition.Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$statusPath = 'D:/git/arcweft/docs/implementation/current-status.md'
$status = [IO.File]::ReadAllText($statusPath)
$anchor = 'AWBC で未検証の取消し・Line affine 捕捉、登録／子構築前の集約検査は継続中。'
if ([regex]::Matches($status, [regex]::Escape($anchor)).Count -ne 1) { throw 'Current ordinary Flow row differs.' }
$replacement = '追加 Source ' + $source.commit + ' では、Native の返却 Actor の直接／tuple 捕捉と条件不一致時の解放の3条件がPASS。受取りのroot認可と子の物理namespaceを分け、所有packetのrollbackと正規pattern破棄を接続した。新しい入力で、cleanup内Lineの捕捉先誤り（unknown local 4）、AWBC通常defer捕捉の登録拒否、直接outするLine操作のlowering拒否を再現した。この3条件とAWBC取消し・登録／子構築前の集約検査は継続中。'
$status = $status.Replace($anchor, $replacement).Replace('確認日 2026-11-07。', '確認日 2026-11-08。')
$gateAnchor = '他 platform／Tier2 の受入へ拡張しない。'
if ([regex]::Matches($status, [regex]::Escape($gateAnchor)).Count -ne 1) { throw 'Current gate row differs.' }
$status = $status.Replace($gateAnchor, '追加Source ' + $source.commit + ' はCore全2323件／doctest80件とCore・Compilerの全target／全feature Clippy・17 path fmt・構造gateが終了0。新Sourceのworkspace全体／Core53再検証は未実施。他 platform／Tier2 の受入へ拡張しない。')
[IO.File]::WriteAllText($statusPath, $status, [Text.UTF8Encoding]::new($false))
[ordered]@{ source = $source.commit; entries = $entries.Count; rawSha256 = $record.raw.sha256; corePassed = 2323; integrationPassed = 7; integrationFailed = 3 } | ConvertTo-Json
