$ErrorActionPreference = 'Stop'
$taskRoot = 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$taskPrefix = Join-Path $taskTemp 'user-whole-clean-20261108'
Set-Location -LiteralPath $taskRoot
if (Test-Path -LiteralPath "$taskPrefix.receipt.json") { throw 'Clean receipt already exists; do not repeat.' }
$metadataText = & cargo metadata --no-deps --format-version 1
if ($LASTEXITCODE -ne 0) { throw 'Cargo metadata failed.' }
$metadata = $metadataText | ConvertFrom-Json
$target = [IO.Path]::GetFullPath($metadata.target_directory)
$expected = [IO.Path]::GetFullPath((Join-Path $taskRoot 'target'))
if ($target -ne $expected) { throw "Unexpected cargo clean target: $target" }
$builders = @(Get-CimInstance Win32_Process -Filter "Name = 'cargo.exe' OR Name = 'rustc.exe' OR Name = 'cargo-nextest.exe'")
if ($builders.Count -gt 0) { throw 'A Cargo build or test is still running.' }
$paths = @(& git diff --name-only HEAD) + @(& git ls-files --others --exclude-standard)
$paths = @($paths | Sort-Object -Unique)
$before = @($paths | ForEach-Object {
    [ordered]@{ path = $_; sha256 = (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash }
})
$statusBefore = @(& git status --porcelain=v1 --untracked-files=all)
$head = & git rev-parse HEAD
$freeBefore = (Get-PSDrive D).Free
$startedAt = [DateTime]::UtcNow.ToString('o')
[ordered]@{ head = $head; target = $target; free = $freeBefore; status = $statusBefore; files = $before } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskPrefix.before.json" -Encoding utf8NoBOM
& cargo clean *> "$taskPrefix.log"
$cleanExit = $LASTEXITCODE
$after = @($paths | ForEach-Object {
    [ordered]@{ path = $_; sha256 = (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash }
})
$statusAfter = @(& git status --porcelain=v1 --untracked-files=all)
$filesUnchanged = ($before | ConvertTo-Json -Compress) -eq ($after | ConvertTo-Json -Compress)
$statusUnchanged = ($statusBefore -join "`n") -eq ($statusAfter -join "`n")
$headUnchanged = $head -eq (& git rev-parse HEAD)
$freeAfter = (Get-PSDrive D).Free
$receipt = [ordered]@{
    command = 'cargo clean'; head = $head; target = $target; exitCode = $cleanExit
    startedAt = $startedAt; finishedAt = [DateTime]::UtcNow.ToString('o')
    freeBefore = $freeBefore; freeAfter = $freeAfter; freeChange = $freeAfter - $freeBefore
    targetPresent = Test-Path -LiteralPath $target
    preservedFiles = $paths.Count; filesUnchanged = $filesUnchanged
    gitStatusUnchanged = $statusUnchanged; headUnchanged = $headUnchanged
}
$receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskPrefix.receipt.json" -Encoding utf8NoBOM
Get-Content -LiteralPath "$taskPrefix.log"
$receipt | ConvertTo-Json -Depth 6
if ($cleanExit -ne 0 -or -not $filesUnchanged -or -not $statusUnchanged -or -not $headUnchanged) { exit 1 }
