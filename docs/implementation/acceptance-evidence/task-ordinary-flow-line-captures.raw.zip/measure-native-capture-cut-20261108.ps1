$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
. "$taskTemp/convergence-image-git-bytes.ps1"
$taskBase = (& git rev-parse HEAD).Trim()
$taskPaths = @(Get-Content "$taskTemp/ordinary-defer-line-captures-20261108.native-cut.owned.txt")
$taskMetadata = Get-Content "$taskTemp/function-scope-20261107.metadata-all.json" -Raw | ConvertFrom-Json -Depth 100
$taskOwners = @{}
foreach ($packageName in @('arcweft-core', 'arcweft-compiler')) {
    $package = $taskMetadata.packages | Where-Object name -eq $packageName
    $node = $taskMetadata.resolve.nodes | Where-Object id -eq $package.id
    $taskOwners[$packageName] = [ordered]@{
        id = $package.id
        fanOut = @($node.deps.pkg | Sort-Object -Unique).Count
        fanIn = @($taskMetadata.resolve.nodes | Where-Object { $package.id -in $_.deps.pkg }).Count
    }
}
function Get-EmbeddedTestLines([string[]]$lines) {
    # Same measurement algorithm as tools/structure-audit.rs::embedded_test_lines.
    $total = 0
    $index = 0
    while ($index -lt $lines.Count) {
        if (-not $lines[$index].Trim().StartsWith('#[cfg(test)]')) { $index++; continue }
        $moduleStart = -1
        for ($cursor = $index; $cursor -lt [Math]::Min($lines.Count, $index + 8); $cursor++) {
            $line = $lines[$cursor].Trim()
            if ($line.Contains('mod ') -and $line.Contains('{')) { $moduleStart = $cursor; break }
        }
        if ($moduleStart -lt 0) { $index++; continue }
        $depth = 0
        $sawOpen = $false
        $moduleEnd = $moduleStart
        for ($cursor = $moduleStart; $cursor -lt $lines.Count; $cursor++) {
            $opens = [regex]::Matches($lines[$cursor], '\{').Count
            $closes = [regex]::Matches($lines[$cursor], '\}').Count
            $sawOpen = $sawOpen -or $opens -gt 0
            $depth += $opens - $closes
            $moduleEnd = $cursor
            if ($sawOpen -and $depth -le 0) { break }
        }
        $total += $moduleEnd - $index + 1
        $index = $moduleEnd + 1
    }
    return $total
}
$taskRows = @(foreach ($path in $taskPaths) {
    $lines = [IO.File]::ReadAllLines((Join-Path (Get-Location) $path))
    [byte[]]$oldBytes = @()
    if (-not $path.EndsWith('/ordinary_defer.rs')) { $oldBytes = Read-GitBytes @('show', "${taskBase}:$path") }
    $oldText = [Text.Encoding]::UTF8.GetString($oldBytes)
    $oldLines = if ($oldBytes.Length -eq 0) { 0 } else { [regex]::Matches($oldText, "`n").Count + [int](-not $oldText.EndsWith("`n")) }
    $owner = if ($path.StartsWith('crates/arcweft-core/')) { 'arcweft-core' } else { 'arcweft-compiler' }
    $isTest = $path.Contains('/tests/')
    $responsibility = switch -Wildcard ($path) {
        '*/engine.rs' { 'Native frame storage, scheduling and ownership reconciliation over actual retained fibers.' }
        '*/engine/rollback.rs' { 'One borrowed native live/inert admission contour; original ledger and storage identities stay authoritative.' }
        '*/engine/eval.rs' { 'Native expression and owning pattern evaluation; consumes the existing pattern proof and journals exact ignored handles.' }
        '*/engine/defer/*' { 'Native ordinary lexical defer registration and budgeted unwind.' }
        '*/engine/program.rs' { 'Program activation and published parent storage inventory; no new value storage or fallback resolver.' }
        '*/engine/dialogue/store.rs' { 'Native dialogue transactions and inert specialization forward to the common registry.' }
        '*/engine/dialogue.rs' { 'Native dialogue activation/publication authenticates the root and the actual physical slot separately.' }
        '*/line_task/activation.rs' { 'Backend-neutral activation registry and atomic issuer-ledger reconciliation.' }
        '*/line_task/handle.rs' { 'Affine Line lease state machine and owner grammar, evolved in place at version 1.' }
        '*/line_task/defer.rs' { 'One live/inert owning deferred capture packet and original ABI admission.' }
        '*/awbc/product_step/dialogue.rs' { 'Product dialogue store forwards to the common registry.' }
        '*/awbc/product_step/line.rs' { 'Product Line ownership/publication consumers migrate to the final qualified owner.' }
        '*/awbc/product_step/snapshot.rs' { 'Product snapshot admission authenticates the published root with its real fiber graph.' }
        '*/tests/evaluated_effects.rs' { 'Shared compiled Source / real Actor ACK / Native and public-save Product acceptance helpers.' }
        default { 'Behavioral tests or fixtures for the same typed storage/lease boundary.' }
    }
    [ordered]@{
        path = $path; owner = $owner; bytes = (Get-Item -LiteralPath $path).Length
        physicalLines = $lines.Count; basePhysicalLines = $oldLines; growth = $lines.Count - $oldLines
        classification = $(if ($isTest) { 'test' } else { 'production' })
        embeddedTestLines = Get-EmbeddedTestLines $lines
        ownerGraph = $taskOwners[$owner]; disposition = 'retain-cohesive-owner'
        rationale = $responsibility
    }
})
[ordered]@{
    base = $taskBase; workingTree = @(& git status --porcelain=v1 --untracked-files=all)
    measurementOnly = $true; sourcePlacementIsNotAcceptanceGate = $true
    metadataSource = 'function-scope-20261107.metadata-all.json'
    graphUnchanged = 'No manifest, lockfile, feature, export or crate dependency changes in this cut.'
    fullCoreReverseClosure = 53; fullReverseRun = 'pending remaining producer/AWBC integration'
    rows = $taskRows
} | ConvertTo-Json -Depth 10 | Set-Content "$taskTemp/ordinary-defer-line-captures-20261108.native-quality.ownership-review.json" -Encoding utf8NoBOM
$taskRows | Select-Object path,physicalLines,basePhysicalLines,growth,embeddedTestLines | Format-Table -AutoSize
