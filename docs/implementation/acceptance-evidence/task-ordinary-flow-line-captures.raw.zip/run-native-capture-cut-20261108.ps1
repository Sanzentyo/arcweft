$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp = 'C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$taskPrefix = Join-Path $taskTemp 'ordinary-defer-line-captures-20261108.native-cut'
if (Test-Path -LiteralPath "$taskPrefix.source.json") { throw 'Source epoch already exists.' }
$owned = @(Get-Content -LiteralPath "$taskPrefix.owned.txt")
& rustfmt --edition 2024 --config skip_children=true @owned
if ($LASTEXITCODE -ne 0) { throw 'Rustfmt failed.' }
$freeze = @($owned | ForEach-Object {
    [ordered]@{ path = $_; sha256 = (Get-FileHash -LiteralPath $_).Hash }
})
[ordered]@{ base = (& git rev-parse HEAD); paths = $freeze } | ConvertTo-Json -Depth 6 |
    Set-Content -LiteralPath "$taskPrefix.source.json" -Encoding utf8NoBOM
function Assert-Inputs {
    foreach ($row in $freeze) {
        if ((Get-FileHash -LiteralPath $row.path).Hash -ne $row.sha256) { throw "Source drift: $($row.path)" }
    }
}
function Invoke-Recorded([string]$name, [string[]]$cargoArgs) {
    Assert-Inputs
    $started = [DateTime]::UtcNow.ToString('o')
    & cargo @cargoArgs *> "$taskPrefix.$name.log"
    $result = $LASTEXITCODE
    Assert-Inputs
    [ordered]@{ arguments = $cargoArgs; exitCode = $result; sourceInputs = $freeze.Count; sourceDrift = 0; startedAt = $started; endedAt = [DateTime]::UtcNow.ToString('o') } |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$taskPrefix.$name.receipt.json" -Encoding utf8NoBOM
    if ($name -ne 'catalog') { Get-Content -LiteralPath "$taskPrefix.$name.log" -Tail 24 }
    if ($result -ne 0) { throw "$name failed with $result" }
}
$selection = @('--locked', '-p', 'arcweft-compiler', '--test', 'evaluated_effects', '--test', 'scoped_defer', '-E', 'binary(=scoped_defer) | test(ordinary_defer::native_) | test(nested_line_handle_)')
Invoke-Recorded 'catalog' (@('nextest', 'list') + $selection + @('--message-format', 'json'))
$json = Get-Content -LiteralPath "$taskPrefix.catalog.log" | Where-Object { $_.StartsWith('{"rust-build-meta"') } | Select-Object -Last 1
$catalog = $json | ConvertFrom-Json -Depth 100
$matches = @($catalog.'rust-suites'.PSObject.Properties | ForEach-Object {
    $suite = $_.Value
    $suite.testcases.PSObject.Properties | Where-Object { $_.Value.'filter-match'.status -eq 'matches' } | ForEach-Object {
        [ordered]@{ package = $suite.'package-name'; binary = $suite.'binary-id'; test = $_.Name }
    }
})
$matches | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskPrefix.catalog.inventory.json" -Encoding utf8NoBOM
if ($matches.Count -ne 38) { throw "Expected 38 cases, got $($matches.Count)" }
Invoke-Recorded 'runtime' (@('nextest', 'run') + $selection + @('--no-tests', 'fail', '--no-fail-fast', '--status-level', 'all', '--final-status-level', 'all'))
