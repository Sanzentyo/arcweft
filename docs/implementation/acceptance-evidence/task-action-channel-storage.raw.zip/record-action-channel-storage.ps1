$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$t='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$t/assert-no-arcweft-build.ps1"
function Receipt([string]$name){Get-Content -LiteralPath "$t/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$publication=Receipt 'checkpoint-action-channel-storage.verified'
if((git rev-parse HEAD).Trim() -ne $publication.commit){throw 'Source publication changed'}
$final=Receipt 'action-channel-storage4-20261103.runtime.terminal-audit'
$full=Receipt 'action-channel-storage2-20261103.runtime.terminal-audit'
if(-not $final.isPassingRun -or $final.executed -ne 3 -or $full.passed -ne 2242 -or $full.failed -ne 3){throw 'Unexpected test results'}
$freeze=Receipt 'action-channel-storage4-20261103.source-freeze'
$earlier=Receipt 'action-channel-storage2-20261103.source-freeze'
foreach($row in $freeze.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw ('Input changed: '+$row.path)}}
$old=@{};foreach($row in $earlier.paths){$old[$row.path]=$row.sha256}
$changed=@($freeze.paths|Where-Object {$old[$_.path] -ne $_.sha256}|Select-Object -ExpandProperty path)
if($changed.Count -ne 1 -or $changed[0] -ne 'crates/arcweft-core/src/awbc/product_step/tests/actions.rs'){throw 'Reuse requires test-fixture-only changes'}
$quality=@(foreach($name in @('check','clippy','structure')){$receipt=Receipt "action-channel-storage-quality1-20261103-$name";if($receipt.exitCode -ne 0){throw 'Quality gate failed'};$receipt})
$original=Receipt 'task-documentation-final-untracked-before'
foreach($row in $original.files){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Original untracked WIP changed'}}
$raw='docs/implementation/acceptance-evidence/task-action-channel-storage.raw.zip'
$record='docs/implementation/acceptance-evidence/task-action-channel-storage.json'
if((Test-Path $raw) -or (Test-Path $record)){throw 'Preserve existing evidence'}
$files=@(Get-ChildItem -LiteralPath $t -File|Where-Object {$_.Name -match '^(action-channel-(core|storage)|checkpoint-action-channel-storage[.])'})
$files+=@(Get-Item "$t/record-action-channel-storage.ps1","$t/run-presentation-projection-owner.ps1","$t/audit-nextest-final-result.ps1","$t/run-action-payload-quality.ps1")
$files=@($files|Sort-Object FullName -Unique)
$entries=@();$zip=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($raw),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,$file.Name,[IO.Compression.CompressionLevel]::Optimal);$entries+=[ordered]@{entry=$file.Name;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($raw))
try{if($zip.Entries.Count -ne $entries.Count){throw 'Raw entry count changed'};foreach($row in $entries){$stream=$zip.GetEntry($row.entry).Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($hash -ne $row.sha256){throw 'Raw entry hash mismatch'}}}finally{$zip.Dispose()}
$basePaths=@(git ls-tree -r --name-only $publication.parent)
$measurements=@(foreach($path in (Get-Content "$t/checkpoint-action-channel-storage.owned.txt")){
    $oldText=@();if($path -in $basePaths){$oldText=@(git show ($publication.parent+':'+$path))}
    [ordered]@{path=$path;owner='arcweft-core';bytes=(Get-Item -LiteralPath $path).Length;physicalLoc=@([IO.File]::ReadLines([IO.Path]::GetFullPath($path))).Count;baseLoc=$oldText.Count;classification=$(if($path -match '/tests[/.]|/tests.rs$'){'test'}else{'production'})}
})
$evidence=[ordered]@{
    version=1;recordedAt=[DateTime]::UtcNow.ToString('o');status='intermediate-source-checkpoint';source=$publication.commit;publication=$publication
    scope='Private bounded Action message storage integrated into Native rollback and Product retained admission, visitors, execution/session checkpoints and version-one inert save/restore. This is substrate validation, not source emit/receive execution acceptance.'
    ownership='The selected immutable program type table remains the sole original Action declaration/payload schema authority. A queue owns semantic payload keys and values only. No parallel channel catalog, live Clone/Serde, fallback or legacy reader. Inert row validation precedes queue construction; complete retained admission precedes snapshot copying and live materialization. Product restores retain the original Source restore context.'
    preliminaryCoreCheck=(Receipt 'action-channel-core-owner1-20261103.check')
    initialMailboxCompile=(Receipt 'action-channel-core-mailbox1-20261103.catalog')
    mailboxTests=(Receipt 'action-channel-core-mailbox2-20261103.runtime.terminal-audit')
    initialStorageCompile=(Receipt 'action-channel-storage1-20261103.catalog')
    fullCoreRun=$full
    fixtureStringRepairRun=(Receipt 'action-channel-storage3-20261103.runtime.terminal-audit')
    finalProductCases=$final
    reuse=[ordered]@{passedCases=2242;from='action-channel-storage2-20261103.runtime';changedInputs=$changed;reason='Only the isolated new Product fixture changed: canonical string-table normalization and actual type-row selection replaced erroneous dense index assumptions. Production bytes, feature/target selection and the other test inputs are identical. Three formerly failing IDs rerun and pass; this is not one fresh 2245-case pass.';ignored=0;finalFilterExcluded=2242}
    repairs=@('Mailbox fixture used a nonexistent max_collection_len field; corrected to max_sequence_items before mailbox2.','Storage1 compile101: two original Product checkpoint callers omitted the new queue, and two fixture layout conversions used the wrong Rust wrapper.','Storage2 new three cases failed canonical string ordering; storage3 then exposed incorrect dense runtime type indices in the fixture. Original failures retained; no production validation was weakened.')
    quality=$quality;sourceInputs=$freeze.paths.Count;sourceDrift=0
    reverseGraph=(Receipt 'action-channel-storage.reverse-graph')
    validationLimit='Core owner gates only in this checkpoint. Source emit/receive, Compiler/RuntimePlan consumers, pending receive/cancellation, original operation/source capture authorization and their full 53-package Core reverse closure remain part of the continuing implementation. No full-workspace compile or actual source delivery claim.'
    structuralReview=[ordered]@{measurements=$measurements;disposition='The private mailbox owns only bounded typed payload custody. Native Engine and Product executor own session state; their existing admission/rollback/save modules include that state under the same owner and allowance. Existing large execution and snapshot owners retain their responsibility; the cut adds no dependency, schema authority, source reconstruction or I/O. New behavior tests follow the mailbox and Product persistence owners.'}
    priorCompleteConsumerSource='7104b200150b9b85b31cd686c48573b92b2028d3';genericMatch='Accepted and published; unchanged acceptance.';originalWip=[ordered]@{tracked=12;untracked=6;heldPatchSha256=$publication.heldPatchSha256;untrackedHashDrift=0}
    raw=[ordered]@{path=$raw;bytes=(Get-Item $raw).Length;sha256=(Get-FileHash $raw).Hash.ToLowerInvariant();entries=$entries;entryDrift=0}
}
$json=($evidence|ConvertTo-Json -Depth 100).Replace("`r`n","`n")+"`n"
[IO.File]::WriteAllText([IO.Path]::GetFullPath($record),$json,[Text.UTF8Encoding]::new($false))
$status=[IO.Path]::GetFullPath('docs/implementation/current-status.md');$text=[IO.File]::ReadAllText($status)
$header="確認日: 2026-11-03。最新公開Sourceは$($publication.commit)（Actionキュー・保持・保存の中間checkpoint）。直近の全consumer検証はSource 7104b200150b9b85b31cd686c48573b92b2028d3の通常9194件PASS。今回のCore保持境界と、送受信前段の739件PASSを全体の実送受信受入や全workspace検証とはしない。既存12 tracked／6 actual untracked WIPを保持している。"
$text=[regex]::Replace($text,'(?m)^確認日:[^\r\n]*',[Text.RegularExpressions.MatchEvaluator]{param($m)$header})
$pattern='(?m)^\| Action宣言・payload record／型付きチャンネル値 \|[^\r\n]*'
if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Current Action authority row changed'}
$text=[regex]::Replace($text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m)
    $row=$m.Value;$cut=$row.IndexOf('進行中Source ');if($cut -lt 0){throw 'Expected replaced current wording absent'}
    $row.Substring(0,$cut)+"前段b014d31e8976bb9f902f707c3b9f73c7851467a5はemit／receive共通callableと通常call構文で739件PASS。[前段実測](acceptance-evidence/task-action-channel-front.json)。進行中Source $($publication.commit)は元program型を使うboundedキューをNative rollback・Productの保持予算／checkpoint／inert saveへ接続した。Core全2245件は2242 PASS／新fixture3 FAIL、fixtureだけを修正した同3 IDの再実行は3 PASS。単一の全件再実行とはしない。Core check／Clippy／構造gateは終了0。ソースからの配送・待機・キャンセル、RuntimePlan／Compiler利用側と全consumer検証は未完。[初回失敗・修復・保持境界の実測](acceptance-evidence/task-action-channel-storage.json)。 |"
})
[IO.File]::WriteAllText($status,$text,[Text.UTF8Encoding]::new($false))
$history=[IO.Path]::GetFullPath('docs/implementation/convergence-evidence-history.md');$before=[IO.File]::ReadAllBytes($history);$prefixSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($before)).ToLowerInvariant()
$append=@"


## Actionキュー・保持・保存の中間checkpoint — 2026-11-03

Source $($publication.commit)、parent $($publication.parent)、tree $($publication.tree)、full patch SHA256 $($publication.patchSha256)。元programのAction declaration／payload schemaを唯一のauthorityとして、キューのFIFO・異channel隔離・拒否時のpayload保持と、Native rollback／Product保持・visitor・checkpoint・version 1 inert saveを接続した。live queueのClone／Serdeや別channel catalogは導入していない。Productは元Sourceのrestore contextも保持する。

初回mailbox catalogはfixtureの上限field名を誤りcompile101、修正後のmailbox3件は3 PASS。storage1 catalogはcheckpoint呼出し2か所とfixtureのlayout型変換2か所でcompile101、修正後のCore library全2245件は2242 PASS／3 FAIL（19.998s）。新Product fixtureの文字列表正規化を修正したstorage3の3件は、dense型indexの誤りで0 PASS／3 FAIL。actual semantic rowから選ぶfixtureへ修正したstorage4は同3 IDが3 PASS（0.043s）。full runから変わった入力は孤立した新Product test moduleだけで、production bytesは同じ。2242 PASSを再利用し、3件を再実行した証拠であって、2245件の一回の新規PASSとはしない。4087入力、Source／case／test EXE差分0。Core all-target／all-feature／locked check・Clippyとcanonical構造gateは終了0、警告は残る。

これは保持境界の検証であり、ソースからのemit／receive・待機・キャンセル、RuntimePlan／Compiler利用側、53 package Core逆依存の最終実行は未完。全workspace compileや実送受信の受入は主張しない。既受入Generic MatchとAction declaration identityは維持する。旧現状の「Core保存復元は未移行」は、この新しい保持境界の実測に基づき現状一覧一か所で更新した。旧失敗・SHA・実測を削除していない。既存12 tracked／6 untracked WIPはhash照合して保持した。

raw $($entries.Count) entries／$($evidence.raw.bytes) bytes、SHA256 $($evidence.raw.sha256)、entry hash差分0。[入力・全失敗・修復・構造判断・公開照合](acceptance-evidence/task-action-channel-storage.json)。
"@
$bytes=[Text.UTF8Encoding]::new($false).GetBytes($append);$stream=[IO.File]::Open($history,[IO.FileMode]::Append,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$stream.Write($bytes)}finally{$stream.Dispose()}
$after=[IO.File]::ReadAllBytes($history);$prefix=[byte[]]::new($before.Length);[Array]::Copy($after,$prefix,$prefix.Length)
if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($prefix)).ToLowerInvariant() -ne $prefixSha){throw 'History prefix changed'}
[ordered]@{source=$publication.commit;rawEntries=$entries.Count;rawBytes=$evidence.raw.bytes;rawSha256=$evidence.raw.sha256;preservedHistoryBytes=$before.Length;preservedHistorySha256=$prefixSha;historyPrefixDrift=0}|ConvertTo-Json
