$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp=$PSScriptRoot
$prefix='line-initial-inputs-20261108'
$source=Get-Content -LiteralPath "$taskTemp/$prefix.baseline.verified.json" -Raw | ConvertFrom-Json
$run=Get-Content -LiteralPath "$taskTemp/$prefix.awbc-baseline.receipt.json" -Raw | ConvertFrom-Json
if((& git rev-parse HEAD).Trim() -ne $source.commit -or $run.exitCode -ne 100){throw 'Baseline differs'}
$log=[IO.File]::ReadAllText("$taskTemp/$prefix.awbc-baseline.log")
if(-not $log.Contains('2 tests run: 0 passed, 2 failed, 112 skipped') -or -not $log.Contains('line task group capture ABI must be exact and recursively unrestricted') -or -not $log.Contains('line-task group capture must be unrestricted because group work may fan out')){throw 'Actual reproduction differs'}
$ledgerPath='docs/implementation/acceptance-evidence/task-flow-registry-execution.json'
$ledger=[IO.File]::ReadAllText((Join-Path (Get-Location) $ledgerPath))
if($ledger.Contains('"ownedLineInputBaseline"')){throw 'Baseline evidence already exists'}
$archivePath='docs/implementation/acceptance-evidence/task-line-initial-inputs-baseline.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Raw archive exists'}
$names=@(@(Get-ChildItem -LiteralPath $taskTemp -File -Filter "$prefix*" | ForEach-Object Name)+@('record-line-initial-inputs-baseline-20261108.ps1') | Sort-Object -Unique)
Compress-Archive -LiteralPath @($names | ForEach-Object {Join-Path $taskTemp $_}) -DestinationPath $archivePath -CompressionLevel Optimal
$entries=@(foreach($name in $names){[ordered]@{entry=$name;bytes=(Get-Item -LiteralPath "$taskTemp/$name").Length;sha256=(Get-FileHash -LiteralPath "$taskTemp/$name").Hash.ToLowerInvariant()}})
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path (Get-Location) $archivePath))
try{
 if($zip.Entries.Count -ne $entries.Count){throw 'Archive count differs'}
 foreach($entry in $zip.Entries){
  $expected=$entries | Where-Object entry -eq $entry.FullName
  $stream=$entry.Open()
  try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
  if($entry.Length -ne $expected.bytes -or $hash -ne $expected.sha256){throw 'Archive entry differs'}
 }
}finally{$zip.Dispose()}
$record=[ordered]@{
 version=1;date='2026-11-08';source=$source
 status='Failing acceptance reproduction, not an implementation acceptance. Production code is unchanged.'
 input='The same returned Actor moves into an ordinary defer, is returned by its Cleanup Line, then is consumed by another nested defer. Both backends use the exact same source factory and unchanged 1-op/512-step, two-line and one-acquire/one-release expectations.'
 actual=[ordered]@{run=2;passed=0;failed=2;skipped=112;receipt=$run}
 failures=@(
  [ordered]@{id='ordinary_defer::native_ordinary_flow_defer_reexports_an_actor_through_its_nested_line';boundary='Native Line ingress';diagnostic='line-task group capture must be unrestricted because group work may fan out'},
  [ordered]@{id='ordinary_defer::saved_awbc_ordinary_flow_defer_reexports_an_actor_through_its_nested_line';boundary='AWBC verifier, before execution or save';diagnostic='line task group capture ABI must be exact and recursively unrestricted'}
 )
 corrections=@('The unresolved initial owned Line input affects both executors on this exact input; replace the Native-only current wording with the concrete two-backend evidence.', 'This is not a failure of previously accepted ordinary defer Actor packets or ordinary deferred-child Dialogue dispatch. Those accepted boundaries are unchanged.', 'Keep the earlier complete 113-case 112 PASS/1 FAIL run as history. The new catalog has one additional test, but only the selected two tests ran; do not infer a complete 114-case result.')
 nextBoundary='Separate the one-time initial Line input ABI from post-reveal shared Copy inputs on the owning plan/function schemas and migrate Native, AWBC lowering/verifier/runtime, custody and save consumers together. Preserve exact selected Copy/Move decisions; no runtime value heuristic, cloned affine inputs or fake frame identity.'
 validation=[ordered]@{fmt='rustfmt --check --edition 2024 --config skip_children=true: one owned path, exit 0';productionChanged=$false;fullOwnerOrReverseRun='Not rerun for this reproduction-only source';originalTrackedWip=12;originalUntrackedWip=6}
 raw=[ordered]@{path='task-line-initial-inputs-baseline.raw.zip';sha256=(Get-FileHash -LiteralPath $archivePath).Hash.ToLowerInvariant();entries=$entries}
}
$fragment=([ordered]@{ownedLineInputBaseline=$record} | ConvertTo-Json -Depth 60).Trim().Replace("`r`n","`n")
$last=$ledger.LastIndexOf('}')
$after=$ledger.Substring(0,$last).TrimEnd()+",`n  "+$fragment.Substring(1,$fragment.Length-2).Trim()+"`n}`n"
$null=$after | ConvertFrom-Json -Depth 100
[IO.File]::WriteAllText((Join-Path (Get-Location) $ledgerPath),$after,[Text.UTF8Encoding]::new($false))
$historyPath='docs/implementation/convergence-evidence-history.md'
$history=[IO.File]::ReadAllText((Join-Path (Get-Location) $historyPath))
$addition=@"

## 2026-11-08 — 初期所有 Line 入力を両実行器で再現

再現テストの Source **$($source.commit)** を通常 commit/push し、親・tree・全 blob・完全差分を照合した。production は変更せず、既存 Native と同じ source factory で保存 AWBC の受入テストを追加。返却 Actor を通常 defer へ移し、その Cleanup Line の out から受け取り、さらに nested defer で消費する入力で、元の1-op／512-step、2 Line、取得・解放各1回の期待を維持する。選択2件は **0 PASS／2 FAIL／112 SKIP**。Native は Line 入口の AffineGroupCapture、AWBC は実行・保存前の verifier で capture ABI の recursively unrestricted 条件に拒否された。原診断・引数・終了100を保持する。
これにより、現状の初期所有入力の未達を Native 専用から同一入力の両 backend に訂正した。通常 defer の Actor packet、受入済み子 Dialogue、Generic Match、Line/init の完了は戻さない。直前の全113件112 PASS／1 FAILは当時の全件runとして保持し、追加後の全114件を実行したとはしない。1 path fmt は終了0。Source／ABI の解決は次の入力境界の実装として継続する。[元入力・診断・訂正理由・原本](acceptance-evidence/task-flow-registry-execution.json)。raw ZIP は$($entries.Count) entries、SHA-256 $($record.raw.sha256)。
"@
[IO.File]::WriteAllText((Join-Path (Get-Location) $historyPath),$history.TrimEnd()+"`n"+$addition.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$statusPath='docs/implementation/current-status.md'
$status=[IO.File]::ReadAllText((Join-Path (Get-Location) $statusPath))
$old='残る実測は、初期所有Line入力と開始後の共有入力の未分離によるNativeのAffineGroupCapture 1件。'
$new='初期所有Line入力と開始後の共有入力の未分離は、同じ入力でNativeのAffineGroupCaptureと保存AWBC verifierのCopy専用ABI拒否を再現した。追加Source '+$source.commit+' の選択2件は0 PASS／2 FAIL／112 SKIPで、全114件runではない。旧Native専用の未達表現をこの具体的根拠で訂正する。'
if(-not $status.Contains($old)){throw 'Current row differs'}
[IO.File]::WriteAllText((Join-Path (Get-Location) $statusPath),$status.Replace($old,$new),[Text.UTF8Encoding]::new($false))
[ordered]@{source=$source.commit;run=2;failed=2;entries=$entries.Count;sha256=$record.raw.sha256} | ConvertTo-Json -Compress
