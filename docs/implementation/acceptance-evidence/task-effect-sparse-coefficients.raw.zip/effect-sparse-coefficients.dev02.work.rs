#![allow(dead_code)]
#[path = "effect-sparse-coefficients.dev02.work-baseline.rs"]
mod baseline;
#[path = "D:/git/arcweft/crates/arcweft-core/src/effect_row/decision.rs"]
mod current;

use std::collections::BTreeSet;

macro_rules! meter {
    ($owner:ident, $name:ident) => {
        #[derive(Default)]
        struct $name { visit: usize, node: usize }
        impl $owner::DecisionControl for $name {
            type Error = std::convert::Infallible;
            fn charge(&mut self, work: $owner::DecisionWork) -> Result<(), Self::Error> {
                match work {
                    $owner::DecisionWork::Visit => self.visit += 1,
                    $owner::DecisionWork::Node => self.node += 1,
                }
                Ok(())
            }
        }
    }
}
meter!(baseline, Before);
meter!(current, After);

macro_rules! table {
    ($owner:ident, $meter:ident, $bits:expr) => {{
        use $owner::EffectDecision;
        let mut setup = $meter::default();
        let mut level: Vec<_> = $bits.iter().copied().map(EffectDecision::constant).collect();
        for variable in (0..7).rev() {
            let test = EffectDecision::variable(variable, &mut setup).unwrap();
            level = level.chunks_exact(2).map(|pair| {
                test.conditional(&pair[1], &pair[0], &mut setup).unwrap()
            }).collect();
        }
        level.pop().unwrap()
    }};
}

fn main() {
    let mut seed = 0x16d_1de9_fc43_u64;
    let mut seen = 0;
    let mut fewer = 0;
    let mut equal = 0;
    let mut more = 0;
    let mut max_added = 0;
    let mut max_saved = 0;
    for sample in 0..32 {
        let bits: Vec<_> = (0..128).map(|slot| {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            match sample {
                0 => false,
                1 => true,
                2 => slot & 0b0100100 == 0,
                _ => seed & (1 << (sample % 63)) != 0,
            }
        }).collect();
        let baseline = table!(baseline, Before, bits);
        let candidate = table!(current, After, bits);
        for mask in [0, 1, 3, 6, 8, 85, 170, 127, 128, 255] {
            let bound = (0..8).filter(|x| mask & (1 << x) != 0).collect::<BTreeSet<_>>();
            let mut prior = Before::default();
            let mut after = After::default();
            let expected = baseline.complete_conditionally(&bound, &mut prior).unwrap();
            let actual = candidate.complete_conditionally(bound.clone(), &mut after).unwrap();
            assert_eq!(format!("{:?}", actual.satisfiable()), format!("{:?}", expected.satisfiable()));
            assert_eq!(format!("{:?}", actual.principal()), format!("{:?}", expected.principal()));
            assert_eq!(actual.lower_envelope().domain(), &bound);
            let envelope = actual.lower_envelope();
            for var in 0..8 {
                assert_eq!(
                    envelope.get(&var).map(|value| format!("{value:?}")),
                    expected.lower_envelope().get(&var).map(|value| format!("{value:?}"))
                );
            }
            let mut verify = After::default();
            assert_eq!(&envelope.instantiate(&candidate, &mut verify).unwrap(), actual.principal());
            seen += 1;
            let prior = prior.visit + prior.node;
            let after = after.visit + after.node;
            max_added = max_added.max(after.saturating_sub(prior));
            max_saved = max_saved.max(prior.saturating_sub(after));
            match after.cmp(&prior) {
                std::cmp::Ordering::Less => fewer += 1,
                std::cmp::Ordering::Equal => equal += 1,
                std::cmp::Ordering::Greater => more += 1,
            }
        }
    }
    println!("exact_outputs={seen} fewer_charges={fewer} equal_charges={equal} more_charges={more} max_added={max_added} max_saved={max_saved}");
    for width in [8, 64, 512, 4096] {
        let bound = (0..width).collect::<BTreeSet<_>>();
        let mut before = Before::default();
        let mut after = After::default();
        let prior_relation = baseline::EffectDecision::variable(0, &mut before).unwrap();
        let current_relation = current::EffectDecision::variable(0, &mut after).unwrap();
        let old = prior_relation.complete_conditionally(&bound, &mut before).unwrap();
        let new = current_relation.complete_conditionally(bound, &mut after).unwrap();
        assert!(new.lower_envelope().get(&0).unwrap().is_constant(true));
        assert!(new.lower_envelope().get(&(width - 1)).unwrap().is_constant(false));
        assert!(new.lower_envelope().get(&width).is_none());
        assert_eq!(old.lower_envelope().len(), new.lower_envelope().domain().len());
        println!("coordinates={width} before={} after={}", before.visit + before.node, after.visit + after.node);
    }
}
