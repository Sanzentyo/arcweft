use arcweft_source::{SourceDocument, SourceDocumentId, SourceName, SourceSetRevision};

fn document(id: &str, path: &str, source: &str) -> SourceDocument {
    SourceDocument::try_new(SourceDocumentId::try_new(id).unwrap(), SourceName::path(path), source)
        .unwrap()
}

fn main() {
    let cases = [
        ("Vec<i64>", "Vec<i64>", "vector"),
        ("Seq<i64>", "Seq<i64>", "sequence"),
        ("Array<i64, 3>", "Array<i64, 3>", "nonempty array"),
        ("Array<i64, 0>", "Array<i64, 0>", "empty array"),
        ("Slice<i64>", "Vec<i64>", "slice"),
        ("Option<i64>", "Option<i64>", "Some"),
        ("Option<i64>", "Option<i64>", "None"),
        ("Result<i64, String>", "Result<i64, String>", "Ok"),
        ("Result<i64, String>", "Result<i64, String>", "Err"),
    ];
    let manifest = document("arcweft-source://arcw.toml", "arcw.toml", "");
    let mut offset = 0;
    for (input_type, output_type, value) in cases {
        for (annotation, expression) in [
            ("", "values.map(increment)".to_owned()),
            ("#[pure]", "map(increment)(values)".to_owned()),
            (
                "#[pure]",
                format!(
                    "{{ let mapper: {input_type} -> {output_type} effects {{}} = map(increment); mapper(values) }}"
                ),
            ),
        ] {
            offset += 1;
            let source = format!(
                r#"
#[pure]
fn increment(item: i64) -> i64 {{ return item + 1i64 }}
{annotation}
pub fn root(values: {input_type}) -> {output_type} {{ {expression} }}
flow main() -> String {{ return "unused" }}
"#
            );
            let module = document("arcweft-source://src/main.arcw", "src/main.arcw", &source);
            let revision = SourceSetRevision::try_for_identities([module.identity(), manifest.identity()]).unwrap();
            println!("ordinal={offset} type={input_type} value={value} expression={expression} revision={}", revision.to_hex());
        }
    }
    assert_eq!(offset, 27);
}
