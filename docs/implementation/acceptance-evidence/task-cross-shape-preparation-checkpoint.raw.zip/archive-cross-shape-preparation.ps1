$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\sanze\AppData\Local\Temp\arcweft-recursive-value-inference-20261111'
$base = '2f0abd78cd2db84bc50c7c0577d3c13011855021'
$source = (Get-Content -Raw -LiteralPath (Join-Path $scratch 'cross-shape-preparation.source-publication.json') | ConvertFrom-Json).source
if ((git rev-parse HEAD) -ne $source) { throw 'Unexpected source' }
function Read-Blob([string]$blob) {
    $start=[Diagnostics.ProcessStartInfo]::new()
    $start.FileName='git'; $start.Arguments='cat-file blob '+$blob
    $start.UseShellExecute=$false; $start.RedirectStandardOutput=$true
    $process=[Diagnostics.Process]::Start($start)
    $buffer=[IO.MemoryStream]::new()
    try {
        $process.StandardOutput.BaseStream.CopyTo($buffer)
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw 'Blob read failed'}
        return ,$buffer.ToArray()
    } finally { $buffer.Dispose(); $process.Dispose() }
}
function Physical-Lines([byte[]]$bytes) {
    if($bytes.Length -eq 0){return 0}
    $count=0
    foreach($byte in $bytes){if($byte -eq 10){$count++}}
    if($bytes[-1] -ne 10){$count++}
    return $count
}
$paths=@(git diff --name-only $base $source -- '*.rs')
$measurements=@(foreach($path in $paths){
    $entry=(& git ls-tree $base -- $path)
    $oldBytes=[byte[]]@()
    if($entry){
        if($entry -notmatch ' blob ([a-f0-9]+)\t'){throw 'Unexpected tree entry'}
        $oldBytes=Read-Blob $Matches[1]
    }
    $bytes=[IO.File]::ReadAllBytes((Join-Path (Get-Location) $path))
    $text=[Text.Encoding]::UTF8.GetString($bytes)
    $embedded=0
    $testModule=[regex]::Match($text,'(?m)^#\[cfg\(test\)\]\r?\nmod tests \{')
    if($testModule.Success){$embedded=Physical-Lines ([Text.Encoding]::UTF8.GetBytes($text.Substring($testModule.Index)))}
    @{path=$path; crate='arcweft-lang-sema'; bytes=$bytes.Length; physical_loc=(Physical-Lines $bytes); base_physical_loc=(Physical-Lines $oldBytes); growth=((Physical-Lines $bytes)-(Physical-Lines $oldBytes)); classification=$(if($path -match '/tests/|/tests\.rs$|_tests\.rs$|/test_support\.rs$'){'test'}else{'production'}); inline_test_module_loc=$embedded; sha256=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))).ToLowerInvariant()}
})
@{version=1; base=$base; source=$source; measured=(Get-Date -Format o); tracked_clean=(@(git status --porcelain --untracked-files=no).Count -eq 0); paths=$measurements; ownership='The remaining eager cross-shape reader is deleted, including its premature seal, for_branch and canonical-only accepts_with calls. Byte collections prepare exact U8 element relations on their actual child operand. AgentValue uses one shared membership algebra with canonical checking, actual element/key/value ports, scoped alias lookup, real template bindings and original Choice equation/direction/side metadata. ClosedScalar is an operand origin for a grammar leaf with no generic ports, source context, source receipt or Free permissions. Scalar expectations are billed before construction and retain the actual occurrence frames; TypeLeaf.rebuild remains the sole scalar shape constructor. No source lineage or Gamma is fabricated. Child/length projections of a closed scalar are refused, and source-specific admission denies forged Free references. The test-only source-context helper explicitly refuses this no-source role. Deferred cycle diagnostics retain the existing opportunity for later source errors and final cycle pruning. Nested AgentValue membership keeps its previous distinction from ordinary Never subtyping; fixed template variables are not concretized. Map-key scalar expectations preserve the original supplied side even in reverse acceptance. Seven new fixtures cover the exact byte collection family, shared AgentValue containers and exclusions, actual template element inference, real Choice equation keys in both directions, reverse map-key Choice provenance, nested bottom/fixed-template refusal, and closed scalar frame retention without Free authority. Original scalar/Ref assertions and budgets are retained. A malformed new fixture caused a fmt-only abort before Cargo; raw fmt logs and the explicit no-Cargo record are preserved. Tests remain unrun because library/test compilation fails. value_membership owns the existing language cross-shape rules and candidate state threading; scalar ownership and permissions remain on operand/projection; canonical/prepared dispatch and membership share their type authority. No parallel resolver/catalog, copied source, source reconstruction, canonical-success shim, body re-preparation or minimum solving during preparation is introduced. Function-local quantified/guarded effects, final transaction/solution callers and full frontend acceptance remain incomplete. Existing accepted Generic Match and runtime cuts are not reopened. Exact sizes/growth/test classification and inline test LOC are recorded for the changed owners. No Cargo dependency/feature, layer direction, I/O, unsafe, codec/version, production budget, jobs or profile change. Existing Cargo graph and reverse-dependency evidence is reused; no workspace scanner or broad acceptance is claimed.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $scratch 'cross-shape-preparation.ownership-review.json') -Encoding utf8NoBOM
$names=@(foreach($iteration in @('dev02','dev03')){foreach($suffix in @('-input.json','-fmt-apply.log','-fmt-check.log','-fmt-result.json','-check.log','-result.json')){'cross-shape-preparation.'+$iteration+$suffix}})
$names+=@('cross-shape-preparation.dev01-fmt-apply.log','cross-shape-preparation.dev01-fmt-check.log','cross-shape-preparation.dev01-fmt-result.json','cross-shape-preparation.dev01-pre-cargo-abort.json')
$names+=@('cross-shape-preparation.source-publication.json','cross-shape-preparation.ownership-review.json','cross-shape-preparation.staged-review.json','cross-shape-preparation.dev03-diagnostic-review.json')
$names+=@('run-cross-shape-preparation-check.ps1','archive-cross-shape-preparation.ps1')
$archivePath=Join-Path (Get-Location) 'docs/implementation/acceptance-evidence/task-cross-shape-preparation-checkpoint.raw.zip'
if(Test-Path -LiteralPath $archivePath){throw 'Archive exists'}
$manifest=@{version=1; base=$base; sources=@($source); entries=@($names | ForEach-Object { $item=Get-Item -LiteralPath (Join-Path $scratch $_); @{name=$_; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()} })}
$stream=[IO.File]::Open($archivePath,[IO.FileMode]::CreateNew)
$archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($name in $names){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $scratch $name),$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $entry=$archive.CreateEntry('manifest.json')
    $writer=[IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try{$writer.Write(($manifest | ConvertTo-Json -Depth 7))}finally{$writer.Dispose()}
} finally {$archive.Dispose();$stream.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($archivePath)
try{
    foreach($expected in $manifest.entries){
        $entry=$archive.GetEntry($expected.name)
        if($entry.Length -ne $expected.bytes){throw 'Archive length mismatch'}
        $inputStream=$entry.Open()
        try{$hash=([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($inputStream))).ToLowerInvariant()}finally{$inputStream.Dispose()}
        if($hash -ne $expected.sha256){throw 'Archive hash mismatch'}
    }
    $entryCount=$archive.Entries.Count
}finally{$archive.Dispose()}
$receipt=@{source=$source; archive='docs/implementation/acceptance-evidence/task-cross-shape-preparation-checkpoint.raw.zip'; entries=$entryCount; bytes=(Get-Item -LiteralPath $archivePath).Length; sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant(); source_paths=$paths.Count; physical_growth=($measurements | Measure-Object growth -Sum).Sum}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratch 'cross-shape-preparation.archive-receipt.json') -Encoding utf8NoBOM
$receipt | ConvertTo-Json
