$ErrorActionPreference='Stop'
$root=$PSScriptRoot
Set-Location 'D:/git/arcweft'
$pin=Get-Content -Raw "$root/source-expectation.final-input.json" | ConvertFrom-Json
$quality=Get-Content -Raw "$root/source-expectation.final-validation.json" | ConvertFrom-Json
if($quality.Steps.Count -ne 4 -or @($quality.Steps | Where-Object {$_.Name -ne 'owner-run' -and $_.ExitCode -ne 0}).Count -or @($quality.Steps | Where-Object {$_.Name -eq 'owner-run' -and $_.ExitCode -ne 100}).Count){throw 'Unexpected validation outcomes'}
$log=[IO.File]::ReadAllText("$root/source-expectation.final-owner-run.log")
$summary=[regex]::Match($log,'(?m)^\s*Summary \[\s*([0-9.]+)s\] 1639 tests run: 1633 passed(?: \((?<slow>[0-9]+) slow\))?, 6 failed, 0 skipped')
if(!$summary.Success){throw 'Unexpected owner summary'}
$terminal=@([regex]::Matches($log.Substring(0,$summary.Index),'(?m)^\s*(PASS|FAIL|SKIP) \[[^\]]+\] \(\s*([0-9]+)/1639\) (\S+) (.+)\r?$') | ForEach-Object {[pscustomobject]@{Result=$_.Groups[1].Value;Ordinal=[int]$_.Groups[2].Value;Binary=$_.Groups[3].Value;Name=$_.Groups[4].Value.TrimEnd();Id=$_.Groups[3].Value+'$'+$_.Groups[4].Value.TrimEnd()}})
$listing=Get-Content -Raw "$root/source-expectation.final-owner-list.json" | ConvertFrom-Json
$selected=@(foreach($property in $listing.'rust-suites'.PSObject.Properties){foreach($case in $property.Value.testcases.PSObject.Properties){if($case.Value.'filter-match'.status -eq 'matches'){$property.Name+'$'+$case.Name}}})
if($selected.Count -ne 1639 -or $terminal.Count -ne 1639 -or @($terminal | Group-Object Id | Where-Object Count -gt 1).Count -or @(Compare-Object -CaseSensitive @($selected|Sort-Object) @($terminal.Id|Sort-Object)).Count){throw 'Selection/terminal mismatch'}
$previous=Get-Content -Raw "$root/result-port-provenance.final-terminal.json" | ConvertFrom-Json
$difference=@(Compare-Object -CaseSensitive @($previous.Id|Sort-Object) @($selected|Sort-Object))
if($difference.Count -ne 3 -or @($difference|Where-Object SideIndicator -NE '=>').Count){throw 'Previous test IDs changed'}
$newIds=@($difference.InputObject)
$new=@($terminal|Where-Object {$newIds -ccontains $_.Id})
if($new.Count -ne 3 -or @($new|Where-Object Result -ne 'PASS').Count){throw 'New regression missing'}
$failed=@($terminal|Where-Object Result -eq 'FAIL'|ForEach-Object Name|Sort-Object)
$baseline=Get-Content -Raw "$root/result-port-provenance.summary.json" | ConvertFrom-Json
if(@(Compare-Object -CaseSensitive $baseline.Failures $failed).Count -or [regex]::Matches($log,'ExpressionCycle \{').Count -ne 5 -or [regex]::Matches($log,'PendingCallableEffectProjection \{').Count -ne 1){throw 'Failures changed'}
$metrics=Import-Csv "$root/source-expectation.structure/file_metrics.csv"
$measurements=@(foreach($p in $pin.Paths){
    if((Get-FileHash -LiteralPath $p.Path -Algorithm SHA256).Hash -ne $p.SHA256 -or (git hash-object -- $p.Path) -ne $p.Blob -or (git rev-parse "$($pin.Base):$($p.Path)") -ne $p.Blob){throw 'Source changed'}
    $row=@($metrics|Where-Object path -CEQ $p.Path)
    if($row.Count -ne 1){throw 'Missing canonical metric'}
    $lines=[IO.File]::ReadAllLines((Join-Path (Get-Location) $p.Path)).Count
    if([int]$row[0].physical_lines -ne $lines -or [long]$row[0].bytes -ne (Get-Item -LiteralPath $p.Path).Length){throw 'Canonical measurement mismatch'}
    $baseText=@(git show "$($pin.ChangeBase):$($p.Path)" 2>$null); $baseLines=if($LASTEXITCODE -eq 0){$baseText.Count}else{0}
    [pscustomobject]@{Path=$p.Path;Crate='arcweft-lang-sema';Bytes=[long]$row[0].bytes;PhysicalLOC=$lines;BaseLOC=$baseLines;Growth=$lines-$baseLines;Classification=if($p.Path -match '(^|/)tests(/|\.rs$)'){'test'}else{'production'};EmbeddedTestLOC=[int]$row[0].embedded_test_lines;SHA256=$p.SHA256;Blob=$p.Blob}
})
$structure=Get-Content -Raw "$root/source-expectation.structure.json" | ConvertFrom-Json
if($structure.ExitCode -ne 0 -or (Get-Content -Raw "$root/source-expectation.structure.stdout") -notmatch '(?m)^blocking violations: 0\r?$'){throw 'Structural gate not verified'}
$reverse=Get-Content -Raw "$root/source-expectation.reverse-reuse.json"|ConvertFrom-Json
$packages=@($reverse.Packages)
if($packages.Count -ne 22 -or !$reverse.CargoInputDiffEmpty -or $reverse.NewExecution){throw 'Unexpected reverse reuse'}
if((git rev-parse HEAD) -ne $pin.Base -or @(git diff --name-only HEAD).Count){throw 'Published source/base mismatch'}
$terminal|ConvertTo-Json -Depth 5|Set-Content -Encoding utf8 "$root/source-expectation.final-terminal.json"
[ordered]@{Version=1;Source=$pin.Base;Tree=(git rev-parse 'HEAD^{tree}');Parent=$pin.ChangeBase;Selected=1639;Passed=1633;Failed=6;Skipped=0;SlowTests=if($summary.Groups['slow'].Success){[int]$summary.Groups['slow'].Value}else{0};IdsEqual=$true;PreviousIdsRetainedWithThreeAdditions=$true;Duplicates=0;Suites=@($listing.'rust-suites'.PSObject.Properties).Count;ExecutionSeconds=[double]::Parse($summary.Groups[1].Value,[Globalization.CultureInfo]::InvariantCulture);Failures=$failed;ActualDiagnostics=@{ExpressionCycle=5;PendingCallableEffectProjection=1};NewTests=$new.Name;SourcePinsVerified=$true;SourcePublishedBeforeFinalValidation=$true;StructureExit=0;BlockingViolations=0;ClippyExit=0;FmtExit=0;Measurements=$measurements;DependencyMetrics=(Import-Csv "$root/source-expectation.structure/package_metrics.csv"|Where-Object package -CEQ 'arcweft-lang-sema');ReversePackages=$packages;ReverseReuse=$reverse;ConsumersNotRerun=$true;LastBroadSource='8b5e375a9c7b3096fe5ed2f65df556a463741a8d';Ownership='The checked source projection now owns the sole typed composition API for persistent source expectations. The actual and expected value are retained in distinct SourceExpectation roles. Scalar reads only the template value; spread Vec/Seq/Slice wrap that value; Array additionally takes the actual length; Map additionally takes the actual kind and key. The factory checks actual header equality and genuine lexical frame identity before construction. Source receipt and selected result association follow the actual, while original expectation context follows the template. Submit_probe uses the value template operand and removes its broad Derived edge. No new AST walker or capture union is introduced. Three regressions cover all six constructor families and exact tuple occurrence/root lifetime, forged header/kind/key/shape rejection, and equal-shaped foreign-frame rejection. Generic scheme specialization still uses Derived; source closure still needs typed effect and closed-row derivations. This cut does not authorize Free from inventories or claim those remaining migrations complete. No Cargo, external public shape, unsafe, I/O, version or budget changes.';Development='The production library check passed in 15.13 seconds. The development owner list compiled the three regressions before the final source-pinned list/run/Clippy/fmt. The six-path checkpoint was pushed before final validation according to the user preference. All 1636 prior test IDs and three new IDs must match terminal results; the six known failure IDs and actual diagnostics must be unchanged. The 22-package reverse graph is reused from 5012e0c6d26655fe005d150c321d47051a21096f after Cargo input diff verification, and the receipt records NewExecution=false. Full owner/frontend/API coverage is rerun, while 21 downstream package executions remain pinned to 8b5e375a9c7b3096fe5ed2f65df556a463741a8d. No new recursive body Native/AWBC, Wasm, Tier2, Free seal or certified effects acceptance is claimed.'}|ConvertTo-Json -Depth 9|Set-Content -Encoding utf8 "$root/source-expectation.summary.json"
Get-Content "$root/source-expectation.summary.json" -TotalCount 20
