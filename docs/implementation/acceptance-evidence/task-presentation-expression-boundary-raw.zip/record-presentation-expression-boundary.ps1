$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskTemp/assert-no-arcweft-build.ps1"
function Read-Record([string]$name) { Get-Content -LiteralPath "$taskTemp/$name.json" -Raw|ConvertFrom-Json -Depth 100 }
$stem='presentation-expression-boundary-reverse-20261101'
$publication=Read-Record 'checkpoint-presentation-expression-boundary.verified'
$testPublication=Read-Record 'checkpoint-presentation-evaluation-temporaries-regressions.verified'
$matrix=Read-Record "$stem.matrix"
$source=$publication.commit
$head=(git rev-parse HEAD).Trim()
if($head -ne $source -or $matrix.base -ne $source -or $matrix.status -ne 'terminal' -or $matrix.rows.Count -ne 5){throw 'Unexpected source or unfinished matrix'}
foreach($row in $publication.paths){if((git rev-parse ('HEAD:'+$row.path)).Trim() -ne $row.blob){throw 'Published implementation blob drift'}}
$owner=Read-Record 'presentation-expression-boundary-owner-final-20261101.runtime.terminal-audit'
$library=Read-Record "$stem.libraries.runtime.terminal-audit"
$cli=Read-Record 'presentation-expression-boundary.cli-target-coverage'
$comparison=Read-Record 'presentation-expression-boundary.cli-failure-comparison'
$generic=Read-Record "$stem.generic-coverage"
if($owner.passed -ne 13 -or $owner.failed -or $library.failed -or $generic.passed -ne 151){throw 'Unverified owner, library or accepted Generic Match cases'}
if($comparison.newFailureIds.Count -or $comparison.unselectedPriorFailures.Count){throw 'New or unselected CLI failure needs investigation before delivery'}
$quality=@(foreach($suffix in @('default-owners','workspace-check','clippy','structure','fmt')) {
    $record=Read-Record "presentation-expression-boundary-final-quality-20261101.$suffix"
    if($record.exitCode -ne 0 -or $record.sourceDrift){throw "Failed quality gate: $suffix"}
    [ordered]@{gate=$suffix;record=$record}
})
$freeze=Read-Record "$stem.source-freeze"
$reference=@{};foreach($row in $freeze.paths){$reference[$row.path]=$row.sha256;if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$bridge=@(foreach($name in @('presentation-expression-boundary-owner-final-20261101','presentation-expression-boundary-final-quality-20261101')) {
    $prior=Read-Record "$name.source-freeze"
    if($prior.paths.Count -ne $reference.Count -or @($prior.paths|Where-Object {$reference[$_.path] -ne $_.sha256}).Count){throw "Validated source bridge differs: $name"}
    [ordered]@{attempt=$name;base=$prior.base;publishedSource=$source;inputs=$reference.Count;pathHashDrift=0}
})
$attempts=@(foreach($name in @(
    'presentation-evaluation-temporaries-baseline1-20261101',
    'presentation-evaluation-temporaries-baseline2-20261101',
    'presentation-evaluation-temporaries-baseline3-20261101',
    'presentation-evaluation-temporaries-pattern-20261101',
    'presentation-evaluation-temporaries-frame1-20261101',
    'presentation-evaluation-temporaries-frame2-20261101',
    'presentation-evaluation-temporaries-owner-20261101',
    'presentation-evaluation-temporaries-owner2-20261101'
)) {
    $catalog=Read-Record "$name.catalog"
    $terminal=if(Test-Path -LiteralPath "$taskTemp/$name.runtime.terminal-audit.json"){Read-Record "$name.runtime.terminal-audit"}else{$null}
    [ordered]@{attempt=$name;catalog=$catalog;terminal=$terminal}
})
$priorQuality=@(foreach($suffix in @('default-owners','workspace-check','clippy','structure','fmt')){Read-Record "presentation-expression-boundary-quality-20261101.$suffix"})
$original=Get-Content -LiteralPath 'C:/Users/sanze/AppData/Local/Temp/arcweft-docs-reconcile-20261027/before.json' -Raw|ConvertFrom-Json
$changed=@($original.held|Where-Object {(Get-FileHash -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
if($changed.Count -ne 1 -or $changed[0].path -ne 'crates/arcweft-cli/tests/check/cli_runtime_bench.rs' -or (git hash-object -- $changed[0].path).Trim() -ne '4df23c4afc860ca51ff3255befe87b69a16de39b'){throw 'Original WIP changed'}
$untracked=@(git ls-files --others --exclude-standard)
if($untracked.Count -ne 6 -or @($untracked|Where-Object {$_ -notin @($original.held.path)}).Count){throw 'Original untracked set changed'}
$evidence='docs/implementation/acceptance-evidence'
$zipPath=Join-Path $evidence 'task-presentation-expression-boundary-raw.zip'
$receiptPath=Join-Path $evidence 'task-presentation-expression-boundary.json'
if((Test-Path -LiteralPath $zipPath) -or (Test-Path -LiteralPath $receiptPath)){throw 'Immutable evidence exists'}
$files=@(Get-ChildItem -LiteralPath $taskTemp -File|Where-Object {
    $_.Name -like 'presentation-evaluation-temporaries-*' -or
    $_.Name -like 'presentation-expression-boundary*' -or
    $_.Name -like 'checkpoint-presentation-evaluation-temporaries-regressions.*' -or
    $_.Name -like 'checkpoint-presentation-expression-boundary.*' -or
    $_.Name -like '*presentation-expression-boundary*.ps1' -or
    $_.Name -like 'cargo-clean-user-reply-*' -or
    $_.Name -in @('run-shared-identity-owner.ps1','audit-nextest-final-result.ps1')
})+@(Get-ChildItem -LiteralPath "$taskTemp/presentation-expression-boundary-quality-20261101.structure-report" -File)+@(Get-ChildItem -LiteralPath "$taskTemp/presentation-expression-boundary-final-quality-20261101.structure-report" -File)
$files=@($files|Sort-Object FullName -Unique)
$raw=@(foreach($file in $files){[ordered]@{name=[IO.Path]::GetRelativePath($taskTemp,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}})
Add-Type -AssemblyName System.IO.Compression
$archive=[IO.Compression.ZipFile]::Open([IO.Path]::GetFullPath($zipPath),[IO.Compression.ZipArchiveMode]::Create)
try {for($index=0;$index -lt $files.Count;$index++){$entry=$archive.CreateEntry($raw[$index].name,[IO.Compression.CompressionLevel]::Optimal);$stream=$entry.Open();try{$bytes=[IO.File]::ReadAllBytes($files[$index].FullName);$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}}}finally{$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($zipPath))
try {if($archive.Entries.Count -ne $raw.Count){throw 'Raw entry count differs'};foreach($row in $raw){$entry=$archive.GetEntry($row.name);$stream=$entry.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($entry.Length -ne $row.bytes -or $hash -ne $row.sha256){throw "Raw entry differs: $($row.name)"}}}finally{$archive.Dispose()}
$normal=@($matrix.rows|Where-Object {$_.group -in @('libraries','cli-unit','cli-integration')})
$result=[ordered]@{
    version=1;date='2026-11-01';source=$source;inspectedHead=$head
    status='General Source let patterns and actual synchronous Native function frames repaired; whole Presentation staging and final cross-backend acceptance remain separate'
    publication=$publication;testOnlyKnownFailingPublication=$testPublication
    sourceInputs=$reference.Count;sourceDrift=0;validatedInputBridge=$bridge
    attempts=$attempts;owner=$owner;priorQualityBeforePhaseRepair=$priorQuality;quality=$quality
    matrix=$matrix;library=$library;cli=$cli;cliFailureComparison=$comparison;genericCoverage=$generic
    libraryCaseComparison=(Read-Record 'presentation-expression-boundary.library-case-comparison')
    normalGroups=[ordered]@{passed=[int]($normal|ForEach-Object {$_.terminal.passed}|Measure-Object -Sum).Sum;failed=[int]($normal|ForEach-Object {$_.terminal.failed}|Measure-Object -Sum).Sum;ignored=[int]($normal|ForEach-Object {$_.terminal.skipped}|Measure-Object -Sum).Sum}
    implementation=@(
        'FinalExprLowerer carries the actual HIR pattern through a let continuation. Existing single bindings keep their Let fast path; other patterns use the existing FinalPatternLowerer and one Match arm. No tuple-specific lowering exception is introduced.',
        'Synchronous and scheduled Native invocations use one actual FunctionCallFrame, staged input owner, physical function scope, type instantiation and original caller queue. The former copied input staging loop and environment-only synchronous path are removed.',
        'Expression return continuations exist only in the live Rust evaluator. The existing PendingStorage phase supplies ValueAdmissionOrigin; inert headers reject Expression before caller queue validation or projection. Snapshot and owning restore check the continuation before copying/restoring that queue.'
    )
    corrections=@(
        'The initial evaluation-temporary custody hypothesis was not established by the actual Source reproductions. Direct call operands passed. Direct tuple inputs failed at general let-pattern lowering, and nested Native factory calls failed because the real environment function context had no matching call frame. The fix addresses these observed owners without inventing a parallel temporary-value bank.',
        'The test-only checkpoint intentionally retained 7 PASS and 5 FAIL. Baseline1 selected four nested cases (2 PASS/2 FAIL), baseline2 selected ten cases (6 PASS/4 FAIL), and baseline3 selected the final twelve Source cases (7 PASS/5 FAIL). Different selections and input freezes are preserved.',
        'The first frame catalog failed compilation due to a wrong relative import and an omitted exhaustive numeric-map continuation arm. The first Core owner catalog failed because its test module omitted the continuation import. These compiler failures remain in the raw record.',
        'The first complete quality gate passed before a subsequent ownership review tightened inert-header rejection ordering. Its receipts are historical inputs, not reused as final-source results. The extended 13-case owner and final quality gates were rerun for the final bytes.'
    )
    ownershipReview='RuntimePlan owns pattern lowering through its existing grammar. Engine owns the actual invocation frame and lexical environment; ScopeControl derives expression execution mode from the same continuation. Original code positions, type/effect bindings and queue ownership are still checked. No public wire tag, Cargo input, version marker, evaluation budget, assertion, loop bound or numeric fusion condition is weakened.'
    limits=@(
        'The Source cases verify two distinct Root/Image handles and evaluation order 12, direct and nested products/calls, one synchronous factory wrapper, canonical AWBC decoding and public AWBC save/restore at each existing OneOp boundary. They do not prove custody of every possible handwritten RuntimeExpr evaluation temporary.',
        'Private live synchronous expression frames deliberately cannot become resumable saved Rust evaluators. This is not new public Native save acceptance.',
        'Explicit scope capability, View/Removed producers, Source command/method and driver, full live-contour construction limits, registration failure atomicity and final Native/Web image parity remain distinct boundaries.',
        'Wasm, doctest and Tier 2 were not rerun for this input. Equal CLI failure IDs do not establish equal causes. The exact accepted Generic Match status remains in force.'
    )
    priorEvidence='task-presentation-factory-native-context.json'
    originalWip=[ordered]@{tracked=14;actualUntracked=6;unchangedOldHashes=19;benchWorkingBlob='4df23c4afc860ca51ff3255befe87b69a16de39b';heldPatchSha256=$publication.heldPatchSha256}
    raw=[ordered]@{path='task-presentation-expression-boundary-raw.zip';entryCount=$raw.Count;entryDrift=0;sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();entries=$raw}
    recordedAt=[DateTime]::UtcNow.ToString('o')
}
$result|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $receiptPath -Encoding utf8
[ordered]@{source=$source;focusedPassed=$owner.passed;libraryPassed=$library.passed;normalPassed=$result.normalGroups.passed;genericPassed=$generic.passed;cliPassed=$cli.passed;cliFailed=$cli.failed;rawEntries=$raw.Count;rawSha256=$result.raw.sha256;rawBytes=(Get-Item -LiteralPath $zipPath).Length}|ConvertTo-Json -Compress
