$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskTemp='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
$receipt=Get-Content -LiteralPath 'docs/implementation/acceptance-evidence/task-presentation-expression-boundary.json' -Raw|ConvertFrom-Json -Depth 100
$before=Get-Content -LiteralPath "$taskTemp/presentation-expression-boundary.docs-before.json" -Raw|ConvertFrom-Json
$source=$receipt.source
$link='[再現・修復・全逆依存の原本](acceptance-evidence/task-presentation-expression-boundary.json)'
$path='docs/implementation/current-status.md'
if((Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -ne $before.statusSha256){throw 'Current inventory changed since the documentation baseline'}
$text=[IO.File]::ReadAllText($path)
$header='確認日: 2026-11-01。公開実装Sourceは {0}。元14 tracked／6 actual untracked WIPを保持し、対象owner・品質gate・全53逆依存／CLIを同一の4,057入力で検証した。各行の結果は記載した入力・境界に限る。' -f $source
$text=[regex]::Replace($text,'(?m)^確認日:.*$',$header)
$library=$receipt.library
$normal=$receipt.normalGroups
$cli=$receipt.cli
$comparison=$receipt.cliFailureComparison
$check=@($receipt.matrix.rows|Where-Object group -eq 'cli-check')[0].terminal
$unit=@($receipt.matrix.rows|Where-Object group -eq 'cli-unit')[0].terminal
$ordinary=@($receipt.matrix.rows|Where-Object group -eq 'cli-integration')[0].terminal
$extra=@($receipt.matrix.rows|Where-Object group -eq 'cli-extra')[0].terminal
$caseComparison=$receipt.libraryCaseComparison
$metrics=Import-Csv -LiteralPath "$taskTemp/presentation-expression-boundary-final-quality-20261101.structure-report/file_metrics.csv"
$rust=@($metrics|Where-Object is_rust -eq 'true')
$physical=($rust|ForEach-Object {[int]$_.physical_lines}|Measure-Object -Sum).Sum
$findings=[IO.File]::ReadAllText("$taskTemp/presentation-expression-boundary-final-quality-20261101.structure-report/findings.md")
$reviewCount=[regex]::Matches($findings,'(?m)^## review-trigger ').Count
$blockingCount=[regex]::Matches($findings,'(?m)^## blocking ').Count
if($blockingCount){throw 'Blocking structural findings'}
$rows=[ordered]@{}
$rows['Presentation resource本体・Source factory実行']='| Presentation resource本体・Source factory実行 | **既受入を維持。tuple束縛・同期関数内imageの修復も検証・公開済み。staging全体は受入前** | Source {0}。元Source・executable・key・型・invocationを持つaffine本体と、metadata／Native実行元の引数評価前検査を維持する。letの複合patternは既存pattern grammarへ下ろし、Nativeの同期／scheduled呼出しは同じ実FunctionCallFrame・入力stager・元caller queueを所有する。live evaluator専用継続をinert headerで拒否し、caller packetのコピー・復元に先行させる。対象13件で直接／関数経由のtuple・call、別tokenのRoot/Image Handle、評価順12、canonical decoded AWBCの各step公開保存復元を確認した。全live候補の構築前検査・後段registrationの失敗原子性、明示scope capability、View生成、Source command／method・driverは別境界。{1}。 |' -f $source,$link
$rows['CLI・全 consumer の統合受入']='| CLI・全 consumer の統合受入 | **本Sourceの全CLIで{0}失敗・統合受入は未完了** | 全12 targetを同じ入力で実行した結果を下表へ集約する。個別の受入済み機能は、その境界の具体的な新未達を示さずに戻さない。{1}。 |' -f $cli.failed,$link
$rows['Presentation factory／共有値の逆依存matrix']='| Presentation factory／共有値の逆依存matrix | **全53 package選択。通常3群 {0} PASS／{1} FAIL／{2} ignored** | Source {3}・4,057入力。library／integrationは{4} PASS／{5} FAIL、CLI unit {6} PASS、通常6 integration target {7} PASS。実行case 0のcompile選択は{8} package。同じ53 package範囲の旧{9} case IDを保持し、追加{10}・削除{11}。既受入Generic Matchの151 IDは151／151 PASS。case／Source／EXE差分0。対象ownerの13件とは重複加算しない。{12}。 |' -f $normal.passed,$normal.failed,$normal.ignored,$source,$library.passed,$library.failed,$unit.passed,$ordinary.passed,$library.noMatchingSelectedTests.Count,$caseComparison.priorCasesWithinCurrentScope,$caseComparison.addedCases.Count,$caseComparison.removedCases.Count,$link
$rows['CLI追加check target']='| CLI追加check target | **{0} PASS／{1} FAIL／{2} ignored** | Source {3}・4,057入力。以前のSource {4} との失敗ID比較は同一{5}・新規{6}・解消{7}・未選択{8}。入力が異なるため、IDだけから原因同一とは判定しない。{9}。 |' -f $check.passed,$check.failed,$check.skipped,$source,$comparison.priorInput,$comparison.sameFailureIds.Count,$comparison.newFailureIds.Count,$comparison.resolvedFailureIds.Count,$comparison.unselectedPriorFailures.Count,$link
$rows['CLI追加3 integration target／全target照合']='| CLI追加3 integration target／全target照合 | **追加{0} PASS。全12 targetは{1} unique実行・{2} PASS／{3} FAIL・{4} ignored** | 同じSource {5}・4,057入力で全lib／bin／integrationを4 commandで照合した。case重複0、zero-case targetのcompile選択をruntimeと区別する。{6}。 |' -f $extra.passed,$cli.executedUnique,$cli.passed,$cli.failed,$cli.ignored,$source,$link
$rows['workspace check／Clippy・fmt・構造gate']='| workspace check／Clippy・fmt・構造gate | **default Core／RuntimePlanと各gate終了0・構造blocking0・警告は残存** | Source {0}と同一の4,057入力。default Core／RuntimePlanの全target・locked check、workspace全97 package・全target・全feature・locked check／Clippy、変更9 Rust pathのfmtは終了0。構造は{1} files／{2} Rust files・{3} physical Rust LOC・{4} review trigger・blocking0。Wasm・doctest・Tier 2は今回未再実行。{5}。 |' -f $source,$metrics.Count,$rust.Count,$physical,$reviewCount,$link
foreach($name in $rows.Keys){$pattern='(?m)^\| '+[regex]::Escape($name)+' \|.*$';if([regex]::Matches($text,$pattern).Count -ne 1){throw "Expected one row: $name"};$text=[regex]::Replace($text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match) $rows[$name]})}
$obsolete='(?m)^\| Native factory originのprivate owner \|.*\r?\n'
if([regex]::Matches($text,$obsolete).Count -ne 1){throw 'Prior private-owner row is missing or duplicated'}
$text=[regex]::Replace($text,$obsolete,'')
if([regex]::Match($text,'(?m)^\| Generic Match.*$').Value -cne $before.genericRow){throw 'Accepted Generic Match row changed'}
[IO.File]::WriteAllText($path,$text,[Text.UTF8Encoding]::new($false))
$history=@'

## Sourceの複合pattern／同期Native呼出しframeの修復 — 2026-11-01

公開実装Source {0}、親はテストのみのcheckpoint {1}。元14 tracked／6 actual untracked WIPとpatch SHA256 {2} を保持した。詳細・全command・凍結入力・失敗・実行ファイルhashは[原本](acceptance-evidence/task-presentation-expression-boundary.json)と、そのraw ZIPへ保持する。

訂正理由: 最初の「評価中temporaryのcustody」仮説は、実Sourceの再現で立証されなかった。direct callは両backendで通り、direct tupleはlet patternの単一binding制限、Nativeのnested／single wrapperは実env contextに対応するfunction frameの欠如で失敗した。仮説に合わせたtemporary bankは導入せず、既存pattern ownerと同じ実FunctionCallFrameへ修復した。Generic Matchの受入・公開を取り消す根拠ではなく、既受入の151 caseも維持する。

再現と修復の実測を別入力のまま保持する。baseline1は2 PASS／2 FAIL、baseline2は6 PASS／4 FAIL、最終12 Source caseのbaseline3は7 PASS／5 FAILであり、テストのみのcheckpointも既知失敗を含めて公開した。pattern修復後は9 PASS／3 FAIL、frame修復後は12／12 PASS。frameの初回catalog終了101は相対importとnumeric-mapのexhaustive arm漏れ、Core owner初回の終了101はtest moduleのimport漏れであり、runtime失敗と混同しない。追加ownerは13／13 PASS。その後の品質gateも全て終了0だったが、保存境界レビューでinert Expression headerの拒否をcaller packetの検査・コピー・復元より前へ揃えたため、最終の同一4,057入力で対象13件と品質gateを再実行し、全件／全gateが正常終了した。

実装は複合let patternを既存FinalPatternLowererとMatchへ下ろし、単純bindingのLet経路を維持する。同期Nativeもscheduledと同じ入力stager・実scope・元caller queue・type bindingを持つ関数frameへ統一し、コピーされた手動staging loopとenvだけの旧経路を除去した。live Rust evaluatorへのExpression継続を保存から再開可能とは扱わず、既存PendingStorageのlive／inert由来で事前拒否する。wire tag・契約version・Cargo入力、OneOp／max_ops 1・256回の上限、assertion・fusion条件は弱めていない。

全53逆依存の通常3群は{3} PASS／{4} FAIL／{5} ignored。library／integration {6} PASS、CLI unit {7} PASS、通常6 integration {8} PASS。旧{9} case IDを保持し、追加{10}・削除{11}。Generic Matchは既受入の正確な151 IDを選択・実行し、151／151 PASS。CLI checkは{12} PASS／{13} FAIL／{14} ignored、追加3 integrationは{15} PASS。全12 CLI targetは{16} unique実行・{17} PASS／{18} FAIL／{19} ignored・重複0。同一失敗ID {20}・新規{21}・解消{22}・未選択{23}という比較は、原因の同一性まで示すものではない。

現状一覧の整理理由: 古いSource 1e0b3f9d5eb86baa04e0359d656ba638cd0ffa3a のprivate owner 2,577件と、9c33b7de0ba05f0e764ecc2e17d593d20e68aaa3 の全逆依存／CLIを、今回の再実行結果へ更新した。旧private ownerの独立した現状行は、全Core／Compilerを含む今回の一覧と重複するため削除した。旧結果・full SHA・原本・履歴本文は変更せずに保持する。新Sourceで検証したpattern／frame境界以外のstaging、Source command／method・driver、全live候補の構築前制限、registration失敗原子性、公開Native save、Wasm／doctest／Tier 2・最終Native/Web画像parityの未確認を完了とはしない。

ユーザーの追加指定によるcargo clean --lockedは、この途中の品質gateが終了してビルドがない状態で実行し、149,486 files／159.9 GiBを削除した。4,057入力・HEAD・git statusの変化0を記録し、最終検証はその後の再ビルドで行った。ソース・検証記録を退避・削除したものではない。

'@
$history=$history -f $source,$receipt.testOnlyKnownFailingPublication.commit,$receipt.originalWip.heldPatchSha256,$normal.passed,$normal.failed,$normal.ignored,$library.passed,$unit.passed,$ordinary.passed,$caseComparison.priorCasesWithinCurrentScope,$caseComparison.addedCases.Count,$caseComparison.removedCases.Count,$check.passed,$check.failed,$check.skipped,$extra.passed,$cli.executedUnique,$cli.passed,$cli.failed,$cli.ignored,$comparison.sameFailureIds.Count,$comparison.newFailureIds.Count,$comparison.resolvedFailureIds.Count,$comparison.unselectedPriorFailures.Count
[IO.File]::AppendAllText('docs/implementation/convergence-evidence-history.md',$history,[Text.UTF8Encoding]::new($false))
Write-Output 'Current inventory updated from final source evidence; accepted Generic Match unchanged; prior history retained'
