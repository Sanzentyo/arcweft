$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Receipt([string]$name){Get-Content -LiteralPath "$taskEvidence/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$owner='bench-target-owner2-20261103';$rest='bench-target-reverse1-20261103';$out="$taskEvidence/bench-target.combined.json"
if(Test-Path -LiteralPath $out){throw 'Preserve existing combined evidence'}
$focused=Receipt "$owner.runtime.terminal-audit";$complement=Receipt "$rest.runtime.terminal-audit"
if(-not $focused.isPassingRun -or $focused.executed -ne 9){throw 'Focused owner has not passed'}
$old=Receipt "$owner.source-freeze";$current=Receipt "$rest.source-freeze";$map=@{};foreach($row in $old.paths){$map[$row.path]=$row.sha256}
if($old.paths.Count -ne $current.paths.Count){throw 'Input set changed'}
foreach($row in $current.paths){if($map[$row.path] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Source drift'}}
$beforePins=Receipt "$owner.binaries-before";$pins=Receipt "$rest.binaries-before";$pinMap=@{};foreach($row in $beforePins){$pinMap[$row.binary]=$row.sha256}
if($beforePins.Count -ne $pins.Count){throw 'Executable set changed'}
foreach($row in $pins){if($pinMap[$row.binary] -ne $row.sha256 -or (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Executable drift'}}
$coverage=@{};$all=@{};$ignored=@{}
foreach($stem in @($owner,$rest)){
 $inventory=Receipt "$stem.catalog.inventory";$selected=@{}
 foreach($row in $inventory.rows){$key=$row.binary+"`t"+$row.test;if($row.ignored){$ignored[$key]=$row}else{$all[$key]=$row};if($row.status -eq 'matches'){$selected[$key]=$row}}
 $after=$false;$observed=0
 foreach($line in [IO.File]::ReadLines("$taskEvidence/$stem.runtime.log")){
  if($line -cmatch '^\s*Summary\s+\['){$after=$true;continue}
  if($after -and $line -cmatch '^\s*(PASS|SLOW|FAIL|ABORT)\s+\[.*?\]\s+\(\s*\d+/\d+\)\s+(\S+)\s+(\S+)\s*$'){
   $status=$Matches[1];$binary=$Matches[2];$test=$Matches[3];$key=$binary+"`t"+$test
   if(-not $selected.ContainsKey($key) -or $coverage.ContainsKey($key)){throw 'Unexpected or duplicate final case'}
   $coverage[$key]=[ordered]@{package=$selected[$key].package;binary=$binary;test=$test;status=$status;run=$stem;kind='fresh-disjoint-selection'};$observed++
  }
 }
 if($observed -ne $selected.Count){throw 'Missing final cases'}
}
if($coverage.Count -ne $all.Count -or @(Compare-Object @($coverage.Keys) @($all.Keys)).Count){throw 'Incomplete reverse closure'}
function Partition([object[]]$rows){$failed=@($rows|Where-Object status -notin @('PASS','SLOW'));[ordered]@{executed=$rows.Count;passed=$rows.Count-$failed.Count;failed=$failed.Count;failureSet=$failed}}
$normal=Partition @($coverage.Values|Where-Object package -ne 'arcweft-cli');$cli=Partition @($coverage.Values|Where-Object package -eq 'arcweft-cli')
$baseline=Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-thread-indentation.json -Raw|ConvertFrom-Json -Depth 100
$oldCases=@($baseline.combined.cases|Where-Object package -eq 'arcweft-cli');$oldKeys=@($oldCases|ForEach-Object {$_.binary+"`t"+$_.test})
$newCases=@($coverage.Values|Where-Object package -eq 'arcweft-cli');$newKeys=@($newCases|ForEach-Object {$_.binary+"`t"+$_.test})
$oldFailures=@($baseline.combined.cli.failureSet|ForEach-Object {$_.binary+"`t"+$_.test});$newFailures=@($cli.failureSet|ForEach-Object {$_.binary+"`t"+$_.test})
$comparison=[ordered]@{baselineSource=$baseline.source;retained=@($newFailures|Where-Object {$_ -in $oldFailures});added=@($newFailures|Where-Object {$_ -notin $oldFailures});resolved=@($oldFailures|Where-Object {$_ -notin $newFailures});addedCases=@($newCases|Where-Object {($_.binary+"`t"+$_.test) -notin $oldKeys});removedCases=@($oldCases|Where-Object {($_.binary+"`t"+$_.test) -notin $newKeys});scope='Failure-ID comparison only. Keep actual current stderr and do not infer identical causes from equal IDs. Four previous benchmark cases were repaired in Source73; this cut adds explicit adapter-target ownership. A timing-test pass is not a general timing repair.'}
if($comparison.removedCases.Count){throw 'Unexpected dropped CLI cases'}
$prior=(Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-cli-yield-context.json -Raw|ConvertFrom-Json -Depth 100).combined.subsets.genericMatch.cases
$generic=@(foreach($row in $prior){$key=$row.binary+"`t"+$row.test;if(-not $coverage.ContainsKey($key)){throw 'Missing accepted Generic Match case'};$coverage[$key]})
if($generic.Count -ne 151){throw 'Generic subset changed'}
$value=[ordered]@{version=1;base=$current.base;graph=(Receipt 'bench-target.graph');focused=$focused;complement=$complement;sourceInputs=$current.paths.Count;sourceDrift=0;caseDrift=0;executables=$pins;executableDrift=0;distinctCases=$coverage.Count;freshCases=$coverage.Count;duplicateExecutions=0;normal=$normal;cli=$cli;ignored=$ignored.Count;generic=(Partition $generic);comparison=$comparison;cases=@($coverage.Values|Sort-Object package,binary,test);scope='Two disjoint fresh invocations under identical source, cases, features, target/toolchain and executable hashes cover the complete Syntax25 reverse closure. Initial8PASS/1FAIL before strict zero-field Headless codec correction remains separate history; no old result is reused as a current pass.'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $out -Encoding utf8
[ordered]@{distinct=$coverage.Count;normalPassed=$normal.passed;normalFailed=$normal.failed;cliExecuted=$cli.executed;cliPassed=$cli.passed;cliFailed=$cli.failed;genericPassed=$value.generic.passed;genericFailed=$value.generic.failed;ignored=$ignored.Count;retained=$comparison.retained.Count;added=$comparison.added.Count;resolved=$comparison.resolved.Count;newCliCases=$comparison.addedCases.Count}|ConvertTo-Json -Compress
