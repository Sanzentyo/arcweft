$ErrorActionPreference='Stop'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
& "$taskEvidence/assert-no-arcweft-build.ps1"
$focused=Get-Content -LiteralPath "$taskEvidence/bench-target-owner2-20261103.runtime.terminal-audit.json" -Raw|ConvertFrom-Json
if(-not $focused.isPassingRun -or $focused.executed -ne 9){throw 'The9 focused owner conditions have not passed'}
$command=(Get-Content -LiteralPath "$taskEvidence/bench-target-owner2-20261103.catalog.json" -Raw|ConvertFrom-Json).command
$selection=@($command[2..($command.Count-3)])
$selection[$selection.Count-1]='not ('+$selection[$selection.Count-1]+')'
$inventory=Get-Content -LiteralPath "$taskEvidence/bench-target-owner2-20261103.catalog.inventory.json" -Raw|ConvertFrom-Json
$expected=@($inventory.rows|Where-Object {-not $_.ignored -and $_.status -ne 'matches'}).Count
$paths=(Get-Content -LiteralPath "$taskEvidence/bench-target-owner2-20261103.source-freeze.json" -Raw|ConvertFrom-Json).paths.path
& "$taskEvidence/run-presentation-projection-owner.ps1" -Stem 'bench-target-reverse1-20261103' -Selection $selection -ExpectedMatches $expected -AdditionalPaths $paths
$runtimeExit=$LASTEXITCODE
if($runtimeExit -notin @(0,100)){throw 'Complement has no valid terminal result'}
& "$taskEvidence/run-action-payload-quality.ps1" -Epoch 'bench-target-reverse1-20261103' -Stem 'bench-target-quality1-20261103'
