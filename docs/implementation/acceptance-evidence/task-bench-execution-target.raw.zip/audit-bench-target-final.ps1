$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/git/arcweft'
$taskEvidence='C:/Users/sanze/AppData/Local/Temp/arcweft-1011-convergence-resume-cb798c1d'
function Receipt([string]$name){Get-Content -LiteralPath "$taskEvidence/$name.json" -Raw|ConvertFrom-Json -Depth 100}
$output="$taskEvidence/bench-target.final-combined.json"
if(Test-Path -LiteralPath $output){throw 'Preserve final evidence'}
$initial=Receipt 'bench-target.combined';$stem='bench-target-dependency1-20261103'
$before=Receipt 'bench-target-reverse1-20261103.source-freeze';$after=Receipt "$stem.source-freeze"
$sourceMap=@{};foreach($row in $before.paths){$sourceMap[$row.path]=$row.sha256}
if($before.paths.Count -ne $after.paths.Count){throw 'Input set differs'}
$delta=@(foreach($row in $after.paths){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Final input drift'};if($sourceMap[$row.path] -ne $row.sha256){$row}})
$expected=@('crates/arcweft-lsp/tests/dependency_direction.rs','docs/00-overview/crate-map.md')
if(@(Compare-Object @($delta.path) $expected).Count){throw 'Unexpected input delta'}
$pins=Receipt "$stem.binaries-before";$pinMap=@{};foreach($row in $initial.executables){$pinMap[$row.binary]=$row.sha256}
if($pins.Count -ne $initial.executables.Count){throw 'Binary set differs'}
$changed=@(foreach($row in $pins){if((Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ne $row.sha256){throw 'Final binary drift'};if($pinMap[$row.binary] -ne $row.sha256){$row}})
if($changed.Count -ne 1 -or $changed[0].binary -ne 'arcweft-lsp::dependency_direction'){throw 'Revalidate every changed binary'}
$inventory=Receipt "$stem.catalog.inventory"
$oldKeys=@($initial.cases|Where-Object binary -eq $changed[0].binary|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object)
$newKeys=@($inventory.rows|Where-Object {-not $_.ignored -and $_.binary -eq $changed[0].binary}|ForEach-Object {$_.binary+"`t"+$_.test}|Sort-Object)
if(@(Compare-Object $oldKeys $newKeys).Count){throw 'Changed binary case inventory changed'}
$rerun=Receipt "$stem.runtime.terminal-audit"
if(-not $rerun.isPassingRun -or $rerun.executed -ne 1){throw 'Repair not validated'}
$selected=@($inventory.rows|Where-Object status -eq 'matches')
if($selected.Count -ne 1 -or $selected[0].binary -ne $changed[0].binary){throw 'Wrong repair selection'}
$changedCases=@($initial.cases|Where-Object binary -eq $changed[0].binary)
if($changedCases.Count -ne 1 -or $changedCases[0].test -ne $selected[0].test){throw 'Changed binary contains unvalidated cases'}
$cases=@(foreach($row in $initial.cases){if($row.binary -eq $changed[0].binary){[pscustomobject]@{package=$row.package;binary=$row.binary;test=$row.test;status='PASS';run=$stem;kind='fresh-after-inventory-repair'}}else{[pscustomobject]@{package=$row.package;binary=$row.binary;test=$row.test;status=$row.status;run=$row.run;kind='reused-unchanged-executable';validatedBy='same123-binary-inventory; onlydependency_direction changed; production and all other code inputs identical'}}})
function Partition([object[]]$rows){$fail=@($rows|Where-Object status -notin @('PASS','SLOW'));[ordered]@{executed=$rows.Count;passed=$rows.Count-$fail.Count;failed=$fail.Count;failureSet=$fail}}
$genericKeys=@($initial.generic.failureSet)
$prior=(Get-Content -LiteralPath docs/implementation/acceptance-evidence/task-cli-yield-context.json -Raw|ConvertFrom-Json -Depth 100).combined.subsets.genericMatch.cases
$caseMap=@{};foreach($row in $cases){$caseMap[$row.binary+"`t"+$row.test]=$row}
$generic=@(foreach($row in $prior){$key=$row.binary+"`t"+$row.test;if(-not $caseMap.ContainsKey($key)){throw 'Missing accepted Generic case'};$caseMap[$key]})
if($generic.Count -ne 151){throw 'Generic subset changed'}
$value=[ordered]@{version=1;base=$after.base;graph=$initial.graph;focused=$initial.focused;complement=$initial.complement;repair=$rerun;initialWhole=[ordered]@{path='bench-target.combined.json';distinctCases=$initial.distinctCases;normal=$initial.normal;cli=$initial.cli;scope='All5859 fresh before the test-inventory repair; originalnormal1FAIL and CLI23FAIL retained verbatim'};sourceInputs=$after.paths.Count;sourceDrift=0;inputDelta=$delta;deltaRationale='Only the normal-dependency inventory test and its maintained crate-map rationale changed. Every production/Cargo/fixture input is identical. The exact full123 binary inventory differs only in dependency_direction, whose sole case was freshly executed. No runtime behavior or layer-direction assertion was weakened.';caseDrift=0;caseInventoryProof='The binary-filtered repair catalog enumerates8 cases, not the whole closure. Compare the changed executable sole case directly; retain other case and ignored inventories only through exact unchanged executable hashes.';executables=$pins;changedExecutables=$changed;executableDrift=0;distinctCases=$cases.Count;freshCases=1;reusedCases=$cases.Count-1;duplicateExecutions=0;normal=(Partition @($cases|Where-Object package -ne 'arcweft-cli'));cli=(Partition @($cases|Where-Object package -eq 'arcweft-cli'));ignored=$initial.ignored;generic=(Partition $generic);genericReused=$generic.Count;comparison=$initial.comparison;cases=$cases;scope='Final coverage is1 fresh replacement plus5858 source/executable-proven reused results, including all23 actual CLI failures. It is not a fresh all-case run after the inventory repair. The initial whole run and original failing dependency test are immutable history.'}
if($value.normal.failed -or $value.cli.failed -ne $initial.cli.failed){throw 'Unexpected final result'}
$value|ConvertTo-Json -Depth 100|Set-Content -LiteralPath $output -Encoding utf8
[ordered]@{normal=$value.normal.executed;normalPass=$value.normal.passed;cli=$value.cli.executed;cliPass=$value.cli.passed;cliFail=$value.cli.failed;fresh=$value.freshCases;reused=$value.reusedCases;genericReused=$generic.Count;changedBinaries=$changed.Count;inputDelta=$delta.path}|ConvertTo-Json -Depth 4 -Compress
